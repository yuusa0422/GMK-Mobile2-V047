package jp.gmk.mobile.domain.horizon

import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.security.MessageDigest
import kotlin.math.exp

/** In-process inference for the exact exported LightGBM trees. No network or Python. */
class PortableTreeModel private constructor(
    val featureNames: List<String>,
    private val classes: Int,
    private val trees: List<Array<Node>>
) {
    private data class Node(val feature: Int, val threshold: Double, val defaultLeft: Boolean,
        val missingZero: Boolean, val left: Int, val right: Int, val value: Double)

    fun predict(features: FloatArray): DoubleArray {
        require(features.size == featureNames.size)
        val out = DoubleArray(classes)
        for ((i, tree) in trees.withIndex()) {
            var at = 0
            while (tree[at].feature >= 0) {
                val n = tree[at]
                val v = features[n.feature].toDouble()
                val missing = v.isNaN() || (n.missingZero && v == 0.0)
                val left = if (missing) n.defaultLeft else v <= n.threshold
                at = if (left) n.left else n.right
            }
            out[i % classes] += tree[at].value
        }
        if (classes > 1) {
            val max = out.maxOrNull()!!
            for (i in out.indices) out[i] = exp(out[i] - max)
            val total = out.sum()
            for (i in out.indices) out[i] /= total
        }
        return out
    }

    companion object {
        fun load(bytes: ByteArray, expectedSha256: String): PortableTreeModel {
            require(bytes.size <= 16 * 1024 * 1024)
            val actual = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
            require(actual == expectedSha256) { "Model SHA-256 mismatch" }
            val input = DataInputStream(ByteArrayInputStream(bytes))
            val magic = ByteArray(8); input.readFully(magic)
            require(String(magic, Charsets.US_ASCII) == "GMKTREE1")
            val nf = input.readInt(); val nc = input.readInt(); val nt = input.readInt()
            require(nf in 1..512 && nc in 1..3 && nt in 1..5000 && nt % nc == 0)
            val names = List(nf) { val size=input.readInt(); require(size in 1..256); val b=ByteArray(size); input.readFully(b);String(b, Charsets.UTF_8) }
            require(names.toSet().size == nf)
            val trees = List(nt) {
                val count=input.readInt(); require(count in 1..2048)
                val nodes=Array(count) { Node(input.readInt(),input.readDouble(),input.readBoolean(),input.readBoolean(),input.readInt(),input.readInt(),input.readDouble()) }
                for ((i,n) in nodes.withIndex()) {
                    require(n.value.isFinite() && n.threshold.isFinite())
                    if(n.feature >= 0) require(n.feature < nf && n.left in (i+1) until count && n.right in (i+1) until count)
                    else require(n.left == -1 && n.right == -1)
                }
                nodes
            }
            require(input.available() == 0)
            return PortableTreeModel(names,nc,trees)
        }
    }
}

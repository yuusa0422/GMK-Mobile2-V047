package jp.gmk.mobile.data

import android.content.Context
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/** Prepares slow inputs outside the scan. No model network request is made by apply(). */
class HorizonRuntime(context: Context, private val repository: MarketRepository) {
    private val app=context.applicationContext
    private val prefs=app.getSharedPreferences("gmk_horizon_policy",Context.MODE_PRIVATE)
    private val cache=HorizonMarketCache(File(app.filesDir,"horizon_history_v1"))
    private val prepared=AtomicReference<PreparedHorizonFrame?>(null)
    @Volatile private var adapter: HorizonScanAdapter?=null
    @Volatile private var backgroundStatus="STARTING"
    @Volatile private var prepareMs=0.0
    @Volatile private var quoteStatus="NOT_CAPTURED"
    private var job: Job?=null
    fun observe(rows: List<RateRow>)=cache.observe(rows)
    fun start(scope: CoroutineScope, enabled: ()->Boolean, scanIdle: ()->Boolean) {
        if(job?.isActive==true)return
        job=scope.launch(Dispatchers.Default) {
            try {
                fun load(name: String)=app.assets.open("horizon_policy/$name").use { PortableTreeModel.load(it.readBytes(),HorizonModelCatalog.hashes.getValue(name)) }
                val saved=if(prefs.getString("version","")==HorizonModelCatalog.VERSION)prefs.getString("scores","").orEmpty().split(',').mapNotNull { it.toDoubleOrNull() } else emptyList()
                adapter=HorizonScanAdapter(listOf(load("base_3m.bin"),load("base_10m.bin"),load("base_15m.bin")),load("r15_path_protect15.bin"),saved)
                withContext(Dispatchers.IO) { HorizonFeatureService.SYMBOLS.forEach { cache.load(it) } }
                backgroundStatus="WARMING"
            } catch(e: Exception) {
                if(e is CancellationException)throw e
                backgroundStatus="MODELS_UNAVAILABLE:${e.javaClass.simpleName}"
                return@launch
            }
            var cursor=0;var bitcoinDay=0;var attemptedBoundary=0L;var quoteBoundary=0L
            val lastFetch=HashMap<String,Long>()
            while(isActive) {
                var now=System.currentTimeMillis()
                val boundary=(now/300_000+1)*300L
                if(!enabled() || !HorizonFeatureService.scheduled(boundary)) {
                    prepared.set(null);backgroundStatus="INACTIVE";delay(1000);continue
                }
                var remaining=boundary-now/1000
                if(remaining in 15..25 && boundary!=attemptedBoundary && HorizonFeatureService.scheduled(boundary)) {
                    attemptedBoundary=boundary
                    val began=System.nanoTime()
                    try {
                        val frame=adapter?.prepare(cache.snapshot(),boundary)
                        if(System.currentTimeMillis()<(boundary-10)*1000)prepared.set(frame)
                        backgroundStatus=if(frame==null)"WARMING_DATA" else "FRAME_READY"
                    } catch(e: Exception) {
                        if(e is CancellationException)throw e
                        backgroundStatus="PREPARE_UNAVAILABLE:${e.javaClass.simpleName}"
                    }
                    prepareMs=(System.nanoTime()-began)/1e6
                }
                now=System.currentTimeMillis()
                val quoteBudget=HorizonTimingPolicy.quoteBudgetMs(now,boundary)
                if(quoteBudget>0 && quoteBoundary!=boundary && enabled() && scanIdle()) {
                    quoteBoundary=boundary
                    try {
                        val rows=withTimeout(quoteBudget) { repository.fetchRates() }
                        cache.observe(rows)
                        quoteStatus="CAPTURED:${rows.count { it.freshnessStatus=="LIVE" }}"
                    } catch(e: TimeoutCancellationException) { quoteStatus="TIMEOUT_NATIVE_CONTINUES" }
                    catch(e: CancellationException) { throw e }
                    catch(e: Exception) { quoteStatus="UNAVAILABLE:${e.javaClass.simpleName}" }
                }
                // History ends before :40. The bounded :41..:45 quote request ends before :50.
                now=System.currentTimeMillis();remaining=boundary-now/1000
                val second=now/1000%60
                if(second in 6..35 && enabled() && scanIdle()) {
                    val symbol=HorizonFeatureService.SYMBOLS[cursor++%19]
                    val warm=cache.size(symbol)<4000
                    if((warm || remaining<=60) && now-(lastFetch[symbol] ?: 0L)>25_000) {
                        try {
                            val day=if(symbol=="BTCJPY" && warm)bitcoinDay++%5 else 0
                            val rows=withTimeout(3500) { repository.fetchHorizonHistory(symbol,warm,day) }
                            cache.merge(symbol,rows,System.currentTimeMillis())
                            withContext(Dispatchers.IO) { cache.persist(symbol) }
                            lastFetch[symbol]=now
                        } catch(e: TimeoutCancellationException) { backgroundStatus="FETCH_TIMEOUT_NATIVE_CONTINUES" }
                        catch(e: CancellationException) { throw e }
                        catch(e: Exception) { backgroundStatus="FETCH_UNAVAILABLE:${e.javaClass.simpleName}";lastFetch[symbol]=now }
                    }
                }
                delay(250)
            }
        }
    }
    fun apply(native: ScanResult,candles: Map<String,List<Candle>>): ScanResult {
        if(native.source!="AUTO")return native
        val policy=adapter ?: return native
        val boundary=runCatching { java.time.ZonedDateTime.parse(native.entryTimeJst).toEpochSecond() }.getOrNull() ?: return native
        val result=policy.apply(native,candles,prepared.getAndSet(null),cache.quoteSnapshot((boundary-10)*1000))
        if(native.source=="AUTO")prefs.edit().putString("version",HorizonModelCatalog.VERSION).putString("scores",policy.snapshot().joinToString(",")).apply()
        return result
    }
    fun diagnosticStats(): JSONObject=JSONObject().put("version",HorizonModelCatalog.VERSION)
        .put("status",adapter?.status ?: "MODELS_UNAVAILABLE").put("background",backgroundStatus)
        .put("feature_prepare_ms",prepareMs).put("inference_ms",adapter?.lastInferenceMs ?: 0.0)
        .put("pre_scan_quote",quoteStatus)
        .put("partial_ohlc_available",false).put("fixed_model_available_from","2026-08-01T00:00:00+09:00")
    fun stop() { job?.cancel();prepared.set(null);repository.cancelInFlightRequests() }
}

package jp.gmk.mobile.domain.horizon

object HorizonModelCatalog {
    const val VERSION = "R15_PATH_LGBM_PROTECT15_T025_20261001"
    const val AVAILABLE_FROM_EPOCH = 1785510000L
    val hashes: Map<String, String> = linkedMapOf(
        "base_3m.bin" to "1425144aac1bb189b9d41e3155321fcc9100ce7b9fa4cedc80b5b60ff8c69f18",
        "base_10m.bin" to "a34ac469634c21a498878289231ea3ee4cf83b9f18d2000f9222d4591fbf3fe7",
        "base_15m.bin" to "8db557b1b2799a91d31ef600cb2b0342d59767b668a94f7e95627f5c53ab59d8",
        "r15_path_protect15.bin" to "052ed75a4c2d5757c86ebb035634d804f6dbec8e1b99d22a9aa5107f53bf5a63"
    )
}

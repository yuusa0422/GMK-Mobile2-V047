package jp.gmk.mobile.domain

import java.time.ZonedDateTime

/** Two entries can share a judge time when their horizons differ. */
object HistoryIdentity {
    fun alreadyRecorded(rows: List<HistoryRow>, result: ScanResult): Boolean = rows.any {
        (result.scanId.isNotBlank() && it.scanId==result.scanId) || sameAutoFrame(it,result)
    }
    fun sameAutoFrame(row: HistoryRow, result: ScanResult): Boolean {
        if(!result.source.startsWith("AUTO") || row.source!=result.source)return false
        if(row.entryTimeJst.isNotBlank() && result.entryTimeJst.isNotBlank())return runCatching {
            ZonedDateTime.parse(row.entryTimeJst).toInstant()==ZonedDateTime.parse(result.entryTimeJst).toInstant()
        }.getOrDefault(row.entryTimeJst==result.entryTimeJst)
        return result.scanId.isNotBlank() && row.scanId==result.scanId
    }
}

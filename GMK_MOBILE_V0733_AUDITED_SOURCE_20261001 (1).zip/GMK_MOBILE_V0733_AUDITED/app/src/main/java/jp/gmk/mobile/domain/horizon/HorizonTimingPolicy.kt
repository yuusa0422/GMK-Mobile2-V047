package jp.gmk.mobile.domain.horizon

/** A bounded quote refresh after normal polling stops, ending before the T-10 scan. */
object HorizonTimingPolicy {
    fun quoteBudgetMs(nowMs: Long, boundaryEpoch: Long): Long {
        val remaining = boundaryEpoch * 1000 - nowMs
        return if (remaining in 15_000L..19_000L) minOf(3_500L, remaining - 11_000L) else 0L
    }
}

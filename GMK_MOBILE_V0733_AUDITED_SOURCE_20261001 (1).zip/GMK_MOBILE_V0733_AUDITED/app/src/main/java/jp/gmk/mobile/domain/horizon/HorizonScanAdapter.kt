package jp.gmk.mobile.domain.horizon

import jp.gmk.mobile.domain.*
import java.time.ZonedDateTime

data class PreparedHorizonFrame(val boundary: Long, val service: HorizonFeatureService,
    val features: Array<Array<FloatArray>>, val preparedMs: Long)

/** Existing scan API remains the sole entry point. The adapter protects native ENTRY first. */
class HorizonScanAdapter(private val models: List<PortableTreeModel>, private val correction: PortableTreeModel,
    seed: List<Double> = emptyList()) {
    private val gate=PastCoverageGate(seed)
    private val joint=JointHorizonPolicy(models,gate)
    private val flip=HorizonFlipPolicy(correction)
    private var lastBoundary=0L
    private var lastResult: ScanResult?=null
    @Volatile var status="WARMING"; private set
    @Volatile var lastInferenceMs=0.0; private set
    fun snapshot(): List<Double> = synchronized(this) { gate.snapshot() }

    fun prepare(prices: Map<String,List<Candle>>, boundary: Long): PreparedHorizonFrame? {
        if(!HorizonFeatureService.scheduled(boundary) || boundary-10<HorizonModelCatalog.AVAILABLE_FROM_EPOCH)return null
        val budgetMs=minOf(8000L,(boundary-12)*1000-System.currentTimeMillis())
        if(budgetMs<=0)return null
        val service=HorizonFeatureService(prices,emptyMap(),boundary,LocalRuleEngine(),System.nanoTime()+budgetMs*1_000_000)
        if(!service.ready)return null
        val columns=models.mapIndexed { j,m->service.jointFeatures(m.featureNames,intArrayOf(3,10,15)[j]) }
        return PreparedHorizonFrame(boundary,service,Array(6){s->Array(3){j->columns[j][s]}},System.currentTimeMillis())
    }

    @Synchronized
    fun apply(native: ScanResult, candles: Map<String,List<Candle>>, prepared: PreparedHorizonFrame?,
        quotes: Map<String,HorizonQuote>, nowMs: Long=System.currentTimeMillis()): ScanResult {
        val began=System.nanoTime()
        val entry=runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return native
        val boundary=entry.toEpochSecond()
        if(native.source!="AUTO" || !HorizonFeatureService.scheduled(boundary)) { status="NATIVE_MANUAL";return native }
        if(boundary==lastBoundary)return lastResult ?: native
        if(boundary<lastBoundary) { status="OUT_OF_ORDER_NATIVE";return native }
        val top=native.top1 ?: return native
        fun finish(result: ScanResult, reason: String): ScanResult {
            lastBoundary=boundary;lastResult=result;status=reason
            lastInferenceMs=(System.nanoTime()-began)/1e6
            return result
        }
        // This comes before every model, quote, readiness and deadline check.
        if(top.decision=="ENTRY") {
            gate.decide(Double.POSITIVE_INFINITY,true,true)
            return finish(native,"NATIVE_ENTRY_PROTECTED")
        }
        fun fallback(reason: String): ScanResult {
            gate.decide(Double.NEGATIVE_INFINITY,false,false)
            return finish(native,reason)
        }
        if(boundary-10<HorizonModelCatalog.AVAILABLE_FROM_EPOCH)return fallback("MODEL_NOT_AVAILABLE_AT_SCAN")
        if(boundary*1000-nowMs<500)return fallback("DEADLINE_NATIVE")
        if(prepared==null || prepared.boundary!=boundary)return fallback("WARMING_OR_FRAME_MISSING")
        if(!prepared.service.matchesNative(candles))return fallback("INPUT_REVISION_NATIVE")
        return try {
            val service=prepared.service
            service.attachQuotes(quotes)
            service.fillQuotes(prepared.features,models.map { it.featureNames })
            val base=HorizonDecision(HorizonFeatureService.SYMBOLS.indexOf(top.instrument),top.direction=="HIGH",3,false)
            val safe=BooleanArray(6) { service.strictSafe(it) }
            val choice=joint.choose(prepared.features,safe,base)
            if(!choice.decision.entry)return finish(native,"COVERAGE_GATE_SKIP")
            val d=choice.decision
            val corrected=flip.correct(d,if(d.minutes==15 && service.pathValid())service.flipFeatures(d.symbol,d.high,correction.featureNames) else null,
                safe[d.symbol],service.pathValid(),false,boundary)
            val final=corrected.decision
            val symbol=HorizonFeatureService.SYMBOLS[final.symbol]
            val candidate=native.candidates.single { it.instrument==symbol }.copy(
                rank=1,direction=if(final.high)"HIGH" else "LOW",grade="R",probability=null,decision="ENTRY",
                reasons=listOf("判定: ${final.minutes}分",HorizonModelCatalog.VERSION,corrected.reason)+
                    listOfNotNull(corrected.utility?.let { "paired_utility=$it" }))
            val candidates=listOf(candidate)+native.candidates.filter { it.instrument!=symbol }.sortedBy { it.rank }.mapIndexed { i,c->c.copy(rank=i+2) }
            finish(native.copy(judgeTimeJst=entry.plusMinutes(final.minutes.toLong()).toString(),candidates=candidates),
                if(corrected.changed)"R15_APPLIED" else "JOINT_${final.minutes}M")
        } catch(e: Exception) {
            // Gate may already have recorded this frame; never add the same frame twice.
            finish(native,"ADAPTER_ERROR_NATIVE:${e.javaClass.simpleName}")
        }
    }
}

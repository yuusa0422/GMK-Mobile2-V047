import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import java.io.*
import java.security.MessageDigest
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.*

private fun sha(b: ByteArray)=MessageDigest.getInstance("SHA-256").digest(b).joinToString(""){"%02x".format(it)}
private fun stream(file: File)=DataInputStream(BufferedInputStream(FileInputStream(file)))
private fun DataInputStream.string(): String { val b=ByteArray(readInt());readFully(b);return String(b) }
private fun DataInputStream.floats(n: Int)=FloatArray(n){readFloat()}
fun main(args: Array<String>) {
    val assets=File(args[0]);val fixtures=File(args[1]);val models=listOf(3,10,15).map { h->val n="base_${h}m.bin";PortableTreeModel.load(File(assets,n).readBytes(),HorizonModelCatalog.hashes.getValue(n)) }
    val regression=PortableTreeModel.load(File(assets,"r15_path_protect15.bin").readBytes(),HorizonModelCatalog.hashes.getValue("r15_path_protect15.bin"))
    var cases=0;var changed=0;var maxError=0.0
    val byMonth=HashMap<String,PortableTreeModel>()
    stream(File(fixtures,"correction.bin")).use { input->repeat(input.readInt()) {
        val month=input.string();val b=input.readLong();val s=input.readInt();val high=input.readBoolean();val h=input.readInt();val en=input.readBoolean();val native=input.readBoolean();val safe=input.readBoolean();val path=input.readBoolean();val expected=input.readDouble();val changes=input.readBoolean();val x=input.floats(90)
        val model=byMonth.getOrPut(month){val bytes=File(fixtures,"r15_$month.bin").readBytes();PortableTreeModel.load(bytes,sha(bytes))}
        val p=model.predict(x)[0];maxError=max(maxError,abs(p-expected));check(abs(p-expected)<1e-12)
        val base=HorizonDecision(s,high,h,en);val result=HorizonFlipPolicy(model).correct(base,x,safe,path,native,b,ZonedDateTime.parse("$month-01T00:00:00+09:00").toEpochSecond())
        check(result.changed==changes){"policy mismatch $b"};check(result.decision.entry==en && result.decision.symbol==s)
        if(changes){check(result.decision.minutes==3 && result.decision.high!=high);changed++}else check(result.decision==base)
        cases++
    };check(input.read()==-1) }
    println("CORRECTION_PASS cases=$cases changed=$changed max_error=$maxError")
    var parents=0
    for((j,h) in listOf(3,10,15).withIndex())stream(File(fixtures,"parent_$h.bin")).use { input->val n=input.readInt();val nf=input.readInt();repeat(n) {
        val x=input.floats(nf);val expected=DoubleArray(3){input.readDouble()};val got=models[j].predict(x)
        check(got.indices.all { abs(got[it]-expected[it])<1e-12 }) { "parent prediction mismatch horizon=$h" };parents++
    };check(input.read()==-1) }
    println("PARENT_PREDICTION_PASS cases=$parents")
    var featureCount=0;var mismatch=0;var predictionMismatch=0;var totalPrepare=0.0
    val nativeRows=StringBuilder()
    stream(File(fixtures,"raw_features.bin")).use { input->repeat(input.readInt()) {
        val b=input.readLong();val prices=HorizonFeatureService.SYMBOLS.associateWith { List(input.readInt()){Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble())} }
        val quotes=HorizonFeatureService.SYMBOLS.take(6).mapNotNull { s->if(!input.readBoolean())null else {
            val received=input.readLong();val source=input.readLong();val price=input.readDouble();val bid=input.readDouble().takeIf { it.isFinite() };val ask=input.readDouble().takeIf { it.isFinite() };val live=input.readBoolean();val start=input.readLong();val o=input.readDouble();val h=input.readDouble();val l=input.readDouble();val n=input.readInt();val progress=input.readDouble()
            check(abs(progress-5.0/6)<1e-8 || !progress.isFinite()) { "historical partial progress $progress" }
            s to HorizonQuote(received,source,price,bid,ask,live,start,o,h,l,n)
        }}.toMap()
        val started=System.nanoTime();val service=HorizonFeatureService(prices,quotes,b,LocalRuleEngine());check(service.ready)
        val actual=models.mapIndexed { j,m->service.jointFeatures(m.featureNames,listOf(3,10,15)[j]) }
        totalPrepare+=(System.nanoTime()-started)/1e6
        val instant=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"));val ctx=prices.filterKeys { it in HorizonFeatureService.SYMBOLS.take(6) }.mapValues { it.value.takeLast(120) }
        val native=LocalRuleEngine().scan(ctx,"AUTO",instant.minusSeconds(10),instant)
        for(c in native.candidates)nativeRows.append("$b ${c.rank} ${c.instrument} ${c.direction} ${c.grade} ${c.probability} ${c.score} ${c.decision}\n")
        for(s in 0..5) {
            for(j in 0..2) {
                val expected=input.floats(152);val got=actual[j][s]
                for(k in got.indices) {
                    featureCount++;val good=(expected[k].isNaN() && got[k].isNaN()) || abs(expected[k]-got[k])<=2e-5f*(1+abs(expected[k]))
                    if(!good){if(mismatch<80)println("FEATURE_MISMATCH $b $s ${models[j].featureNames[k]} expected=${expected[k]} got=${got[k]}");mismatch++}
                }
                val a=models[j].predict(got);val e=models[j].predict(expected)
                if(a.indices.any { abs(a[it]-e[it])>1e-12 })predictionMismatch++
            }
            val expected=input.floats(90);val got=service.flipFeatures(s,true,regression.featureNames)
            for(k in got.indices) { featureCount++;val good=abs(expected[k]-got[k])<=2e-5f*(1+abs(expected[k]));if(!good){if(mismatch<80)println("FLIP_FEATURE_MISMATCH $b $s ${regression.featureNames[k]} expected=${expected[k]} got=${got[k]}");mismatch++} }
            if(abs(regression.predict(got)[0]-regression.predict(expected)[0])>1e-12)predictionMismatch++
        }
    };check(input.read()==-1) }
    check(File(fixtures,"native_kotlin.txt").readText()==nativeRows.toString()) { "Native rule output changed" }
    println("RAW_FEATURE_AUDIT values=$featureCount mismatches=$mismatch prediction_mismatches=$predictionMismatch prepare_total_ms=$totalPrepare")
    val damaged=File(assets,"base_3m.bin").readBytes();damaged[20]=(damaged[20].toInt() xor 1).toByte()
    check(runCatching { PortableTreeModel.load(damaged,HorizonModelCatalog.hashes.getValue("base_3m.bin")) }.isFailure)
    val gate=PastCoverageGate(listOf(.2,.4,.6,.8));check(!gate.decide(.15,true,false).first);check(gate.decide(.25,true,false).first);check(gate.decide(.0,true,true).first)
    val base=HorizonDecision(0,true,15,true)
    check(!HorizonFlipPolicy(regression).correct(base,FloatArray(90){Float.NaN},true,true,false,HorizonModelCatalog.AVAILABLE_FROM_EPOCH+100).changed)
    check(!HorizonFlipPolicy(regression).correct(base,FloatArray(90),true,true,false,HorizonModelCatalog.AVAILABLE_FROM_EPOCH).changed)
    println("SAFETY_PASS checksum, past_only_gate, missing_features, availability_clock")
    check(mismatch==0 && predictionMismatch==0) { "Raw feature parity failed" }
}

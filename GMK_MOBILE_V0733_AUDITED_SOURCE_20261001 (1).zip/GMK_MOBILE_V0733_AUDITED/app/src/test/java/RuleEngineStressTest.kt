import jp.gmk.mobile.domain.*
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Random

fun main() {
    val rnd=Random(73131L)
    val names=listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY")
    val engine=LocalRuleEngine()
    val jst=ZoneId.of("Asia/Tokyo")
    val start=1760000000000L
    val t0=System.nanoTime()
    repeat(1000) { k ->
        val map=names.withIndex().associate { (idx,n) ->
            var px=if(n=="BTCJPY") 12_000_000.0 else 100.0+idx*15
            n to (0 until 80).map { i ->
                val step=(rnd.nextDouble()-0.5)*(if(n=="BTCJPY") 8000.0 else 0.05)
                val o=px; val c=(px+step).coerceAtLeast(0.0001); px=c
                val pad=kotlin.math.abs(step)*0.3 + if(n=="BTCJPY") 50.0 else 0.002
                Candle(start+i*60_000L,o,maxOf(o,c)+pad,minOf(o,c)-pad,c,1.0)
            }
        }
        val entry=ZonedDateTime.of(2026,7,1+(k%20),9+(k%14),0,0,0,jst)
        val r=engine.scan(map,"STRESS",entry.minusSeconds(10),entry)
        require(r.candidates.size==6)
        require(r.candidates.map{it.rank}.toSet()==(1..6).toSet())
        require(r.candidates.all{it.direction in setOf("HIGH","LOW")})
        require(r.candidates.all{it.decision in setOf("ENTRY","SKIP")})
        require(r.candidates.all{it.score.isFinite() && (it.probability?.isFinite() != false)})
    }
    val ms=(System.nanoTime()-t0)/1_000_000.0
    println("PASS rule engine stress scans=1000 elapsedMs=$ms avgMs=${ms/1000.0}")
}

import jp.gmk.mobile.domain.*
import java.time.ZoneId
import java.time.ZonedDateTime

fun series(base: Double, slope: Double, start: Long): List<Candle> = (0 until 60).map { i ->
    val o = base + slope * i
    val c = o + slope * 0.4
    Candle(start + i * 60_000L, o, maxOf(o,c) + 0.01, minOf(o,c) - 0.01, c, 1.0)
}

fun main() {
    val names = listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY")
    val start=1760000000000L
    val map=names.withIndex().associate { (i,n) -> n to series(100.0+i*10, if(i%2==0) 0.01 else -0.008, start) }
    val engine=LocalRuleEngine()
    val jst=ZoneId.of("Asia/Tokyo")
    val entry=ZonedDateTime.of(2026,7,1,12,0,0,0,jst)
    val r=engine.scan(map,"TEST",entry.minusSeconds(10),entry)
    require(r.candidates.size==6) { "expected 6 candidates" }
    require(r.candidates.map{it.rank}.toSet()==(1..6).toSet())
    require(r.candidates.all{it.direction in setOf("HIGH","LOW")})
    require(r.candidates.all{it.decision in setOf("ENTRY","SKIP")})
    // Engine-level malformed OHLC defense: enough malformed rows should remove that instrument.
    val broken=map.toMutableMap()
    broken["USDJPY"] = List(30){ i -> Candle(start+i*60_000L, Double.NaN, 1.0, 1.0, 1.0) }
    val b=engine.scan(broken,"TEST",entry.minusSeconds(10),entry)
    require(b.candidates.none{it.instrument=="USDJPY"}) { "malformed USDJPY must be excluded" }
    // Production time contract: 23:00 is outside active window and must not publish ENTRY.
    val late=ZonedDateTime.of(2026,7,1,23,0,0,0,jst)
    val l=engine.scan(map,"TEST",late.minusSeconds(10),late)
    require(l.top1?.decision=="SKIP") { "outside 09:00-23:00 must SKIP" }
    println("PASS production rule integration candidates=${r.candidates.size} top=${r.top1?.instrument}/${r.top1?.decision}")
}

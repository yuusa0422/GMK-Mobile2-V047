import org.junit.Test
import java.io.File

/** The existing CLI suites now gate APK creation with the project's Kotlin compiler. */
class ProductionRegressionTest {
    private val root=File(requireNotNull(System.getProperty("gmk.projectRoot")))
    private fun runSuite(name: String, vararg args: String) {
        Class.forName(name).getMethod("main", Array<String>::class.java).invoke(null, args as Any)
    }
    @Test fun modelAndRawFeatureParity() = runSuite("HorizonParityTestKt",
        File(root,"app/src/main/assets/horizon_policy").path,File(root,"tools/fixtures").path)
    @Test fun adapterIntegration() = runSuite("HorizonIntegrationTestKt",File(root,"app/src/main/assets/horizon_policy").path)
    @Test fun deepAuditRegressions() = runSuite("HorizonDeepAuditTestKt")
    @Test fun legacyRuleStressAndGuards() {
        for(name in listOf("RuleEngineStressTestKt","OneMinuteEngineStressTestKt","ProductionRuleAuditTestKt","CutInPolicyTestKt","OfficialWinGateFuzzTestKt")) {
            Class.forName(name).getMethod("main").invoke(null)
        }
    }
    @Test fun legacyGateReplay() = runSuite("jp.gmk.mobile.domain.OfficialWinGateReplayTestKt",
        File(root,"OFFICIAL_WIN_GATE_OOS_202607_0818.csv").path)
}

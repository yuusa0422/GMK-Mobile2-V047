import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import jp.gmk.mobile.data.HorizonMarketCache
import java.nio.file.Files
import java.time.ZonedDateTime

fun main(args: Array<String>) {
    val b=ZonedDateTime.parse("2026-10-01T12:00:00+09:00").toEpochSecond()
    for(remaining in 0L..30_000L) {
        val budget=HorizonTimingPolicy.quoteBudgetMs(b*1000-remaining,b)
        check((budget>0)==(remaining in 15_000L..19_000L))
        if(budget>0)check(budget<=3500 && remaining-budget>=11_000)
    }
    val prices=HorizonFeatureService.SYMBOLS.take(6).associateWith {
        (0..60).map { i->Candle((b-120-(60-i)*60)*1000,100.0,100.1,99.9,100.0) }
    }
    val good=HorizonQuote((b-12)*1000,(b-13)*1000,100.0,null,null,true)
    fun safe(q: HorizonQuote): Boolean=HorizonFeatureService(prices,mapOf("USDJPY" to q),b,LocalRuleEngine()).strictSafe(0)
    check(safe(good));check(safe(good.copy(bid=99.99,ask=100.01)))
    for(q in listOf(good.copy(bid=99.99),good.copy(ask=100.01),good.copy(bid=Double.NaN,ask=100.01),
        good.copy(bid=100.1,ask=99.9),good.copy(bid=99.0,ask=101.0),good.copy(sourceMs=(b-21)*1000),
        good.copy(receivedMs=(b-9)*1000)))check(!safe(q))
    val dir=Files.createTempDirectory("gmk-deep-cache").toFile()
    try {
        val cache=HorizonMarketCache(dir)
        fun row(at: Long)=RateRow("USDJPY",100.0,null,null,"TEST",0.0,"LIVE",sourceEpochMs=at,receivedEpochMs=at)
        cache.observe(listOf(row((b-12)*1000)))
        cache.observe(listOf(row((b-18)*1000))) // Slower old request completed after the newer batch.
        cache.observe(listOf(row((b-9)*1000))) // Future-to-scan quote must remain excluded.
        check(cache.quoteSnapshot((b-10)*1000).getValue("USDJPY").receivedMs==(b-12)*1000)
    } finally { dir.deleteRecursively() }
    val row=HistoryRow(1,"saved","AUTO","","USDJPY","HIGH","R","ENTRY",
        entryTimeJst="2026-10-01T12:00:00+09:00[Asia/Tokyo]",judgeTimeJst="2026-10-01T12:15:00+09:00",resultStatus="WIN")
    val retry=ScanResult(scanId="retry",source="AUTO",entryTimeJst="2026-10-01T03:00:00Z")
    check(HistoryIdentity.alreadyRecorded(listOf(row),retry))
    check(HistoryIdentity.alreadyRecorded(listOf(row),retry.copy(scanId="saved",source="MANUAL")))
    check(!HistoryIdentity.alreadyRecorded(listOf(row),retry.copy(source="AUTO_1M")))
    check(!HistoryIdentity.alreadyRecorded(listOf(row),retry.copy(entryTimeJst="2026-10-01T03:05:00Z")))
    val gate=PastCoverageGate(List(1000){Double.NaN})
    check(gate.snapshot().isEmpty());check(gate.decide(.5,true,false).first)
    println("PASS deep audit: 30001 timing points, malformed books, out-of-order quotes, immutable history identity, NaN seed")
}

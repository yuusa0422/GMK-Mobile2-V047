package jp.gmk.mobile.domain

import java.io.File
import kotlin.math.abs

/** Standalone JVM replay check for OfficialWinGate; no Android dependency. */
fun main(args: Array<String>) {
    require(args.isNotEmpty()) { "CSV path required" }
    val lines = File(args[0]).readLines()
    require(lines.size > 1) { "empty replay" }
    val header = lines.first().split(',')
    val pos = header.withIndex().associate { it.value to it.index }
    fun Array<String>.s(name: String) = this[pos.getValue(name)]
    fun Array<String>.d(name: String) = s(name).toDouble()
    fun Array<String>.i(name: String) = s(name).toInt()
    fun Array<String>.b(name: String) = s(name).equals("true", true)

    var checked = 0
    var gateEntries = 0
    var wins = 0
    var maxDelta = 0.0
    for (line in lines.drop(1)) {
        if (line.isBlank()) continue
        val a = line.split(',').toTypedArray()
        val r = OfficialWinGate.evaluate(
            OfficialWinGate.Features(
                instrument = a.s("instrument"),
                regime = a.s("regime"),
                finalDirection = a.s("final_direction"),
                grade = a.s("grade"),
                ruleId = a.i("rid_new"),
                reverse = a.b("rev_new"),
                probability = a.d("rate_new"),
                effectiveScore = a.d("score_eff"),
                regimeConfidence = a.d("regime_conf"),
                hourJst = a.i("hour"),
                rawConfidence = a.d("confidence"),
                rsi14 = a.d("rsi14"),
                atrPct = a.d("atr_pct"),
                agreement = a.d("agreement"),
                efficiency = a.d("efficiency"),
                emaGapAtr = a.d("ema_gap_atr")
            )
        )
        val baseEntry = a.b("entry_new")
        val expected = a.d("gate_score")
        // Runtime evaluates this gate only for an already-ENTRY TOP1. E rows may carry
        // a historical base rule id even though their final stage is NONE, so their
        // unused score is intentionally not part of the equivalence contract.
        if (baseEntry) {
            maxDelta = maxOf(maxDelta, abs(r.score - expected))
            require(abs(r.score - expected) < 1e-10) { "score mismatch ${r.score} vs $expected" }
        }
        val expectedEntry = a.b("gate_entry")
        val actualEntry = baseEntry && r.allowEntry
        require(actualEntry == expectedEntry) { "entry mismatch at row $checked" }
        if (actualEntry) {
            gateEntries++
            if (a.s("outcls") == "WIN") wins++
        }
        checked++
    }
    val invalidCases = listOf(
        OfficialWinGate.Features("BAD", "RANGE", "HIGH", "C", 1, false, 0.6, 0.1, 0.5, 12, 0.6, 50.0, 0.001, 0.5, 0.5, 0.5),
        OfficialWinGate.Features("USDJPY", "UNKNOWN", "HIGH", "C", 1, false, 0.6, 0.1, 0.5, 12, 0.6, 50.0, 0.001, 0.5, 0.5, 0.5),
        OfficialWinGate.Features("USDJPY", "RANGE", "HIGH", "C", 1, false, Double.NaN, 0.1, 0.5, 12, 0.6, 50.0, 0.001, 0.5, 0.5, 0.5),
        OfficialWinGate.Features("USDJPY", "RANGE", "HIGH", "C", 1, false, 0.6, 0.1, 0.5, 23, 0.6, 50.0, 0.001, 0.5, 0.5, 0.5)
    )
    require(invalidCases.all { !OfficialWinGate.evaluate(it).allowEntry }) { "malformed gate input must fail closed" }

    val entryRate = gateEntries.toDouble() / checked.toDouble()
    val winRate = wins.toDouble() / gateEntries.toDouble()
    require(entryRate >= 0.70) { "entry rate below contract: $entryRate" }
    require(winRate >= 0.60) { "official win rate below contract: $winRate" }
    println("PASS rows=$checked entry=$gateEntries entryRate=$entryRate wins=$wins officialWinRate=$winRate maxDelta=$maxDelta")
}

import jp.gmk.mobile.domain.OfficialWinGate
import java.util.Random

fun main() {
    val rnd = Random(731L)
    val instruments = arrayOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY")
    val regimes = arrayOf("TREND_DOWN","RANGE","CHOPPY","TREND_UP")
    val directions = arrayOf("HIGH","LOW")
    val grades = arrayOf("S","A","B","C")
    repeat(200_000) {
        val f = OfficialWinGate.Features(
            instrument = instruments[rnd.nextInt(instruments.size)],
            regime = regimes[rnd.nextInt(regimes.size)],
            finalDirection = directions[rnd.nextInt(directions.size)],
            grade = grades[rnd.nextInt(grades.size)],
            ruleId = rnd.nextInt(30_000),
            reverse = rnd.nextBoolean(),
            probability = 0.45 + rnd.nextDouble() * 0.45,
            effectiveScore = -1.0 + rnd.nextDouble() * 2.0,
            regimeConfidence = rnd.nextDouble(),
            hourJst = 9 + rnd.nextInt(14),
            rawConfidence = 0.50 + rnd.nextDouble() * 0.38,
            rsi14 = rnd.nextDouble() * 100.0,
            atrPct = rnd.nextDouble() * 0.02,
            agreement = rnd.nextDouble(),
            efficiency = rnd.nextDouble(),
            emaGapAtr = rnd.nextDouble() * 20.0
        )
        val r = OfficialWinGate.evaluate(f)
        require(r.score.isFinite() && r.score in 0.0..1.0) { "invalid score: $r" }
        require(r.allowEntry == (r.score >= OfficialWinGate.THRESHOLD))
    }
    val invalid = OfficialWinGate.Features("USDJPY","RANGE","HIGH","C",1,false,0.6,0.1,0.5,12,0.6,50.0,Double.POSITIVE_INFINITY,0.5,0.5,0.5)
    require(!OfficialWinGate.evaluate(invalid).allowEntry)
    println("PASS official gate fuzz 200000")
}

GMK MOBILE v0.7.32 本番ソース

versionCode 102 / 0.7.32-production-horizon-flip
5分間隔AUTOに3/10/15分選択とR15条件付き反転を追加しました。
従来の3分ENTRYは保護し、従来SKIP枠に追加判定を行います。追加候補のランクRは「追加判定」です。
1分判定とMANUALの3分判定は従来通りです。

これはソースZIPです。APK生成・署名・実機インストールは未実行です。
採用根拠の研究ReplayはENTRY71.97%、公式勝率58.52%、最大10連敗。完全未使用の最終OOSと実機成績は未測定です。
詳細はGMK_MOBILE_V0732_AUDIT_JA.txtを確認してください。v0.7.31以前の同梱資料の成績は、今回の新しい版の実績ではありません。

ビルド
1. 別添build.ymlをリポジトリの.github/workflows/build.ymlへ配置し、旧ワークフローを置き換えます。
2. GMK_MOBILE_V0732_PRODUCTION_SOURCE_R15_20261001.zipを名前を変えずリポジトリのルートへ置きます（大きいZIPはGitでpushしてください）。
3. Actions → Build GMK Mobile v0.7.32 → Run workflow。push時も実行されます。
4. 成功後のArtifactsにあるGMK_MOBILE_V0732_APKをダウンロードします。中にGMK_MOBILE.apk、SHA256.txt、signing-mode.txt、package.txtがあります。
ワークフローは115行。Android SDK35、Gradle8.9、Java17を準備し、資産/ソースの検査、Kotlinコンパイル、APK組み立て、署名/ID/版/SHA検証を行います。
展開したプロジェクトをリポジトリのルートへ置く方法にも対応します。ZIPがある場合はZIPを優先し、同名ZIPの複数配置や版違いはエラーで停止します。
GitHub上でのワークフロー実行とAPK生成はこの環境では未確認です。
ローカルで同じ環境がある場合: gradle :app:compileDebugKotlin :app:assembleDebug
APK出力: app/build/outputs/apk/debug/app-debug.apk
既存アプリを更新する際は同じ署名が必要です。
固定署名を使う場合はRepository secretsへGMK_SIGNING_KEYSTORE_BASE64、GMK_SIGNING_STORE_PASSWORD、GMK_SIGNING_KEY_ALIAS、GMK_SIGNING_KEY_PASSWORDを登録してください。一部だけの登録は停止します。未登録ならその実行環境のdebug署名です。異なる署名では既存アプリを上書き更新できません。

判定開始
AUTOは00/05/10…分の10秒前にスキャン。追加モデルの入力が揃うまで既存判定を継続します。
主要6通貨の過去M1を4,000本以上準備し、鮮度と入力整合性が通った場合に追加判定を開始します。
推論は全て端末内で動作し、PC/Ollamaは不要です。価格取得には通信が必要です。
異常時は既存判定へ戻ります。モデル資産のSHA、入力欠測、締切を確認します。
実運用の勝率とENTRY率は履歴で計測してください。P72は過去スコアの閾値設定であり、実ENTRY率の保証ではありません。

検証
bash tools/run_horizon_tests.sh
Java17とkotlincが必要です。研究入力と期待値をtools/fixturesへ同梱しています。
release_evidenceには実行ログ、研究参考CSV、変更一覧、元ファイルのSHA、監査結果があります。
PACKAGE_MANIFEST_SHA256.txtは自分自身を除く全ファイルのSHAです。

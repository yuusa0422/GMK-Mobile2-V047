GitHubブラウザアップロード対応版（各ZIP 25,000,000バイト未満）
本体ZIPとGMK_V0733_TEST_DATA.zipを両方、同じリポジトリのルートへアップロードしてください。
本体と検証データは解凍不要です。ファイル名を変更しないでください。
新しいGMK_V0733_WORKFLOW.zipだけを展開し、.github/workflows/build.ymlを置き換えてください。
Actionsが2つのZIPを安全に展開し、全SHA、モデル/既存ルール単体試験、Lint、APK生成を行います。
片方が欠けた状態のpush実行は不足ファイルのエラーになります。両方をアップロードした後にRun workflowを実行してください。
アプリ本体のソース・モデル・検証用データの内容は前回v0.7.33と同一です。変更は配布構成とワークフロー、パッケージ検証テストのみです。
旧監査書の「本体ZIP1つ」「Gitでpush」の手順は、この手順で置き換えます。
今回もAndroid実ビルド/実機試験は未実行です。

GMK MOBILE v0.7.33 / versionCode103
8件の不具合・検証不足を修正したソース版です。詳細はGMK_V0733_DEEP_AUDIT_JA.txt。
今回の修正版Kotlin/Androidビルド・実機試験は未実行です。
旧v0.7.32やv0.7.31の報告書・JVMログは過去証拠です。新しい版の動作合格を意味しません。

1. build.ymlをリポジトリの.github/workflows/build.ymlへ配置/置換。
2. GMK_MOBILE_V0733_AUDITED_SOURCE_20261001.zipをリポジトリ直下へGitでpush。
3. Actions → Build GMK Mobile v0.7.33 → Run workflow。
4. 成功後、GMK_MOBILE_V0733_APKのGMK_MOBILE.apkを取得。
Java17、SDK35、Gradle8.9。115行のworkflowはコンパイル/単体試験/Android Lintを通した後にAPKを生成します。
既存アプリを上書きするには同じ署名が必要です。4つのGMK_SIGNING_* secretsは詳細監査を参照。

モデル・閾値・従来1分/3分ルールは変更していません。
参考ReplayはENTRY71.97%、公式勝率58.52%、最大10連敗。完全未使用OOSと新版の実運用成績は未測定。
未準備/レート欠測/締切時は従来判定へ復帰します。

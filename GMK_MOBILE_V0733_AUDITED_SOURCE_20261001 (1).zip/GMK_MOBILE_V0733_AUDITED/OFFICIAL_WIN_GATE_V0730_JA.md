# GMK MOBILE RULE v0.7.30 公式勝率ゲート 研究監査

更新日: 2026-10-01

## 目的

- PC版とは無関係。スマートフォン版3分ローカルルールのみを対象とする。
- 合格条件は **平日09:00-23:00のENTRY率70%以上** かつ **DRAWをLOSEとして数える公式勝率60%以上**。
- 9月の結果を9月自身へ戻すResearchRuleIdPolicyは使用しない。

## 監査で判明した重要事項

従来の `PRODUCTION_REPLAY_V079_CONSERVATIVE.csv` の60.354%は `usable_3m=1`、つまりDRAWを除外した値だった。
現行仕様ではDRAWはLOSEなので、この値を「公式60%達成」と扱わない。

またJan-Aug replay 38,640枠には土日11,088枠が含まれていた。現行3分実機は6/6通貨strict gateのため土日はENTRYしない。
したがって本研究では **平日09:00-23:00だけ**をENTRY率/公式勝率の母集団とする。

### v0.7.9 平日ベースライン

- 対象平日枠: 27,552
- ENTRY: 24,289
- ENTRY率: 88.16%
- 採点可能ENTRY: 24,266
- DRAW=LOSE公式勝率: 57.41%
- DRAW除外参考勝率: 60.36%

## v0.7.30 OfficialWinGate

既存の方向判定、FinalRankPolicy、反転、TOP1選択は変更しない。
TOP1が既にS/A/B/Cのときだけ固定ゲートを評価し、スコア0.530未満をE/SKIPへ降格する。

### 安全契約

- EをENTRYへ昇格しない。
- HIGH/LOWを反転しない。
- 候補2〜6へ作用しない。
- 実行時ネットワーク、AI、LLM、オンライン学習なし。
- 30本・深さ3の固定決定木。定数はKotlinへ埋め込み。
- 使用特徴は既にLocalRuleEngineが計算済みの値だけ: instrument / regime / finalDirection / grade / stage / reverse / probability / effectiveScore / regimeConfidence / hour / confidence / RSI14 / ATR% / agreement / efficiency / EMA-gap/ATR。

## 学習・OOS分離

- 固定ルール生成: 2026-01-01〜2026-06-30の平日09:00-23:00
- OOS: 2026-07-01〜2026-08-18
- OOSは決定木生成へ使用していない。
- targetはWIN=1、LOSE=0、DRAW=0。

## OOS結果（Jul〜Aug18合算）

- 全対象枠: 5,880
- ゲートENTRY: 4,144
- ENTRY率: **70.48%**
- 結果取得済みゲートENTRY: 4,136
- WIN: 2,491
- LOSE: 1,423
- DRAW: 222（LOSEとして集計）
- 公式勝率: **60.23%**

合算では指定条件を同時達成した。

### 注意

- 7月単月は条件を上回る一方、8/1〜8/18単月は条件を下回る。したがって「毎月60%以上」を証明したものではない。
- 9/2〜9/22の同梱replay CSVにはOfficialWinGateが必要とするATR%、RSI、agreement、efficiency、EMA-gap/ATR等の生特徴が保存されていないため、v0.7.30ゲートを9月へ正確に再計算できない。
- 9月固定v0.7.28本番ポリシーがENTRY 88.29% / 公式48.70%まで崩れた事実は残る。v0.7.30を「9月も60%」とは認定しない。
- 次の完全未使用期間（10月）で固定条件のままforward validationが必要。

## 実装検証

- `OfficialWinGate.kt` 単体JVM compile: PASS
- `LocalRuleEngine + FinalRankPolicy + Models + OfficialWinGate` Kotlin compile: PASS
- Python生成スコアとKotlin実装をOOS 5,871採点行で1行ずつ照合: PASS
- 最大スコア差: 1.11e-16
- OOS契約テスト: ENTRY率>=70% / 公式勝率>=60% PASS
- 既存functional contract: 164/164 PASS

## 結論

v0.7.30は、DRAW=LOSEの公式集計に修正した上で、Jan-Junから固定した追加SKIPゲートによりJul-Aug18 OOS合算で **ENTRY率70.48% / 公式勝率60.23%** を確認した研究候補。
9月の正確な再Replayができないため、現時点では将来勝率60%を保証する本番認定版ではない。

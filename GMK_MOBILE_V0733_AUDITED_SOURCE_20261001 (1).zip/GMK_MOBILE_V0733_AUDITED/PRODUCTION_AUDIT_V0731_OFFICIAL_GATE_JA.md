# GMK MOBILE RULE v0.7.31 本番実装・全監査レポート

更新日: 2026-10-01

## 結論

スマートフォン版3分ローカルルールへ `OfficialWinGate` を本番実装した。PC版には変更を加えていない。
本番版は `versionCode 101` / `versionName 0.7.31-production-official-win-gate`。
研究用 `ResearchRuleIdPolicy.kt` はproductionソースから削除し、9月結果由来の研究補正をライブ判定へ戻していない。

## 本番ゲート仕様

- 既存FinalRankPolicy・方向・反転・TOP1選択は維持。
- TOP1が既にS/A/B/Cのときだけ固定ゲートを評価。
- ゲート不合格はE/SKIPへ降格するだけ。Eの昇格、方向反転、候補2〜6への作用は禁止。
- 実行時AI/LLM/通信/オンライン学習なし。
- Jan-Jun 2026平日09:00-23:00で固定した30本の浅い決定木。
- 閾値0.530。
- 未知通貨、未知regime、未知方向、未知grade、非有限特徴量、09:00-23:00外はfail-closedでSKIP。

## 勝率・ENTRY率の検証

DRAWはLOSEとして集計。土日は現行6/6 strict gateで3分ENTRYしないため、平日09:00-23:00を母集団とした。

- v0.7.9平日ベースライン Jan-Aug18: ENTRY率 88.16%、公式勝率 57.41%。
- v0.7.31ゲート OOS Jul-Aug18合算: 対象5,880枠、ENTRY 4,144、ENTRY率 **70.48%**。
- 結果取得済みENTRY 4,136、WIN 2,491、LOSE 1,423、DRAW 222（LOSE扱い）、公式勝率 **60.23%**。
- Kotlinゲートで採点済み5,871行を再Replay: ENTRY 4,136、ENTRY率 70.45%、公式勝率 60.23%、Python基準との最大スコア差 1.11e-16。

重要: 7月単月は条件を満たすが、8/1-8/18単月はENTRY率/勝率とも条件を下回る。9月CSVにはゲート再計算に必要な生特徴がないため、9月60%は認定していない。これは将来勝率の保証ではない。

## 今回の監査で修正した項目

1. 研究versionName/研究ZIPのためproductionビルドで拒否される状態を、本番version/production配布経路へ変更。
2. OfficialWinGateの異常特徴量fallbackがENTRYを許し得る経路をfail-closed化。
3. 3分LocalRuleEngineへ独立OHLC有限値・価格関係・時刻・重複検証を追加。
4. 1分OneMinuteLocalEngineにも同等の入力防御を追加。
5. productionパッケージからResearchRuleIdPolicy Kotlinを削除し、将来の誤混入面を縮小。
6. 旧未使用pair-switchコードの不要`!!`を除去し、domain全体を警告エラー扱いでコンパイル可能にした。
7. Repository/ViewModel/HistoryStoreの`catch(Throwable)`を`catch(Exception)`へ変更し、OOM等の致命的Errorを握り潰さないようにした。
8. 残っていた不要な非null強制を除去。

## 全監査結果

- functional_contract_test.py: **167/167 PASS**
- production_full_audit.py: **38/38 PASS**
- domain Kotlin全ファイル `-Werror`: PASS
- OfficialWinGate OOS Kotlin replay: PASS
- OfficialWinGate deterministic fuzz 200,000件: PASS
- 3分LocalRuleEngine stress 1,000 scan: PASS
- 1分OneMinuteLocalEngine stress 1,000 scan: PASS
- ProductionRuleAuditTest: PASS
- CutInPolicyTest: PASS
- Python tools compile: PASS
- AndroidManifest / resource XML parse: PASS
- GitHub Actions YAML parse: PASS
- workflow内Bash 14ブロック構文: PASS
- drawable WebP 66ファイル整合: PASS
- Kotlinから参照するapp drawable欠落: 0
- cleartext通信禁止 / allowBackup=false: PASS
- 明白な埋込API key/token/secret: 0

## 未実施・認定しない項目

この実行環境にはAndroid SDK/Gradle一式がないため、実APKの `assembleDebug`、署名APK、Android実機UI、Yahoo/bitbank実通信はここでは実行していない。GitHub ActionsにはJava17、Android35、Gradle8.9、Kotlin compile、APK assemble、APK metadata検査、署名、固定4ファイル配布ZIP検査が含まれる。

## 再発防止

- production版versionNameに`research`が入ればworkflowがfail。
- productionソース内のResearchRuleIdPolicy Kotlinを監査でfail。
- OfficialWinGateは不正入力をfail-closed。
- 3分/1分エンジンがRepositoryとは独立してOHLCを再検証。
- OOS契約（ENTRY>=70%、DRAW=LOSE公式勝率>=60%）をKotlin replayで固定。
- 既存の6/6、鮮度、結果追跡、DRAW=LOSE、AUTO境界、研究/本番分離テストを継続。

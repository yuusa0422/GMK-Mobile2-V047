#!/usr/bin/env bash
set -euo pipefail
project="$(cd "$(dirname "$0")/.." && pwd)"
test_jar="$(mktemp /tmp/gmk-horizon-tests-XXXXXX.jar)"
trap 'rm -f "$test_jar"' EXIT
kotlinc -jvm-target 17 -include-runtime \
  "$project"/app/src/main/java/jp/gmk/mobile/domain/*.kt \
  "$project"/app/src/main/java/jp/gmk/mobile/domain/horizon/*.kt \
  "$project"/app/src/main/java/jp/gmk/mobile/data/HorizonMarketCache.kt \
  "$project"/tools/Horizon*Test.kt -d "$test_jar"
java -Xmx1400m -cp "$test_jar" HorizonParityTestKt "$project/app/src/main/assets/horizon_policy" "$project/tools/fixtures"
java -Xmx1000m -cp "$test_jar" HorizonIntegrationTestKt "$project/app/src/main/assets/horizon_policy"
java -cp "$test_jar" HorizonDeepAuditTestKt
python3 "$project/tools/horizon_release_audit.py"

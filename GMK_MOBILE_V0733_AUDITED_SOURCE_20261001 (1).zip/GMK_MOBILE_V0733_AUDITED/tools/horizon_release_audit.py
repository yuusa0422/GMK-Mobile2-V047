"""Release gates for source integration. This is not an APK/device test or an OOS claim."""
from pathlib import Path
import hashlib,json,re,struct
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/jp/gmk/mobile'
assets=root/'app/src/main/assets/horizon_policy'
checks=[]
def check(name,okay):
 checks.append({'check':name,'pass':bool(okay)})
def text(p):return p.read_text(encoding='utf-8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads(text(assets/'manifest.json'));catalog=text(src/'domain/horizon/HorizonModelCatalog.kt')
check('four_local_models',len(m['models'])==4)
for model in m['models']:
 p=assets/model['asset'];b=p.read_bytes();nf,nc,nt=struct.unpack('>iii',b[8:20])
 check('model_'+model['asset'],sha(p)==model['sha256'] and model['sha256'] in catalog and b[:8]==b'GMKTREE1' and nf==model['features'] and nc==model['classes'] and nt==model['trees'])
for name,value in json.loads(text(root/'tools/horizon_preserved_sha256.json')).items():check('unchanged_'+Path(name).name,sha(root/name)==value)
vm=text(src/'ui/GmkViewModel.kt');runtime=text(src/'data/HorizonRuntime.kt');adapter=text(src/'domain/horizon/HorizonScanAdapter.kt');history=text(src/'data/HistoryStore.kt');main=text(src/'MainActivity.kt');policy=text(src/'domain/horizon/HorizonPolicy.kt')
check('adapter_connected','horizonRuntime.apply(native, eligible)' in vm and 'horizonRuntime.observe(incoming)' in vm and 'horizonRuntime.stop()' in vm)
check('native_entry_before_data_guards',adapter.index('if(top.decision=="ENTRY")')<adapter.index('if(prepared==null'))
check('manual_native_only','if(native.source!="AUTO")return native' in runtime)
check('causal_quote_cutoff','cache.quoteSnapshot((boundary-10)*1000)' in runtime)
check('off_scan_background','adapter?.prepare(cache.snapshot(),boundary)' in runtime and 'remaining in 15..25' in runtime and 'withTimeout(3500)' in runtime)
check('past_coverage_p72','(1.0-0.72)' in policy and policy.index('val enter=')<policy.index('scores.addLast(if('))
check('native_skip_supplement_rank','grade="R",probability=null,decision="ENTRY"' in adapter and '"R"' in history)
check('mixed_expiry_identity','HistoryIdentity.alreadyRecorded' in history and 'row.entryTimeJst==result.entryTimeJst' in text(src/'domain/HistoryIdentity.kt'))
check('actual_expiry_display','expiryMinutes(h.entryTimeJst,h.judgeTimeJst' in main and 'ModeChip("3/10/15分", true)' in main)
check('no_inference_in_compose','PortableTreeModel' not in main and 'HorizonFlipPolicy' not in main)
check('research_not_declared_final_oos',m['validation_status']=='REUSED_HISTORY_NOT_FINAL_OOS' and not m['live_win_rate_guaranteed'])
check('version_102','versionCode = 103' in text(root/'app/build.gradle.kts'))
failed=[x['check'] for x in checks if not x['pass']]
print(json.dumps({'status':'FAIL' if failed else 'PASS','checks':len(checks),'failed':failed,'android_apk_build_test':False,'live_win_rate_test':False},ensure_ascii=False))
if failed:raise SystemExit(1)

from pathlib import Path
import json,struct,hashlib
ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'work/mobile_r15_production/app/src/main/assets/horizon_policy'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def export(source,target,kind):
    record=json.loads(source.read_text());m=record.get('tree',record);names=record.get('features',m.get('feature_names'));trees=m['tree_info'];classes=m['num_class'] if kind=='CLASSIFIER' else 1;out=bytearray(b'GMKTREE1');out.extend(struct.pack('>iii',len(names),classes,len(trees)))
    for name in names:
        b=name.encode();out.extend(struct.pack('>i',len(b)));out.extend(b)
    for tree in trees:
        nodes=[]
        def walk(n):
            i=len(nodes);nodes.append(None)
            if 'leaf_value' in n:nodes[i]=(-1,0.,False,False,-1,-1,n['leaf_value'])
            else:
                assert n['decision_type']=='<=';left=walk(n['left_child']);right=walk(n['right_child']);nodes[i]=(n['split_feature'],float(n['threshold']),n['default_left'],n['missing_type']=='Zero',left,right,0.)
            return i
        walk(tree['tree_structure']);out.extend(struct.pack('>i',len(nodes)))
        for row in nodes:out.extend(struct.pack('>id??iid',*row))
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(out)
    return dict(source=str(source.relative_to(ROOT)),source_sha256=sha(source),asset=target.name,sha256=sha(target),features=len(names),classes=classes,trees=len(trees),bytes=len(out))

def main():
    DEST.mkdir(parents=True,exist_ok=True);rows=[]
    for h in (3,10,15):rows.append(export(ROOT/f'research_mobile_joint_horizon_r2/evidence/2026-08/models/RULE_STATE365_{h}m.json',DEST/f'base_{h}m.bin','CLASSIFIER'))
    source=ROOT/'research_mobile_horizon_flip_r15/evidence/models/2026-08/PATH__LGBM__PROTECT15.json';rows.append(export(source,DEST/'r15_path_protect15.bin','REGRESSOR'))
    record=json.loads(source.read_text());manifest=dict(version='R15_PATH_LGBM_PROTECT15_T025_20261001',user_authorized_at='2026-10-01T19:34:49+09:00',activation_authorization='本番適用しろ',rule='KEEP_NATIVE_3M_THEN_R2_RULE365_RAW_KEEP_BASE_P72_THEN_R15_15_TO3_OPPOSITE',model_available_from='2026-08-01T00:00:00+09:00',threshold=.025,cost=1.5,models=rows,validation_status='REUSED_HISTORY_NOT_FINAL_OOS',entry_rate_research=.7197039072039072,official_win_rate_research=.5852260666525154,model_clock=record['clocks'],live_win_rate_guaranteed=False)
    (DEST/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    kt=ROOT/'work/mobile_r15_production/app/src/main/java/jp/gmk/mobile/domain/horizon/HorizonModelCatalog.kt';kt.parent.mkdir(parents=True,exist_ok=True)
    kt.write_text('package jp.gmk.mobile.domain.horizon\n\nobject HorizonModelCatalog {\n    const val VERSION = "'+manifest['version']+'"\n    const val AVAILABLE_FROM_EPOCH = 1785510000L\n    val hashes: Map<String, String> = linkedMapOf(\n'+',\n'.join('        "'+r['asset']+'" to "'+r['sha256']+'"' for r in rows)+'\n    )\n}\n')
    (ROOT/'production_mobile_r15/evidence/exported_models.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(assets=len(rows),bytes=sum(r['bytes'] for r in rows))))

if __name__=='__main__':main()

from pathlib import Path
import sys,json,struct,hashlib,sqlite3
import numpy as np
ROOT=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(ROOT/'research_mobile_horizon_flip_r15/tools'),str(ROOT/'production_mobile_r15/tools')]
from common_r15 import inputs
from horizon_flip_core import feature_matrix,eligible,predict_exported
from path_features import features
from export_models import export
OUT=ROOT/'production_mobile_r15/fixtures';OUT.mkdir(exist_ok=True)
def pack(f,fmt,*x):f.write(struct.pack('>'+fmt,*x))
def string(f,s):
 b=s.encode();pack(f,'i',len(b));f.write(b)
def prediction(model,x):
 nc=model['num_class'];a=np.zeros((len(x),nc))
 for k,t in enumerate(model['tree_info']):a[:,k%nc]+=predict_exported({'tree_info':[t]},'LGBM',x)
 if nc>1:
  a=np.exp(a-a.max(1,keepdims=True));a/=a.sum(1,keepdims=True)
 return a
def main():
 d=inputs();ev=np.flatnonzero((d['months']>='2026-05')&(d['months']<='2026-08'));total=0
 with (OUT/'correction.bin').open('wb') as f:
  pack(f,'i',len(ev))
  for month in ('2026-05','2026-06','2026-07','2026-08'):
   ix=ev[d['months'][ev]==month];x,names=feature_matrix(d,ix,'PATH');source=ROOT/f'research_mobile_horizon_flip_r15/evidence/models/{month}/PATH__LGBM__PROTECT15.json'
   export(source,OUT/f'r15_{month}.bin','REGRESSOR');m=json.loads(source.read_text());p=predict_exported(m['tree'],'LGBM',x);ok=eligible(d,ix)
   for row,k in enumerate(ix):
    a=int(d['STRICT_AI__action'][k]);hi=bool(d['STRICT_AI__high'][k]);en=bool(d['STRICT_AI__entry'][k]);s=a//3;native=bool(d['native_entry'][k] and a==d['native_action'][k] and hi==d['native_high'][k])
    string(f,month);pack(f,'qi?i????d?',int(d['boundaries'][k]),s,hi,(3,10,15)[a%3],en,native,bool(d['safe_strict'][k,s]),bool(d['path_valid'][k,s]),float(p[row]),bool(ok[row] and p[row]>=.025));f.write(x[row].astype('>f4').tobytes())
   total+=len(ix)
 print('correction fixtures',total,flush=True)
 # Parent prediction parity: deterministic 512 samples per horizon from the full August fold.
 sys.path.insert(0,str(ROOT/'research_mobile_joint_horizon_r2/tools'))
 from core import feature_view
 with np.load(ROOT/'research_mobile_joint_horizon_r2/inputs/joint_inputs.npz',allow_pickle=False) as z:j={k:z[k] for k in z.files}
 ix=np.flatnonzero(j['months']=='2026-08')[::4]
 for hidx,h in enumerate((3,10,15)):
  X,names,_=feature_view(j,hidx,'RULE_STATE');x=X[ix].reshape(-1,len(names));model=json.loads((ROOT/f'research_mobile_joint_horizon_r2/evidence/2026-08/models/RULE_STATE365_{h}m.json').read_text());p=prediction(model,x)
  with (OUT/f'parent_{h}.bin').open('wb') as f:
   pack(f,'ii',len(x),len(names))
   for xx,pp in zip(x,p):f.write(xx.astype('>f4').tobytes());f.write(pp.astype('>f8').tobytes())
  print('parent',h,len(x),flush=True)
 # Raw OHLC -> full Kotlin feature parity, independent of the exported-vector tests.
 candidates=[int(ev[np.flatnonzero((d['months'][ev]==month)&d['path_valid'][ev,:6].all(1)&d['safe_strict'][ev,:6].all(1))[100]]) for month in ('2026-05','2026-06','2026-07','2026-08')]
 codes=('JPY=X','EURJPY=X','GBPJPY=X','AUDJPY=X','NZDJPY=X','BTC-JPY','AUDUSD=X','BTC-USD','CAD=X','CADJPY=X','CHF=X','CHFJPY=X','ETH-USD','EURAUD=X','EURGBP=X','EURUSD=X','GBPAUD=X','GBPUSD=X','NZDUSD=X')
 prices=sqlite3.connect(f'file:{ROOT}/data_source/history/2026年/replay_history_20260101_20260818.db?mode=ro',uri=True)
 quotes=sqlite3.connect(f'file:{ROOT}/data_source/history/2026年/m10_history_20260101_20260818.sqlite3?mode=ro',uri=True)
 views=[feature_view(j,h,'RULE_STATE')[0] for h in range(3)]
 with (OUT/'raw_features.bin').open('wb') as f:
  pack(f,'i',len(candidates))
  for k in candidates:
   b=int(d['boundaries'][k]);pack(f,'q',b)
   for code in codes:
    rows=prices.execute('SELECT time_utc,open,high,low,close,volume FROM candles_1m WHERE instrument=? AND time_utc BETWEEN ? AND ? ORDER BY time_utc',(code,b-9*86400,b-70)).fetchall();pack(f,'i',len(rows))
    for row in rows:pack(f,'qddddd',int(row[0])*1000,*[float(v or 0.) for v in row[1:]])
   for code in codes[:6]:
    row=quotes.execute('SELECT source_time_utc,current_price,bid,ask,quote_valid,partial_m1_time_utc,partial_m1_open,partial_m1_high,partial_m1_low,partial_m1_tick_count,partial_m1_progress FROM m10_quotes WHERE instrument=? AND boundary_utc=?',(code,b)).fetchone()
    pack(f,'?',row is not None)
    if row:
     vals=[np.nan if v is None else float(v) for v in row];pack(f,'qqddd?qdddid',(b-10)*1000,int(vals[0]*1000),vals[1],vals[2],vals[3],vals[4]==1,int(vals[5]*1000) if np.isfinite(vals[5]) else 0,vals[6],vals[7],vals[8],int(vals[9]) if np.isfinite(vals[9]) else 0,vals[10])
   pos=int(np.searchsorted(j['boundaries'],b));xx,fn,sc,valid=features(d,np.full(6,k),np.arange(6),'PATH');xx=np.concatenate([xx,np.eye(6,dtype=np.float32)],1)
   for s in range(6):
    for h in range(3):f.write(views[h][pos,s].astype('>f4').tobytes())
    f.write(xx[s].astype('>f4').tobytes())
   print('raw frame',b,flush=True)
 (OUT/'manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.bin')},indent=2)+'\n')
if __name__=='__main__':main()

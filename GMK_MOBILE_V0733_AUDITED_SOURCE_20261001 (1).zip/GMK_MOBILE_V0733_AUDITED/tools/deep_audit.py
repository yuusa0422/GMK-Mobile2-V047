"""Independent serialized-model and release audit; does NOT execute Kotlin/Android."""
from pathlib import Path
import csv, hashlib, json, math, re, struct, subprocess, time, xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/jp/gmk/mobile'
assets=root/'app/src/main/assets/horizon_policy'
fixtures=root/'tools/fixtures'
results=[]
def check(name, condition):
    assert condition, name
    results.append({'check':name,'status':'PASS'})
def read(path): return path.read_text(encoding='utf-8')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

class Reader:
    def __init__(self,path): self.data=path.read_bytes();self.at=0
    def take(self,n):
        b=self.data[self.at:self.at+n];assert len(b)==n;self.at+=n;return b
    def get(self,fmt): return struct.unpack('>'+fmt,self.take(struct.calcsize('>'+fmt)))
    def integer(self): return self.get('i')[0]
    def string(self): return self.take(self.integer()).decode()
    def eof(self): assert self.at==len(self.data)

class TreeModel:
    def __init__(self,path):
        r=Reader(path);assert r.take(8)==b'GMKTREE1'
        nf,nc,nt=r.get('iii');assert 0<nf<=512 and 0<nc<=3 and nt%nc==0
        self.names=[r.string() for _ in range(nf)];assert len(set(self.names))==nf
        self.nc=nc;self.trees=[]
        for _ in range(nt):
            n=r.integer();assert 0<n<=2048
            nodes=[r.get('id??iid') for _ in range(n)]
            for i,(f,t,d,z,l,h,v) in enumerate(nodes):
                assert math.isfinite(t) and math.isfinite(v)
                assert (f<nf and i<l<n and i<h<n) if f>=0 else (l==h==-1)
            self.trees.append(nodes)
        r.eof()
    def predict(self,x):
        assert len(x)==len(self.names)
        out=[0.0]*self.nc
        for i,tree in enumerate(self.trees):
            at=0
            while tree[at][0]>=0:
                f,t,d,z,l,h,v=tree[at];value=x[f]
                left=d if math.isnan(value) or (z and value==0) else value<=t
                at=l if left else h
            out[i%self.nc]+=tree[at][-1]
        if self.nc>1:
            maximum=max(out);out=[math.exp(v-maximum) for v in out];total=sum(out);out=[v/total for v in out]
        return out

started=time.monotonic()
manifest=json.loads(read(assets/'manifest.json'))
for m in manifest['models']:
    check('model_sha_'+m['asset'],sha(assets/m['asset'])==m['sha256'])
clock=manifest['model_clock']
check('declared_model_chronology',clock['fit_latest_possible_expiry']<clock['validation_first_scan']<clock['validation_last_possible_expiry']<clock['test_first_scan'])
check('honest_research_status',manifest['validation_status']=='REUSED_HISTORY_NOT_FINAL_OOS' and not manifest['live_win_rate_guaranteed'])
models={h:TreeModel(assets/f'base_{h}m.bin') for h in (3,10,15)}
parents=0;parent_error=0.0
for h in models:
    r=Reader(fixtures/f'parent_{h}.bin');n,nf=r.get('ii')
    for _ in range(n):
        x=r.get(f'{nf}f');expected=r.get('3d');actual=models[h].predict(x)
        parent_error=max(parent_error,max(abs(a-b) for a,b in zip(actual,expected)));parents+=1
    r.eof()
check('parent_9072_predictions',parents==9072 and parent_error<1e-12)
r=Reader(fixtures/'correction.bin');count=r.integer();folds={};changed=0;correction_error=0.0
for _ in range(count):
    month=r.string();boundary,symbol,high,horizon,entry,native,safe,path,expected,changes=r.get('qi?i????d?')
    x=r.get('90f')
    if month not in folds: folds[month]=TreeModel(fixtures/f'r15_{month}.bin')
    value=folds[month].predict(x)[0];correction_error=max(correction_error,abs(value-expected))
    actual=entry and horizon==15 and not native and safe and path and all(math.isfinite(v) for v in x) and value>=.025
    assert actual==changes
    changed+=actual
r.eof();check('correction_13104_predictions_and_169_changes',count==13104 and changed==169 and correction_error<1e-12)

rows=list(csv.DictReader((root/'release_evidence/GMK_MOBILE_R15_REFERENCE_REPLAY.csv').open()))
entries=[r for r in rows if r['decision']=='ENTRY']
counts={k:sum(r['outcome']==k for r in entries) for k in ('WIN','LOSE','DRAW','UNKNOWN')}
run=maximum=0
for r in entries:
    run=run+1 if r['outcome'] in ('LOSE','DRAW') else 0;maximum=max(maximum,run)
check('replay_counts',len(rows)==13104 and len(entries)==9431 and counts==dict(WIN=5514,LOSE=3695,DRAW=213,UNKNOWN=9) and maximum==10)
check('replay_declared_training_and_validation_before_scan',all(float(r['fit_last_possible_expiry'])<float(r['validation_last_possible_expiry'])<float(r['boundary'])-10 for r in rows))
check('replay_closed_candle_and_expiry_times',all(float(r['feature_last_m1'])<=float(r['boundary'])-120 and float(r['expiry'])==float(r['boundary'])+float(r['horizon'])*60 for r in rows))
for p in (root/'app/src/main').rglob('*.xml'): ET.parse(p)
check('all_android_xml_well_formed',True)
vm=read(src/'ui/GmkViewModel.kt');runtime=read(src/'data/HorizonRuntime.kt');history=read(src/'data/HistoryStore.kt')
capture=vm[vm.index('private suspend fun fetchOutcomeRateAtTarget('):vm.index('private fun refreshHistory(')]
check('timeout_retry_before_parent_cancel',len(re.findall(r'catch \(_: TimeoutCancellationException\)[\s\S]*?catch \(ce: CancellationException\)',capture))==2)
check('capture_deadline_checked_after_io',all(s in capture for s in ['captured.isBefore(deadline)','isBefore(hardDeadline)','coerceIn(1L, 6_000L)','q.sourceEpochMs ?:']))
check('history_no_destructive_retry', 'HistoryIdentity.alreadyRecorded(current, result)' in history and 'current.removeAll' not in history)
check('history_atomic_mutations',all(re.search(r'@Synchronized\s+fun '+name+r'\(',history) for name in ['add','load','updateEntryRate','settle','markEntryMissed','markJudgeMissed']))
check('background_disabled_with_auto', '!enabled() || !HorizonFeatureService.scheduled(boundary)' in runtime and 'horizonRuntime.start(viewModelScope, { prefs.autoScan })' in vm)
check('bounded_quote_fetch_before_scan', 'withTimeout(quoteBudget)' in runtime and 'HorizonTimingPolicy.quoteBudgetMs' in runtime and 'second in 6..35' in runtime)
check('quote_snapshot_uses_receipt_order','maxByOrNull { it.receivedMs }' in read(src/'data/HorizonMarketCache.kt'))
check('invalid_book_cannot_be_live','price != null && bookValid &&' in read(src/'data/MarketRepository.kt'))
for path in (root/'tools').glob('Horizon*Test.kt'):
    check('ci_test_matches_cli_'+path.name,path.read_bytes()==(root/'app/src/test/java'/path.name).read_bytes())
for name in ['RuleEngineStressTest','OneMinuteEngineStressTest','ProductionRuleAuditTest','CutInPolicyTest','OfficialWinGateFuzzTest','OfficialWinGateReplayTest']:
    check('legacy_ci_test_matches_cli_'+name,(root/'tools'/f'{name}.kt').read_bytes()==(root/'app/src/test/java'/f'{name}.kt').read_bytes())
check('parity_does_not_overwrite_expected','"native_kotlin.txt").writeText' not in read(root/'tools/HorizonParityTest.kt'))
workflow=read(root/'.github/workflows/build.yml')
check('ci_executes_tests_and_lint', ':app:testDebugUnitTest' in workflow and ':app:lintDebug' in workflow)
check('workflow_stays_short',len(workflow.splitlines())<=115)
for name in ['functional_contract_test.py','production_full_audit.py','horizon_release_audit.py']:
    p=subprocess.run(['python3',str(root/'tools'/name)],capture_output=True,text=True)
    check(name,p.returncode==0)
    results[-1]['output']=p.stdout.strip()
print(json.dumps({'status':'PASS','checks':len(results),'results':results,'seconds':time.monotonic()-started,
    'independent_python_model_audit':{'parent_cases':parents,'parent_max_error':parent_error,'correction_cases':count,'correction_max_error':correction_error,'changed':changed},
    'reference_replay':{'frames':len(rows),'entries':len(entries),**counts,'max_loss':maximum,'entry_rate':len(entries)/len(rows),'official_win_rate':counts['WIN']/sum(counts[k] for k in ('WIN','LOSE','DRAW'))},
    'kotlin_execution_this_audit':False,'android_build_this_audit':False,'device_test':False},ensure_ascii=False,indent=2))

import jp.gmk.mobile.domain.*
import java.io.*
import java.time.*
fun main(args: Array<String>) {
    val symbols=listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY","AUDUSD","BTCUSD","USDCAD","CADJPY","USDCHF","CHFJPY","ETHUSD","EURAUD","EURGBP","EURUSD","GBPAUD","GBPUSD","NZDUSD")
    DataInputStream(BufferedInputStream(FileInputStream(args[0]))).use { input->repeat(input.readInt()) {
        val b=input.readLong();val prices=symbols.associateWith { List(input.readInt()){Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble())} }
        repeat(6){if(input.readBoolean())input.skipNBytes(85)}
        input.skipNBytes(6L*(3*152+90)*4)
        val e=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
        val context=prices.filterKeys { it in symbols.take(6) }.mapValues { it.value.takeLast(120) }
        val r=LocalRuleEngine().scan(context,"AUTO",e.minusSeconds(10),e)
        for(c in r.candidates)println("$b ${c.rank} ${c.instrument} ${c.direction} ${c.grade} ${c.probability} ${c.score} ${c.decision}")
    };check(input.read()==-1) }
}

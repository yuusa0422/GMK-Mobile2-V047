"""Local workflow regression checks. SDK/Gradle and GitHub Actions are NOT run."""
from pathlib import Path
import argparse, base64, json, os, shutil, subprocess, tempfile, warnings, zipfile
import yaml

parser = argparse.ArgumentParser()
parser.add_argument("--zipfile", type=Path)
parser.add_argument("--test-data", type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
workflow = yaml.load((root / ".github/workflows/build.yml").read_text(), Loader=yaml.BaseLoader)
steps = workflow["jobs"]["build"]["steps"]
prepare = next(s["run"] for s in steps if s.get("name") == "Prepare production source")
sign = next(s["run"] for s in steps if s.get("name") == "Sign and verify APK")
archive_name = "GMK_MOBILE_V0733_AUDITED_SOURCE_20261001.zip"
metadata = (root / "app/build.gradle.kts").read_text()
records = []

def check(name, okay):
    if not okay:
        raise AssertionError(name)
    records.append({"check": name, "status": "PASS"})

check("workflow_events", workflow["on"] == ["workflow_dispatch", "push"])
check("minimal_permissions", workflow["permissions"] == {"contents": "read"})
check("no_ignored_build_errors", "continue-on-error" not in str(workflow))
for step in steps:
    if "run" in step:
        run = subprocess.run(["bash", "-n"], input=step["run"], text=True, capture_output=True)
        check("shell_syntax_" + step["name"], run.returncode == 0)
check("fixed_toolchain", all(any(s.get("with", {}).get(k) == v for s in steps) for k, v in [
    ("java-version", "17"), ("gradle-version", "8.9"),
    ("packages", "platform-tools platforms;android-35 build-tools;35.0.0")]))

def source_case(name, entries=None, expected=True, unpacked=False, duplicate=False, raw=None, external=None, companion_mode="ok"):
    with tempfile.TemporaryDirectory(prefix="gmk-workflow-test-") as td:
        base = Path(td)
        repo = base / "repo"; repo.mkdir()
        tmp = base / "tmp"; tmp.mkdir()
        envfile = base / "github-env"
        if unpacked:
            p = repo / "source with spaces"; (p / "app").mkdir(parents=True)
            (p / "settings.gradle.kts").write_text("")
            (p / "app/build.gradle.kts").write_text(metadata)
        elif external:
            shutil.copyfile(external, repo / archive_name)
        elif raw is not None:
            (repo / archive_name).write_bytes(raw)
        elif entries is not None:
            with zipfile.ZipFile(repo / archive_name, "w") as z:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", UserWarning)
                    for path, content in entries:
                        z.writestr(path, content)
            if duplicate:
                (repo / "duplicate").mkdir()
                shutil.copyfile(repo / archive_name, repo / "duplicate" / archive_name)
        if (repo / archive_name).exists() and companion_mode != "missing":
            companion = repo / "GMK_V0733_TEST_DATA.zip"
            if external:
                if args.test_data is None: raise ValueError("--test-data required with --zipfile")
                shutil.copyfile(args.test_data, companion)
            else:
                with zipfile.ZipFile(companion, "w") as z:
                    if companion_mode == "collision": z.writestr("source/app/build.gradle.kts", metadata)
                if companion_mode == "duplicate":
                    (repo / "extra").mkdir()
                    shutil.copyfile(companion, repo / "extra/GMK_V0733_TEST_DATA.zip")
        result = subprocess.run(["bash", "-c", prepare], cwd=repo, capture_output=True, text=True,
            env={**os.environ, "RUNNER_TEMP": str(tmp), "GITHUB_ENV": str(envfile)})
        check(name, (result.returncode == 0) == expected)
        if expected:
            project = Path(envfile.read_text().strip().removeprefix("GMK_PROJECT="))
            check(name + "_project_identity", (project / "app/build.gradle.kts").read_text() == metadata)
            if external:
                result = subprocess.run(["sha256sum", "--check", "--quiet", "PACKAGE_MANIFEST_SHA256.txt"], cwd=project, capture_output=True)
                check("actual_archive_all_member_hashes", result.returncode == 0)

valid = [("source/settings.gradle.kts", ""), ("source/app/build.gradle.kts", metadata)]
source_case("valid_source_zip", valid)
source_case("missing_test_data_rejected", valid, expected=False, companion_mode="missing")
source_case("duplicate_test_data_rejected", valid, expected=False, companion_mode="duplicate")
source_case("cross_archive_collision_rejected", valid, expected=False, companion_mode="collision")
source_case("unpacked_project_with_spaces", unpacked=True)
source_case("missing_project_rejected", expected=False)
source_case("duplicate_archives_rejected", valid, expected=False, duplicate=True)
source_case("corrupt_zip_rejected", raw=b"broken", expected=False)
for key, old, new in [("version", "versionCode = 103", "versionCode = 101"),
                     ("appid", "jp.gmk.mobile.rule", "jp.gmk.research")]:
    source_case("wrong_" + key + "_rejected", [valid[0], (valid[1][0], metadata.replace(old, new))], expected=False)
for path in ["../escape", "/escape", "C:/escape", "source/../../escape", "..\\escape"]:
    source_case("unsafe_" + repr(path), valid + [(path, "bad")], expected=False)
source_case("duplicate_normalized_targets_rejected", valid + [("source/./app/build.gradle.kts", metadata)], expected=False)
source_case("multiple_projects_rejected", valid + [("other/settings.gradle.kts", ""), ("other/app/build.gradle.kts", metadata)], expected=False)
for mode in [0o120777, 0o020600]:
    info = zipfile.ZipInfo("source/link"); info.create_system = 3; info.external_attr = mode << 16
    source_case("special_file_rejected_" + oct(mode), valid + [(info, "target")], expected=False)
if args.zipfile:
    source_case("actual_delivery_zip", external=args.zipfile.resolve())

# Exercise shell branches with a mock signer only; this does not validate Android signing.
for mode in ["ephemeral", "persistent", "partial", "invalid_base64", "signer_failure", "wrong_apk", "missing_apk"]:
    with tempfile.TemporaryDirectory(prefix="gmk-sign-test-") as td:
        base = Path(td); apk = base / "project/app/build/outputs/apk/debug/app-debug.apk"
        apk.parent.mkdir(parents=True)
        if mode != "missing_apk": apk.write_bytes(b"MOCK_APK_FOR_SHELL_TEST_ONLY")
        bt = base / "sdk/build-tools/35.0.0"; bt.mkdir(parents=True)
        signer = bt / "apksigner"
        signer.write_text("#!/usr/bin/env python3\nimport os, pathlib, shutil, sys\na=sys.argv[1:]\nif os.environ['MOCK_MODE']=='signer_failure': sys.exit(7)\nif a[0]=='sign': shutil.copyfile(a[-1],a[a.index('--out')+1])\nelse: sys.exit(0 if pathlib.Path(a[-1]).is_file() else 8)\n")
        signer.chmod(0o755)
        aapt = bt / "aapt"
        package = "wrong.application" if mode == "wrong_apk" else "jp.gmk.mobile.rule"
        aapt.write_text("#!/usr/bin/env python3\nprint(" + repr(f"package: name='{package}' versionCode='103' versionName='0.7.33-production-audited'") + ")\n")
        aapt.chmod(0o755)
        env = {**os.environ, "GMK_PROJECT": str(base / "project"), "ANDROID_HOME": str(base / "sdk"),
               "RUNNER_TEMP": td, "MOCK_MODE": mode, "KEYSTORE_B64": "", "STORE_PASSWORD": "", "KEY_ALIAS": "", "KEY_PASSWORD": ""}
        if mode in ["persistent", "invalid_base64"]:
            env.update(KEYSTORE_B64=base64.b64encode(b"test-only").decode(), STORE_PASSWORD="test", KEY_ALIAS="test", KEY_PASSWORD="test")
        if mode == "partial": env["KEY_ALIAS"] = "test"
        if mode == "invalid_base64": env["KEYSTORE_B64"] = "!invalid!"
        result = subprocess.run(["bash", "-c", sign], cwd=base, env=env, capture_output=True, text=True)
        check("mock_signing_branch_" + mode, (result.returncode == 0) == (mode in ["ephemeral", "persistent"]))
        if result.returncode == 0:
            files = {p.name for p in (base / "artifacts").iterdir()}
            check("artifact_contents_" + mode, files == {"GMK_MOBILE.apk", "SHA256.txt", "signing-mode.txt", "package.txt"})
            check("reported_mode_" + mode, (base / "artifacts/signing-mode.txt").read_text().strip() == ("persistent" if mode == "persistent" else "ephemeral-debug"))
print(json.dumps({"status": "PASS", "checks": len(records), "github_actions_executed": False,
    "sdk_gradle_apk_build_executed": False, "signing_test_scope": "SHELL_CONTROL_FLOW_WITH_MOCK_TOOLS", "results": records}, ensure_ascii=False, indent=2))

# GMK MOBILE RULE v0.7.31 PRODUCTION

- Smartphone production source. PC version is separate.
- versionCode: 101
- versionName: 0.7.31-production-official-win-gate
- 3-minute TOP1 OfficialWinGate enabled in production.
- Held-out Jul-Aug18 aggregate replay: ENTRY 70.48%, DRAW=LOSE official win rate 60.23%.
- ResearchRuleIdPolicy is not included in production Kotlin sources.
- See PRODUCTION_AUDIT_V0731_OFFICIAL_GATE_JA.md for limitations and audit evidence.

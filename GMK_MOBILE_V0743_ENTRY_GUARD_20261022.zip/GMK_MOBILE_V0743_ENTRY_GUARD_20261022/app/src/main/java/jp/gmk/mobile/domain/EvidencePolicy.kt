package jp.gmk.mobile.domain

import jp.gmk.mobile.domain.october.OctoberSimilarityScanAdapter
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.43 final 3-minute ENTRY decision. Runs after the native scan and every optional overlay.
 *
 * Research (Oct 2026, see README_V0743.txt):
 *  - Native rules on new data were ~50% before draws; draws (= LOSE) pushed them to 47%.
 *    Only weekday 09:00-14:59 FX with [EntryQualityGuard] held up (~52-53%).
 *    Weekday 15:00-22:59 native was ~45%; BTCJPY had no edge (weekend draws ~26-35%).
 *  - DIP rule: after a sharp 30-minute decline (normalised r30 <= -1.57, the 5% tail fitted on
 *    2024-2025) the next 3 minutes were HIGH 53.0% / 51.6% / 53.7% in 2024 / 2025 / 2026 and
 *    54.1% in Oct 2026 real data (weekday 09:00-16:59, four JPY pairs, one trade per slot).
 *
 * Decision order:
 *  1) native TOP1 ENTRY that passes [EntryQualityGuard], weekday 09:00-14:59, FX  -> keep (3 min)
 *  2) DIP rule, weekday 09:00-16:59, USD/EUR/GBP/AUD JPY, deepest dip              -> HIGH (3 min)
 *  3) everything else (evening, weekend, BTCJPY)                                    -> SKIP, observe only
 * Signals in (3) are still published and tracked as virtual results in history.
 */
object EvidencePolicy {
    const val VERSION = "V0743_EVIDENCE_POLICY"
    const val DIP_THRESHOLD = -1.57
    const val DIP_FEATURE_INDEX = 5   // OctoberTechnicalFeatures: logret_30m_over_rv60_sqrtk
    val DIP_SYMBOLS = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY")
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    fun nativeWindow(t: ZonedDateTime): Boolean {
        val j = t.withZoneSameInstant(JST)
        return TradingSession.isWeekday(j) && j.hour in 9..14
    }

    fun dipWindow(t: ZonedDateTime): Boolean {
        val j = t.withZoneSameInstant(JST)
        return TradingSession.isWeekday(j) && j.hour in 9..16
    }

    /** Deepest qualifying dip among the four validated JPY pairs, or null. */
    fun dipPick(candles: Map<String, List<Candle>>, boundaryEpochSec: Long): Pair<String, Double>? {
        var best: Pair<String, Double>? = null
        for (symbol in DIP_SYMBOLS) {
            val x = OctoberSimilarityScanAdapter.features(candles[symbol].orEmpty(), boundaryEpochSec) ?: continue
            val r30 = x[DIP_FEATURE_INDEX].toDouble()
            if (!r30.isFinite() || r30 > DIP_THRESHOLD) continue
            if (best == null || r30 < best.second) best = symbol to r30
        }
        return best
    }

    fun apply(native: ScanResult, result: ScanResult, candles: Map<String, List<Candle>>): ScanResult {
        val guarded = EntryQualityGuard.apply(native, result)
        val entry = runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return observeOnly(guarded)
        val nativeTop = native.top1 ?: return guarded
        if (nativeTop.decision == "ENTRY" && EntryQualityGuard.reason(nativeTop) == null &&
            nativeWindow(entry) && nativeTop.instrument in TradingSession.FX) {
            // Evidence-backed native ENTRY: publish the native 3-minute action itself, not an overlay reroute.
            return native.copy(
                candidates = native.candidates.map { c ->
                    if (c.rank == nativeTop.rank) c.copy(reasons = c.reasons + "$VERSION: native ENTRY (weekday 09-15 FX)") else c
                }
            )
        }
        if (dipWindow(entry)) {
            val pick = dipPick(candles, entry.toEpochSecond())
            if (pick != null) {
                val target = native.candidates.firstOrNull { it.instrument == pick.first }
                if (target != null) return promoteDip(native, nativeTop, target, pick.second, entry)
            }
        }
        return observeOnly(guarded)
    }

    private fun promoteDip(native: ScanResult, nativeTop: ScanCandidate, target: ScanCandidate,
                           r30: Double, entry: ZonedDateTime): ScanResult {
        val label = "押し目買い: 30分急落 r30=${"%.2f".format(r30)} → HIGH"
        val chosen = target.copy(
            rank = 1, direction = "HIGH", grade = "B", decision = "ENTRY", probability = null,
            reasons = listOf("判定: 3分", "$VERSION: DIP r30=${"%.2f".format(r30)} <= $DIP_THRESHOLD -> HIGH") + target.reasons,
            assessment = CandidateAssessmentFactory.correction(target, nativeTop, "HIGH", "B", "ENTRY", 3, label)
        )
        val others = native.candidates.filter { it.instrument != target.instrument }.mapIndexed { i, c -> c.copy(rank = i + 2) }
        return native.copy(judgeTimeJst = entry.plusMinutes(3).toString(), candidates = listOf(chosen) + others)
    }

    private fun observeOnly(result: ScanResult): ScanResult {
        val top = result.top1 ?: return result
        if (top.decision != "ENTRY") return result
        val note = "$VERSION: ${CandidateSkipReason.OBSERVE_ONLY.label} -> E/SKIP"
        val assessment = top.assessment?.let { a ->
            a.copy(operationalGrade = "E", decision = "SKIP", skipReason = CandidateSkipReason.OBSERVE_ONLY,
                chosenAction = a.chosenAction.copy(operationalGrade = "E", decision = "SKIP"))
        }
        val updated = top.copy(grade = "E", decision = "SKIP", reasons = top.reasons + note, assessment = assessment)
        return result.copy(candidates = result.candidates.map { if (it.rank == top.rank) updated else it })
    }
}

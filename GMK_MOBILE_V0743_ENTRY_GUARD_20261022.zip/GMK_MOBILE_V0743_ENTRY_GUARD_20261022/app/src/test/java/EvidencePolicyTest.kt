import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.43 final ENTRY decision: native only in its validated window, DIP rule, otherwise observe-only. */
class EvidencePolicyTest {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun at(d: Int, h: Int, m: Int = 0) = ZonedDateTime.of(2026, 10, d, h, m, 0, 0, jst)
    private fun cand(rank: Int, inst: String, grade: String, decision: String, dir: String = "LOW", reasons: List<String> = emptyList()) =
        ScanCandidate(rank, inst, inst, dir, grade, 0.6, decision, -0.2, "RANGE", 0.6, reasons)
    private val reverse = listOf("${EntryQualityGuard.REVERSE_TAG} historical losing-pattern inversion")
    private fun native(entry: ZonedDateTime, top: ScanCandidate, rest: List<ScanCandidate>) = ScanResult(
        scanId = "s", atJst = entry.minusSeconds(10).toOffsetDateTime().toString(), entryTimeJst = entry.toOffsetDateTime().toString(),
        judgeTimeJst = entry.plusMinutes(3).toOffsetDateTime().toString(), candidates = listOf(top) + rest, source = "AUTO")
    private fun six(entry: ZonedDateTime, top: ScanCandidate) = native(entry, top,
        TradingSession.ALL.filter { it != top.instrument }.mapIndexed { i, s -> cand(i + 2, s, "C", "ENTRY") })

    /** 61 one-minute bars ending at OPEN(B-120). drop=true makes the last 30 minutes fall steadily. */
    private fun bars(entry: ZonedDateTime, base: Double, drop: Boolean): List<Candle> {
        val b = entry.toEpochSecond(); val d = base * 0.0002
        val closes = DoubleArray(61); closes[0] = base
        for (i in 1..60) closes[i] = closes[i - 1] + if (drop && i > 30) -d else if (i % 2 == 0) d else -d
        return (0..60).map { i ->
            val o = if (i == 0) base else closes[i - 1]; val c = closes[i]
            Candle((b - 3720 + i * 60L) * 1000L, o, maxOf(o, c) + d * 0.1, minOf(o, c) - d * 0.1, c, 1.0)
        }
    }
    private fun market(entry: ZonedDateTime, dipSymbol: String?) =
        EvidencePolicy.DIP_SYMBOLS.associateWith { bars(entry, if (it == "USDJPY") 150.0 else 160.0, it == dipSymbol) }

    @Test fun nativeEntryIsKeptOnlyInWeekdayMorningWindow() {
        val e = at(21, 10)
        val n = six(e, cand(1, "USDJPY", "C", "ENTRY", reasons = reverse))
        val r = EvidencePolicy.apply(n, n, market(e, null))
        assertEquals("ENTRY", r.top1!!.decision); assertEquals("USDJPY", r.top1!!.instrument); assertEquals("LOW", r.top1!!.direction)
        assertEquals(n.judgeTimeJst, r.judgeTimeJst)
    }

    @Test fun eveningNativeEntryBecomesObserveOnly() {
        val e = at(21, 20)
        val n = six(e, cand(1, "GBPJPY", "B", "ENTRY", reasons = reverse))
        val r = EvidencePolicy.apply(n, n, market(e, "USDJPY"))
        assertEquals("SKIP", r.top1!!.decision); assertEquals("E", r.top1!!.grade)
        assertEquals("GBPJPY", r.top1!!.instrument)
    }

    @Test fun weekendBtcIsObserveOnly() {
        val e = at(24, 12)
        val n = native(e, cand(1, "BTCJPY", "B", "ENTRY", reasons = reverse), emptyList())
        val r = EvidencePolicy.apply(n, n, emptyMap())
        assertEquals("SKIP", r.top1!!.decision)
        assertEquals(1, r.candidates.size)
    }

    @Test fun dipRuleBuysTheDeepestThirtyMinuteDrop() {
        val e = at(21, 16)
        val n = six(e, cand(1, "BTCJPY", "E", "SKIP"))
        val m = market(e, "EURJPY")
        val pick = EvidencePolicy.dipPick(m, e.toEpochSecond())
        assertNotNull(pick); assertEquals("EURJPY", pick!!.first); assertTrue(pick.second <= EvidencePolicy.DIP_THRESHOLD)
        val r = EvidencePolicy.apply(n, n, m)
        val top = r.top1!!
        assertEquals("EURJPY", top.instrument); assertEquals("HIGH", top.direction)
        assertEquals("ENTRY", top.decision); assertEquals("B", top.grade); assertEquals(1, top.rank)
        assertEquals((1..6).toSet(), r.candidates.map { it.rank }.toSet())
        assertEquals(6, r.candidates.size)
        assertEquals(e.plusMinutes(3).toEpochSecond(), ZonedDateTime.parse(r.judgeTimeJst).toEpochSecond())
    }

    @Test fun noDipWithoutSixtyOneContiguousBars() {
        val e = at(21, 11)
        val m = market(e, "USDJPY").mapValues { (_, v) -> v.drop(20) }
        assertNull(EvidencePolicy.dipPick(m, e.toEpochSecond()))
        val n = six(e, cand(1, "USDJPY", "C", "ENTRY"))   // C non-reverse -> guard
        val r = EvidencePolicy.apply(n, n, m)
        assertEquals("SKIP", r.top1!!.decision)
        assertEquals(CandidateSkipReason.C_NON_REVERSE, r.top1!!.assessment?.skipReason ?: CandidateSkipReason.C_NON_REVERSE)
    }
}

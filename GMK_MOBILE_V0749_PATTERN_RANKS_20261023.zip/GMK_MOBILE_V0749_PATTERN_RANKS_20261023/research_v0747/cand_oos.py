"""Out-of-sample per-candidate probabilities (5-model average, trained on the other half), fresh and backup."""
import pandas as pd, numpy as np, pickle, time
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
out = {}
for fresh in (True, False):
    parts = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        t0 = time.time()
        A = P[P.half == tr]; B = P[P.half == te]
        XA = np.vstack([design(A, 1, fresh)[0], design(A, -1, fresh)[0]]); yA = np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int)
        models = [HistGradientBoostingClassifier(random_state=s, **CFG).fit(XA, yA) for s in range(5)]
        t = B[['b', 'inst', 'weekday', 'hour', 'move3', 'half', 'date', 'ts']].copy()
        t['pu'] = np.mean([m.predict_proba(design(B, 1, fresh)[0])[:, 1] for m in models], axis=0)
        t['pd'] = np.mean([m.predict_proba(design(B, -1, fresh)[0])[:, 1] for m in models], axis=0)
        # in-sample (training half) predictions for calibration studies
        s = A[['b', 'inst', 'weekday', 'hour', 'move3', 'half', 'date', 'ts']].copy()
        s['pu'] = np.mean([m.predict_proba(design(A, 1, fresh)[0])[:, 1] for m in models], axis=0)
        s['pd'] = np.mean([m.predict_proba(design(A, -1, fresh)[0])[:, 1] for m in models], axis=0)
        t['role'] = 'test'; s['role'] = 'train'; t['fold'] = te; s['fold'] = te
        parts += [t, s]; print(fresh, tr, '->', te, round(time.time() - t0), 's', flush=True)
    out[fresh] = pd.concat(parts)
pickle.dump(out, open('../work/cand_oos.pkl', 'wb'))

"""How win rate and losing streaks change with the share of slots entered (v0.7.46 five-model average, out-of-sample)."""
import pandas as pd, numpy as np, pickle, json
E = pickle.load(open('../work/sim_ensemble.pkl', 'rb'))[True].copy()
E['m'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
off = E.groupby(['weekday', 'half', 'hour']).p.median()
E['adj'] = E.p - [off[(w, 'H2' if h == 'H1' else 'H1', hr)] for w, h, hr in zip(E.weekday, E.half, E.hour)]
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
rng = np.random.default_rng(4)
rows = []
for wk in (True, False):
    x = E[E.weekday == wk].sort_values('b')
    for rate in ((0.02, 0.05, 0.10, 0.15, 0.25, 0.35, 0.50, 0.74) if wk else (0.05, 0.10, 0.20, 0.30, 0.47)):
        thr = x.groupby('half').adj.transform(lambda v: v.quantile(1 - rate))          # threshold from the same half (approximate)
        e = x[x.adj >= thr]
        dm = e.groupby('date').win.apply(lambda v: ms(v.values)); per_day = len(e) / x.date.nunique()
        r = dict(seg='平日' if wk else '土日', share=rate, per_day=round(per_day, 1), win=round(e.win.mean() * 100, 1), H1=round(e[e.half == 'H1'].win.mean() * 100, 1), H2=round(e[e.half == 'H2'].win.mean() * 100, 1),
                 oct25=round(e[e.m == '2025-10'].win.mean() * 100, 1), oct26=round(e[e.m == '2026-10'].win.mean() * 100, 1), months_ge55=int((e.groupby('m').win.mean() >= 0.55).sum()),
                 months_lt50=int((e.groupby('m').win.mean() < 0.50).sum()), maxs=ms(e.win.values), day_avg=round(dm.mean(), 1), day5=round((dm >= 5).mean() * 100, 0), day8=round((dm >= 8).mean() * 100, 0), n=len(e))
        rows.append(r); print(r)
json.dump(rows, open('../work/coverage_curve.json', 'w'), ensure_ascii=False, indent=1)

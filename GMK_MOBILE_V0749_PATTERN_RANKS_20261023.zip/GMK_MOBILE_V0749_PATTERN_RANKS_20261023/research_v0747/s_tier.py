"""Exact rolling rule with an extra S tier (top 10% of recent slots). Entry decisions unchanged."""
import pandas as pd, numpy as np, pickle, json
E = pickle.load(open('../work/sim_ensemble.pkl', 'rb'))[True].copy()
E['m'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
off = E.groupby(['weekday', 'half', 'hour']).p.median()
E['adj'] = E.p - [off[(w, 'H2' if h == 'H1' else 'H1', hr)] for w, h, hr in zip(E.weekday, E.half, E.hour)]
NBUF = {True: 288, False: 576}
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
out = {}
for wk in (True, False):
    x = E[E.weekday == wk].sort_values('b').copy(); buf = []; tier = []
    for a in x.adj.values:
        if len(buf) >= 96:
            arr = np.array(buf); q90, q75, q50 = np.quantile(arr, .9), np.quantile(arr, .75), np.quantile(arr, .5)
            tier.append('S' if a >= q90 else 'A' if a >= q75 else 'B' if a >= q50 else 'C')
        else: tier.append('-')
        buf.append(a); buf = buf[-NBUF[wk]:]
    x['tier'] = tier; x = x[x.enter & (x.tier != '-')]
    for g in ('S', 'A', 'B', 'C'):
        e = x[x.tier == g]
        if not len(e): continue
        dm = e.groupby('date').win.apply(lambda v: ms(v.values))
        r = dict(n=len(e), per_day=round(len(e) / x.date.nunique(), 1), win=round(e.win.mean() * 100, 1), H1=round(e[e.half == 'H1'].win.mean() * 100, 1), H2=round(e[e.half == 'H2'].win.mean() * 100, 1),
                 oct25=round(e[e.m == '2025-10'].win.mean() * 100, 1), oct26=round(e[e.m == '2026-10'].win.mean() * 100, 1), m_ge55=int((e.groupby('m').win.mean() >= .55).sum()), m_lt50=int((e.groupby('m').win.mean() < .5).sum()),
                 maxs=ms(e.win.values), day_avg=round(dm.mean(), 1), day5=round((dm >= 5).mean() * 100), day8=round((dm >= 8).mean() * 100))
        out[f'{"平日" if wk else "土日"}|{g}'] = r; print('平日' if wk else '土日', g, r)
    # S+A together
    e = x[x.tier.isin(['S', 'A'])]; dm = e.groupby('date').win.apply(lambda v: ms(v.values))
    print('  S+A:', round(e.win.mean() * 100, 1), round(len(e) / x.date.nunique(), 1), '/日 最大連敗', ms(e.win.values), '8+日', round((dm >= 8).mean() * 100))
json.dump(out, open('../work/s_tier.json', 'w'), ensure_ascii=False, indent=1)

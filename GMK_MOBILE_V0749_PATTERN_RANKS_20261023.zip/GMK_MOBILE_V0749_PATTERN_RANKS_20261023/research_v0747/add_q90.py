import pickle, numpy as np, pandas as pd
exec(open('evidence_model.py').read().split('def model():')[0])
M = pickle.load(open('../work/production_ensemble.pkl', 'rb'))
for fresh in (True, False):
    Xu = design(P, 1, fresh)[0]; Xd = design(P, -1, fresh)[0]
    pu = np.mean([m.predict_proba(Xu)[:, 1] for m in M['models'][fresh]], axis=0); pdn = np.mean([m.predict_proba(Xd)[:, 1] for m in M['models'][fresh]], axis=0)
    t = P[['b', 'weekday', 'hour']].copy(); t['p'] = np.maximum(pu, pdn)
    best = t.sort_values('p', ascending=False).groupby('b').head(1)
    for wk in (True, False):
        st = M['stats']['fresh' if fresh else 'fallback']['weekday' if wk else 'weekend']
        x = best[best.weekday == wk].copy(); off = dict(zip(range(9, 23), st['offset'])); adj = x.p - x.hour.map(off)
        st['q90'] = float(adj.quantile(0.90)); print('fresh' if fresh else 'fallback', wk, st['q90'], 'check q75', st['q75'], float(adj.quantile(.75)))
pickle.dump(M, open('../work/production_ensemble.pkl', 'wb'))

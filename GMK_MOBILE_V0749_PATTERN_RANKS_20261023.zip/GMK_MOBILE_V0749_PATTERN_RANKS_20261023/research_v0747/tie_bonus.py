"""Ranking variants that use the backup model's tie risk (bonus / penalty)."""
exec(open('blend_lab.py').read().split('if __name' + '__')[0])
for bonus in [0.01, 0.03, 0.1]:
    run(True, (lambda bo: (lambda tr, te: te.p + bo * (te.fp >= 0.5)))(bonus), f'bonus fp>=.5 {bonus}')
for k in [0.5, 1.0]:
    run(True, (lambda k: (lambda tr, te: te.p + k * np.minimum(te.fp - 0.5, 0)))(k), f'penalty below .5 k={k}')

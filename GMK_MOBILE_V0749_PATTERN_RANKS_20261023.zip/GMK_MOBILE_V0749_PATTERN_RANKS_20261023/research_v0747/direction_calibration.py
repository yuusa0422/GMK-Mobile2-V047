"""Calibration of the chosen slot by direction (is HIGH over-picked?)."""
import pickle, pandas as pd, numpy as np
exec(open('calib_lab.py').read().split("if __name" + "__")[0])
R, _ = run(True, None, 'baseline')
for wk in (True, False):
    x = R[(R.weekday == wk)]; x = x.assign(bin=pd.qcut(x.p, 10, labels=False))
    print('weekday' if wk else 'weekend'); print(x.groupby(['bin', 'dir']).agg(p=('p', 'mean'), win=('win', 'mean'), n=('win', 'size')).unstack().round(3))
    print(x[x.bin >= 8].groupby(['half', 'dir']).agg(p=('p', 'mean'), win=('win', 'mean'), n=('win', 'size')).round(3))
D = C[True]; w = D[D.weekday]
print(w.groupby(['role', 'fold', 'inst']).apply(lambda d: pd.Series(dict(up=(d.move3 == 1).mean(), dn=(d.move3 == -1).mean(), tie=(d.move3 == 0).mean(), pu=d.pu.mean(), pd=d.pd.mean()))).round(4))

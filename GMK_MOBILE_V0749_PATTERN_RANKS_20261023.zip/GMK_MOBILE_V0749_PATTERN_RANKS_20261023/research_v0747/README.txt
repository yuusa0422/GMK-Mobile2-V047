v0.7.47 研究コード（Sランクと「55%に届くか」の検証）

前提: research_v0744/evidence_model.py（特徴量・P=1年分の候補表）と research_v0746/（5モデル平均）を使う。
  cand_oos.py            片方の半年で5モデルを学習し、もう片方の全候補（通貨×HIGH/LOW）の確率を出す（直前価格あり・予備）
  calib_lab.py           アプリと同じ判定（直近288/576枠、下位26%/53%見送り、S=上位10%）を確率から再現する実験台
  topk_tiers.py          上位2〜25%の区切りごとの勝率（前半/後半/10月/最大連敗）
  s_tier.py / s_tier_fb.py / s_tier_summary.py   ランク別（S/A/B/C）・S+A・全ENTRYの勝率と連敗（直前価格あり/予備）
  direction_calibration.py  向き（HIGH/LOW）ごとの予測と実際の勝率
  blend_lab.py / tie_bonus.py / agreement_check.py  予備モデルとの平均・引き分けリスクの加点・向きの一致
  coverage_curve.py      エントリー率と勝率の関係
  add_q90.py / gen_kotlin_ensemble.py  起動直後に使う上位10%の値をモデルデータに追加
結果: s_tier_summary.json（README_V0747.txt の表）、s_tier.json、s_tier_fallback.json、coverage_curve.json

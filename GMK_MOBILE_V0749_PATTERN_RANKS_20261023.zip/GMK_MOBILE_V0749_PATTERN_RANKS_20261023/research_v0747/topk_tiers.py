"""Win rate of the strongest k% of slots (exact rolling percentile, other-half model, fresh)."""
import pickle, pandas as pd, numpy as np
exec(open('calib_lab.py').read().split("if __name" + "__")[0])
D = C[True]; res = []
for fold in ('H1', 'H2'):
    tr = long_form(D[(D.fold == fold) & (D.role == 'train')]); te = long_form(D[(D.fold == fold) & (D.role == 'test')])
    btr = tr.sort_values('p', ascending=False).groupby('b').head(1); bte = te.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
    for wk in (True, False):
        x = btr[btr.weekday == wk]; off = x.groupby('hour').p.median(); adjt = (x.p - x.hour.map(off)).values
        y = bte[bte.weekday == wk].copy(); adj = (y.p - y.hour.map(off)).values; buf = []; pct = []
        for a in adj:
            ref = np.array(buf) if len(buf) >= NMIN else adjt
            pct.append((ref < a).mean()); buf.append(a); buf = buf[-NBUF[wk]:]
        y['pct'] = pct; res.append(y)
R = pd.concat(res).sort_values('b'); R['m'] = R.ts.dt.strftime('%Y-%m')
for wk in (True, False):
    x = R[R.weekday == wk]; nd = x.date.nunique()
    for top in (0.02, 0.03, 0.05, 0.07, 0.10, 0.15, 0.25):
        e = x[x.pct >= 1 - top]; mo = e.groupby('m').win.mean(); dm = e.groupby('date').win.apply(lambda v: ms(v.values))
        print(f'{"平日" if wk else "土日"} top{int(top*100):2d}% n={len(e):5d} {len(e)/nd:4.1f}/日 win={e.win.mean()*100:5.2f} H1={e[e.half=="H1"].win.mean()*100:4.1f} H2={e[e.half=="H2"].win.mean()*100:4.1f} '
              f'Oct25={e[e.m=="2025-10"].win.mean()*100:4.1f} Oct26={e[e.m=="2026-10"].win.mean()*100:4.1f} 月<50:{(mo<.5).sum()} 月>=55:{(mo>=.55).sum()} 最大連敗={ms(e.win.values)} 日平均最大={dm.mean():.1f}')
pickle.dump(R, open('../work/pct_fresh.pkl', 'wb'))

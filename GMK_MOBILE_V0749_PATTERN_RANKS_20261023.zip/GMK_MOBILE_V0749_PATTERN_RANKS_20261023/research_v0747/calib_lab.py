"""Lab: re-run the exact rolling rule from per-candidate OOS probabilities, with optional score transforms."""
import pickle, numpy as np, pandas as pd
C = pickle.load(open('../work/cand_oos.pkl', 'rb'))
RATE = {True: 0.74, False: 0.47}; NBUF = {True: 288, False: 576}; NMIN = 96
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def long_form(df):
    u = df.assign(dir=1, p=df.pu); d = df.assign(dir=-1, p=df.pd)
    x = pd.concat([u, d]); x['win'] = (x.move3 == x.dir).astype(int); return x
def run(fresh=True, score=None, label=''):
    """score(train_long, test_long) -> score series for test_long (higher = better)."""
    D = C[fresh]; res = []
    for fold in ('H1', 'H2'):
        tr = long_form(D[(D.fold == fold) & (D.role == 'train')]); te = long_form(D[(D.fold == fold) & (D.role == 'test')])
        if score is not None: tr['s'] = score(tr, tr); te['s'] = score(tr, te)
        else: tr['s'] = tr.p; te['s'] = te.p
        btr = tr.sort_values('s', ascending=False).groupby('b').head(1); bte = te.sort_values('s', ascending=False).groupby('b').head(1).sort_values('b')
        for wk in (True, False):
            x = btr[btr.weekday == wk]; off = x.groupby('hour').s.median(); adjt = x.s - x.hour.map(off)
            seeds = (adjt.quantile(1 - RATE[wk]), adjt.quantile(.5), adjt.quantile(.75), adjt.quantile(.9))
            y = bte[bte.weekday == wk].copy(); adj = (y.s - y.hour.map(off)).values; buf = []; g = []
            for a in adj:
                if len(buf) >= NMIN:
                    arr = np.array(buf); cut = (np.quantile(arr, 1 - RATE[wk]), np.quantile(arr, .5), np.quantile(arr, .75), np.quantile(arr, .9))
                else: cut = seeds
                g.append('E' if a < cut[0] else 'S' if a >= cut[3] else 'A' if a >= cut[2] else 'B' if a >= cut[1] else 'C')
                buf.append(a); buf = buf[-NBUF[wk]:]
            y['grade'] = g; res.append(y)
    R = pd.concat(res).sort_values('b'); R['m'] = R.ts.dt.strftime('%Y-%m')
    out = {}
    for wk in (True, False):
        x = R[R.weekday == wk]; e = x[x.grade != 'E']; s = e[e.grade == 'S']
        dm = e.groupby('date').win.apply(lambda v: ms(v.values)); dms = s.groupby('date').win.apply(lambda v: ms(v.values))
        out[wk] = dict(entry=round((x.grade != 'E').mean() * 100, 1), win=round(e.win.mean() * 100, 2), h1=round(e[e.half == 'H1'].win.mean() * 100, 1), h2=round(e[e.half == 'H2'].win.mean() * 100, 1),
                       S=round(s.win.mean() * 100, 1), S_h1=round(s[s.half == 'H1'].win.mean() * 100, 1), S_h2=round(s[s.half == 'H2'].win.mean() * 100, 1), S_n=len(s),
                       SA=round(e[e.grade.isin(['S', 'A'])].win.mean() * 100, 1), maxs=ms(e.win.values), d8=round((dm >= 8).mean() * 100, 1), S_max=ms(s.win.values),
                       low_share=round((e.dir == -1).mean() * 100), S_low=round((s.dir == -1).mean() * 100), oct=round(e[e.m.isin(['2025-10', '2026-10'])].win.mean() * 100, 1))
        print(f'{label:28s} {"平日" if wk else "土日"} ' + ' '.join(f'{k}={v}' for k, v in out[wk].items()), flush=True)
    return R, out
if __name__ == '__main__':
    run(True, None, 'baseline fresh')

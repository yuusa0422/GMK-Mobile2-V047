import pickle, numpy as np, pandas as pd
exec(open('calib_lab.py').read().split('if __name' + '__')[0])
Fb = C[False][['b', 'inst', 'fold', 'role', 'pu', 'pd']].rename(columns={'pu': 'fu', 'pd': 'fd'})
C[True] = C[True].merge(Fb, on=['b', 'inst', 'fold', 'role'], how='left')
def long_form(df):
    u = df.assign(dir=1, p=df.pu, fp=df.fu); d = df.assign(dir=-1, p=df.pd, fp=df.fd)
    x = pd.concat([u, d]); x['win'] = (x.move3 == x.dir).astype(int); return x
globals()['long_form'] = long_form
if __name__ == '__main__':
    import sys
    for w in [0.0, 0.25, 0.5]:
        run(True, (lambda w: (lambda tr, te: (1 - w) * te.p + w * te.fp))(w), f'blend w_fallback={w}')

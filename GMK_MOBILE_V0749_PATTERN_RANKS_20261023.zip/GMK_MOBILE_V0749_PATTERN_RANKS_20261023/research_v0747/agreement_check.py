"""Does the backup model (no live price) agreeing with the chosen direction separate winners inside the top tiers?"""
import pickle, pandas as pd, numpy as np
R = pickle.load(open('../work/pct_fresh.pkl', 'rb'))
C = pickle.load(open('../work/cand_oos.pkl', 'rb'))[False]
F = C[C.role == 'test'][['b', 'inst', 'pu', 'pd']].rename(columns={'pu': 'fu', 'pd': 'fd'})
R = R.merge(F, on=['b', 'inst'], how='left')
R['fp'] = np.where(R.dir == 1, R.fu, R.fd); R['fother'] = np.where(R.dir == 1, R.fd, R.fu)
for wk in (False, True):
    for lo in (0.53, 0.75, 0.9, 0.95):
        x = R[(R.weekday == wk) & (R.pct >= lo)]
        for name, m in [('fp>other', x.fp > x.fother), ('fp<=other', x.fp <= x.fother), ('fp>=.5', x.fp >= .5), ('fp<.5', x.fp < .5)]:
            e = x[m]; print(f'{"平日" if wk else "土日"} pct>={lo} {name:10s} n={len(e):5d} win={e.win.mean()*100:5.1f} H1={e[e.half=="H1"].win.mean()*100:5.1f} H2={e[e.half=="H2"].win.mean()*100:5.1f} tie={(e.move3==0).mean()*100:4.1f}')

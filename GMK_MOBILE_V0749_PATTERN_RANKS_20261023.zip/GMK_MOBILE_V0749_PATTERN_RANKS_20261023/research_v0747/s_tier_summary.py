"""S / S+A / all-entry statistics for the README (exact rolling rule, other-half model, fresh)."""
import pandas as pd, numpy as np, pickle, json
E = pickle.load(open('../work/sim_ensemble.pkl', 'rb'))[True].copy()
E['m'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
off = E.groupby(['weekday', 'half', 'hour']).p.median()
E['adj'] = E.p - [off[(w, 'H2' if h == 'H1' else 'H1', hr)] for w, h, hr in zip(E.weekday, E.half, E.hour)]
NBUF = {True: 288, False: 576}
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
out = {}
for wk in (True, False):
    x = E[E.weekday == wk].sort_values('b').copy(); buf = []; tier = []
    for a in x.adj.values:
        if len(buf) >= 96:
            arr = np.array(buf); q90, q75, q50 = np.quantile(arr, .9), np.quantile(arr, .75), np.quantile(arr, .5)
            tier.append('S' if a >= q90 else 'A' if a >= q75 else 'B' if a >= q50 else 'C')
        else: tier.append('-')
        buf.append(a); buf = buf[-NBUF[wk]:]
    x['tier'] = tier; x = x[x.enter & (x.tier != '-')]; nd = x.date.nunique()
    for name, sel in [('S', ['S']), ('S+A', ['S', 'A']), ('all', ['S', 'A', 'B', 'C'])]:
        e = x[x.tier.isin(sel)]; dm = e.groupby('date').win.apply(lambda v: ms(v.values)).reindex(sorted(x.date.unique()), fill_value=0)
        mo = e.groupby('m').win.mean()
        r = dict(n=len(e), per_day=round(len(e) / nd, 1), win=round(e.win.mean() * 100, 1), H1=round(e[e.half == 'H1'].win.mean() * 100, 1), H2=round(e[e.half == 'H2'].win.mean() * 100, 1),
                 oct25=round(e[e.m == '2025-10'].win.mean() * 100, 1), oct26=round(e[e.m == '2026-10'].win.mean() * 100, 1), maxs=ms(e.win.values),
                 day_avg=round(dm.mean(), 1), d5=round((dm >= 5).mean() * 100, 1), d8=round((dm >= 8).mean() * 100, 1), d10=round((dm >= 10).mean() * 100, 1),
                 mlt50=int((mo < .5).sum()), mge55=int((mo >= .55).sum()), months=len(mo), worst_month=round(mo.min() * 100, 1), best_month=round(mo.max() * 100, 1))
        out[f'{"weekday" if wk else "weekend"}|{name}'] = {k: (float(v) if isinstance(v, (np.floating,)) else v) for k, v in r.items()}
        print('平日' if wk else '土日', name, out[f'{"weekday" if wk else "weekend"}|{name}'])
json.dump(out, open('../work/s_tier_summary.json', 'w'), ensure_ascii=False, indent=1)

"""Exhaustive search of 1-3 condition chart patterns (x HIGH/LOW). Find on one period, confirm on a second, score on a third.
Win = the 3-minute move in the chosen direction (a draw is a loss)."""
import pickle, itertools, json, sys, numpy as np, pandas as pd
X = pd.read_pickle('../work/pattern_frame.pkl')
X = X[X.body_r.notna()].copy()
d = pd.to_datetime(X.date)
X['period'] = np.where(d < '2026-02-01', 0, np.where(d < '2026-06-01', 1, 2))
def cut(v, edges, labels=None): return pd.cut(v, edges, labels=False, include_lowest=True).astype('float')
D = {}
D['inst'] = X.inst.map({s: i for i, s in enumerate(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY'])})
D['seg'] = (~X.weekday).astype(int)
D['hour'] = cut(X.hour, [8, 11, 14, 17, 20, 23])
D['f1'] = cut(X.f1, [-1e9, -2.5, -1.5, -0.5, 0.5, 1.5, 2.5, 1e9])
D['f5'] = cut(X.f5, [-1e9, -2, -1, 1, 2, 1e9])
D['r15'] = cut(X.r15, [-1e9, -1.5, -0.5, 0.5, 1.5, 1e9])
D['r60'] = cut(X.r60, [-1e9, -1.5, -0.5, 0.5, 1.5, 1e9])
D['streak'] = X.streak.clip(-5, 5) + 5
D['bar'] = np.select([X.body_r < 0.15, X.lo_w >= 0.6, X.up_w >= 0.6, X.body_r >= 0.8], [0, 1, 2, 3], 4) * 3 + (X.bar_dir + 1)
D['engulf'] = X.engulf + 1
D['brk15'] = X.brk15 + 1; D['brk60'] = X.brk60 + 1
D['rsi'] = cut(X.rsi, [-1, 20, 30, 70, 80, 101])
D['bbzL'] = cut(X.bbzL, [-1e9, -3, -2, -1, 1, 2, 3, 1e9])
D['pos15L'] = cut(X.pos15L, [-1.01, -0.9, -0.5, 0.5, 0.9, 1.01])
D['hhll'] = X.hh3 * 2 + X.ll3
D['round'] = cut(X.rdist, [-1e9, -3, -0.5, 0.5, 3, 1e9])
D['p3'] = X.p3
D['rngx'] = cut(X.rng_x, [-1, 0.5, 1.5, 2.5, 1e9])
D['vol'] = X.groupby('inst').rv60.transform(lambda v: pd.qcut(v.rank(method='first'), 5, labels=False))
D['squeeze'] = cut(X.rv30_60, [-1, 0.8, 1.0, 1.2, 1e9])
D['yen'] = np.where(X.inst == 'BTCJPY', 3, np.sign(X.yenf1).fillna(0) * np.sign(X.f1).fillna(0) + 1)   # 2 = own move with the yen, 0 = against, 3 = BTC
D['tie'] = np.where(X.inst == 'BTCJPY', cut(X.tie58, [-1, 0.05, 0.15, 0.3, 2]), 4)
D['dmean'] = cut(X.dmean60, [-1e9, -3, -1, 1, 3, 1e9])
F = pd.DataFrame(D).fillna(-1).astype(int) + 1     # 0 = missing
names = list(F.columns); K = {c: int(F[c].max()) + 1 for c in names}
up = (X.move3.values == 1).astype(float); dn = (X.move3.values == -1).astype(float); per = X.period.values
nd = {p: X[X.period == p].date.nunique() for p in range(3)}
def mine(find, conf, score, max_order=3, nmin=40, wmin=0.60):
    rules = []
    for order in range(1, max_order + 1):
        for combo in itertools.combinations(names, order):
            key = np.zeros(len(F), dtype=np.int64); mult = 1
            for c in combo: key += F[c].values * mult; mult *= K[c]
            if mult > 5_000_000: continue
            stats = {}
            for p in range(3):
                m = per == p
                n = np.bincount(key[m], minlength=mult); u = np.bincount(key[m], weights=up[m], minlength=mult); w = np.bincount(key[m], weights=dn[m], minlength=mult)
                stats[p] = (n, u, w)
            n0, u0, d0 = stats[find]
            for k in np.flatnonzero(n0 >= nmin):
                for dirn, wins in ((1, u0[k]), (-1, d0[k])):
                    r0 = wins / n0[k]
                    if r0 < wmin: continue
                    n1, u1, d1 = stats[conf]; n2, u2, d2 = stats[score]
                    r1 = (u1[k] if dirn == 1 else d1[k]) / n1[k] if n1[k] else np.nan
                    r2 = (u2[k] if dirn == 1 else d2[k]) / n2[k] if n2[k] else np.nan
                    levels = []; kk = k
                    for c in combo: levels.append(int(kk % K[c])); kk //= K[c]
                    rules.append(dict(order=order, combo='|'.join(combo), levels=levels, key=int(k), dir=dirn, n_find=int(n0[k]), win_find=r0,
                                      n_conf=int(n1[k]), win_conf=r1, n_score=int(n2[k]), win_score=r2))
    return pd.DataFrame(rules)
if __name__ == '__main__':
    out = {}
    for find, conf, score in ((0, 1, 2), (2, 1, 0)):
        R = mine(find, conf, score)
        R.to_pickle(f'../work/patterns_{find}{conf}{score}.pkl')
        print(f'\n===== 探す期間 {find} → 確かめる {conf} → 採点 {score}: 候補 {len(R):,} 件（探す期間で60%以上・40件以上）')
        R['band'] = pd.cut(R.win_find, [0.6, 0.65, 0.7, 0.8, 1.01], right=False)
        t = R.groupby('band', observed=True).agg(rules=('win_find', 'size'), find=('win_find', 'mean'), conf=('win_conf', 'mean'), score=('win_score', 'mean'),
                                                  n_find=('n_find', 'median'))
        print(t.round(3).to_string())
        C = R[(R.win_conf >= 0.60) & (R.n_conf >= 20)]
        print(f'確かめる期間でも60%以上（20件以上）: {len(C):,} 件 → 採点期間の平均 {C.win_score.mean()*100:.1f}%（件数加重 {np.average(C.win_score.fillna(0.5), weights=C.n_score.clip(lower=1))*100:.1f}%）')
        for th in (0.65, 0.70):
            C2 = R[(R.win_find >= th) & (R.win_conf >= th) & (R.n_conf >= 20)]
            print(f'  探す・確かめる両方で{int(th*100)}%以上: {len(C2):,} 件 → 採点期間 平均 {C2.win_score.mean()*100:.1f}% / 採点期間で{int(th*100)}%以上の割合 {(C2.win_score >= th).mean()*100:.1f}%')
        out[f'{find}{conf}{score}'] = dict(n=len(R), bands=t.reset_index().astype({'band': str}).to_dict('records'), confirmed=len(C), confirmed_score=float(C.win_score.mean()))
    json.dump(out, open('../work/pattern_mine.json', 'w'), ensure_ascii=False, indent=1, default=float)

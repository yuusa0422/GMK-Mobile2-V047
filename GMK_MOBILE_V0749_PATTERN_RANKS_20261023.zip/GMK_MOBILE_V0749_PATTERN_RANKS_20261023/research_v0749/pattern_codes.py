"""Pattern condition codes (shared by the search, the app export and the parity fixture).
Every code is computable at B-10s from the 61 complete 1-minute bars + the live price."""
import numpy as np, pandas as pd
INST = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']
EDGES = {
 'hour': [8, 11, 14, 17, 20, 23], 'f1': [-1e9, -2.5, -1.5, -0.5, 0.5, 1.5, 2.5, 1e9], 'f5': [-1e9, -2, -1, 1, 2, 1e9],
 'r3': [-1e9, -2, -1, 1, 2, 1e9], 'r15': [-1e9, -1.5, -0.5, 0.5, 1.5, 1e9], 'r60': [-1e9, -1.5, -0.5, 0.5, 1.5, 1e9],
 'rsi': [-1, 20, 30, 70, 80, 101], 'bbzL': [-1e9, -3, -2, -1, 1, 2, 3, 1e9], 'pos15L': [-1.01, -0.9, -0.5, 0.5, 0.9, 1.01],
 'pos60L': [-1.01, -0.9, -0.5, 0.5, 0.9, 1.01], 'round': [-1e9, -3, -0.5, 0.5, 3, 1e9], 'rngx': [-1, 0.5, 1.5, 2.5, 1e9],
 'squeeze': [-1, 0.8, 1.0, 1.2, 1e9], 'tie': [-1, 0.05, 0.15, 0.3, 2], 'dmean': [-1e9, -3, -1, 1, 3, 1e9]}
def binv(v, e):
    """pd.cut(..., include_lowest=True) labels: (e[i], e[i+1]] with the first bin closed on the left."""
    v = np.asarray(v, float); out = np.searchsorted(np.asarray(e, float), v, side='left') - 1
    out = np.where(v == e[0], 0, out)
    return np.where((v < e[0]) | (v > e[-1]) | np.isnan(v), -1, out)
def codes(X, vol_cuts):
    """X needs the policy_data + pattern_frame columns. Returns DataFrame of small integer codes (0 = missing)."""
    btc = (X.inst == 'BTCJPY').values
    D = {}
    D['inst'] = X.inst.map({s: i for i, s in enumerate(INST)}).values
    D['seg'] = (~X.weekday).astype(int).values
    for c, src in (('hour', 'hour'), ('f1', 'f1'), ('f5', 'f5'), ('r3', 'r3'), ('r15', 'r15'), ('r60', 'r60'), ('rsi', 'rsi'), ('bbzL', 'bbzL'),
                   ('pos15L', 'pos15L'), ('pos60L', 'pos60L'), ('round', 'rdist'), ('rngx', 'rng_x'), ('squeeze', 'rv30_60'), ('dmean', 'dmean60')):
        D[c] = binv(X[src].values, EDGES[c])
    D['streak'] = np.clip(X.streak.values, -5, 5) + 5
    shape = np.select([X.body_r < 0.15, X.lo_w >= 0.6, X.up_w >= 0.6, X.body_r >= 0.8], [0, 1, 2, 3], 4)
    D['bar'] = shape * 3 + (X.bar_dir.values + 1)
    D['engulf'] = X.engulf.values + 1
    D['brk15'] = X.brk15.values + 1; D['brk60'] = X.brk60.values + 1
    D['hhll'] = X.hh3.values * 2 + X.ll3.values
    D['p3'] = X.p3.values
    vc = np.array([vol_cuts[i] for i in X.inst.values])            # per-instrument quintile cut points of rv60
    D['vol'] = (X.rv60.values[:, None] > vc).sum(1)
    D['yen'] = np.where(btc, 3, np.sign(X.yenf1.fillna(0).values) * np.sign(X.f1.fillna(0).values) + 1)
    D['tie'] = np.where(btc, binv(X.tie58.values, EDGES['tie']), 4)
    m = X.ts.dt.minute.values
    D['minute'] = np.where(np.isin(m, [0, 30]), 0, np.where(np.isin(m, [15, 45]), 1, 2))
    D['dow'] = X.ts.dt.dayofweek.values
    F = pd.DataFrame(D, index=X.index)
    return (F.fillna(-1).astype(int) + 1)
# trade-relative flip: level for a LOW trade = mirror of the price-move level
SIGNED_SYM = ['f1', 'f5', 'r3', 'r15', 'r60', 'rsi', 'bbzL', 'pos15L', 'pos60L', 'round', 'dmean', 'streak', 'engulf', 'brk15', 'brk60']
def flip(F, dirs):
    G = F.copy(); low = dirs == -1
    K = {c: int(F[c].max()) for c in F.columns}
    nlev = {'f1': 7, 'f5': 5, 'r3': 5, 'r15': 5, 'r60': 5, 'rsi': 5, 'bbzL': 7, 'pos15L': 5, 'pos60L': 5, 'round': 5, 'dmean': 5, 'streak': 11, 'engulf': 3, 'brk15': 3, 'brk60': 3}
    for c in SIGNED_SYM:
        v = F[c].values; G.loc[low, c] = np.where(v[low] == 0, 0, nlev[c] + 1 - v[low])
    b = F['bar'].values - 1; shape = b // 3; dd = b % 3
    shape_f = np.where(shape == 1, 2, np.where(shape == 2, 1, shape)); dd_f = 2 - dd
    G.loc[low, 'bar'] = (shape_f * 3 + dd_f)[low] + 1
    h = F['hhll'].values - 1; hf = np.where(h == 1, 2, np.where(h == 2, 1, h)); G.loc[low, 'hhll'] = hf[low] + 1
    p = F['p3'].values - 1; a, bb, c3 = p // 9, (p // 3) % 3, p % 3; pf = (2 - a) * 9 + (2 - bb) * 3 + (2 - c3); G.loc[low, 'p3'] = pf[low] + 1
    return G
SIGN = {'f1': [-1, -1, -1, 0, 1, 1, 1], 'f5': [-1, -1, 0, 1, 1], 'r3': [-1, -1, 0, 1, 1], 'r15': [-1, -1, 0, 1, 1], 'r60': [-1, -1, 0, 1, 1],
        'rsi': [-1, -1, 0, 1, 1], 'bbzL': [-1, -1, -1, 0, 1, 1, 1], 'pos15L': [-1, -1, 0, 1, 1], 'pos60L': [-1, -1, 0, 1, 1], 'dmean': [-1, -1, 0, 1, 1],
        'streak': [-1] * 5 + [0] + [1] * 5, 'engulf': [-1, 0, 1], 'brk15': [-1, 0, 1], 'brk60': [-1, 0, 1], 'hhll': [0, -1, 1, 0]}
def move_sign(c, level):
    v = level - 1
    if v < 0: return 0
    if c in SIGN: return SIGN[c][v]
    if c == 'bar': return [-1, 0, 1][v % 3] if v // 3 != 0 else 0
    if c == 'p3': s = (v // 9 - 1) + ((v // 3) % 3 - 1) + (v % 3 - 1); return int(np.sign(s))
    return 0

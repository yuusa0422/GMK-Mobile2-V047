"""Patterns that won in all three periods (each period >= 56%, >= 30 trades each). Selection uses all data -> optimistic ceiling."""
import numpy as np, pandas as pd, itertools, json
exec(open('pattern_mine.py').read().split("if __name" + "__")[0])
LAB = {
 'inst': ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY'], 'seg': ['平日', '土日'], 'hour': ['9-11時', '12-14時', '15-17時', '18-20時', '21-22時'],
 'f1': ['直前1分 -2.5σ以下', '直前1分 -2.5〜-1.5σ', '直前1分 -1.5〜-0.5σ', '直前1分 ±0.5σ', '直前1分 +0.5〜1.5σ', '直前1分 +1.5〜2.5σ', '直前1分 +2.5σ以上'],
 'f5': ['直前5分 -2σ以下', '直前5分 -2〜-1σ', '直前5分 ±1σ', '直前5分 +1〜2σ', '直前5分 +2σ以上'],
 'r15': ['15分 -1.5σ以下', '15分 -1.5〜-0.5σ', '15分 ±0.5σ', '15分 +0.5〜1.5σ', '15分 +1.5σ以上'],
 'r60': ['60分 -1.5σ以下', '60分 -1.5〜-0.5σ', '60分 ±0.5σ', '60分 +0.5〜1.5σ', '60分 +1.5σ以上'],
 'streak': [f'連続{"陰" if v < 0 else "陽" if v > 0 else "横"}{abs(v)}本' if v else '直前は横ばい' for v in range(-5, 6)],
 'engulf': ['陰の包み足', '包み足なし', '陽の包み足'], 'brk15': ['15分安値割れ', '15分の範囲内', '15分高値超え'], 'brk60': ['60分安値割れ', '60分の範囲内', '60分高値超え'],
 'rsi': ['RSI20未満', 'RSI20-30', 'RSI30-70', 'RSI70-80', 'RSI80超'], 'bbzL': ['BB -3σ以下', 'BB -3〜-2σ', 'BB -2〜-1σ', 'BB ±1σ', 'BB +1〜2σ', 'BB +2〜3σ', 'BB +3σ以上'],
 'pos15L': ['15分レンジの最安値付近', '15分レンジ下側', '15分レンジ中央', '15分レンジ上側', '15分レンジの最高値付近'],
 'hhll': ['高値・安値の切り上げ/下げなし', '3本連続の安値切り下げ', '3本連続の高値切り上げ', '両方'],
 'round': ['キリ番の下 3σ以上', 'キリ番の少し下', 'キリ番ちょうど', 'キリ番の少し上', 'キリ番の上 3σ以上'],
 'rngx': ['直前足の値幅 小', '値幅 普通', '値幅 大(1.5-2.5倍)', '値幅 特大(2.5倍超)'], 'vol': ['値動き 最小20%', '値動き 小', '値動き 中', '値動き 大', '値動き 最大20%'],
 'squeeze': ['直近30分が静か', 'やや静か', 'やや荒い', '直近30分が荒い'], 'yen': ['円全体と逆の動き', '円全体の動きなし', '円全体と同じ動き', 'BTC'],
 'tie': ['BTC引き分けリスク 最小', 'BTC引き分けリスク 小', 'BTC引き分けリスク 中', 'BTC引き分けリスク 大', '為替'],
 'dmean': ['60分平均の -3σ以下', '60分平均の -3〜-1σ', '60分平均 付近', '60分平均の +1〜3σ', '60分平均の +3σ以上'],
}
def bar_label(v):
    shape = ['十字線', '下ヒゲ長い', '上ヒゲ長い', '大陽線/大陰線', '普通の足'][v // 3]; dd = ['陰', '横', '陽'][v % 3]; return f'直前足 {shape}（{dd}）'
def p3_label(v):
    a = ['陰', '横', '陽']; return f'足の並び {a[v // 9]}→{a[(v // 3) % 3]}→直前1分{a[v % 3]}'
def label(c, lv):
    v = lv - 1
    if v < 0: return f'{c}=不明'
    if c == 'bar': return bar_label(v)
    if c == 'p3': return p3_label(v)
    return LAB[c][v]
rows = []
for order in range(1, 4):
    for combo in itertools.combinations(names, order):
        key = np.zeros(len(F), dtype=np.int64); mult = 1
        for c in combo: key += F[c].values * mult; mult *= K[c]
        if mult > 5_000_000: continue
        st = []
        for p in range(3):
            m = per == p
            st.append((np.bincount(key[m], minlength=mult), np.bincount(key[m], weights=up[m], minlength=mult), np.bincount(key[m], weights=dn[m], minlength=mult)))
        ok = (st[0][0] >= 30) & (st[1][0] >= 30) & (st[2][0] >= 30)
        for k in np.flatnonzero(ok):
            for dirn in (1, -1):
                r = [(s[1][k] if dirn == 1 else s[2][k]) / s[0][k] for s in st]
                if min(r) >= 0.56:
                    lv = []; kk = k
                    for c in combo: lv.append(int(kk % K[c])); kk //= K[c]
                    n = [int(s[0][k]) for s in st]
                    rows.append(dict(pattern=' & '.join(label(c, l) for c, l in zip(combo, lv)), dir='HIGH' if dirn == 1 else 'LOW', order=order,
                                     n=sum(n), per_day=round(sum(n) / sum(nd.values()), 2), win=round(sum(r[i] * n[i] for i in range(3)) / sum(n) * 100, 1),
                                     p1=round(r[0] * 100, 1), p2=round(r[1] * 100, 1), p3=round(r[2] * 100, 1), min_period=round(min(r) * 100, 1)))
R = pd.DataFrame(rows).sort_values(['min_period', 'n'], ascending=False)
print(len(R), 'patterns with every period >= 56%'); pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 90)
print(R.head(40).to_string())
print('win distribution of these:', R.win.describe().round(1).to_dict())
R.to_csv('../work/pattern_robust.csv', index=False, encoding='utf-8-sig')

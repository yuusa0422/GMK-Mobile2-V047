v0.7.49 研究コード（形＝チャートパターンの探索と、ランク・反転）

  pattern_features.py     61本の1分足＋直前価格から形の特徴（足の形・連続・包み足・高値/安値更新・RSI・キリ番など）
  pattern_codes.py        28項目の区分（アプリと同じ）、取引の向きに合わせた反転（flip）
  pattern_mine.py / pattern_chance.py / pattern_robust*.py / pattern_rotation.py  形の総当たりと、偶然・別期間での確認
  pattern_mine2.py        勝ちパターン（3期間すべて56%以上）・どちらでも負ける形・アプリの取引の負けパターン
  pattern_export.py       一覧（CSV）用の文言
  reversal_mine.py        反転パターン（アプリの取引を逆にすると3期間すべて56%以上）
  reversal_rotation.py / pattern_agree_rotation.py  別の期間での確認
  ladder_v0749.py         v0.7.49 のランク（S/A/B=形、C=形なし、D〜H=見送り）の1年の数字 → ladder_v0749.json
  gen_kotlin_patterns.py  アプリ用の形の表（EvidencePatternData.kt）と一致テストの生成
期間1 = 2025年10月〜2026年1月、期間2 = 2月〜5月、期間3 = 6月〜10月。引き分けは負け。

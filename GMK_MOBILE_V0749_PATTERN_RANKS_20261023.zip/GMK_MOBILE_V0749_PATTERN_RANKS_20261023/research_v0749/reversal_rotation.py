"""Other-period check of reversal: patterns found on two periods, reversal applied in the third."""
import pickle, itertools, json, numpy as np, pandas as pd
from pattern_codes import *
import pattern_mine2 as pm
X = pm.X; F = pm.F
T = pd.read_pickle('../work/reversal_trades.pkl')
pos = pd.Series(np.arange(len(X)), index=X.index); trow = pos.loc[T['index'].values].values
tper = X.period.values[trow]; tdir = T.dir.values
rev = (T.move3.values == -tdir).astype(float); win = T.win.values.astype(float); ent = T.grade.isin(list('SABC')).values
Ft = flip(F.iloc[trow].reset_index(drop=True), tdir); Ft['dir'] = (tdir == 1).astype(int) + 1; Ft['entry'] = ent.astype(int) + 1
cols = list(Ft.columns); Kd = {c: int(Ft[c].max()) + 1 for c in cols}
out = []
for a, b, c in ((0, 1, 2), (0, 2, 1), (1, 2, 0)):
    hit = np.zeros(len(T), bool)
    for order in range(1, 4):
        for combo in itertools.combinations(cols, order):
            key = np.zeros(len(Ft), dtype=np.int64); mult = 1
            for cc in combo: key += Ft[cc].values * mult; mult *= Kd[cc]
            if mult > 6_000_000: continue
            na = np.bincount(key[tper == a], minlength=mult); nb = np.bincount(key[tper == b], minlength=mult)
            ra = np.bincount(key[tper == a], weights=rev[tper == a], minlength=mult) / np.maximum(na, 1)
            rb = np.bincount(key[tper == b], weights=rev[tper == b], minlength=mult) / np.maximum(nb, 1)
            good = (na >= 25) & (nb >= 25) & (np.minimum(ra, rb) >= 0.56)
            if good.any(): hit |= (tper == c) & good[key]
    for wk in (True, False):
        m = (tper == c) & (T.weekday.values == wk)
        for lab, sel in (('ENTRYで該当', m & ent & hit), ('見送りで該当', m & ~ent & hit)):
            out.append(dict(rot=f'{a}{b}->{c}', seg='平日' if wk else '土日', group=lab, n=int(sel.sum()), asis=float(win[sel].mean()) if sel.any() else np.nan,
                            reversed=float(rev[sel].mean()) if sel.any() else np.nan, share=float(sel.sum() / max((m & (ent if 'ENTRY' in lab else ~ent)).sum(), 1))))
R = pd.DataFrame(out); print(R.round(3).to_string())
S = R.groupby(['seg', 'group']).apply(lambda g: pd.Series(dict(n=g.n.sum(), asis=np.average(g.asis.fillna(0), weights=g.n) if g.n.sum() else np.nan,
                                                               reversed=np.average(g.reversed.fillna(0), weights=g.n) if g.n.sum() else np.nan))).reset_index()
print(S.round(3).to_string()); json.dump(S.to_dict('records'), open('../work/reversal_rotation.json', 'w'), ensure_ascii=False, indent=1)

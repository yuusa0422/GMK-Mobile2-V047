"""In-sample evaluation of the pattern overlay (patterns treated as real, per the user's decision)."""
import pickle, json, numpy as np, pandas as pd
from pattern_codes import *
X = pd.read_pickle('../work/pattern_frame.pkl'); X = X[X.body_r.notna()].copy()
J = json.load(open('../work/pattern_mine2.json'))
F = codes(X, J['vol_cuts'])
W = pd.read_pickle('../work/win_patterns.pkl'); B = pd.read_pickle('../work/both_lose_patterns.pkl'); C = pd.read_pickle('../work/chosen_lose_patterns.pkl')
def mask(df, combo, levels):
    m = np.ones(len(df), bool)
    for c, l in zip(combo.split('|'), levels.split('|')): m &= df[c].values == int(l)
    return m
# best winning pattern per row (row = slot x instrument): highest '一番低い期間', then '1年の勝率'
best_score = np.full(len(X), -1.0); best_rate = np.zeros(len(X)); best_dir = np.zeros(len(X), int); best_id = np.full(len(X), -1)
for i, r in enumerate(W.itertuples()):
    m = mask(F, r.combo, r.levels)
    sc = r.一番低い期間 * 1000 + r._7
    upd = m & (sc > best_score)
    best_score[upd] = sc; best_rate[upd] = r._7; best_dir[upd] = 1 if r.向き == 'HIGH' else -1; best_id[upd] = i
X['pat_id'] = best_id; X['pat_rate'] = best_rate; X['pat_min'] = np.floor(best_score / 1000); X['pat_dir'] = best_dir
# both-lose rows
bl = np.zeros(len(X), bool)
for r in B.itertuples(): bl |= mask(F, r.combo, r.levels)
X['both_lose'] = bl
# per slot: best pattern among the app's candidates (weekday: all six, weekend: BTC)
cand = X[(X.weekday) | (X.inst == 'BTCJPY')]
hit = cand[cand.pat_id >= 0].sort_values(['b', 'pat_min', 'pat_rate'], ascending=[True, False, False]).groupby('b').head(1).copy()
hit['win'] = (hit.move3 == hit.pat_dir).astype(int)
nslots = cand.groupby('weekday').b.nunique()
for wk in (True, False):
    h = hit[hit.weekday == wk]
    print(f'{"平日" if wk else "土日"}: 勝ちパターンが出た枠 {len(h)/nslots[wk]*100:.1f}%  （1日 {len(h)/cand[cand.weekday == wk].date.nunique():.1f}回）  1年の勝率（見つけたデータそのもの） {h.win.mean()*100:.1f}%')
    h = h.assign(band=pd.cut(h.pat_rate, [55, 58, 60, 62, 65, 100]))
    print(h.groupby('band', observed=True).agg(n=('win', 'size'), win=('win', 'mean'), rate=('pat_rate', 'mean')).round(3).to_string())
pickle.dump(dict(hit=hit[['b', 'inst', 'pat_dir', 'pat_rate', 'pat_min', 'pat_id', 'win', 'weekday', 'date', 'half', 'hour']], both_lose=X.loc[X.both_lose, ['b', 'inst']]),
            open('../work/pattern_hits.pkl', 'wb'))

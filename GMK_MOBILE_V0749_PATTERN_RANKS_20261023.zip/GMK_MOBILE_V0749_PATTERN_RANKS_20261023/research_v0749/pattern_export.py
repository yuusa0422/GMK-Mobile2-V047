"""Pattern lists for the user (CSV) + page numbers. Chosen-trade losing patterns use trade-relative wording."""
import json, numpy as np, pandas as pd
from pattern_robust_labels import LAB, label
W = pd.read_pickle('../work/win_patterns.pkl'); B = pd.read_pickle('../work/both_lose_patterns.pkl'); C = pd.read_pickle('../work/chosen_lose_patterns.pkl')
REL = {
 'f1': ['直前1分 逆へ2.5σ以上', '直前1分 逆へ1.5〜2.5σ', '直前1分 逆へ0.5〜1.5σ', '直前1分 ほぼ動かず', '直前1分 向きへ0.5〜1.5σ', '直前1分 向きへ1.5〜2.5σ', '直前1分 向きへ2.5σ以上'],
 'f5': ['直前5分 逆へ2σ以上', '直前5分 逆へ1〜2σ', '直前5分 ±1σ', '直前5分 向きへ1〜2σ', '直前5分 向きへ2σ以上'],
 'r3': ['直前3分 逆へ2σ以上', '直前3分 逆へ1〜2σ', '直前3分 ±1σ', '直前3分 向きへ1〜2σ', '直前3分 向きへ2σ以上'],
 'r15': ['15分 逆へ1.5σ以上', '15分 逆へ0.5〜1.5σ', '15分 ±0.5σ', '15分 向きへ0.5〜1.5σ', '15分 向きへ1.5σ以上'],
 'r60': ['60分 逆へ1.5σ以上', '60分 逆へ0.5〜1.5σ', '60分 ±0.5σ', '60分 向きへ0.5〜1.5σ', '60分 向きへ1.5σ以上'],
 'rsi': ['RSI 逆側に行き過ぎ', 'RSI 逆側寄り', 'RSI 中立', 'RSI 向き側寄り', 'RSI 向き側に行き過ぎ'],
 'bbzL': ['BB 逆側3σ超', 'BB 逆側2〜3σ', 'BB 逆側1〜2σ', 'BB ±1σ', 'BB 向き側1〜2σ', 'BB 向き側2〜3σ', 'BB 向き側3σ超'],
 'pos15L': ['15分レンジの逆の端', '15分レンジ 逆側', '15分レンジ中央', '15分レンジ 向き側', '15分レンジの向きの端'],
 'pos60L': ['60分レンジの逆の端', '60分レンジ 逆側', '60分レンジ中央', '60分レンジ 向き側', '60分レンジの向きの端'],
 'round': ['キリ番の逆側 3σ以上', 'キリ番の少し逆側', 'キリ番ちょうど', 'キリ番の少し向き側', 'キリ番の向き側 3σ以上'],
 'dmean': ['60分平均より逆側 3σ超', '60分平均より逆側 1〜3σ', '60分平均付近', '60分平均より向き側 1〜3σ', '60分平均より向き側 3σ超'],
 'streak': [f'逆向きの足が{5 - i}本連続' for i in range(5)] + ['直前は横ばい'] + [f'向きの足が{i}本連続' for i in range(1, 6)],
 'engulf': ['逆向きの包み足', '包み足なし', '向きの包み足'], 'brk15': ['15分の逆側を抜けた', '15分の範囲内', '15分の向き側を抜けた'],
 'brk60': ['60分の逆側を抜けた', '60分の範囲内', '60分の向き側を抜けた'],
 'hhll': ['更新なし', '逆向きに3本連続更新', '向きに3本連続更新', '両方向に更新'], 'dir': ['LOWの取引', 'HIGHの取引']}
def rel_label(c, lv):
    v = lv - 1
    if v < 0: return f'{c}=不明'
    if c in REL: return REL[c][v]
    if c == 'bar':
        shape = ['十字線', '逆側に長いヒゲ', '向き側に長いヒゲ', '大きな実体', '普通の足'][v // 3]; dd = ['逆', '横', '向き'][v % 3]; return f'直前足 {shape}（{dd}）'
    if c == 'p3':
        a = ['逆', '横', '向き']; return f'足の並び {a[v // 9]}→{a[(v // 3) % 3]}→直前1分{a[v % 3]}'
    return label(c, lv)
def _main():
    global C
    C['形'] = [' & '.join(rel_label(c, int(l)) for c, l in zip(r.combo.split('|'), r.levels.split('|'))) for r in C.itertuples()]
    ndays = 337
    win = W.sort_values(['種類', '一番低い期間', '件数'], ascending=[True, False, False])[['種類', '形', '向き', '条件の数', '件数', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3', '一番低い期間']]
    win.to_csv('../pages/GMK_勝ちパターン一覧.csv', index=False, encoding='utf-8-sig')
    lose = C.sort_values(['一番高い期間', '件数'], ascending=[True, False])[['形', '条件の数', '件数', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3', '一番高い期間']]
    lose.insert(0, '説明', 'アプリが選んだ取引の勝率（向き＝取引の向き、逆＝取引と反対）')
    lose.to_csv('../pages/GMK_負けパターン一覧.csv', index=False, encoding='utf-8-sig')
    both = B.sort_values(['1日あたり'], ascending=False).head(300)[['形', '条件の数', '件数', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3']]
    both.rename(columns={'1年の勝率': '1年の勝率（良い方の向き）'}).to_csv('../pages/GMK_どちらでも負ける形.csv', index=False, encoding='utf-8-sig')
    fam = W.groupby('種類').agg(数=('形', 'size'), 平均勝率=('1年の勝率', 'mean'), 最高=('1年の勝率', 'max')).round(1)
    print(fam.to_string()); print(len(win), len(lose), len(both))
    summary = dict(families={k: v for k, v in fam.to_dict('index').items()},
                   top_win={k: g.sort_values(['一番低い期間', '件数'], ascending=False).head(6)[['形', '向き', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3']].to_dict('records') for k, g in W.groupby('種類')},
                   top_lose=lose.head(15)[['形', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3']].to_dict('records'),
                   both_top=both.head(8)[['形', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3']].to_dict('records'), n_both=len(B))
    json.dump(summary, open('../work/pattern_export.json', 'w'), ensure_ascii=False, indent=1, default=float)
    print(lose.head(15).to_string())
if __name__ == '__main__':
    _main()

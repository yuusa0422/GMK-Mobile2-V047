"""Model trade (v0.7.48, other-half model) x winning patterns of the same instrument (in-sample patterns)."""
import pickle, json, numpy as np, pandas as pd
from pattern_codes import *
X = pd.read_pickle('../work/pattern_frame.pkl'); X = X[X.body_r.notna()].copy()
J = json.load(open('../work/pattern_mine2.json')); F = codes(X, J['vol_cuts'])
W = pd.read_pickle('../work/win_patterns.pkl'); C = pd.read_pickle('../work/chosen_lose_patterns.pkl'); Bl = pd.read_pickle('../work/both_lose_patterns.pkl')
def mask(df, combo, levels):
    m = np.ones(len(df), bool)
    for c, l in zip(combo.split('|'), levels.split('|')): m &= df[c].values == int(l)
    return m
# per row and direction: best pattern rate (by min period then year)
best = {1: np.zeros(len(X)), -1: np.zeros(len(X))}; bmin = {1: np.zeros(len(X)), -1: np.zeros(len(X))}; bid = {1: np.full(len(X), -1), -1: np.full(len(X), -1)}
for i, r in enumerate(W.itertuples()):
    d = 1 if r.向き == 'HIGH' else -1; m = mask(F, r.combo, r.levels)
    upd = m & ((r.一番低い期間 > bmin[d]) | ((r.一番低い期間 == bmin[d]) & (r._7 > best[d])))
    best[d][upd] = r._7; bmin[d][upd] = r.一番低い期間; bid[d][upd] = i
bl = np.zeros(len(X), bool)
for r in Bl.itertuples(): bl |= mask(F, r.combo, r.levels)
X = X.assign(wu=best[1], wdn=best[-1], mu=bmin[1], mdn=bmin[-1], iu=bid[1], idn=bid[-1], both_lose=bl)
T = pickle.load(open('../work/design_x_fresh.pkl', 'rb'))
T = T.merge(X.reset_index()[['index', 'b', 'inst', 'wu', 'wdn', 'mu', 'mdn', 'iu', 'idn', 'both_lose']], on=['b', 'inst'], how='left')
T['p_same'] = np.where(T.dir == 1, T.wu, T.wdn); T['p_opp'] = np.where(T.dir == 1, T.wdn, T.wu)
T['m_same'] = np.where(T.dir == 1, T.mu, T.mdn)
# chosen-lose patterns on the model's trade (trade-relative codes)
Ft = flip(F.loc[T['index'].values].reset_index(drop=True), T.dir.values); Ft['dir'] = (T.dir.values == 1).astype(int) + 1
cl = np.zeros(len(T), bool)
for r in C.itertuples(): cl |= mask(Ft, r.combo, r.levels)
T['chosen_lose'] = cl
for wk in (True, False):
    x = T[T.weekday == wk]; e = x[x.grade.isin(list('SABC'))]
    print(f'==== {"平日" if wk else "土日"}  ENTRY {len(e)}  勝率 {e.win.mean()*100:.1f}')
    e = e.assign(band=pd.cut(e.p_same, [-1, 0, 58, 60, 62, 65, 100]))
    t = e.groupby('band', observed=True).agg(n=('win', 'size'), win=('win', 'mean')); t['per_day'] = t.n / x.date.nunique()
    t['H1'] = e.groupby(['band', 'half'], observed=True).win.mean().unstack()['H1']; t['H2'] = e.groupby(['band', 'half'], observed=True).win.mean().unstack()['H2']
    print('同じ向きの勝ちパターンの勝率帯（-1,0]=該当なし'); print(t.round(3).to_string())
    print('逆向きの勝ちパターンあり（モデルと反対）:', round(((e.p_opp > 0) & (e.p_same == 0)).mean() * 100, 1), '% 勝率', round(e[(e.p_opp > 0) & (e.p_same == 0)].win.mean() * 100, 1))
    print('負けパターン（アプリの取引）該当:', round(e.chosen_lose.mean() * 100, 1), '% 勝率', round(e[e.chosen_lose].win.mean() * 100, 1), ' 非該当', round(e[~e.chosen_lose].win.mean() * 100, 1))
    print('どちらでも負ける形 該当:', round(e.both_lose.mean() * 100, 1), '% 勝率', round(e[e.both_lose].win.mean() * 100, 1))
T.to_pickle('../work/pattern_agree.pkl')

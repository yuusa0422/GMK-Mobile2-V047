"""Reversal patterns: conditions (trade-relative) under which the app's chosen trade loses and the OPPOSITE direction wins
>= 56% in every period (draws count as losses for both). All chosen trades (ENTRY and SKIP) of v0.7.48 (other-half model)."""
import pickle, json, itertools, numpy as np, pandas as pd
from pattern_codes import *
import pattern_mine2 as pm
X = pm.X; F = pm.F
T = pickle.load(open('../work/design_x_fresh.pkl', 'rb'))[['b', 'inst', 'dir', 'win', 'grade', 'move3', 'weekday', 'date', 'half', 'hour']]
rowmap = X.reset_index()[['index', 'b', 'inst']]
T = T.merge(rowmap, on=['b', 'inst']).reset_index(drop=True)
pos = pd.Series(np.arange(len(X)), index=X.index); trow = pos.loc[T['index'].values].values
tper = X.period.values[trow]; tdir = T.dir.values
rev = (T.move3.values == -tdir).astype(float); win = T.win.values.astype(float)
Ft = flip(F.iloc[trow].reset_index(drop=True), tdir); Ft['dir'] = (tdir == 1).astype(int) + 1
Ft['entry'] = T.grade.isin(list('SABC')).astype(int).values + 1        # allow 'ENTRY only' / 'SKIP only' conditions
R = pm.scan(Ft, tper, [('反転', rev)], lambda r: r.min(0) >= 0.56, nmin=25)
Rd = pm.describe(R, 'win')
import pattern_export as pe
Rd['形'] = [' & '.join(pe.rel_label(c, int(l)) if c != 'entry' else ['見送りの枠', 'ENTRYの枠'][int(l) - 1] for c, l in zip(r.combo.split('|'), r.levels.split('|'))) for r in Rd.itertuples()]
Rd = Rd.sort_values(['一番低い期間', '件数'], ascending=False)
Rd.to_pickle('../work/reversal_patterns.pkl')
print('反転パターン（反転した取引が3期間すべて56%以上・各25件以上）:', len(Rd))
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 80)
print(Rd.head(25)[['形', '1日あたり', '1年の勝率', '期間1', '期間2', '期間3']].to_string())
# chance benchmark
rng = np.random.default_rng(9); it = np.arange(len(T))
for p in range(3):
    m = np.flatnonzero(tper == p); it[m] = rng.permutation(m)
Rc = pm.scan(Ft, tper, [('反転', rev[it])], lambda r: r.min(0) >= 0.56, nmin=25)
print('偶然（結果を混ぜた場合）:', len(Rc))
# coverage in-sample
def mask(df, combo, levels):
    m = np.ones(len(df), bool)
    for c, l in zip(combo.split('|'), levels.split('|')): m &= df[c].values == int(l)
    return m
hit = np.zeros(len(T), bool)
for r in Rd.itertuples(): hit |= mask(Ft, r.combo, r.levels)
for wk in (True, False):
    m = (T.weekday.values == wk)
    e = m & T.grade.isin(list('SABC')).values
    print(f'{"平日" if wk else "土日"}: 反転パターン該当 ENTRY {hit[e].mean()*100:.1f}%（そのまま {win[e & hit].mean()*100:.1f}% → 反転 {rev[e & hit].mean()*100:.1f}%）  見送り枠の該当 {hit[m & ~e].mean()*100:.1f}%（反転 {rev[m & ~e & hit].mean()*100:.1f}%）')
json.dump(dict(n=len(Rd), chance=len(Rc)), open('../work/reversal_mine.json', 'w'))
T.assign(rev_hit=hit).to_pickle('../work/reversal_trades.pkl')

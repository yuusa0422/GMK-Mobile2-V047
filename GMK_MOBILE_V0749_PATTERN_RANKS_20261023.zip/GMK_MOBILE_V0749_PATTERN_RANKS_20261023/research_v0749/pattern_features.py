"""Candlestick / chart-pattern features for every (slot, instrument) of policy_data, from raw 1-minute bars.
Only information available at B-10s: complete bars up to the one opening at B-120, plus the live price
(backtest proxy: close of the bar opening at B-60)."""
import csv, gzip, bisect, math, numpy as np, pandas as pd
P = pd.read_pickle('../work/policy_data.pkl')
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
bars = {}
for s, p in SRC.items():
    with gzip.open(p, 'rt') as f:
        rows = sorted((int(r['epoch_ms']), float(r['open']), float(r['high']), float(r['low']), float(r['close'])) for r in csv.DictReader(f))
    a = np.array(rows); bars[s] = a
out = []
for inst, g in P.groupby('inst'):
    A = bars[inst]; t = A[:, 0].astype(np.int64)
    for idx, B in zip(g.index, g.b.values):
        i = np.searchsorted(t, (B - 120) * 1000, side='right')       # bars with open <= B-120
        if i < 61 or t[i - 1] != (B - 120) * 1000: out.append((idx,) + (np.nan,) * 23); continue
        w = A[i - 61:i]; o, h, l, c = w[:, 1], w[:, 2], w[:, 3], w[:, 4]
        j = np.searchsorted(t, (B - 60) * 1000)
        live = A[j, 4] if j < len(A) and t[j] == (B - 60) * 1000 else c[-1]
        # last complete bar shape
        rng = max(h[-1] - l[-1], 1e-12); body = c[-1] - o[-1]
        body_r = abs(body) / rng; up_w = (h[-1] - max(o[-1], c[-1])) / rng; lo_w = (min(o[-1], c[-1]) - l[-1]) / rng
        prev_body = c[-2] - o[-2]
        engulf = 0
        if body * prev_body < 0 and abs(body) > abs(prev_body) and max(o[-1], c[-1]) >= max(o[-2], c[-2]) and min(o[-1], c[-1]) <= min(o[-2], c[-2]):
            engulf = 1 if body > 0 else -1
        # consecutive closes in the same direction, ending with the live move
        seq = np.append(c, live); d = np.sign(np.diff(seq)); streak = 0
        last = d[-1]
        if last != 0:
            for v in d[::-1]:
                if v == last: streak += 1
                else: break
            streak = int(last * min(streak, 8))
        # breakouts by the live price
        hi15, lo15 = h[-15:].max(), l[-15:].min(); hi60, lo60 = h.max(), l.min()
        brk15 = 1 if live > hi15 else (-1 if live < lo15 else 0); brk60 = 1 if live > hi60 else (-1 if live < lo60 else 0)
        # RSI14 on closes incl. live (simple average of gains/losses)
        dd = np.diff(seq)[-14:]; gain = dd[dd > 0].sum(); loss = -dd[dd < 0].sum()
        rsi = 50.0 if gain + loss == 0 else 100 * gain / (gain + loss)
        # higher highs / lower lows in the last 3 complete bars
        hh = int(h[-1] > h[-2] > h[-3]); ll = int(l[-1] < l[-2] < l[-3])
        # round number distance (FX: 0.5 yen grid; BTC: 100,000 yen grid), in units of the 60-min 1-minute sigma
        lg = np.log(c); norm = max(np.sqrt(np.mean(np.diff(lg) ** 2)), 1e-8)
        grid = 100000.0 if inst == 'BTCJPY' else 0.5
        rn = round(live / grid) * grid; rdist = (live - rn) / (live * norm)
        # live bar direction vs last complete bar
        lb = np.sign(live - c[-1])
        # 3-bar pattern (signs of last 2 complete bars + live)
        p3 = int((np.sign(c[-2] - o[-2]) + 1) * 9 + (np.sign(body) + 1) * 3 + (lb + 1))
        # range of last complete bar vs average range (expansion)
        avg_rng = np.mean(h[-20:] - l[-20:]) + 1e-12; rng_x = rng / avg_rng
        # gap between live and the 20-bar mean in sigma (already bbzL) -> skip; distance from 60-min VWAP-like mean
        mean60 = c.mean(); dmean60 = (live - mean60) / (live * norm)
        hiL, loL = max(hi60, live), min(lo60, live); pos60L = (live - loL) / max(hiL - loL, 1e-12) * 2 - 1
        out.append((idx, body_r, up_w, lo_w, np.sign(body), engulf, streak, brk15, brk60, rsi, hh, ll, rdist, lb, p3, rng_x, dmean60,
                    float(live), float(c[-1]), float(h[-1] - l[-1]), float(np.sign(prev_body)), float(o[-1]), pos60L))
cols = ['idx', 'body_r', 'up_w', 'lo_w', 'bar_dir', 'engulf', 'streak', 'brk15', 'brk60', 'rsi', 'hh3', 'll3', 'rdist', 'live_dir', 'p3', 'rng_x', 'dmean60',
        'live', 'c_last', 'rng_last', 'prev_dir', 'o_last', 'pos60L']
F = pd.DataFrame(out, columns=cols).set_index('idx').sort_index()
X = P.join(F)
X.to_pickle('../work/pattern_frame.pkl')
print(X.shape, X[['body_r', 'streak', 'rsi', 'brk15', 'rdist']].describe().round(3))

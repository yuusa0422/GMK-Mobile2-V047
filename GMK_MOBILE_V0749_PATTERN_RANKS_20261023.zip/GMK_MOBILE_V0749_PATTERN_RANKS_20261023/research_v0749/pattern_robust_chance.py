"""How many 'won in all three periods' patterns appear when the outcomes are shuffled (pure luck)?"""
import numpy as np, itertools, json
exec(open('pattern_mine.py').read().split("if __name" + "__")[0])
def count(upv, dnv, th=0.56):
    c = 0; c60 = 0; c62 = 0
    for order in range(1, 4):
        for combo in itertools.combinations(names, order):
            key = np.zeros(len(F), dtype=np.int64); mult = 1
            for cc in combo: key += F[cc].values * mult; mult *= K[cc]
            if mult > 5_000_000: continue
            st = [(np.bincount(key[per == p], minlength=mult), np.bincount(key[per == p], weights=upv[per == p], minlength=mult),
                   np.bincount(key[per == p], weights=dnv[per == p], minlength=mult)) for p in range(3)]
            ok = (st[0][0] >= 30) & (st[1][0] >= 30) & (st[2][0] >= 30)
            if not ok.any(): continue
            for j in (1, 2):
                r = np.min([s[j][ok] / s[0][ok] for s in st], axis=0)
                c += int((r >= th).sum()); c60 += int((r >= 0.60).sum()); c62 += int((r >= 0.62).sum())
    return dict(ge56=c, ge60=c60, ge62=c62)
rng = np.random.default_rng(11)
res = {'real': count(up, dn), 'shuffled': []}
for s in range(3):
    idx = np.arange(len(F))
    for p in range(3):
        m = np.flatnonzero(per == p); idx[m] = rng.permutation(m)
    res['shuffled'].append(count(up[idx], dn[idx]))
print(json.dumps(res)); json.dump(res, open('../work/pattern_robust_chance.json', 'w'))

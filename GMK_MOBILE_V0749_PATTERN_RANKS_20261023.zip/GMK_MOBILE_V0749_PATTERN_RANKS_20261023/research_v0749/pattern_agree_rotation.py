"""Honest check of the overlay: patterns found on two periods only; the model's trades in the third period that
match a same-direction pattern vs the rest. Also losing patterns of the model's trades found on two periods."""
import pickle, json, itertools, numpy as np, pandas as pd
from pattern_codes import *
X = pd.read_pickle('../work/pattern_frame.pkl'); X = X[X.body_r.notna()].copy()
d = pd.to_datetime(X.date); X['period'] = np.where(d < '2026-02-01', 0, np.where(d < '2026-06-01', 1, 2))
J = json.load(open('../work/pattern_mine2.json')); F = codes(X, J['vol_cuts'])
per = X.period.values; up = (X.move3.values == 1).astype(float); dn = (X.move3.values == -1).astype(float)
cols = list(F.columns); Kd = {c: int(F[c].max()) + 1 for c in cols}
T = pickle.load(open('../work/design_x_fresh.pkl', 'rb'))
T = T[T.grade.isin(list('SABC'))]
rowmap = X.reset_index()[['index', 'b', 'inst']]
T = T.merge(rowmap, on=['b', 'inst'])
pos = pd.Series(np.arange(len(X)), index=X.index)
trow = pos.loc[T['index'].values].values
tper = per[trow]; tdir = T.dir.values; twin = T.win.values.astype(float)
Ft = flip(F.iloc[trow].reset_index(drop=True), tdir); Ft['dir'] = (tdir == 1).astype(int) + 1
Kt = {c: int(Ft[c].max()) + 1 for c in Ft.columns}
res = []
for a, b_, c in ((0, 1, 2), (0, 2, 1), (1, 2, 0)):
    same = np.zeros(len(T)); lose = np.zeros(len(T), bool)
    for order in range(1, 4):
        for combo in itertools.combinations(cols, order):
            key = np.zeros(len(F), dtype=np.int64); mult = 1
            for cc in combo: key += F[cc].values * mult; mult *= Kd[cc]
            if mult > 6_000_000: continue
            na = np.bincount(key[per == a], minlength=mult); nb = np.bincount(key[per == b_], minlength=mult)
            ok = (na >= 30) & (nb >= 30)
            if not ok.any(): continue
            tkey = key[trow]
            for dirn, w in ((1, up), (-1, dn)):
                ra = np.bincount(key[per == a], weights=w[per == a], minlength=mult) / np.maximum(na, 1)
                rb = np.bincount(key[per == b_], weights=w[per == b_], minlength=mult) / np.maximum(nb, 1)
                good = ok & (np.minimum(ra, rb) >= 0.56)
                if not good.any(): continue
                rate = np.where(good, (ra * na + rb * nb) / np.maximum(na + nb, 1), 0)
                hit = (tper == c) & (tdir == dirn)
                same[hit] = np.maximum(same[hit], rate[tkey[hit]])
        # losing patterns of the model's trades (trade-relative), found on periods a, b
        for combo in itertools.combinations(list(Ft.columns), order):
            key = np.zeros(len(Ft), dtype=np.int64); mult = 1
            for cc in combo: key += Ft[cc].values * mult; mult *= Kt[cc]
            if mult > 6_000_000: continue
            na = np.bincount(key[tper == a], minlength=mult); nb = np.bincount(key[tper == b_], minlength=mult)
            ra = np.bincount(key[tper == a], weights=twin[tper == a], minlength=mult) / np.maximum(na, 1)
            rb = np.bincount(key[tper == b_], weights=twin[tper == b_], minlength=mult) / np.maximum(nb, 1)
            bad = (na >= 25) & (nb >= 25) & (np.maximum(ra, rb) <= 0.45)
            if bad.any(): lose |= (tper == c) & bad[key]
    m = tper == c
    for wk in (True, False):
        mm = m & (T.weekday.values == wk)
        for lab, sel in (('全ENTRY', mm), ('同じ向きの勝ちパターンあり', mm & (same > 0)), ('  うち62%以上', mm & (same >= 62 / 100 * 100) if False else mm & (same >= 0.62)),
                         ('  うち60%以上', mm & (same >= 0.60)), ('勝ちパターンなし', mm & (same == 0)), ('負けパターンに該当', mm & lose), ('負けパターン非該当', mm & ~lose)):
            res.append(dict(rot=f'{a}{b_}->{c}', seg='平日' if wk else '土日', group=lab, n=int(sel.sum()), win=float(twin[sel].mean()) if sel.any() else np.nan))
R = pd.DataFrame(res)
S = R.groupby(['seg', 'group'], sort=False).apply(lambda g: pd.Series(dict(n=g.n.sum(), win=np.average(g.win.fillna(0), weights=g.n) if g.n.sum() else np.nan))).reset_index()
print(R.pivot_table(index=['seg', 'group'], columns='rot', values='win', sort=False).round(3).to_string())
print(S.round(3).to_string())
json.dump(S.to_dict('records'), open('../work/pattern_agree_rotation.json', 'w'), ensure_ascii=False, indent=1)

"""Chance benchmark: the same search on shuffled outcomes (within each period). How many '65%/70%' patterns appear by luck?"""
import numpy as np, pandas as pd, itertools, json
exec(open('pattern_mine.py').read().split("if __name" + "__")[0])
rng = np.random.default_rng(7)
def count_find(upv, dnv, find, nmin=40):
    c = {0.60: 0, 0.65: 0, 0.70: 0, 0.80: 0}
    m = per == find
    for order in range(1, 4):
        for combo in itertools.combinations(names, order):
            key = np.zeros(len(F), dtype=np.int64); mult = 1
            for cc in combo: key += F[cc].values * mult; mult *= K[cc]
            if mult > 5_000_000: continue
            n = np.bincount(key[m], minlength=mult); u = np.bincount(key[m], weights=upv[m], minlength=mult); w = np.bincount(key[m], weights=dnv[m], minlength=mult)
            ok = n >= nmin
            r = np.maximum(u[ok], w[ok]) / n[ok]
            for th in c: c[th] += int((r >= th).sum()) + int(((u[ok] / n[ok]) >= th).sum() if False else 0)
    return c
real = count_find(up, dn, 0)
res = {'real': real, 'shuffled': []}
for s in range(3):
    idx = np.arange(len(F)); 
    for p in range(3):
        m = np.flatnonzero(per == p); idx[m] = rng.permutation(m)
    res['shuffled'].append(count_find(up[idx], dn[idx], 0))
print(json.dumps(res, indent=1))
json.dump(res, open('../work/pattern_chance.json', 'w'), indent=1)

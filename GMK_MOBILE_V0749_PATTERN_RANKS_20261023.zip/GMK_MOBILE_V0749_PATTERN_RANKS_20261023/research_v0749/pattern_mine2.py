"""Extended search (v0.7.49): winning patterns (every period >= 56%), both-direction losers, losers of the app's chosen trades.
Periods: 1 = 2025-10..2026-01, 2 = 2026-02..05, 3 = 2026-06..10. A draw is a loss."""
import itertools, json, pickle, sys, numpy as np, pandas as pd
from pattern_codes import *
from pattern_robust_labels import label, LAB
X = pd.read_pickle('../work/pattern_frame.pkl'); X = X[X.body_r.notna()].copy()
d = pd.to_datetime(X.date); X['period'] = np.where(d < '2026-02-01', 0, np.where(d < '2026-06-01', 1, 2))
VOL_CUTS = {s: [float(v) for v in np.quantile(X[X.inst == s].rv60, [0.2, 0.4, 0.6, 0.8])] for s in INST}
F = codes(X, VOL_CUTS)
names = list(F.columns); K = {c: int(F[c].max()) + 1 for c in names}
per = X.period.values; up = (X.move3.values == 1).astype(float); dn = (X.move3.values == -1).astype(float)
ndays = X.date.nunique()
def scan(Fm, perv, wins_list, select, nmin=30, max_order=3, joint=None):
    """wins_list: list of (label, win-indicator array). select(rates[3], n[3]) -> bool mask. Yields matches."""
    out = []
    cols = list(Fm.columns); Kd = {c: int(Fm[c].max()) + 1 for c in cols}
    for order in range(1, max_order + 1):
        for combo in itertools.combinations(cols, order):
            key = np.zeros(len(Fm), dtype=np.int64); mult = 1
            for c in combo: key += Fm[c].values * mult; mult *= Kd[c]
            if mult > 6_000_000: continue
            n = [np.bincount(key[perv == p], minlength=mult) for p in range(3)]
            ok = (n[0] >= nmin) & (n[1] >= nmin) & (n[2] >= nmin)
            if not ok.any(): continue
            idx = np.flatnonzero(ok)
            if joint:
                R = np.array([[np.bincount(key[perv == p], weights=w[perv == p], minlength=mult)[idx] / n[p][idx] for p in range(3)] for _, w in wins_list])
                for j in np.flatnonzero(joint(R)):
                    k = idx[j]; lv = []; kk = k
                    for c in combo: lv.append(int(kk % Kd[c])); kk //= Kd[c]
                    out.append(dict(combo=list(combo), levels=lv, side='どちらでも', n=[int(n[p][k]) for p in range(3)], rates=[float(x) for x in R[:, :, j].max(0)]))
                continue
            for lab, w in wins_list:
                r = np.array([np.bincount(key[perv == p], weights=w[perv == p], minlength=mult)[idx] / n[p][idx] for p in range(3)])
                sel = select(r)
                for j in np.flatnonzero(sel):
                    k = idx[j]; lv = []; kk = k
                    for c in combo: lv.append(int(kk % Kd[c])); kk //= Kd[c]
                    nn = [int(n[p][k]) for p in range(3)]
                    out.append(dict(combo=list(combo), levels=lv, side=lab, n=nn, rates=[float(x) for x in r[:, j]]))
    return out
def describe(rows, kind):
    recs = []
    if not rows: return pd.DataFrame(columns=['一番低い期間' if kind == 'win' else '一番高い期間', '件数'])
    for m in rows:
        n = sum(m['n']); w = sum(r * k for r, k in zip(m['rates'], m['n'])) / n
        s = sum(move_sign(c, l) for c, l in zip(m['combo'], m['levels']))
        dirn = 1 if m['side'] == 'HIGH' else -1 if m['side'] == 'LOW' else 0
        if kind == 'win':
            theme = '時間帯・通貨・値動きの条件' if s == 0 else ('逆張り：売られすぎの戻り' if s < 0 and dirn == 1 else '逆張り：買われすぎの戻り' if s > 0 and dirn == -1 else '順張り：上げの勢いに乗る' if dirn == 1 else '順張り：下げの勢いに乗る')
        else:
            theme = ''
        recs.append({'形': ' & '.join(label(c, l) for c, l in zip(m['combo'], m['levels'])), '向き': m['side'], '種類': theme, '条件の数': len(m['combo']),
                     '件数': n, '1日あたり': round(n / ndays, 2), '1年の勝率': round(w * 100, 1),
                     '期間1': round(m['rates'][0] * 100, 1), '期間2': round(m['rates'][1] * 100, 1), '期間3': round(m['rates'][2] * 100, 1),
                     '一番低い期間' if kind == 'win' else '一番高い期間': round((min if kind == 'win' else max)(m['rates']) * 100, 1),
                     'combo': '|'.join(m['combo']), 'levels': '|'.join(map(str, m['levels']))})
    return pd.DataFrame(recs)
if __name__ == "__main__" and True:
    res = {}
    # (1) winning patterns, absolute conditions, both directions
    W = scan(F, per, [('HIGH', up), ('LOW', dn)], lambda r: r.min(0) >= 0.56)
    Wd = describe(W, 'win').sort_values(['一番低い期間', '件数'], ascending=False); Wd.to_pickle('../work/win_patterns.pkl')
    print('勝ちパターン（3期間すべて56%以上・各30件以上）:', len(Wd)); print(Wd.groupby('種類').size().to_dict())
    # (2) both directions lose
    B = scan(F, per, [('HIGH', up), ('LOW', dn)], None, joint=lambda R: R.max(axis=(0, 1)) <= 0.45)
    Bd = describe(B, 'lose').sort_values(['一番高い期間', '件数'], ascending=[True, False]); Bd.to_pickle('../work/both_lose_patterns.pkl')
    print('どちらに入っても負ける形（3期間すべて45%以下）:', len(Bd))
    # (3) the app's chosen trades (v0.7.48 ENTRY, other-half model), trade-relative conditions
    T = pickle.load(open('../work/design_x_fresh.pkl', 'rb'))
    T = T[T.grade.isin(list('SABC'))][['b', 'inst', 'dir', 'win', 'grade']]
    key = X.reset_index()[['index', 'b', 'inst']].rename(columns={'index': 'row'})
    T = T.merge(key, on=['b', 'inst'])
    Ft = flip(F.loc[T.row.values].reset_index(drop=True), T.dir.values)
    Ft['dir'] = (T.dir.values == 1).astype(int) + 1        # allow 'HIGH trades only' conditions
    pt = X.loc[T.row.values].period.values; wt = T.win.values.astype(float)
    C = scan(Ft, pt, [('アプリの取引', wt)], lambda r: r.max(0) <= 0.45, nmin=25)
    Cd = describe(C, 'lose').sort_values(['一番高い期間', '件数'], ascending=[True, False]); Cd.to_pickle('../work/chosen_lose_patterns.pkl')
    print('アプリの取引が負けている形（3期間すべて45%以下・各25件以上）:', len(Cd), ' 対象の取引', len(T))
    # chance benchmarks (one shuffle each)
    rng = np.random.default_rng(5)
    idx = np.arange(len(F))
    for p in range(3):
        m = np.flatnonzero(per == p); idx[m] = rng.permutation(m)
    Wc = scan(F, per, [('HIGH', up[idx]), ('LOW', dn[idx])], lambda r: r.min(0) >= 0.56)
    Bc = scan(F, per, [('HIGH', up[idx]), ('LOW', dn[idx])], None, joint=lambda R: R.max(axis=(0, 1)) <= 0.45)
    it = np.arange(len(T))
    for p in range(3):
        m = np.flatnonzero(pt == p); it[m] = rng.permutation(m)
    Cc = scan(Ft, pt, [('アプリの取引', wt[it])], lambda r: r.max(0) <= 0.45, nmin=25)
    res = dict(win=len(Wd), win_chance=len(Wc), both=len(Bd), both_chance=len(Bc), chosen=len(Cd), chosen_chance=len(Cc), trades=len(T), vol_cuts=VOL_CUTS)
    print(json.dumps(res, ensure_ascii=False)); json.dump(res, open('../work/pattern_mine2.json', 'w'), ensure_ascii=False, indent=1)

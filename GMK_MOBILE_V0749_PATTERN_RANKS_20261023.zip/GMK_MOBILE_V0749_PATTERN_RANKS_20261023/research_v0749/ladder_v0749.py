"""v0.7.49 ladder on the year (pattern parts are in-sample by the user's decision):
reversal pattern on the chosen trade -> trade the opposite side; else same-direction win pattern -> S/A/B by the pattern's
one-year rate; else v0.7.48 ENTRY -> C; v0.7.48 skips keep D..H."""
import pickle, json, numpy as np, pandas as pd
from pattern_codes import *
import pattern_mine2 as pm
X = pm.X; F = pm.F
T = pd.read_pickle('../work/reversal_trades.pkl')
W = pd.read_pickle('../work/win_patterns.pkl'); RV = pd.read_pickle('../work/reversal_patterns.pkl')
pos = pd.Series(np.arange(len(X)), index=X.index); trow = pos.loc[T['index'].values].values
tdir = T.dir.values; ent = T.grade.isin(list('SABC')).values
Fa = F.iloc[trow].reset_index(drop=True)
Ft = flip(Fa, tdir); Ft['dir'] = (tdir == 1).astype(int) + 1; Ft['entry'] = ent.astype(int) + 1
def mask(df, combo, levels):
    m = np.ones(len(df), bool)
    for c, l in zip(combo.split('|'), levels.split('|')): m &= df[c].values == int(l)
    return m
def best_match(df, P, side_ok):
    rate = np.zeros(len(df)); mn = np.zeros(len(df)); pid = np.full(len(df), -1)
    for i, r in enumerate(P.itertuples()):
        m = mask(df, r.combo, r.levels) & side_ok(r)
        upd = m & ((r.一番低い期間 > mn) | ((r.一番低い期間 == mn) & (r._7 > rate)))
        rate[upd] = r._7; mn[upd] = r.一番低い期間; pid[upd] = i
    return rate, mn, pid
wr, wm, wid = best_match(Fa, W, lambda r: (tdir == (1 if r.向き == 'HIGH' else -1)))
rr, rm, rid = best_match(Ft, RV, lambda r: np.ones(len(Ft), bool))
use_rev = (rid >= 0) & ((wid < 0) | (rm > wm))
use_win = (wid >= 0) & ~use_rev
def band(rate): return np.where(rate >= 65, 'S', np.where(rate >= 62, 'A', 'B'))
grade = np.where(use_rev, band(rr), np.where(use_win, band(wr), np.where(ent, 'C', T.grade.values)))
final_dir = np.where(use_rev, -tdir, tdir)
won = (T.move3.values == final_dir).astype(int)
T = T.assign(g49=grade, dir49=final_dir, win49=won, kind=np.where(use_rev, '反転', np.where(use_win, '勝ちパターン', np.where(ent, 'モデル', '見送り'))),
             prate=np.where(use_rev, rr, np.where(use_win, wr, np.nan)), pid=np.where(use_rev, rid, np.where(use_win, wid, -1)))
T.to_pickle('../work/ladder_v0749.pkl')
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
res = {}
for wk in (True, False):
    x = T[T.weekday == wk].sort_values('b'); nd = x.date.nunique(); e = x[x.g49.isin(list('SABC'))]
    seg = '平日' if wk else '土日'
    head = dict(entry=round(len(e) / len(x) * 100, 1), win=round(e.win49.mean() * 100, 1), old_entry=round(x.grade.isin(list('SABC')).mean() * 100, 1),
                old_win=round(x[x.grade.isin(list('SABC'))].win.mean() * 100, 1), maxs=ms(e.win49.values), per_day=round(len(e) / nd, 1))
    print(f'=== {seg}: ' + ' '.join(f'{k}={v}' for k, v in head.items()))
    ranks = {}
    for g in 'SABCDEFGH':
        s = x[x.g49 == g]
        if not len(s): continue
        ranks[g] = dict(share=round(len(s) / len(x) * 100, 1), per_day=round(len(s) / nd, 1), win=round(s.win49.mean() * 100, 1),
                        H1=round(s[s.half == 'H1'].win49.mean() * 100, 1), H2=round(s[s.half == 'H2'].win49.mean() * 100, 1), maxs=ms(s.win49.values),
                        rev_share=round((s.kind == '反転').mean() * 100, 1))
        print(f'  {g} ' + ' '.join(f'{k}={v}' for k, v in ranks[g].items()))
    kinds = x.groupby('kind').agg(n=('win49', 'size'), win=('win49', 'mean')).assign(per_day=lambda d: d.n / nd)
    print(kinds.round(3).to_string())
    res[seg] = dict(head=head, ranks=ranks, kinds={k: dict(n=int(v.n), win=round(v.win * 100, 1), per_day=round(v.per_day, 1)) for k, v in kinds.iterrows()})
json.dump(res, open('../work/ladder_v0749.json', 'w'), ensure_ascii=False, indent=1)

"""Honest estimate: choose patterns that held in TWO periods (each >= th, >= 30 trades), score them on the third, all rotations."""
import numpy as np, itertools, json
exec(open('pattern_mine.py').read().split("if __name" + "__")[0])
rows = []
for order in range(1, 4):
    for combo in itertools.combinations(names, order):
        key = np.zeros(len(F), dtype=np.int64); mult = 1
        for cc in combo: key += F[cc].values * mult; mult *= K[cc]
        if mult > 5_000_000: continue
        st = [(np.bincount(key[per == p], minlength=mult), np.bincount(key[per == p], weights=up[per == p], minlength=mult),
               np.bincount(key[per == p], weights=dn[per == p], minlength=mult)) for p in range(3)]
        for a, b, c in ((0, 1, 2), (0, 2, 1), (1, 2, 0)):
            ok = (st[a][0] >= 30) & (st[b][0] >= 30) & (st[c][0] >= 10)
            for j in (1, 2):
                ra = np.where(ok, st[a][j] / np.maximum(st[a][0], 1), 0); rb = np.where(ok, st[b][j] / np.maximum(st[b][0], 1), 0)
                sel = np.flatnonzero(ok & (np.minimum(ra, rb) >= 0.55))
                for k in sel:
                    rows.append((a, b, c, min(ra[k], rb[k]), st[c][j][k] / st[c][0][k], st[c][0][k]))
import pandas as pd
R = pd.DataFrame(rows, columns=['a', 'b', 'c', 'min_ab', 'score', 'n_score'])
R['band'] = pd.cut(R.min_ab, [0.55, 0.58, 0.60, 0.62, 0.65, 0.70, 1.01], right=False)
t = R.groupby('band', observed=True).agg(patterns=('score', 'size'), held_twice=('min_ab', 'mean'), third_period=('score', 'mean'),
                                          third_weighted=('score', lambda s: np.average(s, weights=R.loc[s.index, 'n_score'])), third_ge60=('score', lambda s: (s >= 0.6).mean()))
print(t.round(3).to_string())
json.dump({str(k): v for k, v in t.round(4).to_dict('index').items()}, open('../work/pattern_rotation.json', 'w'), ensure_ascii=False, indent=1)

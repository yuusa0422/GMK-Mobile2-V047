"""v0.7.49 pattern ranks: source gate layered on the unchanged v0.7.48 audit.

Every v0.7.48 check is re-run. Rows that fail only because a v0.7.49-modified file changed are re-pinned to the
v0.7.49 bytes. Stage-1 models and the v0.7.48 strength ladder are unchanged; the pattern overlay is pinned below.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
POLICY = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt'
PATTERNS = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePatterns.kt'
PDATA = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePatternData.kt'
TEST = 'app/src/test/java/EvidencePolicyTest.kt'
PTEST = 'app/src/test/java/PatternParityTest.kt'
GRADLE = 'app/build.gradle.kts'


def audit():
    spec = importlib.util.spec_from_file_location('v0748_audit', ROOT/'tools/audit_v0748.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0749_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text(); patterns = (ROOT/PATTERNS).read_text(); pdata = (ROOT/PDATA).read_text()
    test = (ROOT/TEST).read_text(); ptest = (ROOT/PTEST).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0749_pattern_ranks:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.48 source bytes plus the pinned v0.7.49 change only.')
        elif name == 'evidence_model_frozen_parameters_v0748':
            row.update(check='evidence_model_frozen_parameters_v0749', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0749_PATTERN_RANKS"', 'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER',
                'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER', 'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576',
                'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
                'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]'))},
                detail='v0.7.49: v0.7.48 strength ENTRY rule unchanged; the pattern overlay only upgrades/reverses the chosen trade.')
        elif name == 'gradle_only_version_changed_v0748':
            row.update(check='gradle_only_version_changed_v0749', **{'pass': sha_text(gradle.replace('versionCode = 119', 'versionCode = 118')
                       .replace('versionName = "0.7.49-pattern-ranks"', 'versionName = "0.7.48-rank-ladder"')) == changed[GRADLE]['v0748_sha256']})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*119\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.49-pattern-ranks"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    known = {}
    for v in ('0744', '0745', '0746', '0747', '0748'):
        m = json.loads((ROOT/f'tools/v{v}_source_extension.json').read_text())
        known |= {p: x['updated_sha256'] for p, x in m['modified_existing'].items()} | m.get('new_source_files', {})
    for path, item in changed.items():
        check('v0748_original_before_v0749:' + path, known.get(path) == item['v0748_sha256'])
        check('pinned_v0749_change:' + path, sha(ROOT/path) == item['updated_sha256'])
    for path, digest in new.items():
        check('pinned_v0749_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('v0749_pattern_overlay', all(s in policy for s in (
        'val pm = if (choice.fresh) choice.patternCodes?.let { EvidencePatterns.decide(it, dirInt, decision.enter) } else null',
        'val grade = when { pm != null -> EvidencePatterns.grade(pm.pattern.rate); decision.enter -> "C"; else -> decision.grade }',
        'val finalDirection = if (reversed) (if (choice.direction == "HIGH") "LOW" else "HIGH") else choice.direction')))
    check('v0749_grade_bands', 'fun grade(rate: Double): String = if (rate >= 65.0) "S" else if (rate >= 62.0) "A" else "B"' in patterns
          and 'r != null && (w == null || r.minRate > w.minRate) -> Match(r, true)' in patterns)
    check('v0749_pattern_counts', f'const val WIN_COUNT = {manifest["pattern_counts"]["win"]}' in pdata and f'const val REVERSAL_COUNT = {manifest["pattern_counts"]["reversal"]}' in pdata)
    check('v0749_tests_present', 'fun patternOverlayRanksAndReversesOnRealSlots()' in test and all(f'fun {n}()' in ptest for n in (
        'codesFromRealCandlesMatchPython', 'flipAndBestMatchMatchPython', 'tablesLoadAndGradesFollowTheRate')))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0749_PATTERN_RANKS_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.49-pattern-ranks')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

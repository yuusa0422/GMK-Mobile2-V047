"""v0.7.48 rank ladder: source gate layered on the unchanged v0.7.47 audit.

Every v0.7.47 check is re-run. Rows that fail only because a v0.7.48-modified file changed are re-pinned to the
v0.7.48 bytes; the v0.7.47 S-tier rows are superseded by the strength-ladder rows below. Stage-1 models are unchanged.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
POLICY = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt'
ASSESS = 'app/src/main/java/jp/gmk/mobile/domain/CandidateAssessment.kt'
STRENGTH = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceStrength.kt'
SDATA = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceStrengthData.kt'
TEST = 'app/src/test/java/EvidencePolicyTest.kt'
PTEST = 'app/src/test/java/EvidenceStrengthParityTest.kt'
GRADLE = 'app/build.gradle.kts'
ASSESS_V0748 = '    LOW_EXPECTANCY("検証モデルの強さが低い枠のため見送り（D〜H・理由は判定の説明・観察のみ）"),\n'
ASSESS_V0745 = '    LOW_EXPECTANCY("検証モデルで期待値が低い枠（平日は下位26%・土日は下位53%）のため見送り（観察のみ）"),\n'
SUPERSEDED = {'v0747_s_grade_rule', 'v0747_s_validated_rates', 'v0747_s_tier_test_present'}


def audit():
    spec = importlib.util.spec_from_file_location('v0747_audit', ROOT/'tools/audit_v0747.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0748_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text(); assess = (ROOT/ASSESS).read_text()
    strength = (ROOT/STRENGTH).read_text(); sdata = (ROOT/SDATA).read_text(); test = (ROOT/TEST).read_text(); ptest = (ROOT/PTEST).read_text()
    kept = []
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if name in SUPERSEDED:
            continue
        if path is not None and not row['pass']:
            row.update(check='authorized_v0748_rank_ladder:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.47 source bytes plus the pinned v0.7.48 change only.')
        elif name == 'evidence_model_frozen_parameters_v0747':
            row.update(check='evidence_model_frozen_parameters_v0748', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0748_EVIDENCE_RANK_LADDER"', 'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER',
                'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER', 'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576',
                'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
                'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]'))
                and 'const val WEEKDAY_COVER = 0.85' in sdata and 'const val WEEKEND_COVER = 0.55' in sdata},
                detail='v0.7.48: weekday ENTER top 85% of the rolling 288 strengths; weekend ENTER when strength >= fixed cut (about 55%).')
        elif name == 'assessment_only_low_expectancy_label_changed':
            row.update(check='assessment_only_low_expectancy_label_changed_v0748', **{'pass': ASSESS_V0748 in assess
                       and sha_text(assess.replace(ASSESS_V0748, ASSESS_V0745)) == json.loads((ROOT/'tools/v0745_source_extension.json').read_text())['modified_existing'][ASSESS]['updated_sha256']})
        elif name == 'gradle_only_version_changed_v0747':
            row.update(check='gradle_only_version_changed_v0748', **{'pass': sha_text(gradle.replace('versionCode = 118', 'versionCode = 117')
                       .replace('versionName = "0.7.48-rank-ladder"', 'versionName = "0.7.47-s-tier"')) == changed[GRADLE]['v0747_sha256']})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*118\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.48-rank-ladder"' in gradle
        kept.append(row)
    result['results'] = kept

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v0747 = json.loads((ROOT/'tools/v0747_source_extension.json').read_text())
    v0746 = json.loads((ROOT/'tools/v0746_source_extension.json').read_text())
    v0745 = json.loads((ROOT/'tools/v0745_source_extension.json').read_text())
    v0744 = json.loads((ROOT/'tools/v0744_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v0744['modified_existing'].items()} | v0744['new_source_files'] \
        | {p: x['updated_sha256'] for m in (v0745, v0746, v0747) for p, x in m['modified_existing'].items()}
    for path, item in changed.items():
        check('v0747_original_before_v0748:' + path, known.get(path) == item['v0747_sha256'])
        check('pinned_v0748_change:' + path, sha(ROOT/path) == item['updated_sha256'])
    for path, digest in new.items():
        check('pinned_v0748_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('v0748_strength_ladder_grades', all(s in policy for s in (
        'grade = if (enter) (if (r >= c[0]) "S" else if (r >= c[1]) "A" else if (r >= c[2]) "B" else "C") else if (upperSkip) "D" else "E"',
        'else if (e >= c[4]) "D" else if (e >= c[5]) "E" else if (e >= c[6]) "F" else if (e >= c[7]) "G" else "H"',
        'val updated = top.copy(grade = "I", decision = "SKIP"')))
    check('v0748_every_skip_has_reason', 'EvidenceStrength.REASON_SKIP' in policy and '理由: ${decision.reason}' in policy
          and all(k in strength for k in ('"edge" to', '"move" to', '"quiet" to', '"tie" to', '"time" to')))
    check('v0748_strength_inputs_exact', all(s in strength for s in ('"lrv" -> ln(x.rv60).coerceIn(-2.5, 3.5)', '"hinge" -> max(x.pct - 0.9, 0.0) * 10.0',
          '"fx_fade_big" -> if (!btc && x.f1 * d < 0.0 && af1 >= 2.5) 1.0 else 0.0', '"flat" -> if (af1 < 0.01) 1.0 else 0.0')))
    check('v0748_validated_rates_present', 'FRESH_WEEKDAY_VALIDATED = mapOf("S" to 0.548' in sdata and 'FRESH_WEEKEND_VALIDATED = mapOf("S" to 0.54' in sdata)
    check('v0748_tests_present', all(f'fun {n}()' in test for n in ('weekdayEntersTheStrongest85PercentAndSplitsSkipsIntoDE', 'weekdayRanksAreOrderedByStrength',
          'weekendLadderFollowsStrengthAndExplainsDrawRisk', 'weekendWindowShiftsEntriesFromQuietToActiveDays', 'seedPercentileAndShareBelow'))
          and 'fun probabilitiesAndReasonsMatchPython()' in ptest)
    check('v0748_stage1_models_unchanged', all(f'"{h}"' in (ROOT/'app/src/main/java/jp/gmk/mobile/domain/EvidenceModelData.kt').read_text()
          for h in v0746['model_text_sha256']['fresh'] + v0746['model_text_sha256']['fallback']))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0748_RANK_LADDER_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.48-rank-ladder')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

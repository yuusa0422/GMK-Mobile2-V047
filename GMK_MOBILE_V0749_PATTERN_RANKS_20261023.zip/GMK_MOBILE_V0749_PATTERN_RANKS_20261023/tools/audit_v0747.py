"""v0.7.47 S tier: source gate layered on the unchanged v0.7.46 audit.

Every v0.7.46 check is re-run. Rows that fail only because a v0.7.47-modified file changed are re-pinned to the
v0.7.47 bytes; the version/parameter rows are re-checked with the new values. Models are unchanged.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
POLICY = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt'
DATA = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceModelData.kt'
TEST = 'app/src/test/java/EvidencePolicyTest.kt'
GRADLE = 'app/build.gradle.kts'


def audit():
    spec = importlib.util.spec_from_file_location('v0746_audit', ROOT/'tools/audit_v0746.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0747_source_extension.json').read_text())
    changed = manifest['modified_existing']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text(); data = (ROOT/DATA).read_text(); test = (ROOT/TEST).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0747_s_tier:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.46 source bytes plus the pinned v0.7.47 change only.')
        elif name == 'evidence_model_frozen_parameters_v0746':
            row.update(check='evidence_model_frozen_parameters_v0747', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0747_EVIDENCE_S_TIER"', 'const val WEEKDAY_ENTRY_RATE = 0.74', 'const val WEEKEND_ENTRY_RATE = 0.47',
                'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96',
                'const val LIVE_MAX_AGE_MS = 40_000L', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
                'val enter = choice.adjusted >= thr'))},
                detail='v0.7.47: entry rule, quotas and models unchanged; only the grade label of the strongest 10% changes to S.')
        elif name == 'gradle_only_version_changed_v0746':
            row.update(check='gradle_only_version_changed_v0747', **{'pass': sha_text(gradle.replace('versionCode = 117', 'versionCode = 116')
                       .replace('versionName = "0.7.47-s-tier"', 'versionName = "0.7.46-ensemble"')) == changed[GRADLE]['v0746_sha256']})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*117\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.47-s-tier"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v0744 = json.loads((ROOT/'tools/v0744_source_extension.json').read_text())
    v0745 = json.loads((ROOT/'tools/v0745_source_extension.json').read_text())
    v0746 = json.loads((ROOT/'tools/v0746_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v0744['modified_existing'].items()} | v0744['new_source_files'] \
        | {p: x['updated_sha256'] for p, x in v0745['modified_existing'].items()} | {p: x['updated_sha256'] for p, x in v0746['modified_existing'].items()}
    for path, item in changed.items():
        check('v0746_original_before_v0747:' + path, known.get(path) == item['v0746_sha256'])
        check('pinned_v0747_change:' + path, sha(ROOT/path) == item['updated_sha256'])
    data_v0746 = data
    for k in ('FRESH_WEEKDAY', 'FRESH_WEEKEND', 'FALLBACK_WEEKDAY', 'FALLBACK_WEEKEND'):
        data_v0746 = re.sub(rf'\n    const val {k}_SEED_Q90 = [-0-9.eE]+', '', data_v0746)
    data_v0746 = data_v0746.replace('v0.7.46 production ensembles (v0.7.47 adds the S-tier seed quantile)', 'v0.7.46 production ensembles')
    check('v0747_model_data_only_adds_q90_seeds', sha_text(data_v0746) == changed[DATA]['v0746_sha256'])
    check('v0747_q90_seeds_present', all(f'const val {k}_SEED_Q90 = {v!r}' in data for k, v in manifest['seed_q90'].items()))
    check('v0747_s_grade_rule', 'val grade = if (!enter) "E" else if (a >= q90) "S" else if (a >= q75) "A" else if (a >= q50) "B" else "C"' in policy
          and 'quantile(v, 0.90)' in policy)
    check('v0747_s_validated_rates', '"S" -> 0.540' in policy and '"S" -> 0.528' in policy and '"S" -> 0.527' in policy and '"S" -> 0.514' in policy)
    check('v0747_s_tier_test_present', 'fun sTierIsTheTopTenPercentAndNeverChangesEntries()' in test
          and 'assertEquals(0.10, grades.getValue("S").toDouble() / counted, 0.03)' in test)
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0747_S_TIER_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.47-s-tier')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""Option C: strength E from absolute inputs (hour-adjusted p, last-minute move, relative volatility, tie risk);
one rolling window on E decides ENTRY (same quota) and S–H ranks."""
import pickle, numpy as np, pandas as pd, sys
from sklearn.linear_model import LogisticRegression
D = pickle.load(open('../work/strength_slots.pkl', 'rb'))
RATE = {True: 0.74, False: 0.47}; NBUF = {True: 288, False: 576}; NMIN = 96
CUTS = {True: [('S', .90), ('A', .75), ('B', .50), ('C', .26), ('D', .21), ('E', .16), ('F', .11), ('G', .06), ('H', 0.0)],
        False: [('S', .90), ('A', .80), ('B', .67), ('C', .53), ('D', .43), ('E', .33), ('F', .22), ('G', .11), ('H', 0.0)]}
GR = list('SABCDEFGH')
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def prep(A):
    """constants learned on the training half"""
    return dict(k90=float(A.adj.quantile(0.9)), lrv_h=A.groupby('hour').lrv.median().to_dict())
def feats(x, cols, k):
    fx = x.inst != 'BTCJPY'
    lrvh = (x.lrv - x.hour.map(k['lrv_h'])).clip(-2, 2)
    c = dict(adj=x.adj, hinge=np.maximum(x.adj - k['k90'], 0), af1=x.abs_f1.clip(0, 4), ar1=x.abs_r1.clip(0, 4), lrvh=lrvh,
             fx_fade_big=(fx & (x.s_f1 < 0) & (x.abs_f1 >= 2.5)) * 1.0, btc_follow=((~fx) & (x.s_f1 > 0) & (x.abs_f1 >= 0.5) & (x.abs_f1 < 3)) * 1.0,
             flat=(x.abs_f1 < 0.01) * 1.0, tie58=x.tie58, zero30=x.zero30)
    return np.column_stack([np.asarray(c[n], float) for n in cols])
def simulate(fresh, cols_wd, cols_we, C=1.0, scale=True):
    S = D[fresh]; out = []
    for wk in (True, False):
        cols = cols_wd if wk else cols_we
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = S[(S.weekday == wk) & (S.half == tr)].copy(); B = S[(S.weekday == wk) & (S.half == te)].copy()
            k = prep(A); XA = feats(A, cols, k); XB = feats(B, cols, k)
            mu, sd = XA.mean(0), XA.std(0) + 1e-12
            m = LogisticRegression(C=C, max_iter=5000).fit((XA - mu) / sd, A.win)
            A['E'] = m.predict_proba((XA - mu) / sd)[:, 1]; B['E'] = m.predict_proba((XB - mu) / sd)[:, 1]
            seed = np.sort(A.E.values); buf = []; grade = []
            for a in B.E.values:
                ref = np.array(buf) if len(buf) >= NMIN else seed
                q = (ref < a).mean(); grade.append(next(g for g, c in CUTS[wk] if q >= c))
                buf.append(a); buf = buf[-NBUF[wk]:]
            B['grade'] = grade; B['enter2'] = B.grade.isin(list('SABC'))
            B['coef'] = [dict(zip(cols, np.round(m.coef_[0], 4)))] * len(B); out.append(B)
    return pd.concat(out).sort_values('b')
def report(R, label, detail=True):
    res = {}
    for wk in (True, False):
        x = R[R.weekday == wk]; nd = x.date.nunique(); e = x[x.enter2]; ph = x.groupby('hour').enter2.mean()
        w = x.groupby('grade').win.mean().reindex(GR).dropna().values
        h1 = x[x.half == 'H1'].groupby('grade').win.mean().reindex(GR).dropna().values; h2 = x[x.half == 'H2'].groupby('grade').win.mean().reindex(GR).dropna().values
        inv = (sum(np.diff(w) > 0), sum(np.diff(h1) > 0), sum(np.diff(h2) > 0))
        print(f'=== {label} {"平日" if wk else "土日"}: ENTRY {x.enter2.mean()*100:4.1f}% (時間別 最小{ph.min()*100:4.1f}%) 勝率 {e.win.mean()*100:5.2f} '
              f'(H1 {e[e.half=="H1"].win.mean()*100:4.1f} H2 {e[e.half=="H2"].win.mean()*100:4.1f})  旧 {x[x.enter].win.mean()*100:5.2f}  見送り {x[~x.enter2].win.mean()*100:5.1f}  最大連敗 {ms(e.win.values)}  逆転 {inv}', flush=True)
        if detail:
            for g in GR:
                s = x[x.grade == g]
                if len(s): print(f'  {g} {len(s)/len(x)*100:4.1f}% {len(s)/nd:5.1f}/日 勝率 {s.win.mean()*100:5.1f} (前半 {s[s.half=="H1"].win.mean()*100:4.1f} / 後半 {s[s.half=="H2"].win.mean()*100:4.1f}) 引分 {s.tie.mean()*100:4.1f}')
        res[wk] = dict(entry=e.win.mean(), inv=inv)
    return res
if __name__ == '__main__':
    WD0 = ['adj']; WE0 = ['adj']
    report(simulate(True, WD0, WE0), 'adjのみ（＝現行に相当）', detail=False)
    WD = ['adj', 'hinge', 'af1', 'lrvh', 'fx_fade_big', 'btc_follow']; WE = ['adj', 'hinge', 'flat', 'tie58', 'zero30', 'af1', 'lrvh']
    R = report(simulate(True, WD, WE), 'C案 全部')
    for wd, we in ((['adj', 'hinge', 'af1'], ['adj', 'hinge', 'af1']), (['adj', 'hinge', 'af1', 'lrvh'], ['adj', 'hinge', 'lrvh']),
                   (['adj', 'hinge', 'fx_fade_big', 'btc_follow'], ['adj', 'hinge', 'flat']), (['adj', 'hinge', 'af1', 'lrvh', 'fx_fade_big', 'btc_follow'], ['adj', 'hinge', 'tie58', 'zero30'])):
        report(simulate(True, wd, we), f'{"+".join(wd)} / {"+".join(we)}', detail=False)

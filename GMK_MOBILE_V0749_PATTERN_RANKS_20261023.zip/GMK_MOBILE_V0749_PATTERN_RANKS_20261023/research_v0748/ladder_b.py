"""Option B: ENTRY and ranks both from the strength score E (hour-adjusted, rolling window). Quota unchanged."""
import pickle, numpy as np, pandas as pd, sys
from sklearn.linear_model import LogisticRegression
exec(open('rank_ladder.py').read().split("if __name" + "__")[0])
RATE = {True: 0.74, False: 0.47}; NBUF = {True: 288, False: 576}; NMIN = 96
# rank cut points as quantiles of the rolling window (share of all slots, from the top)
CUTS = {True: [('S', .90), ('A', .75), ('B', .50), ('C', .26), ('D', .21), ('E', .16), ('F', .11), ('G', .06), ('H', 0.0)],
        False: [('S', .90), ('A', .80), ('B', .67), ('C', .53), ('D', .43), ('E', .33), ('F', .22), ('G', .11), ('H', 0.0)]}
def simulate(fresh, spec_wd, spec_we, C=0.1, hour_adjust=True):
    S = D[fresh]; out = []
    for wk in (True, False):
        cols = spec_wd if wk else spec_we
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = S[(S.weekday == wk) & (S.half == tr)].copy(); B = S[(S.weekday == wk) & (S.half == te)].copy()
            m = LogisticRegression(C=C, max_iter=3000).fit(feats(A, cols), A.win)
            A['E'] = m.predict_proba(feats(A, cols))[:, 1]; B['E'] = m.predict_proba(feats(B, cols))[:, 1]
            off = A.groupby('hour').E.median() if hour_adjust else pd.Series(0.0, index=range(24))
            seed = np.sort((A.E - A.hour.map(off)).values)
            adj = (B.E - B.hour.map(off)).values; buf = []; grade = []
            for a in adj:
                ref = np.array(buf) if len(buf) >= NMIN else seed
                q = (ref < a).mean()
                grade.append(next(g for g, c in CUTS[wk] if q >= c))
                buf.append(a); buf = buf[-NBUF[wk]:]
            B['grade'] = grade; B['enter2'] = B.grade.isin(list('SABC')); B['coef'] = [dict(zip(cols, m.coef_[0]))] * len(B)
            out.append(B)
    return pd.concat(out).sort_values('b')
def report(R, label):
    for wk in (True, False):
        x = R[R.weekday == wk]; nd = x.date.nunique(); e = x[x.enter2]
        ph = x.groupby('hour').enter2.mean()
        print(f'=== {label} {"平日" if wk else "土日"}: ENTRY {x.enter2.mean()*100:4.1f}% (時間別 最小{ph.min()*100:4.1f}%) 勝率 {e.win.mean()*100:5.2f} '
              f'(H1 {e[e.half=="H1"].win.mean()*100:4.1f} H2 {e[e.half=="H2"].win.mean()*100:4.1f})  旧ENTRY {x[x.enter].win.mean()*100:5.2f}  見送り {x[~x.enter2].win.mean()*100:5.1f}  最大連敗 {ms(e.win.values)}')
        w = []
        for g in GR:
            s = x[x.grade == g]
            if not len(s): continue
            w.append(s.win.mean())
            print(f'  {g} {len(s)/len(x)*100:4.1f}% {len(s)/nd:5.1f}/日 勝率 {s.win.mean()*100:5.1f} (前半 {s[s.half=="H1"].win.mean()*100:4.1f} / 後半 {s[s.half=="H2"].win.mean()*100:4.1f}) 引分 {s.tie.mean()*100:4.1f}')
        h1 = x[x.half == 'H1'].groupby('grade').win.mean().reindex(GR).dropna().values; h2 = x[x.half == 'H2'].groupby('grade').win.mean().reindex(GR).dropna().values
        print(f'  逆転（下のランクの方が高い）: 全体 {sum(np.diff(w) > 0)} / 前半 {sum(np.diff(h1) > 0)} / 後半 {sum(np.diff(h2) > 0)}  (8か所中)')
if __name__ == '__main__':
    WD = ['pct', 'hinge', 'af1', 'lrv', 'fx_fade_big', 'btc_follow']; WE = ['pct', 'hinge', 'flat', 'tie58', 'zero30', 'af1', 'lrv']
    R = simulate(True, WD, WE); report(R, '直前価格あり'); pickle.dump(R, open('../work/ladder_b_fresh.pkl', 'wb'))
    print(R[R.weekday].coef.iloc[0]); print(R[~R.weekday].coef.iloc[0])
    WDf = ['pct', 'hinge', 'ar1', 'lrv']; WEf = ['pct', 'hinge', 'tie58', 'zero30', 'ar1', 'lrv']
    R = simulate(False, WDf, WEf); report(R, '予備'); pickle.dump(R, open('../work/ladder_b_fallback.pkl', 'wb'))

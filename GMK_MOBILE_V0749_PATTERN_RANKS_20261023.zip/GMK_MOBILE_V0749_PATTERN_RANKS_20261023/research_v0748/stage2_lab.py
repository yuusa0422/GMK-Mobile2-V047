"""Second-stage 'expected win' for the chosen trade. Train on one half's slots, score the other half."""
import pandas as pd, numpy as np, sys
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
S = pd.read_pickle('../work/slots_oos.pkl')
S['abs_f1'] = S.f1.abs(); S['abs_f2'] = S.f2.abs(); S['abs_f5'] = S.f5.abs(); S['lrv'] = np.log(S.rv60)
INST = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']
def feats(x, kind):
    cols = {'p': x.p, 'gap': x.p_gap_opp, 'margin': x.margin, 'bp': x.bp, 'abs_f1': x.abs_f1.clip(0, 6), 's_f1': x.s_f1.clip(-6, 6),
            's_f5': x.s_f5.clip(-6, 6), 's_r15': x.s_r15.clip(-5, 5), 'lrv': x.lrv, 'rv30_60': x.rv30_60, 'tie58': x.tie58, 'zero30': x.zero30,
            'vol10': x.vol10, 'hour': x.hour, 'dow': x.dow, 'dir': x.dir, 'regconf': x.regconf, 's_bbzL': x.s_bbzL.clip(-5, 5), 's_pos15L': x.s_pos15L}
    for s in INST: cols['is_' + s] = (x.inst == s).astype(float)
    if kind == 'small':
        keep = ['p', 'gap', 'abs_f1', 'lrv', 'hour', 'tie58', 'bp'] + ['is_' + s for s in INST]
        cols = {k: cols[k] for k in keep}
    return pd.DataFrame(cols).values.astype(float)
def stage2(kind, wk, cfg):
    out = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        A = S[(S.weekday == wk) & (S.half == tr)]; B = S[(S.weekday == wk) & (S.half == te)].copy()
        if kind == 'p':
            B['e'] = B.p
        else:
            m = HistGradientBoostingClassifier(**cfg).fit(feats(A, kind), A.win)
            B['e'] = m.predict_proba(feats(B, kind))[:, 1]
        out.append(B)
    return pd.concat(out)
def report(R, label):
    R = R.copy(); R['dec'] = R.groupby('half').e.transform(lambda v: pd.qcut(v.rank(method='first'), 10, labels=False))
    t = R.groupby(['dec', 'half']).win.mean().unstack() * 100
    top = R[R.dec == 9]; bot = R[R.dec == 0]
    mono = sum(np.diff(R.groupby('dec').win.mean().values) > 0)
    print(f'{label:34s} top10% {top.win.mean()*100:5.1f} (H1 {t.loc[9,"H1"]:4.1f} H2 {t.loc[9,"H2"]:4.1f}) bottom10% {bot.win.mean()*100:5.1f} (H1 {t.loc[0,"H1"]:4.1f} H2 {t.loc[0,"H2"]:4.1f})  '
          f'deciles: ' + ' '.join(f'{v:4.1f}' for v in R.groupby('dec').win.mean().values * 100) + f'  up-steps {mono}/9', flush=True)
    return R
if __name__ == '__main__':
    for wk in (True, False):
        print('==== 平日' if wk else '==== 土日')
        report(stage2('p', wk, None), 'stage1 p only')
        for kind in ('small', 'full'):
            for cfg in (dict(max_iter=100, learning_rate=0.05, max_depth=2, min_samples_leaf=800, l2_regularization=1.0),
                        dict(max_iter=200, learning_rate=0.03, max_depth=3, min_samples_leaf=500, l2_regularization=1.0),
                        dict(max_iter=300, learning_rate=0.03, max_leaf_nodes=7, min_samples_leaf=300, l2_regularization=2.0)):
                report(stage2(kind, wk, cfg), f'{kind} it{cfg["max_iter"]} msl{cfg["min_samples_leaf"]}')

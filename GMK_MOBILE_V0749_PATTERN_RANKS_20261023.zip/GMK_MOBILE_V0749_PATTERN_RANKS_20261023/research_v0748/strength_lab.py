"""Second-stage strength (expected win) by logistic regression on a few robust inputs; train on one half, test on the other."""
import pickle, numpy as np, pandas as pd, sys
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
D = pickle.load(open('../work/strength_slots.pkl', 'rb'))
def X(x, spec):
    c = {}
    if 'pct' in spec: c['pct'] = x.pct; c['hinge90'] = np.maximum(x.pct - 0.9, 0) * 10
    if 'f1' in spec: c['af1'] = x.abs_f1.clip(0, 4)
    if 'r1' in spec: c['ar1'] = x.abs_r1.clip(0, 4)
    if 'vol' in spec: c['lrv'] = x.lrv.clip(x.lrv.quantile(.01), x.lrv.quantile(.99))
    if 'hour' in spec: c['h9'] = (x.hour == 9).astype(float); c['h10'] = (x.hour == 10).astype(float)
    if 'dow' in spec: c['mon'] = (x.dow == 0).astype(float)
    if 'flat' in spec: c['flat'] = (x.abs_f1 < 0.01).astype(float)
    if 'tie' in spec: c['tie58'] = x.tie58; c['zero30'] = x.zero30
    if 'gap' in spec: c['gap'] = x.gap
    if 'btc' in spec: c['btc'] = (x.inst == 'BTCJPY').astype(float)
    return pd.DataFrame(c).values
def fit_eval(S, wk, spec, C=1.0):
    res = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        A = S[(S.weekday == wk) & (S.half == tr)]; B = S[(S.weekday == wk) & (S.half == te)].copy()
        m = LogisticRegression(C=C, max_iter=2000).fit(X(A, spec), A.win)
        B['E'] = m.predict_proba(X(B, spec))[:, 1]; res.append(B)
    return pd.concat(res)
def summary(R, label):
    R = R.copy(); R['dec'] = R.groupby('half').E.transform(lambda v: pd.qcut(v.rank(method='first'), 10, labels=False))
    d = R.groupby('dec').win.mean() * 100
    h = R.groupby(['dec', 'half']).win.mean().unstack() * 100
    steps = sum(np.diff(d.values) > 0)
    steps_h = sum(np.diff(h.H1.values) > 0) + sum(np.diff(h.H2.values) > 0)
    ll = log_loss(R.win, R.E)
    print(f'{label:34s} dec ' + ' '.join(f'{v:4.1f}' for v in d.values) + f' | steps {steps}/9 halves {steps_h}/18 | logloss {ll:.5f}', flush=True)
    return R
if __name__ == '__main__':
    for fresh in (True, False):
        S = D[fresh]
        for wk in (True, False):
            print(f'==== {"直前価格あり" if fresh else "予備"} {"平日" if wk else "土日"}')
            specs = [('pct',), ('pct', 'vol'), ('pct', 'hour', 'dow'), ('pct', 'vol', 'hour', 'dow')]
            specs += [('pct', 'f1'), ('pct', 'f1', 'vol'), ('pct', 'f1', 'vol', 'hour', 'dow'), ('pct', 'f1', 'vol', 'hour', 'dow', 'btc')] if fresh else [('pct', 'r1'), ('pct', 'r1', 'vol'), ('pct', 'r1', 'vol', 'hour', 'dow')]
            if not wk: specs += [('pct', 'flat', 'tie'), ('pct', 'flat', 'tie', 'f1', 'vol')] if fresh else [('pct', 'tie'), ('pct', 'tie', 'r1', 'vol')]
            for sp in specs: summary(fit_eval(S, wk, sp), '+'.join(sp))

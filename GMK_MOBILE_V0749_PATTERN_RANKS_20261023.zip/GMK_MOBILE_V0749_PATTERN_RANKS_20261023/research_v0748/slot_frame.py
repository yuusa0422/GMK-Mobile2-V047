"""One row per slot: the model's chosen trade (other-half model) plus situation features and outcome."""
import pickle, numpy as np, pandas as pd
P = pd.read_pickle('../work/policy_data.pkl')
C = pickle.load(open('../work/cand_oos.pkl', 'rb'))
key = ['b', 'inst']
F = C[True][C[True].role == 'test'][key + ['pu', 'pd']]
B = C[False][C[False].role == 'test'][key + ['pu', 'pd']].rename(columns={'pu': 'bu', 'pd': 'bd'})
X = P.merge(F, on=key).merge(B, on=key)
assert len(X) == len(P), (len(X), len(P))
# long form: each candidate x direction
L = []
for d in (1, -1):
    t = X.copy(); t['dir'] = d; t['p'] = t.pu if d == 1 else t.pd; t['p_opp'] = t.pd if d == 1 else t.pu
    t['bp'] = t.bu if d == 1 else t.bd; t['bp_opp'] = t.bd if d == 1 else t.bu
    L.append(t)
L = pd.concat(L, ignore_index=True)
L = L.sort_values(['b', 'p'], ascending=[True, False])
L['rk'] = L.groupby('b').cumcount()
best = L[L.rk == 0].copy()
second = L[L.rk == 1][['b', 'p', 'inst', 'dir']].rename(columns={'p': 'p2', 'inst': 'inst2', 'dir': 'dir2'})
S = best.merge(second, on='b', how='left')
S['margin'] = S.p - S.p2
S['win'] = (S.move3 == S.dir).astype(int); S['tie'] = (S.move3 == 0).astype(int)
for c in ['f1', 'f2', 'f5', 'f15', 'r1', 'r3', 'r5', 'r10', 'r15', 'r30', 'r60', 'pos15L', 'bbzL', 'pos60', 'bbz', 'yenf1', 'yen5', 'yen15', 'app_dir']:
    S['s_' + c] = S[c] * S.dir                        # signed with the trade direction (+ = moving our way before entry)
S['app_agree'] = (S.app_dir == S.dir).astype(int)
S['minute'] = S.ts.dt.minute; S['dow'] = S.ts.dt.dayofweek; S['m'] = S.ts.dt.strftime('%Y-%m')
S['same_inst_second'] = (S.inst2 == S.inst).astype(int)
S['p_gap_opp'] = S.p - S.p_opp
S.to_pickle('../work/slots_oos.pkl')
print(S.shape, S.weekday.mean().round(3))
print(S.groupby('weekday').agg(n=('win', 'size'), win=('win', 'mean'), tie=('tie', 'mean')))

"""Entry share vs win rate when slots are ordered by the strength score E (other-half fit, fixed cut points)."""
import pickle, numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
exec(open('ladder_hybrid.py').read().split("if __name" + "__")[0])
S = D[True]
RF2 = {True: ['pct', 'hinge', 'af1', 'lrv', 'fx_fade_big', 'btc_follow'], False: ['pct', 'hinge', 'flat', 'tie58', 'zero30', 'af1', 'lrv']}
RF3 = {True: ['pct', 'hinge', 'af1', 'lrv', 'fx_fade_big', 'btc_follow', 'h9', 'h10', 'mon'], False: RF2[False]}
def oos(spec):
    out = []
    for wk in (True, False):
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = S[(S.weekday == wk) & (S.half == tr)].copy(); B = S[(S.weekday == wk) & (S.half == te)].copy()
            m = LogisticRegression(C=0.1, max_iter=3000).fit(rank_feats(A, spec[wk]), A.win)
            A['R'] = m.predict_proba(rank_feats(A, spec[wk]))[:, 1]; B['R'] = m.predict_proba(rank_feats(B, spec[wk]))[:, 1]
            B['Rq'] = np.searchsorted(np.sort(A.R.values), B.R.values) / len(A)     # position in the training distribution
            out.append(B)
    return pd.concat(out)
for name, spec in (('時間・曜日なし', RF2), ('時間・曜日あり', RF3)):
    R = oos(spec)
    for wk in (True, False):
        x = R[R.weekday == wk]; print(f'--- {name} {"平日" if wk else "土日"}  (現行ルール: 入る{x.enter.mean()*100:.0f}% 勝率{x[x.enter].win.mean()*100:.2f})')
        for cov in ((0.74, 0.80, 0.85, 0.90, 0.95, 1.0) if wk else (0.47, 0.52, 0.57, 0.62, 0.70, 1.0)):
            e = x[x.Rq >= 1 - cov]; ph = x.assign(e=x.Rq >= 1 - cov).groupby('hour').e.mean()
            print(f'  上位{cov*100:3.0f}%: 実際の入る率 {len(e)/len(x)*100:4.1f}% 時間別最小 {ph.min()*100:4.1f}%  勝率 {e.win.mean()*100:5.2f} (前半 {e[e.half=="H1"].win.mean()*100:4.1f} / 後半 {e[e.half=="H2"].win.mean()*100:4.1f})  '
                  f'追加分の勝率 {x[(x.Rq >= 1 - cov) & ~x.enter].win.mean()*100:4.1f}')

"""Slot table for the chosen trade of each model (fresh / backup), with the app's rolling percentile and features.
Rows carry role=test (other-half model) and role=train (own-half in-sample) so a second stage can be fitted on train rows
of half A and evaluated on test rows of half B... but second stage is fitted on the OOS rows of the other half (see strength_lab)."""
import pickle, numpy as np, pandas as pd
P = pd.read_pickle('../work/policy_data.pkl')
C = pickle.load(open('../work/cand_oos.pkl', 'rb'))
RATE = {True: 0.74, False: 0.47}; NBUF = {True: 288, False: 576}; NMIN = 96
feat_cols = ['f1', 'f2', 'f5', 'r1', 'r3', 'r5', 'r15', 'r60', 'rv60', 'rv30_60', 'tie58', 'zero30', 'vol10', 'regime', 'regconf', 'app_dir', 'app_grade', 'pos15L', 'bbzL', 'yenf1']
out = {}
for fresh in (True, False):
    D = C[fresh].merge(P[['b', 'inst'] + feat_cols], on=['b', 'inst'])
    rows = []
    for fold in ('H1', 'H2'):
        parts = {}
        for role in ('train', 'test'):
            d = D[(D.fold == fold) & (D.role == role)]
            u = d.assign(dir=1, p=d.pu, p_opp=d.pd); dn = d.assign(dir=-1, p=d.pd, p_opp=d.pu)
            L = pd.concat([u, dn]).sort_values(['b', 'p'], ascending=[True, False])
            best = L.groupby('b').head(1).sort_values('b').copy()
            best['win'] = (best.move3 == best.dir).astype(int); best['tie'] = (best.move3 == 0).astype(int)
            parts[role] = best
        tr, te = parts['train'], parts['test']
        for wk in (True, False):
            x = tr[tr.weekday == wk]; off = x.groupby('hour').p.median(); adjt = np.sort((x.p - x.hour.map(off)).values)
            y = te[te.weekday == wk].copy(); adj = (y.p - y.hour.map(off)).values; buf = []; pct = []; seed = []
            for a in adj:
                ref = np.array(buf) if len(buf) >= NMIN else adjt
                pct.append((ref < a).mean()); seed.append(len(buf) < NMIN); buf.append(a); buf = buf[-NBUF[wk]:]
            y['adj'] = adj; y['pct'] = pct; y['seed'] = seed; y['enter'] = y.pct >= 1 - RATE[wk]
            rows.append(y)
    S = pd.concat(rows).sort_values('b')
    S['s_f1'] = S.f1 * S.dir; S['abs_f1'] = S.f1.abs(); S['s_r1'] = S.r1 * S.dir; S['abs_r1'] = S.r1.abs(); S['lrv'] = np.log(S.rv60)
    S['dow'] = S.ts.dt.dayofweek; S['m'] = S.ts.dt.strftime('%Y-%m'); S['gap'] = S.p - S.p_opp
    out[fresh] = S; print(fresh, S.shape, S.groupby('weekday').enter.mean().round(3).to_dict(), S.groupby(['weekday', 'enter']).win.mean().round(4).to_dict())
pickle.dump(out, open('../work/strength_slots.pkl', 'wb'))

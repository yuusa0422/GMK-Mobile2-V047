"""Design X (v0.7.48 candidate).
Weekday: ENTRY = top 85% of the rolling 288-slot window by strength E (no hour/day terms, so every hour keeps its quota);
         S/A/B/C among entries by a rank strength that also knows 9時/10時/月曜; skipped slots D (upper half) / E (lower half).
Weekend: ENTRY = strength E7 above a fixed cut (keeps the quiet-day effect), about 55% of slots; S/A/B/C and D–H by E7.
Every skipped slot gets a reason."""
import pickle, numpy as np, pandas as pd, json
from sklearn.linear_model import LogisticRegression
exec(open('final_ladder.py').read().split("if __name" + "__")[0])
WD_E = ['pct', 'hinge', 'af1', 'lrv', 'fx_fade_big', 'btc_follow', 'fx_fade15', 'btc_af1']
WD_R = WD_E + ['h9', 'h10', 'mon']
WE_E = ['pct', 'hinge', 'flat', 'tie58', 'zero30', 'af1', 'lrv']
FB_WD_E = ['pct', 'hinge', 'ar1', 'lrv']; FB_WD_R = FB_WD_E + ['h9', 'h10', 'mon']; FB_WE_E = ['pct', 'hinge', 'tie58', 'zero30', 'ar1', 'lrv']
GROUP.update(h9='time', h10='time', mon='time'); REASON.update(time='弱い時間帯・曜日')
_F = F
def F(x, cols):
    ex = {'h9': (x.hour == 9) * 1.0, 'h10': (x.hour == 10) * 1.0, 'mon': (x.dow == 0) * 1.0}
    base = [c for c in cols if c not in ex]
    M = _F(x, base); parts = []; bi = 0
    for c in cols:
        if c in ex: parts.append(np.asarray(ex[c], float))
        else: parts.append(M[:, bi]); bi += 1
    return np.column_stack(parts)
WD_COVER = 0.85; NBUF = 288; NMIN = 96
WD_SH = [('S', .10), ('A', .15), ('B', .25)]; WE_SH = [('S', .10), ('A', .15), ('B', .30)]; WE_COVER = 0.55   # weekend: B = rest of entries (C unused)
WE_SKIP_Q = [0.75, 0.5, 0.3, 0.15]
def reasons(X, cols, m, mean):
    contrib = (X - mean) * m.coef_[0]; groups = sorted(set(GROUP[c] for c in cols))
    G = np.column_stack([contrib[:, [i for i, c in enumerate(cols) if GROUP[c] == g]].sum(1) for g in groups])
    return [REASON[groups[i]] for i in G.argmin(1)]
def weekday(S, tr, te, cE, cR):
    A = S[S.weekday & (S.half == tr)].copy(); B = S[S.weekday & (S.half == te)].copy()
    mE = LogisticRegression(C=0.1, max_iter=5000).fit(F(A, cE), A.win); mR = LogisticRegression(C=0.1, max_iter=5000).fit(F(A, cR), A.win)
    A['E'] = mE.predict_proba(F(A, cE))[:, 1]; A['R'] = mR.predict_proba(F(A, cR))[:, 1]
    B['E'] = mE.predict_proba(F(B, cE))[:, 1]; B['R'] = mR.predict_proba(F(B, cR))[:, 1]
    seed = np.sort(A.E.values); buf = []; ent = []; qs = []
    for a in B.E.values:
        ref = np.array(buf) if len(buf) >= NMIN else seed
        q = (ref < a).mean(); qs.append(q); ent.append(q >= 1 - WD_COVER); buf.append(a); buf = buf[-NBUF:]
    B['enter3'] = ent; B['q'] = qs
    # rank cut points among entries (training half: top 85% by E, shares of all slots)
    Ae = A[A.E >= np.quantile(A.E, 1 - WD_COVER)]
    acc = 0; cuts = {}
    for g, s in WD_SH: acc += s; cuts[g] = float(np.quantile(Ae.R, 1 - acc / WD_COVER))
    B['grade'] = np.where(~B.enter3, np.where(B.q >= (1 - WD_COVER) / 2, 'D', 'E'),
                          np.where(B.R >= cuts['S'], 'S', np.where(B.R >= cuts['A'], 'A', np.where(B.R >= cuts['B'], 'B', 'C'))))
    B['reason'] = reasons(F(B, cE), cE, mE, F(A, cE).mean(0))
    return B
def weekend(S, tr, te, cE):
    A = S[~S.weekday & (S.half == tr)].copy(); B = S[~S.weekday & (S.half == te)].copy()
    m = LogisticRegression(C=0.1, max_iter=5000).fit(F(A, cE), A.win)
    e = np.sort(m.predict_proba(F(A, cE))[:, 1]); B['E'] = m.predict_proba(F(B, cE))[:, 1]
    q = lambda s: float(np.quantile(e, 1 - s)); cuts = {'enter': q(WE_COVER)}; acc = 0
    for g, s in WE_SH: acc += s; cuts[g] = q(acc)
    sk = e[e < cuts['enter']]; sq = np.quantile(sk, WE_SKIP_Q); cuts.update(D=sq[0], E=sq[1], F=sq[2], G=sq[3])
    B['grade'] = [grade(v, cuts) for v in B.E]; B['enter3'] = B.grade.isin(list('SABC'))
    B['reason'] = reasons(F(B, cE), cE, m, F(A, cE).mean(0))
    return B
def run(fresh):
    S = D[fresh]; out = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        out.append(weekday(S, tr, te, WD_E if fresh else FB_WD_E, WD_R if fresh else FB_WD_R))
        out.append(weekend(S, tr, te, WE_E if fresh else FB_WE_E))
    return pd.concat(out).sort_values('b')
if __name__ == '__main__':
    js = {}
    for fresh in (True, False):
        R = run(fresh); report(R, '直前価格あり' if fresh else '予備', js)
        x = R[R.weekday]; print('  平日 時間別ENTRY率', x.groupby('hour').enter3.mean().round(2).to_dict())
        pickle.dump(R, open(f'../work/design_x_{"fresh" if fresh else "fallback"}.pkl', 'wb'))
    json.dump(js, open('../work/design_x.json', 'w'), ensure_ascii=False, indent=1)

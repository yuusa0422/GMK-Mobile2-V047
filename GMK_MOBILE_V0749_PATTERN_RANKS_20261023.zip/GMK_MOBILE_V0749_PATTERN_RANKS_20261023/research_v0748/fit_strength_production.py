"""Production second stage for v0.7.48: logistic strength models fitted on all cross-fitted (other-half) slots of the year,
cut points, reason means, validated rates (design_x.json) and the adj-percentile seed tables of the production ensemble."""
import pickle, json, numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
exec(open('design_x.py').read().split("if __name" + "__")[0])
exec(open('evidence_model.py').read().split('def model():')[0].replace("P = pd.read_pickle('../work/policy_data.pkl')", "P = pd.read_pickle('../work/policy_data.pkl')"))
DX = json.load(open('../work/design_x.json'))
M = pickle.load(open('../work/production_ensemble.pkl', 'rb'))
out = {'version': 'V0748_STRENGTH', 'weekday_cover': WD_COVER, 'weekend_cover': WE_COVER, 'weekday_shares': WD_SH, 'weekend_shares': WE_SH, 'weekend_skip_quantiles': WE_SKIP_Q,
       'reason_labels': REASON, 'models': {}, 'cuts': {}, 'seed_adj_quantiles': {}, 'validated': {}}
for fresh in (True, False):
    key = 'fresh' if fresh else 'fallback'; S = D[fresh]
    cE, cR, cW = (WD_E, WD_R, WE_E) if fresh else (FB_WD_E, FB_WD_R, FB_WE_E)
    wd = S[S.weekday]; we = S[~S.weekday]
    def fit(x, cols):
        X = F(x, cols); m = LogisticRegression(C=0.1, max_iter=10000).fit(X, x.win)
        return m, dict(cols=cols, coef=[float(v) for v in m.coef_[0]], intercept=float(m.intercept_[0]), mean=[float(v) for v in X.mean(0)],
                       groups=[GROUP[c] for c in cols])
    mE, jE = fit(wd, cE); mR, jR = fit(wd, cR); mW, jW = fit(we, cW)
    out['models'][key] = {'weekday_entry': jE, 'weekday_rank': jR, 'weekend': jW}
    eE = mE.predict_proba(F(wd, cE))[:, 1]; eR = mR.predict_proba(F(wd, cR))[:, 1]; eW = mW.predict_proba(F(we, cW))[:, 1]
    enter_cut = float(np.quantile(eE, 1 - WD_COVER)); de_cut = float(np.quantile(eE, (1 - WD_COVER) / 2))
    ent = eR[eE >= enter_cut]; acc = 0; wcuts = {}
    for g, s in WD_SH: acc += s; wcuts[g] = float(np.quantile(ent, 1 - acc / WD_COVER))
    q = lambda s: float(np.quantile(eW, 1 - s)); ecuts = {'enter': q(WE_COVER)}; acc = 0
    for g, s in WE_SH: acc += s; ecuts[g] = q(acc)
    sk = eW[eW < ecuts['enter']]; sq = np.quantile(sk, WE_SKIP_Q); ecuts.update(D=float(sq[0]), E=float(sq[1]), F=float(sq[2]), G=float(sq[3]))
    out['cuts'][key] = {'weekday_seed_enter': enter_cut, 'weekday_seed_de': de_cut, 'weekday_rank': wcuts, 'weekend': ecuts}
    # validated (other-half) win rates by grade
    lab = '直前価格あり' if fresh else '予備'
    out['validated'][key] = {seg: {g: v['win'] for g, v in DX[f'{lab}|{segj}']['ranks'].items()} for seg, segj in (('weekday', '平日'), ('weekend', '土日'))}
    # seed table for the adj percentile: production ensemble on the whole year (same as the existing seed thresholds)
    Xu = design(P, 1, fresh)[0]; Xd = design(P, -1, fresh)[0]
    pu = np.mean([m.predict_proba(Xu)[:, 1] for m in M['models'][fresh]], axis=0); pdn = np.mean([m.predict_proba(Xd)[:, 1] for m in M['models'][fresh]], axis=0)
    t = P[['b', 'weekday', 'hour']].copy(); t['p'] = np.maximum(pu, pdn); best = t.sort_values('p', ascending=False).groupby('b').head(1)
    for wk, seg in ((True, 'weekday'), (False, 'weekend')):
        st = M['stats'][key][seg]; off = dict(zip(range(9, 23), st['offset'])); x = best[best.weekday == wk]; adj = (x.p - x.hour.map(off)).values
        out['seed_adj_quantiles'][f'{key}|{seg}'] = [float(v) for v in np.quantile(adj, np.linspace(0, 1, 201))]
    print(key, 'weekday entry share', round((eE >= enter_cut).mean(), 3), 'weekend entry share', round((eW >= ecuts['enter']).mean(), 3))
    print('  coefE', dict(zip(cE, np.round(mE.coef_[0], 4))), 'coefW', dict(zip(cW, np.round(mW.coef_[0], 4))))
json.dump(out, open('../work/strength_production.json', 'w'), ensure_ascii=False, indent=1)
print(json.dumps(out['cuts'], indent=1)); print(json.dumps(out['validated'], ensure_ascii=False))

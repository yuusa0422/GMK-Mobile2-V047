"""Parity fixture for EvidenceStrength (Kotlin) from real slots: sklearn-free reference = the lab feature map F() + the
production coefficients, plus an independent check against sklearn's predict_proba refit on the same coefficients."""
import pickle, json, numpy as np, pandas as pd, sys
exec(open('design_x.py').read().split("if __name" + "__")[0])
J = json.load(open('../work/strength_production.json'))
rng = np.random.default_rng(48)
lines = ['# model\tinstrument\tdirection\tpct\tf1\tr1\tr15\trv60\ttie58\tzero30\thour\tdow_iso\tprob\tweakest\tstrongest']
for key, fresh in (('fresh', True), ('fallback', False)):
    S = D[fresh]
    for name, m in J['models'][key].items():
        wk = name.startswith('weekday')
        x = S[S.weekday == wk]
        # 40 random rows + rows that switch on every indicator
        idx = list(rng.choice(len(x), 40, replace=False))
        fx = x.inst != 'BTCJPY'
        for cond in (fx & (x.s_f1 < 0) & (x.abs_f1 >= 2.5), (~fx) & (x.s_f1 > 0) & (x.abs_f1 >= 0.5) & (x.abs_f1 < 3), fx & (x.r15 * x.dir <= -1.5),
                     x.abs_f1 < 0.01, x.hour == 9, x.hour == 10, x.dow == 0, x.pct > 0.95, x.tie58 > 0.4):
            w = np.flatnonzero(cond.values)
            if len(w): idx += list(rng.choice(w, min(3, len(w)), replace=False))
        rows = x.iloc[idx]
        X = F(rows, m['cols']); z = m['intercept'] + X @ np.array(m['coef']); p = 1 / (1 + np.exp(-z))
        contrib = (X - np.array(m['mean'])) * np.array(m['coef']); groups = sorted(set(m['groups']))
        G = np.column_stack([contrib[:, [i for i, g in enumerate(m['groups']) if g == gg]].sum(1) for gg in groups])
        for (_, r), pv, gmin, gmax in zip(rows.iterrows(), p, G.argmin(1), G.argmax(1)):
            lines.append('\t'.join([f'{key}_{name}', r.inst, str(int(r.dir)), repr(float(r.pct)), repr(float(r.f1)), repr(float(r.r1)), repr(float(r.r15)), repr(float(r.rv60)),
                                    repr(float(r.tie58)), repr(float(r.zero30)), str(int(r.hour)), str(int(r.dow) + 1), repr(float(pv)), groups[gmin], groups[gmax]]))
# seed percentile cases: interpolation on the 201-point table
for k, tab in J['seed_adj_quantiles'].items():
    t = np.array(tab)
    for a in [t[0] - 0.01, t[0], t[3] + (t[4] - t[3]) * 0.3, t[100], t[150] + 1e-9, t[-1], t[-1] + 0.01]:
        if a <= t[0]: pc = 0.0
        elif a >= t[-1]: pc = 1.0
        else:
            i = 0
            while i < len(t) - 2 and t[i + 1] <= a: i += 1
            span = t[i + 1] - t[i]; pc = (i + ((a - t[i]) / span if span > 0 else 0.0)) / (len(t) - 1)
        lines.append('\t'.join(['seedpct', k, '0', repr(float(a)), '0', '0', '0', '1', '0', '0', '12', '3', repr(float(pc)), '-', '-']))
open(sys.argv[1], 'w').write('\n'.join(lines) + '\n'); print(len(lines), 'lines')

"""Design X at several entry shares: win rate, losing streaks, skipped share."""
import pickle, numpy as np, pandas as pd, json
exec(open('design_x.py').read().split("if __name" + "__")[0])
out = {}
S = D[True]
for wc, ec in ((0.74, 0.47), (0.80, 0.52), (0.85, 0.55), (0.90, 0.57)):
    globals()['WD_COVER'] = wc; globals()['WE_COVER'] = ec
    R = pd.concat([weekday(S, tr, te, WD_E, WD_R) for tr, te in (('H1', 'H2'), ('H2', 'H1'))] + [weekend(S, tr, te, WE_E) for tr, te in (('H1', 'H2'), ('H2', 'H1'))]).sort_values('b')
    for wk in (True, False):
        x = R[R.weekday == wk]; e = x[x.enter3]; nd = x.date.nunique(); dm = e.groupby('date').win.apply(lambda v: ms(v.values)).reindex(sorted(x.date.unique()), fill_value=0)
        r = dict(cover=wc if wk else ec, entry=round(len(e) / len(x) * 100, 1), per_day=round(len(e) / nd, 1), win=round(e.win.mean() * 100, 2), H1=round(e[e.half == 'H1'].win.mean() * 100, 1),
                 H2=round(e[e.half == 'H2'].win.mean() * 100, 1), maxs=ms(e.win.values), day_avg=round(dm.mean(), 1), d8=round((dm >= 8).mean() * 100, 1), d10=round((dm >= 10).mean() * 100, 1),
                 S=round(e[e.grade == 'S'].win.mean() * 100, 1))
        out[f'{"weekday" if wk else "weekend"}|{wc if wk else ec}'] = r; print('平日' if wk else '土日', r)
json.dump(out, open('../work/design_x_cover.json', 'w'), ensure_ascii=False, indent=1)

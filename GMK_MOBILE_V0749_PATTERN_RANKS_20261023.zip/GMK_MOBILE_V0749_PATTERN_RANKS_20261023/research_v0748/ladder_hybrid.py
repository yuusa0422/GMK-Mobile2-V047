"""Hybrid: ENTRY from a strength score without hour/day terms (keeps every hour's quota), ranks from a strength score
that also knows the hour/day effects. Weekend: ENTRY unchanged (current rule), ranks from strength."""
import pickle, numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
exec(open('ladder_c.py').read().split("if __name" + "__")[0])
RF = {True: ['pct', 'hinge', 'af1', 'lrv', 'h9', 'h10', 'mon', 'fx_fade_big', 'btc_follow'], False: ['pct', 'hinge', 'flat', 'tie58', 'zero30', 'af1', 'lrv']}
def rank_feats(x, cols):
    fx = x.inst != 'BTCJPY'
    c = dict(pct=x.pct, hinge=np.maximum(x.pct - 0.9, 0) * 10, af1=x.abs_f1.clip(0, 4), ar1=x.abs_r1.clip(0, 4), lrv=x.lrv.clip(-2.5, 3.5),
             h9=(x.hour == 9) * 1.0, h10=(x.hour == 10) * 1.0, mon=(x.dow == 0) * 1.0,
             fx_fade_big=(fx & (x.s_f1 < 0) & (x.abs_f1 >= 2.5)) * 1.0, btc_follow=((~fx) & (x.s_f1 > 0) & (x.abs_f1 >= 0.5) & (x.abs_f1 < 3)) * 1.0,
             flat=(x.abs_f1 < 0.01) * 1.0, tie58=x.tie58, zero30=x.zero30)
    return np.column_stack([np.asarray(c[n], float) for n in cols])
ENT_SH = {True: [0.10, 0.15, 0.25], False: [0.08, 0.12, 0.14]}   # S, A, B shares of all slots
SKIP_Q = {True: [0.8, 0.6, 0.4, 0.2], False: [0.8, 0.6, 0.4, 0.2]}
def run(fresh, entry_mode_wd, entry_cols_wd, rank_cols=RF, skip_mode='fifths'):
    S = D[fresh]
    sim = simulate(fresh, entry_cols_wd, ['adj'])        # entry from option C (weekday) and current rule (weekend: adj only == current)
    out = []
    for wk in (True, False):
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = S[(S.weekday == wk) & (S.half == tr)].copy()
            B = sim[(sim.weekday == wk) & (sim.half == te)].copy()
            if not (wk and entry_mode_wd == 'C'):
                B['enter2'] = B.enter
            m = LogisticRegression(C=0.1, max_iter=3000).fit(rank_feats(A, rank_cols[wk]), A.win)
            A['R'] = m.predict_proba(rank_feats(A, rank_cols[wk]))[:, 1]; B['R'] = m.predict_proba(rank_feats(B, rank_cols[wk]))[:, 1]
            # cut points from the training half: shares of all slots, ENTRY ranks among entries, SKIP ranks among skips
            rate = 0.74 if wk else 0.47
            Ae = A[A.enter].R.values; As = A[~A.enter].R.values
            ce = np.quantile(Ae, 1 - np.cumsum(ENT_SH[wk]) / rate); cs = np.quantile(As, SKIP_Q[wk])
            def g(r):
                if r.enter2: return 'S' if r.R >= ce[0] else 'A' if r.R >= ce[1] else 'B' if r.R >= ce[2] else 'C'
                return 'D' if r.R >= cs[0] else 'E' if r.R >= cs[1] else 'F' if r.R >= cs[2] else 'G' if r.R >= cs[3] else 'H'
            B['grade'] = B.apply(g, axis=1); out.append(B)
    return pd.concat(out).sort_values('b')
if __name__ == '__main__':
    WDC = ['adj', 'hinge', 'af1', 'lrvh', 'fx_fade_big', 'btc_follow']
    for mode in ('current', 'C'):
        R = run(True, mode, WDC); report(R, f'ENTRY={mode}')
        pickle.dump(R, open(f'../work/ladder_hybrid_{mode}.pkl', 'wb'))

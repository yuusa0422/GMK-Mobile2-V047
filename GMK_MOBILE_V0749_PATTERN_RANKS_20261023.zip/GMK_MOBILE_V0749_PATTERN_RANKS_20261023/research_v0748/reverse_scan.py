"""Skipped slots: does the opposite direction win anywhere?  Also: which skipped slots win enough to be entered as-is."""
import pickle, numpy as np, pandas as pd, sys
S = pickle.load(open('../work/strength_slots.pkl', 'rb'))[True].copy()
S['rev'] = (S.move3 == -S.dir).astype(int)
S['fx'] = np.where(S.inst == 'BTCJPY', 'BTC', 'FX'); S['fade'] = np.where(S.s_f1 < 0, 'fade', np.where(S.s_f1 > 0, 'follow', 'flat'))
S['af1b'] = pd.cut(S.abs_f1, [-1, 0.01, 0.5, 1, 2, 3, 99], labels=['0', '<.5', '.5-1', '1-2', '2-3', '3+'])
S['volq'] = S.groupby('weekday').lrv.transform(lambda v: pd.qcut(v.rank(method='first'), 5, labels=False))
S['app_agree'] = np.where(S.app_dir == S.dir, 'agree', np.where(S.app_dir == -S.dir, 'oppose', 'none'))
S['gapq'] = S.groupby('weekday').gap.transform(lambda v: pd.qcut(v.rank(method='first'), 5, labels=False))
S['s_r15b'] = pd.cut(S.r15 * S.dir, [-99, -1.5, -0.5, 0.5, 1.5, 99])
S['s_r60b'] = pd.cut(S.r60 * S.dir, [-99, -1.5, -0.5, 0.5, 1.5, 99])
rows = []
def scan(x, keys, seg):
    for lev, g in x.groupby(keys, observed=True):
        if len(g) < 150: continue
        h = g.groupby('half')
        rows.append(dict(seg=seg, cond=' & '.join(f'{k}={v}' for k, v in zip(keys, lev if isinstance(lev, tuple) else (lev,))), n=len(g),
                         win=g.win.mean(), w1=h.win.mean().get('H1', np.nan), w2=h.win.mean().get('H2', np.nan),
                         rev=g.rev.mean(), r1=h.rev.mean().get('H1', np.nan), r2=h.rev.mean().get('H2', np.nan), tie=g.tie.mean()))
for wk in (True, False):
    seg = '平日' if wk else '土日'
    x = S[(S.weekday == wk) & ~S.enter]
    for keys in (['fx'], ['fx', 'fade'], ['fx', 'af1b'], ['fx', 'fade', 'af1b'], ['hour'], ['inst'], ['inst', 'fade'], ['volq'], ['regime'], ['app_agree'], ['gapq'],
                 ['dir'], ['inst', 'dir'], ['s_r15b'], ['s_r60b'], ['fx', 's_r15b'], ['regime', 'fade'], ['app_agree', 'fade'], ['hour', 'fx']):
        scan(x, keys, seg)
R = pd.DataFrame(rows)
for c in ['win', 'w1', 'w2', 'rev', 'r1', 'r2', 'tie']: R[c] = (R[c] * 100).round(1)
R['rev_both53'] = (R.r1 >= 53) & (R.r2 >= 53); R['win_both53'] = (R.w1 >= 53) & (R.w2 >= 53)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400)
print('== 逆向きが前半・後半とも53%以上'); print(R[R.rev_both53].sort_values('rev', ascending=False).to_string())
print('== 逆向きの上位（前半・後半の低い方で並べる）'); R['rev_min'] = R[['r1', 'r2']].min(axis=1); print(R.sort_values('rev_min', ascending=False).head(25).to_string())
print('== そのままの向きで前半・後半とも53%以上'); R['win_min'] = R[['w1', 'w2']].min(axis=1); print(R.sort_values('win_min', ascending=False).head(30).to_string())
R.to_csv('../work/skip_reverse_scan.csv', index=False)

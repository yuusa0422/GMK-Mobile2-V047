v0.7.48 研究コード（ランクS〜Hの作り直し・見送りの理由・逆向きの検証）

前提: research_v0744/evidence_model.py（候補表P・特徴量）、research_v0747/cand_oos.py（片方の半年で学習した5モデル平均の確率）。
  strength_data.py        枠ごとの「選んだ取引」の表（予測の順位pct・直前1分の動き・値動き・引き分けリスク・結果）
  slot_frame.py / cond_scan.py   条件ごとの勝率（前半・後半）
  reverse_scan.py         見送り枠を逆向きにした場合の勝率（前半・後半とも53%以上の場面は無し）
  stage2_lab.py / strength_lab.py  2段目（強さ）のモデルの比較（決定木は過学習、少数の入力のロジスティックが安定）
  rank_ladder.py / ladder_b.py / ladder_c.py / ladder_hybrid.py / coverage_e.py / final_ladder.py  ランクとENTRYの決め方の比較
  design_x.py             採用案（平日: 強さの上位85%・S/A/B/C・D/E、土日: 強さの線55%・S/A/B・D〜H）の検証 → design_x.json
  design_x_cover.py       ENTRY率と勝率・連敗の関係 → design_x_cover.json
  fit_strength_production.py / gen_kotlin_strength.py / gen_strength_fixture.py  アプリ用の係数・線・一致テストの生成
  situation_catalog.py    勝っている場面・負けている場面 → GMK_勝ち負け場面一覧.csv

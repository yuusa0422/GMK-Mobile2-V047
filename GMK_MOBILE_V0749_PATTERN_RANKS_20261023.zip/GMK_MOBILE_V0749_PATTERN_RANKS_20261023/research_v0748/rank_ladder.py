"""S–H ladder: expected win E (second stage, other-half fit) -> ranks. ENTRY/SKIP decision unchanged (rolling quota)."""
import pickle, numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
D = pickle.load(open('../work/strength_slots.pkl', 'rb'))
SPEC = {True: ['pct', 'hinge', 'af1', 'lrv', 'h9', 'h10', 'mon', 'fx_fade_big', 'btc_follow'],      # weekday (fresh)
        False: ['pct', 'hinge', 'flat', 'tie58', 'zero30', 'af1', 'lrv']}                           # weekend (fresh)
SPEC_FB = {True: ['pct', 'hinge', 'ar1', 'lrv', 'h9', 'h10', 'mon'], False: ['pct', 'hinge', 'tie58', 'zero30', 'ar1', 'lrv']}
def feats(x, cols):
    fx = x.inst != 'BTCJPY'
    c = dict(pct=x.pct, hinge=np.maximum(x.pct - 0.9, 0) * 10, af1=x.abs_f1.clip(0, 4), ar1=x.abs_r1.clip(0, 4), lrv=x.lrv.clip(-2.5, 3.5),
             h9=(x.hour == 9) * 1.0, h10=(x.hour == 10) * 1.0, mon=(x.dow == 0) * 1.0,
             fx_fade_big=(fx & (x.s_f1 < 0) & (x.abs_f1 >= 2.5)) * 1.0, btc_follow=((~fx) & (x.s_f1 > 0) & (x.abs_f1 >= 0.5) & (x.abs_f1 < 3)) * 1.0,
             flat=(x.abs_f1 < 0.01) * 1.0, tie58=x.tie58, zero30=x.zero30)
    return np.column_stack([np.asarray(c[k], float) for k in cols])
def oos_E(fresh):
    S = D[fresh]; out = []
    for wk in (True, False):
        cols = (SPEC if fresh else SPEC_FB)[wk]
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = S[(S.weekday == wk) & (S.half == tr)]; B = S[(S.weekday == wk) & (S.half == te)].copy()
            m = LogisticRegression(C=0.1, max_iter=3000).fit(feats(A, cols), A.win)
            B['E'] = m.predict_proba(feats(B, cols))[:, 1]; B['E_train_ref'] = [m.predict_proba(feats(A, cols))[:, 1]] * len(B) if False else 0
            A2 = A.copy(); A2['E'] = m.predict_proba(feats(A, cols))[:, 1]
            B.attrs = {}; out.append((wk, tr, te, A2, B))
    return out
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
GR = list('SABCDEFGH')
def ladder_quantile(A, B, wk):
    """Cut points from the training half (in-sample E) as shares of all slots; ENTRY ranks among entries, SKIP ranks among skips."""
    rate = 0.74 if wk else 0.47
    ent_sh = [0.10, 0.15, 0.25] if wk else [0.08, 0.12, 0.14]          # S, A, B (C = rest of entries)
    ea = A[A.enter].E.values; sa = A[~A.enter].E.values
    cuts_e = np.quantile(ea, 1 - np.cumsum(ent_sh) / rate)            # descending thresholds within entries
    cuts_s = np.quantile(sa, [0.8, 0.6, 0.4, 0.2])                     # D..G thresholds within skips (equal fifths)
    def g(r):
        if r.enter:
            return 'S' if r.E >= cuts_e[0] else 'A' if r.E >= cuts_e[1] else 'B' if r.E >= cuts_e[2] else 'C'
        return 'D' if r.E >= cuts_s[0] else 'E' if r.E >= cuts_s[1] else 'F' if r.E >= cuts_s[2] else 'G' if r.E >= cuts_s[3] else 'H'
    return B.apply(g, axis=1), cuts_e, cuts_s
def table(R, label):
    nd = R.date.nunique()
    rows = []
    for g in GR:
        e = R[R.grade == g]
        if not len(e): rows.append(f'{g}: –'); continue
        rows.append(f'{g} {len(e)/len(R)*100:4.1f}% {len(e)/nd:4.1f}/日 {e.win.mean()*100:5.1f} ({e[e.half=="H1"].win.mean()*100:4.1f}/{e[e.half=="H2"].win.mean()*100:4.1f}) E{e.E.mean()*100:5.1f} tie{e.tie.mean()*100:4.1f}')
    w = R.groupby('grade').win.mean().reindex(GR).dropna().values
    print(f'--- {label}: monotonic steps {sum(np.diff(w) < 0)}/{len(w)-1}'); print('\n'.join(rows))
if __name__ == '__main__':
    for fresh in (True, False):
        res = oos_E(fresh); allB = []
        for wk in (True, False):
            parts = []
            for (w_, tr, te, A, B) in res:
                if w_ != wk: continue
                B['grade'], ce, cs = ladder_quantile(A, B, wk); parts.append(B)
            R = pd.concat(parts); allB.append(R)
            table(R, f'{"直前価格あり" if fresh else "予備"} {"平日" if wk else "土日"}')
        pickle.dump(pd.concat(allB), open(f'../work/ladder_{"fresh" if fresh else "fallback"}.pkl', 'wb'))

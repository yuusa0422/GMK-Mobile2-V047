"""Where the chosen trade wins and loses (all slots, other-half model, fresh). Output: pages/GMK_勝ち負け場面一覧.csv + JSON."""
import pickle, numpy as np, pandas as pd, json
S = pickle.load(open('../work/strength_slots.pkl', 'rb'))[True].copy()
X = pickle.load(open('../work/design_x_fresh.pkl', 'rb'))[['b', 'grade', 'reason']]
S = S.merge(X, on='b', how='left')
S['rev'] = (S.move3 == -S.dir).astype(int); fx = S.inst != 'BTCJPY'; s_f1 = S.f1 * S.dir; s_r15 = S.r15 * S.dir
wd = S.weekday; we = ~S.weekday
lq = S.groupby('weekday').lrv.transform(lambda v: v.rank(pct=True)); tq = S[we].tie58.rank(pct=True).reindex(S.index)
C = [
 ('平日', '為替：直前1分の急変（2.5σ以上）に逆張り', wd & fx & (s_f1 < 0) & (S.abs_f1 >= 2.5), '強い', 'Sに入りやすい（強さの入力）'),
 ('平日', '為替：直前15分の大きな動き（1.5σ以上）に逆張り', wd & fx & (s_r15 <= -1.5), '強い', 'Sに入りやすい（強さの入力）'),
 ('平日', 'BTC：直前1分の動き（0.5〜3σ）に順張り', wd & ~fx & (s_f1 > 0) & (S.abs_f1 >= 0.5) & (S.abs_f1 < 3), '強い', 'Sに入りやすい（強さの入力）'),
 ('平日', '10時台', wd & (S.hour == 10), '強い', 'ランクを上げる'),
 ('平日', '相場の値動きが大きい（上位20%）', wd & (lq >= 0.8), 'やや強い', '強さの入力'),
 ('平日', '予測の強さが直近の上位10%', wd & (S.pct >= 0.9), '強い', '強さの入力'),
 ('平日', '直前1分の動きが小さい（0.5σ未満）', wd & (S.abs_f1 < 0.5), 'やや弱い', '見送りの主な理由'),
 ('平日', '相場の値動きが小さい（下位20%）', wd & (lq < 0.2), 'やや弱い', '見送りの理由'),
 ('平日', '9時台', wd & (S.hour == 9), 'やや弱い', 'ランクを下げる'),
 ('平日', '月曜', wd & (S.dow == 0), 'やや弱い', 'ランクを下げる'),
 ('土日', '予測の強さが直近の上位10%', we & (S.pct >= 0.9), '強い', '強さの入力'),
 ('土日', '直前58分の「3分後も同じ価格」が少ない（下位20%）', we & (tq < 0.2), '強い', '強さの入力'),
 ('土日', '直前1分の動き（0.5〜1σ）に順張り', we & (s_f1 > 0) & (S.abs_f1 >= 0.5) & (S.abs_f1 < 1), 'やや強い', '強さの入力'),
 ('土日', '直前1分に価格が全く動いていない', we & (S.abs_f1 < 0.01), '弱い（引き分け多い）', '見送りの主な理由'),
 ('土日', '直前58分の「3分後も同じ価格」が多い（上位20%）', we & (tq >= 0.8), '非常に弱い（引き分け多い）', 'G・Hの主な理由'),
]
rows = []
for seg, name, m, verdict, use in C:
    g = S[m]; nd = S[S.weekday == (seg == '平日')].date.nunique()
    rows.append({'区分': seg, '場面': name, '件数': len(g), '1日あたり': round(len(g) / nd, 1), '勝率': round(g.win.mean() * 100, 1),
                 '前半': round(g[g.half == 'H1'].win.mean() * 100, 1), '後半': round(g[g.half == 'H2'].win.mean() * 100, 1),
                 '引き分け': round(g.tie.mean() * 100, 1), '逆向きなら': round(g.rev.mean() * 100, 1), '判定': verdict, 'アプリでの扱い': use})
base = {seg: round(S[S.weekday == (seg == '平日')].win.mean() * 100, 1) for seg in ('平日', '土日')}
# reverse check by skip rank
rev = []
for seg in ('平日', '土日'):
    x = S[(S.weekday == (seg == '平日')) & S.grade.isin(list('DEFGH'))]
    for g, d in x.groupby('grade'):
        rev.append({'区分': seg, 'ランク': g, '件数': len(d), 'そのまま': round(d.win.mean() * 100, 1), '逆向き': round(d.rev.mean() * 100, 1),
                    '前半逆向き': round(d[d.half == 'H1'].rev.mean() * 100, 1), '後半逆向き': round(d[d.half == 'H2'].rev.mean() * 100, 1), '引き分け': round(d.tie.mean() * 100, 1)})
df = pd.DataFrame(rows); df.to_csv('../pages/GMK_勝ち負け場面一覧.csv', index=False, encoding='utf-8-sig')
json.dump({'rows': rows, 'base': base, 'reverse': rev}, open('../work/situations.json', 'w'), ensure_ascii=False, indent=1)
pd.set_option('display.width', 250); print(df.to_string()); print(base); print(pd.DataFrame(rev).to_string())

"""Win rate of the chosen trade by condition (all slots incl. skipped), per half."""
import pandas as pd, numpy as np, sys
S = pd.read_pickle('../work/slots_oos.pkl')
S['abs_f1'] = S.f1.abs(); S['abs_f2'] = S.f2.abs(); S['abs_f5'] = S.f5.abs(); S['abs_r60'] = S.r60.abs()
wk = sys.argv[1] == 'weekday'
x = S[S.weekday == wk].copy()
cats = ['hour', 'inst', 'dir', 'regime', 'app_agree', 'app_grade', 'dow', 'minute', 'same_inst_second']
nums = ['p', 'margin', 'p_gap_opp', 'bp', 'abs_f1', 's_f1', 's_f2', 's_f5', 's_f15', 's_r5', 's_r15', 's_r60', 'abs_r60', 'rv60', 'rv30_60', 'tie58', 'zero30', 'vol10',
        'regconf', 's_pos15L', 's_bbzL', 's_pos60', 's_yenf1', 'app_prob']
base = x.win.mean(); out = []
def row(name, lev, g):
    h1 = g[g.half == 'H1'].win; h2 = g[g.half == 'H2'].win
    out.append(dict(feat=name, level=str(lev), n=len(g), win=g.win.mean(), H1=h1.mean(), H2=h2.mean(), tie=g.tie.mean(),
                    z=(g.win.mean() - base) / np.sqrt(base * (1 - base) / len(g))))
for c in cats:
    for lev, g in x.groupby(c): row(c, lev, g)
for c in nums:
    q = pd.qcut(x[c].rank(method='first'), 5, labels=False)
    for k in range(5):
        g = x[q == k]; row(c, f'Q{k+1} [{g[c].min():.3g},{g[c].max():.3g}]', g)
R = pd.DataFrame(out)
R['both'] = np.where((R.H1 > base) & (R.H2 > base), '+', np.where((R.H1 < base) & (R.H2 < base), '-', ''))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
print('base', round(base * 100, 2), 'n', len(x))
print(R.assign(win=(R.win * 100).round(1), H1=(R.H1 * 100).round(1), H2=(R.H2 * 100).round(1), tie=(R.tie * 100).round(1), z=R.z.round(1)).to_string())
R.to_csv(f'../work/cond_scan_{sys.argv[1]}.csv', index=False)

"""v0.7.48 candidate: strength E (logistic, other-half fit) decides ENTRY with fixed cut points and the S–H ladder.
Skipped slots get a reason = the input group that pulls E down the most."""
import pickle, numpy as np, pandas as pd, json, sys
from sklearn.linear_model import LogisticRegression
D = pickle.load(open('../work/strength_slots.pkl', 'rb'))
SPEC = {(True, True): ['pct', 'hinge', 'af1', 'lrv', 'fx_fade_big', 'btc_follow', 'fx_fade15', 'btc_af1'],
        (True, False): ['pct', 'hinge', 'flat', 'tie58', 'zero30'],
        (False, True): ['pct', 'hinge', 'ar1', 'lrv'],
        (False, False): ['pct', 'hinge', 'tie58', 'zero30']}
COVER = {True: 0.85, False: 0.55}
ENT = {True: [('S', .10), ('A', .15), ('B', .25)], False: [('S', .10), ('A', .15), ('B', .15)]}     # shares of all slots, C = rest of entries
GROUP = {'pct': 'edge', 'hinge': 'edge', 'af1': 'move', 'ar1': 'move', 'fx_fade_big': 'move', 'btc_follow': 'move', 'fx_fade15': 'move', 'btc_af1': 'move',
         'flat': 'tie', 'lrv': 'quiet', 'tie58': 'tie', 'zero30': 'tie'}
REASON = {'edge': '予測の強さが直近の枠の中で下位', 'move': '直前の値動きが小さく手がかりが弱い', 'quiet': '相場全体の値動きが小さい（静かな時間）',
          'tie': '引き分けになりやすい（価格が止まりがち）'}
def F(x, cols):
    fx = x.inst != 'BTCJPY'
    c = dict(pct=x.pct, hinge=np.maximum(x.pct - 0.9, 0) * 10, af1=x.abs_f1.clip(0, 4), ar1=x.abs_r1.clip(0, 4), lrv=x.lrv.clip(-2.5, 3.5),
             fx_fade_big=(fx & (x.s_f1 < 0) & (x.abs_f1 >= 2.5)) * 1.0, btc_follow=((~fx) & (x.s_f1 > 0) & (x.abs_f1 >= 0.5) & (x.abs_f1 < 3)) * 1.0,
             fx_fade15=(fx & (x.r15 * x.dir <= -1.5)) * 1.0, btc_af1=((~fx) & (x.abs_f1 >= 0.5) & (x.abs_f1 < 3)) * 1.0,
             flat=(x.abs_f1 < 0.01) * 1.0, tie58=x.tie58, zero30=x.zero30)
    return np.column_stack([np.asarray(c[n], float) for n in cols])
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def fit_cuts(A, cols, wk):
    m = LogisticRegression(C=0.1, max_iter=5000).fit(F(A, cols), A.win)
    e = np.sort(m.predict_proba(F(A, cols))[:, 1]); q = lambda s: float(np.quantile(e, 1 - s))
    cov = COVER[wk]; cuts = {'enter': q(cov)}; acc = 0
    for g, s in ENT[wk]: acc += s; cuts[g] = q(acc)
    skip = e[e < cuts['enter']]; sq = np.quantile(skip, [0.8, 0.6, 0.4, 0.2])
    cuts.update(D=float(sq[0]), E=float(sq[1]), F=float(sq[2]), G=float(sq[3]))
    mean = F(A, cols).mean(0)
    return m, cuts, mean
def grade(E, c):
    if E >= c['enter']:
        return 'S' if E >= c['S'] else 'A' if E >= c['A'] else 'B' if E >= c['B'] else 'C'
    return 'D' if E >= c['D'] else 'E' if E >= c['E'] else 'F' if E >= c['F'] else 'G' if E >= c['G'] else 'H'
def run(fresh):
    S = D[fresh]; out = []
    for wk in (True, False):
        cols = SPEC[(fresh, wk)]
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = S[(S.weekday == wk) & (S.half == tr)]; B = S[(S.weekday == wk) & (S.half == te)].copy()
            m, cuts, mean = fit_cuts(A, cols, wk)
            XB = F(B, cols); B['E'] = m.predict_proba(XB)[:, 1]; B['grade'] = [grade(e, cuts) for e in B.E]
            contrib = (XB - mean) * m.coef_[0]
            groups = sorted(set(GROUP[c] for c in cols))
            G = np.column_stack([contrib[:, [i for i, c in enumerate(cols) if GROUP[c] == g]].sum(1) for g in groups])
            B['reason'] = [REASON[groups[i]] for i in G.argmin(1)]
            out.append(B)
    return pd.concat(out).sort_values('b')
def report(R, label, js):
    for wk in (True, False):
        x = R[R.weekday == wk]; nd = x.date.nunique(); e = x[x.grade.isin(list('SABC'))]
        ph = x.assign(en=x.grade.isin(list('SABC'))).groupby('hour').en.mean(); dd = x.assign(en=x.grade.isin(list('SABC'))).groupby('date').en.mean()
        dm = e.groupby('date').win.apply(lambda v: ms(v.values))
        seg = '平日' if wk else '土日'
        head = dict(entry=round(len(e) / len(x) * 100, 1), win=round(e.win.mean() * 100, 2), H1=round(e[e.half == 'H1'].win.mean() * 100, 1), H2=round(e[e.half == 'H2'].win.mean() * 100, 1),
                    old_entry=round(x.enter.mean() * 100, 1), old_win=round(x[x.enter].win.mean() * 100, 2), hour_min=round(ph.min() * 100, 1), day_p10=round(dd.quantile(.1) * 100, 1),
                    maxs=ms(e.win.values), day8=round((dm >= 8).mean() * 100, 1), oct25=round(e[e.m == '2025-10'].win.mean() * 100, 1), oct26=round(e[e.m == '2026-10'].win.mean() * 100, 1))
        print(f'=== {label} {seg}: ' + ' '.join(f'{k}={v}' for k, v in head.items()))
        ranks = {}
        for g in 'SABCDEFGH':
            s = x[x.grade == g]
            if not len(s): continue
            dms = s.groupby('date').win.apply(lambda v: ms(v.values))
            ranks[g] = dict(share=round(len(s) / len(x) * 100, 1), per_day=round(len(s) / nd, 1), win=round(s.win.mean() * 100, 1), H1=round(s[s.half == 'H1'].win.mean() * 100, 1),
                            H2=round(s[s.half == 'H2'].win.mean() * 100, 1), tie=round(s.tie.mean() * 100, 1), maxs=ms(s.win.values), rev=round((s.move3 == -s.dir).mean() * 100, 1))
            print(f'  {g} ' + ' '.join(f'{k}={v}' for k, v in ranks[g].items()))
        w = [ranks[g]['win'] for g in ranks]; h1 = [ranks[g]['H1'] for g in ranks]; h2 = [ranks[g]['H2'] for g in ranks]
        inv = (sum(np.diff(w) > 0), sum(np.diff(h1) > 0), sum(np.diff(h2) > 0)); print('  逆転', inv)
        sk = x[~x.grade.isin(list('SABC'))]
        rs = sk.groupby('reason').agg(n=('win', 'size'), win=('win', 'mean'), tie=('tie', 'mean'), rev=('move3', lambda v: 0)).drop(columns='rev')
        rs['share_of_slots'] = rs.n / len(x) * 100; rs['rev'] = sk.groupby('reason').apply(lambda d: (d.move3 == -d.dir).mean())
        print(rs.round(3).to_string())
        js[f'{label}|{seg}'] = dict(head=head, ranks=ranks, inv=[int(i) for i in inv],
                                    reasons={k: dict(share=round(v.share_of_slots, 1), win=round(v.win * 100, 1), tie=round(v.tie * 100, 1), rev=round(v.rev * 100, 1)) for k, v in rs.iterrows()})
if __name__ == '__main__':
    js = {}
    for fresh in (True, False):
        R = run(fresh); report(R, '直前価格あり' if fresh else '予備', js); pickle.dump(R, open(f'../work/final_ladder_{"fresh" if fresh else "fallback"}.pkl', 'wb'))
    json.dump(js, open('../work/final_ladder.json', 'w'), ensure_ascii=False, indent=1)

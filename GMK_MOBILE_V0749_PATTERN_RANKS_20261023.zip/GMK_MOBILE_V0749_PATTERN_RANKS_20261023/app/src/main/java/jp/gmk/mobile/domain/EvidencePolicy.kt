package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.floor

/**
 * v0.7.49 final 3-minute ENTRY decision. Runs after the native scan and every optional overlay.
 * v0.7.49 change (user decision: the chart patterns found in the year are treated as real):
 *   - the chosen trade matching a same-direction WIN pattern -> ENTRY, grade by the pattern's one-year rate
 *     (S >= 65%, A >= 62%, B otherwise); a REVERSAL pattern (the chosen side loses, the other side won >= 56% in every
 *     period) -> trade the opposite side, graded the same way; other ENTRY -> C; skips keep D..H (v0.7.48 strength).
 *   - one-year rates by grade are those of the data the patterns were found in (weekday S 64.7 / A 61.7 / B 56.7 / C 49.7).
 *     Other-period check (patterns found on two periods, scored on the third): same-direction >= 62% patterns 53.3%,
 *     reversal 45.5% vs 52.7% unreversed. See README_V0749.txt.
 * v0.7.48 change: second-stage strength (EvidenceStrength) decides ENTRY and the S..H ladder; every skip has a reason.
 *   Weekday: ENTER the strongest 85% of the rolling 288 slots (was 74%); S/A/B/C by a rank strength that also knows
 *   09h/10h/Monday; skipped slots D (upper half) / E. Weekend: ENTER when strength >= fixed cut (about 55%, was 47%);
 *   S/A/B/C and D..H by strength. Out of sample (other half): weekday 52.5% (was 52.5% at 74%), S 54.8 / A 54.1 /
 *   B 52.9 / C 51.1 / D 50.5 / E 48.8; weekend 49.6% (was 49.4% at 47%), S 54.0 / A 50.2 / B 47.0 / C 47.3 /
 *   D 41.7 / E 42.2 / F 38.0 / G 33.6 / H 25.9. Reversing skipped trades never helped (24-48%).
 * v0.7.47 change: grade S = top 10% of recent slots (entries unchanged; S/A/B/C are all ENTRY).
 *   Out of sample (rolling rule, other-half model): weekday S 54.0% (both halves 54.4 / 53.5, about 15 per day,
 *   max 11 losses in a row on S alone), A 53.3%, B 51.6%, C 52.2%; weekend S 52.8%, A 49.7%, B 47.6%.
 * v0.7.46 change: the model is the average of five seeds (EvidenceEnsemble). Same inputs and rule; less variance.
 *   Out of sample, same number of entries: weekday 52.5% (both halves 52.4 / 52.5), October 2025 51.8%,
 *   October 2026 52.0%, days with 8+ losses 12.7% (single model 17.5%).
 * v0.7.45 change: weekend BTC uses a 576-slot window (about two weekend days) and a 47% quota, so quiet,
 * draw-heavy weekend days receive fewer entries and active days more (weekend entry count unchanged on average).
 * Loss/streak study: weekday losses are independent (autocorrelation ~0, runs test, daily dispersion 1.0);
 * weekend losses cluster by day (quiet days: 35% draws, 43.6% wins vs 53.2% on active days).
 *
 * Research (README_V0744.txt, one year of real 1-minute candles 2025-10-01..2026-10-21, the app's
 * exact six-instrument scan, true JST clock, DRAW = LOSE, model trained on one half and tested on the other):
 *  - current app: weekday 50.5% at 73.9% of slots, weekend BTC 47.6% at 46.1% (15% draws), max 18 losses.
 *  - this policy, same number of entries: weekday 51.9% (A 53.1 / B 51.7 / C 50.8), weekend 49.3%
 *    (A 50.8 / B 47.6; BTC 57.8% when draws are excluded). Backup model without a live price: 50.7% / 47.8%.
 *  - the gain comes mainly from the last minute before entry (fade sharp FX moves, follow BTC moves on
 *    bitbank) and from avoiding draw-prone BTC moments; see README_V0744.txt for the full table.
 *
 * Decision (every 5-minute slot, 09:00-22:55 JST, weekday six instruments, weekend BTCJPY):
 *  1) score every candidate instrument x {HIGH, LOW} with the gradient-boosted evidence model
 *     (fresh model when every candidate has a live quote taken within 40 s before entry, else backup model)
 *  2) take the best (instrument, direction); hour-adjust its probability
 *  3) percentile of the hour-adjusted probability among recent slots (rolling 288 weekday / 576 weekend AUTO slots;
 *     one-year table until 96 slots are seen), then the second-stage strength (EvidenceStrength)
 *  4) weekday: ENTER the top 85% of recent strengths; weekend: ENTER when strength >= the one-year 55% cut
 *  5) grades S/A/B/C (ENTRY) and D..H (SKIP, with the reason that pulled the strength down); I = no decision possible
 */
object EvidencePolicy {
    const val VERSION = "V0749_PATTERN_RANKS"
    const val POLICY_TAG = "GMK_V0740_V0749_EVIDENCE"
    const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER
    const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER
    const val WEEKDAY_BUFFER_SIZE = 288
    const val WEEKEND_BUFFER_SIZE = 576
    const val BUFFER_MIN = 96
    fun bufferLimit(weekend: Boolean): Int = if (weekend) WEEKEND_BUFFER_SIZE else WEEKDAY_BUFFER_SIZE
    const val LIVE_MAX_AGE_MS = 40_000L
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    data class LiveQuote(val price: Double, val epochMs: Long)
    /** [inputs] carries the chosen instrument's strength inputs (pct is filled in by [decide]); null = neutral inputs. */
    data class Choice(val instrument: String, val direction: String, val probability: Double, val adjusted: Double, val fresh: Boolean,
                      val inputs: EvidenceStrength.Inputs? = null, val patternCodes: IntArray? = null)
    data class Decision(val choice: Choice, val pct: Double, val strength: Double, val rankStrength: Double, val enter: Boolean, val grade: String,
                        val fromSeed: Boolean, val reasonGroup: String, val reason: String)

    private class Models(val entry: EvidenceStrength.Model, val rank: EvidenceStrength.Model)
    private fun models(fresh: Boolean, weekend: Boolean): Models = when {
        fresh && !weekend -> Models(EvidenceStrengthData.FRESH_WEEKDAY_ENTRY, EvidenceStrengthData.FRESH_WEEKDAY_RANK)
        fresh -> Models(EvidenceStrengthData.FRESH_WEEKEND, EvidenceStrengthData.FRESH_WEEKEND)
        !weekend -> Models(EvidenceStrengthData.FALLBACK_WEEKDAY_ENTRY, EvidenceStrengthData.FALLBACK_WEEKDAY_RANK)
        else -> Models(EvidenceStrengthData.FALLBACK_WEEKEND, EvidenceStrengthData.FALLBACK_WEEKEND)
    }

    /** v0.7.49 one-year rates by grade (pattern grades: the year the patterns were found in). Backup model: every ENTRY is C. */
    fun gradeRate(fresh: Boolean, weekend: Boolean, grade: String): Double? = when {
        fresh -> (if (weekend) EvidencePatternData.VALIDATED_WEEKEND else EvidencePatternData.VALIDATED_WEEKDAY)[grade]
        grade == "C" -> EvidencePatternData.FALLBACK_C[if (weekend) "weekend" else "weekday"]
        else -> validatedRate(false, weekend, grade)
    }

    /** One-year validated win rates of the v0.7.48 strength ladder (strength fitted on the other half, same decision rule). */
    fun validatedRate(fresh: Boolean, weekend: Boolean, grade: String): Double? = when {
        fresh && !weekend -> EvidenceStrengthData.FRESH_WEEKDAY_VALIDATED
        fresh -> EvidenceStrengthData.FRESH_WEEKEND_VALIDATED
        !weekend -> EvidenceStrengthData.FALLBACK_WEEKDAY_VALIDATED
        else -> EvidenceStrengthData.FALLBACK_WEEKEND_VALIDATED
    }[grade]

    // ---------------- live quotes ----------------

    fun quotesFromRates(rows: List<RateRow>): Map<String, LiveQuote> = rows.mapNotNull { r ->
        val p = r.price; val t = r.sourceEpochMs
        if (p != null && p.isFinite() && p > 0.0 && t != null && t > 0L && r.freshnessStatus == "LIVE") r.instrument to LiveQuote(p, t) else null
    }.toMap()

    fun newestQuotes(vararg sources: Map<String, LiveQuote>): Map<String, LiveQuote> {
        val out = HashMap<String, LiveQuote>()
        for (s in sources) for ((k, q) in s) { val old = out[k]; if (old == null || q.epochMs > old.epochMs) out[k] = q }
        return out
    }

    /** Live price for [instrument] taken in [B-40 s, B+1 s]; null when missing or stale. */
    fun freshPrice(quotes: Map<String, LiveQuote>, instrument: String, boundaryEpochSec: Long): Double? {
        val q = quotes[instrument] ?: return null
        val b = boundaryEpochSec * 1000L
        return if (q.price.isFinite() && q.price > 0.0 && q.epochMs >= b - LIVE_MAX_AGE_MS && q.epochMs <= b + 1_000L) q.price else null
    }

    // ---------------- adaptive threshold state ----------------

    private class Buffer { val boundaries = ArrayDeque<Long>(); val values = ArrayDeque<Double>(); val strengths = ArrayDeque<Double>() }
    private val buffers = ConcurrentHashMap<String, Buffer>()
    private fun key(fresh: Boolean, weekend: Boolean) = (if (fresh) "fresh" else "fallback") + "|" + (if (weekend) "weekend" else "weekday")

    @Synchronized fun resetState() = buffers.clear()
    @Synchronized fun bufferSize(fresh: Boolean, weekend: Boolean): Int = buffers[key(fresh, weekend)]?.values?.size ?: 0

    /** numpy.quantile(..., method="linear") */
    fun quantile(values: List<Double>, q: Double): Double {
        require(values.isNotEmpty())
        val a = values.sorted(); val pos = q * (a.size - 1)
        val lo = floor(pos).toInt(); val hi = ceil(pos).toInt()
        return a[lo] + (a[hi] - a[lo]) * (pos - lo)
    }

    /** Share of [values] strictly below [a] (numpy: (ref < a).mean()). */
    fun shareBelow(values: Collection<Double>, a: Double): Double {
        var n = 0; for (v in values) if (v < a) n++
        return n.toDouble() / values.size
    }

    /** Percentile of [a] in the one-year table (201 quantiles), linear between points. Used until 96 slots are seen. */
    fun seedPct(table: DoubleArray, a: Double): Double {
        if (a <= table.first()) return 0.0
        if (a >= table.last()) return 1.0
        var i = 0
        while (i < table.size - 2 && table[i + 1] <= a) i++
        val span = table[i + 1] - table[i]
        val frac = if (span > 0.0) (a - table[i]) / span else 0.0
        return (i + frac) / (table.size - 1)
    }

    private fun seedTable(fresh: Boolean, weekend: Boolean): DoubleArray = when {
        fresh && !weekend -> EvidenceStrengthData.FRESH_WEEKDAY_ADJ_QUANTILES
        fresh -> EvidenceStrengthData.FRESH_WEEKEND_ADJ_QUANTILES
        !weekend -> EvidenceStrengthData.FALLBACK_WEEKDAY_ADJ_QUANTILES
        else -> EvidenceStrengthData.FALLBACK_WEEKEND_ADJ_QUANTILES
    }

    /** Neutral inputs for callers without candle features (tests): no last-minute move, average volatility. */
    fun neutralInputs(choice: Choice, hourJst: Int = 12, dayOfWeek: Int = 3) = EvidenceStrength.Inputs(
        choice.instrument, if (choice.direction == "HIGH") 1 else -1, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, hourJst, dayOfWeek)

    fun hourOffset(fresh: Boolean, weekend: Boolean, hourJst: Int): Double {
        val arr = when {
            fresh && !weekend -> EvidenceModelData.FRESH_WEEKDAY_HOUR_OFFSET
            fresh -> EvidenceModelData.FRESH_WEEKEND_HOUR_OFFSET
            !weekend -> EvidenceModelData.FALLBACK_WEEKDAY_HOUR_OFFSET
            else -> EvidenceModelData.FALLBACK_WEEKEND_HOUR_OFFSET
        }
        return arr[(hourJst - 9).coerceIn(0, arr.size - 1)]
    }

    /** Strength decision; [record] appends this slot to the rolling distributions (AUTO slots only). */
    @Synchronized
    fun decide(choice: Choice, weekend: Boolean, boundaryEpochSec: Long, record: Boolean): Decision {
        val buf = buffers.getOrPut(key(choice.fresh, weekend)) { Buffer() }
        val fromSeed = buf.values.size < BUFFER_MIN
        val pct = if (fromSeed) seedPct(seedTable(choice.fresh, weekend), choice.adjusted) else shareBelow(buf.values, choice.adjusted)
        val x = (choice.inputs ?: neutralInputs(choice)).copy(pct = pct)
        val m = models(choice.fresh, weekend)
        val e = EvidenceStrength.probability(m.entry, x)
        val r = if (weekend) e else EvidenceStrength.probability(m.rank, x)
        val enter: Boolean
        val grade: String
        if (!weekend) {
            val strengthSeed = buf.strengths.size < BUFFER_MIN
            val q = if (strengthSeed) null else shareBelow(buf.strengths, e)
            val seedEnter = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKDAY_SEED_ENTER else EvidenceStrengthData.FALLBACK_WEEKDAY_SEED_ENTER
            val seedDe = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKDAY_SEED_DE else EvidenceStrengthData.FALLBACK_WEEKDAY_SEED_DE
            enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE
            val upperSkip = if (q == null) e >= seedDe else q >= (1.0 - WEEKDAY_ENTRY_RATE) / 2.0
            val c = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKDAY_RANK_CUTS else EvidenceStrengthData.FALLBACK_WEEKDAY_RANK_CUTS
            grade = if (enter) (if (r >= c[0]) "S" else if (r >= c[1]) "A" else if (r >= c[2]) "B" else "C") else if (upperSkip) "D" else "E"
        } else {
            val c = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKEND_CUTS else EvidenceStrengthData.FALLBACK_WEEKEND_CUTS
            enter = e >= c[0]
            grade = if (enter) (if (e >= c[1]) "S" else if (e >= c[2]) "A" else if (e >= c[3]) "B" else "C")
                else if (e >= c[4]) "D" else if (e >= c[5]) "E" else if (e >= c[6]) "F" else if (e >= c[7]) "G" else "H"
        }
        val group = EvidenceStrength.dominantGroup(if (enter) m.rank else m.entry, x, weakest = !enter)
        val reason = (if (enter) EvidenceStrength.REASON_STRONG else EvidenceStrength.REASON_SKIP).getValue(group)
        if (record && buf.boundaries.lastOrNull() != boundaryEpochSec) {
            buf.boundaries.addLast(boundaryEpochSec); buf.values.addLast(choice.adjusted); buf.strengths.addLast(e)
            while (buf.values.size > bufferLimit(weekend)) { buf.values.removeFirst(); buf.boundaries.removeFirst(); buf.strengths.removeFirst() }
        }
        return Decision(choice, pct, e, r, enter, grade, fromSeed, group, reason)
    }

    // ---------------- model choice ----------------

    /** Best (instrument, direction) for this slot, or null when no candidate has a 61-minute window. */
    fun choose(native: ScanResult, candles: Map<String, List<Candle>>, quotes: Map<String, LiveQuote>, entry: ZonedDateTime): Choice? {
        val j = entry.withZoneSameInstant(JST)
        val weekend = !TradingSession.isWeekday(j)
        val b = entry.toEpochSecond()
        val pool = native.candidates.filter { !weekend || it.instrument == "BTCJPY" }
            .sortedBy { EvidenceFeatures.INSTRUMENTS.indexOf(it.instrument).let { i -> if (i < 0) 99 else i } }
        if (pool.isEmpty()) return null
        val live = pool.associate { it.instrument to freshPrice(quotes, it.instrument, b) }
        val fresh = live.values.all { it != null }
        val feats = LinkedHashMap<String, EvidenceFeatures.Instrument>()
        for (c in pool) EvidenceFeatures.instrument(c.instrument, candles[c.instrument].orEmpty(), b, if (fresh) live[c.instrument] else null)?.let { feats[c.instrument] = it }
        if (feats.isEmpty()) return null
        val yen = EvidenceFeatures.yenFactor(feats)
        val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback
        var best: Choice? = null
        for (c in pool) {
            val x = feats[c.instrument] ?: continue
            for (d in intArrayOf(1, -1)) {
                val p = model.probability(EvidenceFeatures.design(x, yen, c, j.hour, weekend, d, fresh))
                if (best == null || p > best.probability) {
                    best = Choice(c.instrument, if (d == 1) "HIGH" else "LOW", p, p - hourOffset(fresh, weekend, j.hour), fresh,
                        EvidenceStrength.Inputs.of(x, d, j.hour, j.dayOfWeek.value))
                }
            }
        }
        if (best != null && fresh) {
            val x = feats.getValue(best.instrument)
            val codes = runCatching { PatternFeatures.codes(x, candles[best.instrument].orEmpty(), b, live[best.instrument], yen, j, weekend) }.getOrNull()
            best = best.copy(patternCodes = codes)
        }
        return best
    }

    // ---------------- final decision ----------------

    fun apply(native: ScanResult, result: ScanResult, candles: Map<String, List<Candle>>, quotes: Map<String, LiveQuote> = emptyMap()): ScanResult {
        val entry = runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return skipTop(result, "エントリー時刻不明")
        if (!TradingSession.isActive(entry)) return skipTop(result, "${TradingSession.LABEL} 外")
        val weekend = !TradingSession.isWeekday(entry.withZoneSameInstant(JST))
        val choice = runCatching { choose(native, candles, quotes, entry) }.getOrNull() ?: return skipTop(result, "1分足61本の連続データ不足")
        val target = native.candidates.firstOrNull { it.instrument == choice.instrument } ?: return skipTop(result, "候補なし")
        val nativeTop = native.top1 ?: target
        val decision = decide(choice, weekend, entry.toEpochSecond(), record = native.source == "AUTO")
        val dirInt = if (choice.direction == "HIGH") 1 else -1
        val pm = if (choice.fresh) choice.patternCodes?.let { EvidencePatterns.decide(it, dirInt, decision.enter) } else null
        val reversed = pm?.reversal == true
        val finalDirection = if (reversed) (if (choice.direction == "HIGH") "LOW" else "HIGH") else choice.direction
        val enter = pm != null || decision.enter
        val grade = when { pm != null -> EvidencePatterns.grade(pm.pattern.rate); decision.enter -> "C"; else -> decision.grade }
        val rate = gradeRate(choice.fresh, weekend, grade)
        val rateText = rate?.let { "1年 ${"%.1f".format(it * 100.0)}%" } ?: "1年の記録なし"
        val pct = "%.1f".format(choice.probability * 100.0)
        val modelLabel = if (choice.fresh) "直前価格あり" else "直前価格なし・予備モデル"
        val seg = if (weekend) "土日BTC" else "平日"
        val label = when {
            pm != null && reversed -> "反転 $grade（$seg・$rateText）${choice.direction}→$finalDirection: ${pm.pattern.label}（そのままでは負けやすい形・反転で1年 ${"%.1f".format(pm.pattern.rate)}%）"
            pm != null -> "勝ちパターン $grade（$seg・$rateText）$finalDirection: ${pm.pattern.label}（形の1年 ${"%.1f".format(pm.pattern.rate)}%）"
            decision.enter -> "検証モデル C（$seg・$rateText）$finalDirection 勝ちパターンなし / 強み: ${decision.reason} / $modelLabel"
            else -> "見送り $grade（$seg・$rateText）理由: ${decision.reason} / ${choice.direction} 強さ ${"%.1f".format(decision.strength * 100.0)}% / $modelLabel"
        }
        val patternNote = pm?.let { " ${if (it.reversal) "REV" else "WIN"}#${it.pattern.index} rate=${it.pattern.rate} min=${it.pattern.minRate}" } ?: ""
        val note = "$VERSION p=$pct% adj=${"%+.4f".format(choice.adjusted)} pct=${"%.3f".format(decision.pct)} e=${"%.4f".format(decision.strength)}" +
            " r=${"%.4f".format(decision.rankStrength)} ${if (decision.fromSeed) "seed" else "rolling"} ${if (choice.fresh) "fresh" else "fallback"}" +
            " ${decision.reasonGroup} v0748=${decision.grade}$patternNote -> $grade/${if (enter) "ENTRY" else "SKIP"} $finalDirection"
        val action = if (enter) "ENTRY" else "SKIP"
        val chosen = target.copy(
            rank = 1, direction = finalDirection, grade = grade, decision = action,
            probability = if (reversed) pm!!.pattern.rate / 100.0 else choice.probability,
            reasons = listOf("判定: 3分", note) + target.reasons.filterNot { it.startsWith("判定:") },
            assessment = CandidateAssessmentFactory.correction(target, nativeTop, finalDirection, grade, action, 3, label,
                if (enter) null else CandidateSkipReason.LOW_EXPECTANCY)
        )
        val others = native.candidates.filter { it.instrument != target.instrument }.mapIndexed { i, c -> c.copy(rank = i + 2) }
        val suffix = if (result.policyVersion.endsWith("_3M_FIXED")) "_3M_FIXED" else ""
        val warnings = result.warnings + listOfNotNull(if (choice.fresh) null else "$VERSION: 直前価格が40秒以内に取れない通貨あり → 予備モデル")
        return native.copy(judgeTimeJst = entry.plusMinutes(3).toString(), candidates = listOf(chosen) + others,
            warnings = warnings.distinct(), policyVersion = POLICY_TAG + suffix)
    }

    /** Fail-safe: keep the overlay result but never ENTER; the top slot is marked I (no evidence decision possible). */
    private fun skipTop(result: ScanResult, why: String): ScanResult {
        val top = result.top1 ?: return result
        if (top.grade == "I" && top.decision == "SKIP") return result
        val note = "$VERSION: ${CandidateSkipReason.OBSERVE_ONLY.label} ($why) -> I/SKIP（判定不能）"
        val assessment = top.assessment?.let { a ->
            a.copy(operationalGrade = "I", decision = "SKIP", skipReason = CandidateSkipReason.OBSERVE_ONLY,
                chosenAction = a.chosenAction.copy(operationalGrade = "I", decision = "SKIP"))
        }
        val updated = top.copy(grade = "I", decision = "SKIP", reasons = top.reasons + note, assessment = assessment)
        return result.copy(candidates = result.candidates.map { if (it.rank == top.rank) updated else it })
    }
}

/** Newest Yahoo meta quote seen while fetching scan candles (written by MarketRepository). */
object LiveQuoteBoard {
    private val quotes = ConcurrentHashMap<String, EvidencePolicy.LiveQuote>()
    fun record(instrument: String, price: Double, epochMs: Long) {
        if (!(price.isFinite() && price > 0.0) || epochMs <= 0L) return
        quotes.merge(instrument, EvidencePolicy.LiveQuote(price, epochMs)) { old, new -> if (new.epochMs >= old.epochMs) new else old }
    }
    fun snapshot(): Map<String, EvidencePolicy.LiveQuote> = HashMap(quotes)
    fun clear() = quotes.clear()
}

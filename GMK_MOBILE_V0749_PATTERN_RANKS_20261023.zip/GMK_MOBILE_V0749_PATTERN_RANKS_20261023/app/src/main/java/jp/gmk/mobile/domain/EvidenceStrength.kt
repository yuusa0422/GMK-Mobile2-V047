package jp.gmk.mobile.domain

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max

/**
 * v0.7.48 second stage: "strength" = validated chance that the chosen trade wins, from a few robust inputs.
 * Exact port of scripts/design_x.py F() / fit_strength_production.py. One-year research (other-half scoring):
 *  - FX: a sharp last-minute move faded (|f1| >= 2.5 sigma) and a strong 15-minute move faded win 56-57%.
 *  - BTC on weekdays: following a 0.5-3 sigma last-minute move wins 55-58%.
 *  - Weekend BTC: when the price stood still (no change in the last minute, many equal 3-minute prices in the
 *    last hour) the trade ends as a draw (= loss) 37-50% of the time; win rates fall to 26-42%.
 *  - Reversing the direction never helped: the opposite side of every skipped group won less (24-48%).
 */
object EvidenceStrength {
    data class Model(val cols: List<String>, val coef: DoubleArray, val intercept: Double, val mean: DoubleArray, val groups: List<String>) {
        init { require(cols.size == coef.size && cols.size == mean.size && cols.size == groups.size) }
    }

    /** Inputs of the chosen trade. [direction] +1 HIGH / -1 LOW, [dayOfWeek] 1 = Monday .. 7 = Sunday (ISO). */
    data class Inputs(
        val instrument: String, val direction: Int, val pct: Double,
        val f1: Double, val r1: Double, val r15: Double, val rv60: Double, val tie58: Double, val zero30: Double,
        val hourJst: Int, val dayOfWeek: Int
    ) {
        companion object {
            fun of(x: EvidenceFeatures.Instrument, direction: Int, hourJst: Int, dayOfWeek: Int) =
                Inputs(x.instrument, direction, 0.0, x.f1, x.r1, x.r15, x.rv60, x.tie58, x.zero30, hourJst, dayOfWeek)
        }
    }

    val REASON_SKIP = mapOf(
        "edge" to "予測の強さが直近の枠の中で下位",
        "move" to "直前の値動きが小さく手がかりが弱い",
        "quiet" to "相場全体の値動きが小さい（静かな時間）",
        "tie" to "引き分けになりやすい（価格が止まりがち）",
        "time" to "弱い時間帯・曜日（9時台・月曜）"
    )
    val REASON_STRONG = mapOf(
        "edge" to "予測の強さが直近の枠の中で上位",
        "move" to "直前の急変の戻り・BTCの勢い",
        "quiet" to "相場の値動きが大きい",
        "tie" to "引き分けになりにくい",
        "time" to "強い時間帯（10時台）"
    )

    fun feature(name: String, x: Inputs): Double {
        val btc = x.instrument == "BTCJPY"
        val d = x.direction.toDouble()
        val af1 = abs(x.f1)
        return when (name) {
            "pct" -> x.pct
            "hinge" -> max(x.pct - 0.9, 0.0) * 10.0
            "af1" -> af1.coerceIn(0.0, 4.0)
            "ar1" -> abs(x.r1).coerceIn(0.0, 4.0)
            "lrv" -> ln(x.rv60).coerceIn(-2.5, 3.5)
            "fx_fade_big" -> if (!btc && x.f1 * d < 0.0 && af1 >= 2.5) 1.0 else 0.0
            "btc_follow" -> if (btc && x.f1 * d > 0.0 && af1 >= 0.5 && af1 < 3.0) 1.0 else 0.0
            "fx_fade15" -> if (!btc && x.r15 * d <= -1.5) 1.0 else 0.0
            "btc_af1" -> if (btc && af1 >= 0.5 && af1 < 3.0) 1.0 else 0.0
            "flat" -> if (af1 < 0.01) 1.0 else 0.0
            "tie58" -> x.tie58
            "zero30" -> x.zero30
            "h9" -> if (x.hourJst == 9) 1.0 else 0.0
            "h10" -> if (x.hourJst == 10) 1.0 else 0.0
            "mon" -> if (x.dayOfWeek == 1) 1.0 else 0.0
            else -> error("unknown strength input $name")
        }
    }

    fun row(m: Model, x: Inputs): DoubleArray = DoubleArray(m.cols.size) { feature(m.cols[it], x) }

    fun probability(m: Model, x: Inputs): Double {
        val r = row(m, x)
        var z = m.intercept
        for (i in r.indices) z += m.coef[i] * r[i]
        return 1.0 / (1.0 + exp(-z))
    }

    /** Input group that pulls the strength down the most (skips) or up the most (entries), versus the yearly average. */
    fun dominantGroup(m: Model, x: Inputs, weakest: Boolean): String {
        val r = row(m, x)
        val sums = sortedMapOf<String, Double>()
        for (i in r.indices) sums.merge(m.groups[i], m.coef[i] * (r[i] - m.mean[i]), Double::plus)
        var best: String? = null; var bv = 0.0
        for ((g, v) in sums) if (best == null || (if (weakest) v < bv else v > bv)) { best = g; bv = v }
        return best!!
    }
}

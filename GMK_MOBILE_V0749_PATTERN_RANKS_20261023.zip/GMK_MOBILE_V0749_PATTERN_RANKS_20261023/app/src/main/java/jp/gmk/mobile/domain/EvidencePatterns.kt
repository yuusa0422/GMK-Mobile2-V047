package jp.gmk.mobile.domain

import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import kotlin.math.sqrt

/**
 * v0.7.49 chart-pattern codes and pattern ranks. Exact port of scripts/pattern_features.py + pattern_codes.py.
 * Inputs: the same 61 complete 1-minute bars as EvidenceFeatures (opens B-3720 .. B-120) and the live price.
 * Code values: 0 = not computable, otherwise level + 1 (levels as in pattern_codes.codes()).
 */
object PatternFeatures {
    val NAMES: List<String> = EvidencePatternData.NAMES
    private val INDEX = NAMES.withIndex().associate { it.value to it.index }
    fun index(name: String): Int = INDEX[name] ?: error("unknown pattern input $name")

    /** pandas.cut(include_lowest=True) bin index, -1 outside the edges or NaN. */
    fun binv(v: Double, e: DoubleArray): Int {
        if (v.isNaN() || v < e[0] || v > e[e.size - 1]) return -1
        if (v == e[0]) return 0
        for (i in 0 until e.size - 1) if (v > e[i] && v <= e[i + 1]) return i
        return -1
    }

    private fun bin(name: String, v: Double) = binv(v, EvidencePatternData.EDGES.getValue(name))

    /** Codes for one instrument, or null when the 61-bar window is incomplete or the live price is missing. */
    fun codes(x: EvidenceFeatures.Instrument, candles: List<Candle>, boundaryEpochSec: Long, live: Double?, yen: EvidenceFeatures.YenFactor,
              entryJst: ZonedDateTime, weekend: Boolean): IntArray? {
        if (live == null || !live.isFinite() || live <= 0.0) return null
        val w = EvidenceFeatures.window(candles, boundaryEpochSec) ?: return null
        val n = w.size
        val o = DoubleArray(n) { w[it].open }; val h = DoubleArray(n) { w[it].high }; val l = DoubleArray(n) { w[it].low }; val c = DoubleArray(n) { w[it].close }
        val btc = x.instrument == "BTCJPY"
        // last complete bar shape
        val rng = max(h[n - 1] - l[n - 1], 1e-12); val body = c[n - 1] - o[n - 1]
        val bodyR = abs(body) / rng; val upW = (h[n - 1] - max(o[n - 1], c[n - 1])) / rng; val loW = (min(o[n - 1], c[n - 1]) - l[n - 1]) / rng
        val prevBody = c[n - 2] - o[n - 2]
        var engulf = 0
        if (body * prevBody < 0 && abs(body) > abs(prevBody) && max(o[n - 1], c[n - 1]) >= max(o[n - 2], c[n - 2]) && min(o[n - 1], c[n - 1]) <= min(o[n - 2], c[n - 2]))
            engulf = if (body > 0) 1 else -1
        // consecutive same-direction moves ending with the live move (closes + live)
        val seq = DoubleArray(n + 1) { if (it < n) c[it] else live }
        val d = IntArray(n) { sign(seq[it + 1] - seq[it]).toInt() }
        val last = d[n - 1]
        var streak = 0
        if (last != 0) {
            var k = 0
            for (i in n - 1 downTo 0) { if (d[i] == last) k++ else break }
            streak = last * min(k, 8)
        }
        var hi15 = h[n - 15]; var lo15 = l[n - 15]
        for (i in n - 15 until n) { hi15 = max(hi15, h[i]); lo15 = min(lo15, l[i]) }
        var hi60 = h[0]; var lo60 = l[0]
        for (i in 0 until n) { hi60 = max(hi60, h[i]); lo60 = min(lo60, l[i]) }
        val brk15 = if (live > hi15) 1 else if (live < lo15) -1 else 0
        val brk60 = if (live > hi60) 1 else if (live < lo60) -1 else 0
        // RSI over the last 14 moves of closes + live
        var gain = 0.0; var loss = 0.0
        for (i in n - 14 until n) { val dd = seq[i + 1] - seq[i]; if (dd > 0) gain += dd else if (dd < 0) loss -= dd }
        val rsi = if (gain + loss == 0.0) 50.0 else 100.0 * gain / (gain + loss)
        val hh = if (h[n - 1] > h[n - 2] && h[n - 2] > h[n - 3]) 1 else 0
        val ll = if (l[n - 1] < l[n - 2] && l[n - 2] < l[n - 3]) 1 else 0
        var s2 = 0.0; for (i in 1 until n) { val r = ln(c[i]) - ln(c[i - 1]); s2 += r * r }
        val norm = max(sqrt(s2 / (n - 1)), 1e-8)
        val grid = if (btc) 100000.0 else 0.5
        val rn = Math.rint(live / grid) * grid
        val rdist = (live - rn) / (live * norm)
        val lb = sign(live - c[n - 1]).toInt()
        val p3 = (sign(c[n - 2] - o[n - 2]).toInt() + 1) * 9 + (sign(body).toInt() + 1) * 3 + (lb + 1)
        var sr = 0.0; for (i in n - 20 until n) sr += h[i] - l[i]
        val rngX = rng / (sr / 20.0 + 1e-12)
        var sc = 0.0; for (v in c) sc += v
        val dmean = (live - sc / n) / (live * norm)
        val hiL = max(hi60, live); val loL = min(lo60, live)
        val pos60L = (live - loL) / max(hiL - loL, 1e-12) * 2 - 1
        val shape = when { bodyR < 0.15 -> 0; loW >= 0.6 -> 1; upW >= 0.6 -> 2; bodyR >= 0.8 -> 3; else -> 4 }
        val cuts = EvidencePatternData.VOL_CUTS.getValue(x.instrument)
        var vol = 0; for (v in cuts) if (x.rv60 > v) vol++
        val yenCode = if (btc) 3 else (sign(yen.yenF1) * sign(x.f1)).toInt() + 1
        val tieCode = if (btc) bin("tie", x.tie58) else 4
        val minute = entryJst.minute
        val minuteCode = if (minute == 0 || minute == 30) 0 else if (minute == 15 || minute == 45) 1 else 2
        val raw = IntArray(NAMES.size)
        fun put(name: String, v: Int) { raw[index(name)] = v }
        put("inst", EvidenceFeatures.INSTRUMENTS.indexOf(x.instrument))
        put("seg", if (weekend) 1 else 0)
        put("hour", bin("hour", entryJst.hour.toDouble()))
        put("f1", bin("f1", x.f1)); put("f5", bin("f5", x.f5)); put("r3", bin("r3", x.r3)); put("r15", bin("r15", x.r15)); put("r60", bin("r60", x.r60))
        put("rsi", bin("rsi", rsi)); put("bbzL", bin("bbzL", x.bbzLive)); put("pos15L", bin("pos15L", x.pos15Live)); put("pos60L", bin("pos60L", pos60L))
        put("round", bin("round", rdist)); put("rngx", bin("rngx", rngX)); put("squeeze", bin("squeeze", x.rv30over60)); put("dmean", bin("dmean", dmean))
        put("streak", streak.coerceIn(-5, 5) + 5)
        put("bar", shape * 3 + (sign(body).toInt() + 1))
        put("engulf", engulf + 1); put("brk15", brk15 + 1); put("brk60", brk60 + 1); put("hhll", hh * 2 + ll); put("p3", p3)
        put("vol", vol); put("yen", yenCode); put("tie", tieCode); put("minute", minuteCode); put("dow", entryJst.dayOfWeek.value - 1)
        return IntArray(raw.size) { if (raw[it] < 0) 0 else raw[it] + 1 }
    }

    private val NLEV = mapOf("f1" to 7, "f5" to 5, "r3" to 5, "r15" to 5, "r60" to 5, "rsi" to 5, "bbzL" to 7, "pos15L" to 5, "pos60L" to 5,
        "round" to 5, "dmean" to 5, "streak" to 11, "engulf" to 3, "brk15" to 3, "brk60" to 3)

    /** Trade-relative codes: for a LOW trade every price-direction condition is mirrored (pattern_codes.flip). */
    fun flip(codes: IntArray, direction: Int): IntArray {
        val g = codes.copyOf()
        if (direction != -1) return g
        for ((name, nl) in NLEV) { val i = index(name); val v = codes[i]; g[i] = if (v == 0) 0 else nl + 1 - v }
        run {
            val i = index("bar"); val b = codes[i] - 1
            val shape = Math.floorDiv(b, 3); val dd = Math.floorMod(b, 3)
            val sf = when (shape) { 1 -> 2; 2 -> 1; else -> shape }
            g[i] = sf * 3 + (2 - dd) + 1
        }
        run { val i = index("hhll"); val hv = codes[i] - 1; g[i] = (when (hv) { 1 -> 2; 2 -> 1; else -> hv }) + 1 }
        run {
            val i = index("p3"); val p = codes[i] - 1
            val a = Math.floorDiv(p, 9); val b = Math.floorMod(Math.floorDiv(p, 3), 3); val c = Math.floorMod(p, 3)
            g[i] = (2 - a) * 9 + (2 - b) * 3 + (2 - c) + 1
        }
        return g
    }
}

object EvidencePatterns {
    /** One pattern: conditions on codes (name -> code), side HIGH/LOW/REV, one-year rate and lowest period rate (percent). */
    data class Pattern(val index: Int, val side: String, val rate: Double, val minRate: Double, val conditions: List<Pair<Int, Int>>, val label: String)
    data class Match(val pattern: Pattern, val reversal: Boolean)

    const val DIR = -1      // pseudo inputs of reversal patterns
    const val ENTRY = -2

    private fun parse(text: String): List<Pattern> = text.split('\n').filter { it.isNotBlank() }.mapIndexed { i, line ->
        val p = line.split(';', limit = 5)
        val conds = p[3].split(',').map { kv ->
            val (k, v) = kv.split('=')
            (when (k) { "dir" -> DIR; "entry" -> ENTRY; else -> PatternFeatures.index(k) }) to v.toInt()
        }
        Pattern(i, p[0], p[1].toDouble(), p[2].toDouble(), conds, p[4])
    }
    val win: List<Pattern> by lazy { parse(EvidencePatternData.winText()).also { check(it.size == EvidencePatternData.WIN_COUNT) } }
    val reversal: List<Pattern> by lazy { parse(EvidencePatternData.reversalText()).also { check(it.size == EvidencePatternData.REVERSAL_COUNT) } }

    private fun better(p: Pattern, best: Pattern?) = best == null || p.minRate > best.minRate || (p.minRate == best.minRate && p.rate > best.rate)

    /** Best same-direction win pattern for the trade (absolute codes). */
    fun bestWin(codes: IntArray, direction: Int): Pattern? {
        val side = if (direction == 1) "HIGH" else "LOW"
        var best: Pattern? = null
        for (p in win) if (p.side == side && p.conditions.all { (i, v) -> codes[i] == v } && better(p, best)) best = p
        return best
    }

    /** Best reversal pattern for the trade (trade-relative codes + direction + v0.7.48 ENTRY flag). */
    fun bestReversal(relCodes: IntArray, direction: Int, entered: Boolean): Pattern? {
        val dirCode = if (direction == 1) 2 else 1; val entCode = if (entered) 2 else 1
        var best: Pattern? = null
        for (p in reversal) {
            val ok = p.conditions.all { (i, v) -> when (i) { DIR -> dirCode == v; ENTRY -> entCode == v; else -> relCodes[i] == v } }
            if (ok && better(p, best)) best = p
        }
        return best
    }

    /** Reversal wins only when its lowest period is strictly higher than the best same-direction win pattern. */
    fun decide(codes: IntArray, direction: Int, entered: Boolean): Match? {
        val w = bestWin(codes, direction)
        val r = bestReversal(PatternFeatures.flip(codes, direction), direction, entered)
        return when {
            r != null && (w == null || r.minRate > w.minRate) -> Match(r, true)
            w != null -> Match(w, false)
            else -> null
        }
    }

    fun grade(rate: Double): String = if (rate >= 65.0) "S" else if (rate >= 62.0) "A" else "B"
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId

/** v0.7.49: Kotlin pattern codes / flip / matching = Python research (scripts/gen_kotlin_patterns.py, real one-year slots). */
class PatternParityTest {
    private val lines: List<List<String>> by lazy {
        javaClass.classLoader!!.getResourceAsStream("v0749_pattern_parity.txt")!!.bufferedReader().readLines().filter { it.isNotBlank() }.map { it.split('|') }
    }
    private fun ints(s: String) = s.split(',').map { it.toInt() }.toIntArray()

    @Test fun codesFromRealCandlesMatchPython() {
        val expected = lines.filter { it[0] == "PCODE" }.associate { (it[1].toLong() to it[2]) to ints(it[3]) }
        assertEquals(114, expected.size)
        var checked = 0
        for (s in EvidenceFixture.slots) {
            val native = s.native()
            val pool = native.candidates.filter { !s.weekend || it.instrument == "BTCJPY" }
            val quotes = s.quotes()
            val feats = LinkedHashMap<String, EvidenceFeatures.Instrument>()
            for (c in pool) EvidenceFeatures.instrument(c.instrument, s.candles()[c.instrument].orEmpty(), s.boundary,
                EvidencePolicy.freshPrice(quotes, c.instrument, s.boundary))?.let { feats[c.instrument] = it }
            val yen = EvidenceFeatures.yenFactor(feats)
            val j = s.entry.withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
            for (c in native.candidates) {
                val want = expected[s.boundary to c.instrument] ?: continue
                val x = feats[c.instrument] ?: EvidenceFeatures.instrument(c.instrument, s.candles()[c.instrument].orEmpty(), s.boundary,
                    EvidencePolicy.freshPrice(quotes, c.instrument, s.boundary))!!
                val got = PatternFeatures.codes(x, s.candles()[c.instrument].orEmpty(), s.boundary, EvidencePolicy.freshPrice(quotes, c.instrument, s.boundary), yen, j, s.weekend)!!
                for (i in want.indices) assertEquals("${s.boundary} ${c.instrument} ${PatternFeatures.NAMES[i]}", want[i], got[i])
                checked++
            }
        }
        assertTrue("checked=$checked", checked >= 100)
    }

    @Test fun flipAndBestMatchMatchPython() {
        val cases = lines.filter { it[0] == "MATCH" }
        assertTrue(cases.size > 1000)
        var hitsW = 0; var hitsR = 0
        for (c in cases) {
            val d = c[1].toInt(); val entered = c[2] == "2"; val codes = ints(c[3])
            assertArrayEquals(ints(c[6]), PatternFeatures.flip(codes, d))
            val w = EvidencePatterns.bestWin(codes, d)
            assertEquals(c.joinToString("|"), c[4].toInt(), w?.index ?: -1)
            val r = EvidencePatterns.bestReversal(PatternFeatures.flip(codes, d), d, entered)
            assertEquals(c.joinToString("|"), c[5].toInt(), r?.index ?: -1)
            if (w != null) hitsW++; if (r != null) hitsR++
        }
        assertTrue(hitsW > 100 && hitsR > 100)
    }

    @Test fun tablesLoadAndGradesFollowTheRate() {
        assertEquals(EvidencePatternData.WIN_COUNT, EvidencePatterns.win.size)
        assertEquals(EvidencePatternData.REVERSAL_COUNT, EvidencePatterns.reversal.size)
        assertTrue(EvidencePatterns.win.all { it.side in setOf("HIGH", "LOW") && it.minRate >= 56.0 && it.label.isNotBlank() })
        assertTrue(EvidencePatterns.reversal.all { it.side == "REV" && it.minRate >= 56.0 })
        assertEquals("S", EvidencePatterns.grade(65.0)); assertEquals("A", EvidencePatterns.grade(64.9)); assertEquals("A", EvidencePatterns.grade(62.0)); assertEquals("B", EvidencePatterns.grade(61.9))
        assertEquals(1, PatternFeatures.binv(-2.0, doubleArrayOf(-3.0, -2.0, -1.0)).let { if (it == 0) 1 else it })
        assertEquals(0, PatternFeatures.binv(-3.0, doubleArrayOf(-3.0, -2.0, -1.0)))
        assertEquals(-1, PatternFeatures.binv(Double.NaN, doubleArrayOf(-3.0, -2.0, -1.0)))
    }
}

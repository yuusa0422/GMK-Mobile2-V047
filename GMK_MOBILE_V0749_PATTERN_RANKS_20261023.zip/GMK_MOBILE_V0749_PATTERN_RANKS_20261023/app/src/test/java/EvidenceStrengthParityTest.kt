import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test

/** v0.7.48: Kotlin strength models = Python research (scripts/gen_strength_fixture.py, real one-year slots). */
class EvidenceStrengthParityTest {
    private val rows: List<List<String>> by lazy {
        javaClass.classLoader!!.getResourceAsStream("v0748_strength_parity.txt")!!.bufferedReader().readLines()
            .filter { it.isNotBlank() && !it.startsWith("#") }.map { it.split('\t') }
    }
    private fun model(key: String): EvidenceStrength.Model = when (key) {
        "fresh_weekday_entry" -> EvidenceStrengthData.FRESH_WEEKDAY_ENTRY
        "fresh_weekday_rank" -> EvidenceStrengthData.FRESH_WEEKDAY_RANK
        "fresh_weekend" -> EvidenceStrengthData.FRESH_WEEKEND
        "fallback_weekday_entry" -> EvidenceStrengthData.FALLBACK_WEEKDAY_ENTRY
        "fallback_weekday_rank" -> EvidenceStrengthData.FALLBACK_WEEKDAY_RANK
        "fallback_weekend" -> EvidenceStrengthData.FALLBACK_WEEKEND
        else -> error(key)
    }
    private fun inputs(r: List<String>) = EvidenceStrength.Inputs(r[1], r[2].toInt(), r[3].toDouble(), r[4].toDouble(), r[5].toDouble(),
        r[6].toDouble(), r[7].toDouble(), r[8].toDouble(), r[9].toDouble(), r[10].toInt(), r[11].toInt())

    @Test fun probabilitiesAndReasonsMatchPython() {
        val m = rows.filter { it[0] != "seedpct" }
        assertTrue(m.size >= 300)
        for (r in m) {
            val x = inputs(r); val mod = model(r[0])
            assertEquals(r.joinToString(" "), r[12].toDouble(), EvidenceStrength.probability(mod, x), 1e-12)
            assertEquals(r.joinToString(" "), r[13], EvidenceStrength.dominantGroup(mod, x, weakest = true))
            assertEquals(r.joinToString(" "), r[14], EvidenceStrength.dominantGroup(mod, x, weakest = false))
        }
        assertEquals(6, m.map { it[0] }.toSet().size)
    }

    @Test fun seedPercentileMatchesPython() {
        val tables = mapOf("fresh|weekday" to EvidenceStrengthData.FRESH_WEEKDAY_ADJ_QUANTILES, "fresh|weekend" to EvidenceStrengthData.FRESH_WEEKEND_ADJ_QUANTILES,
            "fallback|weekday" to EvidenceStrengthData.FALLBACK_WEEKDAY_ADJ_QUANTILES, "fallback|weekend" to EvidenceStrengthData.FALLBACK_WEEKEND_ADJ_QUANTILES)
        val s = rows.filter { it[0] == "seedpct" }
        assertEquals(28, s.size)
        for (r in s) assertEquals(r.joinToString(" "), r[12].toDouble(), EvidencePolicy.seedPct(tables.getValue(r[1]), r[3].toDouble()), 1e-12)
    }

    @Test fun everyIndicatorIsExercisedAndModelsAreConsistent() {
        val m = rows.filter { it[0] != "seedpct" }
        val seen = mutableSetOf<String>()
        for (r in m) {
            val mod = model(r[0]); val x = inputs(r)
            for ((i, c) in mod.cols.withIndex()) if (EvidenceStrength.feature(c, x) != 0.0 && c !in setOf("pct", "lrv", "af1", "ar1", "tie58", "zero30", "hinge")) seen += c
            assertEquals(mod.cols.size, EvidenceStrength.row(mod, x).size)
        }
        assertTrue(seen.containsAll(listOf("fx_fade_big", "btc_follow", "fx_fade15", "btc_af1", "flat", "h9", "h10", "mon")))
        assertEquals(0.85, EvidenceStrengthData.WEEKDAY_COVER, 0.0)
        assertEquals(0.55, EvidenceStrengthData.WEEKEND_COVER, 0.0)
        for (c in listOf(EvidenceStrengthData.FRESH_WEEKDAY_RANK_CUTS, EvidenceStrengthData.FALLBACK_WEEKDAY_RANK_CUTS)) assertTrue(c[0] > c[1] && c[1] > c[2])
        for (c in listOf(EvidenceStrengthData.FRESH_WEEKEND_CUTS, EvidenceStrengthData.FALLBACK_WEEKEND_CUTS)) {
            assertTrue(c[1] > c[2] && c[2] > c[3] && c[0] > c[4] && c[4] > c[5] && c[5] > c[6] && c[6] > c[7])
            assertEquals("weekend B = rest of the entries (C unused)", c[0], c[3], 0.0)
        }
    }
}

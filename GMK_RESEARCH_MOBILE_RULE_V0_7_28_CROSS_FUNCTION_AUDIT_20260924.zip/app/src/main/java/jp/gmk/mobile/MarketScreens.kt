package jp.gmk.mobile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay
import java.time.ZonedDateTime
import java.time.ZoneId
import kotlin.math.max
import kotlin.math.min

private val Night = Color(0xFF07142A)
private val Panel = Color(0xE212203D)
private val Pink = Color(0xFFFF4F91)
private val Cyan = Color(0xFF35D9FF)
private val Purple = Color(0xFF9E6CFF)
private val White = Color(0xFFF6F2FF)
private val Muted = Color(0xFF9FB4D9)
private val Green = Color(0xFF53E6A4)
private val Red = Color(0xFFFF5576)
private val Jst = ZoneId.of("Asia/Tokyo")
private val instruments = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
private val timeframes = listOf("1m", "5m", "15m", "1h", "4h", "1d")

@Composable
fun ChartScreen(
    state: GmkUiState,
    instrument: String,
    timeframe: String,
    focusHistory: HistoryRow?,
    autoFollowScan: Boolean,
    onToggleAutoFollow: () -> Unit,
    onInstrument: (String) -> Unit,
    onTimeframe: (String) -> Unit,
    onRefresh: (String, String, Long?) -> Unit
) {
    val focusMs = remember(focusHistory?.id) { focusHistory?.entryTimeJst?.let(::parseJstMs) }
    LaunchedEffect(instrument, timeframe, focusHistory?.id) {
        onRefresh(instrument, timeframe, focusMs)
        if (focusHistory == null) {
            while (true) {
                delay(60_000L)
                onRefresh(instrument, timeframe, null)
            }
        }
    }
    val candles = state.chartCandles.takeIf { state.chartInstrument == instrument && state.chartTimeframe == timeframe }.orEmpty()
    val rate = state.rates.firstOrNull { it.instrument == instrument }
    val last = candles.lastOrNull()
    val bollinger = remember(candles) { bollingerBands(candles) }
    val macdRows = remember(candles) { macd(candles) }
    val latestBand = bollinger.lastOrNull()
    val latestMacd = macdRows.lastOrNull()
    val scanCandidate = remember(state.scan, state.oneMinuteScan, instrument) {
        listOfNotNull(
            state.scan?.let { scan -> scan.top1?.takeIf { it.instrument == instrument }?.let { scan.atJst to "${it.direction} / ${it.grade} / ${it.regime}" } },
            state.oneMinuteScan?.let { scan -> scan.top1?.takeIf { it.instrument == instrument }?.let { scan.atJst to "${it.direction} / 1M / ${it.regime}" } }
        ).maxByOrNull { runCatching { ZonedDateTime.parse(it.first).toInstant().toEpochMilli() }.getOrDefault(0L) }
    }
    var chartNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val plannedEntry = latestScanEntry(state, instrument, chartNowMs)
    LaunchedEffect(plannedEntry?.first) {
        val target = plannedEntry?.first ?: return@LaunchedEffect
        val delayMs = target - System.currentTimeMillis()
        if (delayMs > 0L) delay(delayMs)
        chartNowMs = System.currentTimeMillis()
    }
    val strengthForPair = remember(state.strengthCandles) { currencyRelativeStrength(state.strengthCandles) }
    val historyRows = remember(state.history, instrument) { state.history.filter { it.instrument == instrument && it.decision == "ENTRY" }.take(60) }

    Column(
        Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(bottom = 12.dp)
    ) {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF201344), Night))).padding(14.dp)) {
            Text("幻想チャート", color = White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text("市場足・スキャン候補・判定履歴を同じ通貨ペアで確認", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                instruments.forEach { pair ->
                    ChoiceChip(pair, pair == instrument, if (pair == instrument) Pink else Cyan) { onInstrument(pair) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                timeframes.forEach { tf -> ChoiceChip(tf, tf == timeframe, Purple) { onTimeframe(tf) } }
            }
            Spacer(Modifier.height(7.dp))
            ChoiceChip("SCAN追従 ${if (autoFollowScan) "ON" else "OFF"}", autoFollowScan, Cyan, onToggleAutoFollow)
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(instrument, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(if (instrument == "BTCJPY") "Bitcoin / Japanese Yen • bitbank" else "$instrument • Yahoo Finance chart", color = Muted, fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(rate?.price?.let(::formatMarketPrice) ?: "—", color = if (rate?.freshnessStatus == "LIVE") Pink else Color(0xFFFFC76B), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("${rate?.freshnessStatus ?: "取得待ち"}  provider ${rate?.ageSeconds?.let { "%.1fs".format(it) } ?: "—"}", color = Muted, fontSize = 9.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OhlcCell("O", last?.open)
                OhlcCell("H", last?.high)
                OhlcCell("L", last?.low)
                OhlcCell("C", last?.close)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "${if (state.chartLoading) "取得中" else if (candles.isNotEmpty()) "確定足 ${candles.size}本" else "足なし"}  •  更新 ${state.chartUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "—"}",
                color = Muted, fontSize = 10.sp
            )
            state.chartError?.let { Text(it, color = Color(0xFFFFC76B), fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp)) }
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ローソク足 • Bollinger (20, 2)", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("● 上限  ● 中央  ● 下限", color = Muted, fontSize = 9.sp)
            }
            Spacer(Modifier.height(5.dp))
            PriceChart(candles, bollinger, historyRows, focusHistory, timeframe, plannedEntry?.first, plannedEntry?.second)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(candles.firstOrNull()?.timeEpochMs?.let(::formatClock) ?: "", color = Muted, fontSize = 9.sp)
                Text(candles.getOrNull(candles.size / 2)?.timeEpochMs?.let(::formatClock) ?: "", color = Muted, fontSize = 9.sp)
                Text(last?.timeEpochMs?.let(::formatClock) ?: "", color = Muted, fontSize = 9.sp)
            }
            latestBand?.let {
                Text("BB 上 ${formatMarketPrice(it.upper)} / 中 ${formatMarketPrice(it.middle)} / 下 ${formatMarketPrice(it.lower)}", color = Muted, fontSize = 10.sp)
            }
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("MACD (12, 26, 9)", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(latestMacd?.let { "${formatMarketPrice(it.macd)} / ${formatMarketPrice(it.signal)} / ${formatMarketPrice(it.histogram)}" } ?: "—", color = Cyan, fontSize = 10.sp)
            }
            Spacer(Modifier.height(4.dp))
            MacdChart(macdRows)
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("✿ 速報コメント", color = Pink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Text(if (rate?.freshnessStatus == "LIVE") "LIVE" else "取得確認", color = if (rate?.freshnessStatus == "LIVE") Green else Color(0xFFFFC76B), fontSize = 10.sp)
            }
            Spacer(Modifier.height(6.dp))
            val comments = buildList {
                if (state.chartError != null) add("チャート取得注意: ${state.chartError}")
                if (rate == null || rate.price == null) add("リアルタイム価格を取得できていません")
                else if (rate.freshnessStatus != "LIVE") add("取得遅延注意: provider age ${rate.ageSeconds?.let { "%.1f秒".format(it) } ?: "不明"}")
                if (scanCandidate != null) add("自動スキャン候補: $instrument ${scanCandidate.second}")
                if (plannedEntry != null) add("ENTRY予定: ${plannedEntry.second} • ${ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(plannedEntry.first), Jst).toLocalTime().toString().take(8)}")
                val strengthGap = strengthForPair[instrument.removeSuffix("JPY")]?.let { base -> strengthForPair["JPY"]?.let { base - it } }
                if (strengthGap != null) {
                    val aligned = scanCandidate?.let { (it.direction == "HIGH" && strengthGap > 0.0) || (it.direction == "LOW" && strengthGap < 0.0) }
                    add("通貨強弱サブ根拠: ${"%+.2f".format(strengthGap)}% • ${when (aligned) { true -> "方向一致"; false -> "逆行に注意"; null -> "方向比較" }}")
                }
                val settled = state.history.firstOrNull { it.instrument == instrument && it.resultStatus in setOf("WIN", "LOSE") }
                if (settled != null) add("結果確定: ${settled.resultStatus} • ${settled.direction} • ${settled.source}")
                if (state.history.any { it.instrument == instrument && it.resultStatus == "WAIT_JUDGE" }) add("判定待ち: ENTRY後の結果取得中")
                if (last != null && latestBand != null) {
                    val span = (latestBand.upper - latestBand.lower).coerceAtLeast(1e-12)
                    val pos = (last.close - latestBand.lower) / span
                    if (pos >= 0.90) add("ボリンジャー上限付近。反転を含めて次の足を確認")
                    else if (pos <= 0.10) add("ボリンジャー下限付近。反発の有無を確認")
                }
                if (latestMacd != null && macdRows.size >= 2) {
                    val before = macdRows[macdRows.lastIndex - 1]
                    if (before != null && before.macd >= before.signal && latestMacd.macd < latestMacd.signal) add("MACDデッドクロスを確認")
                    else if (before != null && before.macd <= before.signal && latestMacd.macd > latestMacd.signal) add("MACDゴールデンクロスを確認")
                }
                if (isSelectedFocusVisible(candles, focusHistory, timeframe)) add("履歴ENTRY/判定位置をチャート上に表示中")
                if (isSelectedFocusVisible(candles, focusHistory, timeframe).not() && focusHistory != null) add("選択履歴の価格・時刻を下に表示。提供元の期間外で足データはありません")
                if (isEmpty()) add("スキャンと市場データを待っています。条件がそろうまで候補を表示しません")
            }
            comments.take(4).forEach { Text("• $it", color = White, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        }

        focusHistory?.let { HistoryFocusCard(it) }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("チャート上の履歴マーカー", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("ENTRY・判定価格、HIGH/LOW方向、WIN/LOSEを、取得した足の期間内に重ねます。選択中の履歴をタップすると時刻を指定して足を再取得します。", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PriceChart(candles: List<Candle>, bands: List<BollingerPoint?>, rows: List<HistoryRow>, focus: HistoryRow?, timeframe: String, plannedEntryMs: Long?, plannedDirection: String?) {
    Canvas(Modifier.fillMaxWidth().height(230.dp).background(Color(0xCC09142B), RoundedCornerShape(6.dp))) {
        if (candles.isEmpty()) {
            drawLine(Muted.copy(alpha = .5f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.dp.toPx())
            return@Canvas
        }
        val focusEntry = focus?.takeIf { it.decision == "ENTRY" }
        val events = (rows + listOfNotNull(focusEntry)).distinctBy { it.id }
        val period = timeframesToMs(timeframe)
        val start = candles.first().timeEpochMs
        val end = max(candles.last().timeEpochMs + period, (plannedEntryMs ?: 0L) + if (plannedEntryMs == null) 0L else period)
        val prices = buildList {
            candles.forEach { add(it.high); add(it.low) }
            bands.filterNotNull().forEach { add(it.upper); add(it.lower) }
            events.forEach { h ->
                val entryVisible = parseJstMs(h.entryTimeJst)?.let { it in start until end } == true
                val judgeVisible = parseJstMs(h.judgeTimeJst)?.let { it in start until end } == true
                if (entryVisible) h.entryRate?.takeIf { it.isFinite() && it > 0.0 }?.let(::add)
                if (judgeVisible) h.judgeRate?.takeIf { it.isFinite() && it > 0.0 }?.let(::add)
            }
        }
        val minPrice = prices.minOrNull() ?: 0.0
        val maxPrice = prices.maxOrNull() ?: 1.0
        val pad = ((maxPrice - minPrice) * .07).coerceAtLeast(maxPrice * .00002)
        val lo = minPrice - pad
        val hi = maxPrice + pad
        val top = 8.dp.toPx()
        val bottom = size.height - 8.dp.toPx()
        val height = (bottom - top).coerceAtLeast(1f)
        fun y(price: Double): Float = bottom - ((price - lo) / (hi - lo).coerceAtLeast(1e-12)).toFloat() * height
        fun x(time: Long): Float = (((time - start).toDouble() / (end - start).coerceAtLeast(1L)) * size.width).toFloat().coerceIn(0f, size.width)
        val chartSpanMs = (end - start).coerceAtLeast(period).toDouble()
        val candleWidth = (period.toDouble() / chartSpanMs * size.width.toDouble() * .58).toFloat().coerceAtLeast(1.5f)
        for (i in 0..4) {
            val gy = top + height * i / 4f
            drawLine(Color(0x334E6A99), Offset(0f, gy), Offset(size.width, gy), 1.dp.toPx())
        }
        candles.forEachIndexed { i, candle ->
            val cx = x(candle.timeEpochMs + period / 2L)
            val color = if (candle.close >= candle.open) Cyan else Pink
            drawLine(color.copy(alpha = .86f), Offset(cx, y(candle.high)), Offset(cx, y(candle.low)), 1.dp.toPx())
            val yOpen = y(candle.open)
            val yClose = y(candle.close)
            drawRect(color, Offset(cx - candleWidth / 2f, min(yOpen, yClose)), Size(candleWidth, max(2.dp.toPx(), kotlin.math.abs(yOpen - yClose))))
        }
        val upperPath = Path()
        val midPath = Path()
        val lowerPath = Path()
        var pathStarted = false
        bands.forEachIndexed { i, point ->
            if (point == null) { pathStarted = false; return@forEachIndexed }
            val px = x(candles[i].timeEpochMs + period / 2L)
            if (!pathStarted) {
                upperPath.moveTo(px, y(point.upper)); midPath.moveTo(px, y(point.middle)); lowerPath.moveTo(px, y(point.lower))
                pathStarted = true
            } else {
                upperPath.lineTo(px, y(point.upper)); midPath.lineTo(px, y(point.middle)); lowerPath.lineTo(px, y(point.lower))
            }
        }
        drawPath(upperPath, Pink.copy(alpha = .85f), style = androidx.compose.ui.graphics.drawscope.Stroke(1.3.dp.toPx()))
        drawPath(midPath, Color(0xFF81A8FF), style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
        drawPath(lowerPath, Color(0xFF4C9DFF), style = androidx.compose.ui.graphics.drawscope.Stroke(1.3.dp.toPx()))
        events.forEach { h ->
            val winColor = when (h.resultStatus) { "WIN" -> Green; "LOSE" -> Red; else -> Purple }
            val entryTime = parseJstMs(h.entryTimeJst)
            if (entryTime != null && entryTime in start until end) {
                val ex = x(entryTime)
                drawLine(winColor, Offset(ex, top), Offset(ex, bottom), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx())))
                h.entryRate?.takeIf { it.isFinite() && it > 0.0 }?.let { drawCircle(Pink, radius = 3.dp.toPx(), center = Offset(ex, y(it))) }
            }
            val judgeTime = parseJstMs(h.judgeTimeJst)
            if (judgeTime != null && judgeTime in start until end) {
                val jx = x(judgeTime)
                drawLine(winColor.copy(alpha = .8f), Offset(jx, top), Offset(jx, bottom), 1.dp.toPx())
                h.judgeRate?.takeIf { it.isFinite() && it > 0.0 }?.let { drawCircle(winColor, radius = 3.dp.toPx(), center = Offset(jx, y(it))) }
            }
        }
        if (plannedEntryMs != null && plannedEntryMs in start until end) {
            val px = x(plannedEntryMs)
            drawLine(Purple, Offset(px, top), Offset(px, bottom), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 3.dp.toPx())))
            drawCircle(if (plannedDirection == "HIGH") Pink else Cyan, radius = 4.dp.toPx(), center = Offset(px, top + 5.dp.toPx()))
        }
    }
}

@Composable
private fun MacdChart(rows: List<MacdPoint?>) {
    Canvas(Modifier.fillMaxWidth().height(115.dp).background(Color(0xBB0B1530), RoundedCornerShape(6.dp))) {
        val valid = rows.filterNotNull()
        if (valid.isEmpty()) return@Canvas
        val extent = valid.flatMap { listOf(it.macd, it.signal, it.histogram) }.maxOf { kotlin.math.abs(it) }.coerceAtLeast(1e-8)
        val mid = size.height / 2f
        drawLine(Color(0x556D82AB), Offset(0f, mid), Offset(size.width, mid), 1.dp.toPx())
        val slot = size.width / rows.size.coerceAtLeast(1)
        val macdPath = Path(); val signalPath = Path()
        var started = false
        rows.forEachIndexed { i, point ->
            if (point == null) return@forEachIndexed
            val cx = slot * (i + .5f)
            fun py(value: Double) = mid - (value / extent).toFloat() * (size.height * .43f)
            val bar = point.histogram.toFloat() / extent.toFloat() * (size.height * .36f)
            drawRect(if (bar >= 0) Cyan.copy(alpha = .78f) else Pink.copy(alpha = .78f), Offset(cx - max(1.dp.toPx(), slot * .32f), mid - bar.coerceAtLeast(0f)), Size(max(2.dp.toPx(), slot * .64f), max(1.dp.toPx(), kotlin.math.abs(bar))))
            if (!started) { macdPath.moveTo(cx, py(point.macd)); signalPath.moveTo(cx, py(point.signal)); started = true }
            else { macdPath.lineTo(cx, py(point.macd)); signalPath.lineTo(cx, py(point.signal)) }
        }
        drawPath(macdPath, Cyan, style = androidx.compose.ui.graphics.drawscope.Stroke(1.6.dp.toPx(), cap = StrokeCap.Round))
        drawPath(signalPath, Color(0xFFFFA33B), style = androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
    }
}

@Composable
fun CurrencyStrengthScreen(state: GmkUiState, onRefresh: (String) -> Unit, onSelectPair: (String) -> Unit) {
    var timeframe by remember { mutableStateOf(state.strengthTimeframe.ifBlank { "1h" }) }
    var session by remember { mutableStateOf("全時間") }
    var filter by remember { mutableStateOf("すべて") }
    LaunchedEffect(timeframe) {
        onRefresh(timeframe)
        while (true) { delay(120_000L); onRefresh(timeframe) }
    }
    val sessions = listOf("全時間", "東京", "欧州", "米国")
    val filteredCandles = remember(state.strengthCandles, session) {
        state.strengthCandles.mapValues { (_, candles) -> filterSessionWindow(candles, session) }
    }
    val values = remember(filteredCandles) { currencyRelativeStrength(filteredCandles) }
    val allowedPairs = when (filter) {
        "メジャー" -> setOf("USDJPY", "EURJPY", "GBPJPY")
        "高金利" -> setOf("AUDJPY", "NZDJPY")
        "コモディティ" -> setOf("AUDJPY", "NZDJPY")
        "暗号資産" -> setOf("BTCJPY")
        else -> instruments.toSet()
    }
    val candidates = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
        .filter { it in allowedPairs }
        .mapNotNull { pair -> values[pair.removeSuffix("JPY")]?.let { pair to it } }
        .sortedByDescending { kotlin.math.abs(it.second - (values["JPY"] ?: 0.0)) }
    val currencies = listOf("JPY", "USD", "EUR", "GBP", "AUD", "NZD", "BTC")
    val currentCandidate = remember(state.scan, state.oneMinuteScan) {
        val choices = listOfNotNull(
            state.scan?.let { scan -> scan.top1?.let { Triple(scan.atJst, it.instrument, it.direction) } },
            state.oneMinuteScan?.let { scan -> scan.top1?.let { Triple(scan.atJst, it.instrument, it.direction) } }
        )
        choices.maxByOrNull { runCatching { ZonedDateTime.parse(it.first).toInstant().toEpochMilli() }.getOrDefault(0L) }
    }

    Column(Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF201344), Night))).padding(14.dp)) {
            Text("通貨強弱", color = White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text("JPYクロス5通貨とBTCJPYの確定足から算出 • 強弱は対JPY変化率", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                sessions.forEach { ChoiceChip(it, it == session, Pink) { session = it } }
            }
            Spacer(Modifier.height(7.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                timeframes.forEach { ChoiceChip(it, it == timeframe, Purple) { timeframe = it } }
            }
        }
        if (state.strengthLoading) Text("通貨足を取得中…", color = Cyan, modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp), fontSize = 11.sp)
        if (state.strengthErrors.isNotEmpty()) Text("一部データなし: ${state.strengthErrors.keys.joinToString()}", color = Color(0xFFFFC76B), modifier = Modifier.padding(horizontal = 14.dp), fontSize = 10.sp)

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("通貨強弱ランキング", color = White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text("更新 ${state.strengthUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "—"}", color = Muted, fontSize = 9.sp)
            }
            val visible = currencies.mapNotNull { c -> values[c]?.let { c to it } }
                .filter { (c, _) -> filter != "暗号資産" || c == "BTC" }
                .sortedByDescending { it.second }
            if (visible.isEmpty()) {
                Text("必要な確定足がまだありません", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            } else {
                val range = (visible.maxOf { it.second } - visible.minOf { it.second }).coerceAtLeast(.01)
                visible.forEachIndexed { index, (currency, score) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", color = Muted, modifier = Modifier.width(24.dp), fontSize = 11.sp)
                        Text(currency, color = White, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp), fontSize = 12.sp)
                        val width = (((score - visible.minOf { it.second }) / range).toFloat()).coerceIn(.03f, 1f)
                        Box(Modifier.weight(1f).height(15.dp).background(Color(0xFF111D36), RoundedCornerShape(3.dp))) {
                            Box(Modifier.fillMaxWidth(width).fillMaxHeight().background(if (score >= 0) Pink else Cyan, RoundedCornerShape(3.dp)))
                        }
                        Text("${if (score >= 0) "+" else ""}${"%.2f".format(score)}%", color = if (score >= 0) Pink else Cyan, textAlign = TextAlign.End, modifier = Modifier.width(62.dp), fontSize = 11.sp)
                    }
                }
            }
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("相対強弱ヒートマップ", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("セル値 = 行通貨の対JPY変化 − 列通貨の対JPY変化。直接取引価格ではなく相対比較です。", color = Muted, fontSize = 9.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("", Modifier.width(31.dp))
                currencies.forEach { Text(it, Modifier.weight(1f), color = Muted, textAlign = TextAlign.Center, fontSize = 8.sp) }
            }
            currencies.forEach { row ->
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(row, Modifier.width(31.dp), color = White, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                    currencies.forEach { col ->
                        val difference = if (row == col) null else values[row]?.let { r -> values[col]?.let { r - it } }
                        val cellColor = when {
                            difference == null -> Color(0xFF17213A)
                            difference >= 0 -> Pink.copy(alpha = (.20f + (difference / 3.0).toFloat().coerceIn(0f, .65f)))
                            else -> Cyan.copy(alpha = (.20f + (kotlin.math.abs(difference) / 3.0).toFloat().coerceIn(0f, .65f)))
                        }
                        Box(Modifier.weight(1f).height(27.dp).padding(1.dp).background(cellColor, RoundedCornerShape(2.dp)), contentAlignment = Alignment.Center) {
                            Text(difference?.let { "%+.1f".format(it) } ?: "—", color = White.copy(alpha = .9f), fontSize = 7.sp)
                        }
                    }
                }
            }
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("セッション別比較（JST）", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("東京 07–16 / 欧州 16–翌01 / 米国 21–翌06", color = Muted, fontSize = 9.sp)
            listOf("東京", "欧州", "米国").forEach { name ->
                val scores = currencyRelativeStrength(state.strengthCandles.mapValues { (_, list) -> filterSessionWindow(list, name) })
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.width(48.dp), color = White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    currencies.forEach { c ->
                        val score = scores[c]
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            val height = if (score == null) 8.dp else (12.dp.value + kotlin.math.abs(score).toFloat().coerceIn(0f, 28f)).dp
                            val barColor = when { score == null -> Muted; score >= 0 -> Pink; else -> Cyan }
                            Box(Modifier.width(17.dp).height(height).background(barColor.copy(alpha = if (score == null) .35f else .85f), RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)))
                            Text(c, color = Muted, fontSize = 7.sp)
                            Text(score?.let { "%+.1f".format(it) } ?: "—", color = if (score == null) Muted else barColor, fontSize = 6.sp)
                        }
                    }
                }
            }
        }

        CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("すべて", "メジャー", "高金利", "コモディティ", "暗号資産").forEach { ChoiceChip(it, it == filter, Pink) { filter = it } }
            }
            Spacer(Modifier.height(8.dp))
            Text("注目ペア候補", color = White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("対象は現在取得可能なJPYペアです。強い側がJPYなら、反対方向を表示します。", color = Muted, fontSize = 9.sp)
            if (candidates.isEmpty()) Text("候補データなし", color = Muted, modifier = Modifier.padding(top = 8.dp), fontSize = 11.sp)
            candidates.take(4).forEach { (pair, score) ->
                val yen = values["JPY"] ?: 0.0
                val direction = if (score >= yen) "HIGH" else "LOW"
                Row(
                    Modifier.fillMaxWidth().padding(top = 7.dp).border(1.dp, Pink.copy(alpha = .45f), RoundedCornerShape(8.dp))
                        .background(Color(0x66161E3A), RoundedCornerShape(8.dp)).clickable { onSelectPair(pair) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("$pair  $direction", color = if (direction == "HIGH") Pink else Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("対JPY ${"%+.2f".format(score - yen)}% • タップでチャートへ", color = Muted, fontSize = 9.sp)
                    }
                    Text("›", color = Pink, fontSize = 22.sp)
                }
            }
        }

        currentCandidate?.let { (at, pair, direction) ->
            val gap = values[pair.removeSuffix("JPY")]?.let { base -> values["JPY"]?.let { base - it } }
            val aligned = gap?.let { (direction == "HIGH" && it > 0.0) || (direction == "LOW" && it < 0.0) }
            CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
                Text("スキャン候補と通貨強弱の整合", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("$pair $direction • ${at.take(19)}", color = Muted, fontSize = 9.sp)
                Text(
                    when (aligned) { true -> "方向一致 • サブ根拠として追い風"; false -> "逆行 • エントリー根拠と照合"; null -> "比較可能な足が不足" },
                    color = when (aligned) { true -> Green; false -> Color(0xFFFFC76B); null -> Muted },
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text("強弱差 ${gap?.let { "%+.2f%%".format(it) } ?: "—"} • 補助表示。スキャンの順位条件には加点していません。", color = Muted, fontSize = 9.sp)
                Text("チャートで候補を開く ›", color = Pink, modifier = Modifier.clickable { onSelectPair(pair) }.padding(top = 5.dp), fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun StatusScreen(state: GmkUiState, setCutInEnabled: (Boolean) -> Unit, exportDiagnostic: () -> Unit) {
    val fetchAge = remember(state.rates, state.lastRateUpdateMs) {
        state.rates.associate { it.instrument to (it.fetchAgeSeconds ?: if (state.lastRateUpdateMs > 0) ((System.currentTimeMillis() - state.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0) else null) }
    }
    val chartSyncStatus = when {
        state.chartLoading -> "取得中"
        state.chartError != null -> "注意"
        state.chartUpdatedAtMs > 0L -> "同期済"
        else -> "未取得"
    }
    val strengthSyncStatus = when {
        state.strengthLoading -> "取得中"
        state.strengthErrors.isNotEmpty() -> "一部注意"
        state.strengthUpdatedAtMs > 0L -> "更新済"
        else -> "未取得"
    }
    val latestCandidateStatus = listOfNotNull(
        state.scan?.let { scan -> scan.top1?.let { scan.atJst to "${it.instrument} ${it.direction} ${it.grade} ${it.decision} • 3分" } },
        state.oneMinuteScan?.let { scan -> scan.top1?.let { scan.atJst to "${it.instrument} ${it.direction} ${if (it.confidence >= 0.53) "ENTRY" else "SKIP"} • 1分" } }
    ).maxByOrNull { parseJstMs(it.first) ?: 0L }?.second ?: "なし"
    Column(Modifier.fillMaxSize().background(Night).verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("状態・診断", color = White, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Text("取得品質 / スキャン / 連携 / カットイン", color = Muted, fontSize = 11.sp)
        StatusPanel {
            StatusLine("レート元", if (state.rates.any { it.instrument == "BTCJPY" }) "FX Yahoo Finance • BTC bitbank" else "接続待ち")
            StatusLine("有効 / LIVE", "${state.rateAvailableCount}/6  •  ${state.rateLiveCount}/6")
            StatusLine("レート更新", state.lastRateUpdateMs.takeIf { it > 0 }?.let(::formatClock) ?: "未取得")
            StatusLine("スキャン", if (state.busy || state.oneMinuteBusy) "実行中" else "待機")
            StatusLine("3分AUTO / 1分AUTO", "${if (state.autoScan) "ON" else "OFF"} / ${if (state.oneMinuteAutoScan) "ON" else "OFF"}")
            StatusLine("直近候補", latestCandidateStatus)
            StatusLine("判定可能 / 対象", "${state.scannableCount} / ${state.rateAvailableCount}")
            state.error?.let { StatusLine("最終エラー", it, Color(0xFFFFC76B)) }
            StatusLine("通信 / 失敗 / 取消", "${state.networkRequestCount} / ${state.networkFailureCount} / ${state.networkCancelledCount}")
            StatusLine("HTTP 429 / 5xx", "${state.network429Count} / ${state.network5xxCount}")
            state.lastNetworkError?.let { StatusLine("最終通信エラー", it, Color(0xFFFFC76B)) }
            state.scanStatus?.let { StatusLine("スキャン状態", it) }
            state.rateStatus?.let { StatusLine("取得状態", it) }
        }
        StatusPanel {
            Text("通貨ペアごとの取得状態", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            state.rates.forEach { rate ->
                val age = rate.ageSeconds
                val quality = when {
                    rate.freshnessStatus == "LIVE" -> "FRESH"
                    rate.price == null -> "STALE"
                    age != null && age > 120.0 -> "STALE"
                    else -> "LAG"
                }
                val freshColor = when (quality) { "FRESH" -> Green; "LAG" -> Color(0xFFFFC76B); else -> Red }
                Column(Modifier.fillMaxWidth().padding(top = 8.dp).border(1.dp, freshColor.copy(alpha = .4f), RoundedCornerShape(7.dp)).padding(8.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(rate.instrument, Modifier.weight(1f), color = White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(quality, color = freshColor, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                    Text("${rate.source} • ${rate.price?.let(::formatMarketPrice) ?: "価格なし"}", color = Muted, fontSize = 9.sp)
                    val receivedAt = fetchAge[rate.instrument]?.let { formatClock(System.currentTimeMillis() - (it * 1000.0).toLong()) } ?: "—"
                    Text("受信目安 $receivedAt • provider age ${rate.ageSeconds?.let { "%.1fs".format(it) } ?: "—"} / fetch age ${fetchAge[rate.instrument]?.let { "%.1fs".format(it) } ?: "—"}", color = Muted, fontSize = 9.sp)
                    rate.bid?.let { Text("bid ${formatMarketPrice(it)} / ask ${rate.ask?.let(::formatMarketPrice) ?: "—"}", color = Muted, fontSize = 9.sp) }
                }
            }
        }
        StatusPanel {
            Text("チャート・強弱連携", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            StatusLine("チャート", "${state.chartInstrument} ${state.chartTimeframe} • ${state.chartCandles.size}本 • $chartSyncStatus")
            state.chartError?.let { StatusLine("チャート警告", it, Color(0xFFFFC76B)) }
            StatusLine("チャート更新", state.chartUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "未取得")
            StatusLine("通貨強弱", "${state.strengthTimeframe} • ${state.strengthCandles.count { it.value.isNotEmpty() }}/6 • $strengthSyncStatus")
            StatusLine("強弱更新", state.strengthUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "未取得")
            if (state.strengthErrors.isNotEmpty()) StatusLine("強弱エラー", state.strengthErrors.entries.joinToString { "${it.key}: ${it.value}" }, Color(0xFFFFC76B))
        }
        StatusPanel {
            Text("カットイン / 実行環境", color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("カットイン ${if (state.cutInEnabled) "ON" else "OFF"}", color = White, fontSize = 11.sp)
                    Text("表示 ${state.cutInShownCount}回 • 最終 ${state.lastCutInType ?: "なし"}", color = Muted, fontSize = 9.sp)
                }
                Switch(checked = state.cutInEnabled, onCheckedChange = setCutInEnabled)
            }
            StatusLine("最終カットイン候補", "${state.lastCutInInstrument ?: "—"} • ${state.lastCutInAtJst ?: "—"}")
            state.lastCutInSuppressedReason?.let { StatusLine("抑制理由", it, Color(0xFFFFC76B)) }
            StatusLine("電池最適化除外", if (state.batteryOptimizationExempt) "はい" else "いいえ")
            StatusLine("バックグラウンド制限", if (state.backgroundRestricted) "あり" else "なし")
            Text("優勢: 3分は判定30秒前、1分は15秒前の確認条件を満たしたとき。確定: WIN/LOSE保存後。", color = Muted, fontSize = 9.sp)
        }
        OutlinedButton(onClick = exportDiagnostic, modifier = Modifier.fillMaxWidth()) { Text("JSON診断ログを保存") }
        Text("ログには時刻、ペア、bid/ask/last、provider/fetch age、freshness、候補、ENTRY/判定、結果、カットイン、連携状態、ネットワーク失敗数を含みます。", color = Muted, fontSize = 9.sp, modifier = Modifier.padding(7.dp))
    }
}

@Composable
private fun CardPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().border(1.dp, Color(0x667B68D7), RoundedCornerShape(10.dp)).background(Panel, RoundedCornerShape(10.dp)).padding(11.dp), content = content)
}

@Composable
private fun StatusPanel(content: @Composable ColumnScope.() -> Unit) = CardPanel(Modifier.padding(top = 8.dp), content)

@Composable
private fun StatusLine(label: String, value: String, valueColor: Color = White) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(112.dp), color = Muted, fontSize = 10.sp)
        Text(value, Modifier.weight(1f), color = valueColor, fontSize = 10.sp)
    }
}

@Composable
private fun ChoiceChip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        text,
        Modifier.border(1.dp, if (selected) accent else Color(0x556B7CA5), RoundedCornerShape(8.dp))
            .background(if (selected) accent.copy(alpha = .18f) else Color(0x66101C36), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 7.dp),
        color = if (selected) White else Muted,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        fontSize = 10.sp
    )
}

@Composable
private fun OhlcCell(label: String, value: Double?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 9.sp)
        Text(value?.let(::formatMarketPrice) ?: "—", color = White, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HistoryFocusCard(row: HistoryRow) {
    CardPanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
        Text("選択履歴 • ${row.instrument} ${row.direction}", color = Pink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text("ENTRY ${row.entryTimeJst} @ ${row.entryRate?.let(::formatMarketPrice) ?: "取得なし"}", color = White, fontSize = 10.sp)
        Text("判定 ${row.judgeTimeJst} @ ${row.judgeRate?.let(::formatMarketPrice) ?: "取得なし"} • ${row.resultStatus}", color = White, fontSize = 10.sp)
        Text("${row.source} / ${row.grade} / ${row.regime}", color = Muted, fontSize = 9.sp)
    }
}

private fun isSelectedFocusVisible(candles: List<Candle>, focus: HistoryRow?, timeframe: String): Boolean {
    if (candles.isEmpty() || focus == null) return false
    val time = parseJstMs(focus.entryTimeJst) ?: return false
    val span = timeframesToMs(timeframe)
    return time in candles.first().timeEpochMs..(candles.last().timeEpochMs + span)
}

private fun inSession(timeMs: Long, session: String): Boolean {
    if (session == "全時間") return true
    val hour = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(timeMs), Jst).hour
    return when (session) {
        "東京" -> hour in 7..15
        "欧州" -> hour >= 16 || hour < 1
        "米国" -> hour >= 21 || hour < 6
        else -> true
    }
}

private fun filterSessionWindow(candles: List<Candle>, session: String): List<Candle> {
    if (session == "全時間" || candles.isEmpty()) return candles
    val latest = candles.mapNotNull { sessionBucket(it.timeEpochMs, session) }.maxOrNull() ?: return emptyList()
    return candles.filter { sessionBucket(it.timeEpochMs, session) == latest }
}

private fun latestScanEntry(state: GmkUiState, instrument: String, nowMs: Long): Pair<Long, String>? {
    val entries = listOfNotNull(
        state.scan?.let { scan -> scan.top1?.takeIf { it.instrument == instrument && it.decision == "ENTRY" }?.let { Triple(scan.atJst, scan.entryTimeJst, it.direction) } },
        state.oneMinuteScan?.let { scan -> scan.top1?.takeIf { it.instrument == instrument && it.confidence >= 0.53 }?.let { Triple(scan.atJst, scan.entryTimeJst, it.direction) } }
    )
    val recent = entries.maxByOrNull { runCatching { ZonedDateTime.parse(it.first).toInstant().toEpochMilli() }.getOrDefault(0L) } ?: return null
    val target = runCatching { ZonedDateTime.parse(recent.second).toInstant().toEpochMilli() }.getOrNull() ?: return null
    if (target <= nowMs) return null
    return target to recent.third
}

private fun sessionBucket(timeMs: Long, session: String): java.time.LocalDate? {
    val local = java.time.Instant.ofEpochMilli(timeMs).atZone(Jst)
    if (!inSession(timeMs, session)) return null
    return when (session) {
        "欧州" -> if (local.hour < 1) local.toLocalDate().minusDays(1) else local.toLocalDate()
        "米国" -> if (local.hour < 6) local.toLocalDate().minusDays(1) else local.toLocalDate()
        else -> local.toLocalDate()
    }
}

private fun parseJstMs(value: String): Long? = runCatching { ZonedDateTime.parse(value).toInstant().toEpochMilli() }.getOrNull()
private fun timeframesToMs(value: String): Long = when (value) { "1m" -> 60_000L; "5m" -> 300_000L; "15m" -> 900_000L; "1h" -> 3_600_000L; "4h" -> 14_400_000L; "1d" -> 86_400_000L; else -> 60_000L }
private fun formatMarketPrice(value: Double): String = if (value >= 1_000_000.0) "%,.0f".format(value) else "%.3f".format(value)
private fun formatClock(value: Long): String = runCatching { ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(value), Jst).toLocalTime().toString().take(8) }.getOrDefault("—")

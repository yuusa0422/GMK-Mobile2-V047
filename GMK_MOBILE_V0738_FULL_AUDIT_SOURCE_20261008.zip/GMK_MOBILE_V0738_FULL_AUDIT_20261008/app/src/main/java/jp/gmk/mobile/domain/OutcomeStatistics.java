package jp.gmk.mobile.domain;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.*;

/** Shared UI and diagnostic definition: resolved ENTRY only; SKIP never loses. */
public final class OutcomeStatistics {
    private OutcomeStatistics() {}
    public static final class Row {
        public final String decision,status,entryAt,judgeAt,policy;
        public final Double entryRate,judgeRate;
        public Row(String decision,String status,String entryAt,String judgeAt,String policy,Double entryRate,Double judgeRate) {
            this.decision=decision;this.status=status;this.entryAt=entryAt;this.judgeAt=judgeAt;this.policy=policy;this.entryRate=entryRate;this.judgeRate=judgeRate;
        }
        public int minutes() {
            try {
                Duration duration=Duration.between(ZonedDateTime.parse(entryAt),ZonedDateTime.parse(judgeAt));
                if(duration.getNano()!=0)return 0;
                long seconds=duration.getSeconds();
                return seconds>0 && seconds%60==0 && seconds<=86400?(int)(seconds/60):0;
            } catch(RuntimeException e){return 0;}
        }
    }
    public static final class Summary {
        public int wins,losses,draws,pending,missed,entries,skips,skipShadow;
        public int resolved(){return wins+losses;}
        public Double winRate(){return resolved()>0?100.0*wins/resolved():null;}
        public void accept(Row row) {
            if(row.decision.equals("SKIP")){skips++;if(row.status.equals("WIN")||row.status.equals("LOSE"))skipShadow++;return;}
            if(!row.decision.equals("ENTRY"))return;
            entries++;
            if(row.status.equals("WIN"))wins++;
            else if(row.status.equals("LOSE")){
                losses++;
                if(row.entryRate!=null && row.judgeRate!=null && Double.isFinite(row.entryRate) && row.entryRate.doubleValue()==row.judgeRate.doubleValue())draws++;
            } else if(row.status.equals("WAIT_ENTRY")||row.status.equals("WAIT_JUDGE"))pending++;
            else missed++;
        }
    }
    public static Map<Integer,Summary> byHorizon(Collection<Row> rows) {
        Map<Integer,Summary> result=new LinkedHashMap<>();
        for(int m:new int[]{3,5,1,10,15,0})result.put(m,new Summary());
        for(Row r:rows)result.computeIfAbsent(r.minutes(),key->new Summary()).accept(r);
        return result;
    }
}

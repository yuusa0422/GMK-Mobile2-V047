import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.activity.ComponentActivity
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.test.hasScrollToIndexAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import jp.gmk.mobile.HistoryScreen
import jp.gmk.mobile.StatusScreen
import jp.gmk.mobile.domain.HistoryRow
import jp.gmk.mobile.ui.GmkUiState
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35], qualifiers="w360dp-h640dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class MobileFullAuditUiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private fun history(fontScale: Float) {
        val row = HistoryRow(1,"ui-test","AUTO","2026-10-08T09:04:50+09:00","USDJPY","HIGH","C","ENTRY",
            entryTimeJst="2026-10-08T09:05:00+09:00",judgeTimeJst="2026-10-08T09:10:00+09:00",
            entryRate=150.0,judgeRate=151.0,resultStatus="WIN",policyVersion="GMK_V0736_DIRECT19")
        compose.setContent {
            val density=LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density,fontScale)) {
                MaterialTheme { Box(Modifier.size(360.dp,520.dp)) { HistoryScreen(listOf(row),false,{}) } }
            }
        }
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("USDJPY",substring=true))
        compose.onNodeWithText("USDJPY",substring=true).assertIsDisplayed()
        saveScreenshot(if(fontScale>1f) "history_large_text.png" else "history_regular.png")
        val layouts=mutableListOf<androidx.compose.ui.text.TextLayoutResult>()
        compose.onNodeWithText("HIGH",useUnmergedTree=true).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.GetTextLayoutResult) { it(layouts) }
        val label=layouts.single()
        println("DIRECTION_LAYOUT text=${label.layoutInput.text.text} size=${label.size} paragraphWidth=${label.multiParagraph.width} lineRight=${label.getLineRight(0)} lineLeft=${label.getLineLeft(0)} constraints=${label.layoutInput.constraints}")
        assertEquals("HIGH",layouts.single().layoutInput.text.text)
        assertEquals("The direction must remain readable as one label",1,layouts.single().lineCount)
        // With softWrap=false Compose's paragraph keeps the parent's available width;
        // didOverflowWidth compares that width with the smaller intrinsic Text size.
        // Check the actual glyph bounds, which must fit the allocated label width.
        assertTrue("The HIGH label must fit horizontally",label.getLineRight(0)<=label.size.width)
        assertTrue("The HIGH label must not clip on its left",label.getLineLeft(0)>=0f)
    }
    @Test fun historyRowReachableOnSmallPhone() { history(1f) }
    @Test fun historyRowReachableWithLargeText() { history(1.8f) }
    private fun saveScreenshot(name:String) {
        val root=java.io.File(System.getProperty("gmk.projectRoot"),"release_evidence/v0738_full_audit/screenshots")
        root.mkdirs()
        lateinit var bitmap: android.graphics.Bitmap
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            bitmap = android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(bitmap))
        }
        java.io.File(root,name).outputStream().use {
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it)
        }
    }
    @Test fun statusExportReachableWithLargeText() {
        compose.setContent {
            val density=LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density,1.8f)) {
                MaterialTheme { Box(Modifier.size(360.dp,520.dp)) { StatusScreen(GmkUiState(),{}, {}) } }
            }
        }
        compose.onNodeWithText("JSON診断ログを保存").performScrollTo().assertIsDisplayed()
        saveScreenshot("status_large_text.png")
    }
}

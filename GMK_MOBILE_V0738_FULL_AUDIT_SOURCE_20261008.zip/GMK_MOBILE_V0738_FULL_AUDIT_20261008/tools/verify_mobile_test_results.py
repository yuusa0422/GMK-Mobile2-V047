"""Require complete, unskipped Android-host and prediction regression suites."""
import argparse
from pathlib import Path
import xml.etree.ElementTree as ET
import json

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {"Direct19IntegrationTest":6,"ProductionRegressionTest":5,"PcSyncRegressionTest":3,
    "MobileDeepAuditRegressionTest":28,"MobileFullAuditStateTest":10,"MobileFullAuditUiTest":3,
    "RuleAiFunctionalTest":4,"RuleAiRuntimeIntegrationTest":14,
    "MobileRealtimeAuditTest":26,"HistoryPipelineAuditTest":6}

def main():
    rows={}
    for path in (ROOT/"app/build/test-results/testDebugUnitTest").glob("TEST*.xml"):
        root=ET.parse(path).getroot()
        assert all(int(root.get(key,0))==0 for key in ("failures","errors","skipped")),path
        assert root.get("name") not in rows,"Duplicate suite"
        rows[root.get("name")]=int(root.get("tests"))
    assert rows==EXPECTED,rows
    print(json.dumps(dict(status="PASS",tests=sum(rows.values()),failed=0,skipped=0,suites=rows)))

if __name__=="__main__":main()

"""Bundle the complete source and APK, restoring duplicate assets by verified SHA."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--apk", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    apk_data = args.apk.read_bytes()
    with zipfile.ZipFile(args.apk) as apk:
        lookup = {}
        for name in apk.namelist():
            if name.startswith(("assets/", "res/")) and not name.endswith("/"):
                lookup.setdefault(sha(apk.read(name)), name)
        with zipfile.ZipFile(args.source) as source:
            roots = {PurePosixPath(i.filename).parts[0] for i in source.infolist()}
            assert len(roots) == 1, roots
            prefix = roots.pop()
            verification=json.loads(source.read(prefix+'/RELEASE_VERIFICATION.json'))
            tests=sum(x['tests'] for x in verification['tests'])
            assert tests==105 and all(x['failures']==x['errors']==x['skipped']==0 for x in verification['tests'])
            retained = []
            assets = []
            for i in source.infolist():
                path = PurePosixPath(i.filename)
                assert not path.is_absolute() and ".." not in path.parts
                assert not i.is_dir()
                relative = PurePosixPath(*path.parts[1:])
                data = source.read(i)
                digest = sha(data)
                match = lookup.get(digest)
                if relative.parts[:4] in (("app", "src", "main", "assets"), ("app", "src", "main", "res")) and match:
                    assert apk.read(match) == data
                    assets.append(dict(source_path=str(relative), apk_member=match, bytes=len(data), sha256=digest))
                else:
                    retained.append((i.filename, data))
    manifest = dict(apk_filename=args.apk.name, apk_sha256=sha(apk_data), assets=assets)
    readme = f"""GMK MOBILE v0.7.38 — APK・復元可能な全ソース・AI/ルール/履歴/リアルタイム監査

24課題を修正・補強。API26/35の検証、実AIモデル、UI、既存試験を含む{tests}試験PASS、スキップ0。
BTC/JPYの公式WebSocket実配信とREST連続3回、為替5通貨の実APIで新しい配信元時刻を確認。
BTCはスキャンから独立し、配信停止時は専用RESTで回復。15秒を超えた価格はLASTへ移行。
本番用APKは未署名。実端末へのインストール・本番署名は未実施です。

展開先のプロジェクトに入り、python tools/restore_bundled_assets.py を実行してください。
全ソース資産を同梱APKからSHA検証付きで復元します。
sha256sum --check --quiet PACKAGE_MANIFEST_SHA256.txt で全ソースを確認できます。
既存のGMK_V0735_TEST_DATA.zipを併用すると元の14試験も再実行できます。
完全な元の実測特徴量fixtureは同梱済み。追加の環境変数指定は不要です。
独立ファイル GMK_MOBILE_V0738_BUILD_WORKFLOW_20261008.yml は .github/workflows/build.yml と同一。
署名には従来のアプリと同じ本番署名鍵が必要です。

MOBILE_DEEP_AUDIT_REPORT.html / RELEASE_VERIFICATION.json / release_evidence/v0738_full_audit を参照。
"""
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in retained:
            z.writestr(name, data)
        z.writestr(prefix + "/" + args.apk.name, apk_data)
        z.writestr(prefix + "/BUNDLED_ASSETS.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        z.writestr("README_BUNDLE_JA.txt", readme)
    with zipfile.ZipFile(args.output) as z:
        assert z.testzip() is None
        assert sha(z.read(prefix + "/" + args.apk.name)) == manifest["apk_sha256"]
    print(json.dumps(dict(bundle=str(args.output), bytes=args.output.stat().st_size,
        restored_assets=len(assets), duplicated_source_bytes=sum(x["bytes"] for x in assets))))


if __name__ == "__main__":
    main()

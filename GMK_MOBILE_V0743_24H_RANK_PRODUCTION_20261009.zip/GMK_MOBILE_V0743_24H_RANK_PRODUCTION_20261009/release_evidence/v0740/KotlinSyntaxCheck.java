import java.nio.file.*;
import org.jetbrains.kotlin.cli.jvm.compiler.KotlinCoreEnvironment;
import org.jetbrains.kotlin.cli.jvm.compiler.EnvironmentConfigFiles;
import org.jetbrains.kotlin.config.CompilerConfiguration;
import org.jetbrains.kotlin.psi.KtPsiFactory;
import org.jetbrains.kotlin.com.intellij.openapi.util.Disposer;
import org.jetbrains.kotlin.com.intellij.openapi.Disposable;
import org.jetbrains.kotlin.com.intellij.psi.PsiErrorElement;
import org.jetbrains.kotlin.com.intellij.psi.util.PsiTreeUtil;
public final class KotlinSyntaxCheck {
 public static void main(String[] args) throws Exception {
  Disposable disposable = Disposer.newDisposable();
  try {
   KotlinCoreEnvironment environment = KotlinCoreEnvironment.createForProduction(disposable,new CompilerConfiguration(),EnvironmentConfigFiles.JVM_CONFIG_FILES);
   KtPsiFactory factory = new KtPsiFactory(environment.getProject(),false);
   int count=0;
   for(String filename:args) {
    var file=factory.createFile(Path.of(filename).getFileName().toString(),Files.readString(Path.of(filename)));
    var errors=PsiTreeUtil.findChildrenOfType(file,PsiErrorElement.class);
    if(!errors.isEmpty()) throw new AssertionError(filename+": "+errors);
    count++;
   }
   System.out.println("PASS Kotlin syntax parser: "+count+" files; Kotlin1.9.24. This is parsing, not an Android typecheck/build.");
  } finally { Disposer.dispose(disposable); }
 }
}

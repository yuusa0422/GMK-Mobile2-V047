package jp.gmk.mobile.data

import jp.gmk.mobile.domain.CandidateActionTrace
import jp.gmk.mobile.domain.CandidateAssessment
import jp.gmk.mobile.domain.CandidateSkipReason
import jp.gmk.mobile.domain.ChartRankAssessment
import jp.gmk.mobile.domain.ChartRankDisplay
import jp.gmk.mobile.domain.RuleSelectionStage
import org.json.JSONObject

/** Optional explanation and frozen chart estimate; never read as a trading action. */
object AssessmentJsonCodec {
    private const val SCHEMA_VERSION = 1

    fun encode(value: CandidateAssessment?): JSONObject? = value?.let { a ->
        JSONObject()
            .put("schema_version", SCHEMA_VERSION)
            .put("usage", "EXPLANATION_ONLY")
            .put("strength_status", "UNVALIDATED")
            .put("legacy_rule_grade", a.legacyRuleGrade)
            .put("legacy_rule_id", a.legacyRuleId ?: JSONObject.NULL)
            .put("operational_rule_id", a.operationalRuleId ?: JSONObject.NULL)
            .put("operational_grade", a.operationalGrade)
            .put("decision", a.decision)
            .put("selection_stage", a.selectionStage.name)
            .put("skip_reason", a.skipReason?.name ?: JSONObject.NULL)
            .put("gate_score", a.gateScore?.takeIf { it.isFinite() && it in 0.0..1.0 } ?: JSONObject.NULL)
            .put("historical_expected_rate", a.historicalExpectedRate?.takeIf { it.isFinite() && it in 0.0..1.0 } ?: JSONObject.NULL)
            .put("historical_sample_size", a.historicalSampleSize?.takeIf { it > 0 } ?: JSONObject.NULL)
            .put("original_action", encodeTrace(a.originalAction, "ORIGINAL_NATIVE"))
            .put("chosen_action", encodeTrace(a.chosenAction, "CHOSEN_OPERATIONAL"))
            .put("correction_source_action", a.correctionSourceAction?.let { encodeTrace(it, "CORRECTION_SOURCE_TOP1") } ?: JSONObject.NULL)
            .put("correction_label", a.correctionLabel ?: JSONObject.NULL)
            .put("chart_rank", a.chartRank?.let(::encodeChartRank) ?: JSONObject.NULL)
    }

    /** Unknown schemas or broken traces affect this metadata only, never the history row. */
    fun decode(json: JSONObject?): CandidateAssessment? = runCatching {
        val x = json ?: return@runCatching null
        if (int(x, "schema_version") != SCHEMA_VERSION) return@runCatching null
        val legacyGrade = grade(x, "legacy_rule_grade") ?: return@runCatching null
        val operationalGrade = grade(x, "operational_grade") ?: return@runCatching null
        val decision = decision(x) ?: return@runCatching null
        val stage = RuleSelectionStage.entries.firstOrNull { it.name == string(x, "selection_stage") } ?: return@runCatching null
        val original = decodeTrace(x.optJSONObject("original_action"), "ORIGINAL_NATIVE") ?: return@runCatching null
        val chosen = decodeTrace(x.optJSONObject("chosen_action"), "CHOSEN_OPERATIONAL") ?: return@runCatching null
        val legacyRuleId = ruleId(x, "legacy_rule_id")
        val operationalRuleId = ruleId(x, "operational_rule_id")
        // Native and chosen traces concern the selected instrument. Direction, decision,
        // operational grade and horizon may change through a correction; rule provenance
        // may not. The routing source below is an independent TOP1 and may be different.
        if (original.instrument != chosen.instrument || original.legacyRuleGrade != legacyGrade ||
            chosen.legacyRuleGrade != legacyGrade || original.legacyRuleId != legacyRuleId ||
            chosen.legacyRuleId != legacyRuleId || original.operationalRuleId != operationalRuleId ||
            chosen.operationalRuleId != operationalRuleId || chosen.decision != decision ||
            chosen.operationalGrade != operationalGrade) return@runCatching null
        val source = if (!x.has("correction_source_action") || x.isNull("correction_source_action")) null
            else decodeTrace(x.optJSONObject("correction_source_action"), "CORRECTION_SOURCE_TOP1") ?: return@runCatching null
        val correctionLabel = string(x, "correction_label")?.takeIf { it.length <= 512 }
        if ((source == null) != (correctionLabel == null)) return@runCatching null
        val skipReason = if (decision == "ENTRY") null else
            CandidateSkipReason.entries.firstOrNull { it.name == string(x, "skip_reason") } ?: CandidateSkipReason.UNKNOWN
        val sample = int(x, "historical_sample_size")?.takeIf { it > 0 }
        val historicalRate = probability(x, "historical_expected_rate")
        CandidateAssessment(
            legacyGrade, legacyRuleId, operationalRuleId,
            operationalGrade, decision, stage, skipReason, probability(x, "gate_score"),
            historicalRate?.takeIf { sample != null }, sample?.takeIf { historicalRate != null },
            original, chosen, source, correctionLabel,
            // A corrupt optional chart block must not erase native provenance or a row.
            decodeChartRank(x.optJSONObject("chart_rank"), chosen.direction)
        )
    }.getOrNull()

    private fun encodeChartRank(c: ChartRankAssessment) = JSONObject()
        .put("schema_version", SCHEMA_VERSION)
        .put("usage", "DISPLAY_ONLY")
        .put("grade", c.grade)
        .put("raw_probability", c.rawProbability?.takeIf { it.isFinite() && it in 0.0..1.0 } ?: JSONObject.NULL)
        .put("shrunk_probability", c.shrunkProbability?.takeIf { it.isFinite() && it in 0.0..1.0 } ?: JSONObject.NULL)
        .put("calibrated_probability", c.calibratedProbability?.takeIf { it.isFinite() && it in 0.0..1.0 } ?: JSONObject.NULL)
        .put("support_n", c.supportN)
        .put("reference_dates", c.referenceDates)
        .put("effective_sample_size", c.effectiveSampleSize?.takeIf { it.isFinite() && it >= 0.0 } ?: JSONObject.NULL)
        .put("status_reason", c.statusReason)
        .put("snapshot_id", c.snapshotId)
        .put("model_version", c.modelVersion)
        .put("query_boundary_utc", c.queryBoundaryUtc)
        .put("direction", c.direction)
        .put("validation_status", c.validationStatus)

    private fun decodeChartRank(json: JSONObject?, chosenDirection: String): ChartRankAssessment? = runCatching {
        val x = json ?: return@runCatching null
        if (int(x, "schema_version") != SCHEMA_VERSION || string(x, "usage") != "DISPLAY_ONLY" ||
            string(x, "validation_status") != "UNVALIDATED") return@runCatching null
        val chartGrade = string(x, "grade")?.takeIf { it in ChartRankDisplay.grades } ?: return@runCatching null
        val direction = string(x, "direction")?.takeIf { it == chosenDirection && it in setOf("HIGH", "LOW") }
            ?: return@runCatching null
        val support = int(x, "support_n")?.takeIf { it in 0..1_000_000 } ?: return@runCatching null
        val dates = int(x, "reference_dates")?.takeIf { it in 0..support } ?: return@runCatching null
        val raw = optionalProbability(x, "raw_probability") ?: return@runCatching null
        val shrunk = optionalProbability(x, "shrunk_probability") ?: return@runCatching null
        val calibrated = optionalProbability(x, "calibrated_probability") ?: return@runCatching null
        val effective = if (!x.has("effective_sample_size") || x.isNull("effective_sample_size")) null else {
            // An equal-weight sum may round a few ulps above N. Preserve its valid
            // mathematical bound while rejecting counts meaningfully above N.
            (x.opt("effective_sample_size") as? Number)?.toDouble()?.takeIf {
                it.isFinite() && it >= 0.0 && it <= support.toDouble() + 1e-9
            }?.coerceAtMost(support.toDouble()) ?: return@runCatching null
        }
        if (chartGrade != "UNRANKED" && (support != 200 || dates < 51 || effective == null || effective < 100.0 ||
                raw.value == null || shrunk.value == null || calibrated.value == null)) return@runCatching null
        val reason = string(x, "status_reason")?.takeIf { it.length <= 512 } ?: return@runCatching null
        val snapshot = string(x, "snapshot_id")?.takeIf { it.length <= 256 } ?: return@runCatching null
        val version = string(x, "model_version")?.takeIf { it.length <= 128 } ?: return@runCatching null
        val boundary = long(x, "query_boundary_utc")?.takeIf { it > 0L } ?: return@runCatching null
        ChartRankAssessment(chartGrade, raw.value, calibrated.value, support, dates, effective,
            reason, snapshot, version, boundary, direction, shrunk.value, "UNVALIDATED")
    }.getOrNull()

    private data class OptionalProbability(val value: Double?)
    private fun optionalProbability(x: JSONObject, key: String): OptionalProbability? {
        if (!x.has(key) || x.isNull(key)) return OptionalProbability(null)
        return probability(x, key)?.let { OptionalProbability(it) }
    }

    private fun long(x: JSONObject, key: String): Long? {
        val value = x.opt(key) as? Number ?: return null
        return when (value) {
            is Byte, is Short, is Int, is Long -> value.toLong()
            else -> value.toDouble().takeIf { it.isFinite() && it > Long.MIN_VALUE.toDouble() &&
                it < Long.MAX_VALUE.toDouble() && it == it.toLong().toDouble() }?.toLong()
        }
    }

    private fun encodeTrace(t: CandidateActionTrace, role: String) = JSONObject()
        .put("role", role)
        .put("instrument", t.instrument)
        .put("direction", t.direction)
        .put("legacy_rule_grade", t.legacyRuleGrade)
        .put("legacy_rule_id", t.legacyRuleId ?: JSONObject.NULL)
        .put("operational_rule_id", t.operationalRuleId ?: JSONObject.NULL)
        .put("operational_grade", t.operationalGrade)
        .put("decision", t.decision)
        .put("judge_minutes", t.judgeMinutes)

    private fun decodeTrace(json: JSONObject?, role: String): CandidateActionTrace? {
        val x = json ?: return null
        if (string(x, "role") != role) return null
        val instrument = string(x, "instrument")?.takeIf { it.length <= 32 } ?: return null
        val direction = string(x, "direction")?.takeIf { it in setOf("HIGH", "LOW") } ?: return null
        val legacyGrade = grade(x, "legacy_rule_grade") ?: return null
        val operationalGrade = grade(x, "operational_grade") ?: return null
        val decision = decision(x) ?: return null
        val minutes = int(x, "judge_minutes")?.takeIf { it in setOf(1, 3, 5, 10, 15) } ?: return null
        return CandidateActionTrace(instrument, direction, legacyGrade, ruleId(x, "legacy_rule_id"),
            ruleId(x, "operational_rule_id"), operationalGrade, decision, minutes)
    }

    private fun string(x: JSONObject, key: String): String? = (x.opt(key) as? String)?.takeIf { it.isNotBlank() }
    private fun decision(x: JSONObject): String? = string(x, "decision")?.takeIf { it in setOf("ENTRY", "SKIP") }
    private fun grade(x: JSONObject, key: String): String? = string(x, key)?.takeIf {
        (key == "legacy_rule_grade" && it == "未記録") ||
            it in setOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I", "R") ||
            (it.startsWith("C") && it.removePrefix("C").toIntOrNull()?.let { n -> n in 1..10 } == true)
    }
    private fun int(x: JSONObject, key: String): Int? {
        val value = (x.opt(key) as? Number)?.toDouble() ?: return null
        return value.takeIf { it.isFinite() && it >= Int.MIN_VALUE.toDouble() && it <= Int.MAX_VALUE.toDouble() && it == it.toInt().toDouble() }?.toInt()
    }
    private fun ruleId(x: JSONObject, key: String): Int? = int(x, key)?.takeIf { it >= 0 }
    private fun probability(x: JSONObject, key: String): Double? = (x.opt(key) as? Number)?.toDouble()?.takeIf { it.isFinite() && it in 0.0..1.0 }
}

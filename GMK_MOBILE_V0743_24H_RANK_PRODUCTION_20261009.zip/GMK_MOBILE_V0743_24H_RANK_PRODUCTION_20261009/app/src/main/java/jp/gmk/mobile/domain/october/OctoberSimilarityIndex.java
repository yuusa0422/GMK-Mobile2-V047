package jp.gmk.mobile.domain.october;

import java.io.*;
import java.security.*;
import java.time.*;
import java.util.*;
import java.util.zip.GZIPInputStream;

/** Same-symbol standardized Euclidean TECH_WEEKDAY_HOUR_K100. Raw float32
 * observations retain exact labels. Daily 09:00 JST snapshot excludes B+300 >=
 * cutoff; scaler uses all eligible rows, prior uses the selected temporal bucket.
 * Model has no authority to create/remove ENTRY or alter native S/A/B. */
public final class OctoberSimilarityIndex {
    public static final String VERSION="GMK_V0740_TECH_WEEKDAY_HOUR_K100_C_M10";
    public static final String[] TRADED={"USDJPY","EURJPY","GBPJPY","AUDJPY"};
    private static final int FEATURES=35,K=100,MINIMUM=400;
    private static final ZoneId JST=ZoneId.of("Asia/Tokyo");
    public static final class Record {
        public final long boundary;public final float[] x;public final byte y3,y5;public final int weekday,hour;
        public Record(long b,float[] f,int y3,int y5) {
            if(b%300!=0||f==null||f.length!=FEATURES||y3<0||y3>2||y5<0||y5>2)throw new IllegalArgumentException("record");
            for(float v:f)if(!Float.isFinite(v))throw new IllegalArgumentException("features");
            boundary=b;x=f.clone();this.y3=(byte)y3;this.y5=(byte)y5;
            ZonedDateTime t=Instant.ofEpochSecond(b).atZone(JST);weekday=t.getDayOfWeek().getValue()-1;hour=t.getHour();
        }
    }
    private final List<Record>[] records;
    private final HashSet<Long>[] existing;
    public final long bundledLastBoundary;
    private long snapshot=Long.MIN_VALUE;
    private final List<Record>[] eligible;
    private final double[][] means=new double[4][35],scales=new double[4][35];
    private final Map<Integer,List<Record>>[] buckets;
    private long snapshotLatestLabel=0;
    @SuppressWarnings("unchecked") private OctoberSimilarityIndex(long last) {
        bundledLastBoundary=last;records=new List[4];eligible=new List[4];buckets=new Map[4];existing=new HashSet[4];
        for(int s=0;s<4;s++){records[s]=new ArrayList<>();eligible[s]=new ArrayList<>();buckets[s]=new HashMap<>();existing[s]=new HashSet<>();}
    }
    public static OctoberSimilarityIndex readCompressed(InputStream input,String expectedRawSha256) throws IOException {
        try {
            MessageDigest md=MessageDigest.getInstance("SHA-256");
            DataInputStream in=new DataInputStream(new BufferedInputStream(new DigestInputStream(new GZIPInputStream(input),md),65536));
            if(in.readInt()!=0x474d4b4f||in.readInt()!=1||in.readInt()!=4||in.readInt()!=35)throw new IOException("October asset schema");
            OctoberSimilarityIndex model=new OctoberSimilarityIndex(in.readLong());
            for(int s=0;s<4;s++){
                int n=in.readInt();if(n<400||n>200000)throw new IOException("row count");long prev=Long.MIN_VALUE;
                for(int i=0;i<n;i++){
                    long b=in.readLong();int y3=in.readUnsignedByte(),y5=in.readUnsignedByte();float[] x=new float[35];for(int j=0;j<35;j++)x[j]=in.readFloat();
                    if(b<=prev||b>model.bundledLastBoundary)throw new IOException("source time bounds");prev=b;
                    Record r=new Record(b,x,y3,y5);model.records[s].add(r);model.existing[s].add(b);
                }
            }
            if(in.read()!=-1)throw new IOException("trailing bytes");
            StringBuilder hex=new StringBuilder();for(byte b:md.digest())hex.append(String.format(Locale.ROOT,"%02x",b&255));
            if(!hex.toString().equals(expectedRawSha256))throw new IOException("October asset SHA mismatch");
            in.close();return model;
        } catch(NoSuchAlgorithmException|IllegalArgumentException e){throw new IOException("October asset invalid",e);}
    }
    public static long dailyCutoff(long boundary) {
        ZonedDateTime t=Instant.ofEpochSecond(boundary).atZone(JST);
        ZonedDateTime day=t.toLocalDate().atTime(9,0).atZone(JST);if(t.isBefore(day))day=day.minusDays(1);
        return day.toEpochSecond();
    }
    /** Only actual completed live OPEN labels can be added. Never fills unavailable days. */
    public synchronized boolean addObserved(int symbol,Record r,long observedNowSeconds) {
        if(symbol<0||symbol>=4||r.boundary<=bundledLastBoundary||r.boundary+300>=observedNowSeconds||r.weekday>=5||r.hour<9||r.hour>17||(r.hour==17&&Math.floorMod(r.boundary+9*3600,3600)!=0)||existing[symbol].contains(r.boundary))return false;
        records[symbol].add(r);existing[symbol].add(r.boundary);if(r.boundary+300<snapshot)snapshot=Long.MIN_VALUE;return true;
    }
    public synchronized long snapshotEpoch(){return snapshot;}
    public synchronized long latestSnapshotLabelEpoch(){return snapshotLatestLabel;}
    public synchronized int observationCount(){int n=0;for(List<Record> r:records)n+=r.size();return n;}
    public synchronized int liveObservationCount(){int n=0;for(List<Record> rs:records)for(Record r:rs)if(r.boundary>bundledLastBoundary)n++;return n;}
    private void snapshot(long cutoff,long deadlineNs) {
        if(snapshot==cutoff)return;
        snapshotLatestLabel=0;
        for(int s=0;s<4;s++){
            checkDeadline(deadlineNs);List<Record> rows=eligible[s];rows.clear();buckets[s].clear();Arrays.fill(means[s],0);Arrays.fill(scales[s],0);
            for(Record r:records[s])if(r.boundary+300<cutoff){rows.add(r);snapshotLatestLabel=Math.max(snapshotLatestLabel,r.boundary+300);}
            if(rows.size()<400)throw new IllegalStateException("insufficient training rows");
            rows.sort(Comparator.comparingLong(r->r.boundary));
            for(Record r:rows)for(int j=0;j<35;j++)means[s][j]+=r.x[j];
            for(int j=0;j<35;j++)means[s][j]/=rows.size();
            for(Record r:rows)for(int j=0;j<35;j++){double d=r.x[j]-means[s][j];scales[s][j]+=d*d;}
            for(int j=0;j<35;j++){scales[s][j]=Math.sqrt(scales[s][j]/rows.size());if(scales[s][j]<1e-15)scales[s][j]=1;}
            for(Record r:rows){buckets[s].computeIfAbsent(r.weekday*24+r.hour,a->new ArrayList<>()).add(r);buckets[s].computeIfAbsent(1000+r.weekday,a->new ArrayList<>()).add(r);}
        }
        if(snapshotLatestLabel>=cutoff)throw new AssertionError("future label");snapshot=cutoff;
    }
    private static void checkDeadline(long ns){if(ns>0&&System.nanoTime()>ns)throw new IllegalStateException("October inference deadline");}
    public synchronized float[][][] predict(float[][] features,boolean[] valid,long boundary,long deadlineNs) {
        snapshot(dailyCutoff(boundary),deadlineNs);ZonedDateTime t=Instant.ofEpochSecond(boundary).atZone(JST);int dow=t.getDayOfWeek().getValue()-1,hour=t.getHour();
        float[][][] out=new float[4][2][3];for(float[][] a:out)for(float[] p:a)Arrays.fill(p,Float.NaN);
        for(int s=0;s<4;s++){
            checkDeadline(deadlineNs);if(!valid[s]||features[s]==null||features[s].length!=35)continue;
            boolean finite=true;for(float v:features[s])finite&=Float.isFinite(v);if(!finite)continue;
            List<Record> pool=buckets[s].get(dow*24+hour);if(pool==null||pool.size()<MINIMUM)pool=buckets[s].get(1000+dow);if(pool==null||pool.size()<MINIMUM)pool=eligible[s];
            // Max heap retains the exact closest 100; equal distances use earlier absolute
            // boundary deterministically. Continuous-price data normally has no cutoff ties.
            final class Near {Record r;double distance;Near(Record r,double d){this.r=r;distance=d;}}
            PriorityQueue<Near> heap=new PriorityQueue<>((a,b)->{int c=Double.compare(b.distance,a.distance);return c!=0?c:Long.compare(b.r.boundary,a.r.boundary);});
            int[][] priorCount=new int[2][3];int n=0;
            for(Record r:pool){if((n++&255)==0)checkDeadline(deadlineNs);priorCount[0][r.y3]++;priorCount[1][r.y5]++;double d=0;
                for(int j=0;j<35;j++){double delta=((double)r.x[j]-(double)features[s][j])/scales[s][j];d+=delta*delta;}
                double dist=Math.sqrt(Math.max(d,0));Near near=new Near(r,dist);
                if(heap.size()<K)heap.add(near);else{Near worst=heap.peek();if(dist<worst.distance||(dist==worst.distance&&r.boundary<worst.r.boundary)){heap.poll();heap.add(near);}}
            }
            boolean zero=false;for(Near near:heap)zero|=near.distance<=1e-12;
            double[][] count=new double[2][3];double sum=0;
            for(Near near:heap){double w=zero?(near.distance<=1e-12?1:0):1/Math.max(near.distance,1e-12);sum+=w;count[0][near.r.y3]+=w;count[1][near.r.y5]+=w;}
            for(int h=0;h<2;h++)for(int c=0;c<3;c++)out[s][h][c]=(float)(.8*count[h][c]/sum+.2*priorCount[h][c]/pool.size());
        }
        return out;
    }
    /** Encodes 4*symbol + 2*horizon + direction. Native 3m action only; fixed3 gate
     * suppresses 5m candidates. Same float32 .10 comparison as NumPy ledger. */
    public static int decide(int nativeAction,boolean entry,String grade,boolean[] safe,float[][][] p,boolean fixed3) {
        if(!entry||!"C".equals(grade)||nativeAction<0||nativeAction>=16||nativeAction%4>=2)return nativeAction;
        if(safe==null||safe.length!=4||p==null||p.length!=4)return nativeAction;
        for(int s=0;s<4;s++)if(safe[s]) {
            if(p[s]==null||p[s].length!=2)return nativeAction;
            for(int h=0;h<2;h++) {
                if(p[s][h]==null||p[s][h].length!=3)return nativeAction;double sum=0;
                for(float v:p[s][h]){if(!Float.isFinite(v)||v<0||v>1)return nativeAction;sum+=v;}
                if(Math.abs(sum-1)>1e-5)return nativeAction;
            }
        }
        int own=nativeAction/4,dir=nativeAction%2;if(!safe[own])return nativeAction;float base=p[own][0][dir==0?0:2];if(!Float.isFinite(base))return nativeAction;
        int best=-1;float conf=Float.NEGATIVE_INFINITY;
        for(int s=0;s<4;s++)if(safe[s])for(int h=0;h<(fixed3?1:2);h++)for(int d=0;d<2;d++){float value=p[s][h][d==0?0:2];if(Float.isFinite(value)&&value>conf){best=s*4+h*2+d;conf=value;}}
        return best>=0&&conf>base+.10f?best:nativeAction;
    }
}

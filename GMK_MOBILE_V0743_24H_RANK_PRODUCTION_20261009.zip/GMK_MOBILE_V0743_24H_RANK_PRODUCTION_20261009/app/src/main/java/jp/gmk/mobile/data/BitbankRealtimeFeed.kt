package jp.gmk.mobile.data

import jp.gmk.mobile.domain.RateRow
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/** Official ticker_btc_jpy Socket.IO / Engine.IO v4 subscription.
 * A dedicated socket never waits for Yahoo or scan HTTP slots. REST recovery is
 * owned by the caller; neither reconnect nor heartbeat refreshes a price timestamp.
 */
class BitbankRealtimeFeed(
    private val endpoint:String="wss://stream.bitbank.cc/socket.io/?EIO=4&transport=websocket",
    private val epochMillis:()->Long=System::currentTimeMillis
) {
    private val client=OkHttpClient.Builder().connectTimeout(3,TimeUnit.SECONDS)
        .readTimeout(0,TimeUnit.MILLISECONDS).callTimeout(0,TimeUnit.MILLISECONDS).build()
    private val _latest=MutableStateFlow<RateRow?>(null)
    val latest:StateFlow<RateRow?> = _latest
    @Volatile var status="STOPPED";private set
    @Volatile private var socket:WebSocket?=null
    @Volatile private var lastPacketMs=0L
    @Volatile private var lastError:String?=null
    @Volatile private var retryAfterMs=0L
    @Volatile private var job:Job?=null
    private val lifecycleLock=Any()
    private val generation=AtomicLong()
    private val connections=AtomicLong()
    private val failures=AtomicLong()
    private val accepted=AtomicLong()
    private val rejected=AtomicLong()
    private val heartbeats=AtomicLong()
    fun start(scope:CoroutineScope):Unit=synchronized(lifecycleLock) {
        if(job?.isActive==true)return@synchronized
        val token=generation.incrementAndGet()
        job=scope.launch(Dispatchers.IO) {
            var backoff=1000L
            try { coroutineScope {
                launch {
                    while(isActive) {
                        delay(1000)
                        synchronized(lifecycleLock) {
                            if(generation.get()==token && lastPacketMs>0 && epochMillis()-lastPacketMs>90_000)socket?.cancel()
                        }
                    }
                }
                while(isActive && generation.get()==token) {
                    val priorCount=accepted.get();status="CONNECTING";retryAfterMs=0;lastPacketMs=epochMillis()
                    connect(token)
                    if(!isActive || generation.get()!=token)break
                    status="RECONNECTING"
                    delay(maxOf(backoff,retryAfterMs))
                    backoff=if(accepted.get()>priorCount)1000 else minOf(15_000,backoff*2)
                }
            } } finally {
                // Parent cancellation must not leave SUBSCRIBED/fresh after the socket closes.
                // A cancelled previous owner also must not touch a replacement generation.
                synchronized(lifecycleLock) {
                    if(generation.get()==token) {
                        socket?.cancel();socket=null;status="STOPPED"
                    }
                }
            }
        }
    }
    private suspend fun connect(token:Long):Unit=suspendCancellableCoroutine { continuation ->
        val ended=AtomicBoolean(false)
        fun finish() { if(ended.compareAndSet(false,true))continuation.resume(Unit) }
        val listener=object:WebSocketListener() {
            private var joined=false
            override fun onOpen(ws:WebSocket,response:Response) {
                synchronized(lifecycleLock) {
                    if(generation.get()!=token || !continuation.isActive) { ws.cancel();return }
                    connections.incrementAndGet();lastPacketMs=epochMillis();status="HANDSHAKE"
                }
            }
            override fun onMessage(ws:WebSocket,text:String) {
                synchronized(lifecycleLock) {
                if(generation.get()!=token || !continuation.isActive)return
                if(text.length>64_000) { rejected.incrementAndGet();ws.cancel();return }
                lastPacketMs=epochMillis()
                try {
                    when {
                        text.startsWith("0{") -> { JSONObject(text.substring(1));ws.send("40") }
                        text=="2" -> { heartbeats.incrementAndGet();ws.send("3") }
                        text.startsWith("40") -> {
                            if(!joined) { joined=true;ws.send("42[\"join-room\",\"ticker_btc_jpy\"]");status="SUBSCRIBED";lastError=null }
                            Unit
                        }
                        text.startsWith("42") -> {
                            val packet=JSONArray(text.substring(2))
                            if(packet.optString(0)!="message")return
                            val envelope=packet.optJSONObject(1) ?: return
                            if(envelope.optString("room_name")!="ticker_btc_jpy")return
                            val data=envelope.optJSONObject("message")?.optJSONObject("data") ?: throw IllegalArgumentException("Ticker data missing")
                            val row=MarketRepository.decodeBitbankTicker(data,epochMillis(),"bitbank stream")
                            val timestamp=row.sourceEpochMs
                            val previous=_latest.value?.sourceEpochMs
                            if(row.price==null || timestamp==null || (previous!=null && timestamp<previous)) { rejected.incrementAndGet();return }
                            _latest.value=row;accepted.incrementAndGet()
                        }
                        text=="1" || text.startsWith("41") -> { ws.close(1000,"Server closed stream");finish() }
                        else -> Unit
                    }
                } catch(e:Exception) { rejected.incrementAndGet();lastError="INVALID_PACKET:${e.javaClass.simpleName}" }
                }
            }
            override fun onClosing(ws:WebSocket,code:Int,reason:String) { ws.close(code,reason) }
            override fun onClosed(ws:WebSocket,code:Int,reason:String) {
                synchronized(lifecycleLock) {
                    if(generation.get()==token && continuation.isActive)status="DISCONNECTED"
                    finish()
                }
            }
            override fun onFailure(ws:WebSocket,t:Throwable,response:Response?) {
                synchronized(lifecycleLock) {
                    if(generation.get()==token && continuation.isActive) {
                        failures.incrementAndGet();status="DISCONNECTED";lastError=t.javaClass.simpleName+":"+t.message?.take(120)
                        retryAfterMs=response?.header("Retry-After")?.toLongOrNull()?.takeIf { it in 0L..3600L }?.times(1000) ?: 0
                    }
                    finish()
                }
            }
        }
        val ws=client.newWebSocket(Request.Builder().url(endpoint).build(),listener)
        synchronized(lifecycleLock) {
            if(generation.get()==token && continuation.isActive)socket=ws else ws.cancel()
        }
        continuation.invokeOnCancellation { ended.set(true);ws.cancel() }
    }
    fun hasFreshStream(nowMs:Long):Boolean {
        val row=_latest.value ?: return false
        val source=row.sourceEpochMs ?: return false
        val received=row.receivedEpochMs ?: return false
        return job?.isActive==true && status=="SUBSCRIBED" && row.freshnessStatus=="LIVE" && nowMs-source in 0L..3000L && nowMs-received in 0L..3000L
    }
    fun diagnosticStats():JSONObject {
        val nowMs=epochMillis();val row=_latest.value
        fun ageMs(stamp:Long?):Any = if(stamp!=null && stamp in 1L..nowMs)nowMs-stamp else JSONObject.NULL
        return JSONObject().put("status",status).put("connections",connections.get())
            .put("failures",failures.get()).put("accepted_ticks",accepted.get()).put("rejected_ticks",rejected.get())
            .put("heartbeat_packets",heartbeats.get()).put("owner_active",job?.isActive==true)
            .put("stream_fresh_as_of_ms",nowMs).put("has_fresh_stream",hasFreshStream(nowMs))
            .put("last_packet_age_ms",ageMs(lastPacketMs.takeIf { it>0 }))
            .put("last_source_age_ms",ageMs(row?.sourceEpochMs)).put("last_received_age_ms",ageMs(row?.receivedEpochMs))
            .put("last_error",lastError ?: JSONObject.NULL).put("last_source_epoch_ms",row?.sourceEpochMs ?: JSONObject.NULL)
            .put("transport","BITBANK_SOCKET_IO_EIO4_WITH_INDEPENDENT_REST_RECOVERY")
    }
    fun stop():Unit=synchronized(lifecycleLock) {
        generation.incrementAndGet();job?.cancel();job=null;socket?.cancel();socket=null;status="STOPPED"
        client.dispatcher.cancelAll()
    }
}

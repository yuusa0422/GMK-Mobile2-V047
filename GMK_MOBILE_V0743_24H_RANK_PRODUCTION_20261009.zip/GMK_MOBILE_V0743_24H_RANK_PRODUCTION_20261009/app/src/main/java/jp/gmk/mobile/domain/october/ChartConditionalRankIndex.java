package jp.gmk.mobile.domain.october;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/** Frozen, chart-only200 real-example relative E-H assessment.
 *
 * This index has no ENTRY, direction or horizon authority. It contains the FULL
 * strictly pre-October eligible bank, not the examples selected by an October
 * replay. The immutable bank and frozen calibration cannot learn query results.
 * Calendar feature indices30:35 are ignored. No live observations are appended.
 */
public final class ChartConditionalRankIndex {
    public static final String VERSION="GMK_V0742_OCTOBER_CHART200_EH";
    public static final long SNAPSHOT_UTC=1790780400L;
    public static final String SOURCE_POOL_SHA256="7d3a8d49769109589c4addeeef52bb480054950672983a235cb8148e99958ac3";
    public static final String CALIBRATION_FILE_SHA256="881261226786fc9880ffaa50a55995391bf3c2f91175e4663f7a10587ce2f6cc";
    public static final String GRADE_FILE_SHA256="417014ef8fb606d6f8af76e9bea010d35b551990ae9ad9c4a9419a5f104efdfc";
    public static final String CHART_CORE_SHA256="2199e047b7fd5a4feefc1c573d1fdb7b5b3143b0364c0124e5c8f222b2553148";
    private static final String[] CANONICAL_SYMBOLS={"USDJPY","EURJPY","GBPJPY","AUDJPY"};
    public static final String[] SYMBOLS=CANONICAL_SYMBOLS.clone();
    private static final int FEATURES=30,NEIGHBORS=200,ROW_COUNT=270501;
    private static final int[] EXPECTED_ROWS={67547,67656,67643,67655};
    private static final int[][] GROUPS={{0,1,2,3,4,5,6},{7,8,9,10,11,12,13,14,15,16},
            {17,18,19,20,21,27,28,29},{22,23,24,25,26}};
    private static final ZoneOffset JST=ZoneOffset.ofHours(9);
    private final Bank[] banks;
    private final boolean calibrationSupported;
    private final double rawMinimum,rawMaximum;
    private final double[] calibrationEdges,gradeEdges;
    private final Block[] blocks;
    private final String[] gradeLabels;
    private volatile Match recentMatch; // Optional immutable same-query reuse for HIGH/LOW.

    public static final class DeadlineExceededException extends IllegalStateException {
        public DeadlineExceededException(){super("CHART200_INFERENCE_DEADLINE");}
    }
    /** Arrays are independent per result. Mutating diagnostics cannot alter the model. */
    public static final class Result {
        public final String rank,grade,statusReason,evidenceStatus,modelVersion,direction,calibrationBlockId,
                querySymbol,queryChartFeaturesFloat32Sha256;
        public final long queryBoundaryUtc,snapshotUtc,maxNeighborAvailableUtc,maxNeighborBoundaryUtc;
        public final double rawProbability,weightedProbability,shrunkProbability,calibratedProbability,
                sameSymbolDirectionPrior,effectiveSampleSize,effectiveReferenceDays,distanceMin,distanceMedian,distanceMax,
                calibrationIntervalLow,calibrationIntervalHigh;
        public final int supportN,referenceDates,sourcePoolCount,calibrationCaseCount,calibrationWins,querySymbolIndex;
        public final boolean chartSupport,calibrationSupport,outOfCalibrationRange;
        public final long[] neighborIds,neighborBoundaries,neighborAvailable;
        public final int[] neighborLabels;
        public final double[] distances,weights;
        public final String neighborIdSequenceSha256;
        private Result(String rank,String reason,String direction,long boundary,Match m,double raw,double weighted,
                double shrunk,double prior,double calibrated,int blockIndex,Block block,boolean calibrationSupport,
                boolean outOfRange){
            this.rank=rank;grade=rank;statusReason=reason;evidenceStatus=m.support?"REAL_200_DIVERSE":
                    (m.rows.length<NEIGHBORS?"INSUFFICIENT_REAL_HISTORY":"LOW_DIVERSITY_OR_EFFECTIVE_N");
            modelVersion=VERSION;this.direction=direction;queryBoundaryUtc=boundary;snapshotUtc=SNAPSHOT_UTC;
            querySymbolIndex=m.symbol;querySymbol=CANONICAL_SYMBOLS[m.symbol];queryChartFeaturesFloat32Sha256=chartFeatureHash(m.query);
            rawProbability=raw;weightedProbability=weighted;shrunkProbability=shrunk;sameSymbolDirectionPrior=prior;
            calibratedProbability=calibrated;supportN=m.rows.length;referenceDates=m.uniqueDays;
            effectiveSampleSize=m.effectiveN;effectiveReferenceDays=m.effectiveDays;chartSupport=m.support;
            this.calibrationSupport=calibrationSupport;outOfCalibrationRange=outOfRange;sourcePoolCount=m.bank.size;
            calibrationCaseCount=block.count;calibrationWins=block.wins;calibrationBlockId=String.format(Locale.ROOT,"block_%02d",blockIndex);
            calibrationIntervalLow=block.intervalLow;calibrationIntervalHigh=block.intervalHigh;
            distances=m.distances.clone();weights=m.weights.clone();neighborIds=new long[supportN];
            neighborBoundaries=new long[supportN];neighborAvailable=new long[supportN];neighborLabels=new int[supportN];
            long latestAvailable=0,latestBoundary=0;
            for(int i=0;i<supportN;i++){int row=m.rows[i];neighborIds[i]=m.bank.ids[row];neighborBoundaries[i]=m.bank.boundaries[row];
                neighborAvailable[i]=m.bank.available[row];neighborLabels[i]=m.bank.labels[row];
                latestAvailable=Math.max(latestAvailable,neighborAvailable[i]);latestBoundary=Math.max(latestBoundary,neighborBoundaries[i]);}
            maxNeighborAvailableUtc=latestAvailable;maxNeighborBoundaryUtc=latestBoundary;
            distanceMin=distances[0];distanceMax=distances[supportN-1];distanceMedian=(supportN%2==1)?distances[supportN/2]:
                    (distances[supportN/2-1]+distances[supportN/2])/2;
            neighborIdSequenceSha256=idHash(neighborIds);
        }
    }
    private static final class Bank {
        final int size;final int[] ids;final long[] boundaries,available;final byte[] labels;
        final float[] features;final double[] median,iqr;final double lowPrior,highPrior;
        Bank(int n,double[] median,double[] iqr,double low,double high){size=n;ids=new int[n];boundaries=new long[n];available=new long[n];
            labels=new byte[n];features=new float[n*FEATURES];this.median=median;this.iqr=iqr;lowPrior=low;highPrior=high;}
    }
    private static final class Block {
        final int count,wins,dates;final double probability,intervalLow,intervalHigh;
        Block(int n,int w,int dates,double p,double lo,double hi){count=n;wins=w;this.dates=dates;probability=p;intervalLow=lo;intervalHigh=hi;}
    }
    private static final class Match {
        final long boundary;final int symbol;final float[] query;final Bank bank;final int[] rows;
        final double[] distances,weights;final double effectiveN,effectiveDays;final int uniqueDays;final boolean support;
        Match(long boundary,int symbol,float[] query,Bank bank,int[] rows,double[] distances,double[] weights,
                double neff,double effectiveDays,int days){this.boundary=boundary;this.symbol=symbol;this.query=query;
            this.bank=bank;this.rows=rows;this.distances=distances;this.weights=weights;effectiveN=neff;
            this.effectiveDays=effectiveDays;uniqueDays=days;support=rows.length==NEIGHBORS&&days>50&&neff>=100;}
    }
    private ChartConditionalRankIndex(Bank[] banks,boolean supported,double minimum,double maximum,double[] edges,
            Block[] blocks,double[] gradeEdges,String[] gradeLabels){this.banks=banks;calibrationSupported=supported;
        rawMinimum=minimum;rawMaximum=maximum;calibrationEdges=edges;this.blocks=blocks;this.gradeEdges=gradeEdges;this.gradeLabels=gradeLabels;}

    public static ChartConditionalRankIndex readCompressed(InputStream input,String expectedRawSha256) throws IOException {
        return readCompressed(input,expectedRawSha256,0);
    }
    public static ChartConditionalRankIndex readCompressed(InputStream input,String expectedRawSha256,long deadlineNs) throws IOException {
        if(input==null||expectedRawSha256==null||!expectedRawSha256.matches("[0-9a-f]{64}"))throw new IOException("CHART200_REQUIRED_SHA256");
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try(DataInputStream in=new DataInputStream(new BufferedInputStream(new DigestInputStream(new GZIPInputStream(input),digest),65536))){
                checkDeadline(deadlineNs);
                if(in.readInt()!=0x474d4352||in.readInt()!=1||in.readInt()!=4||in.readInt()!=FEATURES||in.readLong()!=SNAPSHOT_UTC||in.readInt()!=ROW_COUNT)
                    throw new IOException("CHART200_ASSET_SCHEMA");
                if(!SOURCE_POOL_SHA256.equals(in.readUTF())||!CALIBRATION_FILE_SHA256.equals(in.readUTF())||
                        !GRADE_FILE_SHA256.equals(in.readUTF())||!CHART_CORE_SHA256.equals(in.readUTF()))throw new IOException("CHART200_FROZEN_SOURCE_SHA256");
                boolean support=in.readBoolean();double minimum=in.readDouble(),maximum=in.readDouble();int trainingN=in.readInt(),blockN=in.readInt();
                if(!support||trainingN!=269||blockN!=4||minimum!=0.3888106015455521||maximum!=0.5872298952240342)throw new IOException("CHART200_CALIBRATION_SCHEMA");
                double[] edges=new double[blockN-1];for(int i=0;i<edges.length;i++)edges[i]=in.readDouble();
                Block[] blocks=new Block[blockN];int total=0;double previous=-1;
                for(int i=0;i<blockN;i++){int n=in.readInt(),w=in.readInt(),dates=in.readInt();double p=in.readDouble(),lo=in.readDouble(),hi=in.readDouble();
                    if(n<20||w<0||w>n||dates<1||dates>n||p!=(double)w/n||p<=previous||!(lo>=0&&lo<=p&&p<=hi&&hi<=1))throw new IOException("CHART200_CALIBRATION_BLOCK");
                    blocks[i]=new Block(n,w,dates,p,lo,hi);previous=p;total+=n;}
                if(total!=trainingN)throw new IOException("CHART200_CALIBRATION_COUNT");
                for(int i=0;i<edges.length;i++)if(!Double.isFinite(edges[i])||edges[i]<minimum||edges[i]>maximum||(i>0&&edges[i]<=edges[i-1]))throw new IOException("CHART200_CALIBRATION_EDGES");
                if(in.readInt()!=4)throw new IOException("CHART200_FOUR_SUPPORTED_RANKS_REQUIRED");
                double[] gradeEdges=new double[3];for(int i=0;i<3;i++)gradeEdges[i]=in.readDouble();
                String[] labels=new String[4];String[] expected={"H","G","F","E"};for(int i=0;i<4;i++){labels[i]=in.readUTF();if(!labels[i].equals(expected[i]))throw new IOException("CHART200_RANK_ORDER");}
                for(int i=0;i<3;i++)if(gradeEdges[i]!=(blocks[i].probability+blocks[i+1].probability)/2)throw new IOException("CHART200_RANK_EDGES");
                Bank[] banks=new Bank[4];boolean[] seenIds=new boolean[271845];int rowTotal=0;
                for(int s=0;s<4;s++){
                    int n=in.readInt();if(n!=EXPECTED_ROWS[s])throw new IOException("CHART200_FULL_BANK_COUNT");
                    double[] median=new double[FEATURES],iqr=new double[FEATURES];
                    for(int j=0;j<FEATURES;j++){median[j]=in.readDouble();if(!Double.isFinite(median[j]))throw new IOException("CHART200_NONFINITE_MEDIAN");}
                    for(int j=0;j<FEATURES;j++){iqr[j]=in.readDouble();if(!Double.isFinite(iqr[j])||iqr[j]<=0)throw new IOException("CHART200_INVALID_IQR");}
                    double low=in.readDouble(),high=in.readDouble();if(!Double.isFinite(low)||!Double.isFinite(high)||low<0||high<0||low+high>1)throw new IOException("CHART200_INVALID_PRIOR");
                    Bank bank=new Bank(n,median,iqr,low,high);long prevBoundary=Long.MIN_VALUE;int lowCount=0,highCount=0;
                    for(int i=0;i<n;i++){
                        if((i&1023)==0)checkDeadline(deadlineNs);
                        int id=in.readInt();long boundary=in.readLong();int delta=in.readInt(),label=in.readUnsignedByte();
                        if(id<0||id>=seenIds.length||seenIds[id]||boundary<=prevBoundary||Math.floorMod(boundary,300)!=0||delta<=0||label>2||boundary>=SNAPSHOT_UTC||boundary+delta>=SNAPSHOT_UTC)
                            throw new IOException("CHART200_INVALID_REAL_RECORD");
                        seenIds[id]=true;prevBoundary=boundary;bank.ids[i]=id;bank.boundaries[i]=boundary;bank.available[i]=boundary+delta;bank.labels[i]=(byte)label;
                        if(label==0)lowCount++;if(label==2)highCount++;
                        for(int j=0;j<FEATURES;j++){float v=in.readFloat();if(!Float.isFinite(v))throw new IOException("CHART200_NONFINITE_HISTORY");bank.features[i*FEATURES+j]=v;}
                    }
                    if(low!=(double)lowCount/n||high!=(double)highCount/n)throw new IOException("CHART200_FULL_BANK_PRIOR_MISMATCH");
                    banks[s]=bank;rowTotal+=n;
                }
                if(rowTotal!=ROW_COUNT||in.read()!=-1)throw new IOException("CHART200_TRAILING_BYTES_OR_COUNT");
                if(!hex(digest.digest()).equals(expectedRawSha256))throw new IOException("CHART200_ASSET_SHA256_MISMATCH");
                checkDeadline(deadlineNs);
                return new ChartConditionalRankIndex(banks,support,minimum,maximum,edges,blocks,gradeEdges,labels);
            }
        }catch(NoSuchAlgorithmException e){throw new IOException("SHA256 unavailable",e);}
    }
    public int observationCount(){return ROW_COUNT;}
    public int sameSymbolObservationCount(int symbol){if(symbol<0||symbol>=4)throw new IllegalArgumentException("Unsupported chart200 symbol");return banks[symbol].size;}
    public long snapshotEpoch(){return SNAPSHOT_UTC;}
    public static int symbolIndex(String symbol){for(int i=0;i<4;i++)if(CANONICAL_SYMBOLS[i].equals(symbol))return i;throw new IllegalArgumentException("Unsupported chart200 symbol");}
    /** Outcome-free identity of exactly the30 chart inputs used in distance.
     * Calendar fields30:35 are ignored consistently with the predictor. */
    public static String chartFeatureHash(float[] technical35){
        if(technical35==null||(technical35.length!=30&&technical35.length!=35))throw new IllegalArgumentException("30 or35 technical features required");
        try{MessageDigest digest=MessageDigest.getInstance("SHA-256");for(int i=0;i<FEATURES;i++){
                float value=technical35[i];if(!Float.isFinite(value))throw new IllegalArgumentException("Nonfinite chart feature");
                int bits=Float.floatToIntBits(value);for(int shift=24;shift>=0;shift-=8)digest.update((byte)(bits>>>shift));}
            return hex(digest.digest());
        }catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}
    }

    /** Features must retain the technical extractor's float32 values. Index30:35
     * neither enters the distance nor requires finiteness. A deadline aborts the
     * complete assessment; partially selected neighbours never receive a rank. */
    public Result predict(long boundaryUtc,int symbol,String direction,float[] technical35,long deadlineNs){
        checkDeadline(deadlineNs);if(symbol<0||symbol>=4)throw new IllegalArgumentException("Unsupported chart200 symbol");
        if(direction==null)throw new IllegalArgumentException("Direction HIGH or LOW required");String d=direction.toUpperCase(Locale.ROOT);
        if(!d.equals("HIGH")&&!d.equals("LOW"))throw new IllegalArgumentException("Direction HIGH or LOW required");
        ZonedDateTime when=Instant.ofEpochSecond(boundaryUtc).atZone(JST);
        if(when.getYear()!=2026||when.getMonthValue()!=10)throw new IllegalArgumentException("CHART200_FROZEN_OCTOBER_ONLY");
        if(technical35==null||(technical35.length!=30&&technical35.length!=35))throw new IllegalArgumentException("30 or35 technical features required");
        float[] query=Arrays.copyOf(technical35,FEATURES);for(float v:query)if(!Float.isFinite(v))throw new IllegalArgumentException("Nonfinite chart feature");
        Match m=recentMatch;
        if(m==null||m.boundary!=boundaryUtc||m.symbol!=symbol||!Arrays.equals(m.query,query)){m=match(boundaryUtc,symbol,query,deadlineNs);recentMatch=m;}
        checkDeadline(deadlineNs);int wanted=d.equals("HIGH")?2:0,wins=0;double weighted=0;
        for(int i=0;i<m.rows.length;i++)if(m.bank.labels[m.rows[i]]==wanted){wins++;weighted+=m.weights[i];}
        double raw=(double)wins/m.rows.length,prior=d.equals("HIGH")?m.bank.highPrior:m.bank.lowPrior;
        double shrunk=(m.rows.length*weighted+20*prior)/(m.rows.length+20);
        int blockIndex=upperBound(calibrationEdges,shrunk);Block block=blocks[blockIndex];
        boolean outside=shrunk<rawMinimum||shrunk>rawMaximum;
        boolean supported=calibrationSupported&&block.count>=20&&!outside;
        String rank=m.support&&supported?gradeLabels[upperBound(gradeEdges,block.probability)]:"UNRANKED";
        String reason=!m.support?"INSUFFICIENT_REAL_CHART_SUPPORT":(!calibrationSupported||block.count<20)?
                "INSUFFICIENT_REAL_CALIBRATION_CASES":outside?"OUT_OF_CALIBRATION_RANGE":"PAST_OUTCOME_CALIBRATED_RELATIVE";
        checkDeadline(deadlineNs);
        Result result=new Result(rank,reason,d,boundaryUtc,m,raw,weighted,shrunk,prior,block.probability,blockIndex,block,supported,outside);
        checkDeadline(deadlineNs);return result;
    }
    private Match match(long boundary,int symbol,float[] query,long deadlineNs){
        Bank bank=banks[symbol];int n=bank.size;double[] queryZ=new double[FEATURES];
        for(int j=0;j<FEATURES;j++)queryZ[j]=((double)query[j]-bank.median[j])/bank.iqr[j];
        double[] squared=new double[n];int[] order=new int[n];
        for(int row=0;row<n;row++){
            if((row&1023)==0)checkDeadline(deadlineNs);double total=0;int offset=row*FEATURES;
            for(int[] group:GROUPS){double sum=0;for(int j:group){double delta=((double)bank.features[offset+j]-bank.median[j])/bank.iqr[j]-queryZ[j];
                    delta=Math.max(-6,Math.min(6,delta));sum+=delta*delta;}total+=sum/group.length;}
            squared[row]=.25*total;order[row]=row;
        }
        sort(order,squared,bank,0,n-1,deadlineNs);
        int[] chosen=new int[NEIGHBORS];int count=0;Map<Long,long[]> byDay=new HashMap<>();
        for(int at=0;at<n&&count<NEIGHBORS;at++){
            if((at&1023)==0)checkDeadline(deadlineNs);int row=order[at];long stamp=bank.boundaries[row];
            if(bank.available[row]>=SNAPSHOT_UTC||stamp>=boundary)throw new IllegalStateException("CHART200_CAUSAL_ELIGIBILITY");
            long day=Math.floorDiv(stamp+32400,86400);long[] previous=byDay.get(day);int used=previous==null?0:(int)previous[4];
            if(used>=4)continue;boolean tooClose=false;for(int i=0;i<used;i++)if(Math.abs(stamp-previous[i])<3600){tooClose=true;break;}
            if(tooClose)continue;if(previous==null){previous=new long[5];byDay.put(day,previous);}previous[used]=stamp;previous[4]=used+1;chosen[count++]=row;
        }
        if(count==0)throw new IllegalStateException("CHART200_NO_REAL_NEIGHBOR");chosen=Arrays.copyOf(chosen,count);
        double[] distances=new double[count],weights=new double[count];double sum=0;
        for(int i=0;i<count;i++){distances[i]=Math.sqrt(squared[chosen[i]]);weights[i]=1/(.25+distances[i]);sum+=weights[i];}
        double sumSquares=0;Map<Long,Double> dayWeights=new HashMap<>();
        for(int i=0;i<count;i++){weights[i]/=sum;sumSquares+=weights[i]*weights[i];long day=Math.floorDiv(bank.boundaries[chosen[i]]+32400,86400);
            Double old=dayWeights.get(day);dayWeights.put(day,(old==null?0:old)+weights[i]);}
        long[] days=new long[dayWeights.size()];int dayAt=0;for(Long day:dayWeights.keySet())days[dayAt++]=day;Arrays.sort(days);
        double daySquared=0;for(long day:days){double w=dayWeights.get(day);daySquared+=w*w;}
        checkDeadline(deadlineNs);return new Match(boundary,symbol,query,bank,chosen,distances,weights,1/sumSquares,1/daySquared,days.length);
    }
    private static int compare(int left,int right,double[] distances,Bank bank){int c=Double.compare(distances[left],distances[right]);
        if(c!=0)return c;c=Long.compare(bank.boundaries[left],bank.boundaries[right]);return c!=0?c:Integer.compare(bank.ids[left],bank.ids[right]);}
    private static void sort(int[] order,double[] distances,Bank bank,int low,int high,long deadlineNs){
        while(low<high){checkDeadline(deadlineNs);int i=low,j=high,pivot=order[low+(high-low)/2];
            while(i<=j){while(compare(order[i],pivot,distances,bank)<0)i++;while(compare(order[j],pivot,distances,bank)>0)j--;
                if(i<=j){int temp=order[i];order[i++]=order[j];order[j--]=temp;}}
            // Recurse into the smaller partition to bound call-stack memory.
            if(j-low<high-i){if(low<j)sort(order,distances,bank,low,j,deadlineNs);low=i;}
            else{if(i<high)sort(order,distances,bank,i,high,deadlineNs);high=j;}
        }
    }
    private static int upperBound(double[] edges,double value){int low=0,high=edges.length;while(low<high){int mid=(low+high)>>>1;
        if(value>=edges[mid])low=mid+1;else high=mid;}return low;}
    private static void checkDeadline(long deadlineNs){if(Thread.currentThread().isInterrupted()||(deadlineNs>0&&System.nanoTime()>deadlineNs))throw new DeadlineExceededException();}
    private static String idHash(long[] ids){try{MessageDigest digest=MessageDigest.getInstance("SHA-256");for(long id:ids){for(int i=0;i<8;i++)digest.update((byte)(id>>>(8*i)));}return hex(digest.digest());}
        catch(NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
    private static String hex(byte[] bytes){StringBuilder result=new StringBuilder(bytes.length*2);for(byte value:bytes)result.append(String.format(Locale.ROOT,"%02x",value&255));return result.toString();}
}

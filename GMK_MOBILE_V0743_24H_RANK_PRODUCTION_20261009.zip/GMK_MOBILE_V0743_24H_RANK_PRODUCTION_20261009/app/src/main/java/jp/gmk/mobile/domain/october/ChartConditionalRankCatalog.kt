package jp.gmk.mobile.domain.october

import android.content.res.AssetManager
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.SequenceInputStream
import java.util.Enumeration

object ChartConditionalRankCatalog {
    const val RAW_SHA256 = "ed9dd5af193bfee2c3b5b9834b90b8ab8cb6fd8192cc9a166dfab0a76f1dcec4"
    private fun load(open: (String) -> InputStream): ChartConditionalRankIndex {
        val parts = (1..2).iterator()
        var stopped = false
        val streams = object : Enumeration<InputStream> {
            override fun hasMoreElements() = !stopped && parts.hasNext()
            override fun nextElement(): InputStream = open("october_chart_rank/index.bin.gz.part" + parts.next().toString().padStart(2, '0'))
        }
        return SequenceInputStream(streams).use {
            try { ChartConditionalRankIndex.readCompressed(it, RAW_SHA256) }
            finally { stopped = true }
        }
    }
    fun loadIndex(assets: AssetManager): ChartConditionalRankIndex = load { assets.open(it) }
    fun loadIndex(assetBytes: (String) -> ByteArray): ChartConditionalRankIndex = load { ByteArrayInputStream(assetBytes(it)) }
}

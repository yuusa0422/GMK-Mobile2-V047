package jp.gmk.mobile.domain.horizon

import jp.gmk.mobile.domain.*
import java.time.ZonedDateTime

data class PreparedHorizonFrame(val boundary: Long, val service: HorizonFeatureService,
    val features: Array<Array<FloatArray>>, val preparedMs: Long)
data class HorizonAdapterState(val scores: List<Double>, val boundary: Long, val result: ScanResult?)

/** Existing scan API remains the sole entry point. The adapter protects native ENTRY first. */
class HorizonScanAdapter(private val models: List<PortableTreeModel>, private val correction: PortableTreeModel,
    seed: List<Double> = emptyList(), private val epochMillis: () -> Long = System::currentTimeMillis) {
    private val gate=PastCoverageGate(seed)
    private val joint=JointHorizonPolicy(models,gate)
    private val flip=HorizonFlipPolicy(correction)
    private var lastBoundary=0L
    private var lastResult: ScanResult?=null
    @Volatile var status="WARMING"; private set
    @Volatile var lastInferenceMs=0.0; private set
    fun snapshot(): List<Double> = synchronized(this) { gate.snapshot() }
    fun checkpointState(): HorizonAdapterState = synchronized(this) { HorizonAdapterState(gate.snapshot(),lastBoundary,lastResult) }
    fun restoreState(state: HorizonAdapterState) = synchronized(this) {
        gate.restore(state.scores);lastBoundary=state.boundary;lastResult=state.result
    }

    fun prepare(prices: Map<String,List<Candle>>, boundary: Long): PreparedHorizonFrame? {
        if(!HorizonFeatureService.scheduled(boundary) || boundary-10<HorizonModelCatalog.AVAILABLE_FROM_EPOCH)return null
        // Preparation and publication must use the same clock as the runtime.
        val budgetMs=minOf(8000L,(boundary-12)*1000-epochMillis())
        if(budgetMs<=0)return null
        val service=HorizonFeatureService(prices,emptyMap(),boundary,LocalRuleEngine(),System.nanoTime()+budgetMs*1_000_000)
        // Warm frames still capture causal R13 context, as the PC does. Models cannot
        // supplement until the separate readiness guard below succeeds.
        val columns=models.mapIndexed { j,m->service.jointFeatures(m.featureNames,intArrayOf(3,10,15)[j]) }
        return PreparedHorizonFrame(boundary,service,Array(6){s->Array(3){j->columns[j][s]}},epochMillis())
    }

    @Synchronized
    fun apply(native: ScanResult, candles: Map<String,List<Candle>>, prepared: PreparedHorizonFrame?,
        quotes: Map<String,HorizonQuote>, nowMs: Long=epochMillis()): ScanResult {
        val began=System.nanoTime()
        val entry=runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return native
        val boundary=entry.toEpochSecond()
        if(native.source!="AUTO" || !HorizonFeatureService.scheduled(boundary)) { status="NATIVE_MANUAL";return native }
        if(boundary==lastBoundary)return lastResult ?: native
        if(boundary<lastBoundary) { status="OUT_OF_ORDER_NATIVE";return native }
        val top=native.top1 ?: return native
        val seed = gate.snapshot()
        val close = candles[top.instrument].orEmpty().lastOrNull { it.timeEpochMs/1000 <= boundary-70 }?.close ?: Double.NaN
        val safeNative = HorizonFeatureService.nativeQuoteSafe(top.instrument,quotes[top.instrument],boundary,close)
        val fallbackNative = if (top.decision=="ENTRY" && !safeNative) native.copy(candidates=native.candidates.map {
            if (it.rank==1) it.copy(grade="E",decision="SKIP",reasons=it.reasons+"PC_QUOTE_SAFETY_SKIP",
                assessment=CandidateAssessmentFactory.correction(it,top,it.direction,"E","SKIP",3,"レート安全性による見送り",CandidateSkipReason.QUOTE_UNSAFE)) else it
        }) else native
        fun finish(result: ScanResult, reason: String): ScanResult {
            lastBoundary=boundary;lastResult=result;status=reason
            lastInferenceMs=(System.nanoTime()-began)/1e6
            return result
        }
        // PC protects native ENTRY only when the frozen quote is tradable.
        if(top.decision=="ENTRY" && safeNative) {
            gate.decide(Double.POSITIVE_INFINITY,true,true)
            return finish(native,"NATIVE_ENTRY_PROTECTED")
        }
        fun fallback(reason: String): ScanResult {
            gate.decide(Double.NEGATIVE_INFINITY,false,false)
            return finish(fallbackNative,reason)
        }
        if(boundary-10<HorizonModelCatalog.AVAILABLE_FROM_EPOCH)return fallback("MODEL_NOT_AVAILABLE_AT_SCAN")
        if(boundary*1000-nowMs<500)return fallback("DEADLINE_NATIVE")
        if(prepared==null || prepared.boundary!=boundary)return fallback("WARMING_OR_FRAME_MISSING")
        if(!prepared.service.matchesNative(candles))return fallback("INPUT_REVISION_NATIVE")
        if(!prepared.service.ready)return fallback("WARMING_NEED_4000_M1_BARS")
        return try {
            val service=prepared.service
            service.attachQuotes(quotes)
            service.fillQuotes(prepared.features,models.map { it.featureNames })
            val base=HorizonDecision(HorizonFeatureService.SYMBOLS.indexOf(top.instrument),top.direction=="HIGH",3,false)
            val safe=BooleanArray(6) { service.strictSafe(it) }
            val choice=joint.choose(prepared.features,safe,base)
            if(!choice.decision.entry)return finish(fallbackNative,"COVERAGE_GATE_SKIP")
            val d=choice.decision
            val corrected=flip.correct(d,if(d.minutes==15 && service.pathValid())service.flipFeatures(d.symbol,d.high,correction.featureNames) else null,
                safe[d.symbol],service.pathValid(),false,boundary)
            val final=corrected.decision
            val symbol=HorizonFeatureService.SYMBOLS[final.symbol]
            val nativeTarget=native.candidates.single { it.instrument==symbol }
            val chosenDirection=if(final.high)"HIGH" else "LOW"
            val candidate=nativeTarget.copy(
                rank=1,direction=chosenDirection,grade="R",probability=null,decision="ENTRY",
                reasons=listOf("判定: ${final.minutes}分",HorizonModelCatalog.VERSION,corrected.reason)+
                    listOfNotNull(corrected.utility?.let { "paired_utility=$it" }),
                assessment=CandidateAssessmentFactory.correction(nativeTarget,top,chosenDirection,"R","ENTRY",final.minutes,HorizonModelCatalog.VERSION+":"+corrected.reason))
            val candidates=listOf(candidate)+native.candidates.filter { it.instrument!=symbol }.sortedBy { it.rank }.mapIndexed { i,c->c.copy(rank=i+2) }
            finish(native.copy(judgeTimeJst=entry.plusMinutes(final.minutes.toLong()).toString(),candidates=candidates),
                if(corrected.changed)"R15_APPLIED" else "JOINT_${final.minutes}M")
        } catch(e: Exception) {
            // Restore the proposal seed before recording a single technical failure.
            gate.restore(seed)
            fallback("ADAPTER_ERROR_NATIVE:${e.javaClass.simpleName}")
        }
    }
}

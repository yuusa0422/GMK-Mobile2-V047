package jp.gmk.mobile.domain.october

import jp.gmk.mobile.domain.*
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

data class ChartConditionalRankFrame(
    val boundary: Long,
    val preparedMs: Long,
    val features: Map<String, FloatArray>,
    val predictions: Map<String, ChartConditionalRankIndex.Result>,
    val unavailable: Map<String, String>
)

/** Frozen, chart-only labels for native TOP1 E/SKIP in AUTO and MANUAL.
 * Complete M1 bars and an explicit publication deadline also protect on-demand retrieval.
 */
class ChartConditionalRankAdapter(
    private val index: ChartConditionalRankIndex?,
    private val clockMillis: () -> Long = System::currentTimeMillis
) {
    companion object {
        private val JST = ZoneId.of("Asia/Tokyo")
        fun supports(boundary: Long): Boolean {
            val t = Instant.ofEpochSecond(boundary).atZone(JST)
            return boundary >= ChartConditionalRankIndex.SNAPSHOT_UTC &&
                t.year == 2026 && t.monthValue == 10
        }
        fun originalResearchScope(boundary: Long): Boolean {
            val t = Instant.ofEpochSecond(boundary).atZone(JST)
            return supports(boundary) && boundary % 300L == 0L &&
                t.dayOfWeek.value <= 5 && t.hour in 9..14
        }
        // Entry minus ten seconds is the input cutoff. A manual entry need not
        // lie on a minute boundary; never shift candles or invent partial M1 bars.
        fun featureBoundary(boundary: Long): Long = Math.floorDiv(boundary - 10, 60) * 60 + 60
        private fun key(symbol: String, direction: String) = "$symbol:$direction"
        private fun finite(value: Double): Double? = value.takeIf { it.isFinite() }
    }
    @Volatile var status: String = "WARMING"; private set
    @Volatile var prepareMs: Double = 0.0; private set
    @Volatile var inferenceMs: Double = 0.0; private set
    @Volatile var lastGrade: String = "UNRANKED"; private set

    fun prepare(prices: Map<String, List<Candle>>, boundary: Long, budgetMs: Long = 1800): ChartConditionalRankFrame {
        require(supports(boundary))
        val started = System.nanoTime()
        val deadline = started + budgetMs.coerceAtLeast(1) * 1_000_000L
        val features = linkedMapOf<String, FloatArray>()
        val predictions = linkedMapOf<String, ChartConditionalRankIndex.Result>()
        val unavailable = linkedMapOf<String, String>()
        for ((symbolIndex, symbol) in ChartConditionalRankIndex.SYMBOLS.withIndex()) {
            val x = OctoberSimilarityScanAdapter.features(prices[symbol].orEmpty(), featureBoundary(boundary))
            if (x == null) {
                unavailable[symbol] = "MISSING_CONTIGUOUS_61_M1_BARS"
                continue
            }
            features[symbol] = x.copyOf()
            for (direction in listOf("HIGH", "LOW")) {
                try {
                    predictions[key(symbol, direction)] = requireNotNull(index).predict(boundary, symbolIndex, direction, x, deadline)
                } catch (_: ChartConditionalRankIndex.DeadlineExceededException) {
                    unavailable[key(symbol, direction)] = "PREPARE_DEADLINE"
                } catch (e: IllegalArgumentException) {
                    unavailable[key(symbol, direction)] = "INVALID_CHART_INPUT:${e.javaClass.simpleName}"
                }
            }
        }
        prepareMs = (System.nanoTime() - started) / 1e6
        status = if (predictions.isEmpty()) "FRAME_UNAVAILABLE" else "FRAME_READY"
        return ChartConditionalRankFrame(boundary, clockMillis(), features, predictions, unavailable)
    }

    fun apply(native: ScanResult, selected: ScanResult, candles: Map<String, List<Candle>>,
              frame: ChartConditionalRankFrame?, unavailableReason: String = "FRAME_NOT_READY"): ScanResult {
        val top = native.top1 ?: return selected
        if (native.source !in setOf("AUTO", "MANUAL") || top.grade != "E" || top.decision != "SKIP") return selected
        val boundary = runCatching { ZonedDateTime.parse(native.entryTimeJst).toEpochSecond() }.getOrNull() ?: return selected
        val chosen = selected.top1 ?: return selected
        if (chosen.instrument != top.instrument || chosen.direction != top.direction ||
            chosen.decision != "SKIP" || chosen.grade != "E") return selected
        val assessment = chosen.assessment ?: return selected
        val started = System.nanoTime()
        fun finish(result: ChartConditionalRankIndex.Result?, reason: String): ScanResult {
            val grade = result?.rank?.takeIf { it in setOf("E", "F", "G", "H") } ?: "UNRANKED"
            val metadata = ChartRankAssessment(
                grade = grade,
                rawProbability = result?.rawProbability?.let(::finite),
                calibratedProbability = result?.calibratedProbability?.let(::finite),
                supportN = result?.supportN ?: 0,
                referenceDates = result?.referenceDates ?: 0,
                effectiveSampleSize = result?.effectiveSampleSize?.let(::finite),
                statusReason = reason,
                snapshotId = "2026-10-01T00:00:00+09:00",
                modelVersion = ChartConditionalRankIndex.VERSION,
                queryBoundaryUtc = boundary,
                direction = chosen.direction,
                shrunkProbability = result?.shrunkProbability?.let(::finite)
            )
            // Label updates do not change rank/order, score, direction, ENTRY mask or expiry.
            val displayedGrade = if (grade == "UNRANKED") chosen.grade else grade
            val updated = chosen.copy(grade = displayedGrade, assessment = assessment.copy(
                operationalGrade = displayedGrade,
                chosenAction = assessment.chosenAction.copy(operationalGrade = displayedGrade),
                chartRank = metadata
            ))
            status = reason; lastGrade = grade; inferenceMs = (System.nanoTime() - started) / 1e6
            return selected.copy(candidates = selected.candidates.map { if (it.rank == chosen.rank) updated else it })
        }
        val minutes = runCatching {
            Duration.between(ZonedDateTime.parse(selected.entryTimeJst), ZonedDateTime.parse(selected.judgeTimeJst)).seconds
        }.getOrNull()
        if (!supports(boundary))
            return finish(null, "OUTSIDE_VALIDATED_RESEARCH_SCOPE")
        if (minutes != 180L) return finish(null, "UNSUPPORTED_JUDGE_HORIZON")
        if (chosen.instrument !in ChartConditionalRankIndex.SYMBOLS)
            return finish(null, "UNSUPPORTED_SAME_CURRENCY_BANK:" + chosen.instrument)
        if (clockMillis() >= boundary * 1000 - 800) return finish(null, "PUBLISH_DEADLINE")
        if (frame != null && (frame.boundary != boundary || frame.preparedMs > (boundary - 10) * 1000))
            return finish(null, unavailableReason)
        val actual = OctoberSimilarityScanAdapter.features(candles[chosen.instrument].orEmpty(), featureBoundary(boundary))
            ?: return finish(null, "MISSING_CONTIGUOUS_61_M1_BARS")
        if (frame != null && frame.features[chosen.instrument]?.contentEquals(actual) != true)
            return finish(null, "CHART_INPUT_REVISED")
        val result = if (frame != null) {
            frame.predictions[key(chosen.instrument, chosen.direction)]
                ?: return finish(null, frame.unavailable[key(chosen.instrument, chosen.direction)]
                    ?: frame.unavailable[chosen.instrument] ?: "SYMBOL_FRAME_NOT_READY")
        } else {
            val model = index ?: return finish(null, unavailableReason)
            // One currency/direction, no network or file reads. Leave 800ms for
            // the existing scan publication and never complete a partial query.
            val budgetMs = minOf(350L, boundary * 1000 - clockMillis() - 800L)
            if (budgetMs <= 0) return finish(null, "PUBLISH_DEADLINE")
            try {
                model.predict(boundary, ChartConditionalRankIndex.SYMBOLS.indexOf(chosen.instrument),
                    chosen.direction, actual, System.nanoTime() + budgetMs * 1_000_000L)
            } catch (_: ChartConditionalRankIndex.DeadlineExceededException) {
                return finish(null, "RETRIEVAL_DEADLINE")
            } catch (_: IllegalArgumentException) {
                return finish(null, "INVALID_CHART_INPUT")
            }
        }
        if (clockMillis() >= boundary * 1000 - 800) return finish(null, "PUBLISH_DEADLINE")
        if (result.queryBoundaryUtc != boundary || result.direction != chosen.direction ||
            result.snapshotUtc != ChartConditionalRankIndex.SNAPSHOT_UTC ||
            result.querySymbol != chosen.instrument ||
            result.queryChartFeaturesFloat32Sha256 != ChartConditionalRankIndex.chartFeatureHash(actual))
            return finish(null, "FRAME_IDENTITY_MISMATCH")
        val reason = if (result.rank != "UNRANKED" && (native.source == "MANUAL" || !originalResearchScope(boundary)))
            "OUTSIDE_ORIGINAL_RESEARCH_SCOPE:" + result.statusReason else result.statusReason
        return finish(result, reason)
    }
}

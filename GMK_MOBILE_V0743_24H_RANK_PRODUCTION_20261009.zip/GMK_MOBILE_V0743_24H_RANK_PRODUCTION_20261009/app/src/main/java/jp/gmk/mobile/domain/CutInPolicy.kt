package jp.gmk.mobile.domain

enum class CutInAdvantageSignal { WIN_ADVANTAGE, LOSE_ADVANTAGE }

/**
 * Pure policy used by the UI cut-in controller.
 * No Android/Compose dependency so the timing and direction rules can be regression-tested.
 */
object CutInPolicy {
    data class Suppression(val reason: String, val scanId: String, val instrument: String)

    /** Offers every eligible event, including while a previous image is being displayed. */
    fun observeEvents(queue: CutInEventQueue, history: List<HistoryRow>, rates: List<RateRow>,
                      nowMs: Long, enabled: Boolean): List<Suppression> {
        if (!enabled) return emptyList()
        fun epoch(value: String): Long? = runCatching {
            java.time.ZonedDateTime.parse(value).toInstant().toEpochMilli()
        }.getOrNull()
        val recent = history.take(256)
        recent.filter { it.decision == "ENTRY" && it.resultStatus in setOf("WIN", "LOSE") }
            .forEach { row ->
                val settled = epoch(row.settledAtJst)
                if (settled != null && row.entryRate?.let { it.isFinite() && it > 0.0 } == true &&
                    row.judgeRate?.let { it.isFinite() && it > 0.0 } == true) {
                    queue.offerFinal(row.scanId, row.instrument, row.resultStatus == "WIN", settled, nowMs)
                }
            }
        // Re-evaluate a queued advantage with the latest genuinely live rate. Stale/missing
        // quotes must not block another symbol or survive until a later display slot.
        queue.clearPendingAdvantages()
        val bySymbol = rates.associateBy { it.instrument }
        val suppressed = mutableListOf<Suppression>()
        recent.filter { it.decision == "ENTRY" && it.resultStatus == "WAIT_JUDGE" }
            .forEach { row ->
                val judge = epoch(row.judgeTimeJst) ?: return@forEach
                val oneMinute = row.source.contains("1M", ignoreCase = true)
                if (!isInAdvantageWindow(judge - nowMs, oneMinute)) return@forEach
                val quote = bySymbol[row.instrument]
                val age = quote?.sourceEpochMs?.let {
                    if (it in 1L..nowMs) (nowMs - it) / 1000.0 else Double.POSITIVE_INFINITY
                } ?: quote?.ageSeconds ?: Double.POSITIVE_INFINITY
                val freshnessLimit = if (row.instrument == "BTCJPY") 15.0 else 20.0
                if (quote?.freshnessStatus != "LIVE" || !age.isFinite() || age < 0.0 || age > freshnessLimit) {
                    suppressed += Suppression("NO_FRESH_LIVE_RATE", row.scanId, row.instrument)
                    return@forEach
                }
                val entry = row.entryRate
                val price = quote.price
                val signal = if (entry != null && price != null) advantageSignal(row.direction, entry, price) else null
                if (signal == null) {
                    suppressed += Suppression("INVALID_ADVANTAGE_PRICE", row.scanId, row.instrument)
                    return@forEach
                }
                queue.offerAdvantage(row.scanId, row.instrument, signal == CutInAdvantageSignal.WIN_ADVANTAGE,
                    oneMinute, judge, nowMs)
            }
        return suppressed
    }

    fun leadMs(isOneMinute: Boolean): Long = if (isOneMinute) 15_000L else 30_000L

    fun isInAdvantageWindow(remainingMs: Long, isOneMinute: Boolean): Boolean {
        val lead = leadMs(isOneMinute)
        return remainingMs in 1L..(lead + 1_500L)
    }

    fun advantageSignal(direction: String, entryPrice: Double, currentPrice: Double): CutInAdvantageSignal? {
        if (!entryPrice.isFinite() || !currentPrice.isFinite() || entryPrice <= 0.0 || currentPrice <= 0.0) return null
        val favorable = when (direction) {
            "HIGH" -> currentPrice > entryPrice
            "LOW" -> currentPrice < entryPrice
            else -> return null
        }
        // Directional draw/equality is LOSE by GMK result specification.
        return if (favorable) CutInAdvantageSignal.WIN_ADVANTAGE else CutInAdvantageSignal.LOSE_ADVANTAGE
    }
}

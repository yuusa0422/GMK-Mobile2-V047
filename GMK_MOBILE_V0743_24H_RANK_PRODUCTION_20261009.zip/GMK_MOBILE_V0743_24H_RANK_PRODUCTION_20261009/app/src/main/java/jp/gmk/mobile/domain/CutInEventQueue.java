package jp.gmk.mobile.domain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

/** UI-only event queue. It never calculates or changes a trade result. */
public final class CutInEventQueue {
    public enum Kind { WIN_ADVANTAGE, LOSE_ADVANTAGE, WIN_FINAL, LOSE_FINAL }
    public static final class Event {
        public final String key, scanId, instrument;
        public final Kind kind;
        public final boolean oneMinuteAdvantage;
        public final long targetEpochMs, observedAtMs;
        private Event(String scanId, String instrument, Kind kind, boolean oneMinute,
                      long targetEpochMs, long observedAtMs) {
            this.key = scanId + (isFinal(kind) ? ":FINAL" : ":ADVANTAGE");
            this.scanId = scanId; this.instrument = instrument; this.kind = kind;
            this.oneMinuteAdvantage = oneMinute;
            this.targetEpochMs = targetEpochMs; this.observedAtMs = observedAtMs;
        }
    }
    public static final class Tick {
        public final Event current, started;
        private Tick(Event current, Event started) { this.current = current; this.started = started; }
    }
    private final Map<String, Event> pending = new LinkedHashMap<>();
    private final Map<String, Long> shown = new LinkedHashMap<>();
    private Event active;
    private long expiresElapsedMs, expiredCount, maxDispatchDelayMs;

    public static boolean isFinal(Kind kind) { return kind == Kind.WIN_FINAL || kind == Kind.LOSE_FINAL; }

    public synchronized void offerFinal(String scanId, String instrument, boolean win,
                                        long settledEpochMs, long nowEpochMs) {
        if (scanId == null || scanId.isEmpty() || nowEpochMs < settledEpochMs || nowEpochMs - settledEpochMs > 20_000L) return;
        pending.remove(scanId + ":ADVANTAGE");
        offer(new Event(scanId, instrument, win ? Kind.WIN_FINAL : Kind.LOSE_FINAL, false,
                settledEpochMs, nowEpochMs));
    }
    public synchronized void offerAdvantage(String scanId, String instrument, boolean favorable,
                                            boolean oneMinute, long judgeEpochMs, long nowEpochMs) {
        if (scanId == null || scanId.isEmpty() || judgeEpochMs <= nowEpochMs) return;
        if (pending.containsKey(scanId + ":FINAL") || shown.containsKey(scanId + ":FINAL")) return;
        offer(new Event(scanId, instrument, favorable ? Kind.WIN_ADVANTAGE : Kind.LOSE_ADVANTAGE,
                oneMinute, judgeEpochMs, nowEpochMs));
    }
    private void offer(Event event) {
        if (shown.containsKey(event.key) || pending.containsKey(event.key)) return;
        if (pending.size() >= 64) {
            // Drop the oldest advantage before a confirmed result. A bounded queue avoids
            // replaying an arbitrary large startup history after a malformed import.
            String discard = pending.values().stream().filter(e -> !isFinal(e.kind))
                    .map(e -> e.key).findFirst().orElse(pending.keySet().iterator().next());
            pending.remove(discard); expiredCount++;
        }
        pending.put(event.key, event);
    }
    public synchronized Tick advance(long nowEpochMs, long elapsedMs) {
        shown.entrySet().removeIf(e -> nowEpochMs - e.getValue() > 2L * 60L * 60L * 1000L);
        ArrayList<String> expired = new ArrayList<>();
        for (Event event : pending.values()) {
            boolean tooOld = isFinal(event.kind) ? nowEpochMs - event.observedAtMs > 120_000L
                    : nowEpochMs >= event.targetEpochMs;
            if (tooOld) expired.add(event.key);
        }
        for (String key : expired) { pending.remove(key); expiredCount++; }
        if (active != null && elapsedMs >= expiresElapsedMs) active = null;
        if (active != null) return new Tick(active, null);
        Event next = pending.values().stream().min(Comparator
                .comparingInt((Event e) -> isFinal(e.kind) ? 0 : 1)
                .thenComparingLong(e -> e.targetEpochMs)
                .thenComparing(e -> e.key)).orElse(null);
        if (next == null) return new Tick(null, null);
        pending.remove(next.key);
        shown.put(next.key, nowEpochMs);
        active = next;
        expiresElapsedMs = elapsedMs + (isFinal(next.kind) ? 3_600L : 3_200L);
        maxDispatchDelayMs = Math.max(maxDispatchDelayMs, Math.max(0L, nowEpochMs - next.observedAtMs));
        return new Tick(next, next);
    }
    public synchronized void dismiss() { active = null; }
    public synchronized void clearPendingAdvantages() {
        pending.entrySet().removeIf(e -> !isFinal(e.getValue().kind));
    }
    public synchronized void clearVisibleAndPending() { active = null; pending.clear(); }
    public synchronized int pendingCount() { return pending.size(); }
    public synchronized String activeKey() { return active == null ? null : active.key; }
    public synchronized long expiredCount() { return expiredCount; }
    public synchronized long maxDispatchDelayMs() { return maxDispatchDelayMs; }
}

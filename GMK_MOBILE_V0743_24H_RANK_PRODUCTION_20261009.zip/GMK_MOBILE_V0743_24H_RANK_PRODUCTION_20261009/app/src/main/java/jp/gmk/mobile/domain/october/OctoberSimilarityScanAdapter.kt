package jp.gmk.mobile.domain.october

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import java.io.*
import java.time.*
import java.util.zip.CRC32

/** Observation journal contains complete actual M1 OPEN outcomes only. It is
 * optional and never fills days on which this device did not observe prices. */
data class OctoberSimilarityFrame(val boundary: Long, val probability: Array<Array<FloatArray>>,
    val eligible: BooleanArray, val ownPrices: Map<String,List<Candle>>, val preparedMs: Long,
    val snapshotEpoch: Long, val latestTrainingLabelEpoch: Long)

class OctoberSimilarityScanAdapter(private val index: OctoberSimilarityIndex, private val journalFile: File? = null, private val clockMillis: () -> Long = { System.currentTimeMillis() }) {
    companion object {
        private val JST=ZoneId.of("Asia/Tokyo")
        const val FALLBACK="GMK_V0740_OCTOBER_NATIVE_FALLBACK"
        fun supports(boundary: Long): Boolean {
            val t=Instant.ofEpochSecond(boundary).atZone(JST)
            return boundary>=OctoberSimilarityCatalog.AVAILABLE_FROM && boundary%300L==0L && t.monthValue==10 && t.dayOfWeek.value<=5 &&
                t.toLocalTime()>=LocalTime.of(9,0) && t.toLocalTime()<=LocalTime.of(17,0)
        }
        /** Exact observed minute geometry and timestamp continuity; never uses partial B-60. */
        fun featureRows(candles: List<Candle>,boundary: Long): List<Candle>? {
            val rows=candles.filter { it.timeEpochMs/1000 in (boundary-3720)..(boundary-120) }.sortedBy { it.timeEpochMs }
            if(rows.size!=61)return null
            for(i in rows.indices)if(rows[i].timeEpochMs!=(boundary-3720+i*60)*1000)return null
            return rows
        }
        fun features(candles: List<Candle>,boundary: Long): FloatArray? = runCatching {
            val rows=featureRows(candles,boundary) ?: return null
            OctoberTechnicalFeatures.compute(rows.map { doubleArrayOf(it.open,it.high,it.low,it.close) }.toTypedArray(),boundary)
        }.onFailure { if(it is OutOfMemoryError)throw it }.getOrNull()
    }
    @Volatile var status="WARMING";private set
    @Volatile var changed=false;private set
    @Volatile var inferenceMs=0.0;private set
    @Volatile var prepareMs=0.0;private set
    @Volatile var snapshotEpoch=0L;private set
    @Volatile var latestTrainingLabelEpoch=0L;private set
    val bundledLastBoundary get()=index.bundledLastBoundary
    val liveObservationCount get()=index.liveObservationCount()
    @Volatile var journalStatus="DISABLED";private set
    private var lastResult: ScanResult?=null;private var lastNative: ScanResult?=null
    private var lastFixedThree=false;private var pendingResult: ScanResult?=null
    private var committedResult: ScanResult?=null;private var committedNative: ScanResult?=null;private var committedFixedThree=false
    init { readJournal() }
    private fun readJournal() {
        val file=journalFile ?: return
        journalStatus="READY"
        if(!file.isFile)return
        runCatching {
            DataInputStream(BufferedInputStream(FileInputStream(file))).use { input ->
                var n=0
                while(input.available()>0) {
                    check(n++<100000) { "journal row limit" }
                    val payload=ByteArray(151);input.readFully(payload);val expected=input.readInt()
                    val crc=CRC32().apply { update(payload) };check(crc.value.toInt()==expected) { "journal CRC" }
                    DataInputStream(ByteArrayInputStream(payload)).use { row ->
                        val symbol=row.readUnsignedByte();val b=row.readLong();val y3=row.readUnsignedByte();val y5=row.readUnsignedByte()
                        val x=FloatArray(35) { row.readFloat() }
                        index.addObserved(symbol,OctoberSimilarityIndex.Record(b,x,y3,y5),clockMillis()/1000)
                    }
                }
            }
        }.onFailure {
            if(it is OutOfMemoryError)throw it
            // Previously valid prefix remains usable. Stop journal writing until the
            // corrupt file is quarantined; never append behind a corrupt prefix.
            journalStatus="READ_ERROR:${it.javaClass.simpleName}"
        }
    }
    private fun recordObserved(prices: Map<String,List<Candle>>,nowSeconds: Long) {
        val added=mutableListOf<Pair<Int,OctoberSimilarityIndex.Record>>()
        for((symbolIndex,symbol) in OctoberSimilarityIndex.TRADED.withIndex()) {
            val rows=prices[symbol].orEmpty();if(rows.size<67)continue
            val byTime=rows.groupBy { it.timeEpochMs/1000 }
            val latest=minOf(rows.maxOf { it.timeEpochMs/1000 },nowSeconds-60)
            var b=((latest-300)/300)*300
            val earliest=maxOf(rows.minOf { it.timeEpochMs/1000 }+3720,latest-7200)
            // At most 2h live context; all supplied dates/times observed, no price fill.
            while(b>=earliest && b>index.bundledLastBoundary) {
                val at=byTime[b]?.singleOrNull();val at3=byTime[b+180]?.singleOrNull();val at5=byTime[b+300]?.singleOrNull()
                if(at!=null&&at3!=null&&at5!=null&&at.open>0&&at3.open>0&&at5.open>0&&at.open.isFinite()&&at3.open.isFinite()&&at5.open.isFinite()) {
                    val x=features(rows,b)
                    if(x!=null) {
                        fun label(p: Double)=if(p>at.open)2 else if(p<at.open)0 else 1
                        val record=OctoberSimilarityIndex.Record(b,x,label(at3.open),label(at5.open))
                        if(index.addObserved(symbolIndex,record,nowSeconds))added += symbolIndex to record
                    }
                }
                b-=300
            }
        }
        if(added.isEmpty()||journalStatus.startsWith("READ_ERROR"))return
        val file=journalFile ?: return
        runCatching {
            file.parentFile?.mkdirs()
            DataOutputStream(BufferedOutputStream(FileOutputStream(file,true))).use { output ->
                for((symbol,r) in added) {
                    val bytes=ByteArrayOutputStream()
                    DataOutputStream(bytes).use { row -> row.writeByte(symbol);row.writeLong(r.boundary);row.writeByte(r.y3.toInt());row.writeByte(r.y5.toInt());r.x.forEach(row::writeFloat) }
                    val payload=bytes.toByteArray();check(payload.size==151)
                    output.write(payload);output.writeInt(CRC32().apply { update(payload) }.value.toInt())
                }
            }
            journalStatus="READY"
        }.onFailure {
            if(it is OutOfMemoryError)throw it
            journalStatus="WRITE_ERROR:${it.javaClass.simpleName}"
        }
    }
    @Synchronized fun prepare(prices: Map<String,List<Candle>>,boundary: Long,budgetMs: Long=1800): OctoberSimilarityFrame {
        require(supports(boundary))
        val began=System.nanoTime();val deadline=began+budgetMs*1_000_000
        recordObserved(prices,clockMillis()/1000)
        val own=mutableMapOf<String,List<Candle>>();val valid=BooleanArray(4)
        val x=Array(4) { s ->
            val symbol=OctoberSimilarityIndex.TRADED[s];val rows=featureRows(prices[symbol].orEmpty(),boundary)
            if(rows!=null)own[symbol]=rows
            val feature=features(prices[symbol].orEmpty(),boundary);valid[s]=feature!=null
            feature ?: FloatArray(35) { Float.NaN }
        }
        val probability=index.predict(x,valid,boundary,deadline)
        prepareMs=(System.nanoTime()-began)/1e6;snapshotEpoch=index.snapshotEpoch();latestTrainingLabelEpoch=index.latestSnapshotLabelEpoch()
        return OctoberSimilarityFrame(boundary,probability,valid,own,clockMillis(),snapshotEpoch,latestTrainingLabelEpoch)
    }
    @Synchronized fun apply(native: ScanResult,candles: Map<String,List<Candle>>,frame: OctoberSimilarityFrame?,
        quotes: Map<String,HorizonQuote>,fixedThreeMinute: Boolean=false,nowMs: Long=clockMillis()): ScanResult {
        val entry=runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return native
        val b=entry.toEpochSecond();if(native.source!="AUTO"||!supports(b))return native
        val began=System.nanoTime();changed=false
        fun finish(result: ScanResult,reason: String,evaluated: Boolean=false): ScanResult {
            check(result.scanId==native.scanId&&result.entryTimeJst==native.entryTimeJst&&result.source==native.source)
            check((result.top1?.decision=="ENTRY")== (native.top1?.decision=="ENTRY"))
            status=reason;inferenceMs=(System.nanoTime()-began)/1e6
            val tag=if(evaluated)OctoberSimilarityIndex.VERSION else FALLBACK
            val done=result.copy(policyVersion=tag+if(fixedThreeMinute)"_3M_FIXED" else "")
            pendingResult=done;lastResult=done;lastNative=native;lastFixedThree=fixedThreeMinute;return done
        }
        if(lastResult?.scanId==native.scanId&&lastResult?.entryTimeJst==native.entryTimeJst&&lastNative==native&&lastFixedThree==fixedThreeMinute)return requireNotNull(lastResult)
        if(nowMs>=b*1000-800)return finish(native,"PUBLISH_DEADLINE")
        val top=native.top1 ?: return finish(native,"NO_SIGNAL",true)
        if(top.decision!="ENTRY")return finish(native,"NATIVE_SKIP",true)
        if(top.grade in setOf("S","A","B"))return finish(native,"NATIVE_S_A_B_PROTECTED",true)
        val own=OctoberSimilarityIndex.TRADED.indexOf(top.instrument)
        if(top.grade!="C"||own<0||top.direction !in setOf("HIGH","LOW"))return finish(native,"OUTSIDE_COMMON_FOUR",true)
        if(frame==null||frame.boundary!=b||frame.preparedMs>(b-10)*1000||frame.snapshotEpoch!=OctoberSimilarityIndex.dailyCutoff(b)||frame.latestTrainingLabelEpoch>=frame.snapshotEpoch)return finish(native,"FRAME_NOT_READY")
        for(symbol in OctoberSimilarityIndex.TRADED) {
            val rows=featureRows(candles[symbol].orEmpty(),b)
            if(rows!=frame.ownPrices[symbol])return finish(native,"INPUT_REVISION:$symbol")
        }
        val safe=BooleanArray(4) { s -> frame.eligible[s]&&native.candidates.count { it.instrument==OctoberSimilarityIndex.TRADED[s] }==1&&HorizonFeatureService.nativeQuoteSafe(OctoberSimilarityIndex.TRADED[s],quotes[OctoberSimilarityIndex.TRADED[s]],b,frame.ownPrices[OctoberSimilarityIndex.TRADED[s]]?.lastOrNull()?.close ?: Double.NaN) }
        if(!safe[own])return finish(native,"QUOTE_NOT_SAFE")
        return try {
            val action=4*own+if(top.direction=="HIGH")1 else 0
            val selected=OctoberSimilarityIndex.decide(action,true,top.grade,safe,frame.probability,fixedThreeMinute)
            if(selected==action)return finish(native,"UNCHANGED",true)
            val target=OctoberSimilarityIndex.TRADED[selected/4];val minutes=if(selected%4/2==0)3 else 5
            val nativeTarget=native.candidates.single { it.instrument==target }
            val chosenDirection=if(selected%2==1)"HIGH" else "LOW"
            val candidate=nativeTarget.copy(rank=1,direction=chosenDirection,grade="C",decision="ENTRY",probability=null,
                reasons=listOf("判定: ${minutes}分","同通貨・曜日・時間帯の類似100件でC補正"),
                assessment=CandidateAssessmentFactory.similarityCorrection(nativeTarget,top,chosenDirection,minutes))
            val candidates=listOf(candidate)+native.candidates.filter { it.instrument!=target }.mapIndexed { i,c -> c.copy(rank=i+2) }
            if(nowMs+(System.nanoTime()-began)/1_000_000>=b*1000-800)return finish(native,"PUBLISH_DEADLINE")
            changed=true;finish(native.copy(candidates=candidates,judgeTimeJst=entry.plusMinutes(minutes.toLong()).toString()),"APPLIED",true)
        } catch(e: Exception) { changed=false;finish(native,"NATIVE_FALLBACK:${e.javaClass.simpleName}") }
    }
    @Synchronized fun commit(scanId: String) {if(pendingResult?.scanId==scanId){committedResult=pendingResult;committedNative=lastNative;committedFixedThree=lastFixedThree;pendingResult=null}}
    @Synchronized fun discardPending() {pendingResult=null;lastResult=committedResult;lastNative=committedNative;lastFixedThree=committedFixedThree}
}

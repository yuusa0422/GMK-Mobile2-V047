package jp.gmk.mobile.domain.october;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

/** Exact float32 technical35 from build_year_data.features_one. 61 observed M1 bars,
 * oldest to newest, ending at OPEN(B-120); never includes HLC of OPEN(B-60). */
public final class OctoberTechnicalFeatures {
    public static final int COUNT=35;
    private static final ZoneId JST=ZoneId.of("Asia/Tokyo");
    private static double div(double a,double b,double fallback) {
        return Double.isFinite(b)&&Math.abs(b)>1e-15?a/b:fallback;
    }
    public static float[] compute(double[][] bars,long boundary) {
        if(bars==null||bars.length!=61)throw new IllegalArgumentException("61 consecutive bars required");
        double[] o=new double[61],h=new double[61],l=new double[61],c=new double[61],log=new double[61],r=new double[60],tr=new double[60];
        for(int i=0;i<61;i++) {
            if(bars[i]==null||bars[i].length!=4)throw new IllegalArgumentException("OHLC");
            o[i]=bars[i][0];h[i]=bars[i][1];l[i]=bars[i][2];c[i]=bars[i][3];
            if(!Double.isFinite(o[i])||!Double.isFinite(h[i])||!Double.isFinite(l[i])||!Double.isFinite(c[i])||Math.min(Math.min(o[i],h[i]),Math.min(l[i],c[i]))<=0||h[i]<Math.max(o[i],c[i])||l[i]>Math.min(o[i],c[i])||h[i]<l[i])throw new IllegalArgumentException("Invalid OHLC");
            log[i]=Math.log(c[i]);
            if(i>0){r[i-1]=log[i]-log[i-1];tr[i-1]=Math.max(h[i]-l[i],Math.max(Math.abs(h[i]-c[i-1]),Math.abs(l[i]-c[i-1])));}
        }
        float[] x=new float[35];int at=0;
        int[] ks={5,15,30,60};double[] rv=new double[4];
        for(int t=0;t<4;t++){double sum=0;for(int i=60-ks[t];i<60;i++)sum+=r[i]*r[i];rv[t]=Math.sqrt(sum/ks[t]);}
        double norm=Math.max(rv[3],1e-8);
        for(int k:new int[]{1,3,5,10,15,30,60})x[at++]=(float)((log[60]-log[60-k])/(norm*Math.sqrt(k)));
        for(double v:rv)x[at++]=(float)(v*10000);
        for(int i=0;i<3;i++)x[at++]=(float)div(rv[i],rv[3],1);
        double atr14=0,atr60=0;for(int i=0;i<60;i++){atr60+=tr[i];if(i>=46)atr14+=tr[i];}atr14/=14;atr60/=60;
        x[at++]=(float)(div(atr14,c[60],0)*10000);x[at++]=(float)(div(atr60,c[60],0)*10000);x[at++]=(float)div(atr14,atr60,1);
        for(int k:new int[]{15,30,60}){double signed=0,abs=0;for(int i=61-k;i<61;i++){double d=c[i]-c[i-1];signed+=d;abs+=Math.abs(d);}x[at++]=(float)div(Math.abs(signed),abs,0);}
        int pairs=0,flips=0;for(int i=31;i<60;i++){double a=Math.signum(r[i-1]),b=Math.signum(r[i]);if(a!=0&&b!=0){pairs++;if(a!=b)flips++;}}x[at++]=(float)div(flips,pairs,0);
        double ma=0,mb=0;for(int i=30;i<59;i++){ma+=r[i];mb+=r[i+1];}ma/=29;mb/=29;
        double aa=0,bb=0,ab=0;for(int i=30;i<59;i++){double a=r[i]-ma,b=r[i+1]-mb;aa+=a*a;bb+=b*b;ab+=a*b;}x[at++]=(float)div(ab,Math.sqrt(aa*bb),0);
        double body=c[60]-o[60],upper=h[60]-Math.max(o[60],c[60]),lower=Math.min(o[60],c[60])-l[60],span=h[60]-l[60];
        for(double v:new double[]{body,upper,lower,span})x[at++]=(float)div(v,atr14,0);x[at++]=(float)div(upper+lower,span,0);
        for(int k:new int[]{30,60}){double hi=-Double.MAX_VALUE,lo=Double.MAX_VALUE;for(int i=61-k;i<61;i++){hi=Math.max(hi,h[i]);lo=Math.min(lo,l[i]);}x[at++]=(float)(2*div(c[60]-lo,hi-lo,.5)-1);}
        double sign=Math.signum(r[59]);int run=0;for(int i=59;i>=0&&Math.signum(r[i])==sign;i--)run++;x[at++]=(float)(run*sign);
        ZonedDateTime t=Instant.ofEpochSecond(boundary).atZone(JST);double hour=t.getHour()+t.getMinute()/60.;
        x[at++]=t.getMinute();x[at++]=t.getHour();x[at++]=(float)Math.sin(2*Math.PI*hour/24);x[at++]=(float)Math.cos(2*Math.PI*hour/24);x[at++]=t.getDayOfWeek().getValue()-1;
        if(at!=35)throw new AssertionError("feature count");for(float v:x)if(!Float.isFinite(v))throw new IllegalArgumentException("Nonfinite feature");return x;
    }
    private OctoberTechnicalFeatures(){}
}

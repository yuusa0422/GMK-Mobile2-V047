package jp.gmk.mobile.domain.direct19

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import java.time.*

data class Direct19Input(val boundary: Long,val features: Array<FloatArray>,val eligible: BooleanArray,
    val ownPrices: Map<String,List<Candle>>)
data class Direct19Frame(val input: Direct19Input,val probability: Array<Array<FloatArray>>,val preparedMs: Long)

/** Frozen latest portable model. No fitting, network requests or ENTRY changes. */
class Direct19ScanAdapter(private val model3: Direct19Model,private val model5: Direct19Model) {
    companion object {
        private val JST=ZoneId.of("Asia/Tokyo")
        const val FALLBACK="GMK_V0736_DIRECT19_FALLBACK"
        fun supports(boundary: Long): Boolean {
            val t=Instant.ofEpochSecond(boundary).atZone(JST)
            return boundary%300L==0L && t.dayOfWeek.value<=5 && t.toLocalTime()>=LocalTime.of(9,0) && t.toLocalTime()<=LocalTime.of(17,0)
        }
    }
    @Volatile var status="WARMING";private set
    @Volatile var changed=false;private set
    @Volatile var inferenceMs=0.0;private set
    @Volatile var prepareMs=0.0;private set
    private var lastScanId="";private var lastResult: ScanResult?=null
    private var lastNative: ScanResult?=null
    private var lastFixedThree=false
    private var pendingResult: ScanResult?=null
    private var committedResult: ScanResult?=null
    private var committedNative: ScanResult?=null
    private var committedFixedThree=false
    fun prepare(prices: Map<String,List<Candle>>,boundary: Long,budgetMs: Long=1800): Direct19Frame {
        val began=System.nanoTime();val deadline=began+budgetMs*1_000_000
        val input=HorizonFeatureService(prices,emptyMap(),boundary,LocalRuleEngine(),deadline).direct19Input()
        val probability=Array(4) { s->Array(2) { h->if(input.eligible[s])(if(h==0)model3 else model5).predict(input.features[s],deadline) else FloatArray(3) { Float.NaN } } }
        prepareMs=(System.nanoTime()-began)/1e6
        return Direct19Frame(input,probability,System.currentTimeMillis())
    }
    @Synchronized fun apply(native: ScanResult,candles: Map<String,List<Candle>>,frame: Direct19Frame?,
        quotes: Map<String,HorizonQuote>,fixedThreeMinute: Boolean=false,nowMs: Long=System.currentTimeMillis()): ScanResult {
        val entry=runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return native
        val b=entry.toEpochSecond();if(native.source!="AUTO" || !supports(b))return native
        val began=System.nanoTime();changed=false
        fun finish(result: ScanResult,reason: String,evaluated: Boolean=false): ScanResult {
            check(result.scanId==native.scanId && result.entryTimeJst==native.entryTimeJst && result.source==native.source)
            check((result.top1?.decision=="ENTRY")== (native.top1?.decision=="ENTRY"))
            status=reason;inferenceMs=(System.nanoTime()-began)/1e6
            val tag=if(evaluated)Direct19Policy.VERSION else FALLBACK
            val done=result.copy(policyVersion=tag+if(fixedThreeMinute)"_3M_FIXED" else "")
            pendingResult=done;lastScanId=native.scanId;lastResult=done;lastNative=native;lastFixedThree=fixedThreeMinute;return done
        }
        if(lastScanId==native.scanId && lastResult?.entryTimeJst==native.entryTimeJst && lastNative==native && lastFixedThree==fixedThreeMinute)return requireNotNull(lastResult)
        if(b-10<Direct19Catalog.AVAILABLE_FROM)return finish(native,"MODEL_NOT_AVAILABLE")
        if(nowMs>=b*1000-800)return finish(native,"PUBLISH_DEADLINE")
        val top=native.top1 ?: return finish(native,"NO_SIGNAL",true)
        if(top.decision!="ENTRY")return finish(native,"NATIVE_SKIP",true)
        if(top.grade in setOf("S","A","B"))return finish(native,"NATIVE_S_A_B_PROTECTED",true)
        val nativeSymbol=Direct19Policy.TRADED.indexOf(top.instrument)
        if(top.grade!="C" || nativeSymbol<0)return finish(native,"OUTSIDE_COMMON_FOUR",true)
        if(frame==null || frame.input.boundary!=b || frame.preparedMs>(b-10)*1000)return finish(native,"FRAME_NOT_READY")
        for(symbol in Direct19Policy.TRADED) {
            val rows=candles[symbol].orEmpty().filter { it.timeEpochMs/1000<=b-120 }.takeLast(120)
            if(rows!=frame.input.ownPrices[symbol])return finish(native,"INPUT_REVISION:$symbol")
        }
        val safe=BooleanArray(4) { s->frame.input.eligible[s] && HorizonFeatureService.nativeQuoteSafe(Direct19Policy.TRADED[s],quotes[Direct19Policy.TRADED[s]],b,frame.input.ownPrices[Direct19Policy.TRADED[s]]?.lastOrNull()?.close ?: Double.NaN) }
        if(!safe[nativeSymbol])return finish(native,"QUOTE_NOT_SAFE")
        return try {
            val action=4*nativeSymbol+if(top.direction=="HIGH")1 else 0
            val selected=Direct19Policy.decide(action,true,top.grade,safe,frame.probability,fixedThreeMinute)
            if(selected==action)return finish(native,"UNCHANGED",true)
            val target=Direct19Policy.TRADED[selected/4];val minutes=if(selected%4/2==0)3 else 5
            val nativeTarget=native.candidates.single { it.instrument==target }
            val chosenDirection=if(selected%2==1)"HIGH" else "LOW"
            val candidate=nativeTarget.copy(rank=1,
                direction=chosenDirection,grade="C",decision="ENTRY",probability=null,
                reasons=listOf("判定: ${minutes}分","C判定のAI補正"),
                assessment=CandidateAssessmentFactory.correction(nativeTarget,top,chosenDirection,"C","ENTRY",minutes,"C判定のAI補正"))
            val candidates=listOf(candidate)+native.candidates.filter { it.instrument!=target }.mapIndexed { i,c->c.copy(rank=i+2) }
            if(nowMs+(System.nanoTime()-began)/1_000_000>=b*1000-800)return finish(native,"PUBLISH_DEADLINE")
            changed=true
            finish(native.copy(candidates=candidates,judgeTimeJst=entry.plusMinutes(minutes.toLong()).toString()),"APPLIED",true)
        } catch(e: Exception) { changed=false;finish(native,"NATIVE_FALLBACK:${e.javaClass.simpleName}") }
    }
    @Synchronized fun commit(scanId: String) {if(pendingResult?.scanId==scanId){committedResult=pendingResult;committedNative=lastNative;committedFixedThree=lastFixedThree;pendingResult=null}}
    @Synchronized fun discardPending() {pendingResult=null;lastResult=committedResult;lastNative=committedNative;lastFixedThree=committedFixedThree;lastScanId=committedResult?.scanId.orEmpty()}
}

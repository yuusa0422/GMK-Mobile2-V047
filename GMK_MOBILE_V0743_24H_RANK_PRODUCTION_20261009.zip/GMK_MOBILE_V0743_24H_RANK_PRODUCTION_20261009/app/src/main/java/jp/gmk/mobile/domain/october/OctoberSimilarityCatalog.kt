package jp.gmk.mobile.domain.october

import android.content.res.AssetManager
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.SequenceInputStream
import java.util.Enumeration

object OctoberSimilarityCatalog {
    const val AVAILABLE_FROM = 1791471600L
    const val RAW_SHA256 = "abca58abae1364b54adde3d0044e3d114606d94e80fcacfedfdc3f93039e32ee"
    const val BUNDLED_LAST_BOUNDARY = 1791273600L
    /** Open one compressed part at a time. Closing after an error must not open
     * untouched future parts: SequenceInputStream.close otherwise drains its enum. */
    private fun load(open: (String) -> InputStream): OctoberSimilarityIndex {
        val parts=(1..4).iterator()
        var stopped=false
        val streams=object : Enumeration<InputStream> {
            override fun hasMoreElements()=!stopped && parts.hasNext()
            override fun nextElement(): InputStream {
                val path="october_similarity/index.bin.gz.part" + parts.next().toString().padStart(2,'0')
                return open(path)
            }
        }
        return SequenceInputStream(streams).use {
            try { OctoberSimilarityIndex.readCompressed(it,RAW_SHA256) }
            finally { stopped=true }
        }
    }
    fun loadIndex(assets: AssetManager): OctoberSimilarityIndex = load { assets.open(it) }
    fun loadIndex(assetBytes: (String) -> ByteArray): OctoberSimilarityIndex = load { ByteArrayInputStream(assetBytes(it)) }
}

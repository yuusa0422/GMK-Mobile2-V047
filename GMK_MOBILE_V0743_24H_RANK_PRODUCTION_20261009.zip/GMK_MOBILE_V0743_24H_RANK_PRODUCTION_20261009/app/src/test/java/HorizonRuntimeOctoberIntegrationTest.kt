import android.app.Application
import android.content.Context
import jp.gmk.mobile.data.*
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.october.*
import kotlinx.coroutines.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.Duration
import java.time.ZonedDateTime
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.atomic.AtomicBoolean

/** Real asset load and background preparation on actual observed fixture prices,
 * moved to the first production Friday. Controlled probabilities below exercise
 * commit/history/expiry transport; they are not a claim about future win rate. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
@LooperMode(LooperMode.Mode.PAUSED)
class HorizonRuntimeOctoberIntegrationTest {
    private lateinit var app: Application
    private val owners = mutableListOf<Pair<HorizonRuntime, Job>>()
    @Before fun setup() {
        app = RuntimeEnvironment.getApplication()
        listOf("gmk_horizon_policy", "gmk_mobile_history", "gmk_mobile_history_journal")
            .forEach { app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit() }
        File(app.filesDir, "horizon_history_v1").deleteRecursively()
        File(app.filesDir, "pc_r13_frames_v1.bin").delete()
        File(app.filesDir, "october_observed_m1.bin").delete()
    }
    @After fun cleanup() {
        owners.forEach { (runtime, owner) -> runtime.stop(); owner.cancel(); runBlocking { owner.join() } }
    }
    private data class Running(val runtime: HorizonRuntime, val clock: AtomicLong,
                               val repository: MarketRepository)
    private fun observed(): RuleAiObservedFixture.Observed {
        val original = RuleAiObservedFixture.at(0, 1)
        val target = ZonedDateTime.parse("2026-10-09T14:00:00+09:00").toEpochSecond()
        val shift = (target - original.boundary) * 1000
        return RuleAiObservedFixture.Observed(target, original.prices.mapValues { (_, bars) ->
            bars.map { it.copy(timeEpochMs = it.timeEpochMs + shift) }
        })
    }
    private fun start(observed: RuleAiObservedFixture.Observed, fault: String? = null,
                      enabled: Boolean = true, optionalAllocationFailure: Boolean = false,
                      enabledGate: (() -> Boolean)? = null): Running {
        val at = (observed.boundary - 20) * 1000
        val cache = HorizonMarketCache(File(app.filesDir, "horizon_history_v1"))
        observed.prices.forEach { (symbol, bars) -> cache.merge(symbol, bars, at); cache.persist(symbol) }
        val clock = AtomicLong(at)
        val repository = MarketRepository(AppPrefs(app))
        val runtime = HorizonRuntime(app, repository, { path ->
            if (optionalAllocationFailure && path.startsWith("october_similarity/"))
                throw OutOfMemoryError("controlled optional October model allocation failure")
            app.assets.open(path).use { it.readBytes() }.also { bytes ->
                if (path == fault) bytes[20] = (bytes[20].toInt() xor 1).toByte()
            }
        }, clock::get)
        val owner = SupervisorJob(); owners += runtime to owner
        runtime.start(CoroutineScope(owner + Dispatchers.Default), { enabledGate?.invoke() ?: enabled }, { false })
        return Running(runtime, clock, repository)
    }
    private fun waitFor(message: String, diagnostic: () -> String = { "" }, condition: () -> Boolean) {
        val end = System.nanoTime() + 45_000_000_000L
        while (!condition() && System.nanoTime() < end) Thread.sleep(10)
        assertTrue("$message ${diagnostic()}", condition())
    }
    @Suppress("UNCHECKED_CAST")
    private fun frames(runtime: HorizonRuntime): AtomicReference<OctoberSimilarityFrame?> =
        HorizonRuntime::class.java.getDeclaredField("preparedOctober").apply { isAccessible = true }
            .get(runtime) as AtomicReference<OctoberSimilarityFrame?>
    private fun ready(run: Running): OctoberSimilarityFrame {
        waitFor("Real October background frame was not prepared", { run.runtime.diagnosticStats().toString() }) {
            frames(run.runtime).get() != null
        }
        return requireNotNull(frames(run.runtime).get())
    }
    private fun capture(run: Running, observed: RuleAiObservedFixture.Observed) {
        run.runtime.observe(RuleAiObservedFixture.quotes(observed).map { (symbol, q) ->
            RateRow(symbol, q.price, q.bid, q.ask, "controlled observed-price quote", 2.0, "LIVE",
                sourceEpochMs = q.sourceMs, receivedEpochMs = q.receivedMs)
        })
        run.clock.set((observed.boundary - 5) * 1000)
    }
    private fun controlledCorrection(frame: OctoberSimilarityFrame): OctoberSimilarityFrame {
        val probability = Array(4) { Array(2) { floatArrayOf(.34f, .33f, .33f) } }
        probability[3][1] = floatArrayOf(.10f, .05f, .85f)
        return frame.copy(probability = probability)
    }

    @Test fun actualOctoberAssetBackgroundInputsAndDailyLabelCutoffAreReady() {
        val observed = observed(); val run = start(observed); val frame = ready(run)
        val diagnostic = run.runtime.diagnosticStats().getJSONObject("october_similarity")
        assertEquals("LOADED", diagnostic.getString("load_status"))
        assertEquals(observed.boundary, frame.boundary)
        assertTrue(frame.eligible.all { it })
        assertTrue(frame.preparedMs < (observed.boundary - 10) * 1000)
        assertEquals(OctoberSimilarityIndex.dailyCutoff(observed.boundary), frame.snapshotEpoch)
        assertTrue(frame.latestTrainingLabelEpoch < frame.snapshotEpoch)
        assertTrue(frame.ownPrices.values.all { rows -> rows.size == 61 && rows.last().timeEpochMs / 1000 == observed.boundary - 120 })
        assertTrue(frame.probability.flatMap { it.toList() }.all { p ->
            p.all { it.isFinite() && it in 0f..1f } && kotlin.math.abs(p.sum() - 1f) < 3e-5
        })
        assertEquals("Preparation must not issue network requests during the reserved slot", 0L,
            run.repository.diagnosticStats().getLong("requests"))
    }

    @Test fun runtimeCorrectionFiveMinuteSettlementAndCommittedRetryPreserveIdentity() {
        val observed = observed(); val (native, candles) = RuleAiObservedFixture.native(observed)
        assertEquals("C", native.top1!!.grade); assertEquals("ENTRY", native.top1!!.decision)
        val run = start(observed); frames(run.runtime).set(controlledCorrection(ready(run))); capture(run, observed)
        val result = run.runtime.apply(native, candles)
        assertEquals("APPLIED", run.runtime.diagnosticStats().getJSONObject("october_similarity").getString("status"))
        assertEquals("AUDJPY", result.top1!!.instrument); assertEquals("HIGH", result.top1!!.direction)
        assertEquals(5L, Duration.between(ZonedDateTime.parse(result.entryTimeJst), ZonedDateTime.parse(result.judgeTimeJst)).toMinutes())
        assertEquals(native.scanId, result.scanId); assertEquals(native.entryTimeJst, result.entryTimeJst)
        assertEquals(native.source, result.source); assertEquals(native.top1!!.decision, result.top1!!.decision)
        val store = HistoryStore(app); store.add(result); run.runtime.commit(result.scanId); run.runtime.discardPending()
        assertEquals(result, run.runtime.apply(native, candles))
        store.updateEntryRate(result.scanId, 150.0, "fixture exact open", result.entryTimeJst, 0, 0.0)
        store.settle(result.scanId, 151.0, "fixture exact open", result.judgeTimeJst, 0, 0.0)
        val saved = store.load().single()
        assertEquals("WIN", saved.resultStatus); assertEquals(result.policyVersion, saved.policyVersion)
        assertEquals(result.judgeTimeJst, saved.judgeTimeJst)
        assertTrue("New October rows must be counted by the current expiry-profile view", ExpiryProfiles.includes(saved, false, false))
        assertFalse(ExpiryProfiles.includes(saved, true, false))
        assertEquals(1, historyStatistics(listOf(saved)).getValue(5).wins)
        val revised = native.copy(scanId = "another-scan-at-same-boundary")
        val retried = run.runtime.apply(revised, candles)
        assertEquals(revised.scanId, retried.scanId)
        assertEquals(revised.candidates, retried.candidates)
        assertEquals("FRAME_NOT_READY", run.runtime.diagnosticStats().getJSONObject("october_similarity").getString("status"))
    }

    @Test fun skipSabManualAndOneMinuteStayOnTheirNativeDecisions() {
        val observed = observed(); val (native, candles) = RuleAiObservedFixture.native(observed)
        val run = start(observed, enabled = false)
        waitFor("Disabled startup did not complete") { run.runtime.diagnosticStats().getString("background") == "INACTIVE" }
        capture(run, observed)
        for (grade in listOf("S", "A", "B", "E")) {
            val decision = if (grade == "E") "SKIP" else "ENTRY"
            val guarded = native.copy(scanId = "guard-$grade", candidates = native.candidates.map {
                if (it.rank == 1) it.copy(grade = grade, decision = decision, assessment = it.assessment?.let { assessment ->
                    // Align the simulated operational action while retaining the immutable native trace.
                    assessment.copy(operationalGrade = grade, decision = decision,
                        chosenAction = assessment.chosenAction.copy(operationalGrade = grade, decision = decision))
                }) else it
            })
            val result = run.runtime.apply(guarded, candles)
            result.candidates.forEach { candidate ->
                if (candidate.rank == 1 && grade == "E") {
                    val chart = requireNotNull(candidate.assessment?.chartRank)
                    assertEquals(observed.boundary, chart.queryBoundaryUtc)
                    assertEquals(guarded.top1!!.direction, chart.direction)
                    assertEquals(200, chart.supportN)
                    assertTrue(chart.grade in setOf("E", "F", "G", "H", "UNRANKED"))
                } else assertNull(candidate.assessment?.chartRank)
            }
            // Only display-grade and optional chart fields are authorized to change.
            // Restore exactly those fields; full equality checks every action and original trace.
            val withoutChart = result.copy(candidates = result.candidates.map { candidate ->
                val original = guarded.candidates.single { it.rank == candidate.rank }
                candidate.copy(grade = original.grade, assessment = candidate.assessment?.let { a ->
                    a.copy(operationalGrade = original.assessment!!.operationalGrade,
                        chosenAction = a.chosenAction.copy(operationalGrade = original.assessment.chosenAction.operationalGrade),
                        chartRank = null)
                })
            })
            assertEquals(guarded.copy(policyVersion = OctoberSimilarityIndex.VERSION), withoutChart)
        }
        for (source in listOf("MANUAL", "AUTO_1M")) {
            val unchanged = native.copy(source = source)
            assertEquals(unchanged, run.runtime.apply(unchanged, candles, true))
        }
    }

    @Test fun actualCorruptOctoberChunkFallsBackWithoutDisablingOriginalModels() {
        val observed = observed(); val (native, candles) = RuleAiObservedFixture.native(observed)
        val run = start(observed, "october_similarity/index.bin.gz.part01", enabled = false)
        waitFor("Corrupt index startup did not complete") { run.runtime.diagnosticStats().getString("background") == "INACTIVE" }
        val diagnostic = run.runtime.diagnosticStats()
        assertTrue(diagnostic.getJSONObject("october_similarity").getString("load_status").startsWith("MODEL_UNAVAILABLE:"))
        assertEquals("LOADED", diagnostic.getJSONObject("direct19").getString("load_status"))
        assertEquals("LOADED", diagnostic.getJSONObject("pc_r13").getString("load_status"))
        capture(run, observed)
        val result = run.runtime.apply(native, candles)
        assertEquals(native.candidates, result.candidates); assertEquals(native.judgeTimeJst, result.judgeTimeJst)
        assertEquals(native.top1!!.decision, result.top1!!.decision)
        assertEquals(OctoberSimilarityScanAdapter.FALLBACK, result.policyVersion)
    }

    @Test fun optionalOctoberAllocationFailureKeepsOriginalModelsRuntimeAndNativeEntryWorking() {
        val observed = observed(); val (native, candles) = RuleAiObservedFixture.native(observed)
        val run = start(observed, enabled = false, optionalAllocationFailure = true)
        waitFor("Optional allocation fault did not finish startup", { run.runtime.diagnosticStats().toString() }) {
            run.runtime.diagnosticStats().getString("background") == "INACTIVE"
        }
        fun verifyRecovery(running: Running, phase: String) {
            val diagnostic = running.runtime.diagnosticStats()
            assertTrue(diagnostic.getJSONObject("october_similarity").getString("load_status").contains("OutOfMemoryError"))
            assertEquals("LOADED", diagnostic.getJSONObject("direct19").getString("load_status"))
            assertEquals("LOADED", diagnostic.getJSONObject("pc_r13").getString("load_status"))
            assertEquals("LOADED", diagnostic.getString("legacy_model_load_status"))
            assertEquals(0, diagnostic.getJSONObject("october_similarity").getInt("ready_symbols"))
            assertNull(frames(running.runtime).get())
            assertTrue("Optional $phase failure must leave the original background owner active",
                owners.single { it.first === running.runtime }.second.isActive)
            capture(running, observed)
            for (grade in listOf("C", "S", "A", "B")) {
                val guarded = native.copy(scanId = "allocation-fault-$phase-$grade", candidates = native.candidates.map {
                    if (it.rank == 1) it.copy(grade = grade, decision = "ENTRY") else it
                })
                val result = running.runtime.apply(guarded, candles)
                assertEquals(guarded.candidates, result.candidates)
                assertEquals(guarded.judgeTimeJst, result.judgeTimeJst)
                assertEquals(guarded.scanId, result.scanId)
                assertEquals("ENTRY", result.top1!!.decision)
                assertEquals(OctoberSimilarityScanAdapter.FALLBACK, result.policyVersion)
                running.runtime.discardPending()
            }
        }
        verifyRecovery(run, "startup")

        // Use the real index snapshot path. Only its iteration fault is injected;
        // no copied model, modified production body or actual huge allocation.
        val enabled = AtomicBoolean(false)
        val preparing = start(observed, enabledGate = enabled::get)
        waitFor("Disabled preparation startup did not complete") {
            preparing.runtime.diagnosticStats().getString("background") == "INACTIVE"
        }
        val adapter = HorizonRuntime::class.java.getDeclaredField("october").apply { isAccessible = true }
            .get(preparing.runtime) as OctoberSimilarityScanAdapter
        val index = OctoberSimilarityScanAdapter::class.java.getDeclaredField("index").apply { isAccessible = true }
            .get(adapter) as OctoberSimilarityIndex
        @Suppress("UNCHECKED_CAST")
        val records = OctoberSimilarityIndex::class.java.getDeclaredField("records").apply { isAccessible = true }
            .get(index) as Array<MutableList<OctoberSimilarityIndex.Record>>
        records[0] = object : java.util.ArrayList<OctoberSimilarityIndex.Record>() {
            override fun iterator(): MutableIterator<OctoberSimilarityIndex.Record> =
                throw OutOfMemoryError("controlled optional October snapshot allocation failure")
        }
        val background = HorizonRuntime::class.java.getDeclaredField("backgroundStatus").apply { isAccessible = true }
        enabled.set(true)
        waitFor("Optional snapshot OOM did not recover", { background.get(preparing.runtime).toString() }) {
            background.get(preparing.runtime) == "OCTOBER_RESOURCE_LIMIT_NATIVE_CONTINUES"
        }
        verifyRecovery(preparing, "preparation")

        // Exercise the separate publication boundary with the real ready frame.
        val publishing = start(observed)
        frames(publishing.runtime).set(controlledCorrection(ready(publishing)))
        capture(publishing, observed)
        val failingCandles = object : AbstractMap<String, List<Candle>>() {
            override val entries: Set<Map.Entry<String, List<Candle>>> = candles.entries
            override fun get(key: String): List<Candle>? =
                throw OutOfMemoryError("controlled optional October publication allocation failure")
        }
        val fallback = publishing.runtime.apply(native, failingCandles)
        assertEquals(native.candidates, fallback.candidates)
        assertEquals(native.judgeTimeJst, fallback.judgeTimeJst)
        assertEquals(native.scanId, fallback.scanId)
        assertEquals(OctoberSimilarityScanAdapter.FALLBACK, fallback.policyVersion)
        verifyRecovery(publishing, "publication")
    }

    @Test fun latePreparationAndDiscardCannotLeakUnacceptedCorrection() {
        val observed = observed(); val (native, candles) = RuleAiObservedFixture.native(observed)
        val run = start(observed); val real = ready(run); capture(run, observed)
        frames(run.runtime).set(controlledCorrection(real).copy(preparedMs = (observed.boundary - 9) * 1000))
        val late = run.runtime.apply(native, candles)
        assertEquals(native.candidates, late.candidates)
        assertEquals("FRAME_NOT_READY", run.runtime.diagnosticStats().getJSONObject("october_similarity").getString("status"))
        run.runtime.discardPending()
        frames(run.runtime).set(controlledCorrection(real))
        val changed = run.runtime.apply(native, candles)
        assertEquals("APPLIED", run.runtime.diagnosticStats().getJSONObject("october_similarity").getString("status"))
        assertEquals("AUDJPY", changed.top1!!.instrument)
        run.runtime.discardPending()
        val retry = run.runtime.apply(native, candles)
        assertEquals(native.candidates, retry.candidates)
        assertEquals(native.judgeTimeJst, retry.judgeTimeJst)
        assertEquals("FRAME_NOT_READY", run.runtime.diagnosticStats().getJSONObject("october_similarity").getString("status"))
    }

    @Test fun newProductionHistoryProfileIncludesBothFixedAndVariableAndExcludesUnknownPolicies() {
        val entry = "2026-10-09T09:05:00+09:00"
        val row = HistoryRow(1, "current", "AUTO", entry, "USDJPY", "HIGH", "C", "ENTRY",
            entryTimeJst = entry, judgeTimeJst = "2026-10-09T09:10:00+09:00",
            policyVersion = OctoberSimilarityIndex.VERSION)
        assertTrue(ExpiryProfiles.includes(row, false, false)); assertFalse(ExpiryProfiles.includes(row, true, false))
        val fixed = row.copy(policyVersion = row.policyVersion + "_3M_FIXED")
        assertTrue(ExpiryProfiles.includes(fixed, true, false)); assertFalse(ExpiryProfiles.includes(fixed, false, false))
        assertTrue(ExpiryProfiles.includes(row.copy(policyVersion = OctoberSimilarityScanAdapter.FALLBACK), false, false))
        assertTrue(ExpiryProfiles.includes(row.copy(source = "MANUAL"), true, false))
        assertFalse(ExpiryProfiles.includes(row.copy(policyVersion = "OTHER_UNVERIFIED_POLICY"), false, false))
        assertTrue(ExpiryProfiles.includes(row.copy(policyVersion = "OTHER_UNVERIFIED_POLICY"), false, true))
    }
}

package jp.gmk.mobile.rankbaseline

data class RateRow(
    val instrument: String,
    val price: Double?,
    val bid: Double?,
    val ask: Double?,
    val source: String,
    val ageSeconds: Double?,
    val freshnessStatus: String = "UNKNOWN",
    /** Seconds since this device last fetched a quote for this instrument. */
    val fetchAgeSeconds: Double? = null,
    /** Actual provider / device receipt times. Never refreshed when displaying cached rows. */
    val sourceEpochMs: Long? = null,
    val receivedEpochMs: Long? = null
)

data class Candle(
    val timeEpochMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0
)

data class CandleBatch(
    val candles: Map<String, List<Candle>>,
    val errors: Map<String, String> = emptyMap()
)

data class ScanCandidate(
    val rank: Int,
    val instrument: String,
    val display: String,
    val direction: String,
    val grade: String,
    val probability: Double?,
    val decision: String,
    val score: Double = 0.0,
    val regime: String = "UNKNOWN",
    val regimeConfidence: Double = 0.0,
    val reasons: List<String> = emptyList()
)

data class ScanResult(
    val scanId: String = "",
    val atJst: String = "",
    val entryTimeJst: String = "",
    val judgeTimeJst: String = "",
    val candidates: List<ScanCandidate> = emptyList(),
    val warnings: List<String> = emptyList(),
    val source: String = "MANUAL",
    val policyVersion: String = "GMK_V0736_NATIVE_3M"
) {
    val top1: ScanCandidate? get() = candidates.minByOrNull { it.rank.takeIf { n -> n > 0 } ?: 999 }
}

data class HistoryRow(
    val id: Long,
    val scanId: String = "",
    val source: String,
    val atJst: String,
    val instrument: String,
    val direction: String,
    val grade: String,
    val decision: String,
    val candidateRank: Int = 1,
    val regime: String = "UNKNOWN",
    val entryTimeJst: String = "",
    val judgeTimeJst: String = "",
    val entryRate: Double? = null,
    val judgeRate: Double? = null,
    val entryRateSource: String = "",
    val judgeRateSource: String = "",
    val entryCapturedAtJst: String = "",
    val settledAtJst: String = "",
    val entryCaptureDelayMs: Long? = null,
    val judgeCaptureDelayMs: Long? = null,
    val entryProviderAgeSeconds: Double? = null,
    val judgeProviderAgeSeconds: Double? = null,
    val resultStatus: String = "WAIT_ENTRY",
    val policyVersion: String = "LEGACY_UNVERSIONED"
)


data class OneMinuteCandidate(
    val rank: Int,
    val instrument: String,
    val direction: String,
    val confidence: Double,
    val regime: String,
    val score: Double,
    val reasons: List<String> = emptyList()
)

data class OneMinuteScanResult(
    val scanId: String,
    val atJst: String,
    val entryTimeJst: String,
    val judgeTimeJst: String,
    val candidates: List<OneMinuteCandidate>,
    val source: String = "MANUAL_1M_LOCAL"
) {
    val top1: OneMinuteCandidate? get() = candidates.minByOrNull { it.rank }
}

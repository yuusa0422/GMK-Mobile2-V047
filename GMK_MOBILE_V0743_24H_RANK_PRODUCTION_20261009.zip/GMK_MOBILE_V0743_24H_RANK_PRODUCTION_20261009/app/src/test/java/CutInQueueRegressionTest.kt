import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZonedDateTime

class CutInQueueRegressionTest {
    private val at = ZonedDateTime.parse("2026-10-09T09:08:00+09:00")
    private val now = at.toInstant().toEpochMilli()
    private fun row(id: String, instrument: String, status: String = "WAIT_JUDGE") = HistoryRow(
        id.hashCode().toLong(), id, "AUTO", at.minusSeconds(10).toString(), instrument, "HIGH", "C", "ENTRY",
        entryTimeJst = at.minusMinutes(3).toString(), judgeTimeJst = at.plusSeconds(20).toString(),
        entryRate = 150.0, judgeRate = if (status == "WIN") 151.0 else null,
        settledAtJst = if (status == "WIN") at.toString() else "", resultStatus = status)
    private fun quote(instrument: String, price: Double, source: Long) = RateRow(
        instrument, price, price, price, "fixture", 0.0, "LIVE", sourceEpochMs = source, receivedEpochMs = now)

    @Test fun staleFirstSymbolDoesNotSuppressAnotherValidAdvantage() {
        val q = CutInEventQueue()
        val reports = CutInPolicy.observeEvents(q, listOf(row("stale", "EURJPY"), row("fresh", "USDJPY")),
            listOf(quote("EURJPY", 151.0, now - 30_000), quote("USDJPY", 151.0, now - 1_000)), now, true)
        assertEquals("stale", reports.single().scanId)
        assertEquals("fresh", q.advance(now, 0).started.scanId)
    }
    @Test fun futureSourceAndExpiredBitcoinCannotShowAnAdvantage() {
        val q = CutInEventQueue()
        CutInPolicy.observeEvents(q, listOf(row("future", "USDJPY"), row("stale-btc", "BTCJPY")),
            listOf(quote("USDJPY", 151.0, now + 1_000), quote("BTCJPY", 151.0, now - 16_000)), now, true)
        assertNull(q.advance(now, 0).current)
    }
    @Test fun queuedAdvantageIsReevaluatedWithFreshDirectionBeforeDisplay() {
        val q = CutInEventQueue()
        q.offerFinal("busy", "USDJPY", true, now, now)
        q.advance(now, 0)
        val rows = listOf(row("waiting", "EURJPY"))
        CutInPolicy.observeEvents(q, rows, listOf(quote("EURJPY", 151.0, now)), now, true)
        CutInPolicy.observeEvents(q, rows, listOf(quote("EURJPY", 149.0, now + 3_600)), now + 3_600, true)
        assertEquals(CutInEventQueue.Kind.LOSE_ADVANTAGE, q.advance(now + 3_600, 3_600).started.kind)
    }
    @Test fun missingCurrentQuoteRemovesQueuedAdvantage() {
        val q = CutInEventQueue()
        q.offerFinal("busy", "USDJPY", true, now, now)
        q.advance(now, 0)
        val rows = listOf(row("waiting", "EURJPY"))
        CutInPolicy.observeEvents(q, rows, listOf(quote("EURJPY", 151.0, now)), now, true)
        CutInPolicy.observeEvents(q, rows, emptyList(), now + 3_600, true)
        assertNull(q.advance(now + 3_600, 3_600).current)
    }
    @Test fun backgroundObservationKeepsFinalDuringScreenRecreation() {
        val q = CutInEventQueue()
        CutInPolicy.observeEvents(q, listOf(row("result", "AUDJPY", "WIN")), emptyList(), now, true)
        // Same VM controller is handed to the recreated Activity 30 seconds later.
        assertEquals(CutInEventQueue.Kind.WIN_FINAL, q.advance(now + 30_000, 30_000).started.kind)
        assertNull(q.advance(now + 30_001, 30_001).started)
    }
    @Test fun disabledOverlaysDoNotTurnOldHistoryIntoNewEvents() {
        val q = CutInEventQueue()
        CutInPolicy.observeEvents(q, listOf(row("result", "AUDJPY", "WIN")), emptyList(), now, false)
        assertEquals(0, q.pendingCount())
        CutInPolicy.observeEvents(q, listOf(row("result", "AUDJPY", "WIN")), emptyList(), now + 20_001, true)
        assertEquals(0, q.pendingCount())
    }
}

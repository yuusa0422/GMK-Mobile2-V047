import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.domain.ScanCandidate
import jp.gmk.mobile.domain.ScanResult
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
@LooperMode(LooperMode.Mode.PAUSED)
class HistoryPublicationLatencyTest {
    private val app get() = RuntimeEnvironment.getApplication()
    @Before fun clear() {
        listOf("gmk_mobile_history", "gmk_mobile_history_journal").forEach {
            app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
    }
    private val result = ScanResult("latency", "2026-10-09T09:04:50+09:00",
        "2026-10-09T09:05:00+09:00", "2026-10-09T09:08:00+09:00",
        listOf(ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "C", null, "ENTRY")), source = "AUTO")

    @Test fun historySnapshotIsVisibleWhileItsDurableJournalWriteIsBlocked() {
        val blockNext = AtomicBoolean(false)
        val entered = AtomicReference(CountDownLatch(1))
        val release = AtomicReference(CountDownLatch(1))
        val context = object : ContextWrapper(app) {
            override fun getSharedPreferences(name: String, mode: Int): SharedPreferences {
                val actual = super.getSharedPreferences(name, mode)
                if (name != "gmk_mobile_history_journal") return actual
                return object : SharedPreferences by actual {
                    override fun edit(): SharedPreferences.Editor {
                        val editor = actual.edit()
                        return object : SharedPreferences.Editor by editor {
                            override fun putString(key: String, value: String?): SharedPreferences.Editor {
                                editor.putString(key, value)
                                return this
                            }
                            override fun commit(): Boolean {
                                if (blockNext.compareAndSet(true, false)) {
                                    entered.get().countDown()
                                    check(release.get().await(3, TimeUnit.SECONDS)) { "Blocked fixture not released" }
                                }
                                return editor.commit()
                            }
                        }
                    }
                }
            }
        }
        val store = HistoryStore(context)
        store.load()
        fun mutate(expected: String, body: () -> Unit) {
            entered.set(CountDownLatch(1)); release.set(CountDownLatch(1)); blockNext.set(true)
            val error = AtomicReference<Throwable?>(null)
            val worker = Thread({ try { body() } catch (t: Throwable) { error.set(t) } }, "fixture-history-io")
            worker.start()
            try {
                assertTrue("Fixture reached slow journal", entered.get().await(2, TimeUnit.SECONDS))
                assertTrue("The disk write is still blocked", worker.isAlive)
                // This immutable snapshot read does not call synchronized load() or wait on IO.
                assertEquals(expected, store.rows.value.single().resultStatus)
            } finally {
                release.get().countDown(); worker.join(2_000)
            }
            assertFalse("Mutation must finish after disk is released", worker.isAlive)
            error.get()?.let { throw AssertionError("Mutation failed", it) }
        }
        mutate("WAIT_ENTRY") { store.add(result) }
        mutate("WAIT_JUDGE") { store.updateEntryRate(result.scanId, 150.0, "fixture", result.entryTimeJst, 0, 0.0) }
        mutate("WIN") { store.settle(result.scanId, 151.0, "fixture", result.judgeTimeJst, 0, 0.0) }
        val until = System.nanoTime() + TimeUnit.SECONDS.toNanos(3)
        while (store.diagnosticStats().getBoolean("writer_active") && System.nanoTime() < until) Thread.sleep(5)
        assertEquals("WIN", HistoryStore(app).load().single().resultStatus)
        assertEquals(150.0, store.rows.value.single().entryRate!!, 0.0)
        assertEquals(151.0, store.rows.value.single().judgeRate!!, 0.0)
    }
}

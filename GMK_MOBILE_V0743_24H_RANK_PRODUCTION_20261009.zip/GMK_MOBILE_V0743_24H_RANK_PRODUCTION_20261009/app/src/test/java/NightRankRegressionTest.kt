import android.content.Context
import jp.gmk.mobile.data.*
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.october.*
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.*
import java.time.*
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.GZIPInputStream

/** Night timestamps below test scheduling and rank transport using real OHLC.
 * They do not represent measured night-session win rates. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
class NightRankRegressionTest {
    companion object {
        private val root=File(requireNotNull(System.getProperty("gmk.projectRoot")))
        private val jst=ZoneId.of("Asia/Tokyo")
        private val model by lazy {
            ChartConditionalRankCatalog.loadIndex { File(root,"app/src/main/assets/$it").readBytes() }
        }
        private val examples by lazy {
            val found=linkedMapOf<String,Pair<ScanResult,Map<String,List<Candle>>>>()
            val input=NightRankRegressionTest::class.java.classLoader!!
                .getResourceAsStream("rank_assessment_native_october.bin.gz")!!
            DataInputStream(BufferedInputStream(GZIPInputStream(input))).use { data ->
                check(data.readInt()==0x474D4B41)
                repeat(data.readInt()) {
                    val b=data.readLong();val prices=linkedMapOf<String,List<Candle>>()
                    repeat(data.readInt()) {
                        val symbol=data.readUTF()
                        prices[symbol]=List(data.readInt()) {
                            Candle(data.readLong(),data.readDouble(),data.readDouble(),data.readDouble(),data.readDouble(),data.readDouble())
                        }
                    }
                    if(found.size<3) {
                        val at=Instant.ofEpochSecond(b).atZone(jst)
                        val native=LocalRuleEngine().scan(prices,"AUTO",at.minusSeconds(10),at)
                        val top=native.top1
                        if(top?.grade=="E") {
                            val x=OctoberSimilarityScanAdapter.features(prices.getValue(top.instrument),b)!!
                            val result=model.predict(b,ChartConditionalRankIndex.symbolIndex(top.instrument),top.direction,x,0)
                            if(result.rank in setOf("F","G","H"))found.putIfAbsent(result.rank,native to prices)
                        }
                    }
                }
                check(data.read()==-1)
            }
            check(found.keys==setOf("F","G","H"));found
        }
    }
    private fun moved(grade:String,at:String,source:String): Pair<ScanResult,Map<String,List<Candle>>> {
        val (original,prices)=examples.getValue(grade)
        val target=ZonedDateTime.parse(at);val b=target.toEpochSecond()
        val originalB=ZonedDateTime.parse(original.entryTimeJst).toEpochSecond()
        val delta=(ChartConditionalRankAdapter.featureBoundary(b)-originalB)*1000
        val shifted=prices.mapValues { (_,rows)->rows.map { it.copy(timeEpochMs=it.timeEpochMs+delta) } }
        return original.copy(scanId="night-$grade-$source-$b",source=source,
            atJst=target.minusSeconds(10).toString(),entryTimeJst=target.toString(),
            judgeTimeJst=target.plusMinutes(3).toString()) to shifted
    }
    private fun withoutDisplay(result:ScanResult,original:ScanResult):ScanResult = result.copy(
        candidates=result.candidates.map { c ->
            val before=original.candidates.single { it.rank==c.rank }
            c.copy(grade=before.grade,assessment=c.assessment?.let { a ->
                a.copy(operationalGrade=before.assessment!!.operationalGrade,
                    chosenAction=a.chosenAction.copy(operationalGrade=before.assessment.chosenAction.operationalGrade),chartRank=null)
            })
        })
    @Test fun ruleAndAiGateEvaluateEveryValidHourInsteadOfApplyingAClockStop() {
        val f=FinalRankPolicy.Features("USDJPY","RANGE","HIGH",.23,.66,58.0,.8,.42,.8,.75)
        val gate=OfficialWinGate.Features("USDJPY","RANGE","HIGH","C",82,false,.62,.23,.75,
            12,.66,58.0,.05,.8,.42,.8)
        for(hour in 0..23) {
            assertNotEquals(RuleSelectionStage.TIME_WINDOW,FinalRankPolicy.classifyBase(f,hour).selectionStage)
            assertNotEquals(RuleSelectionStage.TIME_WINDOW,FinalRankPolicy.classify(f,hour).selectionStage)
            val evaluated=OfficialWinGate.evaluate(gate.copy(hourJst=hour))
            assertTrue("Valid hour $hour must actually evaluate the gate",evaluated.score>0 && evaluated.score<1)
            assertEquals(evaluated.score>=OfficialWinGate.THRESHOLD,evaluated.allowEntry)
        }
        for(hour in listOf(-1,24))assertEquals(OfficialWinGate.Result(0.0,false),OfficialWinGate.evaluate(gate.copy(hourJst=hour)))
        assertEquals(OfficialWinGate.Result(0.0,false),OfficialWinGate.evaluate(gate.copy(probability=Double.NaN)))
    }
    @Test fun actualFghLabelsSurviveNightAutoManualAndHistoryWithoutActionChanges() {
        val app=RuntimeEnvironment.getApplication()
        listOf("gmk_mobile_history","gmk_mobile_history_journal").forEach {
            app.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit()
        }
        val store=HistoryStore(app)
        for((i,grade) in listOf("F","G","H").withIndex())for((baseAt,source) in listOf(
            "2026-10-09T23:00:00+09:00" to "AUTO",
            "2026-10-10T00:00:00+09:00" to "AUTO",
            "2026-10-09T23:17:35+09:00" to "MANUAL")) {
            // AUTO owns one result per entry boundary, so each case needs its own slot.
            val at=ZonedDateTime.parse(baseAt).plusMinutes(i*5L).toString()
            val (native,prices)=moved(grade,at,source);val b=ZonedDateTime.parse(at).toEpochSecond()
            val result=ChartConditionalRankAdapter(model) { (b-5)*1000 }.apply(native,native,prices,null)
            assertEquals(native,withoutDisplay(result,native))
            val top=result.top1!!;assertEquals(grade,top.grade);assertEquals("SKIP",top.decision)
            val evidence=top.assessment!!.chartRank!!
            assertEquals(grade,evidence.grade);assertEquals(200,evidence.supportN)
            assertTrue(evidence.referenceDates>50);assertTrue(evidence.effectiveSampleSize!!>=100)
            assertTrue(evidence.outsideOriginalResearchScope);assertNotNull(evidence.scopeLabel)
            assertTrue(evidence.displayLabel.contains("類似ランク $grade"))
            store.add(result)
        }
        val restored=HistoryStore(app).load()
        assertEquals(9,restored.size)
        for(grade in listOf("F","G","H")) {
            val filtered=restored.filter { ChartRankDisplay.matches(it.assessment,grade) }
            assertEquals(3,filtered.size)
            filtered.forEach { assertEquals(grade,it.grade);assertEquals(200,it.assessment!!.chartRank!!.supportN) }
        }
    }
    @Test fun nonAlignedManualUsesCompletedM1AndIgnoresPartialAndFutureCandles() {
        val at="2026-10-09T23:17:35+09:00";val (native,prices)=moved("H",at,"MANUAL")
        val b=ZonedDateTime.parse(at).toEpochSecond();val anchor=ChartConditionalRankAdapter.featureBoundary(b)
        assertEquals(ZonedDateTime.parse("2026-10-09T23:18:00+09:00").toEpochSecond(),anchor)
        val symbol=native.top1!!.instrument
        val actual=OctoberSimilarityScanAdapter.featureRows(prices.getValue(symbol),anchor)!!
        assertTrue(actual.all { it.timeEpochMs+60_000 <= (b-10)*1000 })
        val a=ChartConditionalRankAdapter(model) { (b-5)*1000 }
        val first=a.apply(native,native,prices,null)
        val contaminated=prices+mapOf(symbol to prices.getValue(symbol).filter { it.timeEpochMs<=(anchor-120)*1000 }+
            listOf(Candle((anchor-60)*1000,900.0,1000.0,800.0,999.0),Candle(anchor*1000,800.0,900.0,700.0,899.0)))
        assertEquals(first,a.apply(native,native,contaminated,null))
        assertEquals("H",first.top1!!.grade)
    }
    @Test fun frozenCalibrationOrdersEThroughHAndKeepsUnsupportedResultsUnranked() {
        val results=mutableListOf<ChartConditionalRankIndex.Result>()
        DataInputStream(File(root,"tools/chart_rank_independent/queries47.bin").inputStream()).use { data ->
            assertEquals(0x43495251,data.readInt());assertEquals(47,data.readInt())
            repeat(47) {
                val name=ByteArray(data.readInt());data.readFully(name)
                val b=data.readLong();val symbol=data.readInt();val direction=if(data.readInt()==1)"HIGH" else "LOW"
                results+=model.predict(b,symbol,direction,FloatArray(35) { data.readFloat() },0)
            }
        }
        val grades=listOf("E","F","G","H")
        for(i in grades.indices)for(j in i+1 until grades.size) {
            val stronger=results.filter { it.rank==grades[i] };val weaker=results.filter { it.rank==grades[j] }
            assertTrue(stronger.isNotEmpty() && weaker.isNotEmpty())
            assertTrue(stronger.minOf { it.calibratedProbability } >= weaker.maxOf { it.calibratedProbability })
        }
        val held=results.filter { it.rank=="UNRANKED" };assertEquals(2,held.size)
        assertTrue(held.all { it.outOfCalibrationRange && !it.calibrationSupport })
    }
    @Test fun missingUnsupportedOrExpiredInputsDoNotManufactureFgh() {
        val (native,prices)=moved("F","2026-10-09T23:00:00+09:00","MANUAL")
        val b=ZonedDateTime.parse(native.entryTimeJst).toEpochSecond()
        val a=ChartConditionalRankAdapter(model) { (b-5)*1000 }
        for(symbol in listOf("BTCJPY","NZDJPY")) {
            val unsupported=native.copy(candidates=native.candidates.map { if(it.rank==1)it.copy(instrument=symbol) else it })
            val result=a.apply(unsupported,unsupported,prices,null)
            assertEquals("E",result.top1!!.grade);assertEquals(0,result.top1!!.assessment!!.chartRank!!.supportN)
        }
        val missing=a.apply(native,native,emptyMap(),null)
        assertEquals("MISSING_CONTIGUOUS_61_M1_BARS",missing.top1!!.assessment!!.chartRank!!.statusReason)
        val expired=ChartConditionalRankAdapter(model) { b*1000-799 }.apply(native,native,prices,null)
        assertEquals("PUBLISH_DEADLINE",expired.top1!!.assessment!!.chartRank!!.statusReason)
        val absent=ChartConditionalRankAdapter(null) { (b-5)*1000 }.apply(native,native,prices,null,"MODEL_UNAVAILABLE")
        assertEquals("UNRANKED",absent.top1!!.assessment!!.chartRank!!.grade)
        assertEquals(0,absent.top1!!.assessment!!.chartRank!!.supportN)
    }
    @Test fun realBackgroundPreparesNightAndMidnightRanksWithoutNetworkOrActionFrames() {
        val app=RuntimeEnvironment.getApplication()
        for(at in listOf("2026-10-09T23:00:00+09:00","2026-10-10T00:00:00+09:00")) {
            val (_,prices)=moved("H",at,"AUTO");val b=ZonedDateTime.parse(at).toEpochSecond()
            val directory=File(app.filesDir,"horizon_history_v1");directory.deleteRecursively()
            val cache=HorizonMarketCache(directory)
            prices.forEach { (symbol,rows)->cache.merge(symbol,rows,(b-20)*1000);cache.persist(symbol) }
            val repository=MarketRepository(AppPrefs(app));val owner=SupervisorJob()
            val runtime=HorizonRuntime(app,repository,epochMillis={ (b-20)*1000 })
            @Suppress("UNCHECKED_CAST")
            val frames=HorizonRuntime::class.java.getDeclaredField("preparedChartRank").apply { isAccessible=true }
                .get(runtime) as AtomicReference<ChartConditionalRankFrame?>
            try {
                runtime.start(CoroutineScope(owner+Dispatchers.Default),{true},{false})
                val until=System.nanoTime()+45_000_000_000L
                while(frames.get()==null && System.nanoTime()<until)Thread.sleep(10)
                val ready=frames.get();assertNotNull(runtime.diagnosticStats().toString(),ready)
                assertEquals(b,ready!!.boundary);assertTrue(ready.predictions.isNotEmpty())
                assertEquals(0L,repository.diagnosticStats().getLong("requests"))
                for(field in listOf("prepared","preparedDirect","preparedOctober")) {
                    val action=HorizonRuntime::class.java.getDeclaredField(field).apply { isAccessible=true }
                        .get(runtime) as AtomicReference<*>
                    assertNull("Original action scope must remain unchanged",action.get())
                }
            } finally { runtime.stop();owner.cancel();runBlocking { owner.join() } }
        }
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test

class RankAssessmentRegressionTest {
    private val unmatched = FinalRankPolicy.Features("EURJPY", "RANGE", "LOW", -0.1854741213969764,
        0.6074969776330627, 38.96103896103008, 1.0, 0.2617449664431066, 0.0479976998631364, 0.6959391103515363)
    private val rejected = FinalRankPolicy.Features("GBPJPY", "RANGE", "HIGH", 0.070094364453424,
        0.5617292529805615, 59.53757225434276, 0.5, 0.3290322580647385, 0.0571518701141647, 0.7938712363579363)

    private fun assess(f: FinalRankPolicy.Features, hour: Int, gateRejected: Boolean = false, gate: Double? = null,
        baseOnly: Boolean = false): CandidateAssessment {
        val base = FinalRankPolicy.classifyBase(f, hour)
        val policy = if (baseOnly) base else FinalRankPolicy.classify(f, hour)
        val grade = if (gateRejected) "E" else policy.rank
        val decision = if (grade in setOf("S", "A", "B", "C")) "ENTRY" else "SKIP"
        val direction = if ((if (policy.reverse) -f.score else f.score) >= 0) "HIGH" else "LOW"
        return CandidateAssessmentFactory.native(f.instrument, direction, base, policy, grade, decision, gate, gateRejected)
    }

    @Test fun actualBranchesSeparateUnmatchedRemapGateAndInvalidTime() {
        val noMatch = assess(unmatched, 10)
        assertEquals(RuleSelectionStage.UNMATCHED_RESCUE_FAILED, noMatch.selectionStage)
        assertEquals(CandidateSkipReason.UNMATCHED_RESCUE_FAILED, noMatch.skipReason)
        assertNull(noMatch.historicalExpectedRate)
        assertNull(noMatch.historicalSampleSize)
        assertEquals("検証待ち", noMatch.strengthLabel)
        val lower = assess(unmatched, 10, baseOnly = true)
        assertEquals(RuleSelectionStage.BASE_UNMATCHED, lower.selectionStage)
        assertEquals(CandidateSkipReason.RULE_UNMATCHED, lower.skipReason)
        val remap = assess(rejected, 11)
        assertEquals(164, remap.legacyRuleId)
        assertEquals("C", remap.legacyRuleGrade)
        assertEquals("E", remap.operationalGrade)
        assertEquals(CandidateSkipReason.REMAP_RESCUE_REJECTED, remap.skipReason)
        assertNull(remap.historicalExpectedRate)
        val time = assess(unmatched, 23)
        assertNotEquals(CandidateSkipReason.TIME_WINDOW, time.skipReason)
        assertNotEquals(RuleSelectionStage.TIME_WINDOW, time.selectionStage)
        assertEquals("SKIP", time.decision)
        val f = FinalRankPolicy.Features("EURJPY", "RANGE", "LOW", -0.030886325801022,
            0.5762414276649835, 45.06172839505674, 0.8333333333333334, 0.0406504065040124,
            0.2094523110430454, 0.5709723658877888)
        val gate = assess(f, 10, true, 0.5257955603615683)
        assertEquals(10067, gate.operationalRuleId)
        assertEquals(CandidateSkipReason.AI_GATE_REJECTED, gate.skipReason)
        assertEquals(0.5257955603615683, gate.gateScore!!, 0.0)
        assertEquals("E", gate.operationalGrade)
        assertTrue(gate.historicalRateLabel.startsWith("過去ルール統計:"))
        assertEquals("UNVALIDATED", gate.strengthStatus)
    }

    @Test fun actualRemapAndBothRescueStagesRetainSeparateRuleOrigins() {
        val examples = listOf(
            FinalRankPolicy.Features("EURJPY", "TREND_DOWN", "LOW", -0.2558807714868051,
                0.6459897058275763, 16.911764705893873, 0.8333333333333334, 0.6166666666664535,
                1.1345151062134236, 0.9167734848484078) to Pair(RuleSelectionStage.REMAPPED, 82),
            FinalRankPolicy.Features("USDJPY", "RANGE", "HIGH", 0.026286372017139,
                0.5481487753253131, 50.93167701862948, 0.5, 0.0933333333332423,
                0.6080560147420374, 0.6657374893820059) to Pair(RuleSelectionStage.RESCUE_STAGE1, 10018),
            FinalRankPolicy.Features("GBPJPY", "TREND_DOWN", "LOW", -0.2085570004221392,
                0.6446526701308631, 34.3023255813945, 1.0, 0.2625000000000155,
                0.5606333921264157, 0.6738811338889816) to Pair(RuleSelectionStage.RESCUE_STAGE2, 20092)
        )
        for ((f, expected) in examples) {
            val assessment = assess(f, 10)
            assertEquals(expected.first, assessment.selectionStage)
            assertEquals(expected.second, assessment.operationalRuleId)
            assertEquals("ENTRY", assessment.decision)
            assertNull(assessment.skipReason)
            assertNotNull(assessment.historicalExpectedRate)
            assertTrue(assessment.historicalSampleSize!! > 0)
            assertEquals("検証待ち", assessment.strengthLabel)
        }
    }

    private fun candidate(instrument: String, grade: String, rule: Int, direction: String = "LOW"): ScanCandidate {
        val policy = FinalRankPolicy.Match(grade, false, 0.65, 0.60, 100, rule, RuleSelectionStage.REMAPPED)
        val decision = if (grade == "E") "SKIP" else "ENTRY"
        return ScanCandidate(1, instrument, instrument, direction, grade, 0.65, decision,
            assessment = CandidateAssessmentFactory.native(instrument, direction, policy, policy, grade, decision, .57, false))
    }

    @Test fun CCorrectionRetainsNativeTargetAndTriggerAndChosenAction() {
        val target = candidate("GBPJPY", "B", 82)
        val source = candidate("USDJPY", "C", 10067)
        val assessment = CandidateAssessmentFactory.similarityCorrection(target, source, "HIGH", 5)
        assertEquals(target.assessment!!.originalAction, assessment.originalAction)
        assertEquals("B", assessment.legacyRuleGrade)
        assertEquals(82, assessment.legacyRuleId)
        assertEquals("GBPJPY", assessment.chosenAction.instrument)
        assertEquals("HIGH", assessment.chosenAction.direction)
        assertEquals("C", assessment.chosenAction.operationalGrade)
        assertEquals("ENTRY", assessment.chosenAction.decision)
        assertEquals(5, assessment.chosenAction.judgeMinutes)
        assertEquals(source.assessment!!.chosenAction, assessment.correctionSourceAction)
        assertEquals("LOW", assessment.originalAction.direction)
        assertEquals("B", assessment.originalAction.operationalGrade)
        assertNull(assessment.skipReason)
        assertTrue(assessment.historicalRateLabel.startsWith("補正前の過去ルール統計:"))
        assertEquals("UNVALIDATED", assessment.strengthStatus)
        // The descriptive factory itself never mutates the operational input objects.
        assertEquals("LOW", target.direction)
        assertEquals("B", target.grade)
        assertEquals("C", source.grade)
    }

    @Test fun oldCallersAndHistoryRemainUnknownWithoutInventedStatistics() {
        val candidate = ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "E", .50, "SKIP")
        assertNull(candidate.assessment)
        assertEquals("未記録", candidate.legacyRuleGrade)
        assertEquals("旧データ・理由未記録", candidate.skipReasonLabel)
        assertEquals("検証待ち", candidate.strengthLabel)
        assertEquals("過去ルール統計: 未記録", candidate.historicalRateLabel)
        val history = HistoryRow(1, source = "AUTO", atJst = "old", instrument = "USDJPY", direction = "HIGH", grade = "E", decision = "SKIP")
        assertNull(history.assessment)
        assertEquals("未記録", history.legacyRuleGrade)
        assertEquals("旧データ・理由未記録", history.skipReasonLabel)
        val correction = CandidateAssessmentFactory.similarityCorrection(candidate, candidate, "LOW", 3)
        assertEquals("未記録", correction.legacyRuleGrade)
        assertEquals("E", correction.originalAction.operationalGrade)
        assertEquals("HIGH", correction.originalAction.direction)
        assertNull(correction.legacyRuleId)
        assertNull(correction.historicalExpectedRate)
    }

    @Test fun alternateAdaptersCanExplainSafetySkipAndActionChanges() {
        val top = candidate("USDJPY", "A", 8)
        val safety = CandidateAssessmentFactory.correction(top, top, top.direction, "E", "SKIP", 3,
            "レート安全性による見送り", CandidateSkipReason.QUOTE_UNSAFE)
        assertEquals("A", safety.legacyRuleGrade)
        assertEquals(CandidateSkipReason.QUOTE_UNSAFE, safety.skipReason)
        assertEquals("E", safety.chosenAction.operationalGrade)
        assertEquals("SKIP", safety.chosenAction.decision)
        val reroute = CandidateAssessmentFactory.correction(top, top, "HIGH", "R", "ENTRY", 15, "R13")
        assertEquals("A", reroute.legacyRuleGrade)
        assertEquals("R", reroute.operationalGrade)
        assertEquals(15, reroute.chosenAction.judgeMinutes)
        assertEquals("UNVALIDATED", reroute.strengthStatus)
        assertEquals(0.57, reroute.gateScore!!, 0.0)
    }

    @Test fun fixedThreeProjectionKeepsMetadataHorizonConsistentWithRealJudge() {
        val top = candidate("USDJPY", "C", 10067)
        val metadata = CandidateAssessmentFactory.correction(top, top, "HIGH", "R", "ENTRY", 15, "R13")
        val selected = top.copy(direction = "HIGH", grade = "R", assessment = metadata)
        val result = ScanResult("projection", "2026-10-09T11:59:50+09:00", "2026-10-09T12:00:00+09:00",
            "2026-10-09T12:15:00+09:00", listOf(selected), source = "AUTO", policyVersion = "GMK_V0736_PC_R13")
        val fixed = ExpiryProfiles.apply(result, true)
        assertEquals("2026-10-09T12:03+09:00", fixed.judgeTimeJst)
        assertEquals(3, fixed.top1!!.assessment!!.chosenAction.judgeMinutes)
        assertEquals(metadata.originalAction, fixed.top1!!.assessment!!.originalAction)
        assertEquals(metadata.correctionSourceAction, fixed.top1!!.assessment!!.correctionSourceAction)
        assertEquals(selected.direction, fixed.top1!!.direction)
        assertEquals(selected.grade, fixed.top1!!.grade)
        assertEquals(selected.decision, fixed.top1!!.decision)
        assertTrue(fixed.top1!!.assessment!!.correctionLabel!!.contains("モデル選択=15分"))
    }
}

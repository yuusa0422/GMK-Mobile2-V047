import android.app.Application
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.BitbankRealtimeFeed
import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.data.MarketRequestAbortedException
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.mockwebserver.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.atomic.AtomicLong

/** Real HTTP / EIO4 fixtures; quotes retain provider time and exact-minute OPEN. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
class MarketTransportV0740Test {
    private lateinit var app: Application
    private val servers=mutableListOf<MockWebServer>()
    private val clients=mutableListOf<OkHttpClient>()
    private val feeds=mutableListOf<Pair<BitbankRealtimeFeed,Job>>()
    @Before fun setup() { app=RuntimeEnvironment.getApplication() }
    @After fun cleanup() {
        feeds.forEach { (feed,owner)->feed.stop();owner.cancel();runBlocking { owner.join() } }
        clients.forEach { it.dispatcher.cancelAll();it.connectionPool.evictAll();it.dispatcher.executorService.shutdownNow() }
        servers.forEach { it.shutdown() }
    }
    private fun server()=MockWebServer().also { it.start();servers+=it }
    private fun repo(server:MockWebServer):MarketRepository {
        val repo=MarketRepository(AppPrefs(app))
        val client=OkHttpClient.Builder().addInterceptor { chain->
            val request=chain.request()
            chain.proceed(request.newBuilder().url(server.url(request.url.encodedPath+"?provider="+request.url.host)).build())
        }.build()
        clients+=client
        MarketRepository::class.java.getDeclaredField("client").apply { isAccessible=true }.set(repo,client)
        return repo
    }
    private fun candlePayload(rows:List<Long>)=JSONObject().put("success",1).put("data",JSONObject().put("candlestick",JSONArray().put(
        JSONObject().put("ohlcv",JSONArray().apply { rows.forEach { t->put(JSONArray().put("100").put("102").put("98").put("101").put("1").put(t)) } })
    ))).toString()
    @Test fun officialAnnualAndDailyPartitionsStayDistinctAcrossNewYear() {
        assertEquals(listOf("2026"),MarketRepository.bitbankChartRequestKeys("4h",LocalDate.of(2026,10,8)))
        assertEquals(listOf("2025","2026"),MarketRepository.bitbankChartRequestKeys("1d",LocalDate.of(2026,1,3)))
        assertEquals(listOf("20251231","20260101"),MarketRepository.bitbankChartRequestKeys("1h",LocalDate.of(2026,1,1)))
    }
    @Test fun fourHourChartRequestsOneAnnualPartitionAndKeepsItsFocusedWindow()=runBlocking {
        val server=server();val repo=repo(server)
        val center=LocalDate.of(2026,3,10);val zone=ZoneId.of("Asia/Tokyo")
        val start=center.minusDays(6).atStartOfDay(zone).toInstant().toEpochMilli()
        val end=center.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        val inside=start+4*60*60_000L
        server.enqueue(MockResponse().setBody(candlePayload(listOf(start-4*60*60_000L,inside,end))))
        val result=repo.fetchChartCandles("BTCJPY","4h",center.atStartOfDay(zone).toInstant().toEpochMilli())
        assertEquals(listOf(inside),result.candles.map { it.timeEpochMs })
        assertEquals(1,server.requestCount)
        assertTrue(server.takeRequest().path!!.startsWith("/btc_jpy/candlestick/4hour/2026?"))
    }
    @Test fun dailyChartUsesTwoAnnualRequestsAcrossNewYearWithoutDuplicateCandles()=runBlocking {
        val server=server();val repo=repo(server);val zone=ZoneId.of("Asia/Tokyo")
        val center=LocalDate.of(2026,1,3);val inside=center.minusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        repeat(2) { server.enqueue(MockResponse().setBody(candlePayload(listOf(inside)))) }
        val result=repo.fetchChartCandles("BTCJPY","1d",center.atStartOfDay(zone).toInstant().toEpochMilli())
        assertEquals(listOf(inside),result.candles.map { it.timeEpochMs });assertEquals(2,server.requestCount)
        val paths=listOf(server.takeRequest().path!!.substringBefore('?'),server.takeRequest().path!!.substringBefore('?')).toSet()
        assertEquals(setOf("/btc_jpy/candlestick/1day/2025","/btc_jpy/candlestick/1day/2026"),paths)
    }
    @Test fun syntacticallySuccessfulStaleYahooFallsBackAndRetainsFreshProviderTime()=runBlocking {
        val server=server();val repo=repo(server);val now=System.currentTimeMillis()/1000
        fun payload(ts:Long,price:Double)="{\"chart\":{\"result\":[{\"meta\":{\"regularMarketTime\":$ts,\"regularMarketPrice\":$price},\"timestamp\":[],\"indicators\":{\"quote\":[{\"close\":[]}]}}]}}"
        server.enqueue(MockResponse().setBody(payload(now-90,150.0)))
        server.enqueue(MockResponse().setBody(payload(now,151.0)))
        val rate=repo.fetchRate("USDJPY")
        assertEquals("LIVE",rate.freshnessStatus);assertEquals(151.0,rate.price!!,0.0)
        assertEquals(now*1000,rate.sourceEpochMs);assertEquals(2,server.requestCount)
        assertTrue(server.takeRequest().path!!.contains("provider=query2.finance.yahoo.com"))
        assertTrue(server.takeRequest().path!!.contains("provider=query1.finance.yahoo.com"))
    }
    @Test fun unpublishedExactMinuteOnQueryTwoUsesQueryOneOpenWithoutPriceSubstitution()=runBlocking {
        val server=server();val repo=repo(server);val target=(System.currentTimeMillis()/60_000-3)*60_000
        server.enqueue(MockResponse().setBody("{\"chart\":{\"result\":[{\"timestamp\":[],\"indicators\":{\"quote\":[{\"open\":[],\"high\":[],\"low\":[],\"close\":[]}]}}]}}"))
        server.enqueue(MockResponse().setBody("{\"chart\":{\"result\":[{\"timestamp\":[${target/1000}],\"indicators\":{\"quote\":[{\"open\":[150.0],\"high\":[152.0],\"low\":[149.0],\"close\":[151.0]}]}}]}}"))
        val candle=repo.fetchMinuteOpenAt("USDJPY",target)
        assertNotNull(candle);assertEquals(target,candle!!.timeEpochMs);assertEquals(150.0,candle.open,0.0)
        assertEquals(151.0,candle.close,0.0);assertEquals(2,server.requestCount)
    }
    @Test fun cancellingHttpWaitCancelsUnderlyingCallInsteadOfWaitingForReadTimeout()=runBlocking {
        val server=server();val repo=repo(server)
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
        val request=launch { repo.fetchRate("BTCJPY") }
        withTimeout(3000) { while(server.requestCount==0)delay(10) }
        request.cancelAndJoin()
        val deadline=System.nanoTime()+2_000_000_000L
        while(repo.diagnosticStats().getLong("cancelled")==0L && System.nanoTime()<deadline)delay(10)
        assertEquals(1,server.requestCount);assertEquals(1L,repo.diagnosticStats().getLong("cancelled"))
    }
    @Test fun intentionalForexAbortPropagatesSeparatelyFromProviderUnavailable()=runBlocking {
        val server=server();val repo=repo(server)
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
        val outcome=async { runCatching { repo.fetchRate("USDJPY") }.exceptionOrNull() }
        withTimeout(3000) { while(server.requestCount==0)delay(10) }
        repo.cancelInFlightRequests()
        val error=withTimeout(3000) { outcome.await() }
        assertTrue("Intentional abort must not become a fake UNAVAILABLE quote",error is MarketRequestAbortedException)
        assertTrue(currentCoroutineContext().isActive)
        assertEquals(1,server.requestCount)
        assertEquals(1L,repo.diagnosticStats().getLong("cancelled"))
    }
    @Test fun parentScopeCancellationImmediatelyInvalidatesStreamFreshness()=runBlocking {
        val server=server();val now=AtomicLong(System.currentTimeMillis())
        server.enqueue(MockResponse().withWebSocketUpgrade(object:WebSocketListener() {
            override fun onOpen(ws:WebSocket,response:Response) { ws.send("0{\"sid\":\"scope-test\",\"pingInterval\":25000,\"pingTimeout\":60000}") }
            override fun onMessage(ws:WebSocket,text:String) {
                if(text=="40")ws.send("40{\"sid\":\"namespace\"}")
                if(text=="42[\"join-room\",\"ticker_btc_jpy\"]")ws.send("42[\"message\",{\"room_name\":\"ticker_btc_jpy\",\"message\":{\"data\":{\"last\":\"100\",\"buy\":\"99\",\"sell\":\"101\",\"timestamp\":${now.get()-100}}}}]")
            }
        }))
        val owner=SupervisorJob();val feed=BitbankRealtimeFeed(server.url("/socket.io/?EIO=4&transport=websocket").toString(),now::get)
        feeds+=feed to owner;feed.start(CoroutineScope(owner+Dispatchers.Default))
        withTimeout(4000) { while(feed.latest.value==null)delay(10) }
        assertTrue(feed.hasFreshStream(now.get()))
        owner.cancel();owner.join()
        assertEquals("STOPPED",feed.status);assertFalse(feed.hasFreshStream(now.get()))
        assertFalse(feed.diagnosticStats().getBoolean("owner_active"))
        assertEquals(now.get()-100,feed.latest.value!!.sourceEpochMs)
    }
}

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.rankbaseline.LocalRuleEngine as OriginalLocalRuleEngine
import jp.gmk.mobile.rankbaseline.Candle as OriginalCandle
import org.junit.Assert.*
import org.junit.Test
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.time.Instant
import java.time.ZoneId
import java.util.zip.GZIPInputStream

/** Real observed candle replay against the unchanged V0740 engine, not a mirror implementation. */
class NativeRankMetadataParityTest {
    @Test fun all432OctoberFramesKeepEveryOperationalFieldExactly() {
        val stream = javaClass.classLoader!!.getResourceAsStream("rank_assessment_native_october.bin.gz")
        assertNotNull("Missing recorded native replay fixture", stream)
        val engine = LocalRuleEngine()
        val original = OriginalLocalRuleEngine()
        val reasons = mutableMapOf<CandidateSkipReason, Int>()
        var empty = 0; var entries = 0; var candidateCount = 0
        val grades = mutableMapOf<String, Int>()
        DataInputStream(BufferedInputStream(GZIPInputStream(stream!!))).use { input ->
            assertEquals(0x474D4B41, input.readInt())
            val frames = input.readInt()
            assertEquals(432, frames)
            repeat(frames) {
                val boundary = input.readLong()
                val candles = mutableMapOf<String, List<Candle>>()
                repeat(input.readInt()) {
                    val instrument = input.readUTF()
                    candles[instrument] = List(input.readInt()) {
                        Candle(input.readLong(), input.readDouble(), input.readDouble(), input.readDouble(), input.readDouble(), input.readDouble())
                    }
                }
                val oldCandles = candles.mapValues { (_, rows) -> rows.map { OriginalCandle(it.timeEpochMs, it.open, it.high, it.low, it.close, it.volume) } }
                val entry = Instant.ofEpochSecond(boundary).atZone(ZoneId.of("Asia/Tokyo"))
                val before = original.scan(oldCandles, "AUTO", entry.minusSeconds(10), entry)
                val after = engine.scan(candles, "AUTO", entry.minusSeconds(10), entry)
                assertEquals(before.atJst, after.atJst)
                assertEquals(before.entryTimeJst, after.entryTimeJst)
                assertEquals(before.judgeTimeJst, after.judgeTimeJst)
                assertEquals(before.source, after.source)
                assertEquals(before.policyVersion, after.policyVersion)
                assertEquals(before.warnings, after.warnings)
                assertEquals(before.candidates.size, after.candidates.size)
                if (after.top1 == null) empty++ else {
                    val top = after.top1!!
                    if (top.decision == "ENTRY") entries++
                    grades[top.grade] = grades.getOrDefault(top.grade, 0) + 1
                    top.assessment!!.skipReason?.let { reasons[it] = reasons.getOrDefault(it, 0) + 1 }
                }
                before.candidates.zip(after.candidates).forEach { (a, c) ->
                    candidateCount++
                    assertEquals(a.rank, c.rank)
                    assertEquals(a.instrument, c.instrument)
                    assertEquals(a.display, c.display)
                    assertEquals(a.direction, c.direction)
                    assertEquals(a.grade, c.grade)
                    assertEquals(a.probability, c.probability)
                    assertEquals(a.decision, c.decision)
                    assertEquals(a.score, c.score, 0.0)
                    assertEquals(a.regime, c.regime)
                    assertEquals(a.regimeConfidence, c.regimeConfidence, 0.0)
                    assertEquals(a.reasons, c.reasons)
                    val metadata = c.assessment!!
                    assertEquals(c.grade, metadata.operationalGrade)
                    assertEquals(c.decision, metadata.decision)
                    assertEquals(c.instrument, metadata.chosenAction.instrument)
                    assertEquals(c.direction, metadata.chosenAction.direction)
                    assertEquals(c.grade, metadata.chosenAction.operationalGrade)
                    assertEquals(c.decision, metadata.chosenAction.decision)
                    assertEquals(3, metadata.chosenAction.judgeMinutes)
                    assertEquals("UNVALIDATED", metadata.strengthStatus)
                    assertEquals("検証待ち", c.strengthLabel)
                    if (c.decision == "ENTRY") assertNull(metadata.skipReason) else assertNotNull(metadata.skipReason)
                }
            }
            assertEquals(-1, input.read())
        }
        assertEquals(78, empty)
        assertEquals(307, entries)
        assertEquals(1416, candidateCount)
        assertEquals(mapOf("A" to 6, "B" to 94, "C" to 207, "E" to 47), grades)
        assertEquals(mapOf(CandidateSkipReason.AI_GATE_REJECTED to 7,
            CandidateSkipReason.REMAP_RESCUE_REJECTED to 12,
            CandidateSkipReason.UNMATCHED_RESCUE_FAILED to 28), reasons)
    }
}

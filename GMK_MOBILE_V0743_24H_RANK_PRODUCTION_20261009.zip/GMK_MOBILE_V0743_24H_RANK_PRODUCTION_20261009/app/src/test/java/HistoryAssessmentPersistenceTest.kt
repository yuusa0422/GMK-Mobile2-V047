import android.content.Context
import jp.gmk.mobile.data.AssessmentJsonCodec
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.domain.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26])
class HistoryAssessmentPersistenceTest {
    private val app get() = RuntimeEnvironment.getApplication()
    private val stores = mutableListOf<HistoryStore>()
    private val entryAt = "2026-10-09T09:05:00+09:00"
    private val judgeAt = "2026-10-09T09:08:00+09:00"

    @Before fun clearPreferences() {
        listOf("gmk_mobile_history", "gmk_mobile_history_journal").forEach {
            app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
    }

    @After fun flushWriters() = stores.forEach(::drain)
    private fun store() = HistoryStore(app).also { stores += it }
    private fun drain(s: HistoryStore) {
        val deadline = System.nanoTime() + 3_000_000_000L
        while ((s.diagnosticStats().getBoolean("write_pending") || s.diagnosticStats().getBoolean("writer_active")) && System.nanoTime() < deadline) Thread.sleep(5)
        assertFalse("History snapshot must finish writing", s.diagnosticStats().getBoolean("writer_active"))
        assertFalse("History snapshot must not remain pending", s.diagnosticStats().getBoolean("write_pending"))
    }

    private fun oldRow(scanId: String = "old-complete") = JSONObject()
        .put("id", 1791504300000L).put("scan_id", scanId).put("source", "AUTO")
        .put("at_jst", "2026-10-09T09:04:50+09:00").put("policy_version", "ORIGINAL_POLICY")
        .put("instrument", "USDJPY").put("direction", "HIGH").put("grade", "C").put("decision", "ENTRY")
        .put("candidate_rank", 1).put("regime", "TREND_UP").put("entry_time_jst", entryAt).put("judge_time_jst", judgeAt)
        .put("entry_rate", 150.01).put("judge_rate", 150.02).put("entry_rate_source", "old-entry-provider")
        .put("judge_rate_source", "old-judge-provider").put("entry_captured_at_jst", entryAt).put("settled_at_jst", judgeAt)
        .put("entry_capture_delay_ms", 17L).put("judge_capture_delay_ms", 19L)
        .put("entry_provider_age_seconds", 0.2).put("judge_provider_age_seconds", 0.3).put("result_status", "WIN")

    private fun setRows(vararg rows: JSONObject) {
        val array = JSONArray(); rows.forEach { array.put(it) }
        app.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE).edit().putString("items", array.toString()).commit()
    }

    private fun trace(instrument: String = "USDJPY", direction: String = "HIGH", grade: String = "E",
        decision: String = "SKIP", minutes: Int = 3) = CandidateActionTrace(instrument, direction, "B", 12, 12, grade, decision, minutes)

    private fun assessment(reason: CandidateSkipReason = CandidateSkipReason.AI_GATE_REJECTED): CandidateAssessment {
        val action = trace()
        return CandidateAssessment("B", 12, 12, "E", "SKIP", RuleSelectionStage.REMAPPED, reason,
            0.529, 0.61, 120, action, action)
    }

    private fun scan(id: String, a: CandidateAssessment, minutes: Int = 3): ScanResult {
        val action = a.chosenAction
        return ScanResult(id, "2026-10-09T09:04:50+09:00", entryAt,
            java.time.ZonedDateTime.parse(entryAt).plusMinutes(minutes.toLong()).toString(),
            listOf(ScanCandidate(1, action.instrument, action.instrument, action.direction, action.operationalGrade,
                null, action.decision, assessment = a)), source = "AUTO", policyVersion = "NATIVE_POLICY_UNCHANGED")
    }

    @Test fun oldOutcomeRoundTripsWithoutInventingAReasonStrengthOrProbability() {
        val old = oldRow(); setRows(old)
        val s = store(); val before = s.load().single()
        assertNull(before.assessment)
        assertEquals("未記録", before.legacyRuleGrade)
        assertEquals("検証待ち", before.strengthLabel)
        assertEquals("過去ルール統計: 未記録", before.historicalRateLabel)
        s.add(scan("new-skip", assessment()).copy(source = "MANUAL"))
        drain(s)
        val after = store().load().single { it.scanId == "old-complete" }
        assertEquals("Existing identity, actual trade and settled outcome must be unchanged", before, after)
        val stats = historyStatistics(listOf(after)).getValue(3)
        assertEquals(1, stats.wins); assertEquals(0, stats.losses)
        val saved = JSONArray(app.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE).getString("items", "[]"))
        val savedOld = (0 until saved.length()).map { saved.getJSONObject(it) }.single { it.getString("scan_id") == "old-complete" }
        old.keys().forEach { key -> assertEquals("Historical field $key", old.get(key).toString(), savedOld.get(key).toString()) }
        assertTrue(savedOld.isNull("assessment"))
    }

    @Test fun eachSkipReasonSurvivesThePrimarySnapshotAndRemainsExcludedFromOutcomeCounts() {
        val reasons = listOf(CandidateSkipReason.AI_GATE_REJECTED, CandidateSkipReason.REMAP_RESCUE_REJECTED,
            CandidateSkipReason.UNMATCHED_RESCUE_FAILED, CandidateSkipReason.QUOTE_UNSAFE, CandidateSkipReason.TIME_WINDOW)
        val s = store()
        reasons.forEachIndexed { i, reason ->
            // Different MANUAL scan IDs may share a boundary; AUTO identity intentionally deduplicates it.
            s.add(scan("reason-$i", assessment(reason)).copy(source = "MANUAL"))
        }
        drain(s)
        val reloaded = store().load()
        assertEquals(reasons.size, reloaded.size)
        reasons.forEachIndexed { i, reason ->
            val row = reloaded.single { it.scanId == "reason-$i" }
            assertEquals(assessment(reason), row.assessment)
            assertEquals(reason.label, row.skipReasonLabel)
            assertEquals("UNVALIDATED", row.assessment!!.strengthStatus)
            assertEquals("SKIP", row.resultStatus)
        }
        assertTrue(s.pending().isEmpty())
        assertEquals(0, historyStatistics(reloaded).values.sumOf { it.wins + it.losses })
    }

    @Test fun aCRerouteStoresThreeDifferentActionsWithoutSettlingTheOriginalOrSourceInstead() {
        val original = trace("GBPJPY", "HIGH", "E", "SKIP", 3)
        val chosen = original.copy(direction = "LOW", operationalGrade = "C", decision = "ENTRY", judgeMinutes = 5)
        val source = trace("USDJPY", "HIGH", "C", "ENTRY", 3).copy(
            legacyRuleGrade = "A", legacyRuleId = 456, operationalRuleId = 20456)
        val a = CandidateAssessment("B", 12, 12, "C", "ENTRY", RuleSelectionStage.LEGACY_BASE, null,
            null, 0.61, 120, original, chosen, source, "類似100件のC補正")
        val s = store(); val r = scan("rerouted-five", a, 5)
        s.add(r)
        s.updateEntryRate(r.scanId, 190.0, "entry-provider", entryAt, 0, 0.0)
        s.settle(r.scanId, 189.9, "judge-provider", r.judgeTimeJst, 0, 0.0)
        drain(s)
        val saved = store().load().single()
        assertEquals("GBPJPY", saved.instrument); assertEquals("LOW", saved.direction)
        assertEquals("C", saved.grade); assertEquals("ENTRY", saved.decision); assertEquals("WIN", saved.resultStatus)
        assertEquals(a, saved.assessment)
        assertEquals(original, saved.assessment!!.originalAction)
        assertEquals(chosen, saved.assessment!!.chosenAction)
        assertEquals(source, saved.assessment!!.correctionSourceAction)
        assertEquals(1, historyStatistics(listOf(saved)).getValue(5).wins)
        assertEquals("UNVALIDATED", saved.assessment!!.strengthStatus)
    }

    @Test fun fabricatedStrengthIsIgnoredAndMissingOrUnknownSkipReasonsBecomeUnknown() {
        val payload = AssessmentJsonCodec.encode(assessment())!!
            .put("strength_status", "VALIDATED").put("strength_rank", "S").put("strength_probability", 0.99)
            .put("skip_reason", "SURE_WIN")
        val decoded = AssessmentJsonCodec.decode(payload)!!
        assertEquals("UNVALIDATED", decoded.strengthStatus)
        assertEquals(CandidateSkipReason.UNKNOWN, decoded.skipReason)
        assertEquals("UNVALIDATED", AssessmentJsonCodec.encode(decoded)!!.getString("strength_status"))
        payload.remove("skip_reason")
        assertEquals(CandidateSkipReason.UNKNOWN, AssessmentJsonCodec.decode(payload)!!.skipReason)
    }

    @Test fun malformedEnumSchemaTraceAndConflictingChosenActionNeverEraseOrRewriteTheTrade() {
        val entryTrace = trace(grade = "C", decision = "ENTRY")
        val valid = CandidateAssessment("B", 12, 12, "C", "ENTRY", RuleSelectionStage.REMAPPED, null,
            0.6, 0.61, 120, entryTrace, entryTrace)
        val changes: List<(JSONObject) -> Unit> = listOf(
            { it.put("selection_stage", "UNKNOWN_NEW_STAGE") },
            { it.remove("selection_stage") },
            { it.put("schema_version", 999) },
            { it.put("original_action", "broken") },
            { it.getJSONObject("chosen_action").put("direction", "LOW") },
            { it.getJSONObject("chosen_action").put("judge_minutes", 5) },
            { it.getJSONObject("original_action").put("instrument", "EURJPY") },
            { it.getJSONObject("original_action").put("legacy_rule_grade", "A") },
            { it.getJSONObject("original_action").put("legacy_rule_id", 13) },
            { it.getJSONObject("original_action").put("operational_rule_id", 13) },
            { it.getJSONObject("chosen_action").put("legacy_rule_id", 13) },
            { it.getJSONObject("chosen_action").put("operational_rule_id", 13) },
            { it.put("legacy_rule_id", 13) },
            { it.put("operational_rule_id", 13) },
            { it.getJSONObject("original_action").put("legacy_rule_id", JSONObject.NULL) },
            { it.remove("legacy_rule_id") }
        )
        val rows = changes.mapIndexed { i, change ->
            val json = AssessmentJsonCodec.encode(valid)!!; change(json)
            oldRow("malformed-$i").put("assessment", json)
        }
        setRows(*rows.toTypedArray())
        val loaded = store().load()
        assertEquals(rows.size, loaded.size)
        loaded.forEach {
            assertEquals("USDJPY", it.instrument); assertEquals("HIGH", it.direction)
            assertEquals("C", it.grade); assertEquals("ENTRY", it.decision); assertEquals("WIN", it.resultStatus)
            assertEquals(150.01, it.entryRate!!, 0.0); assertEquals(150.02, it.judgeRate!!, 0.0)
            assertNull(it.assessment); assertEquals("検証待ち", it.strengthLabel)
        }
        assertEquals(rows.size, historyStatistics(loaded).getValue(3).wins)
    }
}

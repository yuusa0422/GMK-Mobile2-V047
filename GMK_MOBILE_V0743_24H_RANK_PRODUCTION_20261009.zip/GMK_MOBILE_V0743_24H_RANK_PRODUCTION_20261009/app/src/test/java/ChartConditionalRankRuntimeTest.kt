import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.october.*
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HorizonRuntime
import jp.gmk.mobile.data.MarketRepository
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.*
import java.time.*
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.zip.GZIPInputStream

/** Real full-bank/query parity plus production annotation guards. Scripted native
 * E inputs below test transport only; their prices are observed fixture OHLC and
 * their outcomes are never used as model input or claimed as trading performance. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26])
class ChartConditionalRankRuntimeTest {
    companion object {
        private val root = File(requireNotNull(System.getProperty("gmk.projectRoot")))
        private val model by lazy {
            ChartConditionalRankCatalog.loadIndex { path -> File(root,"app/src/main/assets/$path").readBytes() }
        }
        private val observed by lazy { RuleAiObservedFixture.at(0,1) }
        private val boundary get() = observed.boundary
        private val frame by lazy {
            ChartConditionalRankAdapter(model) { (boundary-20)*1000 }.prepare(observed.prices,boundary,5000)
        }
    }
    private fun native(symbol: String="USDJPY", direction: String="HIGH", grade: String="E",
                       decision: String="SKIP", source: String="AUTO", minutes: Int=3): ScanResult {
        val at=Instant.ofEpochSecond(boundary).atZone(ZoneId.of("Asia/Tokyo"))
        val trace=CandidateActionTrace(symbol,direction,"B",12,12,grade,decision,minutes)
        val assessment=CandidateAssessment("B",12,12,grade,decision,RuleSelectionStage.REMAPPED,
            if(decision=="SKIP")CandidateSkipReason.AI_GATE_REJECTED else null,.52,.61,120,trace,trace)
        return ScanResult("chart-rank-functional-$symbol-$direction-$grade",at.minusSeconds(10).toString(),at.toString(),
            at.plusMinutes(minutes.toLong()).toString(),listOf(ScanCandidate(1,symbol,symbol,direction,grade,null,decision,
                score=.42,reasons=listOf("Original native guard fixture"),assessment=assessment)),source=source,
            policyVersion="ORIGINAL_OPERATIONAL_POLICY")
    }
    private fun operational(result: ScanResult): List<Any?> = listOf(result.scanId,result.atJst,result.entryTimeJst,
        result.judgeTimeJst,result.source,result.policyVersion,result.warnings,result.candidates.map {
            listOf(it.rank,it.instrument,it.direction,it.decision,it.probability,it.score,it.regime,it.regimeConfidence,it.reasons)
        })
    private fun adapter(clock: AtomicLong=AtomicLong((boundary-5)*1000)) = ChartConditionalRankAdapter(model,clock::get)
    private fun assertHeld(result: ScanResult,original: ScanResult,reason: String) {
        assertEquals(operational(original),operational(result))
        assertEquals("E",result.top1!!.grade)
        assertEquals("UNRANKED",result.top1!!.assessment!!.chartRank!!.grade)
        assertEquals(reason,result.top1!!.assessment!!.chartRank!!.statusReason)
        assertEquals(0,result.top1!!.assessment!!.chartRank!!.supportN)
        assertNull(result.top1!!.assessment!!.chartRank!!.calibratedProbability)
    }

    @Test fun independentAll47QueriesProduceEveryRankIncludingH() {
        val counts=linkedMapOf<String,Int>()
        DataInputStream(BufferedInputStream(File(root,"tools/chart_rank_independent/queries47.bin").inputStream())).use { input ->
            assertEquals(0x43495251,input.readInt());val count=input.readInt();assertEquals(47,count)
            repeat(count) {
                val name=ByteArray(input.readInt());input.readFully(name)
                val b=input.readLong();val symbol=input.readInt();val direction=if(input.readInt()==1)"HIGH" else "LOW"
                val x=FloatArray(35) { input.readFloat() };val result=model.predict(b,symbol,direction,x,0)
                assertEquals(200,result.supportN);assertTrue(result.chartSupport);assertTrue(result.referenceDates>50)
                assertEquals(ChartConditionalRankIndex.SNAPSHOT_UTC,result.snapshotUtc)
                assertEquals(symbol,result.querySymbolIndex)
                assertEquals(ChartConditionalRankIndex.chartFeatureHash(x),result.queryChartFeaturesFloat32Sha256)
                assertTrue(result.maxNeighborAvailableUtc<result.snapshotUtc)
                counts[result.rank]=(counts[result.rank] ?: 0)+1
            }
            assertEquals(-1,input.read())
        }
        assertEquals(mapOf("E" to 1,"F" to 11,"G" to 27,"H" to 6,"UNRANKED" to 2),counts)
    }

    @Test fun all432ActualNativeFramesCarryThe47ChartRanksWithoutChangingEntryOrExpiry() {
        val queries=linkedMapOf<String,FloatArray>()
        DataInputStream(BufferedInputStream(File(root,"tools/chart_rank_independent/queries47.bin").inputStream())).use { input ->
            assertEquals(0x43495251,input.readInt())
            repeat(input.readInt()) {
                val name=ByteArray(input.readInt());input.readFully(name)
                input.readLong();input.readInt();input.readInt()
                queries[String(name,Charsets.UTF_8)]=FloatArray(35) { input.readFloat() }
            }
            assertEquals(-1,input.read())
        }
        val stream=javaClass.classLoader!!.getResourceAsStream("rank_assessment_native_october.bin.gz")
        assertNotNull("Missing actual native candle fixture",stream)
        val engine=LocalRuleEngine();val grades=linkedMapOf<String,Int>();var entriesBefore=0;var entriesAfter=0;var empty=0
        DataInputStream(BufferedInputStream(GZIPInputStream(stream!!))).use { input ->
            assertEquals(0x474D4B41,input.readInt());assertEquals(432,input.readInt())
            repeat(432) {
                val b=input.readLong();val candles=linkedMapOf<String,List<Candle>>()
                repeat(input.readInt()) {
                    val symbol=input.readUTF()
                    candles[symbol]=List(input.readInt()) {
                        Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble())
                    }
                }
                val entry=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
                val original=engine.scan(candles,"AUTO",entry.minusSeconds(10),entry)
                if(original.top1==null)empty++
                if(original.top1?.decision=="ENTRY")entriesBefore++
                val a=ChartConditionalRankAdapter(model) { (b-5)*1000 }
                val top=original.top1
                val actualFrame=if(top?.grade=="E") {
                    assertEquals("SKIP",top.decision)
                    val x=OctoberSimilarityScanAdapter.features(candles.getValue(top.instrument),b)!!
                    val caseId="${top.instrument}:$b"
                    assertArrayEquals("Every native-E TECH35 must match the independently frozen query $caseId",queries.getValue(caseId),x,0f)
                    val prediction=model.predict(b,ChartConditionalRankIndex.symbolIndex(top.instrument),top.direction,x,0)
                    ChartConditionalRankFrame(b,(b-20)*1000,mapOf(top.instrument to x),
                        mapOf("${top.instrument}:${top.direction}" to prediction),emptyMap())
                } else null
                val result=a.apply(original,original,candles,actualFrame)
                assertEquals(operational(original),operational(result))
                if(result.top1?.decision=="ENTRY")entriesAfter++
                if(top?.grade=="E") {
                    val evidence=result.top1!!.assessment!!.chartRank!!
                    assertEquals("E",result.top1!!.assessment!!.originalAction.operationalGrade)
                    assertEquals(original.top1!!.assessment!!.originalAction,result.top1!!.assessment!!.originalAction)
                    assertEquals("SKIP",result.top1!!.decision)
                    assertEquals(200,evidence.supportN)
                    assertEquals(if(evidence.grade=="UNRANKED")"E" else evidence.grade,result.top1!!.grade)
                    grades[evidence.grade]=(grades[evidence.grade] ?: 0)+1
                } else assertEquals(original,result)
            }
            assertEquals(-1,input.read())
        }
        assertEquals(78,empty);assertEquals(307,entriesBefore);assertEquals(entriesBefore,entriesAfter)
        assertEquals(mapOf("E" to 1,"F" to 11,"G" to 27,"H" to 6,"UNRANKED" to 2),grades)
        File(root,"release_evidence/v0742/CHART_RANK_ACTUAL_432_NATIVE_FRAME_AUDIT.json").apply {
            parentFile!!.mkdirs()
        }.writeText("{\"status\":\"PASS\",\"actual_native_frames\":432,\"empty_frames\":78,\"native_entries_before\":307,"+
            "\"entries_after\":307,\"actual_native_E_queries\":47,\"TECH35_values_exact\":1645,"+
            "\"rank_counts\":{\"E\":1,\"F\":11,\"G\":27,\"H\":6,\"UNRANKED\":2},"+
            "\"operational_actions_directions_order_expiry_identity_unchanged\":true,\"current_outcomes_used_as_features\":false}\n")
    }

    @Test fun publishedHSurvivesCommitRetryManualInterleaveAndInputRevisionRecovery() {
        var chosen: Triple<ScanResult,Map<String,List<Candle>>,ChartConditionalRankFrame>?=null
        val stream=javaClass.classLoader!!.getResourceAsStream("rank_assessment_native_october.bin.gz")!!
        val engine=LocalRuleEngine()
        DataInputStream(BufferedInputStream(GZIPInputStream(stream))).use { input ->
            assertEquals(0x474D4B41,input.readInt())
            repeat(input.readInt()) {
                val b=input.readLong();val prices=linkedMapOf<String,List<Candle>>()
                repeat(input.readInt()) {
                    val symbol=input.readUTF();prices[symbol]=List(input.readInt()) {
                        Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble())
                    }
                }
                if(chosen==null) {
                    val at=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
                    val original=engine.scan(prices,"AUTO",at.minusSeconds(10),at);val top=original.top1
                    if(top?.grade=="E") {
                        val x=OctoberSimilarityScanAdapter.features(prices.getValue(top.instrument),b)!!
                        val prediction=model.predict(b,ChartConditionalRankIndex.symbolIndex(top.instrument),top.direction,x,0)
                        if(prediction.rank=="H")chosen=Triple(original,prices,ChartConditionalRankFrame(b,(b-20)*1000,
                            mapOf(top.instrument to x),mapOf("${top.instrument}:${top.direction}" to prediction),emptyMap()))
                    }
                }
            }
            assertEquals(-1,input.read())
        }
        val (original,prices,prepared)=requireNotNull(chosen)
        val app: android.app.Application=RuntimeEnvironment.getApplication()
        val clock={ (prepared.boundary-5)*1000 }
        val runtime=HorizonRuntime(app,MarketRepository(AppPrefs(app)),epochMillis=clock)
        HorizonRuntime::class.java.getDeclaredField("chartRank").apply { isAccessible=true }
            .set(runtime,ChartConditionalRankAdapter(model,clock))
        @Suppress("UNCHECKED_CAST")
        val pending=HorizonRuntime::class.java.getDeclaredField("preparedChartRank").apply { isAccessible=true }
            .get(runtime) as AtomicReference<ChartConditionalRankFrame?>
        pending.set(prepared)
        try {
            val first=runtime.apply(original,prices)
            assertEquals("H",first.top1!!.grade);assertEquals("H",first.top1!!.assessment!!.chartRank!!.grade)
            assertEquals("SKIP",first.top1!!.decision);assertSame(prepared,pending.get())
            runtime.commit(first.scanId)
            assertEquals(first,runtime.apply(original,prices))
            val manual=original.copy(source="MANUAL")
            val manualResult=runtime.apply(manual,prices)
            assertEquals(operational(manual),operational(manualResult))
            assertEquals("H",manualResult.top1!!.grade);assertSame(prepared,pending.get())
            assertEquals(first,runtime.apply(original,prices))
            runtime.discardPending();assertEquals(first,runtime.apply(original,prices))
            val instrument=original.top1!!.instrument;val revised=prices.getValue(instrument).map { c ->
                if(c.timeEpochMs==(prepared.boundary-120)*1000)c.copy(high=c.high+.1) else c
            }
            val held=runtime.apply(original,prices+mapOf(instrument to revised))
            assertEquals("E",held.top1!!.grade)
            assertEquals("UNRANKED",held.top1!!.assessment!!.chartRank!!.grade)
            assertEquals("CHART_INPUT_REVISED",held.top1!!.assessment!!.chartRank!!.statusReason)
            assertSame(prepared,pending.get())
            assertEquals(first,runtime.apply(original,prices))
        } finally { runtime.stop() }
        assertNull(pending.get())
    }

    @Test fun observedM1PreparationAndNativeESkipTransportPreserveOperationalAction() {
        assertEquals(8,frame.predictions.size)
        assertTrue(frame.features.keys.containsAll(ChartConditionalRankIndex.SYMBOLS.toList()))
        for(symbol in ChartConditionalRankIndex.SYMBOLS) for(direction in listOf("HIGH","LOW")) {
            val original=native(symbol,direction);val result=adapter().apply(original,original,observed.prices,frame)
            val evidence=result.top1!!.assessment!!.chartRank!!
            assertEquals(operational(original),operational(result))
            assertEquals("E",result.top1!!.assessment!!.originalAction.operationalGrade)
            assertEquals("SKIP",result.top1!!.decision)
            assertEquals(frame.predictions.getValue("$symbol:$direction").rank,evidence.grade)
            assertEquals(200,evidence.supportN)
            assertEquals("UNVALIDATED",result.top1!!.assessment!!.strengthStatus)
        }
    }

    @Test fun missingLateRevisedAndWrongBoundaryFramesKeepTheNativeSkip() {
        val original=native();val a=adapter()
        val onDemand=a.apply(original,original,observed.prices,null)
        assertEquals(operational(original),operational(onDemand))
        assertEquals(frame.predictions.getValue("USDJPY:HIGH").rank,onDemand.top1!!.assessment!!.chartRank!!.grade)
        assertHeld(a.apply(original,original,observed.prices,frame.copy(preparedMs=(boundary-9)*1000)),original,"FRAME_NOT_READY")
        assertHeld(a.apply(original,original,observed.prices,frame.copy(boundary=boundary+300)),original,"FRAME_NOT_READY")
        val missing=observed.prices+mapOf("USDJPY" to observed.prices.getValue("USDJPY").filterNot {
            it.timeEpochMs==(boundary-120)*1000
        })
        assertHeld(a.apply(original,original,missing,frame),original,"MISSING_CONTIGUOUS_61_M1_BARS")
        val prices=observed.prices.getValue("USDJPY").toMutableList()
        val index=prices.indexOfLast { it.timeEpochMs==(boundary-120)*1000 }
        val bar=prices[index];prices[index]=bar.copy(high=bar.high+.1)
        val revised=observed.prices+mapOf("USDJPY" to prices)
        assertHeld(a.apply(original,original,revised,frame),original,"CHART_INPUT_REVISED")
    }

    @Test fun allOtherEntryGradesAndSourcesRetainTheirSelectedCandidates() {
        for(grade in listOf("S","A","B","C")) {
            val original=native(grade=grade,decision="ENTRY")
            assertEquals(original,adapter().apply(original,original,observed.prices,frame))
        }
        for(source in listOf("AUTO_1M","MANUAL_1M")) {
            val original=native(source=source)
            assertEquals(original,adapter().apply(original,original,observed.prices,frame))
        }
        val original=native();val selected=original.copy(candidates=original.candidates.map { it.copy(direction="LOW") })
        assertEquals(selected,adapter().apply(original,selected,observed.prices,frame))
    }

    @Test fun wrongCurrencyAndWrongFeatureResultsCannotMasqueradeAsTheCurrentQuery() {
        val original=native();val a=adapter()
        val wrongCurrency=frame.copy(predictions=frame.predictions+mapOf("USDJPY:HIGH" to frame.predictions.getValue("EURJPY:HIGH")))
        assertHeld(a.apply(original,original,observed.prices,wrongCurrency),original,"FRAME_IDENTITY_MISMATCH")
        val different=frame.features.getValue("USDJPY").copyOf();different[0]+=.04f
        val wrongFeature=model.predict(boundary,0,"HIGH",different,0)
        val wrongChart=frame.copy(predictions=frame.predictions+mapOf("USDJPY:HIGH" to wrongFeature))
        assertHeld(a.apply(original,original,observed.prices,wrongChart),original,"FRAME_IDENTITY_MISMATCH")
    }

    @Test fun unsupportedSessionCurrencyAndExpiryAreHeldWithoutInventedSupport() {
        assertTrue(ChartConditionalRankAdapter.supports(ZonedDateTime.parse("2026-10-09T15:00:00+09:00").toEpochSecond()))
        assertFalse(ChartConditionalRankAdapter.originalResearchScope(ZonedDateTime.parse("2026-10-09T15:00:00+09:00").toEpochSecond()))
        assertTrue(ChartConditionalRankAdapter.supports(ZonedDateTime.parse("2026-10-10T12:00:00+09:00").toEpochSecond()))
        assertFalse(ChartConditionalRankAdapter.originalResearchScope(ZonedDateTime.parse("2026-10-10T12:00:00+09:00").toEpochSecond()))
        assertFalse(ChartConditionalRankAdapter.supports(ZonedDateTime.parse("2026-11-02T12:00:00+09:00").toEpochSecond()))
        assertTrue(ChartConditionalRankAdapter.supports(ZonedDateTime.parse("2026-10-09T09:00:00+09:00").toEpochSecond()))
        val btc=native(symbol="BTCJPY")
        assertHeld(adapter().apply(btc,btc,observed.prices,frame),btc,"UNSUPPORTED_SAME_CURRENCY_BANK:BTCJPY")
        val five=native(minutes=5)
        assertHeld(adapter().apply(five,five,observed.prices,frame),five,"UNSUPPORTED_JUDGE_HORIZON")
    }

    @Test fun publishDeadlineHoldsTheRankAndACompleteLaterAttemptStillWorks() {
        val original=native();val clock=AtomicLong(boundary*1000-799);val a=adapter(clock)
        assertHeld(a.apply(original,original,observed.prices,frame),original,"PUBLISH_DEADLINE")
        clock.set((boundary-5)*1000)
        val completed=a.apply(original,original,observed.prices,frame)
        assertEquals(frame.predictions.getValue("USDJPY:HIGH").rank,completed.top1!!.assessment!!.chartRank!!.grade)
        assertEquals(operational(original),operational(completed))
    }

    @Test fun absentDataAndAnUnavailableModelNeverManufactureReferencesOrStrength() {
        val a=ChartConditionalRankAdapter(null) { (boundary-20)*1000 }
        val unavailable=a.prepare(emptyMap(),boundary)
        assertTrue(unavailable.predictions.isEmpty());assertTrue(unavailable.features.isEmpty())
        val original=native()
        assertHeld(a.apply(original,original,observed.prices,unavailable),original,"CHART_INPUT_REVISED")
        val budgeted=adapter().prepare(observed.prices,boundary,1)
        // An interrupted query cannot publish a partially populated neighbour set.
        budgeted.predictions.values.forEach { assertEquals(200,it.supportN) }
        assertTrue(budgeted.unavailable.values.all { it=="PREPARE_DEADLINE" || it.startsWith("MISSING_") })
    }

    @Test fun lazyCorruptAndMissingChunksCloseStreamsWithoutOpeningUntouchedParts() {
        val requested=mutableListOf<String>()
        try {
            ChartConditionalRankCatalog.loadIndex { path -> requested+=path;byteArrayOf(0,1,2,3) }
            fail("Invalid chart rank gzip was accepted")
        } catch(_: IOException) { }
        assertEquals(listOf("october_chart_rank/index.bin.gz.part01"),requested)
        requested.clear()
        try {
            ChartConditionalRankCatalog.loadIndex { path ->
                requested+=path
                if(path.endsWith("part02"))throw IOException("Missing chart rank part")
                File(root,"app/src/main/assets/$path").readBytes()
            }
            fail("Missing second chart rank part was accepted")
        } catch(_: IOException) { }
        assertEquals(listOf("october_chart_rank/index.bin.gz.part01","october_chart_rank/index.bin.gz.part02"),requested)
    }
}

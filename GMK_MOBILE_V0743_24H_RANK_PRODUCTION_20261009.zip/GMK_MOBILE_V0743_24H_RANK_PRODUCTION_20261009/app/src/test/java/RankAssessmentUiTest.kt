import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performSemanticsAction
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import jp.gmk.mobile.Top1Card
import jp.gmk.mobile.domain.*
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35], qualifiers="w360dp-h640dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class RankAssessmentUiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    private fun render(fontScale: Float, candidate: ScanCandidate) {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, fontScale)) {
                MaterialTheme { Box(Modifier.size(360.dp, 600.dp)) { Top1Card(candidate, 6, 3) } }
            }
        }
        compose.onNodeWithText("RULE", substring=true).assertDoesNotExist()
    }

    private fun rejected(): ScanCandidate {
        val base = FinalRankPolicy.Match("B", false, .65, .6, 100, 82, RuleSelectionStage.LEGACY_BASE)
        val policy = base.copy(rank="C", ruleId=10067, selectionStage=RuleSelectionStage.RESCUE_STAGE1)
        return ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "E", .65, "SKIP",
            assessment=CandidateAssessmentFactory.native("USDJPY", "HIGH", base, policy, "E", "SKIP", .52, true))
    }

    private fun verifyGate(fontScale: Float) {
        render(fontScale, rejected())
        compose.onNodeWithText("運用等級 E", substring=true).assertIsDisplayed()
        compose.onNodeWithText("元ルール B • 推定強度: 検証待ち").assertIsDisplayed()
        compose.onNodeWithText("見送り: AIゲート見送り").assertIsDisplayed()
        compose.onNodeWithText("過去ルール統計: 65.0% (n=100)").assertIsDisplayed()
        val layouts=mutableListOf<androidx.compose.ui.text.TextLayoutResult>()
        compose.onNodeWithText("USDJPY",useUnmergedTree=true).performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.GetTextLayoutResult) { it(layouts) }
        val label=layouts.single()
        assertEquals("Instrument must remain one readable label",1,label.lineCount)
        assertTrue("Instrument glyphs must fit",label.getLineRight(0)<=label.size.width && label.getLineLeft(0)>=0f)
        saveScreenshot(if (fontScale > 1f) "rank_large_text.png" else "rank_regular.png")
    }

    @Test fun gateRejectionDisplaysDifferentOriginsAndHistoricalRate() { verifyGate(1f) }
    @Test fun explanationsRemainVisibleOnSmallPhoneWithLargeText() { verifyGate(1.8f) }
    @Test fun legacyCandidateDoesNotInventAReasonOrWinningProbability() {
        render(1f, ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "E", .81, "SKIP"))
        compose.onNodeWithText("元ルール 未記録 • 推定強度: 検証待ち").assertIsDisplayed()
        compose.onNodeWithText("見送り: 旧データ・理由未記録").assertIsDisplayed()
        compose.onNodeWithText("過去ルール統計: 未記録").assertIsDisplayed()
        compose.onNodeWithText("81", substring=true).assertDoesNotExist()
    }

    private fun saveScreenshot(name: String) {
        val root = java.io.File(System.getProperty("gmk.projectRoot"), "release_evidence/v0741/screenshots")
        root.mkdirs()
        lateinit var bitmap: android.graphics.Bitmap
        compose.runOnUiThread {
            val view=compose.activity.window.decorView
            bitmap=android.graphics.Bitmap.createBitmap(view.width,view.height,android.graphics.Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(bitmap))
        }
        java.io.File(root, name).outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it) }
    }
}

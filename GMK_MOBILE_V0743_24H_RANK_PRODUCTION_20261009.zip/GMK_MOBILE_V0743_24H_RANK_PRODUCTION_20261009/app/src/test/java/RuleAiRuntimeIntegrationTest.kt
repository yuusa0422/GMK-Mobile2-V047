import android.app.Application
import android.content.Context
import jp.gmk.mobile.data.*
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.direct19.*
import jp.gmk.mobile.domain.horizon.*
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.io.File
import java.time.*
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/** Drives the production background preparation and public apply/commit/history path.
 * Faults change model bytes at the asset boundary; valid assets and OHLC are real.
 * Quotes are controlled safety fixtures, and no live network is used.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
@LooperMode(LooperMode.Mode.PAUSED)
class RuleAiRuntimeIntegrationTest {
    private lateinit var app:Application
    private val owners=mutableListOf<Pair<HorizonRuntime,Job>>()
    @Before fun setup() {
        app=RuntimeEnvironment.getApplication()
        listOf("gmk_horizon_policy","gmk_mobile_history","gmk_mobile_history_journal")
            .forEach { app.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit() }
        File(app.filesDir,"horizon_history_v1").deleteRecursively()
        File(app.filesDir,"pc_r13_frames_v1.bin").delete()
    }
    @After fun cleanup() {
        owners.forEach { (runtime,owner)->runtime.stop();owner.cancel();runBlocking { owner.join() } }
    }
    private data class Running(val runtime:HorizonRuntime,val clock:AtomicLong,val repository:MarketRepository)
    private fun start(observed:RuleAiObservedFixture.Observed, fault:String?=null, enabled:Boolean=true):Running {
        val at=(observed.boundary-20)*1000
        val cache=HorizonMarketCache(File(app.filesDir,"horizon_history_v1"))
        observed.prices.forEach { (symbol,bars)->cache.merge(symbol,bars,at);cache.persist(symbol) }
        val clock=AtomicLong(at);val repository=MarketRepository(AppPrefs(app))
        val runtime=HorizonRuntime(app,repository,{ path ->
            val bytes=app.assets.open(path).use { it.readBytes() }
            if(path==fault)bytes[20]=(bytes[20].toInt() xor 1).toByte()
            bytes
        },clock::get)
        val owner=SupervisorJob();owners+=runtime to owner
        runtime.start(CoroutineScope(owner+Dispatchers.Default),{enabled},{false})
        return Running(runtime,clock,repository)
    }
    private fun waitFor(message:String,diagnostics:()->String={""},condition:()->Boolean) {
        val end=System.nanoTime()+10_000_000_000L
        while(!condition() && System.nanoTime()<end)Thread.sleep(10)
        assertTrue("$message ${diagnostics()}",condition())
    }
    private fun frame(runtime:HorizonRuntime):Direct19Frame? {
        val field=HorizonRuntime::class.java.getDeclaredField("preparedDirect").apply { isAccessible=true }
        @Suppress("UNCHECKED_CAST")
        return (field.get(runtime) as AtomicReference<Direct19Frame?>).get()
    }
    private fun ready(run:Running) { waitFor("Production background task did not prepare a Direct19 frame") { frame(run.runtime)!=null } }
    private fun capture(run:Running,observed:RuleAiObservedFixture.Observed) {
        run.runtime.observe(RuleAiObservedFixture.quotes(observed).map { (symbol,q)->
            RateRow(symbol,q.price,q.bid,q.ask,"test observed-price safety quote",2.0,"LIVE",sourceEpochMs=q.sourceMs,receivedEpochMs=q.receivedMs)
        })
        run.clock.set((observed.boundary-5)*1000)
    }
    /** R13 keeps its production wall-clock deadline. The evening-only operation
     * fixture must therefore be ahead of that clock; its OHLC geometry stays
     * unchanged. A JVM property shares one selected weekday across SDK sandboxes. */
    private fun futureEveningObserved():RuleAiObservedFixture.Observed {
        val source=RuleAiObservedFixture.at(0,1)
        val key="gmk.v0740.legacyEveningBoundary"
        val boundary=synchronized(System.getProperties()) {
            val now=ZonedDateTime.now(ZoneId.of("Asia/Tokyo"))
            val saved=System.getProperty(key)?.toLongOrNull()?.let { Instant.ofEpochSecond(it).atZone(now.zone) }
            val selected=if(saved!=null && saved.dayOfWeek.value<=5 && saved.toLocalTime()==LocalTime.of(17,55) && saved.isAfter(now.plusHours(6)))saved else {
                var next=now.toLocalDate().plusDays(1).atTime(17,55).atZone(now.zone)
                while(next.dayOfWeek.value>5)next=next.plusDays(1)
                System.setProperty(key,next.toEpochSecond().toString())
                next
            }
            selected.toEpochSecond()
        }
        val delta=(boundary-source.boundary)*1000
        val observed=RuleAiObservedFixture.Observed(boundary,source.prices.mapValues { (_,bars)->
            bars.map { it.copy(timeEpochMs=it.timeEpochMs+delta) }
        })
        File(RuleAiObservedFixture.root,"release_evidence/v0740/LEGACY_EVENING_FIXTURE_API${android.os.Build.VERSION.SDK_INT}.json")
            .apply { parentFile!!.mkdirs() }.writeText(org.json.JSONObject()
                .put("scope","OPERATION_FIXTURE_CLOCK_ONLY_NOT_TRADING_ACCURACY")
                .put("source_boundary_epoch",source.boundary).put("selected_boundary_epoch",boundary)
                .put("selected_boundary_jst",Instant.ofEpochSecond(boundary).atZone(ZoneId.of("Asia/Tokyo")).toString())
                .put("actual_wall_clock_epoch_ms",System.currentTimeMillis()).put("same_jvm_boundary_key",key)
                .put("ohlc_volume_and_bar_intervals_unchanged",true).put("original_r13_deadline_unchanged",true)
                .put("shared_direct19_october8_fixture_unchanged",true).toString(2)+"\n")
        return observed
    }
    @Test fun healthyStartupLoadsActualAssetsAndRestoresAllNineteenHistories() {
        val observed=RuleAiObservedFixture.at(0,1);val run=start(observed,enabled=false)
        waitFor("Healthy startup did not finish") { run.runtime.diagnosticStats().getString("background")=="INACTIVE" }
        val diagnostic=run.runtime.diagnosticStats()
        assertEquals("LOADED",diagnostic.getJSONObject("direct19").getString("load_status"))
        assertEquals("LOADED",diagnostic.getJSONObject("pc_r13").getString("load_status"))
        val cache=HorizonRuntime::class.java.getDeclaredField("cache").apply { isAccessible=true }.get(run.runtime) as HorizonMarketCache
        assertEquals(19,cache.snapshot().size)
        assertTrue(cache.snapshot().values.all { it.size>4000 })
        assertEquals(0L,run.repository.diagnosticStats().getLong("requests"))
        File(RuleAiObservedFixture.root,"release_evidence/v0738_full_audit/RULE_AI_RUNTIME_HEALTH_API${android.os.Build.VERSION.SDK_INT}.json")
            .apply { parentFile!!.mkdirs() }.writeText(diagnostic.toString(2)+"\n")
    }
    @Test fun realScheduledCorrectionAndFiveMinuteOutcomeReachDurableHistory() {
        val observed=RuleAiObservedFixture.at(1,0);val (native,candles)=RuleAiObservedFixture.native(observed)
        assertEquals("C",native.top1!!.grade);assertEquals("ENTRY",native.top1!!.decision)
        val run=start(observed);ready(run);capture(run,observed)
        val result=run.runtime.apply(native,candles)
        assertEquals("APPLIED",run.runtime.diagnosticStats().getJSONObject("direct19").getString("status"))
        assertEquals("GBPJPY",result.top1!!.instrument);assertEquals("LOW",result.top1!!.direction)
        assertEquals(5L,Duration.between(ZonedDateTime.parse(result.entryTimeJst),ZonedDateTime.parse(result.judgeTimeJst)).toMinutes())
        val store=HistoryStore(app);store.add(result);run.runtime.commit(result.scanId);run.runtime.discardPending()
        assertEquals("WAIT_ENTRY",store.pending().single().resultStatus)
        store.updateEntryRate(result.scanId,150.0,"test reference",result.entryTimeJst,0,0.0)
        store.settle(result.scanId,149.0,"test reference",result.judgeTimeJst,0,0.0)
        assertTrue(store.pending().isEmpty())
        waitFor("Final result was not durably saved") { store.diagnosticStats().getLong("persist_success")>0 }
        val restored=HistoryStore(app).load().single()
        assertEquals(result.scanId,restored.scanId);assertEquals(result.top1!!.instrument,restored.instrument)
        assertEquals(result.judgeTimeJst,restored.judgeTimeJst);assertEquals(result.policyVersion,restored.policyVersion)
        assertEquals("WIN",restored.resultStatus)
        assertEquals(0L,run.repository.diagnosticStats().getLong("requests"))
        File(RuleAiObservedFixture.root,"release_evidence/v0738_full_audit/RULE_AI_RUNTIME_APPLIED_API${android.os.Build.VERSION.SDK_INT}.json")
            .apply { parentFile!!.mkdirs() }.writeText(run.runtime.diagnosticStats().toString(2)+"\n")
    }
    @Test fun brokenLegacyModelCannotDisableHealthyDirect19CacheAndCorrection() {
        val observed=RuleAiObservedFixture.at(0,1);val (native,candles)=RuleAiObservedFixture.native(observed)
        val run=start(observed,"horizon_policy/base_3m.bin");ready(run)
        assertTrue("An unrelated legacy model failure must not suppress restored Direct19 price history",frame(run.runtime)!!.input.eligible.all { it })
        capture(run,observed)
        val result=run.runtime.apply(native,candles)
        assertEquals("APPLIED",run.runtime.diagnosticStats().getJSONObject("direct19").getString("status"))
        assertEquals("GBPJPY",result.top1!!.instrument)
        assertEquals("ENTRY",result.top1!!.decision)
    }
    @Test fun corruptDirect19ModelFallsBackToNativeWithoutBreakingLegacyModels() {
        val observed=RuleAiObservedFixture.at(0,1);val (native,candles)=RuleAiObservedFixture.native(observed)
        val run=start(observed,"direct19/hgb_3m.bin",enabled=false)
        waitFor("Corrupt-model startup did not finish") { run.runtime.diagnosticStats().getString("background")=="INACTIVE" }
        capture(run,observed)
        assertTrue(run.runtime.diagnosticStats().getJSONObject("direct19").getString("load_status").startsWith("MODEL_UNAVAILABLE:"))
        assertEquals("LOADED",run.runtime.diagnosticStats().getJSONObject("pc_r13").getString("load_status"))
        val result=run.runtime.apply(native,candles)
        assertEquals(native.candidates,result.candidates);assertEquals(native.judgeTimeJst,result.judgeTimeJst)
        assertEquals(Direct19ScanAdapter.FALLBACK,result.policyVersion)
    }
    @Test fun committedRetryAndProfileSwitchKeepCorrectResultAndDiagnostic() {
        val observed=RuleAiObservedFixture.at(0,1);val (native,candles)=RuleAiObservedFixture.native(observed)
        val run=start(observed);ready(run);capture(run,observed)
        val first=run.runtime.apply(native,candles);run.runtime.commit(first.scanId);run.runtime.discardPending()
        assertEquals(first,run.runtime.apply(native,candles))
        assertTrue("A cached APPLIED result must still report the actual correction",run.runtime.diagnosticStats().getJSONObject("direct19").getBoolean("changed"))
        val fixed=run.runtime.apply(native,candles,true)
        assertEquals(3L,Duration.between(ZonedDateTime.parse(fixed.entryTimeJst),ZonedDateTime.parse(fixed.judgeTimeJst)).toMinutes())
        assertEquals(native.top1!!.decision,fixed.top1!!.decision)
        assertTrue(fixed.policyVersion.endsWith("_3M_FIXED"))
        run.runtime.discardPending()
        val skipped=native.copy(candidates=native.candidates.map { if(it.rank==1)it.copy(grade="E",decision="SKIP") else it })
        assertEquals("SKIP",run.runtime.apply(skipped,candles).top1!!.decision)
    }
    @Test fun eveningLegacyPreparationAndManualIsolationUseTheirActualProductionRoutes() {
        val observed=futureEveningObserved()
        val (native,candles)=RuleAiObservedFixture.native(observed);val run=start(observed)
        waitFor("Evening horizon frame did not prepare", { run.runtime.diagnosticStats().toString() }) { run.runtime.diagnosticStats().getString("background") in setOf("FRAME_READY","FRAME_CONTEXT_WARMING") }
        val quotes=HorizonFeatureService.SYMBOLS.take(6).map { symbol->
            val price=candles.getValue(symbol).last().close
            RateRow(symbol,price,price*.99999,price*1.00001,"test evening safety quote",2.0,"LIVE",sourceEpochMs=(observed.boundary-12)*1000,receivedEpochMs=(observed.boundary-11)*1000)
        }
        run.runtime.observe(quotes);run.clock.set((observed.boundary-5)*1000)
        assertFalse(Direct19ScanAdapter.supports(observed.boundary))
        val result=run.runtime.apply(native,candles)
        assertEquals(native.scanId,result.scanId);assertEquals(native.entryTimeJst,result.entryTimeJst)
        val diagnostic=run.runtime.diagnosticStats()
        assertTrue("policy=${result.policyVersion};diagnostic=$diagnostic",result.policyVersion.startsWith("GMK_V0736_PC_R13"))
        assertFalse(diagnostic.getJSONObject("pc_r13").getString("status").contains("FALLBACK"))
        assertEquals("LOADED",diagnostic.getJSONObject("pc_r13").getString("load_status"))
        for(sourceName in listOf("MANUAL","AUTO_1M")) {
            val manual=native.copy(source=sourceName)
            assertEquals(manual,run.runtime.apply(manual,candles,true))
        }
        File(RuleAiObservedFixture.root,"release_evidence/v0738_full_audit/RULE_AI_RUNTIME_EVENING_API${android.os.Build.VERSION.SDK_INT}.json")
            .apply { parentFile!!.mkdirs() }.writeText(diagnostic.toString(2)+"\n")
        assertEquals(0L,run.repository.diagnosticStats().getLong("requests"))
    }
    @Test fun eveningRetryCannotReturnAnotherNativeScanIdentity() {
        val observed=futureEveningObserved()
        val (native,candles)=RuleAiObservedFixture.native(observed);val run=start(observed)
        waitFor("Evening horizon frame did not prepare", { run.runtime.diagnosticStats().toString() }) { run.runtime.diagnosticStats().getString("background") in setOf("FRAME_READY","FRAME_CONTEXT_WARMING") }
        run.runtime.observe(HorizonFeatureService.SYMBOLS.take(6).map { symbol->
            val price=candles.getValue(symbol).last().close
            RateRow(symbol,price,null,null,"test quote",2.0,"LIVE",sourceEpochMs=(observed.boundary-12)*1000,receivedEpochMs=(observed.boundary-11)*1000)
        })
        run.clock.set((observed.boundary-5)*1000)
        val first=run.runtime.apply(native,candles);run.runtime.commit(first.scanId);run.runtime.discardPending()
        for(id in listOf("new-native-scan",native.scanId)) {
            val revised=native.copy(scanId=id,candidates=native.candidates.map { if(it.rank==1)it.copy(grade="E",decision="SKIP") else it })
            val retried=run.runtime.apply(revised,candles)
            assertEquals("A same-boundary retry must not reuse another scan's signal",revised.scanId,retried.scanId)
            assertEquals(revised.entryTimeJst,retried.entryTimeJst);assertEquals(revised.source,retried.source)
            assertEquals("SKIP",retried.top1!!.decision)
        }
    }
}

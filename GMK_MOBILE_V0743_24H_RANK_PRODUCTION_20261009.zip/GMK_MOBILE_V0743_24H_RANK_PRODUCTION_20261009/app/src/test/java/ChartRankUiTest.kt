import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import jp.gmk.mobile.ChartRankFilterChips
import jp.gmk.mobile.HistoryScreen
import jp.gmk.mobile.Top1Card
import jp.gmk.mobile.domain.*
import org.junit.Rule
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[35], qualifiers="w360dp-h640dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class ChartRankUiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private fun candidate(grade: String = "H"): ScanCandidate {
        val native = CandidateActionTrace("USDJPY", "HIGH", "B", 12, 12, "E", "SKIP", 3)
        val chart = ChartRankAssessment(grade, .42, .4716981132075472, 200, 162, 187.25,
            "SUPPORTED_PAST_CALIBRATION_UNVALIDATED", "2026-10-01T00:00:00+09:00",
            "GMK_V0742_OCTOBER_CHART200_EH", 1791504300L, "HIGH", .441)
        val a = CandidateAssessment("B", 12, 12, grade, "SKIP", RuleSelectionStage.REMAPPED,
            CandidateSkipReason.AI_GATE_REJECTED, .529, .61, 120, native,
            native.copy(operationalGrade = grade), chartRank = chart)
        return ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", grade, null, "SKIP", assessment = a)
    }
    private fun renderTop(fontScale: Float, night: Boolean = false) {
        val base = candidate()
        val row = if (night) base.copy(assessment = base.assessment!!.copy(chartRank = base.assessment.chartRank!!.copy(
            statusReason = "OUTSIDE_ORIGINAL_RESEARCH_SCOPE:PAST_OUTCOME_CALIBRATED_RELATIVE"))) else base
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, fontScale)) {
                MaterialTheme { Box(Modifier.size(360.dp, 600.dp)) { Top1Card(row, 6, 3) } }
            }
        }
        compose.onNodeWithText("運用等級 H", substring=true).assertIsDisplayed()
        compose.onNodeWithText("類似ランク H / 推定 47.2% / 参照200件（強弱未検証）").assertIsDisplayed()
        compose.onNodeWithText("見送り: AIゲート見送り").assertIsDisplayed()
        compose.onNodeWithText("類似履歴 42.0% / 162日参照 / 有効件数 187.3").assertIsDisplayed()
        if (night) {
            saveScreenshot(if (fontScale > 1f) "chart_H_night_large_text.png" else "chart_H_night.png")
            val tree = compose.onRoot(useUnmergedTree = true).printToString()
            java.io.File(System.getProperty("gmk.projectRoot"), "release_evidence/v0743/night_scope_semantics.txt").writeText(tree)
            compose.onNodeWithText("元の検証条件外・参考推定").assertIsDisplayed()
        }
        saveScreenshot(if (night) (if (fontScale > 1f) "chart_H_night_large_text.png" else "chart_H_night.png") else if (fontScale > 1f) "chart_H_large_text.png" else "chart_H_regular.png")
    }
    @Test fun skippedNativeECandidateDisplaysHOnSmallPhone() { renderTop(1f) }
    @Test fun estimatedHAndSkipExplanationRemainVisibleWithLargeText() { renderTop(1.8f) }
    @Test fun nightReferenceScopeDisplaysBesideHOnSmallPhone() { renderTop(1f, true) }
    @Test fun nightReferenceScopeAndHStayVisibleWithLargeText() { renderTop(1.8f, true) }
    @Test fun topCardCanDisplayEveryGradeThroughH() {
        val c = mutableStateOf(candidate("E"))
        compose.setContent { MaterialTheme { Top1Card(c.value, 6, 3) } }
        listOf("E", "F", "G", "H").forEach { grade ->
            compose.runOnIdle { c.value = candidate(grade) }
            compose.onNodeWithText("類似ランク $grade", substring = true).assertIsDisplayed()
            compose.onNodeWithText("SKIP").assertIsDisplayed()
        }
    }
    @Test fun filterAlwaysShowsHAndHoldAtZeroAndAllowsSelection() {
        var selected = ""
        compose.setContent { MaterialTheme { ChartRankFilterChips(emptyList(), "すべて") { selected = it } } }
        compose.onNodeWithTag("chart-rank-filter-H").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals("H", selected) }
        compose.onNodeWithText("保留 (0)").assertIsDisplayed()
        compose.onNodeWithText("未記録 (0)").assertIsDisplayed()
        saveScreenshot("chart_rank_filters_zero.png")
    }
    @Test fun skippedHIsReachableInHistoryAndFilterDoesNotTreatItAsAnEntry() {
        val c = candidate()
        val row = HistoryRow(1, "chart-H", "AUTO", "2026-10-09T09:04:50+09:00", "USDJPY", "HIGH", "H", "SKIP",
            entryTimeJst = "2026-10-09T09:05:00+09:00", judgeTimeJst = "2026-10-09T09:08:00+09:00",
            resultStatus = "SKIP", policyVersion = "GMK_V0742_OCTOBER_CHART200_EH", assessment = c.assessment)
        compose.setContent { MaterialTheme { Box(Modifier.size(360.dp, 520.dp)) { HistoryScreen(listOf(row), true, {}) } } }
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("類似ランク H / 推定", substring = true))
        compose.onNodeWithText("類似ランク H / 推定 47.2% / 参照200件（強弱未検証）").assertIsDisplayed()
        compose.onNodeWithText("見送り: AIゲート見送り").assertIsDisplayed()
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasTestTag("chart-rank-filter-H"))
        compose.onNodeWithTag("chart-rank-filter-H").assertIsDisplayed().performClick()
        saveScreenshot("chart_rank_filter_H_selected.png")
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("類似ランク H / 推定", substring = true))
        compose.onNodeWithText("類似ランク H / 推定 47.2% / 参照200件（強弱未検証）").assertIsDisplayed()
        saveScreenshot("chart_H_history.png")
    }
    private fun saveScreenshot(name: String) {
        val root = java.io.File(System.getProperty("gmk.projectRoot"), "release_evidence/v0743/screenshots")
        root.mkdirs()
        lateinit var bitmap: android.graphics.Bitmap
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            bitmap = android.graphics.Bitmap.createBitmap(view.width, view.height, android.graphics.Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(bitmap))
        }
        java.io.File(root, name).outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,it) }
    }
}

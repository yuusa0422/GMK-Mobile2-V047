import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasScrollToIndexAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.unit.dp
import jp.gmk.mobile.CutInOverlay
import jp.gmk.mobile.HistoryScreen
import jp.gmk.mobile.domain.CutInEventQueue
import jp.gmk.mobile.domain.HistoryRow
import jp.gmk.mobile.ui.GmkUiState
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.time.ZonedDateTime
import java.time.ZoneId

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w360dp-h640dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class HistoryCutInTimingUiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    private fun row(status: String): HistoryRow {
        val judge = ZonedDateTime.now(ZoneId.of("Asia/Tokyo")).minusSeconds(1)
        return HistoryRow(1, "ui-timing", "AUTO", judge.minusMinutes(3).minusSeconds(10).toString(),
            "USDJPY", "HIGH", "C", "ENTRY", entryTimeJst = judge.minusMinutes(3).toString(),
            judgeTimeJst = judge.toString(), entryRate = 150.0,
            judgeRate = if (status == "WIN") 151.0 else null,
            settledAtJst = if (status == "WIN") judge.plusSeconds(1).toString() else "", resultStatus = status)
    }
    @Test fun dueOutcomeShowsProviderWaitInsteadOfAnUnexplainedCountdown() {
        val rows = listOf(row("WAIT_JUDGE"))
        compose.setContent { MaterialTheme { Box(Modifier.size(360.dp, 520.dp)) { HistoryScreen(rows, false, {}) } } }
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("対象分OPEN配信待ち", substring = true))
        compose.onNodeWithText("対象分OPEN配信待ち", substring = true).assertIsDisplayed()
    }
    @Test fun historyStateChangesDoNotCancelOrRepeatAnActiveCutIn() {
        val controller = CutInEventQueue()
        val settled = row("WIN")
        var state by mutableStateOf(GmkUiState(history = listOf(settled)))
        var shown = 0
        compose.setContent {
            MaterialTheme { Box(Modifier.size(360.dp, 520.dp)) {
                CutInOverlay(state, controller, { _, _, _ -> shown++ }, { _, _, _ -> })
            } }
        }
        compose.onNodeWithText("WIN").assertIsDisplayed()
        compose.runOnIdle { state = state.copy(scanStatus = "チャート画面へ切替", lastRateUpdateMs = 10) }
        compose.onNodeWithText("WIN").assertIsDisplayed()
        compose.runOnIdle { assertEquals(1, shown) }
    }
}

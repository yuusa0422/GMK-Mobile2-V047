import android.content.Context
import jp.gmk.mobile.data.AssessmentJsonCodec
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.domain.*
import org.json.JSONObject
import org.json.JSONArray
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26])
class ChartRankAssessmentPersistenceTest {
    private val app get() = RuntimeEnvironment.getApplication()
    private val stores = mutableListOf<HistoryStore>()
    private fun chart(grade: String = "H", direction: String = "HIGH") = ChartRankAssessment(
        grade = grade, rawProbability = .42, calibratedProbability = .4716981132075472,
        supportN = 200, referenceDates = 162, effectiveSampleSize = 187.25,
        statusReason = "SUPPORTED_PAST_CALIBRATION_UNVALIDATED",
        snapshotId = "2026-10-01T00:00:00+09:00", modelVersion = "GMK_V0742_OCTOBER_CHART200_EH",
        queryBoundaryUtc = 1791504300L, direction = direction, shrunkProbability = .441)
    private fun assessment(grade: String = "H", chart: ChartRankAssessment? = chart(grade)): CandidateAssessment {
        val native = CandidateActionTrace("USDJPY", "HIGH", "B", 12, 12, "E", "SKIP", 3)
        val chosen = native.copy(operationalGrade = grade)
        return CandidateAssessment("B", 12, 12, grade, "SKIP", RuleSelectionStage.REMAPPED,
            CandidateSkipReason.AI_GATE_REJECTED, .529, .61, 120, native, chosen, chartRank = chart)
    }
    private fun drain(s: HistoryStore) {
        val deadline = System.nanoTime() + 3_000_000_000L
        while ((s.diagnosticStats().getBoolean("write_pending") || s.diagnosticStats().getBoolean("writer_active")) && System.nanoTime() < deadline) Thread.sleep(5)
        assertFalse("History write must finish", s.diagnosticStats().getBoolean("writer_active"))
        assertFalse("History write must not remain pending", s.diagnosticStats().getBoolean("write_pending"))
    }
    @Before fun clear() {
        listOf("gmk_mobile_history", "gmk_mobile_history_journal").forEach {
            app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit()
        }
    }
    @After fun flush() = stores.forEach(::drain)

    @Test fun allFourGradesKeepNativeEAndExactChartEvidenceAcrossJson() {
        listOf("E", "F", "G", "H").forEach { grade ->
            val a = assessment(grade)
            val json = AssessmentJsonCodec.encode(a)!!
            assertEquals(1, json.getInt("schema_version"))
            assertEquals("DISPLAY_ONLY", json.getJSONObject("chart_rank").getString("usage"))
            val decoded = AssessmentJsonCodec.decode(JSONObject(json.toString()))!!
            assertEquals(a, decoded)
            assertEquals("E", decoded.originalAction.operationalGrade)
            assertEquals(grade, decoded.chosenAction.operationalGrade)
            assertEquals("SKIP", decoded.decision)
            assertEquals("UNVALIDATED", decoded.strengthStatus)
            assertTrue(decoded.strengthLabel.contains("類似ランク $grade"))
        }
        val uniform = assessment(chart = chart().copy(effectiveSampleSize = 200.00000000000003))
        val uniformDecoded = AssessmentJsonCodec.decode(AssessmentJsonCodec.encode(uniform))!!
        assertEquals(200.0, uniformDecoded.chartRank!!.effectiveSampleSize!!, 0.0)
        assertEquals("H", uniformDecoded.chartRank!!.grade)
    }

    @Test fun unrankedUnsupportedQueryDoesNotInventAnEstimateOrAReference() {
        val unavailable = chart("UNRANKED").copy(rawProbability = null, shrunkProbability = null,
            calibratedProbability = null, supportN = 0, referenceDates = 0, effectiveSampleSize = null,
            statusReason = "OUTSIDE_RESEARCH_SCOPE")
        val a = assessment("E", unavailable)
        val decoded = AssessmentJsonCodec.decode(AssessmentJsonCodec.encode(a))!!
        assertEquals(a, decoded)
        assertEquals("類似ランク 保留 / 参照0件（強弱未検証）", decoded.strengthLabel)
        assertFalse(decoded.strengthLabel.contains("推定"))
    }

    @Test fun oldSchemaOneWithoutChartKeepsItsOriginalAssessment() {
        val old = assessment("E", null)
        val json = AssessmentJsonCodec.encode(old)!!
        json.remove("chart_rank")
        assertEquals(old, AssessmentJsonCodec.decode(json))
        assertEquals("検証待ち", old.strengthLabel)
        assertNull(AssessmentJsonCodec.decode(null))
    }

    @Test fun malformedOptionalChartDropsOnlyChartNotNativeActionOrReason() {
        val changes: List<(JSONObject) -> Unit> = listOf(
            { it.put("schema_version", 2) }, { it.put("grade", "S") }, { it.put("grade", "I") },
            { it.put("validation_status", "VALIDATED") }, { it.put("usage", "TRADE_ACTION") },
            { it.put("direction", "LOW") }, { it.put("raw_probability", 1.1) },
            { it.put("shrunk_probability", "0.44") }, { it.put("calibrated_probability", -.1) },
            { it.put("support_n", 199) }, { it.put("support_n", 201) }, { it.put("support_n", 200.5) },
            { it.put("reference_dates", 50) }, { it.put("reference_dates", 201) },
            { it.put("effective_sample_size", 99.0) }, { it.put("effective_sample_size", 201.0) },
            { it.put("query_boundary_utc", 0) }, { it.put("query_boundary_utc", 12.5) },
            { it.put("model_version", "") }, { it.remove("snapshot_id") }, { it.remove("status_reason") }
        )
        val a = assessment()
        changes.forEach { change ->
            val json = AssessmentJsonCodec.encode(a)!!
            change(json.getJSONObject("chart_rank"))
            assertEquals(a.copy(chartRank = null), AssessmentJsonCodec.decode(json))
        }
        val json = AssessmentJsonCodec.encode(a)!!.put("chart_rank", "broken")
        assertEquals(a.copy(chartRank = null), AssessmentJsonCodec.decode(json))
    }

    @Test fun nonNumericNullableProbabilityIsRejectedRatherThanConvertedToMissing() {
        val json = AssessmentJsonCodec.encode(assessment("E", chart("UNRANKED")))!!
        json.getJSONObject("chart_rank").put("calibrated_probability", "bad")
        assertNull(AssessmentJsonCodec.decode(json)!!.chartRank)
    }

    @Test fun historyPersistsAllGradesIncludingHOnSkippedRowsWithoutChangingStatistics() {
        val s = HistoryStore(app).also { stores += it }
        listOf("E", "F", "G", "H").forEach { grade ->
            val a = assessment(grade)
            val c = ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", grade, null, "SKIP", assessment = a)
            s.add(ScanResult("chart-$grade", "2026-10-09T09:04:50+09:00", "2026-10-09T09:05:00+09:00",
                "2026-10-09T09:08:00+09:00", listOf(c), source = "MANUAL", policyVersion = "GMK_V0742_OCTOBER_CHART200_EH"))
        }
        drain(s)
        val after = HistoryStore(app).also { stores += it }.load()
        assertEquals(4, after.size)
        after.forEach { row ->
            assertEquals(assessment(row.grade), row.assessment)
            assertEquals("SKIP", row.decision)
            assertEquals("SKIP", row.resultStatus)
            assertTrue(row.chartRankLabel!!.contains("類似ランク ${row.grade}"))
        }
        assertEquals(0, historyStatistics(after).values.sumOf { it.wins + it.losses })
        assertEquals(4, historyStatistics(after).values.sumOf { it.skips })
        assertTrue(s.pending().isEmpty())
    }

    @Test fun correctionPreservesChartForSameDirectionButClearsReversalAndExpiryChange() {
        val a = assessment()
        val c = ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "H", null, "SKIP", assessment = a)
        val unchanged = CandidateAssessmentFactory.correction(c, c, "HIGH", "H", "SKIP", 3, "routing")
        assertEquals(a.chartRank, unchanged.chartRank)
        assertNull(CandidateAssessmentFactory.correction(c, c, "LOW", "C", "ENTRY", 3, "reverse").chartRank)
        assertNull(CandidateAssessmentFactory.correction(c, c, "HIGH", "C", "ENTRY", 5, "expiry").chartRank)
    }

    @Test fun rankFilterIncludesHAndHoldEvenWithNoCasesAndLeavesLegacyRowsUnranked() {
        assertEquals(listOf("E", "F", "G", "H", "UNRANKED"), ChartRankDisplay.grades)
        assertTrue(ChartRankDisplay.filters.containsAll(listOf("H", "保留", "未記録")))
        assertTrue(ChartRankDisplay.matches(assessment(), "H"))
        assertFalse(ChartRankDisplay.matches(assessment(), "E"))
        assertTrue(ChartRankDisplay.matches(null, "未記録"))
        assertFalse(ChartRankDisplay.matches(null, "保留"))
        assertTrue(ChartRankDisplay.matches(assessment("E", chart("UNRANKED")), "保留"))
    }

    @Test fun chartForAnotherBoundaryIsDroppedWithoutLosingTheHistoryOrNativeAssessment() {
        val a = assessment(chart = chart().copy(queryBoundaryUtc = 1791504000L))
        val json = JSONObject().put("id", 1L).put("scan_id", "wrong-chart-boundary")
            .put("source", "AUTO").put("at_jst", "2026-10-09T09:04:50+09:00")
            .put("instrument", "USDJPY").put("direction", "HIGH").put("grade", "H").put("decision", "SKIP")
            .put("entry_time_jst", "2026-10-09T09:05:00+09:00").put("judge_time_jst", "2026-10-09T09:08:00+09:00")
            .put("result_status", "SKIP").put("policy_version", "GMK_V0742_OCTOBER_CHART200_EH")
            .put("assessment", AssessmentJsonCodec.encode(a))
        app.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE).edit()
            .putString("items", JSONArray().put(json).toString()).commit()
        val loaded = HistoryStore(app).also { stores += it }.load().single()
        assertEquals("wrong-chart-boundary", loaded.scanId)
        assertEquals("H", loaded.grade)
        assertEquals("SKIP", loaded.decision)
        assertEquals(a.copy(chartRank = null), loaded.assessment)
        assertEquals("E", loaded.assessment!!.originalAction.operationalGrade)
        assertNull(loaded.chartRankLabel)
    }
}

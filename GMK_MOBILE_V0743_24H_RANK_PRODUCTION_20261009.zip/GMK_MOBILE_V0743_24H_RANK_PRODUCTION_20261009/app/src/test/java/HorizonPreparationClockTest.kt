import jp.gmk.mobile.domain.horizon.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.concurrent.atomic.AtomicLong

/** Frozen observed prices and models; wall-clock time must not decide readiness. */
class HorizonPreparationClockTest {
    private fun adapter(clock: () -> Long): HorizonScanAdapter {
        fun model(name: String) = PortableTreeModel.load(
            File(RuleAiObservedFixture.root,"app/src/main/assets/horizon_policy/$name").readBytes(),
            HorizonModelCatalog.hashes.getValue(name))
        return HorizonScanAdapter(listOf(model("base_3m.bin"),model("base_10m.bin"),model("base_15m.bin")),
            model("r15_path_protect15.bin"),epochMillis=clock)
    }
    @Test fun preparationUsesInjectedClockForAFixedEveningBoundary() {
        val source=RuleAiObservedFixture.at(0,1)
        val delta=4*3600L
        val boundary=source.boundary+delta
        val prices=source.prices.mapValues { (_,bars)->bars.map { it.copy(timeEpochMs=it.timeEpochMs+delta*1000) } }
        val now=(boundary-20)*1000
        val frame=adapter { now }.prepare(prices,boundary)
        assertNotNull("A frozen pre-scan clock must prepare even after the real date passes",frame)
        assertEquals(boundary,frame!!.boundary)
        assertEquals(now,frame.preparedMs)
    }
    @Test fun preparationStillRejectsAnExpiredInjectedDeadline() {
        val observed=RuleAiObservedFixture.at(0,1)
        val clock=AtomicLong((observed.boundary-12)*1000)
        val adapter=adapter(clock::get)
        assertNull(adapter.prepare(observed.prices,observed.boundary))
        clock.incrementAndGet()
        assertNull(adapter.prepare(observed.prices,observed.boundary))
    }
    @Test fun frameRecordsInjectedTimeAfterPreparationFinishes() {
        val observed=RuleAiObservedFixture.at(0,1)
        val began=(observed.boundary-20)*1000
        val clock=AtomicLong(began)
        val frame=adapter { clock.getAndAdd(250) }.prepare(observed.prices,observed.boundary)
        assertNotNull(frame)
        assertEquals(began+250,frame!!.preparedMs)
        assertEquals(began+500,clock.get())
    }
}

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import jp.gmk.mobile.domain.october.*
import org.junit.Assert.*
import org.junit.Test
import java.io.*
import java.time.*
import kotlin.math.abs

class OctoberSimilarityIntegrationTest {
    private val root=File(requireNotNull(System.getProperty("gmk.projectRoot")))
    private val b=ZonedDateTime.parse("2026-10-09T12:00:00+09:00").toEpochSecond()
    private fun model()=SequenceInputStream(java.util.Collections.enumeration((1..4).map { File(root,"app/src/main/assets/october_similarity/index.bin.gz.part"+it.toString().padStart(2,'0')).inputStream() })).use { OctoberSimilarityIndex.readCompressed(it,OctoberSimilarityCatalog.RAW_SHA256) }
    private fun adapter()=OctoberSimilarityScanAdapter(model(),clockMillis={ (b-20)*1000 })
    private fun prices()=OctoberSimilarityIndex.TRADED.associateWith { (0 until 120).map { i -> Candle((b-120-(119-i)*60)*1000,100.0,100.01,99.99,100.0) } }
    private fun quotes()=OctoberSimilarityIndex.TRADED.associateWith { HorizonQuote((b-11)*1000,(b-12)*1000,100.0,99.999,100.001,true) }
    private fun native(grade: String="C",decision: String="ENTRY"): ScanResult {
        val at=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
        return ScanResult("oct-live",at.minusSeconds(10).toString(),at.toString(),at.plusMinutes(3).toString(),
            OctoberSimilarityIndex.TRADED.mapIndexed { i,s -> ScanCandidate(i+1,s,s,"LOW",if(i==0)grade else "C",null,if(i==0)decision else "SKIP") },source="AUTO")
    }
    private fun frame(prices: Map<String,List<Candle>>): OctoberSimilarityFrame {
        val p=Array(4) { Array(2) { floatArrayOf(.4f,.2f,.4f) } };p[0][0]=floatArrayOf(.2f,.2f,.6f);p[3][0]=floatArrayOf(.1f,.1f,.8f);p[2][1]=floatArrayOf(.01f,.01f,.98f)
        val cutoff=OctoberSimilarityIndex.dailyCutoff(b)
        return OctoberSimilarityFrame(b,p,BooleanArray(4) { true },prices.mapValues { (_,rows) -> OctoberSimilarityScanAdapter.featureRows(rows,b)!! },(b-20)*1000,cutoff,cutoff-300)
    }
    @Test fun exactObservedTechnical35AndFutureMutation() {
        val file=File(root,"tools/october_fixtures/technical_features.bin")
        DataInputStream(BufferedInputStream(file.inputStream())).use { input ->
            assertEquals(0x474d4b54,input.readInt());val n=input.readInt();assertTrue(n>=100)
            repeat(n) {
                val boundary=input.readLong();val rows=List(61) { i -> Candle((boundary-3720+i*60)*1000,input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble()) }
                val expected=FloatArray(35) { input.readFloat() };val actual=OctoberSimilarityScanAdapter.features(rows,boundary)!!
                assertArrayEquals(expected,actual,2e-6f)
                val last=rows.last();val poisoned=rows+listOf(boundary-60,boundary,boundary+180).map { Candle(it*1000,last.open*7,last.high*7,last.low*7,last.close*7) }
                assertArrayEquals(actual,OctoberSimilarityScanAdapter.features(poisoned,boundary)!!,0f)
                assertNull(OctoberSimilarityScanAdapter.features(rows.dropLast(1),boundary))
                assertNull(OctoberSimilarityScanAdapter.features(rows+rows.last(),boundary))
            }
            assertEquals(-1,input.read())
        }
    }
    @Test fun fullAutoAndFixed3RouteWithoutEntryOrSABChanges() {
        val a=adapter();val rows=prices();val n=native();val f=frame(rows)
        val r=a.apply(n,rows,f,quotes(),false,(b-5)*1000)
        assertEquals("GBPJPY",r.top1!!.instrument);assertEquals("HIGH",r.top1!!.direction)
        assertEquals(n.entryTimeJst,r.entryTimeJst);assertEquals(5,Duration.between(ZonedDateTime.parse(r.entryTimeJst),ZonedDateTime.parse(r.judgeTimeJst)).toMinutes().toInt())
        assertEquals(listOf(1,2,3,4),r.candidates.map { it.rank });assertEquals("ENTRY",r.top1!!.decision)
        assertEquals(r,a.apply(n,rows,f,quotes(),false,(b-5)*1000))
        val fixed=a.apply(n,rows,f,quotes(),true,(b-5)*1000);assertEquals("AUDJPY",fixed.top1!!.instrument);assertTrue(fixed.policyVersion.endsWith("_3M_FIXED"))
        for(g in listOf("S","A","B")){val protected=native(g);assertEquals(protected.candidates,a.apply(protected,rows,f,quotes(),false,(b-5)*1000).candidates)}
        val skipped=native(decision="SKIP");assertEquals("SKIP",a.apply(skipped,rows,f,quotes(),false,(b-5)*1000).top1!!.decision)
    }
    @Test fun missingRevisedUnsafeLateFramesFallBack() {
        val a=adapter();val rows=prices();val n=native();val f=frame(rows)
        fun fallback(candles: Map<String,List<Candle>> =rows,frame: OctoberSimilarityFrame?=f,q: Map<String,HorizonQuote> =quotes(),time: Long=(b-5)*1000) {
            val r=a.apply(n.copy(scanId=java.util.UUID.randomUUID().toString()),candles,frame,q,false,time)
            assertEquals(n.candidates,r.candidates);assertEquals(n.judgeTimeJst,r.judgeTimeJst);assertTrue(r.policyVersion.startsWith(OctoberSimilarityScanAdapter.FALLBACK))
        }
        fallback(frame=null);fallback(candles=rows+mapOf("USDJPY" to rows.getValue("USDJPY").dropLast(1)))
        fallback(frame=f.copy(latestTrainingLabelEpoch=f.snapshotEpoch));fallback(frame=f.copy(snapshotEpoch=f.snapshotEpoch-86400))
        fallback(q=quotes().mapValues { (_,q) -> q.copy(sourceMs=(b-21)*1000) });fallback(time=b*1000-799)
        assertFalse(OctoberSimilarityScanAdapter.supports(ZonedDateTime.parse("2026-10-08T14:00:00+09:00").toEpochSecond()))
        assertTrue(OctoberSimilarityScanAdapter.supports(b));assertFalse(OctoberSimilarityScanAdapter.supports(b+86400))
        assertFalse(OctoberSimilarityScanAdapter.supports(ZonedDateTime.parse("2026-11-02T12:00:00+09:00").toEpochSecond()))
    }
    @Test fun optionalFeatureAndJournalOomPropagateToRuntimeRecovery() {
        val explosiveRows=object : AbstractList<Candle>() {
            override val size=61
            override fun get(index: Int): Candle = throw OutOfMemoryError("injected feature allocation")
        }
        try { OctoberSimilarityScanAdapter.features(explosiveRows,b);fail("feature OOM swallowed") }
        catch(expected: OutOfMemoryError) { assertEquals("injected feature allocation",expected.message) }
        val shared=model()
        val readFile=object : File("october-injected-read-oom.bin") {
            override fun isFile()=true
            override fun getPath(): String = throw OutOfMemoryError("injected journal read")
        }
        try { OctoberSimilarityScanAdapter(shared,readFile,clockMillis={ (b-20)*1000 });fail("read journal OOM swallowed") }
        catch(expected: OutOfMemoryError) { assertEquals("injected journal read",expected.message) }
        val writeFile=object : File("october-injected-write-oom.bin") {
            override fun isFile()=false
            override fun getParentFile(): File? = throw OutOfMemoryError("injected journal write")
        }
        val a=OctoberSimilarityScanAdapter(shared,writeFile,clockMillis={ (b-20)*1000 })
        try { a.prepare(prices(),b,3000);fail("write journal OOM swallowed") }
        catch(expected: OutOfMemoryError) { assertEquals("injected journal write",expected.message) }
    }
    @Test fun lazyChunkFailureDoesNotOpenUntouchedParts() {
        val requested=mutableListOf<String>()
        try {
            OctoberSimilarityCatalog.loadIndex { path -> requested+=path;byteArrayOf(0,1,2,3) }
            fail("invalid gzip accepted")
        } catch(expected: IOException) { }
        assertEquals(listOf("october_similarity/index.bin.gz.part01"),requested)
        // Exercise the same private stream loader with a tracked input to prove
        // header failure closes the opened stream without opening future parts.
        var closed=false;var opened=0
        val opener: (String) -> InputStream = {
            opened++
            object : ByteArrayInputStream(byteArrayOf(0,1,2,3)) {
                override fun close() { closed=true;super.close() }
            }
        }
        val load=OctoberSimilarityCatalog::class.java.declaredMethods.single { it.name=="load" }
        load.isAccessible=true
        try { load.invoke(OctoberSimilarityCatalog,opener);fail("bad tracked gzip accepted") }
        catch(expected: java.lang.reflect.InvocationTargetException) { assertTrue(expected.targetException is IOException) }
        assertEquals(1,opened);assertTrue(closed)
        requested.clear()
        try {
            OctoberSimilarityCatalog.loadIndex { path ->
                requested+=path
                if(path.endsWith("part02"))throw IOException("missing second part")
                File(root,"app/src/main/assets/$path").readBytes()
            }
            fail("missing compressed part accepted")
        } catch(expected: IOException) { }
        assertEquals(listOf("october_similarity/index.bin.gz.part01","october_similarity/index.bin.gz.part02"),requested)
    }
    @Test fun longCacheJournalIsBoundedToTwoObservedHours() {
        val prices=OctoberSimilarityIndex.TRADED.associateWith { (0 until 9000).map { i -> Candle((b-120-(8999-i)*60)*1000,100.0,100.01,99.99,100.0) } }
        val a=adapter();val frame=a.prepare(prices,b,3000)
        assertTrue(a.liveObservationCount in 1..100)
        assertTrue(frame.latestTrainingLabelEpoch<frame.snapshotEpoch)
        assertEquals(61,frame.ownPrices.getValue("USDJPY").size)
        assertTrue(OctoberSimilarityIndex.decide(0,true,"C",BooleanArray(4) { true },Array(4) { Array(2) { floatArrayOf(.1f,.1f,1.8f) } },false)==0)
    }
    @Test fun journalOnlyActualCompletedOutcomesAndCrcRejectsCorruption() {
        val folder=kotlin.io.path.createTempDirectory("gmk-october-journal").toFile();val file=File(folder,"journal.bin")
        try {
            val first=OctoberSimilarityScanAdapter(model(),file,clockMillis={ (b-20)*1000 });val prepared=first.prepare(prices(),b,3000)
            assertTrue(first.liveObservationCount>0);assertTrue(file.length()>0);assertEquals("READY",first.journalStatus)
            assertTrue(prepared.latestTrainingLabelEpoch<prepared.snapshotEpoch)
            val second=OctoberSimilarityScanAdapter(model(),file,clockMillis={ (b-20)*1000 })
            assertEquals(first.liveObservationCount,second.liveObservationCount)
            assertEquals("READY",second.journalStatus)
            val bytes=file.readBytes();bytes[20]=(bytes[20].toInt() xor 1).toByte();file.writeBytes(bytes)
            val corrupt=OctoberSimilarityScanAdapter(model(),file,clockMillis={ (b-20)*1000 });assertTrue(corrupt.journalStatus.startsWith("READ_ERROR"))
        } finally { folder.deleteRecursively() }
    }
}

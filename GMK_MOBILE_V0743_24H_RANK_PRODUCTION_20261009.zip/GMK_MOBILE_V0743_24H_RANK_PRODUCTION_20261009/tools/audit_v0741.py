"""Extend existing immutable audits for explicitly authorized explanation metadata.

Trading rules, gate weights, model assets and settlement math still use the old
baseline checks. Authorized Kotlin annotations are separately hash-pinned and
must pass the old-vs-new real-candle regression during the Android build.
"""
from pathlib import Path
import importlib.util,json,hashlib,re,argparse

ROOT=Path(__file__).resolve().parents[1]

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def audit():
    spec=importlib.util.spec_from_file_location('original_audit',ROOT/'tools/audit_v0740.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    result=old.audit()
    extension=json.loads((ROOT/'tools/v0741_assessment_extension.json').read_text())
    authorized=extension['authorized_metadata_source_files']
    gradle=(ROOT/'app/build.gradle.kts').read_text()
    for row in result['results']:
        name=row['check']
        if name.startswith('unchanged:') and name[len('unchanged:'):] in authorized:
            path=name[len('unchanged:'):];entry=authorized[path]
            row['check']='authorized_assessment_extension:'+path
            row['pass']=sha(ROOT/path)==entry['fixed_sha256']
            row['detail']={'original_sha256':entry['original_sha256'],'fixed_sha256':entry['fixed_sha256'],
                'scope':'Structured explanation fields only; required real-candle old-vs-new parity is executed by the build, not asserted by this source-only audit.'}
        elif name=='updated_version_code':row['pass']=re.search(r'versionCode\s*=\s*111\b',gradle) is not None
        elif name=='updated_version_name':row['pass']='versionName = "0.7.41-rank-clarified"' in gradle
        elif name=='expiry_apply_unchanged_with_history_filter_extension':
            path='app/src/main/java/jp/gmk/mobile/domain/ExpiryProfiles.kt'
            entry=authorized[path]
            text=(ROOT/path).read_text()
            fragment=extension['expiry_metadata_projection_fragment']
            # Remove exactly the descriptive argument. Every original scheduling,
            # reason, decision and settlement statement must then be byte-identical.
            restored=text.replace(',\n'+fragment,'',1)
            row['check']='expiry_original_operations_identical_with_metadata_projection'
            row['pass']=(text.count(fragment)==1 and sha(ROOT/path)==entry['fixed_sha256']
                and hashlib.sha256(restored.encode()).hexdigest()==entry['original_sha256'])
            row['detail']='Metadata updates chosen expiry only; original operations preserved byte-for-byte and fixedThreeProjection regression is required.'
    def check(name,passed):result['results'].append({'check':name,'pass':bool(passed)})
    domain=ROOT/'app/src/main/java/jp/gmk/mobile/domain'
    before=ROOT/'app/src/test/java/jp/gmk/mobile/rankbaseline/FinalRankPolicy.kt'
    policy=(domain/'FinalRankPolicy.kt').read_text()
    original=before.read_text()
    # Every rule literal remains in identical list order; classification annotations
    # are not allowed to replace or refit the stored trading rules.
    lines=lambda text:[line.strip() for line in text.splitlines() if line.strip().startswith('Rule(') or re.fullmatch(r'\s*\d+ to "[A-Z]",?\s*',line)]
    check('fixed_policy_rule_literals_and_remaps_identical',lines(policy)==lines(original))
    presentation=(domain/'CandidateAssessment.kt').read_text()
    check('strength_is_explicitly_unvalidated','val strengthStatus: String get() = "UNVALIDATED"' in presentation and 'val strengthLabel: String get() = "検証待ち"' in presentation)
    main=(ROOT/'app/src/main/java/jp/gmk/mobile/MainActivity.kt').read_text()
    check('current_rule_average_not_displayed_as_current_probability','"RULE ${' not in main and 'top.historicalRateLabel' in main and 'top.strengthLabel' in main)
    codec=(ROOT/'app/src/main/java/jp/gmk/mobile/data/AssessmentJsonCodec.kt').read_text()
    check('assessment_roundtrip_codec_present','fun encode(' in codec and 'fun decode(' in codec)
    tests=ROOT/'app/src/test/java'
    check('assessment_history_and_behavior_tests_present',all((tests/name).is_file() for name in extension['required_test_sources']))
    fixture=ROOT/'app/src/test/resources/rank_assessment_native_october.manifest.json'
    fixture_manifest=json.loads(fixture.read_text())
    check('real_candle_parity_fixture_sha256',sha(fixture.with_name('rank_assessment_native_october.bin.gz'))==fixture_manifest['compressed_sha256'])
    check('original_v0740_parity_test_baselines_sha256',all(sha(ROOT/r['test_relative_path'])==r['package_renamed_sha256'] for r in fixture_manifest['unchanged_v0740_test_baseline']))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
        scope='V0741_SOURCE_GUARDS_WITH_AUTHORIZED_EXPLANATION_FIELDS; RUNTIME_PARITY_REQUIRED_SEPARATELY',
        checks=len(result['results']),failed=[r['check'] for r in result['results'] if not r['pass']],
        current_version='0.7.41-rank-clarified',strength_model_adopted=False)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args()
    result=audit()
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','checks','failed','scope']},ensure_ascii=False))
    if result['status']!='PASS':raise SystemExit(1)

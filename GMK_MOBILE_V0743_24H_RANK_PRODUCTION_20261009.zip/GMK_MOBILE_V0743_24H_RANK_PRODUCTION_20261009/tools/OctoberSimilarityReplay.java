import jp.gmk.mobile.domain.october.*;
import java.io.*;
import java.time.*;
import java.nio.file.*;
import java.util.*;

/** Independent portable runtime consumes frozen research oracle fixtures. Fails
 * on any changed action, ENTRY/SAB mutation, probability error or future label. */
public final class OctoberSimilarityReplay {
    private static InputStream openCompressed(String path) throws IOException {
        File file=new File(path);if(file.isFile())return new FileInputStream(file);
        List<InputStream> streams=new ArrayList<>();try {for(int i=1;i<=4;i++)streams.add(new FileInputStream(new File(file,String.format(Locale.ROOT,"index.bin.gz.part%02d",i))));return new SequenceInputStream(Collections.enumeration(streams));}
        catch(IOException e){for(InputStream stream:streams)stream.close();throw e;}
    }
    public static void main(String[] args) throws Exception {
        if(args.length!=4)throw new IllegalArgumentException("index.gz rawSHA replayFixture technicalFixture");
        long load=System.nanoTime();OctoberSimilarityIndex model=OctoberSimilarityIndex.readCompressed(openCompressed(args[0]),args[1]);double loadMs=(System.nanoTime()-load)/1e6;
        DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(args[2])));
        if(in.readInt()!=0x474d4b46)throw new IOException("fixture header");int count=in.readInt(),entries=0,wins=0,loss=0,max=0,changed=0,protectedCount=0;double maxDiff=0;List<Double> milliseconds=new ArrayList<>();
        for(int i=0;i<count;i++) {
            long b=in.readLong();int nativeAction=in.readInt();boolean entry=in.readUnsignedByte()!=0;int gradeByte=in.readUnsignedByte();String grade=gradeByte==0?"":Character.toString((char)gradeByte);boolean common=in.readUnsignedByte()!=0,win=in.readUnsignedByte()!=0;int expected=in.readInt(),label=in.readInt();
            boolean[] valid=new boolean[4];for(int s=0;s<4;s++)valid[s]=in.readUnsignedByte()!=0;
            float[][] x=new float[4][35];for(int s=0;s<4;s++)for(int j=0;j<35;j++)x[s][j]=in.readFloat();
            float[][][] oracle=new float[4][2][3];for(int s=0;s<4;s++)for(int h=0;h<2;h++)for(int c=0;c<3;c++)oracle[s][h][c]=in.readFloat();
            long t=System.nanoTime();float[][][] p=model.predict(x,valid,b,0);milliseconds.add((System.nanoTime()-t)/1e6);
            if(model.latestSnapshotLabelEpoch()>=OctoberSimilarityIndex.dailyCutoff(b))throw new AssertionError("label cutoff");
            for(int s=0;s<4;s++)for(int h=0;h<2;h++)for(int c=0;c<3;c++){
                float actual=p[s][h][c],ref=oracle[s][h][c];if(Float.isNaN(actual)!=Float.isNaN(ref))throw new AssertionError("availability mismatch "+b+" symbol"+s);
                if(Float.isFinite(ref)){double d=Math.abs(actual-ref);maxDiff=Math.max(maxDiff,d);if(d>2e-6)throw new AssertionError("probability mismatch "+b+" "+s+" "+h+" "+c+" "+actual+"!="+ref);}
            }
            int actual=OctoberSimilarityIndex.decide(nativeAction,entry,grade,valid,p,false);
            if(actual!=expected)throw new AssertionError("decision mismatch "+b+" "+actual+"!="+expected+" native"+nativeAction+" grade"+grade);
            if(grade.equals("S")||grade.equals("A")||grade.equals("B")){protectedCount++;if(actual!=nativeAction)throw new AssertionError("protected");}
            int hour=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo")).getHour();
            if(common&&hour>=9&&hour<15&&entry){entries++;if(actual!=nativeAction)changed++;if(win){wins++;loss=0;}else{loss++;max=Math.max(max,loss);}}
            if(!entry&&actual!=nativeAction)throw new AssertionError("ENTRY changed");
            int fixed=OctoberSimilarityIndex.decide(nativeAction,entry,grade,valid,p,true);if(fixed>=0&&fixed%4/2!=0)throw new AssertionError("fixed3 selects5");
        }
        if(in.read()!=-1)throw new IOException("fixture trailing");in.close();
        if(entries!=204||wins!=122||max!=5||changed!=42)throw new AssertionError("primary metrics "+entries+" "+wins+" "+max+" "+changed);
        DataInputStream feat=new DataInputStream(new BufferedInputStream(new FileInputStream(args[3])));if(feat.readInt()!=0x474d4b54)throw new IOException("featurefixture header");int features=feat.readInt();double featureDiff=0;
        for(int i=0;i<features;i++){long b=feat.readLong();double[][] bars=new double[61][4];for(int j=0;j<61;j++)for(int k=0;k<4;k++)bars[j][k]=feat.readDouble();float[] expected=new float[35];for(int j=0;j<35;j++)expected[j]=feat.readFloat();float[] actual=OctoberTechnicalFeatures.compute(bars,b);for(int j=0;j<35;j++){double diff=Math.abs(expected[j]-actual[j]);featureDiff=Math.max(featureDiff,diff);if(diff>Math.max(2e-6,Math.abs(expected[j])*2e-6))throw new AssertionError("feature parity "+b+" "+j+" "+actual[j]+" "+expected[j]);}}
        if(feat.read()!=-1)throw new IOException("featurefixture trailing");feat.close();
        double[][] flat=new double[61][4];for(double[] bar:flat)Arrays.fill(bar,150);float[] flatFeatures=OctoberTechnicalFeatures.compute(flat,1790899200L);for(float v:flatFeatures)if(!Float.isFinite(v))throw new AssertionError("flat denominator");
        boolean invalidRejected=false;flat[2][1]=149;try{OctoberTechnicalFeatures.compute(flat,1790899200L);}catch(IllegalArgumentException e){invalidRejected=true;}if(!invalidRejected)throw new AssertionError("invalidOHLC accepted");
        // Missing quote/feature protects native even if another candidate is stronger.
        boolean[] noOwn={false,true,true,true};float[][][] artificial=new float[4][2][3];for(float[][] ss:artificial)for(float[] pp:ss){pp[0]=.1f;pp[2]=.9f;}
        if(OctoberSimilarityIndex.decide(0,true,"C",noOwn,artificial,false)!=0)throw new AssertionError("unsafeOwn");
        for(String g:new String[]{"S","A","B"})if(OctoberSimilarityIndex.decide(0,true,g,new boolean[]{true,true,true,true},artificial,false)!=0)throw new AssertionError("protected native");
        float[][][] invalid=new float[4][2][3];for(float[][] ss:invalid)for(float[] pp:ss){pp[0]=.1f;pp[1]=.1f;pp[2]=1.8f;}
        if(OctoberSimilarityIndex.decide(0,true,"C",new boolean[]{true,true,true,true},invalid,false)!=0)throw new AssertionError("invalid probability accepted");
        boolean corruptionRejected=false;try{OctoberSimilarityIndex.readCompressed(openCompressed(args[0]),"badsha");}catch(IOException e){corruptionRejected=true;}if(!corruptionRejected)throw new AssertionError("SHA notchecked");
        Collections.sort(milliseconds);double p95=milliseconds.get((int)Math.floor(.95*(milliseconds.size()-1))),maxMs=milliseconds.get(milliseconds.size()-1);
        System.out.printf(Locale.ROOT,"{\"status\":\"PASS\",\"replay_boundaries\":%d,\"protected_rows\":%d,\"primary_entries\":%d,\"primary_wins\":%d,\"primary_max_loss\":%d,\"primary_changed\":%d,\"probability_max_abs_error\":%.9g,\"feature_cases\":%d,\"feature_max_abs_error\":%.9g,\"model_load_ms\":%.3f,\"prepare_p95_ms\":%.3f,\"prepare_max_ms\":%.3f,\"label_cutoff_verified\":true,\"fixed3_verified\":true,\"asset_SHA_verified\":true,\"native_ENTRY_SAB_preserved\":true}\n",count,protectedCount,entries,wins,max,changed,maxDiff,features,featureDiff,loadMs,p95,maxMs);
    }
}

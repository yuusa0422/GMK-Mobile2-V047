import jp.gmk.mobile.domain.october.ChartConditionalRankIndex;
import java.io.*;
import java.lang.reflect.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Independent Java consumer. Expected probabilities and labels are not read. */
public final class IndependentChartRankReplay {
    private static final List<String> guards=new ArrayList<>();
    private interface Checked { void run() throws Exception; }
    private static void expectRejected(String name,String message,Checked action)throws Exception{
        try{action.run();throw new AssertionError("Accepted invalid input: "+name);}
        catch(AssertionError e){throw e;}
        catch(Exception e){if(message!=null&&!String.valueOf(e.getMessage()).contains(message))
            throw new AssertionError(name+" wrong rejection: "+e,e);guards.add(name);}
    }
    private static String sha(byte[] bytes)throws Exception{
        StringBuilder text=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(bytes))
            text.append(String.format(Locale.ROOT,"%02x",b&255));return text.toString();
    }
    private static byte[] gzip(byte[] bytes)throws Exception{
        ByteArrayOutputStream bytesOut=new ByteArrayOutputStream();
        try(GZIPOutputStream out=new GZIPOutputStream(bytesOut)){out.write(bytes);}return bytesOut.toByteArray();
    }
    private static void malformed(String name,String message,byte[] raw,int length,int offset,byte[] alteration)throws Exception{
        byte[] poisoned=Arrays.copyOf(raw,length);System.arraycopy(alteration,0,poisoned,offset,alteration.length);
        byte[] compressed=gzip(poisoned);String expected=sha(poisoned);
        expectRejected(name,message,()->ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(compressed),expected));
    }
    private static byte[] integer(int value)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();new DataOutputStream(b).writeInt(value);return b.toByteArray();
    }
    private static byte[] longValue(long value)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();new DataOutputStream(b).writeLong(value);return b.toByteArray();
    }
    private static byte[] number(double value)throws Exception{
        ByteArrayOutputStream b=new ByteArrayOutputStream();new DataOutputStream(b).writeDouble(value);return b.toByteArray();
    }
    private static String json(Object value)throws Exception{
        if(value==null)return "null";
        if(value instanceof String){return "\""+((String)value).replace("\\","\\\\").replace("\"","\\\"")+"\"";}
        if(value instanceof Number){double d=((Number)value).doubleValue();return Double.isFinite(d)?value.toString():"null";}
        if(value instanceof Boolean)return value.toString();
        if(value.getClass().isArray()){
            StringBuilder out=new StringBuilder("[");for(int i=0;i<Array.getLength(value);i++){
                if(i>0)out.append(',');out.append(json(Array.get(value,i)));}return out.append(']').toString();
        }
        if(value instanceof Collection)return json(((Collection<?>)value).toArray());
        if(value instanceof Map){StringBuilder out=new StringBuilder("{");boolean first=true;
            for(Map.Entry<?,?> entry:((Map<?,?>)value).entrySet()){if(!first)out.append(',');first=false;
                out.append(json(entry.getKey().toString())).append(':').append(json(entry.getValue()));}return out.append('}').toString();}
        Map<String,Object> fields=new TreeMap<>();for(Field f:value.getClass().getFields())if(!Modifier.isStatic(f.getModifiers()))fields.put(f.getName(),f.get(value));
        return json(fields);
    }
    public static void main(String[] args)throws Exception{
        if(args.length!=4)throw new IllegalArgumentException("compressed-asset rawSHA query47.bin result.json");
        byte[] compressed=Files.readAllBytes(Paths.get(args[0]));String expectedSha=args[1];
        long began=System.nanoTime();ChartConditionalRankIndex model=ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(compressed),expectedSha);
        double loadMs=(System.nanoTime()-began)/1e6;
        DataInputStream input=new DataInputStream(new BufferedInputStream(new FileInputStream(args[2])));
        if(input.readInt()!=0x43495251)throw new AssertionError("Independent query header");int count=input.readInt();
        List<Map<String,Object>> rows=new ArrayList<>();float[] first=null;long firstBoundary=0;int firstSymbol=0;String firstDirection=null;
        for(int i=0;i<count;i++){
            int nameLength=input.readInt();byte[] name=new byte[nameLength];input.readFully(name);String id=new String(name,"UTF-8");
            long boundary=input.readLong();int symbol=input.readInt();String direction=input.readInt()==1?"HIGH":"LOW";
            float[] x=new float[35];for(int j=0;j<35;j++)x[j]=input.readFloat();
            if(i==0){first=x.clone();firstBoundary=boundary;firstSymbol=symbol;firstDirection=direction;}
            began=System.nanoTime();ChartConditionalRankIndex.Result prediction=model.predict(boundary,symbol,direction,x,0);
            Map<String,Object> row=new LinkedHashMap<>();row.put("case_id",id);row.put("prediction",prediction);row.put("inference_ms",(System.nanoTime()-began)/1e6);rows.add(row);
        }
        if(input.read()!=-1)throw new AssertionError("Independent query trailing bytes");input.close();
        final float[] query=first.clone();final long b=firstBoundary;final int s=firstSymbol;final String direction=firstDirection;
        ChartConditionalRankIndex.Result reference=model.predict(b,s,direction,query,0);
        String before=json(reference);
        float[] calendar=query.clone();Arrays.fill(calendar,30,35,Float.NaN);
        if(!before.equals(json(model.predict(b,s,direction,calendar,0))))throw new AssertionError("Calendar features affect retrieval");guards.add("calendar_features_nan_ignored");
        if(!before.equals(json(model.predict(b,s,direction,Arrays.copyOf(query,30),0))))throw new AssertionError("Technical30 compatibility");guards.add("technical30_input_equivalence");
        reference.neighborIds[0]=-999;reference.weights[0]=0;reference.distances[0]=999;
        if(!before.equals(json(model.predict(b,s,direction,query,0))))throw new AssertionError("Result mutation changed model");guards.add("result_arrays_do_not_mutate_model");
        query[0]=987;model.predict(b,s,direction,query,0);query[0]=first[0];
        if(!before.equals(json(model.predict(b,s,direction,query,0))))throw new AssertionError("Query mutation changed cached model");guards.add("input_array_copy_preserves_model");
        expectRejected("negative_symbol",null,()->model.predict(b,-1,direction,query,0));
        expectRejected("unsupported_symbol",null,()->model.predict(b,4,direction,query,0));
        expectRejected("unsupported_BTC",null,()->ChartConditionalRankIndex.symbolIndex("BTCJPY"));
        expectRejected("unsupported_direction",null,()->model.predict(b,s,"UP",query,0));
        expectRejected("null_direction",null,()->model.predict(b,s,null,query,0));
        expectRejected("null_features",null,()->model.predict(b,s,direction,null,0));
        expectRejected("wrong_feature_length",null,()->model.predict(b,s,direction,new float[29],0));
        float[] nonfinite=query.clone();nonfinite[29]=Float.POSITIVE_INFINITY;
        expectRejected("nonfinite_chart_feature",null,()->model.predict(b,s,direction,nonfinite,0));
        expectRejected("pre_october_query",null,()->model.predict(1790755200L,s,direction,query,0));
        expectRejected("november_query",null,()->model.predict(1793509200L,s,direction,query,0));
        expectRejected("expired_cached_inference_deadline","DEADLINE",()->model.predict(b,s,direction,query,System.nanoTime()-1));
        float[] fresh=query.clone();fresh[2]+=.013f;
        expectRejected("expired_fresh_inference_deadline","DEADLINE",()->model.predict(b,s,direction,fresh,System.nanoTime()-1));
        Thread.currentThread().interrupt();try{expectRejected("interrupted_inference","DEADLINE",()->model.predict(b,s,direction,query,0));}
        finally{Thread.interrupted();}
        if(!before.equals(json(model.predict(b,s,direction,query,0))))throw new AssertionError("Deadline changed model");guards.add("deadline_abort_preserves_complete_model");
        expectRejected("required_asset_hash","REQUIRED_SHA256",()->ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(compressed),""));
        expectRejected("wrong_asset_hash","SHA256_MISMATCH",()->ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(compressed),String.join("",Collections.nCopies(64,"0"))));
        expectRejected("expired_asset_load_deadline","DEADLINE",()->ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(compressed),expectedSha,System.nanoTime()-1));
        expectRejected("truncated_gzip",null,()->ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(Arrays.copyOf(compressed,compressed.length-20)),expectedSha));
        ByteArrayOutputStream rawOut=new ByteArrayOutputStream();try(GZIPInputStream in=new GZIPInputStream(new ByteArrayInputStream(compressed))){byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)rawOut.write(buffer,0,n);}
        byte[] raw=rawOut.toByteArray();
        malformed("wrong_schema","ASSET_SCHEMA",raw,28,0,integer(0));
        malformed("wrong_provenance","FROZEN_SOURCE_SHA256",raw,292,30,new byte[]{'0'});
        malformed("unsupported_calibration","CALIBRATION_SCHEMA",raw,317,292,new byte[]{0});
        malformed("oversized_symbol_count","FULL_BANK_COUNT",raw,529,525,integer(Integer.MAX_VALUE));
        malformed("nonpositive_iqr","INVALID_IQR",raw,1009,769,number(0));
        malformed("future_history_boundary","INVALID_REAL_RECORD",raw,1162,1029,longValue(1790780400L));
        malformed("nonpositive_availability","INVALID_REAL_RECORD",raw,1162,1037,integer(0));
        malformed("invalid_history_label","INVALID_REAL_RECORD",raw,1162,1041,new byte[]{3});
        malformed("nonfinite_history_feature","NONFINITE_HISTORY",raw,1162,1042,integer(0x7fc00000));
        malformed("duplicate_original_id","INVALID_REAL_RECORD",raw,1299,1162,Arrays.copyOfRange(raw,1025,1029));
        byte[] trailing=Arrays.copyOf(raw,raw.length+1);byte[] trailingGzip=gzip(trailing);String trailingSha=sha(trailing);
        expectRejected("trailing_raw_bytes","TRAILING_BYTES",()->ChartConditionalRankIndex.readCompressed(new ByteArrayInputStream(trailingGzip),trailingSha));
        Map<String,Object> result=new LinkedHashMap<>();result.put("schema",1);result.put("queries",rows);result.put("guards",guards);
        result.put("model_load_ms",loadMs);result.put("actual_real_bank_rows",model.observationCount());
        Files.write(Paths.get(args[3]),(json(result)+"\n").getBytes("UTF-8"));
        System.out.println("PASS independent Java consumer queries="+count+" guards="+guards.size());
    }
}

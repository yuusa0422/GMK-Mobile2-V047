独立監査の実行

プロジェクト直下で次を実行します。
  python3 tools/audit_chart_rank_independent.py

Python標準ライブラリとJDKのみを使用します。javacコマンドがないJDKでも
jdk.compiler/com.sun.tools.javac.Mainを利用します。Android用の学習や再調整は行いません。

検査内容
・270,501件の全適格履歴を、元271,845件から独立に抽出した照合値で検査。
  元ID、日時、ラベル、float32特徴量、全母集団の中央値/IQR/事前率を確認。
・Python研究エンジンから独立に作成した47件の入力と予測をJavaで再現。
  9,400件の参照IDと選択順序、距離、重み、校正値、E〜H、保留を確認。
・通貨と最初の30個のfloat32特徴量のハッシュで入力同一性を確認。
・破損データ、範囲外入力、将来履歴、期限切れ、入力/結果配列の変更など33件。

queries47.binは現在候補の勝敗や判定価格を含みません。
oracle47.jsonは、固定Pythonモデルから作成した検証用の予測照合値です。
bank_oracle.jsonの勝敗は、10月より前の実在269件の校正履歴のみです。

実機の速度、GitHub上の実行、将来のランク別勝率順を確認する検査ではありません。
監査結果はCHART_RANK_INDEPENDENT_AUDIT.jsonへ保存します。

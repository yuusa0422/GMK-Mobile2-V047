"""Aggregate distinct v0.7.40 audit scopes without inventing build/device results.

Run after source freeze. Add --verify-android only after all Gradle tasks finish;
add --package-dir for the actual build_release.py verified artifact directory.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import audit_v0740
import build_release

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "release_evidence/v0740"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def collect(verify_android=False, package_dir=None):
    references = {}

    def read(relative):
        path = ROOT / relative
        data = json.loads(path.read_text())
        references[relative] = {"sha256": digest(path), "bytes": path.stat().st_size}
        return data

    source = audit_v0740.audit()
    source_path = EVIDENCE / "SOURCE_AUDIT.json"
    source_path.write_text(json.dumps(source, ensure_ascii=False, indent=2) + "\n")
    read("release_evidence/v0740/SOURCE_AUDIT.json")
    independent = read("release_evidence/v0740/OCTOBER_INDEPENDENT_INPUT_AUDIT.json")
    portable = read("OCTOBER_SIMILARITY_PORTABLE_AUDIT.json")
    domain = read("release_evidence/v0740/DOMAIN_KOTLIN_CLI_AUDIT.json")
    data = read("release_evidence/v0740/DATA_RUNTIME_COMPILE_AUDIT.json")
    r13 = read("release_evidence/v0740/R13_HOST_JAVA_REGRESSION.json")
    transport = read("release_evidence/v0740/market_headless_execution.json")
    market = read("release_evidence/v0740/MARKET_TRANSPORT_AUDIT.json")
    history = read("release_evidence/v0740/history_cutin_audit.json")
    production_compile = read("release_evidence/v0740/UI_VIEWMODEL_COMPILE_AUDIT.json")
    october_junit = read("release_evidence/v0740/OCTOBER_ADAPTER_JUNIT_AUDIT.json")
    october_runtime_test_compile = read("release_evidence/v0740/OCTOBER_RUNTIME_TEST_SOURCE_COMPILE_AUDIT.json")
    legacy_evening_test_compile = read("release_evidence/v0740/LEGACY_EVENING_TEST_SOURCE_COMPILE_AUDIT.json")
    legacy_evening_clock = read("release_evidence/v0740/LEGACY_EVENING_CLOCK_AUDIT.json")
    legacy_evening_change = read("release_evidence/v0740/LEGACY_EVENING_FIXTURE_CHANGE_AUDIT.json")
    if (legacy_evening_change["status"] != "PASS"
            or not legacy_evening_change["all_existing_assertion_predicates_and_unrelated_runtime_scenarios_byte_exact"]
            or legacy_evening_change["repaired_runtime_test_sha256"] != digest(ROOT / "app/src/test/java/RuleAiRuntimeIntegrationTest.kt")):
        raise ValueError("original evening test assertions changed or clock repair evidence is stale")
    heap = read("release_evidence/v0740/october_resources/OCTOBER_HEAP_RESOURCE_AUDIT.json")
    freshness = []
    for label, records in (("data_runtime_compile", data["source_sha256"]),
                           ("market_headless_execution", transport["production_source_sha256"]),
                           ("history_cutin_owner_audit", history["sha256"]),
                           ("all_production_kotlin_compose_compile", production_compile["source_sha256"]),
                           ("all_production_java_compile", production_compile["java_source_sha256"]),
                           ("runtime_october_test_typecheck", october_runtime_test_compile["source_sha256"]),
                           ("repaired_legacy_evening_test_typecheck", legacy_evening_test_compile["source_sha256"]),
                           ("october_host_junit_test_source", {"app/src/test/java/OctoberSimilarityIntegrationTest.kt": october_junit["test_source_sha256"]}),
                           ("actual_catalog_heap_replay_production_inputs", {name: sha for name, sha in heap["source_sha256"].items() if name.startswith("app/src/main/")})):
        for name, sha in records.items():
            path = ROOT / name
            freshness.append({"scope": label, "source": name,
                              "evidence_source_sha256": sha,
                              "current_source_sha256": digest(path),
                              "match": digest(path) == sha})

    android = {"status": "PENDING", "required_minimum_tests": sum(build_release.REQUIRED_SUITES.values()),
               "actual_executed_tests": None,
               "planned_tasks": [":app:testDebugUnitTest", ":app:lintRelease", ":app:assembleRelease", ":app:assembleDebug"],
               "robolectric_is_physical_phone_execution": False}
    if verify_android:
        android.update(build_release.verify_tests(ROOT))
        android["actual_executed_tests"] = android.pop("tests")
        build_qa = read("release_evidence/v0740/ANDROID_FINAL_BUILD_QA.json")
        if (build_qa["status"] != "PASS_ACTUAL_ANDROID_BUILD_TESTS_AND_APK_VERIFICATION"
                or build_qa["unit_tests"] != android["actual_executed_tests"]
                or build_qa["failed"] or build_qa["skipped"]
                or set(build_qa["tasks"]) != {"testDebugUnitTest", "lintRelease", "assembleRelease", "assembleDebug"}):
            raise ValueError("final actual Android task completion evidence is not PASS")
        android["actual_task_completion_evidence"] = {k: v for k, v in build_qa.items() if k != "source_input_sha256"}
        for name, sha in build_qa["source_input_sha256"].items():
            current = digest(ROOT / name)
            freshness.append({"scope": "actual_final_android_build_inputs", "source": name,
                "evidence_source_sha256": sha, "current_source_sha256": current, "match": current == sha})
        # The original deadline remains a real production guard. Verify the
        # repaired operation fixture across both actual Android host SDK runs.
        proofs = [read(f"release_evidence/v0740/LEGACY_EVENING_FIXTURE_API{sdk}.json") for sdk in (26, 35)]
        if len({p["selected_boundary_epoch"] for p in proofs}) != 1:
            raise ValueError("SDK26/35 evening fixtures did not use the same boundary")
        for proof in proofs:
            selected = datetime.fromisoformat(proof["selected_boundary_jst"].split("[", 1)[0])
            if (selected.isoweekday() > 5 or (selected.hour, selected.minute, selected.second) != (17, 55, 0)
                    or proof["selected_boundary_epoch"] * 1000 - proof["actual_wall_clock_epoch_ms"] <= 6 * 3600 * 1000
                    or not all(proof.get(k) for k in ("ohlc_volume_and_bar_intervals_unchanged",
                        "original_r13_deadline_unchanged", "shared_direct19_october8_fixture_unchanged"))):
                raise ValueError("evening operation fixture clock/geometry contract failed")
        for name, expected in legacy_evening_clock["source_sha256"].items():
            if name.startswith("app/src/main/") or name.endswith("RuleAiFunctionalTest.kt"):
                if digest(ROOT / name) != expected:
                    raise ValueError("original R13 code or common Oct8 fixture changed: " + name)
        if digest(ROOT / "app/src/test/java/RuleAiRuntimeIntegrationTest.kt") != legacy_evening_clock["repaired_fixture_source_sha256"]:
            raise ValueError("evening fixture changed after repair source freeze")
        replay_xml = ROOT / "app/build/test-results/testDebugUnitTest/TEST-RuleAiRuntimeIntegrationTest.xml"
        replay_suite = ET.parse(replay_xml).getroot()
        evening_cases = [t for t in replay_suite.findall("testcase") if t.get("name", "").startswith("evening")]
        if len(evening_cases) != 4 or any(t.find(tag) is not None for t in evening_cases for tag in ("failure", "error", "skipped")):
            raise ValueError("all four original evening route/retry SDK cases must pass")
        legacy_evening_clock.update({"status": "PASS_STATIC_EXPIRED_CLOCK_CAUSE_AND_ACTUAL_REPAIRED_SCENARIOS",
            "final_actual_replay": {"tests": 4, "failures": 0, "errors": 0, "skipped": 0,
                "sdk": [26, 35], "result_xml": str(replay_xml.relative_to(ROOT)), "xml_sha256": digest(replay_xml),
                "same_selected_future_boundary": True, "proofs": proofs,
                "production_r13_and_common_oct8_source_sha_unchanged": True,
                "existing_route_manual_identity_skip_network_assertions_retained": True},
            "cause_scope": "Static original deadline expression plus recorded actual wallclock proves expired fixed boundary; repaired scenario replay executes all original assertions."})
        (EVIDENCE / "LEGACY_EVENING_CLOCK_AUDIT.json").write_text(json.dumps(legacy_evening_clock, indent=2) + "\n")
        legacy_evening_clock = read("release_evidence/v0740/LEGACY_EVENING_CLOCK_AUDIT.json")
    else:
        # A draft must disclose a known failure, even before the strict final
        # verifier is requested. Partial or old XMLs cannot establish a PASS.
        observed = []
        for path in sorted((ROOT / "app/build/test-results/testDebugUnitTest").glob("TEST*.xml")):
            suite = ET.parse(path).getroot()
            observed.append({"suite": suite.get("name"), "tests": int(suite.get("tests", "0")),
                             "failures": int(suite.get("failures", "0")), "errors": int(suite.get("errors", "0")),
                             "skipped": int(suite.get("skipped", "0"))})
        if observed:
            android["observed_xml_results_pending_final_strict_verification"] = observed
            android["actual_executed_tests"] = sum(row["tests"] for row in observed)
            if any(row["failures"] or row["errors"] or row["skipped"] for row in observed):
                android["status"] = "FAIL"
                android["observed_failed_or_error_tests"] = sum(row["failures"] + row["errors"] for row in observed)

    lint_path = ROOT / "app/build/reports/lint-results-release.xml"
    lint = {"status": "PENDING", "executed": False}
    if verify_android and lint_path.is_file():
        issues = ET.parse(lint_path).getroot().findall("issue")
        fatal = [x.get("id") for x in issues if x.get("severity") in ("Error", "Fatal")]
        lint = {"status": "FAIL" if fatal else "PASS", "executed": True,
                "fatal_or_error_issue_ids": fatal, "warning_count": sum(x.get("severity") == "Warning" for x in issues),
                "report": str(lint_path.relative_to(ROOT)), "report_sha256": digest(lint_path)}

    package = {"status": "PENDING", "actual_apk_build_verified": False,
               "same_existing_production_signing_key_available": False,
               "installed_on_user_phone": False}
    if package_dir is not None:
        package_dir = Path(package_dir).resolve()
        release = json.loads((package_dir / "release-verification.json").read_text())
        if release.get("status") != "PASS":
            raise ValueError("actual release verification is not PASS")
        if verify_android and json.loads((package_dir / "android-build-verification.json").read_text()) != build_qa:
            raise ValueError("packaged actual Android build provenance differs from final QA evidence")
        apks = sorted(package_dir.glob("*.apk"))
        if not apks:
            raise ValueError("verified package directory has no actual APK")
        packaged_assets = {}
        for apk in apks:
            assets = build_release.verify_apk_assets(apk, ROOT)
            packaged_assets[apk.name] = {"sha256": digest(apk), "bytes": apk.stat().st_size,
                                       "all_current_source_assets_byte_exact": assets["status"] == "PASS"}
        package = {"status": "PASS", "actual_apk_build_verified": True,
                   "release_verification": release,
                   "same_existing_production_signing_key_available": bool(release.get("existing_certificate_matched")),
                   "artifacts": packaged_assets,
                   "installed_on_user_phone": False,
                   "phone_build_from_current_sources_live_verified": False}

    completed_statuses = [source["status"], independent["status"], portable["status"],
                          domain["status"], data["status"], r13["status"], production_compile["status"], october_junit["status"], october_runtime_test_compile["status"], legacy_evening_test_compile["status"]]
    completed_pass = (all(x == "PASS" for x in completed_statuses)
                      and transport["compile_exit"] == 0 and transport["test_exit"] == 0
                      and history["tests"]["host_queue"]["status"] == "PASS"
                      and history["tests"]["Kotlin_adapter_host"]["status"] == "PASS"
                      and production_compile["source_unchanged_during_compile"]
                      and heap["status"].startswith("PASS_")
                      and {row["heap_limit_mib"] for row in heap["lazy_actual_kotlin_catalog_after_fix"] if row["status"] == "PASS"} == {96, 128}
                      and all(row["status"] == "PASS" for row in heap["lazy_actual_kotlin_catalog_after_fix"] if row["heap_limit_mib"] in (96, 128))
                      and all(row["match"] for row in freshness))
    full_build = android["status"] == "PASS" and lint["status"] == "PASS" and package["status"] == "PASS"
    status = ("FAIL_OR_STALE_COMPLETED_EVIDENCE" if not completed_pass else
              "FAIL_OBSERVED_ANDROID_RUN_PENDING_REPAIR_AND_FINAL_VERIFICATION" if android["status"] == "FAIL" else
              "PASS_COMPLETED_CHECKS_ANDROID_BUILD_VERIFIED_PHONE_PENDING" if full_build else
              "PASS_COMPLETED_CHECKS_ANDROID_BUILD_PENDING")
    snap = {}
    for subdir in ("app/src/main", "app/src/debug", "app/src/test"):
        for path in sorted((ROOT / subdir).rglob("*")):
            if path.is_file():
                snap[str(path.relative_to(ROOT))] = digest(path)
    for name in ("app/build.gradle.kts", "build.gradle.kts", "settings.gradle.kts"):
        snap[name] = digest(ROOT / name)

    return {
        "status": status,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "release": "0.7.40-october-audit",
        "scopes_are_separate_not_summed_into_one_test_count": True,
        "completed_checks": {
            "immutable_source_and_contract_audit": {"status": source["status"], "checks": source["checks"],
                "protected_original_files": len(json.loads((ROOT / "tools/v0740_protected_baseline.json").read_text())["protected_files"]),
                "original_rule_rank_gate_model_and_resource_bytes_preserved": source["status"] == "PASS",
                "allowed_extensions": ["CutInPolicy.observeEvents adapter; original timing/direction suffix byte exact",
                    "ExpiryProfiles.includes recognizes GMK_V0740; original apply prefix byte exact",
                    "HistoryStore settlement: two I/O calls relocated to publish-before-journal save; all other guards/math byte exact"]},
            "independent_october_index_and_oracle_inputs": {"status": independent["status"], "checks": independent["checks"],
                "exact_observed_index_rows": independent["exact_observed_index_rows"], "query_rows": independent["replay_query_rows"]},
            "october_production_java_replay": portable,
            "actual_domain_java_kotlin_compile_and_cli": domain,
            "actual_all_data_kotlin_typecheck": data,
            "actual_all_production_38kotlin_11java_with_compose_compiler": production_compile,
            "actual_october_adapter_catalog_host_junit": october_junit,
            "october_runtime_14_case_source_typecheck_not_execution": october_runtime_test_compile,
            "repaired_legacy_evening_source_typecheck_not_execution": legacy_evening_test_compile,
            "original_r13_evening_fixture_clock_diagnosis_and_replay": legacy_evening_clock,
            "original_evening_assertions_and_unrelated_scenarios_preserved": legacy_evening_change,
            "october_heap_resource_replay": heap,
            "original_r13_host_regression": r13,
            "actual_market_transport_headless_junit": transport,
            "actual_cut_in_queue_host": history["tests"]["host_queue"],
            "actual_cut_in_adapter_host_junit": history["tests"]["Kotlin_adapter_host"],
        },
        "source_evidence_freshness": freshness,
        "external_market_live_probes": market["live_probe_status"],
        "old_user_device_diagnostic": market["observed_device_diagnostic"],
        "btc_selection_analysis": market["btc_selection_analysis"],
        "outcome_display_and_price_semantics": history["latency_limits"],
        "android_host_junit": android,
        "android_release_lint": lint,
        "actual_apk_and_signing": package,
        "physical_phone_validation": {"status": "NOT_CONNECTED_NOT_EXECUTED", "current_release_installed": False,
            "history_visible_latency_measured": False, "cut_in_foreground_background_delivery_measured": False,
            "current_release_btc_websocket_live_verified_on_phone": False},
        "research_interpretation": {"scope": "Same historical October 09-15 common-four-JPY native-entry mother set",
            "entries": 204, "wins": 122, "historical_win_rate_percent": 122 / 204 * 100,
            "max_loss_streak": 5, "original_same_mother_max_loss_streak": 6,
            "forecast_or_live_win_rate_guaranteed": False,
            "full_application_all_symbols_win_rate_verified": False,
            "same_month_selection_is_independent_untouched_holdout": False,
            "production_start_jst": "2026-10-09T00:00:00+09:00",
            "source_limitations": ["Original 2024 archive integrity limitation retained; recovered observed four-JPY data only",
                "Missing Aug19-31 and Oct7/8 observations are not synthesized", "2024/2025 broker time-zone convention inferred from validated 2026 convention"]},
        "evidence_sha256": references,
        "current_source_snapshot_sha256": snap,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-android", action="store_true")
    parser.add_argument("--package-dir", type=Path)
    parser.add_argument("--output", type=Path, default=EVIDENCE / "FULL_AUDIT_SCOPE.json")
    args = parser.parse_args()
    report = collect(args.verify_android, args.package_dir)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "output": str(args.output),
                      "android_tests": report["android_host_junit"]["status"],
                      "apk": report["actual_apk_and_signing"]["status"]}))
    return 1 if report["status"].startswith("FAIL") else 0


if __name__ == "__main__":
    sys.exit(main())

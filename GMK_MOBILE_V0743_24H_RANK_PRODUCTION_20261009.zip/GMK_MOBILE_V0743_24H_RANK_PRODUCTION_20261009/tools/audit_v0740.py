"""Independent release-source gate; never reports an APK or device test as run.

The earlier audit scripts retain their historical versions. This gate checks the
current release plus immutable v0.7.39 decision math, models, and resource bytes.
Behavioral suites and actual APK verification are separate mandatory build gates.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import sys
import struct
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app/src/main"
SRC = APP / "java/jp/gmk/mobile"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native_btc_statistics() -> dict:
    path = ROOT / "OFFICIAL_WIN_GATE_OOS_202607_0818.csv"
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    entries = [r for r in rows if r["gate_entry"].lower() == "true"]
    rule_counts = Counter()
    for line in (SRC / "domain/FinalRankPolicy.kt").read_text().splitlines():
        if "Rule(id =" in line:
            match = re.search(r'instrument = "(\w+)"', line)
            rule_counts[match[1] if match else "generic"] += 1
    return {
        "scope": "ARCHIVED_JULY_TO_AUG18_NATIVE_RULE_SELECTION; NOT_CURRENT_PHONE_HISTORY",
        "input_sha256": sha(path),
        "scored_top1_rows": len(rows),
        "scored_top1_by_instrument": dict(sorted(Counter(r["instrument"] for r in rows).items())),
        "entry_rows": len(entries),
        "entry_by_instrument": dict(sorted(Counter(r["instrument"] for r in entries).items())),
        "explicit_symbol_rule_counts": dict(sorted(rule_counts.items())),
        "sort_priority": ["base_rank", "minimum_period_win_rate", "expected_win_rate", "confidence", "absolute_effective_score", "symbol"],
        "missing_fx_policy": "Incomplete six-instrument input cancels the scan; BTC is not promoted as a missing-FX substitute.",
        "observed_current_phone_btc_selection_rate_verified": False,
    }


def audit() -> dict:
    checks: list[dict] = []

    def check(name: str, ok: bool, detail=None):
        row = {"check": name, "pass": bool(ok)}
        if detail is not None:
            row["detail"] = detail
        checks.append(row)

    def text(rel: str) -> str:
        return (ROOT / rel).read_text(encoding="utf-8")

    baseline = json.loads(text("tools/v0740_protected_baseline.json"))
    protected = baseline["protected_files"]
    event_extension = baseline["authorized_ui_event_transport_extension"]
    filter_extension = baseline["authorized_history_filter_extension"]
    for name, digest in protected.items():
        path = ROOT / name
        if name == event_extension["file"] and path.is_file() and sha(path) != digest:
            policy_source = path.read_text(encoding="utf-8")
            suffix_at = policy_source.find("    fun leadMs(")
            actual_suffix = policy_source[suffix_at:].encode("utf-8") if suffix_at >= 0 else b""
            check("cutin_original_timing_and_direction_unchanged", hashlib.sha256(actual_suffix).hexdigest() == event_extension["protected_original_timing_and_direction_suffix_sha256"],
                  {"original_source_sha256": digest, "extended_source_sha256": sha(path), "change": "Application-owned event collector; original timing and directional math unchanged."})
            continue
        if name == filter_extension["file"] and path.is_file() and sha(path) != digest:
            expiry_source = path.read_text(encoding="utf-8")
            prefix_at = expiry_source.find("    fun includes(")
            actual_prefix = expiry_source[:prefix_at].encode("utf-8") if prefix_at >= 0 else b""
            check("expiry_apply_unchanged_with_history_filter_extension", hashlib.sha256(actual_prefix).hexdigest() == filter_extension["protected_original_apply_prefix_sha256"],
                  {"original_source_sha256": digest, "extended_source_sha256": sha(path), "change": "History filter recognizes current production model; expiry transformation unchanged."})
            check("history_filter_recognizes_october_production", '"GMK_V0740"' in expiry_source[prefix_at:])
            continue
        check("unchanged:" + name, path.is_file() and sha(path) == digest)

    gradle = text("app/build.gradle.kts")
    check("production_application_id", 'applicationId = "jp.gmk.mobile.rule"' in gradle)
    check("updated_version_code", re.search(r"versionCode\s*=\s*110\b", gradle) is not None)
    version = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
    check("updated_version_name", version is not None and version[1].startswith("0.7.40") and "research" not in version[1].lower())
    check("android_jvm17", "JavaVersion.VERSION_17" in gradle and 'jvmTarget = "17"' in gradle)

    manifest = ET.fromstring(text("app/src/main/AndroidManifest.xml"))
    android = "{http://schemas.android.com/apk/res/android}"
    application = manifest.find("application")
    check("backup_disabled", application is not None and application.get(android + "allowBackup") == "false")
    check("cleartext_disabled", application is not None and application.get(android + "usesCleartextTraffic") == "false")
    check("keep_alive_service_private", application is not None and any(
        el.get(android + "name") == ".runtime.GmkRuntimeKeepAliveService" and
        el.get(android + "exported") == "false" and el.get(android + "foregroundServiceType") == "specialUse"
        for el in application.findall("service")))
    config = ET.fromstring(text("app/src/main/res/xml/network_security_config.xml"))
    check("network_config_forbids_cleartext", any(el.get("cleartextTrafficPermitted") == "false" for el in config.iter()))
    xml_errors = []
    for path in APP.rglob("*.xml"):
        try:
            ET.parse(path)
        except ET.ParseError as error:
            xml_errors.append({"file": str(path.relative_to(ROOT)), "error": str(error)})
    check("all_android_xml_parse", not xml_errors, xml_errors)

    refs = set()
    files = {p.stem for p in (APP / "res/drawable-nodpi").glob("*") if p.is_file()}
    source_files = list((APP / "java").rglob("*.kt")) + list((APP / "java").rglob("*.java"))
    for path in source_files:
        refs.update(re.findall(r"(?<!android\.)R\.drawable\.([A-Za-z0-9_]+)", path.read_text(encoding="utf-8")))
    check("all_drawable_refs_exist", refs <= files, sorted(refs - files))
    check("all_sixty_cutin_assets_preserved", len(list((APP / "res/drawable-nodpi").glob("cutin_*.webp"))) == 60)
    check("no_unsafe_research_rule_class", not any(p.name == "ResearchRuleIdPolicy.kt" for p in (APP / "java").rglob("*.kt")))
    fatal_catches = [(str(p.relative_to(ROOT)), match.group(1))
        for p in source_files for match in re.finditer(
            r"catch\s*\([^)]*:\s*(Throwable|Error|VirtualMachineError|OutOfMemoryError|LinkageError|ThreadDeath)\b",
            p.read_text(encoding="utf-8"))]
    allowed_optional_memory_catch = [("app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt", "OutOfMemoryError")] * 3
    check("fatal_errors_not_swallowed", fatal_catches == allowed_optional_memory_catch,
          "Exactly three OutOfMemoryError boundaries are allowed for optional October startup/preparation/publication; no broad Throwable/Error/VMError recovery.")
    credentials = []
    for path in source_files + [ROOT / "gradle.properties"]:
        data = path.read_text(encoding="utf-8")
        if re.search(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|ghp_[A-Za-z0-9]{30,}|AIza[0-9A-Za-z_-]{30,}", data):
            credentials.append(str(path.relative_to(ROOT)))
    check("no_committed_private_keys_or_tokens", not credentials, credentials)

    vm = text("app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt")
    runtime = text("app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt")
    history = text("app/src/main/java/jp/gmk/mobile/data/HistoryStore.kt")
    optional_load_end = runtime.find('fun model(name: String)=Direct19Model')
    optional_startup = runtime[:optional_load_end] if optional_load_end >= 0 else ""
    check("optional_october_memory_failure_continues_original_runtime",
          optional_load_end >= 0 and optional_startup.count("catch(e: OutOfMemoryError)") == 1
          and 'october=null' in optional_startup and 'octoberLoadStatus="MODEL_RESOURCE_LIMIT:${e.javaClass.simpleName}"' in optional_startup
          and "actualCorruptOctoberChunkFallsBackWithoutDisablingOriginalModels" in text("app/src/test/java/HorizonRuntimeOctoberIntegrationTest.kt")
          and "optionalOctoberAllocationFailureKeepsOriginalModelsRuntimeAndNativeEntryWorking" in text("app/src/test/java/HorizonRuntimeOctoberIntegrationTest.kt"))
    prepare_at = runtime.find("if(OctoberSimilarityScanAdapter.supports(boundary))")
    prepare_end = runtime.find("else if(Direct19ScanAdapter.supports(boundary))", prepare_at)
    publish_at = runtime.find("if(OctoberSimilarityScanAdapter.supports(boundary))", runtime.find("    fun apply("))
    publish_end = runtime.find("if(Direct19ScanAdapter.supports(boundary))", publish_at)
    optional_boundaries = [runtime[prepare_at:prepare_end], runtime[publish_at:publish_end]]
    check("optional_october_prepare_and_publish_memory_failure_clears_only_optional_refs",
          min(prepare_at, prepare_end, publish_at, publish_end) >= 0
          and all(block.count("catch(e: OutOfMemoryError)") == 1
                  and "october=null;preparedOctober.set(null);octoberReadySymbols=0" in block
                  and 'backgroundStatus="OCTOBER_RESOURCE_LIMIT_NATIVE_CONTINUES"' in block for block in optional_boundaries))
    check("production_october_loader_uses_asset_stream_default",
          "assetBytes: ((String)->ByteArray)? = null" in runtime
          and "private val hasInjectedAssetBytes=assetBytes!=null" in runtime
          and "if(hasInjectedAssetBytes)OctoberSimilarityCatalog.loadIndex(assetBytes)" in runtime
          and "else OctoberSimilarityCatalog.loadIndex(app.assets)" in runtime)
    october_adapter = text("app/src/main/java/jp/gmk/mobile/domain/october/OctoberSimilarityScanAdapter.kt")
    check("october_feature_and_journal_memory_errors_reach_runtime_recovery",
          october_adapter.count("if(it is OutOfMemoryError)throw it") == 3
          and "optionalFeatureAndJournalOomPropagateToRuntimeRecovery" in text("app/src/test/java/OctoberSimilarityIntegrationTest.kt"))
    check("strict_six_instrument_scan", "スキャン見送り: 6/6必須" in vm)
    check("exact_auto_minute_open_outcome", "fetchMinuteOpenAt(instrument, targetMs)" in vm and 'exactMinuteOpen = result.source != "MANUAL"' in vm)
    check("exact_manual_quote_outcome", "providerAtMs >= targetSecondMs" in vm and "providerAtMs <= capturedMs" in vm)
    check("draw_is_directional_loss", "DRAW is directional LOSE by specification" in history and 'resultStatus = if (win) "WIN" else "LOSE"' in history)
    check("history_atomic_mutations", all(re.search(r"@Synchronized\s+fun\s+" + name + r"\(", history) for name in ["add", "load", "updateEntryRate", "settle", "markEntryMissed", "markJudgeMissed"]))
    check("history_keeps_crash_journal", "critical_row_journal" in history and "mergeCriticalRow" in history)
    settlement_at = history.index("    fun settle(")
    settlement_end = history.index("    fun markJudgeMissed(", settlement_at)
    check("original_history_settlement_math_and_guards_unchanged", hashlib.sha256(history[settlement_at:settlement_end].encode()).hexdigest() == baseline["protected_history_settlement_io_relocated_sha256"],
          baseline["history_settlement_allowed_difference"])
    save_at = history.index("    private fun save(")
    save_end = history.index("    private fun scheduleWriterIfNeeded(", save_at)
    saving = history[save_at:save_end]
    check("history_publishes_before_durable_journal", "_rows.value = snapshot" in saving and saving.index("_rows.value = snapshot") < saving.index("persistCriticalRow(criticalRow)"))
    check("history_ui_reads_immutable_flow", "historyStore.rows.collect" in vm and "history = historyStore.rows.value" in vm)
    check("outcome_no_destructive_rededup", "HistoryIdentity.alreadyRecorded(current, result)" in history and "current.removeAll" not in history)
    check("runtime_single_process_owner", "GmkRuntimeHolder.get(application)" in text("app/src/main/java/jp/gmk/mobile/runtime/GmkRuntimeKeepAliveService.kt") and "GmkRuntimeHolder.get(app)" in text("app/src/main/java/jp/gmk/mobile/MainActivity.kt"))
    check("runtime_manual_unchanged", 'if(native.source!="AUTO")return native' in runtime)
    check("runtime_causal_quote_snapshot", "cache.quoteSnapshot((boundary-10)*1000)" in runtime)
    check("runtime_stopped_with_viewmodel", "horizonRuntime.stop()" in vm)
    check("runtime_october_route_precedes_direct19", runtime.index("if(OctoberSimilarityScanAdapter.supports(boundary))") < runtime.index("else if(Direct19ScanAdapter.supports(boundary))"))
    check("runtime_october_asset_fault_boundary", "OctoberSimilarityCatalog.loadIndex(assetBytes)" in runtime)
    check("runtime_october_frame_cleared_on_stop", "preparedOctober.set(null)" in runtime[runtime.index("    fun stop()"):])
    check("intentional_fx_abort_not_fake_failure", "catch(e:jp.gmk.mobile.data.MarketRequestAbortedException) { null }" in vm and "publishRates(if (row != null) listOf(row) else emptyList())" in vm)
    check("outcome_permit_per_individual_request", "outcomeCaptureSemaphore.withPermit { outcomeRepository.fetchRate(instrument) }" in vm and "outcomeCaptureSemaphore.withPermit { outcomeRepository.fetchMinuteOpenAt(instrument, targetMs) }" in vm)

    tests = list((ROOT / "app/src/test/java").glob("*"))
    check("existing_regression_suites_present", all((ROOT / "app/src/test/java" / (name + ".kt")).is_file() for name in [
        "ProductionRegressionTest", "PcSyncRegressionTest", "Direct19IntegrationTest", "RuleAiFunctionalTest",
        "RuleAiRuntimeIntegrationTest", "MobileRealtimeAuditTest", "MobileDeepAuditRegressionTest",
        "MobileFullAuditStateTest", "MobileFullAuditUiTest", "HistoryPipelineAuditTest", "HorizonPreparationClockTest"]))
    check("new_critical_regression_suites_present", all((ROOT / "app/src/test/java" / (name + ".kt")).is_file() for name in [
        "HorizonRuntimeOctoberIntegrationTest", "OctoberSimilarityIntegrationTest", "MarketTransportV0740Test",
        "CutInQueueRegressionTest", "HistoryPublicationLatencyTest", "HistoryCutInTimingUiTest"]))

    october_assets = APP / "assets/october_similarity"
    check("october_assets_exist", all((october_assets / ("index.bin.gz.part" + str(i).zfill(2))).is_file() for i in range(1, 5)) and (october_assets / "manifest.json").is_file())
    if (october_assets / "manifest.json").is_file():
        october_manifest = json.loads((october_assets / "manifest.json").read_text())
        check("october_policy_contract", october_manifest["policy"] == "TECH_WEEKDAY_HOUR_K100__C_M10" and october_manifest["feature_count"] == 35 and october_manifest["nearest_neighbors"] == 100 and october_manifest["correction_margin_float32"] == .10)
        check("october_entry_and_sab_protected", october_manifest["native_entry_preserved"] and october_manifest["native_grades_protected"] == ["S", "A", "B"])
        check("october_scope_and_horizons", october_manifest["symbols"] == ["USDJPY", "EURJPY", "GBPJPY", "AUDJPY"] and october_manifest["horizons_seconds"] == [180, 300])
        check("october_source_limitations_disclosed", not october_manifest["recovered_2024_archive_integrity_verified"] and october_manifest["raw_2026_august_19_31_missing"] and october_manifest["october_7_8_not_supplied"])
        compressed = bytearray()
        chunk_names = []
        for part in october_manifest["asset_chunks"]:
            filename = part["filename"]
            check("safe_october_chunk_name:" + filename, Path(filename).name == filename and filename not in chunk_names)
            chunk_names.append(filename)
            file = october_assets / filename
            check("october_chunk_integrity:" + filename, file.is_file() and file.stat().st_size == part["bytes"] and sha(file) == part["sha256"])
            if file.is_file():
                compressed.extend(file.read_bytes())
        check("october_four_ordered_chunks", chunk_names == ["index.bin.gz.part" + str(i).zfill(2) for i in range(1, 5)])
        check("october_concatenated_stream_sha", len(compressed) == october_manifest["compressed_bytes"] and hashlib.sha256(compressed).hexdigest() == october_manifest["asset_sha256"])
        try:
            raw = gzip.decompress(compressed)
            check("october_raw_stream_sha", len(raw) == october_manifest["uncompressed_bytes"] and hashlib.sha256(raw).hexdigest() == october_manifest["uncompressed_sha256"])
            magic, schema, symbols, features, last = struct.unpack_from(">iiiiq", raw)
            check("october_index_header", (magic, schema, symbols, features, last) == (0x474d4b4f, 1, 4, 35, october_manifest["last_bundled_boundary_utc"]))
        except (OSError, ValueError, struct.error) as error:
            check("october_raw_stream_sha", False, str(error))
        catalog = text("app/src/main/java/jp/gmk/mobile/domain/october/OctoberSimilarityCatalog.kt")
        check("october_loader_hash_matches_index", october_manifest["uncompressed_sha256"] in catalog)
        check("october_loader_streams_parts_lazily_and_stops_error_close_drain",
              "object : Enumeration<InputStream>" in catalog and "return open(path)" in catalog
              and "hasMoreElements()=!stopped && parts.hasNext()" in catalog
              and "finally { stopped=true }" in catalog and ".map {" not in catalog)
        available = re.search(r"AVAILABLE_FROM\s*=\s*(\d+)L", catalog)
        check("october_model_before_availability", available is not None and int(available[1]) == 1791471600 and october_manifest["last_bundled_label_utc"] < int(available[1]))
        check("october_stream_chunk_loader", "SequenceInputStream" in catalog and "(1..4)" in catalog)
    october_domain = SRC / "domain/october"
    check("october_native_adapter_present", (october_domain / "OctoberSimilarityScanAdapter.kt").is_file())
    if (october_domain / "OctoberSimilarityScanAdapter.kt").is_file():
        adapter = (october_domain / "OctoberSimilarityScanAdapter.kt").read_text(encoding="utf-8")
        check("october_entry_invariant_asserted", "native.top1" in adapter and ("decision" in adapter and "check(" in adapter))
        check("october_has_native_sab_guard", all('"' + rank + '"' in adapter for rank in ("S", "A", "B")))
    btc = native_btc_statistics()
    check("archived_native_selection_counts", btc["scored_top1_rows"] == 5871 and btc["entry_rows"] == 4136 and btc["entry_by_instrument"].get("BTCJPY") == 1390)
    failed = [row["check"] for row in checks if not row["pass"]]
    return {
        "status": "FAIL" if failed else "PASS",
        "scope": "SOURCE_AND_IMMUTABLE_BASELINE_AUDIT_ONLY",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "checks": len(checks),
        "failed": failed,
        "results": checks,
        "protected_original_files": len(protected),
        "test_sources_present": len(tests),
        "native_btc_selection": btc,
        "android_kotlin_compile_executed": False,
        "android_apk_build_executed": False,
        "android_unit_tests_executed": False,
        "phone_install_or_device_execution_verified": False,
        "live_win_rate_verified": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit()
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(json.dumps({k: result[k] for k in ["status", "checks", "failed", "protected_original_files", "scope"]}, ensure_ascii=False))
    if result["failed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Cross-language full-bank47-case parity, with outcome-free query fixtures."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys
import numpy as np
import pandas as pd

def run(project,study):
    project=Path(project);study=Path(study);work=project/'tools/chart_rank_parity';work.mkdir(exist_ok=True)
    sys.path.insert(0,str(study))
    from engine.chart_similarity import ChartSimilarityPredictor
    from engine.calibration import apply
    from engine.empirical_grades import assign_relative_grades
    pool=np.load(study/'inputs/historical_pool.npz',allow_pickle=False);queries=np.load(study/'inputs/native_e_queries.npz',allow_pickle=False)
    predictor=ChartSimilarityPredictor(pool);calibration=json.loads((study/'outputs/FROZEN_CALIBRATION_MODEL.json').read_text());grades=json.loads((study/'outputs/FROZEN_EMPIRICAL_GRADE_MODEL.json').read_text())
    october=pd.read_csv(study/'outputs/OCTOBER_E47_RANKS.csv',float_precision='round_trip')
    summary=[];neighbors=[];fixture=[];outcome_guards=0
    for row in october.to_dict('records'):
        at=np.flatnonzero(queries['case_id']==row['case_id']);assert len(at)==1;i=int(at[0]);features=queries['X'][i]
        query={'boundary_utc':int(row['boundary_utc']),'symbol':row['symbol'],'direction':row['direction'],'technical35':features}
        core,n=predictor.predict_query_json(query);c=apply(core['shrunk_probability'],calibration)[0]
        rank=assign_relative_grades([c['calibrated_probability']],grades)[0] if c['calibration_support_flag'] and core['support_flag'] else 'UNRANKED'
        assert rank==row['strength_rank']
        values=[row['case_id'],str(row['boundary_utc']),str(row['symbol_index']),row['direction']]+[format(float(v),'.9g') for v in features]
        fixture.append('\t'.join(values))
        summary.append({'case_id':row['case_id'],'rank':rank,'raw':core['raw_probability'],'weighted':core['local_weighted_probability'],
            'shrunk':core['shrunk_probability'],'calibrated':c['calibrated_probability'],'effective_n':core['effective_neighbor_n'],
            'effective_days':core['effective_neighbor_days'],'days':core['unique_neighbor_days'],'n':core['neighbor_count'],
            'prior':core['same_symbol_past_direction_prior'],'id_sha256':core['neighbor_id_sequence_sha256'],
            'query_symbol':row['symbol'],'query_symbol_index':row['symbol_index'],
            'query_chart_sha256':hashlib.sha256(features[:30].astype('>f4').tobytes()).hexdigest()})
        for position,value in enumerate(n.to_dict('records')):
            neighbors.append({'case_id':row['case_id'],'position':position,'id':value['neighbor_id'],'boundary':value['neighbor_boundary_utc'],
                'available':value['neighbor_available_utc'],'label':value['neighbor_label3'],'distance':value['distance'],'weight':value['weight']})
        for value in (0,1):
            try:predictor.predict_query_json(dict(query,win=value))
            except ValueError:outcome_guards+=1
            else:raise AssertionError('Current-query outcome accepted')
    (work/'queries.tsv').write_text('\n'.join(fixture)+'\n');pd.DataFrame(summary).to_csv(work/'python_expected_summary.tsv',sep='\t',index=False)
    pd.DataFrame(neighbors).to_csv(work/'python_expected_neighbors.tsv',sep='\t',index=False)
    classes=work/'classes';classes.mkdir(exist_ok=True)
    compiler=['javac'] if shutil.which('javac') else ['java','--module','jdk.compiler/com.sun.tools.javac.Main']
    subprocess.run(compiler+['-d',str(classes),str(project/'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankIndex.java'),str(project/'tools/ChartConditionalRankParity.java')],check=True)
    assets=project/'app/src/main/assets/october_chart_rank';manifest=json.loads((assets/'chart_rank_manifest.json').read_text())
    result=subprocess.run(['java','-Xmx256m','-cp',str(classes),'ChartConditionalRankParity',str(assets),manifest['raw_sha256'],str(work/'queries.tsv'),
         str(work/'java_summary.tsv'),str(work/'java_neighbors.tsv')],check=True,capture_output=True,text=True)
    diagnostics=json.loads(result.stdout)
    actual=pd.read_csv(work/'java_summary.tsv',sep='\t',float_precision='round_trip');expected=pd.DataFrame(summary)
    assert actual['case_id'].tolist()==expected['case_id'].tolist()
    numeric=['raw','weighted','shrunk','calibrated','effective_n','effective_days','prior'];max_error={}
    for column in ('rank','days','n','id_sha256','query_symbol','query_symbol_index','query_chart_sha256'):assert actual[column].tolist()==expected[column].tolist(),column
    for column in numeric:
        error=float(np.max(np.abs(actual[column]-expected[column])));max_error[column]=error
        if error>1e-12:raise AssertionError((column,error))
    got=pd.read_csv(work/'java_neighbors.tsv',sep='\t',float_precision='round_trip');want=pd.DataFrame(neighbors)
    for column in ('case_id','position','id','boundary','available','label'):assert got[column].tolist()==want[column].tolist(),column
    for column in ('distance','weight'):
        error=float(np.max(np.abs(got[column]-want[column])));max_error[column]=error
        if error>1e-12:raise AssertionError((column,error))
    final={'status':'PASS','full_bank_rows':270501,'case_count':len(actual),'neighbor_count':len(got),'rank_and_neighbor_ids_exact':True,
        'query_symbol_and_first30_float32_big_endian_hash_exact':True,
        'java_source_sha256':hashlib.sha256((project/'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankIndex.java').read_bytes()).hexdigest(),
        'cross_language_numeric_absolute_tolerance':1e-12,'max_absolute_error':max_error,
        'current_query_outcome_rejection_checks':outcome_guards,'java_diagnostics':diagnostics,
        'production_device_latency_measured':False,'source_selected_using_query_outcomes':False,
        'asset_raw_sha256':manifest['raw_sha256'],'asset_gzip_sha256':manifest['gzip_sha256']}
    (work/'PARITY_RESULT.json').write_text(json.dumps(final,indent=2)+'\n');print(json.dumps(final,indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--project',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--study',required=True,type=Path)
    args=parser.parse_args();run(args.project,args.study)

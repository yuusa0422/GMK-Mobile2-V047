"""Execute release-preparation guards and the exact standalone YAML bootstrap.

Synthetic source/APK fixtures test workflow logic only. They are never an Android
build, a model-parity result, or an installable APK. --source executes preparation
again with a real final distribution after it has been packaged.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import warnings
import xml.etree.ElementTree as ET
import zipfile

import yaml

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("gmk_build_release", ROOT / "tools/build_release.py")
release = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(release)


def expect_reject(fn, reason):
    try:
        fn()
    except (ValueError, zipfile.BadZipFile) as error:
        assert reason in str(error), (reason, str(error))
    else:
        raise AssertionError("Input incorrectly accepted: " + reason)


def manifest(project):
    files = sorted(p for p in project.rglob("*") if p.is_file() and p.name != "PACKAGE_MANIFEST_SHA256.txt")
    (project / "PACKAGE_MANIFEST_SHA256.txt").write_text("".join(
        release.sha256(p) + "  " + str(p.relative_to(project)) + "\n" for p in files))


def minimal_project(root):
    project = root / "GMK_MOBILE_V0740_TEST_FIXTURE"
    (project / "app/src/main/assets/october_similarity").mkdir(parents=True)
    (project / "app/build.gradle.kts").write_text('''android {
 compileSdk = 35
 defaultConfig {
  applicationId = "jp.gmk.mobile.rule"
  versionCode = 110
  versionName = "0.7.40-october-audit"
  minSdk = 26
  targetSdk = 35
 }
}
''')
    (project / "settings.gradle.kts").write_text('include(":app")\n')
    (project / "tools/fixtures").mkdir(parents=True)
    (project / "tools/pc_r13_fixtures").mkdir()
    for name in ("fixtures", "pc_r13_fixtures"):
        (project / "tools" / name / "synthetic.json").write_text('{"synthetic":true}')
    (project / "tools/direct19_feature_fixture.bin").write_bytes(b"synthetic workflow fixture only")
    (project / "DIRECT19_BUNDLED_FIXTURE_MANIFEST.json").write_text(json.dumps({
        "bundled_sha256": release.sha256(project / "tools/direct19_feature_fixture.bin")}))
    (project / "tools/audit_v0740.py").write_text('print("SYNTHETIC_STUB: this does not audit Android sources")\n')
    shutil.copyfile(ROOT / "tools/build_release.py", project / "tools/build_release.py")
    (project / "app/src/main/assets/october_similarity/manifest.json").write_text('{"synthetic":true}')
    (project / "app/src/main/assets/october_similarity/index.bin.gz").write_bytes(b"synthetic asset")
    manifest(project)
    return project


def make_zip(project, target, omitted=()):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(project.rglob("*")):
            relative = str(file.relative_to(project))
            if file.is_file() and relative not in omitted:
                archive.write(file, project.name + "/" + relative)


def execute(script, cwd, temporary, ok=True, updates=None):
    env = os.environ.copy()
    for key in (*release.KEY_NAMES, "EXPECTED_CERT_SHA256", "GMK_PROJECT"):
        env.pop(key, None)
    temporary.mkdir(parents=True, exist_ok=True)
    envfile = temporary / "env.txt"
    envfile.write_text("")
    env.update(RUNNER_TEMP=str(temporary), GITHUB_ENV=str(envfile), GITHUB_WORKSPACE=str(cwd))
    if updates:
        env.update(updates)
    completed = subprocess.run(["bash", "--noprofile", "--norc"], input=script, cwd=cwd,
                               env=env, text=True, capture_output=True, timeout=120)
    assert (completed.returncode == 0) == ok, (completed.returncode, completed.stdout, completed.stderr)
    project = None
    if envfile.read_text().strip():
        project = Path(dict(line.split("=", 1) for line in envfile.read_text().splitlines())["GMK_PROJECT"])
    return completed, project


def test_reports(project):
    reports = project / "app/build/test-results/testDebugUnitTest"
    reports.mkdir(parents=True)
    for name, count in release.REQUIRED_SUITES.items():
        suite = ET.Element("testsuite", name=name, tests=str(count), failures="0", errors="0", skipped="0")
        for i in range(count):
            ET.SubElement(suite, "testcase", name="synthetic_" + str(i), classname=name)
        ET.ElementTree(suite).write(reports / ("TEST-" + name + ".xml"))
    result = release.verify_tests(project)
    assert result["tests"] == sum(release.REQUIRED_SUITES.values())
    report = reports / "TEST-Direct19IntegrationTest.xml"
    original = report.read_bytes()
    report.unlink()
    expect_reject(lambda: release.verify_tests(project), "required regression suite")
    report.write_bytes(original)
    suite = ET.fromstring(original)
    suite.set("skipped", "1")
    report.write_bytes(ET.tostring(suite))
    expect_reject(lambda: release.verify_tests(project), "failed or skipped")
    report.write_bytes(original)
    (project / "app/src/test/java").mkdir(parents=True)
    (project / "app/src/test/java/NewCriticalTest.kt").write_text("class NewCriticalTest { @Test fun check() {} }")
    expect_reject(lambda: release.verify_tests(project), "current test source not executed")
    suite = ET.Element("testsuite", name="NewCriticalTest", tests="1", failures="0", errors="0", skipped="0")
    ET.SubElement(suite, "testcase", name="synthetic_new", classname="NewCriticalTest")
    ET.ElementTree(suite).write(reports / "TEST-NewCriticalTest.xml")
    assert release.verify_tests(project)["tests"] == sum(release.REQUIRED_SUITES.values()) + 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workflow", type=Path, required=True)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--data-parts", type=Path, nargs="*", default=[])
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    workflow = yaml.load(args.workflow.read_text(), Loader=yaml.BaseLoader)
    assert workflow["permissions"] == {"contents": "read"}
    assert workflow["on"] == ["workflow_dispatch"]
    job = workflow["jobs"]["build"]
    assert job["runs-on"] == "ubuntu-24.04"
    assert {step["uses"] for step in job["steps"] if "uses" in step} == {
        "actions/checkout@v7", "actions/setup-java@v6", "android-actions/setup-android@v4",
        "gradle/actions/setup-gradle@v5", "actions/upload-artifact@v6"}
    assert job["env"]["KEYSTORE_B64"] == "${{ secrets.GMK_SIGNING_KEYSTORE_BASE64 }}"
    run_steps = {step["name"]: step["run"] for step in job["steps"] if "run" in step}
    for script in run_steps.values():
        checked = subprocess.run(["bash", "-n"], input=script, capture_output=True, text=True)
        assert checked.returncode == 0, checked.stderr
    bootstrap = run_steps["Prepare source and verify inputs"]
    guards = []
    with tempfile.TemporaryDirectory(prefix="gmk-v0740-workflow-qa-") as work:
        temp = Path(work)
        extracted = temp / "extracted"
        extracted.mkdir()
        project = minimal_project(extracted)
        _, selected = execute(bootstrap, extracted, temp / "run-extracted")
        assert selected == project.resolve()
        guards.append("exact_yaml_extracted_project_prepare")
        zipped = temp / "zipped"
        zipped.mkdir()
        make_zip(project, zipped / release.SOURCE_ZIP)
        _, selected = execute(bootstrap, zipped, temp / "run-zipped")
        assert selected and release.verify_package_manifest(selected) > 0
        guards.append("exact_yaml_source_zip_prepare")
        bad = temp / "missing"
        bad.mkdir()
        rejected, _ = execute(bootstrap, bad, temp / "run-missing", False)
        assert "keep one v0.7.40 source ZIP" in rejected.stderr
        guards.append("missing_source")
        other = extracted / "other"
        shutil.copytree(project, other)
        rejected, _ = execute(bootstrap, extracted, temp / "run-multiple", False)
        assert "keep one" in rejected.stderr
        shutil.rmtree(other)
        guards.append("multiple_source_projects")
        metadata = project / "app/build.gradle.kts"
        original = metadata.read_bytes()
        metadata.write_text(original.decode().replace("versionCode = 110", "versionCode = 109"))
        manifest(project)
        rejected, _ = execute(bootstrap, extracted, temp / "run-version", False)
        assert "wrong applicationId or production version" in rejected.stderr
        metadata.write_bytes(original)
        manifest(project)
        guards.append("wrong_application_version")
        fixture = project / "tools/direct19_feature_fixture.bin"
        original = fixture.read_bytes()
        fixture.write_bytes(b"corrupt")
        manifest(project)  # Force fixture-specific validation rather than package SHA gate.
        rejected, _ = execute(bootstrap, extracted, temp / "run-fixture", False)
        assert "missing or corrupted observed-price fixture" in rejected.stderr
        fixture.write_bytes(original)
        manifest(project)
        guards.append("corrupted_observed_fixture")
        asset = project / "app/src/main/assets/october_similarity/index.bin.gz"
        original = asset.read_bytes()
        asset.write_bytes(b"corrupt")
        rejected, _ = execute(bootstrap, extracted, temp / "run-asset", False)
        assert "source package integrity failure" in rejected.stderr
        asset.write_bytes(original)
        guards.append("corrupted_source_asset")
        rejected, _ = execute(bootstrap, extracted, temp / "run-secrets", False,
                              {"KEYSTORE_B64": "c3ludGhldGlj"})
        assert "partial signing secrets" in rejected.stderr
        assert not (temp / "run-secrets/gmk-v0740.keystore").exists()
        guards.append("partial_signing_secrets_before_build")
        expect_reject(lambda: release.signing_mode(dict(KEYSTORE_B64="not base64", STORE_PASSWORD="x", KEY_ALIAS="x", KEY_PASSWORD="x")), "valid base64")
        expect_reject(lambda: release.signing_mode(dict(EXPECTED_CERT_SHA256="00")), "expected certificate")
        assert release.signing_mode({}) == "test-only-debug-production-unsigned"
        guards.extend(["invalid_signing_base64", "invalid_expected_certificate", "no_secrets_is_test_only"])
        for name, entries, reason in [
            ("traversal", [("../../escape.txt", b"x", None)], "unsafe ZIP path"),
            ("absolute", [("/escape.txt", b"x", None)], "unsafe ZIP path"),
            ("drive", [("C:/escape.txt", b"x", None)], "unsafe ZIP path"),
            ("backslash_traversal", [("..\\..\\escape.txt", b"x", None)], "unsafe ZIP path"),
            ("symlink", [("link", b"../escape", stat.S_IFLNK | 0o777)], "links and special"),
            ("duplicate", [("same", b"a", None), ("same", b"b", None)], "duplicate ZIP target")]:
            archive = temp / (name + ".zip")
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", UserWarning)
                with zipfile.ZipFile(archive, "w") as source:
                    for path, content, mode in entries:
                        info = zipfile.ZipInfo(path)
                        if mode:
                            info.create_system = 3
                            info.external_attr = mode << 16
                        source.writestr(info, content)
            expect_reject(lambda: release.safe_extract(archive, temp / (name + "-out")), reason)
            guards.append("zip_" + name)
        assert not (temp.parent / "escape.txt").exists()
        # Exercise a source ZIP + a separately uploaded asset data ZIP.
        parts_dir = temp / "parts"
        parts_dir.mkdir()
        part_name = "GMK_MOBILE_V0740_DATA_PART01.zip"
        path = str(asset.relative_to(project))
        with zipfile.ZipFile(parts_dir / part_name, "w") as archive:
            archive.write(asset, path)
        part_manifest = {"format_version": 1,
                         "parts": [{"filename": part_name, "bytes": (parts_dir / part_name).stat().st_size,
                                    "sha256": release.sha256(parts_dir / part_name)}],
                         "files": [{"path": path, "bytes": asset.stat().st_size, "sha256": release.sha256(asset)}]}
        (project / "DATA_PARTS_MANIFEST.json").write_text(json.dumps(part_manifest))
        manifest(project)
        make_zip(project, parts_dir / release.SOURCE_ZIP, omitted=[path])
        _, selected = execute(bootstrap, parts_dir, temp / "run-parts")
        assert selected and (selected / path).read_bytes() == asset.read_bytes()
        guards.append("exact_yaml_source_zip_plus_data_part")
        source_copy = parts_dir / (Path(release.SOURCE_ZIP).stem + " (2)(1).zip")
        part_copy = parts_dir / (Path(part_name).stem + " (1).zip")
        (parts_dir / release.SOURCE_ZIP).rename(source_copy)
        (parts_dir / part_name).rename(part_copy)
        _, selected = execute(bootstrap, parts_dir, temp / "run-browser-suffix")
        assert selected and (selected / path).read_bytes() == asset.read_bytes()
        guards.append("numeric_browser_source_and_data_suffix")
        shutil.copyfile(source_copy, parts_dir / release.SOURCE_ZIP)
        rejected, _ = execute(bootstrap, parts_dir, temp / "run-duplicate-source-suffix", False)
        assert "keep one" in rejected.stderr
        guards.append("duplicate_source_numeric_suffix")
        source_copy.unlink()
        shutil.copyfile(part_copy, parts_dir / part_name)
        rejected, _ = execute(bootstrap, parts_dir, temp / "run-duplicate-part-suffix", False)
        assert "upload exactly one required data ZIP" in rejected.stderr
        guards.append("duplicate_data_numeric_suffix")
        part_copy.unlink()
        arbitrary_source = parts_dir / (Path(release.SOURCE_ZIP).stem + "-backup.zip")
        (parts_dir / release.SOURCE_ZIP).rename(arbitrary_source)
        rejected, _ = execute(bootstrap, parts_dir, temp / "run-arbitrary-source-suffix", False)
        assert "keep one" in rejected.stderr
        arbitrary_source.rename(parts_dir / release.SOURCE_ZIP)
        guards.append("non_numeric_source_suffix_rejected")
        arbitrary_part = parts_dir / (Path(part_name).stem + "-backup.zip")
        (parts_dir / part_name).rename(arbitrary_part)
        rejected, _ = execute(bootstrap, parts_dir, temp / "run-arbitrary-part-suffix", False)
        assert "upload exactly one required data ZIP" in rejected.stderr
        arbitrary_part.rename(parts_dir / part_name)
        guards.append("non_numeric_data_suffix_rejected")
        original = (parts_dir / part_name).read_bytes()
        (parts_dir / part_name).write_bytes(original + b"corrupt")
        rejected, _ = execute(bootstrap, parts_dir, temp / "run-corrupt-part", False)
        assert "missing or corrupted data ZIP" in rejected.stderr
        guards.append("corrupted_data_part")
        (parts_dir / part_name).write_bytes(original)
        (parts_dir / part_name).unlink()
        rejected, _ = execute(bootstrap, parts_dir, temp / "run-missing-part", False)
        assert "upload exactly one required data ZIP" in rejected.stderr
        guards.append("missing_data_part")
        # APK fixtures below are ordinary ZIPs, never compiled Android APKs.
        apk = temp / "synthetic-assets-only.apk"
        source_assets = project / "app/src/main/assets"
        with zipfile.ZipFile(apk, "w") as archive:
            for file in source_assets.rglob("*"):
                if file.is_file():
                    archive.write(file, "assets/" + str(file.relative_to(source_assets)))
        assert release.verify_apk_assets(apk, project)["assets_verified"] == 2
        with zipfile.ZipFile(apk, "w") as archive:
            archive.writestr("assets/october_similarity/manifest.json", b"altered")
            archive.write(asset, "assets/october_similarity/index.bin.gz")
        expect_reject(lambda: release.verify_apk_assets(apk, project), "packaged asset differs")
        guards.extend(["all_packaged_assets_verified_synthetic_zip", "altered_packaged_assets"])
        test_reports(project)
        guards.extend(["missing_required_suite", "skipped_tests", "new_test_class_must_execute", "new_suites_allowed"])
        real_prepared = False
        if args.source:
            real = temp / "real-release"
            real.mkdir()
            shutil.copyfile(args.source, real / args.source.name)
            for part in args.data_parts:
                shutil.copyfile(part, real / part.name)
            _, selected = execute(bootstrap, real, temp / "run-real")
            assert selected and release.verify_package_manifest(selected) > 0
            real_prepared = True
    result = {"status": "PASS_WORKFLOW_LOGIC_QA", "workflow_bytes": args.workflow.stat().st_size,
              "exact_yaml_bootstrap_executed": True, "yaml_and_bash_syntax_valid": True,
              "source_preparation_cases": guards, "case_count": len(guards),
              "real_final_distribution_preparation_executed": real_prepared,
              "synthetic_cases_are_android_builds": False, "android_unit_tests_executed": False,
              "production_signature_applied": False, "remote_github_actions_run": False,
              "workflow_sha256": release.sha256(args.workflow), "helper_sha256": release.sha256(ROOT / "tools/build_release.py")}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()

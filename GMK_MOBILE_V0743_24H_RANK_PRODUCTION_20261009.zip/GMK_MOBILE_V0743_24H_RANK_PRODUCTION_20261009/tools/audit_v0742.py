"""Source and immutable asset gates for the authorized chart200 label overlay.

Original numerical/action/settlement guards remain; explicitly changed source
bytes are pinned separately. Android tests and APK gates are mandatory elsewhere.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def audit():
    spec = importlib.util.spec_from_file_location('v0741_audit', ROOT/'tools/audit_v0741.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0742_source_extension.json').read_text())
    changes = manifest['modified_existing']
    gradle = (ROOT/'app/build.gradle.kts').read_text()
    assessment = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/CandidateAssessment.kt').read_text()
    runtime = (ROOT/'app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt').read_text()
    for row in result['results']:
        name = row['check']
        prefixes = ('unchanged:', 'authorized_assessment_extension:')
        path = next((name[len(prefix):] for prefix in prefixes if name.startswith(prefix)), None)
        if path in changes:
            row.update(check='authorized_v0742_chart_overlay:'+path,
                       **{'pass':sha(ROOT/path)==changes[path]['updated_sha256']},
                       detail='Exact source bytes pinned; original operational action replay is mandatory.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*112\b',gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.42-chart-rank"' in gradle
        elif name == 'strength_is_explicitly_unvalidated':
            row['pass'] = 'val strengthStatus: String get() = "UNVALIDATED"' in assessment and '強弱未検証' in assessment
        elif name == 'fatal_errors_not_swallowed':
            fatal = [(str(p.relative_to(ROOT)), m.group(1))
                     for p in (ROOT/'app/src/main/java').rglob('*') if p.suffix in {'.kt','.java'}
                     for m in re.finditer(r'catch\s*\([^)]*:\s*(Throwable|Error|VirtualMachineError|OutOfMemoryError|LinkageError|ThreadDeath)\b',p.read_text())]
            row['pass'] = fatal == [('app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt','OutOfMemoryError')]*5
            row['detail'] = 'Three original optional-model boundaries plus chart model loading/preparation; no broad Throwable/Error catches.'
    def check(name, ok, detail=None):
        row={'check':name,'pass':bool(ok)}
        if detail is not None: row['detail']=detail
        result['results'].append(row)
    allowed = {
        'app/src/main/java/jp/gmk/mobile/MainActivity.kt',
        'app/src/main/java/jp/gmk/mobile/MarketScreens.kt',
        'app/src/main/java/jp/gmk/mobile/data/AssessmentJsonCodec.kt',
        'app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt',
        'app/src/main/java/jp/gmk/mobile/data/HistoryStore.kt',
        'app/src/main/java/jp/gmk/mobile/domain/CandidateAssessment.kt',
        'app/src/main/java/jp/gmk/mobile/domain/Models.kt',
        'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt',
    }
    check('only_authorized_original_main_files_changed',set(changes)<=allowed)
    for path, digest in manifest['all_original_main_files'].items():
        expected = changes[path]['updated_sha256'] if path in changes else digest
        check('v0741_baseline_or_pinned_overlay:'+path,(ROOT/path).is_file() and sha(ROOT/path)==expected)
    for path, digest in manifest['new_source_files'].items():
        check('pinned_new_chart_source:'+path,(ROOT/path).is_file() and sha(ROOT/path)==digest)
    start = runtime.index('        if(native.source!="AUTO")return native',runtime.index('private fun applyOperational('))
    end = runtime.index('    /** Persist policy',start)
    check('entire_original_operational_apply_body_identical',
          hashlib.sha256(runtime[start:end].encode()).hexdigest()==manifest['protected_operational_apply_body_sha256'])
    check('chart_preparation_is_separate_child_job', 'chartRankPreparation=launch(Dispatchers.Default)' in runtime
          and 'if(isActive && enabled() && epochMillis()<(boundary-10)*1000)' in runtime)
    adapter=(ROOT/'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankAdapter.kt').read_text()
    check('only_native_top1_E_SKIP_label_overlay','top.grade != "E" || top.decision != "SKIP"' in adapter
          and 'chosen.decision != "SKIP" || chosen.grade != "E"' in adapter)
    check('chart_result_bound_to_symbol_boundary_direction_and_features',all(x in adapter for x in (
        'result.querySymbol != chosen.instrument','result.queryBoundaryUtc != boundary',
        'result.direction != chosen.direction','ChartConditionalRankIndex.chartFeatureHash(actual)')))
    check('unranked_not_forced_into_H','val displayedGrade = if (grade == "UNRANKED") chosen.grade else grade' in adapter)
    asset_root=ROOT/'app/src/main/assets/october_chart_rank'
    assets=json.loads((asset_root/'chart_rank_manifest.json').read_text())
    check('chart_bank_packaged_once_as_exact_two_parts',
          {p.name for p in asset_root.iterdir() if p.is_file()} == {
              'index.bin.gz.part01','index.bin.gz.part02','chart_rank_manifest.json',
              'chart_rank_frozen_calibration.json','chart_rank_frozen_relative_grades.json'})
    for item in assets['parts']:
        file=asset_root/item['file']
        check('immutable_full_chart_bank_part:'+item['file'],file.is_file() and file.stat().st_size==item['bytes'] and sha(file)==item['sha256'])
    check('full_eligible_bank_270501', assets.get('eligible_rows')==270501 or assets.get('eligible_bank_rows')==270501 or assets.get('row_count')==270501)
    check('calibration_future_strength_not_claimed', 'UNVALIDATED' in assessment and 'E〜Hは元E候補' in (ROOT/'app/src/main/java/jp/gmk/mobile/MainActivity.kt').read_text())
    tests=ROOT/'app/src/test/java'
    check('chart_runtime_history_ui_tests_present',all((tests/(n+'.kt')).is_file() for n in (
        'ChartConditionalRankRuntimeTest','ChartRankAssessmentPersistenceTest','ChartRankUiTest')))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
        scope='V0742_SOURCE_AND_FULL_BANK_GUARDS; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
        checks=len(result['results']),failed=[r['check'] for r in result['results'] if not r['pass']],
        current_version='0.7.42-chart-rank',strength_model_adopted=True,
        future_strength_order_proven=False,actual_phone_installed=False)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args()
    result=audit()
    if args.output: args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','checks','failed','scope']},ensure_ascii=False))
    raise SystemExit(0 if result['status']=='PASS' else 1)

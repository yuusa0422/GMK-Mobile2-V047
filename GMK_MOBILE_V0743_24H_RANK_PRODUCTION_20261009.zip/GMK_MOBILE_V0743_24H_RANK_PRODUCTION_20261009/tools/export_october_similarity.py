#!/usr/bin/env python3
"""Rebuild an audited exact observed technical35 index and October replay fixtures.

Requires original research NPZs, not supplied in mobile source distribution. Release
assets are already built. Never downloads input or invents missing labels/prices.
"""
import argparse, gzip, hashlib, io, json, struct, zipfile, tempfile
from pathlib import Path
import numpy as np
import pandas as pd

PROJECT=Path(__file__).resolve().parents[1]
DEFAULT_WORK=PROJECT.parents[1]
POLICY='TECH_WEEKDAY_HOUR_K100__C_M10'
SYMBOLS=['USDJPY','EURJPY','GBPJPY','AUDJPY']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def export(research,neighbor,recent=None):
    asset=PROJECT/'app/src/main/assets/october_similarity';asset.mkdir(parents=True,exist_ok=True)
    fixtures=PROJECT/'tools/october_fixtures';fixtures.mkdir(parents=True,exist_ok=True)
    src=[];sets=[]
    for year in [2024,2025,2026]:
        path=research/'data'/f'features_{year}.npz'
        z=np.load(path,allow_pickle=False)
        assert list(z['symbols'])==SYMBOLS and z['X'].shape[2]==35
        sets.append({k:z[k].copy() for k in ['boundaries','X','Y','valid']})
        src.append(dict(year=year,filename=path.name,sha256=sha(path),archive_integrity_verified=year!=2024,recovered=year==2024))
    data={k:np.concatenate([d[k] for d in sets]) for k in sets[0]};order=np.argsort(data['boundaries'])
    for k in data:data[k]=data[k][order]
    known_cutoff=int(pd.Timestamp('2026-10-08 23:44:36',tz='Asia/Tokyo').timestamp())
    eligible=(data['boundaries']+300<known_cutoff)[:,None]&data['valid']&(data['Y']>=0).all(axis=2)&np.isfinite(data['X']).all(axis=2)
    last=int(data['boundaries'][eligible.any(axis=1)].max());raw=io.BytesIO()
    raw.write(struct.pack('>iiiiq',0x474d4b4f,1,4,35,last));counts=[]
    for s in range(4):
        ix=np.flatnonzero(eligible[:,s]);counts.append(len(ix));raw.write(struct.pack('>i',len(ix)))
        for i in ix:
            raw.write(struct.pack('>qBB',int(data['boundaries'][i]),int(data['Y'][i,s,0]),int(data['Y'][i,s,1])))
            raw.write(np.asarray(data['X'][i,s],dtype='>f4').tobytes())
    rawbytes=raw.getvalue();target=Path(tempfile.gettempdir())/'gmk_october_index.bin.gz'
    with target.open('wb') as f:
        with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9) as gz:gz.write(rawbytes)
    digest=hashlib.sha256(rawbytes).hexdigest()
    compressed=target.read_bytes();chunks=[];chunk_size=(len(compressed)+3)//4
    for i in range(4):
        part=asset/f'index.bin.gz.part{i+1:02}';part.write_bytes(compressed[i*chunk_size:(i+1)*chunk_size]);chunks.append(dict(filename=part.name,bytes=part.stat().st_size,sha256=sha(part)))
    legacy=asset/'index.bin.gz'
    if legacy.exists():legacy.unlink()
    provenance_path=research/'recovered_2024/FORENSIC_4FX_SENSITIVITY_PROVENANCE.json'
    proof=json.loads(provenance_path.read_text())
    manifest=dict(schema=1,available_from_utc=1791471600,policy=POLICY,policy_version='GMK_V0740_TECH_WEEKDAY_HOUR_K100_C_M10',feature_count=35,feature_names=list(np.load(research/'data/features_2026.npz')['feature_names']),symbols=SYMBOLS,horizons_seconds=[180,300],
        asset='index.bin.gz.part01..04',asset_chunks=chunks,asset_sha256=sha(target),uncompressed_sha256=digest,uncompressed_bytes=len(rawbytes),compressed_bytes=target.stat().st_size,rows_by_symbol=dict(zip(SYMBOLS,counts)),
        known_data_export_asof_utc=known_cutoff,last_bundled_boundary_utc=last,last_bundled_label_utc=last+300,source_data_through_jst='2026-10-06',
        raw_2026_august_19_31_missing=True,october_7_8_not_supplied=True,source_features=src,
        recovered_2024_archive_integrity_verified=False,recovered_2024_target_4fx_observed_values=True,recovered_2024_provenance_sha256=sha(provenance_path),recovered_2024_database_sha256=proof['output_sha256'],
        historical_MT5_broker_clock_2024_2025_assumption='same Europe/Helsinki broker clock convention as empirically validated 2026',
        nearest_neighbors=100,minimum_filtered_training_rows=400,distance='same-symbol standardized Euclidean',
        scaler='StandardScaler population mean/variance over all eligible same-symbol past rows',temporal_bucket='weekday+hour if400 else weekday if400 else all',
        vote='.8 inverse-distance local + .2 selected-bucket class prior',correction_margin_float32=.10,
        training_snapshot='daily09:00JST; B+300 strictly before cutoff',native_entry_preserved=True,native_grades_protected=['S','A','B'],
        production_scope='October weekdays09:00 through17:00 inclusive; AUTO only; same four JPY symbols; nativeC only',
        live_journal='CRC32 actual completed M1 OPEN labels; observed sparse device history only; available next daily09snapshot; gaps never filled',
        production_vs_replay='Replay covers four known October days with daily snapshots. Future deployment begins with supplied history throughOct6 plus actual device journal; days7/8 full-history unavailable. Historical59.80% is not a guaranteed future rate.')
    write_json(asset/'manifest.json',manifest)
    cat=PROJECT/'app/src/main/java/jp/gmk/mobile/domain/october/OctoberSimilarityCatalog.kt'
    cat.write_text('''package jp.gmk.mobile.domain.october

import android.content.res.AssetManager
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.SequenceInputStream
import java.util.Enumeration

object OctoberSimilarityCatalog {
    const val AVAILABLE_FROM = 1791471600L
    const val RAW_SHA256 = "%s"
    const val BUNDLED_LAST_BOUNDARY = %dL
    /** Open one compressed part at a time. Closing after an error must not open
     * untouched future parts: SequenceInputStream.close otherwise drains its enum. */
    private fun load(open: (String) -> InputStream): OctoberSimilarityIndex {
        val parts=(1..4).iterator()
        var stopped=false
        val streams=object : Enumeration<InputStream> {
            override fun hasMoreElements()=!stopped && parts.hasNext()
            override fun nextElement(): InputStream {
                val path="october_similarity/index.bin.gz.part" + parts.next().toString().padStart(2,'0')
                return open(path)
            }
        }
        return SequenceInputStream(streams).use {
            try { OctoberSimilarityIndex.readCompressed(it,RAW_SHA256) }
            finally { stopped=true }
        }
    }
    fun loadIndex(assets: AssetManager): OctoberSimilarityIndex = load { assets.open(it) }
    fun loadIndex(assetBytes: (String) -> ByteArray): OctoberSimilarityIndex = load { ByteArrayInputStream(assetBytes(it)) }
}
'''%(digest,last))
    # The untouched research probability and policy ledger are the independent oracle.
    native=np.load(research/'checkpoint/research_workspace/GMK_PC_R13_COMMON_PRICE_COMPARE_20261008/frames.npz',allow_pickle=False)
    native_lookup={int(b):i for i,b in enumerate(native['boundaries'])};lookup={int(b):i for i,b in enumerate(data['boundaries'])}
    rows=[];oracles=[]
    for day in ['2026-10-01','2026-10-02','2026-10-05','2026-10-06']:
        pp=neighbor/f'{day}_probabilities.npz';ll=neighbor/f'{day}_ledger.csv.gz';p=np.load(pp,allow_pickle=False)
        pi=list(p['strategies']).index('TECH_WEEKDAY_HOUR_K100');ledger=pd.read_csv(ll);ledger=ledger[ledger.policy==POLICY].set_index('boundary_utc')
        oracles.append(dict(probabilities_file=pp.name,probabilities_sha256=sha(pp),ledger_file=ll.name,ledger_sha256=sha(ll)))
        for q,b in enumerate(p['boundaries']):
            b=int(b);i=lookup[b];ni=native_lookup[b];n=int(native['original_action'][ni]);row=ledger.loc[b]
            expected=-1 if int(row.action)<0 else int(row.action)//2*4+(int(row.horizon_minutes)==5)*2+int(row.action)%2
            rows.append((b,4*(n//2)+n%2 if n>=0 else -1,bool(native['native_entry'][ni]),str(native['original_grade'][ni]),bool(row.common_mother),expected,data['X'][i],data['valid'][i],p['prob'][q,pi],bool(row.win),int(row.label)))
    f=io.BytesIO();f.write(struct.pack('>ii',0x474d4b46,len(rows)))
    for b,n,e,g,common,expected,x,valid,p,w,label in rows:
        grade=ord(g) if len(g)==1 else 0
        f.write(struct.pack('>qiBBBBii',b,n,int(e),grade,int(common),int(w),expected,label))
        f.write(valid.astype(np.uint8).tobytes());f.write(np.asarray(x,dtype='>f4').tobytes());f.write(np.asarray(p,dtype='>f4').tobytes())
    fixture=fixtures/'october_replay.bin';fixture.write_bytes(f.getvalue())
    write_json(fixtures/'manifest.json',dict(schema=1,fixture_sha256=sha(fixture),rows=len(rows),oracles=oracles,native_frames_sha256=sha(research/'checkpoint/research_workspace/GMK_PC_R13_COMMON_PRICE_COMPARE_20261008/frames.npz'),all_four_october_days=True,expected_primary_entries=204,expected_primary_wins=122,expected_primary_max_loss=5,entry_unchanged=True,source_features=src))
    # Actual supplied GMO M1 candles exercise technical feature arithmetic, times,
    # wick/ATR/streak/day-of-week. Synthetic flat bars additionally cover zero divisors.
    if recent:
        raw_by={}
        with zipfile.ZipFile(recent) as z:
            for s in SYMBOLS:
                members=[n for n in z.namelist() if n.endswith(f'1M/{s}_1m_JST.csv')];assert len(members)==1
                df=pd.read_csv(io.BytesIO(z.read(members[0])),encoding='utf-8-sig')
                dt=pd.to_datetime(df.datetime_jst,utc=True).astype('datetime64[ns, UTC]');ts=dt.astype('int64').to_numpy()//1_000_000_000
                bars=df[['open','high','low','close']].to_numpy();raw_by[s]=dict(zip(ts,bars))
        cases=[]
        for day in ['2026-10-01','2026-10-02','2026-10-05','2026-10-06']:
            mask=pd.to_datetime(data['boundaries'],unit='s',utc=True).tz_convert('Asia/Tokyo').strftime('%Y-%m-%d')==day
            ix=np.flatnonzero(mask&data['valid'].all(axis=1))[::13]
            for i in ix:
                b=int(data['boundaries'][i])
                for s,symbol in enumerate(SYMBOLS):
                    bars=np.array([raw_by[symbol][b-3720+j*60] for j in range(61)])
                    cases.append(dict(boundary_utc=b,symbol=symbol,bars=bars.tolist(),features=data['X'][i,s].tolist()))
        feature_out=io.BytesIO();feature_out.write(struct.pack('>ii',0x474d4b54,len(cases)))
        for c in cases:
            feature_out.write(struct.pack('>q',c['boundary_utc']));feature_out.write(np.asarray(c['bars'],dtype='>f8').tobytes());feature_out.write(np.asarray(c['features'],dtype='>f4').tobytes())
        target2=fixtures/'technical_features.bin';target2.write_bytes(feature_out.getvalue())
        write_json(fixtures/'technical_feature_manifest.json',dict(rows=len(cases),fixture_sha256=sha(target2),source_recent_zip_sha256=sha(recent),source_features_sha256=src[-1]['sha256'],bars='Actual observed M1 OHLC, consecutive61, lastOPENB-120',future_bar_not_included=True))
    print(json.dumps(dict(status='EXPORTED',asset_bytes=target.stat().st_size,raw_sha256=digest,rows_by_symbol=counts,fixture_rows=len(rows))))
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--research',type=Path,default=DEFAULT_WORK/'gmk_similarity_research');parser.add_argument('--neighbor',type=Path,default=DEFAULT_WORK/'gmk_october_friday_research/neighbor_outputs');parser.add_argument('--recent',type=Path,default=DEFAULT_WORK/'gmk_similarity_inputs/GMK_HISTORY_20260901_20261006 (2)(1).zip');a=parser.parse_args();export(a.research,a.neighbor,a.recent if a.recent.is_file() else None)

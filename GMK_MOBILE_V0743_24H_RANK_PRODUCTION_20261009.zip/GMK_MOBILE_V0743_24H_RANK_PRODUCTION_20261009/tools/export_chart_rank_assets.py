#!/usr/bin/env python3
"""Export the full, frozen and outcome-unselected October chart200 bank.

Only strictly pre-October finite observations are retained. Original row IDs,
float32 chart features and three-minute labels are losslessly exported. Median,
linear IQR and direction priors are computed using that entire eligible bank.
The existing frozen calibration and relative grades are copied without fitting.
"""
from __future__ import annotations
import argparse, gzip, hashlib, io, json, shutil, struct, sys
from pathlib import Path
import numpy as np

CUTOFF = 1790780400
POOL_SHA = '7d3a8d49769109589c4addeeef52bb480054950672983a235cb8148e99958ac3'
CALIB_SHA = '881261226786fc9880ffaa50a55995391bf3c2f91175e4663f7a10587ce2f6cc'
GRADE_SHA = '417014ef8fb606d6f8af76e9bea010d35b551990ae9ad9c4a9419a5f104efdfc'
CORE_SHA = '2199e047b7fd5a4feefc1c573d1fdb7b5b3143b0364c0124e5c8f222b2553148'
SYMBOLS = ('USDJPY','EURJPY','GBPJPY','AUDJPY')

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def export(study, destination):
    study, destination = Path(study), Path(destination)
    source = study/'inputs/historical_pool.npz'
    calibration = study/'outputs/FROZEN_CALIBRATION_MODEL.json'
    grades = study/'outputs/FROZEN_EMPIRICAL_GRADE_MODEL.json'
    for path, expected in ((source,POOL_SHA),(calibration,CALIB_SHA),(grades,GRADE_SHA),
                           (study/'engine/chart_similarity.py',CORE_SHA)):
        if sha(path) != expected: raise ValueError(f'Frozen source SHA mismatch: {path.name}')
    sys.path.insert(0,str(study))
    from engine.calibration import _validate_state
    from engine.empirical_grades import fit_relative_grades
    state=json.loads(calibration.read_text());grade=json.loads(grades.read_text())
    _validate_state(state)
    if grade != fit_relative_grades(state) or not grade['four_levels_supported']:
        raise ValueError('Frozen supported relative grade mapping mismatch')
    pool=np.load(source,allow_pickle=False)
    if tuple(pool['symbols'])!=SYMBOLS:raise ValueError('Symbol order mismatch')
    b=pool['boundary_utc'];a=pool['available_utc'];s=pool['symbol_index'];x=pool['X'];y=pool['label3']
    mask=(a<CUTOFF)&(b<CUTOFF)&np.isfinite(x[:,:30]).all(axis=1)
    if int(mask.sum())!=270501:raise ValueError('Full eligible bank count mismatch')
    if not (a>b).all() or not np.isin(y,[0,1,2]).all():raise ValueError('Invalid observed labels')
    if not np.array_equal(np.lexsort((s,b)),np.arange(len(b))):raise ValueError('Original canonical row order mismatch')
    out=io.BytesIO()
    def pack(fmt,*values):out.write(struct.pack('>'+fmt,*values))
    def utf(text):
        data=text.encode('ascii');pack('H',len(data));out.write(data)
    pack('iiiiqi',0x474d4352,1,4,30,CUTOFF,int(mask.sum()))
    for value in (POOL_SHA,CALIB_SHA,GRADE_SHA,CORE_SHA):utf(value)
    pack('?ddii',state['support_flag'],state['training_raw_min'],state['training_raw_max'],
         state['training_count'],len(state['blocks']))
    for edge in state['step_boundaries']:pack('d',edge)
    for block in state['blocks']:
        pack('iiiddd',block['count'],block['wins'],block['unique_dates'],block['probability'],
             *block['wilson_95_case_interval'])
    pack('i',grade['supported_level_count'])
    for edge in grade['probability_boundaries']:pack('d',edge)
    for label in grade['labels_ascending']:utf(label)
    symbol_manifest=[]
    dtype=np.dtype([('id','>i4'),('boundary','>i8'),('available_delta','>i4'),('label','u1'),('x','>f4',(30,))])
    for symbol_index,symbol in enumerate(SYMBOLS):
        ids=np.flatnonzero(mask&(s==symbol_index));features=x[ids,:30].astype(np.float64)
        q=np.quantile(features,[.25,.5,.75],axis=0,method='linear');median=q[1];iqr=q[2]-q[0];iqr[iqr<1e-8]=1.
        prior_low=float(np.mean(y[ids]==0));prior_high=float(np.mean(y[ids]==2))
        pack('i',len(ids));out.write(median.astype('>f8').tobytes());out.write(iqr.astype('>f8').tobytes());pack('dd',prior_low,prior_high)
        delta=a[ids]-b[ids]
        if not ((delta>0)&(delta<=2147483647)).all():raise ValueError('Availability delta out of range')
        records=np.empty(len(ids),dtype=dtype);records['id']=ids;records['boundary']=b[ids];records['available_delta']=delta;records['label']=y[ids];records['x']=x[ids,:30]
        out.write(records.tobytes())
        symbol_manifest.append({'symbol':symbol,'count':len(ids),'median30':median.tolist(),'linear_iqr30':iqr.tolist(),
          'low_prior':prior_low,'high_prior':prior_high,'last_available_utc':int(a[ids].max()),
          'canonical_id_sha256':hashlib.sha256(ids.astype('<i8').tobytes()).hexdigest()})
    raw=out.getvalue();compressed=gzip.compress(raw,compresslevel=9,mtime=0)
    destination.mkdir(parents=True,exist_ok=True)
    asset=destination/'index.bin.gz'
    # Android's SequenceInputStream reconstructs these exact gzip bytes. Each
    # reusable download part stays below the existing25MB transfer limit.
    split=(len(compressed)+1)//2
    parts=[]
    for number,chunk in enumerate((compressed[:split],compressed[split:]),1):
        part=destination/f'index.bin.gz.part{number:02d}';part.write_bytes(chunk)
        parts.append({'file':part.name,'bytes':len(chunk),'sha256':hashlib.sha256(chunk).hexdigest()})
    # Do not duplicate the full bank in the APK's asset directory.
    if asset.exists():asset.unlink()
    shutil.copyfile(calibration,destination/'chart_rank_frozen_calibration.json')
    shutil.copyfile(grades,destination/'chart_rank_frozen_relative_grades.json')
    manifest={'schema':1,'version':'GMK_V0742_OCTOBER_CHART200_EH','asset':asset.name,'parts':parts,
      'raw_sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(compressed).hexdigest(),
      'raw_bytes':len(raw),'gzip_bytes':len(compressed),'row_count':int(mask.sum()),'source_row_count':len(b),
      'cutoff_utc':CUTOFF,'availability_operator':'strictly_less_than','same_currency_required':True,
      'features_used':'0:30; calendar indices30:35 ignored','median_iqr_method':'all eligible same-symbol rows, numpy linear quantiles',
      'neighbor_count':200,'day_cap':4,'minimum_same_day_separation_seconds':3600,'direction_prior_pseudo_count':20,
      'support':{'neighbor_count':200,'unique_days_strictly_greater_than':50,'effective_neighbor_n_at_least':100},
      'full_bank_outcome_selection':False,'original_neighbor_ids_preserved':True,'source_pool_sha256':POOL_SHA,
      'chart_core_sha256':CORE_SHA,'frozen_calibration_file_sha256':CALIB_SHA,'frozen_grade_file_sha256':GRADE_SHA,
      'calibration_training_count':state['training_count'],'supported_rank_labels':['E','F','G','H'],
      'outside_calibration_range':'UNRANKED','query_outcome_input':False,'live_observation_append':False,
      'scope':'Former native E; weekday JST09<=hour<15; four FX JPY pairs; three-minute; October2026; grading only',
      'statistical_strength_order':'UNCONFIRMED','symbol_statistics':symbol_manifest}
    (destination/'chart_rank_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
    return manifest
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--study',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();result=export(args.study,args.output)
    print(json.dumps({k:result[k] for k in ('asset','row_count','raw_bytes','gzip_bytes','raw_sha256','gzip_sha256')},indent=2))

"""Independent full asset/fixture comparison to unchanged research source arrays.

Requires the original research workspace and NumPy. It is a release evidence
rebuild, rather than a build-time requirement to distribute all raw research data.
It neither exports assets nor changes oracle fixtures.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import struct
import numpy as np

PROJECT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(research: Path, neighbors: Path):
    assets = PROJECT / "app/src/main/assets/october_similarity"
    fixtures = PROJECT / "tools/october_fixtures"
    manifest = json.loads((assets / "manifest.json").read_text())
    check_count = 0

    def require(condition, label):
        nonlocal check_count
        assert bool(condition), label
        check_count += 1

    compressed = bytearray()
    for part in manifest["asset_chunks"]:
        file = assets / part["filename"]
        require(file.name == part["filename"] and file.stat().st_size == part["bytes"], "safe complete chunk name and length")
        require(sha(file) == part["sha256"], "chunk SHA")
        compressed.extend(file.read_bytes())
    require(hashlib.sha256(compressed).hexdigest() == manifest["asset_sha256"], "complete compressed asset SHA")
    raw = gzip.decompress(compressed)
    require(hashlib.sha256(raw).hexdigest() == manifest["uncompressed_sha256"], "raw asset SHA")
    require(len(raw) == manifest["uncompressed_bytes"], "uncompressed length")
    magic, schema, symbols, features, last = struct.unpack_from(">iiiiq", raw)
    require((magic, schema, symbols, features) == (0x474D4B4F, 1, 4, 35), "index schema")
    require(last == manifest["last_bundled_boundary_utc"], "last source boundary")

    originals = []
    for source in manifest["source_features"]:
        path = research / "data" / source["filename"]
        require(sha(path) == source["sha256"], "original feature SHA " + path.name)
        loaded = np.load(path, allow_pickle=False)
        require(list(loaded["symbols"]) == manifest["symbols"], "symbol order")
        originals.append({k: loaded[k] for k in ["boundaries", "X", "Y", "valid"]})
    data = {key: np.concatenate([row[key] for row in originals]) for key in originals[0]}
    order = np.argsort(data["boundaries"])
    data = {key: value[order] for key, value in data.items()}
    source_eligible = ((data["boundaries"] + 300 < manifest["known_data_export_asof_utc"])[:, None]
                       & data["valid"] & (data["Y"] >= 0).all(axis=2)
                       & np.isfinite(data["X"]).all(axis=2))
    dtype = np.dtype([("boundary", ">i8"), ("y3", "u1"), ("y5", "u1"), ("x", ">f4", (35,))])
    pos = 24
    totals = {}
    for symbol, name in enumerate(manifest["symbols"]):
        n = struct.unpack_from(">i", raw, pos)[0]
        pos += 4
        require(n == manifest["rows_by_symbol"][name], "declared symbol row count")
        rows = np.frombuffer(raw, dtype=dtype, count=n, offset=pos)
        pos += n * dtype.itemsize
        subset = np.flatnonzero(source_eligible[:, symbol])
        require(n == len(subset), "no missing or invented observed row " + name)
        require(np.array_equal(rows["boundary"], data["boundaries"][subset]), "all observed boundaries " + name)
        require(np.array_equal(rows["x"], data["X"][subset, symbol]), "every feature float exact " + name)
        require(np.array_equal(rows["y3"], data["Y"][subset, symbol, 0]), "every 3m OPEN label exact " + name)
        require(np.array_equal(rows["y5"], data["Y"][subset, symbol, 1]), "every 5m OPEN label exact " + name)
        require(np.all(np.diff(rows["boundary"]) > 0), "strict unique chronological rows " + name)
        totals[name] = n
    require(pos == len(raw), "asset has no trailing data")

    fm = json.loads((fixtures / "manifest.json").read_text())
    fixture_bytes = (fixtures / "october_replay.bin").read_bytes()
    require(hashlib.sha256(fixture_bytes).hexdigest() == fm["fixture_sha256"], "frozen replay fixture SHA")
    fixture_magic, n = struct.unpack_from(">ii", fixture_bytes)
    require(fixture_magic == 0x474D4B46 and n == fm["rows"], "replay schema")
    fixture_dtype = np.dtype([
        ("boundary", ">i8"), ("native_action", ">i4"), ("entry", "u1"), ("grade", "u1"),
        ("common", "u1"), ("win", "u1"), ("expected_action", ">i4"), ("label", ">i4"),
        ("valid", "u1", (4,)), ("x", ">f4", (4, 35)), ("probability", ">f4", (4, 2, 3))])
    require(len(fixture_bytes) == 8 + n * fixture_dtype.itemsize, "replay complete binary length")
    rows = np.frombuffer(fixture_bytes, dtype=fixture_dtype, count=n, offset=8)
    lookup = {int(boundary): i for i, boundary in enumerate(data["boundaries"])}
    indices = [lookup[int(boundary)] for boundary in rows["boundary"]]
    require(np.array_equal(rows["valid"], data["valid"][indices]), "every replay availability exact")
    require(np.array_equal(rows["x"], data["X"][indices], equal_nan=True), "every replay query feature exact")

    expected_prob = []
    for source in fm["oracles"]:
        prob = neighbors / source["probabilities_file"]
        ledger = neighbors / source["ledger_file"]
        require(sha(prob) == source["probabilities_sha256"], "untouched probability oracle SHA")
        require(sha(ledger) == source["ledger_sha256"], "untouched policy ledger SHA")
        z = np.load(prob, allow_pickle=False)
        column = list(z["strategies"]).index("TECH_WEEKDAY_HOUR_K100")
        expected_prob.append(z["prob"][:, column])
    require(np.array_equal(rows["probability"], np.concatenate(expected_prob), equal_nan=True), "every probability oracle exact")
    native_path = research / "checkpoint/research_workspace/GMK_PC_R13_COMMON_PRICE_COMPARE_20261008/frames.npz"
    require(sha(native_path) == fm["native_frames_sha256"], "untouched native baseline SHA")
    native = np.load(native_path, allow_pickle=False)
    native_lookup = {int(b): i for i, b in enumerate(native["boundaries"])}
    ni = [native_lookup[int(b)] for b in rows["boundary"]]
    actions = native["original_action"][ni]
    mapped = np.where(actions >= 0, 4 * (actions // 2) + actions % 2, -1)
    require(np.array_equal(rows["native_action"], mapped), "all native fixture actions exact")
    require(np.array_equal(rows["entry"], native["native_entry"][ni]), "all native ENTRY masks exact")
    grades = [ord(str(v)) if len(str(v)) == 1 else 0 for v in native["original_grade"][ni]]
    require(np.array_equal(rows["grade"], grades), "all native rank fixture values exact")
    require(not manifest["recovered_2024_archive_integrity_verified"], "2024 source integrity limitation disclosed")
    require(manifest["raw_2026_august_19_31_missing"] and manifest["october_7_8_not_supplied"], "source missing days disclosed")
    return {"status": "PASS", "scope": "INDEPENDENT_FULL_INDEX_AND_ORACLE_INPUT_COMPARISON",
            "checks": check_count, "exact_observed_index_rows_by_symbol": totals,
            "exact_observed_index_rows": sum(totals.values()), "replay_query_rows": n,
            "all_index_features_and_3m_5m_labels_byte_exact": True,
            "all_replay_query_features_probabilities_native_actions_entry_ranks_exact": True,
            "index_sha256": manifest["asset_sha256"], "source_integrity_limitation_2024_retained": True,
            "android_build_executed": False, "phone_or_broker_execution_verified": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--research", required=True, type=Path)
    parser.add_argument("--neighbors", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify(args.research, args.neighbors)
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(rendered)

import jp.gmk.mobile.domain.CutInEventQueue;
import java.util.HashSet;
import java.util.Random;

/** Run with the JDK alone; virtual timestamps isolate scheduling from device/network speed. */
public final class CutInQueueHostTest {
    private static int checks;
    private static void check(boolean ok, String message) {
        checks++; if (!ok) throw new AssertionError(message);
    }
    private static void sameBoundaryResultsDoNotExpireBehindOtherImages() {
        CutInEventQueue q = new CutInEventQueue();
        for (int i = 7; i >= 0; i--) q.offerFinal("simultaneous-" + i, "USDJPY", true, 100_000, 100_000);
        HashSet<String> seen = new HashSet<>();
        for (int i = 0; i < 8; i++) {
            CutInEventQueue.Tick tick = q.advance(100_000 + i * 3_600, i * 3_600);
            check(tick.started != null, "All eight simultaneous finals must show; old 20s window lost the tail");
            check(tick.started.scanId.equals("simultaneous-" + i), "FIFO tie-break must be deterministic");
            check(seen.add(tick.started.key), "No duplicate final");
        }
        check(q.pendingCount() == 0, "Queue drained");
        check(q.maxDispatchDelayMs() == 25_200, "Last image is queued for 25.2s, not discarded at 20s");
    }
    private static void advantageThenOfficialFinalHasIndependentDedupe() {
        CutInEventQueue q = new CutInEventQueue();
        q.offerAdvantage("scan", "BTCJPY", true, true, 30_000, 15_000);
        check(q.advance(15_000, 0).started.kind == CutInEventQueue.Kind.WIN_ADVANTAGE, "Advantage starts");
        q.offerFinal("scan", "BTCJPY", false, 16_000, 16_000);
        q.offerFinal("scan", "BTCJPY", false, 16_000, 16_001);
        check(q.pendingCount() == 1, "Official final queued once while image is active");
        check(q.advance(16_000, 1_000).started == null, "No overlapping images");
        check(q.advance(18_200, 3_200).started.kind == CutInEventQueue.Kind.LOSE_FINAL, "Actual losing result follows winning advantage");
        q.offerFinal("scan", "BTCJPY", false, 16_000, 18_201);
        check(q.pendingCount() == 0, "Result never repeats after activity recreation");
    }
    private static void rotationAndLongMainWorkRetainTheActualFinal() {
        CutInEventQueue q = new CutInEventQueue();
        q.offerFinal("recreated", "EURJPY", true, 100_000, 100_000);
        check(q.advance(100_000, 500).started != null, "Starts once");
        check(q.advance(100_001, 501).started == null, "Recreated screen reuses active event without re-emitting shown");
        q.offerFinal("background", "GBPJPY", false, 101_000, 101_000);
        check(q.advance(191_000, 91_500).started.scanId.equals("background"), "90-second long work does not discard observed final");
        check(q.expiredCount() == 0, "Pending confirmed event is retained for two minutes from observation");
    }
    private static void pendingAdvantageNeverShowsAfterJudgement() {
        CutInEventQueue q = new CutInEventQueue();
        q.offerFinal("first", "AUDJPY", true, 10_000, 10_000);
        q.advance(10_000, 0);
        q.offerAdvantage("expires", "NZDJPY", false, true, 12_000, 10_000);
        check(q.advance(13_600, 3_600).current == null, "Expired advantage cannot appear after judge boundary");
        check(q.expiredCount() == 1, "Expired advantage recorded");
        q.offerFinal("expires", "NZDJPY", true, 13_600, 13_600);
        check(q.advance(13_600, 3_600).started.kind == CutInEventQueue.Kind.WIN_FINAL, "Official result remains eligible");
    }
    private static void historicAndFutureResultsAreNotReplayed() {
        CutInEventQueue q = new CutInEventQueue();
        q.offerFinal("old", "USDJPY", true, 1, 20_002);
        q.offerFinal("future", "USDJPY", true, 30_000, 20_002);
        check(q.advance(20_002, 0).current == null, "Old/future startup results rejected");
        q.offerFinal("later", "USDJPY", true, 20_002, 20_002);
        q.clearVisibleAndPending();
        check(q.advance(20_003, 1).current == null, "Disable cancels current/queued images");
    }
    private static void queueBoundKeepsConfirmedResultsAheadOfAdvantages() {
        CutInEventQueue q = new CutInEventQueue();
        for (int i = 0; i < 64; i++) q.offerAdvantage("adv" + i, "BTCJPY", true, false, 50_000, 10_000);
        q.offerFinal("confirmed", "USDJPY", false, 10_000, 10_000);
        check(q.pendingCount() == 64, "Queue memory bounded");
        check(q.advance(10_000, 0).started.scanId.equals("confirmed"), "Final priority cannot be consumed by advantages");
    }
    private static void randomizedPollingNeverRepeatsOrOverlaps() {
        Random random = new Random(740);
        for (int run = 0; run < 200; run++) {
            CutInEventQueue q = new CutInEventQueue(); HashSet<String> seen = new HashSet<>();
            long time = 100_000, elapsed = 0;
            for (int tick = 0; tick < 250; tick++) {
                if (random.nextInt(4) == 0) {
                    String id = "id" + random.nextInt(30);
                    q.offerFinal(id, "EURJPY", random.nextBoolean(), time, time);
                }
                CutInEventQueue.Tick event = q.advance(time, elapsed);
                if (event.started != null) {
                    check(seen.add(event.started.key), "Fuzz: shown once per scan/result");
                    check(event.current == event.started, "Fuzz: only one active image");
                }
                if (random.nextInt(25) == 0) q.dismiss();
                long step = 10 + random.nextInt(600); time += step; elapsed += step;
            }
        }
    }
    public static void main(String[] args) {
        sameBoundaryResultsDoNotExpireBehindOtherImages();
        advantageThenOfficialFinalHasIndependentDedupe();
        rotationAndLongMainWorkRetainTheActualFinal();
        pendingAdvantageNeverShowsAfterJudgement();
        historicAndFutureResultsAreNotReplayed();
        queueBoundKeepsConfirmedResultsAheadOfAdvantages();
        randomizedPollingNeverRepeatsOrOverlaps();
        System.out.println("PASS CutInEventQueue host scheduling: " + checks + " assertions; 200 randomized timelines");
        System.out.println("SIMULATED latency: immediate slot=0ms; eight simultaneous finals last slot=25200ms; retained long-work event=90000ms");
        System.out.println("These are virtual scheduling results, not physical-device or network latency measurements.");
    }
}

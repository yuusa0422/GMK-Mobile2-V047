#!/usr/bin/env python3
"""Independent source-bank and Java parity audit against a frozen Python oracle.

The oracle was generated separately from the Android asset exporter using the
unchanged Python research engine, all 271845 historical rows and 47 outcome-free
queries. This runner needs only Python's standard library and the JDK.
"""
from __future__ import annotations
import argparse, gzip, hashlib, json, math, shutil, struct, subprocess, tempfile, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / 'tools/chart_rank_independent'
ASSET_DIR = ROOT / 'app/src/main/assets/october_chart_rank'

def digest(data):
    return hashlib.sha256(data).hexdigest()

class Reader:
    def __init__(self, data):
        self.data = memoryview(data)
        self.pos = 0
    def read(self, n):
        if n < 0 or self.pos + n > len(self.data):
            raise AssertionError('Truncated independent audit input')
        value = self.data[self.pos:self.pos+n]
        self.pos += n
        return value
    def unpack(self, fmt):
        return struct.unpack('>'+fmt, self.read(struct.calcsize('>'+fmt)))
    def utf16(self):
        return bytes(self.read(self.unpack('H')[0])).decode('ascii')
    def finish(self):
        assert self.pos == len(self.data), 'Unexpected trailing audit input'

def audit_bank(asset_dir):
    expected = json.loads((FIXTURE/'bank_oracle.json').read_text())
    manifest = json.loads((asset_dir/'chart_rank_manifest.json').read_text())
    compressed = compressed_asset(asset_dir,manifest)
    raw = gzip.decompress(compressed)
    assert len(raw) == manifest['raw_bytes']
    assert len(compressed) == manifest['gzip_bytes']
    assert digest(raw) == manifest['raw_sha256']
    assert digest(compressed) == manifest['gzip_sha256']
    r = Reader(raw)
    assert r.unpack('iiiiqi') == (0x474d4352,1,4,30,1790780400,270501)
    sources = [r.utf16() for _ in range(4)]
    oracle = json.loads((FIXTURE/'oracle47.json').read_text())
    assert sources == [oracle['oracle_source'][key] for key in
        ('full_pool_sha256','calibration_sha256','grades_sha256','core_sha256')]
    calibration = expected['calibration']
    supported,lo,hi,training_count,block_count = r.unpack('?ddii')
    assert (supported,lo,hi,training_count,block_count) == (
        calibration['support_flag'],calibration['training_raw_min'],
        calibration['training_raw_max'],269,len(calibration['blocks']))
    assert [r.unpack('d')[0] for _ in range(block_count-1)] == calibration['step_boundaries']
    for b in calibration['blocks']:
        assert r.unpack('iiiddd') == (b['count'],b['wins'],b['unique_dates'],
            b['probability'],*b['wilson_95_case_interval'])
    levels = r.unpack('i')[0]
    assert levels == 4
    assert [r.unpack('d')[0] for _ in range(levels-1)] == expected['grade_model']['probability_boundaries']
    assert [r.utf16() for _ in range(levels)] == ['H','G','F','E']
    total = 0
    for table in expected['symbols']:
        count = r.unpack('i')[0]
        assert count == table['count']
        assert list(r.unpack('30d')) == table['median']
        assert list(r.unpack('30d')) == table['iqr']
        assert r.unpack('dd') == (table['low_prior'],table['high_prior'])
        names = ('ids_i32_sha','boundary_i64_sha','availability_delta_i32_sha',
                 'label3_u8_sha','features30_f32_sha')
        hashes = [hashlib.sha256() for _ in names]
        previous = -1
        previous_id = -1
        for _ in range(count):
            record = r.read(137)
            slices = (record[:4],record[4:12],record[12:16],record[16:17],record[17:])
            for h,value in zip(hashes,slices):
                h.update(value)
            identifier,boundary,delta = struct.unpack('>iqi',record[:16])
            assert identifier > previous_id and boundary > previous
            assert boundary % 300 == 0 and delta > 0 and boundary+delta < expected['cutoff']
            assert record[16] in (0,1,2)
            previous,previous_id = boundary,identifier
        assert [h.hexdigest() for h in hashes] == [table[name] for name in names]
        total += count
    r.finish()
    assert total == expected['eligible_total'] == manifest['row_count']
    return {'status':'PASS','actual_real_rows_verified':total,
        'same_symbol_scaler_and_prior_tables_verified':4,
        'full_float32_chart_bytes_and_label_bytes_exact':True,
        'original_canonical_ids_and_strict_availability_exact':True,
        'calibration_and_relative_rank_tables_exact':True,
        'raw_asset_sha256':digest(raw),'compressed_asset_sha256':digest(compressed)}

def compressed_asset(asset_dir,manifest):
    if manifest.get('parts'):
        data=[]
        for part in manifest['parts']:
            value=(asset_dir/part['file']).read_bytes()
            assert len(value)==part['bytes'] and digest(value)==part['sha256']
            data.append(value)
        return b''.join(data)
    return (asset_dir/manifest['asset']).read_bytes()

def audit_java(asset_dir,jdk_bin=None):
    manifest=json.loads((asset_dir/'chart_rank_manifest.json').read_text())
    expected=json.loads((FIXTURE/'oracle47.json').read_text())
    assert digest((FIXTURE/'queries47.bin').read_bytes())==expected['queries_sha256']
    javac=str(jdk_bin/'javac') if jdk_bin else shutil.which('javac')
    java=str(jdk_bin/'java') if jdk_bin else shutil.which('java')
    if not java:raise RuntimeError('JDK java runtime is required for the independent Java audit')
    compiler=[javac] if javac and Path(javac).exists() else [java,'--module','jdk.compiler/com.sun.tools.javac.Main']
    with tempfile.TemporaryDirectory(prefix='gmk-chart-rank-independent-') as directory:
        temp=Path(directory);classes=temp/'classes';classes.mkdir()
        subprocess.run(compiler+['-d',str(classes),str(ROOT/'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankIndex.java'),
            str(FIXTURE/'IndependentChartRankReplay.java')],check=True)
        asset=temp/'independent-full.gz';asset.write_bytes(compressed_asset(asset_dir,manifest))
        result=temp/'java-result.json'
        subprocess.run([java,'-Xmx384m','-cp',str(classes),'IndependentChartRankReplay',str(asset),manifest['raw_sha256'],
            str(FIXTURE/'queries47.bin'),str(result)],check=True)
        actual=json.loads(result.read_text())
    assert len(actual['queries'])==expected['query_count']==47
    maximum={name:0.0 for name in ['probability','distance','weight','effective_n']}
    integer_checks=0
    case_checks=0
    rank_counts={}
    float_names={'rawProbability':'raw_probability','weightedProbability':'local_weighted_probability',
        'shrunkProbability':'shrunk_probability','calibratedProbability':'calibrated_probability',
        'sameSymbolDirectionPrior':'prior'}
    for observation,reference in zip(actual['queries'],expected['cases']):
        assert observation['case_id']==reference['case_id']
        value=observation['prediction']
        assert value['rank']==reference['rank'] and value['grade']==reference['rank']
        assert value['queryBoundaryUtc']==reference['boundary']
        assert value['querySymbolIndex']==reference['symbol']
        assert value['querySymbol']==['USDJPY','EURJPY','GBPJPY','AUDJPY'][reference['symbol']]
        assert value['queryChartFeaturesFloat32Sha256']==reference['query_chart_features_sha256']
        assert value['snapshotUtc']==reference['pool_snapshot_utc']==1790780400
        assert value['supportN']==200 and value['referenceDates']==reference['unique_days']
        assert value['sourcePoolCount']==reference['source_pool_count']
        assert value['chartSupport']==reference['support']
        assert value['calibrationSupport']==reference['calibration_support']
        assert value['outOfCalibrationRange']==reference['out_of_range']
        assert value['maxNeighborAvailableUtc']==reference['max_available_utc']
        assert value['neighborIds']==reference['neighbor_ids']
        assert digest(struct.pack('<'+str(len(value['neighborIds']))+'q',*value['neighborIds']))==value['neighborIdSequenceSha256']
        for name,wanted in float_names.items():
            error=abs(value[name]-reference[wanted]);maximum['probability']=max(maximum['probability'],error)
            assert error<=1e-12,(reference['case_id'],name,value[name],reference[wanted])
        for name,wanted,metric in [('distances','distances','distance'),('weights','weights','weight')]:
            assert len(value[name])==len(reference[wanted])==200
            error=max(abs(a-b) for a,b in zip(value[name],reference[wanted]));maximum[metric]=max(maximum[metric],error)
            assert error<=1e-12,(reference['case_id'],name,error)
        error=abs(value['effectiveSampleSize']-reference['effective_n']);maximum['effective_n']=max(maximum['effective_n'],error)
        assert error<=1e-12*max(1,reference['effective_n'])
        selected={}
        labels=value['neighborLabels'];weights=value['weights']
        wins=sum(label==(2 if reference['direction']=='HIGH' else 0) for label in labels)
        assert value['rawProbability']==wins/200
        assert all(a<1790780400 for a in value['neighborAvailable'])
        assert all(b<reference['boundary'] for b in value['neighborBoundaries'])
        for boundary in value['neighborBoundaries']:
            day=(boundary+32400)//86400
            previous=selected.setdefault(day,[])
            assert len(previous)<4 and all(abs(boundary-b)>=3600 for b in previous)
            previous.append(boundary)
        assert len(selected)==reference['unique_days'] and len(set(value['neighborIds']))==200
        integer_checks+=len(value['neighborIds'])
        case_checks+=1
        rank_counts[value['rank']]=rank_counts.get(value['rank'],0)+1
    durations=sorted(row['inference_ms'] for row in actual['queries'])
    return {'status':'PASS','query_count':case_checks,'exact_ordered_neighbor_id_checks':integer_checks,
        'query_symbol_and_exact_float32_feature_identity_checks':case_checks,
        'guard_count':len(actual['guards']),'guards':actual['guards'],'rank_counts':rank_counts,
        'maximum_absolute_errors':maximum,'probability_distance_weight_absolute_tolerance':1e-12,
        'effective_n_relative_tolerance':1e-12,'model_load_ms':actual['model_load_ms'],
        'host_inference_p95_ms':durations[int(.95*(len(durations)-1))],
        'host_inference_max_ms':durations[-1],
        'device_latency_verified':False,'current_outcomes_present_in_query_fixture':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--asset-dir',type=Path,default=ASSET_DIR)
    parser.add_argument('--bank-only',action='store_true')
    parser.add_argument('--jdk-bin',type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'CHART_RANK_INDEPENDENT_AUDIT.json')
    args=parser.parse_args()
    result = {'schema':1,'asset_bank':audit_bank(args.asset_dir)}
    if not args.bank_only:result['java_runtime']=audit_java(args.asset_dir,args.jdk_bin)
    result['audited_source_sha256']={str(path.relative_to(ROOT)):digest(path.read_bytes()) for path in [
        ROOT/'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankIndex.java',
        Path(__file__).resolve(),FIXTURE/'IndependentChartRankReplay.java',
        FIXTURE/'queries47.bin',FIXTURE/'oracle47.json',FIXTURE/'bank_oracle.json']}
    result['status']='PASS'
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()

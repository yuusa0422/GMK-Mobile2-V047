"""Require all current, unskipped Android-host regression suites."""
import json
from pathlib import Path

from build_release import REQUIRED_SUITES, verify_tests

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = REQUIRED_SUITES

def main():
    print(json.dumps(verify_tests(ROOT)))

if __name__ == "__main__":
    main()

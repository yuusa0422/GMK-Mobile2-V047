"""Authorized 24h clock/rank extension with previous immutable math/model gates.

Android behavioral tests, lint and fresh APK verification remain mandatory.
Night labels are explicitly reference estimates; no new win-rate claim is made.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT=Path(__file__).resolve().parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def digest(text):return hashlib.sha256(text.encode()).hexdigest()
def audit():
    spec=importlib.util.spec_from_file_location('v0742_audit',ROOT/'tools/audit_v0742.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);result=old.audit()
    manifest=json.loads((ROOT/'tools/v0743_source_extension.json').read_text())
    changes=manifest['modified_existing']
    prefixes=('unchanged:','authorized_assessment_extension:','authorized_v0742_chart_overlay:',
              'v0741_baseline_or_pinned_overlay:','pinned_new_chart_source:')
    gradle=(ROOT/'app/build.gradle.kts').read_text()
    for row in result['results']:
        name=row['check'];path=next((name[len(p):] for p in prefixes if name.startswith(p)),None)
        if path in changes:
            row.update(check='authorized_v0743_clock_rank:'+path,
                **{'pass':sha(ROOT/path)==changes[path]['updated_sha256']},
                detail='Exact authorized source bytes; daytime native parity and night boundary tests mandatory.')
        elif name=='updated_version_code':row['pass']=re.search(r'versionCode\s*=\s*113\b',gradle) is not None
        elif name=='updated_version_name':row['pass']='versionName = "0.7.43-24h-rank"' in gradle
        elif name=='fatal_errors_not_swallowed':
            fatal=[(str(p.relative_to(ROOT)),m.group(1)) for p in (ROOT/'app/src/main/java').rglob('*')
                if p.suffix in {'.kt','.java'} for m in re.finditer(
                    r'catch\s*\([^)]*:\s*(Throwable|Error|VirtualMachineError|OutOfMemoryError|LinkageError|ThreadDeath)\b',p.read_text())]
            row['pass']=fatal==[('app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt','OutOfMemoryError')]*6
            row['detail']='Original optional model boundaries plus bounded chart-label retrieval; no broad catches.'
    def check(name,ok,detail=None):
        row={'check':name,'pass':bool(ok)}
        if detail is not None:row['detail']=detail
        result['results'].append(row)
    allowed={
        'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt',
        'app/src/main/java/jp/gmk/mobile/domain/FinalRankPolicy.kt',
        'app/src/main/java/jp/gmk/mobile/domain/OfficialWinGate.kt',
        'app/src/main/java/jp/gmk/mobile/domain/LocalRuleEngine.kt',
        'app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt',
        'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankAdapter.kt',
        'app/src/main/java/jp/gmk/mobile/domain/CandidateAssessment.kt',
        'app/src/main/java/jp/gmk/mobile/MainActivity.kt',
        'app/src/main/java/jp/gmk/mobile/MarketScreens.kt'}
    check('only_authorized_v0743_main_files_changed',set(changes)==allowed)
    for path,record in changes.items():check('exact_v0743_source:'+path,sha(ROOT/path)==record['updated_sha256'])
    vm=(ROOT/'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt').read_text()
    gate=(ROOT/'app/src/main/java/jp/gmk/mobile/domain/OfficialWinGate.kt').read_text()
    policy=(ROOT/'app/src/main/java/jp/gmk/mobile/domain/FinalRankPolicy.kt').read_text()
    engine=(ROOT/'app/src/main/java/jp/gmk/mobile/domain/LocalRuleEngine.kt').read_text()
    adapter=(ROOT/'app/src/main/java/jp/gmk/mobile/domain/october/ChartConditionalRankAdapter.kt').read_text()
    runtime=(ROOT/'app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt').read_text()
    check('auto_manual_3m_1m_no_hour_stop','9..22' not in vm and '09:00-23:00' not in vm)
    check('invalid_hours_rejected_but_24_valid_hours_evaluated','if (f.hourJst !in 0..23) return false' in gate)
    gate_original=gate.replace('if (f.hourJst !in 0..23) return false','if (f.hourJst !in 9..22) return false')
    check('entire_original_ai_gate_math_unchanged',digest(gate_original)==changes['app/src/main/java/jp/gmk/mobile/domain/OfficialWinGate.kt']['original_sha256'])
    policy_original=policy.replace('        require(hourJst in 0..23) { "Invalid JST hour" }\n',
        '        if (hourJst !in 9..22) return Match("E", false, 0.50, 0.0, 0, -1, RuleSelectionStage.TIME_WINDOW)\n')
    policy_original=policy_original.replace('        in 21..22 -> "21-22"\n        else -> "OUTSIDE_ORIGINAL_HOUR_BUCKETS"\n','        else -> "21-22"\n')
    check('original_rules_rescue_and_remap_math_unchanged',digest(policy_original)==changes['app/src/main/java/jp/gmk/mobile/domain/FinalRankPolicy.kt']['original_sha256'])
    engine_original=engine.replace('if (entry.hour !in 9..22) add("V0743_24H_SESSION: original night-hour win rate unvalidated")',
        'if (entry.hour !in 9..22) add("V076_TIME_GATE outside 09:00-23:00 -> E/SKIP")')
    check('entire_native_engine_unchanged_except_time_diagnostic',digest(engine_original)==changes['app/src/main/java/jp/gmk/mobile/domain/LocalRuleEngine.kt']['original_sha256'])
    start=runtime.index('        if(native.source!="AUTO")return native',runtime.index('private fun applyOperational('))
    end=runtime.index('    /** Persist policy',start)
    check('v0743_entire_original_action_model_apply_unchanged',digest(runtime[start:end])==manifest['protected_operational_apply_body_sha256'])
    check('manual_and_auto_share_frozen_rank_model','native.source !in setOf("AUTO", "MANUAL")' in adapter)
    check('manual_uses_causal_completed_m1','Math.floorDiv(boundary - 10, 60) * 60 + 60' in adapter)
    check('on_demand_rank_is_bounded_and_retains_publication_margin','minOf(350L, boundary * 1000 - clockMillis() - 800L)' in adapter)
    check('night_rank_does_not_expand_action_model_schedule','if(!HorizonFeatureService.scheduled(boundary))' in runtime)
    check('reference_scope_is_visible','OUTSIDE_ORIGINAL_RESEARCH_SCOPE:' in adapter and 'it.scopeLabel?.let' in (ROOT/'app/src/main/java/jp/gmk/mobile/MainActivity.kt').read_text())
    check('night_regression_suite_mandatory','"NightRankRegressionTest": 12' in (ROOT/'tools/build_release.py').read_text()
        and (ROOT/'app/src/test/java/NightRankRegressionTest.kt').is_file())
    helper=(ROOT/'tools/build_release.py').read_text()
    check('fresh_build_and_binary_stale_code_rejection',
        '["gradle", "clean", ":app:testDebugUnitTest"' in helper and
        '"unsigned_release": verify_binary_behavior(release)' in helper)
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
        checks=len(result['results']),failed=[r['check'] for r in result['results'] if not r['pass']],
        scope='V0743_AUTHORIZED_24H_AND_CHART_LABEL_GUARDS; ANDROID_TESTS_LINT_APK_REQUIRED',
        current_version='0.7.43-24h-rank',night_win_rate_validated=False,actual_phone_installed=False)
    return result
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args();result=audit()
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['status','checks','failed','scope']},ensure_ascii=False))
    raise SystemExit(0 if result['status']=='PASS' else 1)

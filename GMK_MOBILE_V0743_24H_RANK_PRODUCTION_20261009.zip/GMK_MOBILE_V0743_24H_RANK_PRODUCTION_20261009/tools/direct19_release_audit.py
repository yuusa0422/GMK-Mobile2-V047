"""Gate release inputs and preserved native rules without changing references."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    preserved = json.loads((ROOT / 'tools/pc_sync_preserved_sha256.json').read_text())
    audit = json.loads((ROOT / 'MOBILE_DEEP_AUDIT_CHANGES.json').read_text())
    allowed = audit['audited_original_preserved_changes']
    streak = json.loads((ROOT / 'MOBILE_STREAK_CHANGES.json').read_text())['statistics_files']
    clock = json.loads((ROOT / 'MOBILE_CLOCK_FIX_CHANGES.json').read_text())['clock_files']
    assert set(clock) == {'app/src/main/java/jp/gmk/mobile/domain/horizon/HorizonScanAdapter.kt', 'app/src/main/java/jp/gmk/mobile/data/HorizonRuntime.kt'}
    for name, change in clock.items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == change['current_sha256'], name
    assert set(streak) == {'app/src/main/java/jp/gmk/mobile/domain/OutcomeStatistics.java', 'app/src/main/java/jp/gmk/mobile/domain/HistoryStatistics.kt'}
    assert set(allowed) == {'app/src/main/java/jp/gmk/mobile/data/MarketRepository.kt', 'app/src/main/java/jp/gmk/mobile/MarketScreens.kt'}
    for name, digest in audit['protected_domain_files'].items():
        if name in streak:
            assert streak[name]['previous_sha256'] == digest, name
            digest = streak[name]['current_sha256']
        if name in clock:
            assert clock[name]['previous_sha256'] == digest, name
            digest = clock[name]['current_sha256']
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for name, digest in audit['protected_assets'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for name, digest in preserved.items():
        actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        if actual != allowed.get(name, digest):
            raise SystemExit('Preserved native/source file changed: ' + name)
    assets = ROOT / 'app/src/main/assets/direct19'
    manifest = json.loads((assets / 'manifest.json').read_text())
    assert manifest['policy'] == 'HGB15_TRAIN20__NATIVE_C_OPEN4_BOTH_M10'
    assert manifest['feature_count'] == 165
    assert manifest['horizon_minutes'] == [3, 5]
    assert manifest['latest_training_label_epoch'] < manifest['available_from_epoch'] - 10
    for name, digest in manifest['hashes'].items():
        assert hashlib.sha256((assets / name).read_bytes()).hexdigest() == digest, name
    replay = json.loads((ROOT / 'DIRECT19_PORTABLE_REPLAY_AUDIT.json').read_text())
    assert replay['status'] == 'PASS', replay
    for namespace in ('fixtures', 'pc_r13_fixtures'):
        path = ROOT / 'tools' / namespace
        assert path.is_dir(), 'Materialize GMK_V0735_TEST_DATA.zip first'
    print(json.dumps(dict(status='PASS', preserved_files=len(preserved)-len(allowed), audited_io_ui_changes=len(allowed), protected_domain_files=len(audit['protected_domain_files']),
        policy=manifest['policy'], latest_training_label_epoch=manifest['latest_training_label_epoch'],
        bundled_mobile_daily_fitting=False), ensure_ascii=False))

if __name__ == '__main__':
    main()

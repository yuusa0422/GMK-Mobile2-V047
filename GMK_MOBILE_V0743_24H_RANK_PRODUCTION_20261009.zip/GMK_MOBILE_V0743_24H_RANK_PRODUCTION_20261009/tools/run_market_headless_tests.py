#!/usr/bin/env python3
"""Run production market I/O with real OkHttp sockets, without Android UI emulation.

The AppPrefs constructor is stubbed because MarketRepository never reads prefs.
Production Models.kt / MarketRepository.kt / BitbankRealtimeFeed.kt are compiled
unchanged. Existing tests are stripped only of their Android test harness setup.
Requires Gradle 8.10.2 lib (Kotlin compiler), and the pinned transport jars below.
Full Android Gradle tests remain mandatory for release.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time

DEPENDENCIES = {
    "okhttp-4.12.0.jar": "b1050081b14bb7a3a7e55a4d3ef01b5dcfabc453b4573a4fc019767191d5f4e0",
    "mockwebserver-4.12.0.jar": "6784673687f4ac8f21679b9d4bc7cdb46e1a1ce1be9d3133b36bede59a741561",
    "okio-jvm-3.6.0.jar": "67543f0736fc422ae927ed0e504b98bc5e269fda0d3500579337cb713da28412",
    "kotlinx-coroutines-core-jvm-1.9.0.jar": "ad89c2892235e670f222d819cb3d81188143cb19a05b59df9889ae4269f5c70a",
    "json-20240303.jar": "3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gradle-lib", type=Path, required=True)
    parser.add_argument("--dependencies", type=Path, required=True)
    parser.add_argument("--evidence", type=Path)
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    repo = project / "app/src/main/java/jp/gmk/mobile/data/MarketRepository.kt"
    if re.search(r"\bprefs\s*\.", repo.read_text()):
        raise SystemExit("MarketRepository now reads prefs; AppPrefs stub is no longer valid")
    for name, digest in DEPENDENCIES.items():
        file = args.dependencies / name
        if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest() != digest:
            raise SystemExit(f"Missing or modified pinned dependency: {name}")
    evidence = args.evidence
    if evidence:
        evidence.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="gmk-market-headless-") as directory:
        work = Path(directory)
        (work / "AppPrefs.kt").write_text("package jp.gmk.mobile.data\nclass AppPrefs\n")
        original = project / "app/src/test/java/MarketTransportV0740Test.kt"
        text = original.read_text()
        for line in [
            "import android.app.Application\n", "import org.junit.runner.RunWith\n",
            "import org.robolectric.RobolectricTestRunner\n", "import org.robolectric.RuntimeEnvironment\n",
            "import org.robolectric.annotation.Config\n", "@RunWith(RobolectricTestRunner::class)\n",
            "@Config(sdk=[26,35])\n", "    private lateinit var app: Application\n",
            "    @Before fun setup() { app=RuntimeEnvironment.getApplication() }\n",
        ]:
            text = text.replace(line, "")
        text = text.replace("AppPrefs(app)", "AppPrefs()").replace("class MarketTransportV0740Test", "class MarketTransportHeadlessV0740Test")
        (work / "MarketTransportHeadlessV0740Test.kt").write_text(text)
        legacy = (project / "app/src/test/java/MobileRealtimeAuditTest.kt").read_text()
        body = legacy[legacy.index("    private fun server():"):legacy.index("    private fun mockRepository(")]
        body = body.replace("scheduler.runCurrent();", "").replace("scheduler.runCurrent()", "")
        prefix = """import jp.gmk.mobile.data.*
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.mockwebserver.*
import org.junit.*
import org.junit.Assert.*
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong
class LegacyRealtimeSocketHeadlessV0740Test {
    private val servers=mutableListOf<MockWebServer>()
    private val feeds=mutableListOf<Pair<BitbankRealtimeFeed,Job>>()
    private val base=1_791_400_000_000L
    @After fun cleanup() {
        feeds.forEach { (feed,job)->feed.stop();job.cancel();runBlocking { job.join() } }
        servers.forEach { it.shutdown() }
    }
"""
        (work / "LegacyRealtimeSocketHeadlessV0740Test.kt").write_text(prefix + body + "}\n")
        sources = [repo, project / "app/src/main/java/jp/gmk/mobile/data/BitbankRealtimeFeed.kt",
                   project / "app/src/main/java/jp/gmk/mobile/domain/Models.kt", *work.glob("*.kt")]
        classes = work / "classes"
        classpath = [args.gradle_lib / "kotlin-stdlib-1.9.24.jar", args.gradle_lib / "junit-4.13.2.jar",
                     args.gradle_lib / "hamcrest-core-1.3.jar", *(args.dependencies / name for name in DEPENDENCIES)]
        command = ["java", "-cp", str(args.gradle_lib / "*"), "org.jetbrains.kotlin.cli.jvm.K2JVMCompiler",
                   "-jvm-target", "17", "-no-stdlib", "-no-reflect", "-classpath", os.pathsep.join(map(str, classpath)),
                   "-d", str(classes), *map(str, sources)]
        compile_result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if evidence:
            (evidence / "market_headless_compile.log").write_text(compile_result.stdout)
        if compile_result.returncode:
            print(compile_result.stdout)
            raise SystemExit(compile_result.returncode)
        run_command = ["java", "-cp", os.pathsep.join(map(str, [classes, *classpath])), "org.junit.runner.JUnitCore",
                       "MarketTransportHeadlessV0740Test", "LegacyRealtimeSocketHeadlessV0740Test"]
        started = time.monotonic()
        result = subprocess.run(run_command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        print(result.stdout)
        if evidence:
            (evidence / "market_headless_tests.log").write_text(result.stdout)
            (evidence / "market_headless_execution.json").write_text(json.dumps({
                "compile_exit": compile_result.returncode, "test_exit": result.returncode,
                "elapsed_seconds": round(time.monotonic() - started, 3),
                "production_source_sha256": {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources[:3]},
                "dependency_sha256": DEPENDENCIES,
                "tests": len(re.findall(r"@Test\s+fun ", text + body)),
                "stubbed": "AppPrefs constructor only; repository does not read prefs",
                "android_ui_or_device_validation": False,
            }, indent=2))
        raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()

import jp.gmk.mobile.domain.october.ChartConditionalRankIndex;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Pure-Java executable parity fixture runner; no Android dependency. */
public final class ChartConditionalRankParity {
    private static ChartConditionalRankIndex load(Path assets,String sha)throws Exception{
        return ChartConditionalRankIndex.readCompressed(new SequenceInputStream(Files.newInputStream(assets.resolve("index.bin.gz.part01")),
                Files.newInputStream(assets.resolve("index.bin.gz.part02"))),sha);
    }
    public static void main(String[] args)throws Exception{
        Path assets=Paths.get(args[0]);String sha=args[1];long loadStart=System.nanoTime();ChartConditionalRankIndex index=load(assets,sha);
        long loadNanos=System.nanoTime()-loadStart;
        if(index.observationCount()!=270501)throw new AssertionError("full bank");
        long[] elapsed=new long[47];int count=0;int guards=0;float[] firstQuery=null;long firstBoundary=0;int firstSymbol=0;String firstDirection="";
        try(BufferedReader input=Files.newBufferedReader(Paths.get(args[2]));PrintWriter summary=new PrintWriter(args[3]);PrintWriter neighbors=new PrintWriter(args[4])){
            summary.println("case_id\trank\traw\tweighted\tshrunk\tcalibrated\teffective_n\teffective_days\tdays\tn\tprior\tstatus\tid_sha256\telapsed_ns\tquery_symbol\tquery_symbol_index\tquery_chart_sha256");
            neighbors.println("case_id\tposition\tid\tboundary\tavailable\tlabel\tdistance\tweight");
            String line;while((line=input.readLine())!=null){if(line.isEmpty())continue;String[] row=line.split("\\t");
                String caseId=row[0];long boundary=Long.parseLong(row[1]);int symbol=Integer.parseInt(row[2]);String direction=row[3];
                float[] features=new float[35];for(int j=0;j<35;j++)features[j]=Float.parseFloat(row[4+j]);
                long start=System.nanoTime();ChartConditionalRankIndex.Result result=index.predict(boundary,symbol,direction,features,start+1800000000L);
                long nanos=System.nanoTime()-start;if(count<47)elapsed[count]=nanos;count++;
                summary.printf(Locale.ROOT,"%s\t%s\t%.17g\t%.17g\t%.17g\t%.17g\t%.17g\t%.17g\t%d\t%d\t%.17g\t%s\t%s\t%d\t%s\t%d\t%s%n",caseId,result.rank,
                        result.rawProbability,result.weightedProbability,result.shrunkProbability,result.calibratedProbability,result.effectiveSampleSize,
                        result.effectiveReferenceDays,result.referenceDates,result.supportN,result.sameSymbolDirectionPrior,result.statusReason,result.neighborIdSequenceSha256,nanos,
                        result.querySymbol,result.querySymbolIndex,result.queryChartFeaturesFloat32Sha256);
                for(int i=0;i<result.supportN;i++)neighbors.printf(Locale.ROOT,"%s\t%d\t%d\t%d\t%d\t%d\t%.17g\t%.17g%n",caseId,i,result.neighborIds[i],
                        result.neighborBoundaries[i],result.neighborAvailable[i],result.neighborLabels[i],result.distances[i],result.weights[i]);
                if(firstQuery==null){firstQuery=features;firstBoundary=boundary;firstSymbol=symbol;firstDirection=direction;}
                float[] calendar=features.clone();Arrays.fill(calendar,30,35,Float.NaN);
                ChartConditionalRankIndex.Result changed=index.predict(boundary,symbol,direction,calendar,0);
                if(!Arrays.equals(result.neighborIds,changed.neighborIds)||result.shrunkProbability!=changed.shrunkProbability||!result.rank.equals(changed.rank)||
                        !result.queryChartFeaturesFloat32Sha256.equals(changed.queryChartFeaturesFloat32Sha256))throw new AssertionError("calendar ignored");guards++;
                // Public diagnostics cannot mutate the shared HIGH/LOW cached match.
                result.neighborIds[0]=-1;result.weights[0]=100;
                ChartConditionalRankIndex.Result again=index.predict(boundary,symbol,direction,features,0);
                if(again.neighborIds[0]<0||again.weights[0]>1||again.shrunkProbability!=changed.shrunkProbability)throw new AssertionError("immutable cache");guards++;
            }
        }
        try{load(assets,"0000000000000000000000000000000000000000000000000000000000000000");throw new AssertionError("wrongSHA accepted");}catch(IOException expected){guards++;}
        try{index.predict(firstBoundary,4,firstDirection,firstQuery,0);throw new AssertionError("unsupported accepted");}catch(IllegalArgumentException expected){guards++;}
        try{index.predict(firstBoundary,firstSymbol,"DRAW",firstQuery,0);throw new AssertionError("invaliddirection accepted");}catch(IllegalArgumentException expected){guards++;}
        try{index.predict(1793458800L,firstSymbol,firstDirection,firstQuery,0);throw new AssertionError("November accepted");}catch(IllegalArgumentException expected){guards++;}
        try{index.predict(firstBoundary,firstSymbol,firstDirection,firstQuery,System.nanoTime()-1);throw new AssertionError("expireddeadline accepted");}catch(ChartConditionalRankIndex.DeadlineExceededException expected){guards++;}
        float[] nonfinite=firstQuery.clone();nonfinite[0]=Float.NaN;
        try{index.predict(firstBoundary,firstSymbol,firstDirection,nonfinite,0);throw new AssertionError("nonfinite accepted");}catch(IllegalArgumentException expected){guards++;}
        Arrays.sort(elapsed);System.out.printf(Locale.ROOT,"{\"case_count\":%d,\"guard_count\":%d,\"load_ms\":%.3f,\"predict_median_ms\":%.3f,\"predict_p95_ms\":%.3f,\"predict_max_ms\":%.3f,\"device_measurement\":false}%n",count,guards,
                loadNanos/1e6,elapsed[23]/1e6,elapsed[44]/1e6,elapsed[46]/1e6);
    }
}

GMK モバイル v0.7.41 — 等級・見送り理由の分離

修正内容
・元ルール等級（再マップ前）、運用等級、ENTRY/SKIP、見送り理由を別々に保持します。
・Eは見送り処理の区分です。研究用E/F/G/Hを、共通の強さ順として扱う分類は撤回しました。
・強さは「検証待ち」。過去ルールの平均成績は「過去ルール統計」と表示します。
・AIゲート見送り／再マップ拒否・救済不成立／ルール未一致・救済不成立／時間外を区別します。
・補正時は対象通貨の元判断、補正を発動したTOP1、選択後の方向・判定時間を記録します。
・履歴・診断JSONにも説明情報を保存します。旧履歴の未記録情報を推測で補いません。
・説明情報が壊れていても、実際の勝敗履歴は保持します。

取引処理
・ルール条件、AIゲートの重み・閾値、類似検索モデル、順位式、決済計算は従来版を維持しています。
・S/A/Bと全ENTRY、同値負け、日付/SKIPをまたぐ連敗計算も維持します。
・今回の修正による勝率の改善は主張しません。
・10月1/2/5/6/7/8、JST09:00以上15:00未満、4FX、固定3分の研究では
  REFERENCE 175/307勝=57.00%、最大9連敗。修正前と一致します。
・旧E47件の21勝=44.68%は、見送った候補の仮想成績です。実ENTRYへ混ぜません。
・研究対象にBTCやリアルタイムの実約定は含みません。
・v0740以下の資料・証跡は過去版資料です。今回の検証はrelease_evidence/v0741を参照してください。

GitHubで作成
1. 新版のSOURCE ZIPと、変更のないV0740 DATA PART01/02/03を解凍せずリポジトリ直下に置きます。
   SOURCE: GMK_MOBILE_V0741_RANK_CLARIFIED_20261009.zip
   DATA: GMK_MOBILE_V0740_DATA_PART01.zip
         GMK_MOBILE_V0740_DATA_PART02.zip
         GMK_MOBILE_V0740_DATA_PART03.zip
   旧版SOURCE ZIPや展開済み別プロジェクトと混在させないでください。
2. 別ファイルGMK_MOBILE_V0741_BUILD_WORKFLOW_20261009.ymlの内容を
   .github/workflows/build.yml に保存します。旧TEST_DATAは不要です。
3. Actions → GMK Mobile v0.7.41 → Run workflow。
4. 成功した実行のGMK_MOBILE_V0741_APKをダウンロードします。

インストール
・TEST_ONLY.apkは別アプリ（jp.gmk.mobile.rule.test）です。本番履歴は移行されません。
・RELEASE_UNSIGNED.apkは未署名で、そのままインストールできません。
・本番の上書き更新には、今の本番APKと同じ元署名鍵が必要です。
・元鍵がある場合はGitHub Settings → Secrets and variables → Actionsに以下を登録してビルドします。
  GMK_SIGNING_KEYSTORE_BASE64 / GMK_SIGNING_STORE_PASSWORD /
  GMK_SIGNING_KEY_ALIAS / GMK_SIGNING_KEY_PASSWORD
  任意の追加一致確認: GMK_SIGNING_CERT_SHA256
・新しい本番鍵は生成していません。本番アプリをアンインストールせず上書き更新してください。
・端末への本番インストールは未実施です。

検証状況
・実ローソク足432フレーム、1,416候補で元版との取引項目完全一致。
・ソース監査185項目PASS。研究・Android実行結果は同梱証跡を参照してください。
・Androidホスト176試験PASS、失敗・エラー・スキップ0。debug/release組立PASS。
・lintRelease: Error/Fatal0、Warning15。TEST署名・アプリ情報・ZIP配置・全19モデルアセット一致。
・研究17試験/55確認、独立76確認PASS。実機試験とは別です。

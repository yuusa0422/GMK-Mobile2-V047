GMK Mobile v0.7.43 24時間スキャン・ランク表示修正版

変更
・3分/1分の自動と手動から、09:00〜23:00の時刻停止を解除。
・23:00以降と日付をまたぐ枠もスキャン対象。
・ルール/AIゲートの一律時間外拒否を解除。実際の時刻をAIの入力に渡す。
・夜間を21〜22時のルール区分へ誤って割り当てない。
・データの鮮度、6通貨の取得、判定期限、AUTO優先、履歴の重複防止は維持。
・元E/SKIPのTOP1に対する類似ランクを、自動と手動に対応。
・夜間にも準備し、準備フレームがない場合は当該チャートを最大350msで参照。
・手動の秒単位のENTRY時刻でも、実際に確定済みの1分足だけを使用。
・F/G/Hは画面と履歴に保存。参照不足等は保留と理由を表示。

類似ランクの範囲
・2026年10月、3分判定、USDJPY/EURJPY/GBPJPY/AUDJPYの元E/SKIP TOP1。
・同通貨の実データ200件、参照50日超、有効件数100以上が必要。
・BTCJPY/NZDJPYの同通貨200件モデルは今回の固定データに含まれないため保留。
・1分や5分の判定へ3分の類似ランクを流用しない。
・E→F→G→Hは固定校正モデルの推定順。将来の実勝率の順序を保証するものではない。
・夜間・手動の成績は未検証。画面には参考推定と表示。
・ランク表示はENTRYへの昇格、方向、候補順、判定時間を変更しない。
・夜間の実勝率を計測した研究や、新しい校正モデルへの更新はこの修正では行っていない。

GitHubへの配置
1. リポジトリに新しいソースZIPをアップロードする。ソースは展開せずに使える。
   GMK_MOBILE_V0743_24H_RANK_PRODUCTION_20261009.zip
2. 以下のデータZIP5本を同じリポジトリに置く。前回と同じファイルを再利用する。
   GMK_MOBILE_V0740_DATA_PART01.zip
   GMK_MOBILE_V0740_DATA_PART02.zip
   GMK_MOBILE_V0740_DATA_PART03.zip
   GMK_MOBILE_V0742_CHART_DATA_PART01_20261009.zip
   GMK_MOBILE_V0742_CHART_DATA_PART02_20261009.zip
3. 別出力のワークフローの内容を .github/workflows/build.yml として保存する。
   ワークフローは51行。ソースZIP・モデルZIPは各25MB未満。
4. Commit changes → Actions → GMK Mobile v0.7.43 → Run workflow。
5. 完了後、ArtifactsのGMK_MOBILE_V0743_APKをダウンロードして展開する。

本番とTESTの署名
・本番更新にはインストール済みアプリと同じ署名キーが必要。
・GitHub Secretsに次の5項目を設定済みなら本番署名APKを生成する。
  GMK_SIGNING_KEYSTORE_BASE64
  GMK_SIGNING_STORE_PASSWORD
  GMK_SIGNING_KEY_ALIAS
  GMK_SIGNING_KEY_PASSWORD
  GMK_SIGNING_CERT_SHA256
・未設定の場合はTEST_ONLY.apkとRELEASE_UNSIGNED.apkを出力する。
・TEST_ONLYは別アプリ。本番アプリの履歴は移行しない。
・過去のTESTから上書き更新する場合も同じ署名キーが必要。既存アプリは削除しない。
・本番端末へのインストールやGitHubでのリモート実行は、この作業では行っていない。

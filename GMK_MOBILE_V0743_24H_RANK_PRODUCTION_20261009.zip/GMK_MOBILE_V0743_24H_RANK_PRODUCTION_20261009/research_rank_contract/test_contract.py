"""Boundary tests for the corrected pre-result classification contract."""
from __future__ import annotations

import unittest

import pandas as pd

from ranker import assess_candidate
from run_research import ROOT, assess_frame, loss_stats


class ContractTests(unittest.TestCase):
    def assess(self, **changes):
        inputs = dict(legacy_rule_grade="E", operational_rule_grade="E", action=0, native_action=0,
                      entry=False, archived_group="F", selected_probability=.65,
                      native_similarity_probability=.4, legacy_expected_rate=.7)
        inputs.update(changes)
        return assess_candidate(**inputs)

    def test_withdrawn_group_cannot_promote_rule_or_entry(self):
        result = self.assess()
        self.assertEqual(result["operational_grade"], "E")
        self.assertEqual(result["decision"], "SKIP")
        self.assertEqual(result["study_group"], "WITHDRAWN_E_ONLY_F")
        self.assertEqual(result["study_group_status"], "WITHDRAWN")
        self.assertIsNone(result["strength_grade"])
        self.assertEqual(result["strength_status"], "UNVALIDATED")

    def test_probability_extremes_never_create_strength(self):
        for p in (0., .01, .5, .99, 1., float("nan"), float("inf"), -1.):
            with self.subTest(probability=p):
                result = self.assess(selected_probability=p, legacy_expected_rate=p)
                self.assertIsNone(result["strength_grade"])
                self.assertEqual(result["strength_status"], "UNVALIDATED")
                self.assertEqual(result["decision"], "SKIP")
                self.assertEqual(result["operational_grade"], "E")

    def test_no_candidate_remains_unranked(self):
        result = self.assess(action=-1, native_action=-1, archived_group="H")
        self.assertEqual(result["operational_grade"], "UNRANKED")
        self.assertEqual(result["skip_reason"], "NO_CANDIDATE")
        self.assertIsNone(result["study_group"])
        self.assertIsNone(result["selected_action_probability"])
        self.assertIsNone(result["strength_grade"])

    def test_unknown_legacy_grade_is_not_inferred_from_operational_grade(self):
        result = self.assess(legacy_rule_grade="Z", archived_group="H")
        self.assertIsNone(result["legacy_rule_grade"])
        self.assertEqual(result["legacy_rule_grade_status"], "UNRECORDED")
        self.assertEqual(result["operational_grade"], "E")
        self.assertIsNone(result["strength_grade"])

    def test_unknown_operational_grade_is_not_lowest_strength(self):
        result = self.assess(operational_rule_grade="Z", archived_group="H")
        self.assertEqual(result["operational_grade"], "UNRANKED")
        self.assertIsNone(result["study_group"])
        self.assertIsNone(result["strength_grade"])

    def test_base_grade_and_rescue_grade_are_separate(self):
        result = self.assess(legacy_rule_grade="E", operational_rule_grade="B", entry=True)
        self.assertEqual(result["legacy_rule_grade"], "E")
        self.assertEqual(result["original_operational_grade"], "B")
        self.assertEqual(result["operational_grade"], "B")
        self.assertEqual(result["decision"], "ENTRY")
        self.assertIsNone(result["study_group"])

    def test_missing_base_grade_keeps_operational_grade_and_unrecorded_status(self):
        result = self.assess(legacy_rule_grade=None, operational_rule_grade="B", entry=True)
        self.assertIsNone(result["legacy_rule_grade"])
        self.assertEqual(result["legacy_rule_grade_status"], "UNRECORDED")
        self.assertEqual(result["operational_grade"], "B")

    def test_C_reroute_scores_bind_to_different_actions(self):
        result = self.assess(legacy_rule_grade="C", operational_rule_grade="C", entry=True, action=3,
                             native_action=0, selected_probability=.61,
                             legacy_expected_rate=.63)
        self.assertEqual(result["decision"], "ENTRY")
        self.assertEqual(result["operational_grade"], "C")
        self.assertEqual(result["score_provenance"], "REFERENCE_SIMILARITY_SELECTED_ACTION_REROUTED")
        self.assertEqual(result["selected_action_probability_action"], 3)
        self.assertEqual(result["legacy_expected_rate_action"], 0)
        self.assertIsNone(result["strength_grade"])

    def test_explicit_origin_and_unknown_evidence(self):
        for reason in ("GATE_REJECT", "BASE_REMAP_E_NO_RESCUE", "NO_BASE_MATCH_NO_RESCUE"):
            self.assertEqual(self.assess(skip_origin=reason)["skip_reason"], reason)
        self.assertEqual(self.assess(skip_origin=None)["skip_reason"], "LEGACY_REASON_UNAVAILABLE")

    def test_default_expected_rate_is_not_a_pattern_sample_estimate(self):
        result = self.assess(legacy_expected_rate=.5, legacy_sample_size=0)
        self.assertEqual(result["legacy_expected_rate_evidence_status"], "DEFAULT_ROUTER_FALLBACK")
        self.assertIsNone(result["strength_grade"])
        result = self.assess(legacy_sample_size=67)
        self.assertEqual(result["legacy_expected_rate_evidence_status"], "PATTERN_SAMPLE_RATE")

    def test_missing_entry_action_rejected(self):
        with self.assertRaisesRegex(ValueError, "available candidate"):
            self.assess(action=-1, entry=True)

    def test_skip_and_date_change_do_not_reset_loss_streak(self):
        rows = pd.DataFrame([
            {"boundary_utc": 1, "date": "2026-10-01", "entry": True, "win": False},
            {"boundary_utc": 2, "date": "2026-10-01", "entry": False, "win": True},
            {"boundary_utc": 3, "date": "2026-10-02", "entry": True, "win": False},
            {"boundary_utc": 4, "date": "2026-10-02", "entry": True, "win": False},
        ])
        self.assertEqual(loss_stats(rows), {"max_loss": 3, "loss_runs_ge3": 1, "loss_runs_ge5": 0})

    def test_unknown_entry_outcome_neither_counts_nor_resets_streak(self):
        rows = pd.DataFrame([
            {"boundary_utc": 1, "entry": True, "label": 0, "win": False},
            {"boundary_utc": 2, "entry": True, "label": -1, "win": False},
            {"boundary_utc": 3, "entry": True, "label": -1, "win": True},
            {"boundary_utc": 4, "entry": True, "label": 2, "win": False},
        ])
        self.assertEqual(loss_stats(rows), {"max_loss": 2, "loss_runs_ge3": 0, "loss_runs_ge5": 0})

    def test_lower_target_uses_actual_base_scan_not_counterfactual_rescue(self):
        target = {"symbol": "EURJPY", "selected_native": False, "native_scan_grade": "E",
                  "native_scan_direction": "LOW", "base_rule": -1, "base_expected": .5, "base_sample_size": 0,
                  "base_reverse": False, "mobile_score": -.2,
                  "final_rule": 10001, "final_expected": .8, "independent_full_gate_grade": "B"}
        origin = {"base_grade": "C", "base_rule": 183, "mapped_or_rescue_rule": 10166}
        result = self.assess(action=3, native_action=6, operational_rule_grade="C",
                             entry=True, selected_target_metadata=target, original_decision_metadata=origin)
        self.assertEqual(result["legacy_rule_grade_role"], "SELECTED_TARGET_PRE_REMAP")
        self.assertEqual(result["legacy_rule_grade_symbol"], "EURJPY")
        self.assertEqual(result["legacy_rule_grade_action"], 2)
        self.assertEqual(result["selected_target_operational_rule_id"], -1)
        self.assertEqual(result["selected_target_router_expected_rate"], .5)
        self.assertIsNone(result["selected_target_historical_expected_rate"])
        self.assertIsNone(result["selected_target_historical_expected_rate_action"])
        self.assertEqual(result["original_decision_origin_base_grade"], "C")
        self.assertEqual(result["original_decision_origin_action"], 6)

    def test_original_TOP1_target_uses_post_remap_operational_metadata(self):
        target = {"symbol": "EURJPY", "selected_native": True, "native_scan_grade": "C",
                  "native_scan_direction": "HIGH", "base_rule": 183, "base_expected": .7,
                  "base_reverse": True, "mobile_score": -.2,
                  "final_rule": 10166, "final_expected": .63, "final_sample_size": 67}
        result = self.assess(action=2, native_action=3, operational_rule_grade="C",
                             entry=True, selected_target_metadata=target)
        self.assertEqual(result["selected_target_operational_rule_id"], 10166)
        self.assertEqual(result["selected_target_historical_expected_rate"], .63)
        self.assertEqual(result["selected_target_historical_expected_rate_action"], 3)
        self.assertEqual(result["selected_action_probability_action"], 2)

    def test_positive_and_negative_zero_remain_HIGH_with_or_without_reverse(self):
        for score in (0.0, -0.0):
            for reverse in (False, True):
                with self.subTest(score=repr(score), reverse=reverse):
                    target = {"symbol": "EURJPY", "mobile_score": score, "base_reverse": reverse}
                    result = self.assess(selected_target_metadata=target)
                    self.assertEqual(result["legacy_rule_grade_action"], 3)

    def test_full_ledger_assessment_does_not_read_outcomes(self):
        ledger = pd.read_csv(ROOT / "inputs/rank_trade_ledger.csv.gz")
        trace = pd.read_csv(ROOT / "inputs/SEPT_OCT_NATIVE_RULE_ORIGIN_TRACE.csv")
        candidates = pd.read_csv(ROOT / "inputs/SEPT_OCT_ALL_CANDIDATES_RULE_ORIGIN_TRACE.csv")
        expected = assess_frame(ledger, trace, candidates)
        ledger["label"] = 999
        ledger["win"] = ~ledger.win
        trace["native_win"] = 999
        trace["alternative_win"] = 999
        candidates["direction_win"] = 999
        candidates["judge_open"] = 999
        pd.testing.assert_frame_equal(expected, assess_frame(ledger, trace, candidates))


if __name__ == "__main__":
    unittest.main()

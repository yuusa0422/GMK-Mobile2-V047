"""Corrected classification contract; this module does not predict strength.

Legacy grades route existing rules. The withdrawn E-only logistic groups are
archival study groups, not grades comparable with legacy S/A/B/C. A replacement
strength model has not qualified, so strength_grade is always None.

Outcome labels are deliberately absent from the assessment API.
"""
from __future__ import annotations

import math
from typing import Any

CONTRACT_VERSION = "2.0.0"
LEGACY_GRADES = frozenset(("S", "A", "B", "C", "D", "E"))
SKIP_ORIGINS = frozenset((
    "GATE_REJECT", "BASE_REMAP_E_NO_RESCUE", "NO_BASE_MATCH_NO_RESCUE",
))
SYMBOL_INDEX = {"USDJPY": 0, "EURJPY": 1, "GBPJPY": 2, "AUDJPY": 3}


def _action_for(symbol: Any, direction: Any) -> int | None:
    if symbol not in SYMBOL_INDEX or direction not in ("HIGH", "LOW"):
        return None
    return 2 * SYMBOL_INDEX[symbol] + (direction == "HIGH")


def _base_action(metadata: dict[str, Any]) -> int | None:
    try:
        score = float(metadata["mobile_score"])
    except (KeyError, TypeError, ValueError):
        return None
    if not math.isfinite(score):
        return None
    effective_score = -score if metadata.get("base_reverse") is True else score
    high = effective_score >= 0
    return _action_for(metadata.get("symbol"), "HIGH" if high else "LOW")


def _probability(value: Any) -> float | None:
    try:
        p = float(value)
    except (TypeError, ValueError):
        return None
    return p if math.isfinite(p) and 0.0 <= p <= 1.0 else None


def _grade(value: Any) -> str | None:
    return value if isinstance(value, str) and value in LEGACY_GRADES else None


def assess_candidate(
    *,
    legacy_rule_grade: str | None,
    operational_rule_grade: str | None,
    action: int,
    native_action: int,
    entry: bool,
    skip_origin: str | None = None,
    archived_group: str | None = None,
    selected_probability: float | None = None,
    native_similarity_probability: float | None = None,
    legacy_expected_rate: float | None = None,
    legacy_sample_size: int | None = None,
    selected_target_metadata: dict[str, Any] | None = None,
    original_decision_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Describe one already selected action without changing its decision.

    A missing candidate cannot be ranked. Missing trace evidence is stated
    explicitly rather than guessed. Probabilities remain diagnostic inputs and
    never control the operational grade, ENTRY, or estimated strength.
    """
    legacy_grade = _grade(legacy_rule_grade)
    grade = _grade(operational_rule_grade)
    valid_candidate = action >= 0
    if entry and not valid_candidate:
        raise ValueError("ENTRY requires an available candidate action")
    if entry:
        reason = "NONE"
    elif not valid_candidate:
        reason = "NO_CANDIDATE"
    elif skip_origin in SKIP_ORIGINS:
        reason = skip_origin
    else:
        reason = "LEGACY_REASON_UNAVAILABLE"

    withdrawn_group = (
        f"WITHDRAWN_E_ONLY_{archived_group}"
        if valid_candidate and grade == "E" and archived_group in ("E", "F", "G", "H")
        else None
    )
    p = _probability(selected_probability) if valid_candidate else None
    old_p = _probability(legacy_expected_rate) if valid_candidate else None
    rerouted = valid_candidate and native_action >= 0 and action != native_action
    target = selected_target_metadata or {}
    origin = original_decision_metadata or {}
    target_recorded = bool(target)
    target_scan_action = _action_for(target.get("symbol"), target.get("native_scan_direction"))
    target_was_top1 = target.get("selected_native") is True
    target_rule_id = target.get("final_rule" if target_was_top1 else "base_rule")
    target_rate = _probability(target.get("final_expected" if target_was_top1 else "base_expected"))
    target_sample_size = target.get("final_sample_size" if target_was_top1 else "base_sample_size")
    target_sampled_rate = target_rate if target_sample_size is not None and target_sample_size > 0 else None
    return {
        "classification_contract_version": CONTRACT_VERSION,
        "legacy_rule_grade": legacy_grade,
        "legacy_rule_grade_status": "RECORDED" if legacy_grade is not None else "UNRECORDED",
        "legacy_rule_grade_role": "SELECTED_TARGET_PRE_REMAP",
        "legacy_rule_grade_symbol": target.get("symbol"),
        "legacy_rule_grade_action": _base_action(target),
        "legacy_rule_grade_rule_id": target.get("base_rule"),
        "selected_target_trace_status": "RECORDED" if target_recorded else "UNRECORDED",
        "selected_target_native_scan_grade": _grade(target.get("native_scan_grade")),
        "selected_target_native_scan_action": target_scan_action,
        "selected_target_operational_rule_id": target_rule_id,
        "selected_target_base_expected_rate": _probability(target.get("base_expected")),
        "selected_target_router_expected_rate": target_rate,
        "selected_target_historical_expected_rate": target_sampled_rate,
        "selected_target_historical_sample_size": target_sample_size,
        "selected_target_historical_expected_rate_evidence_status": (
            "UNRECORDED" if target_rate is None else "DEFAULT_ROUTER_FALLBACK" if target_sample_size == 0 else
            "PATTERN_SAMPLE_RATE" if target_sample_size is not None and target_sample_size > 0 else "SOURCE_EVIDENCE_UNAVAILABLE"
        ),
        "selected_target_historical_expected_rate_action": target_scan_action if target_sampled_rate is not None else None,
        "selected_target_historical_expected_rate_provenance": (
            "SELECTED_TARGET_POST_REMAP_NATIVE_TOP1" if target_was_top1 else "SELECTED_TARGET_CLASSIFY_BASE"
        ) if target_rate is not None else "UNRECORDED",
        "original_operational_grade": grade,
        "original_decision_origin_grade": grade,
        "original_decision_origin_action": native_action if native_action >= 0 else None,
        "original_decision_origin_role": "ORIGINAL_NATIVE_TOP1",
        "original_decision_origin_trace_status": "RECORDED" if origin else "UNRECORDED",
        "original_decision_origin_base_grade": _grade(origin.get("base_grade")),
        "original_decision_origin_base_rule_id": origin.get("base_rule"),
        "original_decision_origin_operational_rule_id": origin.get("mapped_or_rescue_rule"),
        "original_decision_origin_expected_rate": old_p,
        "original_decision_origin_expected_rate_action": native_action if old_p is not None else None,
        "operational_grade": grade if valid_candidate and grade else "UNRANKED",
        "decision": "ENTRY" if entry else "SKIP",
        "skip_reason": reason,
        "candidate_status": "VALID" if valid_candidate else "NO_CANDIDATE",
        "strength_grade": None,
        "strength_status": "UNVALIDATED",
        "study_group": withdrawn_group,
        "study_group_status": "WITHDRAWN" if withdrawn_group else "NONE",
        "action_rerouted": rerouted,
        "correction_source": "REFERENCE_SIMILARITY_ACTION_REROUTE" if rerouted else "NATIVE_TOP1_ACTION_RETAINED" if valid_candidate else "NO_CANDIDATE",
        "selected_action_probability": p,
        "selected_action_probability_action": action if p is not None else None,
        "score_provenance": (
            "REFERENCE_SIMILARITY_SELECTED_ACTION_REROUTED" if rerouted
            else "REFERENCE_SIMILARITY_SELECTED_ACTION"
        ) if p is not None else "UNAVAILABLE",
        "score_status": "UNCALIBRATED_DIAGNOSTIC" if p is not None else "UNAVAILABLE",
        "native_action_similarity_probability": (
            _probability(native_similarity_probability) if native_action >= 0 else None
        ),
        "legacy_expected_rate": old_p,
        "legacy_expected_rate_action": native_action if old_p is not None else None,
        "legacy_expected_rate_role": "ORIGINAL_NATIVE_TOP1_POST_REMAP_RULE_ACTION",
        "legacy_expected_rate_provenance": (
            "LEGACY_PATTERN_ROUTER_ORIGINAL_RULE_ACTION" if old_p is not None else "UNAVAILABLE"
        ),
        "legacy_expected_rate_evidence_status": (
            "UNAVAILABLE" if old_p is None else
            "DEFAULT_ROUTER_FALLBACK" if legacy_sample_size == 0 else
            "PATTERN_SAMPLE_RATE" if legacy_sample_size is not None and legacy_sample_size > 0 else
            "SOURCE_EVIDENCE_UNAVAILABLE"
        ),
    }

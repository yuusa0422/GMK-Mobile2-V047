"""Rebuild corrected classifications and verify unchanged historical decisions."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

from ranker import CONTRACT_VERSION, assess_candidate

ROOT = Path(__file__).resolve().parent
INVARIANT_COLUMNS = (
    "boundary_utc", "date", "mode", "policy", "common_mother", "entry",
    "action", "symbol", "direction", "horizon_minutes", "label", "win",
    "changed", "native_grade", "native_action", "native_entry",
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assess_frame(ledger: pd.DataFrame, trace: pd.DataFrame, candidate_trace: pd.DataFrame) -> pd.DataFrame:
    origins = trace.set_index("boundary_utc").to_dict("index")
    targets = candidate_trace.set_index(["boundary_utc", "symbol"], drop=False).to_dict("index")
    assessments = []
    for row in ledger.to_dict("records"):
        origin = origins.get(row["boundary_utc"], {})
        target = targets.get((row["boundary_utc"], row["symbol"]), {}) if row["action"] >= 0 else {}
        assessments.append(assess_candidate(
            legacy_rule_grade=target.get("base_grade"),
            operational_rule_grade=row["native_grade"],
            action=int(row["action"]), native_action=int(row["native_action"]),
            entry=bool(row["entry"]), skip_origin=origin.get("E_origin"),
            archived_group=row["extended_grade"],
            selected_probability=row["selected_probability"],
            native_similarity_probability=row["native_probability"],
            legacy_expected_rate=origin.get("legacy_expected_rate"),
            legacy_sample_size=origin.get("legacy_sample_size"),
            selected_target_metadata=target,
            original_decision_metadata=origin,
        ))
    return pd.DataFrame(assessments, index=ledger.index)


def make_corrected(ledger: pd.DataFrame, trace: pd.DataFrame, candidate_trace: pd.DataFrame) -> pd.DataFrame:
    out = ledger.rename(columns={
        "extended_grade": "archived_study_group_letter",
        "rank_score": "archived_withdrawn_E_only_score",
        "native_probability": "source_native_probability",
    }).copy()
    assessment = assess_frame(ledger, trace, candidate_trace)
    for name in assessment:
        out[name] = assessment[name]
    out["outcome_scope"] = [
        "ENTRY_REPLAY" if entry else "SKIP_VIRTUAL" if action >= 0 else "NO_CANDIDATE"
        for entry, action in zip(out.entry, out.action)
    ]
    out["outcome_status"] = [
        "SETTLED_KNOWN" if action >= 0 and label in (0, 1, 2) else "UNAVAILABLE"
        for action, label in zip(out.action, out.label)
    ]
    return out


def rate(wins: int, count: int) -> float | None:
    return 100.0 * wins / count if count else None


def loss_stats(rows: pd.DataFrame) -> dict:
    run = maximum = 0
    runs = []
    for row in rows.sort_values("boundary_utc").to_dict("records"):
        if not row["entry"]:
            continue  # neither SKIP nor a date boundary resets the streak
        if "label" in row and row["label"] not in (0, 1, 2):
            continue  # unavailable outcomes are neither wins nor losses/resets
        if row["win"]:
            if run:
                runs.append(run)
            run = 0
        else:
            run += 1
            maximum = max(maximum, run)
    if run:
        runs.append(run)
    return {"max_loss": maximum, "loss_runs_ge3": sum(x >= 3 for x in runs),
            "loss_runs_ge5": sum(x >= 5 for x in runs)}


def make_summary(corrected: pd.DataFrame) -> pd.DataFrame:
    summary = []
    for period, rows in (
        ("ALL_AVAILABLE", corrected),
        ("SEPTEMBER", corrected[corrected.date.str.startswith("2026-09")]),
        ("OCTOBER_6_DAYS", corrected[corrected.date.str.startswith("2026-10")]),
    ):
        for grade in ("S", "A", "B", "C", "D", "E", "UNRANKED"):
            q = rows[rows.operational_grade == grade]
            valid = q[(q.action >= 0) & (q.label >= 0)]
            entries = q[q.entry & (q.label >= 0)]
            summary.append({
                "period": period, "summary_type": "OPERATIONAL_GRADE",
                "grade_or_reason": grade, "rows": len(q),
                "valid_candidate_count": len(valid),
                "entry_count": len(entries), "entry_wins": int(entries.win.sum()),
                "entry_win_rate_pct": rate(int(entries.win.sum()), len(entries)),
                "virtual_skip_count": len(valid[~valid.entry]),
                "virtual_skip_wins": int(valid.loc[~valid.entry, "win"].sum()),
                "virtual_skip_win_rate_pct": rate(int(valid.loc[~valid.entry, "win"].sum()), len(valid[~valid.entry])),
                "strength_status": "UNVALIDATED", "strength_grade": None,
            })
        skips = rows[(rows.operational_grade == "E") & ~rows.entry]
        for reason, q in skips.groupby("skip_reason", sort=True):
            valid = q[(q.action >= 0) & (q.label >= 0)]
            summary.append({
                "period": period, "summary_type": "ORIGINAL_E_SKIP_REASON",
                "grade_or_reason": reason, "rows": len(q),
                "valid_candidate_count": len(valid), "entry_count": 0, "entry_wins": 0,
                "entry_win_rate_pct": None, "virtual_skip_count": len(valid),
                "virtual_skip_wins": int(valid.win.sum()),
                "virtual_skip_win_rate_pct": rate(int(valid.win.sum()), len(valid)),
                "strength_status": "UNVALIDATED", "strength_grade": None,
            })
    return pd.DataFrame(summary)


def validate(ledger: pd.DataFrame, trace: pd.DataFrame, candidate_trace: pd.DataFrame, out: pd.DataFrame) -> dict:
    checks = {}
    def check(name: str, condition: bool):
        checks[name] = bool(condition)
        if not condition:
            raise AssertionError(name)
    check("source_rows_2664", len(ledger) == 2664)
    check("fixed3_reference_only", bool((ledger["mode"] == "FIXED_3").all() and (ledger.policy == "REFERENCE").all()))
    check("unique_boundary_ids", ledger.boundary_utc.is_unique and trace.boundary_utc.is_unique)
    check("unique_candidate_boundary_symbol_keys", not candidate_trace.duplicated(["boundary_utc", "symbol"]).any())
    check("candidate_trace_6608_rows", len(candidate_trace) == 6608)
    check("JST_09_to_15_only", bool(ledger.hour.between(9, 14).all()))
    check("four_FX_only", set(ledger.symbol.dropna()) <= {"USDJPY", "EURJPY", "GBPJPY", "AUDJPY"})
    for column in INVARIANT_COLUMNS:
        check(f"unchanged_{column}", ledger[column].equals(out[column]))
    active = ledger.action >= 0
    expected = ledger.label == ledger.action.mod(2).map({0: 0, 1: 2})
    check("all_valid_actions_draw_is_loss", bool((ledger.loc[active, "win"] == expected[active]).all()))
    check("DRAW_never_WIN", not bool(ledger.loc[ledger.label == 1, "win"].any()))
    check("unknown_outcomes_explicitly_unavailable", bool((out.loc[out.label < 0, "outcome_status"] == "UNAVAILABLE").all()))
    check("strength_is_unvalidated_everywhere", bool(out.strength_grade.isna().all() and (out.strength_status == "UNVALIDATED").all()))
    check("withdrawn_groups_not_operational_grades", not out.operational_grade.isin(["F", "G", "H"]).any())
    check("no_candidate_unranked", bool((out.loc[out.action < 0, "operational_grade"] == "UNRANKED").all()))
    check("no_candidate_has_no_study_group", bool(out.loc[out.action < 0, "study_group"].isna().all()))
    check("all_skips_have_explicit_reason", bool((out.loc[~out.entry, "skip_reason"] != "NONE").all()))
    original = ledger.set_index("boundary_utc").reindex(trace.boundary_utc)
    check("trace_grade_alignment", bool((original.native_grade.to_numpy() == trace.native_grade.to_numpy()).all()))
    output_trace = out.set_index("boundary_utc").reindex(trace.boundary_utc)
    check("original_origin_base_grade_is_native_TOP1_base", bool((output_trace.original_decision_origin_base_grade.to_numpy() == trace.base_grade.to_numpy()).all()))
    targets = candidate_trace.set_index(["boundary_utc", "symbol"])
    recorded = out.selected_target_trace_status == "RECORDED"
    target_rows = targets.reindex(pd.MultiIndex.from_arrays([out.loc[recorded, "boundary_utc"], out.loc[recorded, "symbol"]]))
    check("selected_target_legacy_grade_matches_target_base", bool((out.loc[recorded, "legacy_rule_grade"].to_numpy() == target_rows.base_grade.to_numpy()).all()))
    check("selected_target_legacy_rule_matches_target_base", bool((out.loc[recorded, "legacy_rule_grade_rule_id"].to_numpy() == target_rows.base_rule.to_numpy()).all()))
    check("legacy_grade_selected_target_role_explicit", bool((out.legacy_rule_grade_role == "SELECTED_TARGET_PRE_REMAP").all()))
    top1 = target_rows.selected_native.to_numpy(dtype=bool)
    expected_rule = target_rows.base_rule.to_numpy().copy()
    expected_rule[top1] = target_rows.final_rule.to_numpy()[top1]
    expected_rate = target_rows.base_expected.to_numpy().copy()
    expected_rate[top1] = target_rows.final_expected.to_numpy()[top1]
    check("selected_target_operational_rule_uses_actual_scan_phase", bool((out.loc[recorded, "selected_target_operational_rule_id"].to_numpy() == expected_rule).all()))
    check("selected_target_router_rate_uses_actual_scan_phase", bool((out.loc[recorded, "selected_target_router_expected_rate"].to_numpy() == expected_rate).all()))
    sampled = out.loc[recorded, "selected_target_historical_sample_size"].to_numpy() > 0
    check("selected_target_sampled_history_never_uses_fallback_rate", bool(out.loc[recorded, "selected_target_historical_expected_rate"].iloc[~sampled].isna().all()))
    check("selected_target_sampled_history_matches_router", bool((out.loc[recorded, "selected_target_historical_expected_rate"].iloc[sampled].to_numpy() == expected_rate[sampled]).all()))
    target_symbol_index = target_rows.reset_index().symbol.map({"USDJPY": 0, "EURJPY": 1, "GBPJPY": 2, "AUDJPY": 3}).to_numpy()
    expected_scan_action = 2 * target_symbol_index + (target_rows.native_scan_direction.to_numpy() == "HIGH")
    effective_base_score = target_rows.mobile_score.to_numpy(dtype=float).copy()
    effective_base_score[target_rows.base_reverse.to_numpy(dtype=bool)] *= -1.
    base_high = effective_base_score >= 0
    expected_base_action = 2 * target_symbol_index + base_high
    check("selected_target_native_scan_action_matches_trace", bool((out.loc[recorded, "selected_target_native_scan_action"].to_numpy() == expected_scan_action).all()))
    check("selected_target_pre_remap_base_action_matches_trace", bool((out.loc[recorded, "legacy_rule_grade_action"].to_numpy() == expected_base_action).all()))
    unrecorded = ~out.boundary_utc.isin(trace.boundary_utc)
    check("unrecorded_target_base_grade_never_inferred", bool(out.loc[~recorded, "legacy_rule_grade"].isna().all() and (out.loc[~recorded, "legacy_rule_grade_status"] == "UNRECORDED").all()))
    check("original_operational_grade_preserved", bool(out.original_operational_grade.fillna("MISSING").equals(ledger.native_grade.fillna("MISSING"))))
    check("original_TOP1_expected_rate_remains_original_role", bool((output_trace.original_decision_origin_expected_rate.to_numpy() == trace.legacy_expected_rate.to_numpy()).all()))
    check("selected_target_match_1652_rows", int(recorded.sum()) == 1652)
    # A changed label and win must not change the pre-result assessment. Trace
    # native/alternative outcomes are poisoned as well, not merely ledger labels.
    poison = ledger.copy()
    poison["label"] = poison.label.map({-1: 2, 0: 2, 1: 0, 2: 1})
    poison["win"] = ~poison.win
    poisoned_trace = trace.copy()
    for c in ("native_win", "alternative_win"):
        poisoned_trace[c] = 999
    poisoned_candidates = candidate_trace.copy()
    for c in ("direction_win", "entry_open", "judge_open"):
        poisoned_candidates[c] = 999
    check("assessment_independent_of_all_outcome_labels", assess_frame(ledger, trace, candidate_trace).equals(assess_frame(poison, poisoned_trace, poisoned_candidates)))
    rerouted = out.action_rerouted
    check("rerouted_probability_provenance_explicit", bool((out.loc[rerouted, "score_provenance"] == "REFERENCE_SIMILARITY_SELECTED_ACTION_REROUTED").all()))
    lp = out.legacy_expected_rate.notna()
    check("legacy_expected_rate_bound_to_original_action", bool((out.loc[lp, "legacy_expected_rate_action"] == out.loc[lp, "native_action"]).all()))
    check("selected_probability_bound_to_selected_action", bool((out.loc[out.selected_action_probability.notna(), "selected_action_probability_action"] == out.loc[out.selected_action_probability.notna(), "action"]).all()))
    october = out[out.date.str.startswith("2026-10")]
    oct_entry = october[october.entry]
    oct_e = october[october.operational_grade == "E"]
    check("October_432_mother_rows", len(october) == 432)
    check("October_REFERENCE_175_of_307_unchanged", len(oct_entry) == 307 and int(oct_entry.win.sum()) == 175)
    check("October_original_E_21_of_47", len(oct_e) == 47 and int(oct_e.win.sum()) == 21)
    check("October_no_candidate_78", int((october.action < 0).sum()) == 78)
    oct_origins = {
        reason: {"count": len(q), "wins": int(q.win.sum())}
        for reason, q in oct_e.groupby("skip_reason", sort=True)
    }
    check("October_E_reason_reconstruction", oct_origins == {
        "BASE_REMAP_E_NO_RESCUE": {"count": 12, "wins": 3},
        "GATE_REJECT": {"count": 7, "wins": 5},
        "NO_BASE_MATCH_NO_RESCUE": {"count": 28, "wins": 13},
    })
    return {
        "status": "PASS", "contract_version": CONTRACT_VERSION,
        "checks": checks, "passed_checks": len(checks),
        "production_trading_decisions_changed": False,
        "strength_model_status": "NONE_QUALIFIED",
        "E_H_model_status": "WITHDRAWN",
        "October": {
            "mother_count": len(october), "entry_count": len(oct_entry),
            "entry_wins": int(oct_entry.win.sum()), "win_rate_pct": rate(int(oct_entry.win.sum()), len(oct_entry)),
            "entry_rate_pct": rate(len(oct_entry), len(october)),
            "original_E_virtual_count": len(oct_e), "original_E_virtual_wins": int(oct_e.win.sum()),
            "original_E_virtual_rate_pct": rate(int(oct_e.win.sum()), len(oct_e)),
            "original_E_origins": oct_origins,
            **loss_stats(october),
        },
        "all_rows": len(out), "trace_rows": len(trace),
        "original_operational_E_reason_unavailable_rows": int((out.skip_reason == "LEGACY_REASON_UNAVAILABLE").sum()),
        "legacy_base_grade_recorded_rows": int((out.legacy_rule_grade_status == "RECORDED").sum()),
        "legacy_base_grade_unrecorded_rows": int((out.legacy_rule_grade_status == "UNRECORDED").sum()),
        "candidate_trace_rows": len(candidate_trace),
        "selected_target_metadata_matched_rows": int(recorded.sum()),
        "selected_target_metadata_missing_valid_action_rows": int(((~recorded) & (out.action >= 0)).sum()),
        "selected_target_metadata_missing_no_candidate_rows": int(((~recorded) & (out.action < 0)).sum()),
        "rerouted_action_rows": int(out.action_rerouted.sum()),
        "rerouted_recorded_target_rows": int((out.action_rerouted & recorded).sum()),
        "scope": "JST 09<=hour<15, USDJPY/EURJPY/GBPJPY/AUDJPY, fixed 3 minutes; no BTC or live-fill assertion",
        "limits": [
            "Historical labels are unchanged; this correction does not increase the measured win rate.",
            "Original-E replay outcomes are virtual SKIP outcomes, not actual entries.",
            "July/August source samples are Fridays only; detailed origin trace is available only for September/October.",
            "Legacy rule grade and legacy expectedRate are not a calibrated common strength scale.",
            "Similarity scores are archived diagnostics; score provenance follows their action.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ledger", type=Path, default=ROOT / "inputs/rank_trade_ledger.csv.gz")
    parser.add_argument("--trace", type=Path, default=ROOT / "inputs/SEPT_OCT_NATIVE_RULE_ORIGIN_TRACE.csv")
    parser.add_argument("--candidate-trace", type=Path, default=ROOT / "inputs/SEPT_OCT_ALL_CANDIDATES_RULE_ORIGIN_TRACE.csv")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs")
    args = parser.parse_args()
    ledger, trace, candidates = pd.read_csv(args.ledger), pd.read_csv(args.trace), pd.read_csv(args.candidate_trace)
    corrected = make_corrected(ledger, trace, candidates)
    audit = validate(ledger, trace, candidates, corrected)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output_ledger = args.output_dir / "CORRECTED_CLASSIFICATION_LEDGER.csv.gz"
    output_summary = args.output_dir / "CORRECTED_OPERATIONAL_SUMMARY.csv"
    corrected.to_csv(output_ledger, index=False, compression={"method": "gzip", "mtime": 0})
    make_summary(corrected).to_csv(output_summary, index=False)
    audit["input_sha256"] = {args.ledger.name: sha256(args.ledger), args.trace.name: sha256(args.trace), args.candidate_trace.name: sha256(args.candidate_trace)}
    audit["output_sha256"] = {output_ledger.name: sha256(output_ledger), output_summary.name: sha256(output_summary)}
    (args.output_dir / "RESEARCH_CONTRACT_AUDIT.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": audit["status"], "passed_checks": audit["passed_checks"], "rows": len(corrected), "October": audit["October"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()

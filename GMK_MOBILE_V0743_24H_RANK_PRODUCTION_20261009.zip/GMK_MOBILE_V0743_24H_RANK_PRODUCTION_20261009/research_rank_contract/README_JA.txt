研究分類の修正（2026-10-09）

修正内容
・旧ルール等級、ENTRY/SKIP、見送り理由、推定強度を別の項目にした。
・legacy_rule_grade は最終選択した通貨の再マップ・救済・AIゲート前の classifyBase 等級
  （全通貨トレースを時刻＋最終選択通貨で引いたbase_grade）。元TOP1の等級とは別にした。
  未収録の7月/8月や候補なし行では推測せず
  null/UNRECORDED とする。
・元TOP1の基本等級・最終等級・ルールID・action・旧expectedRateは
  original_decision_origin_* として別に保持した。最終選択通貨の基本方向と元スキャン方向も
  分け、元TOP1なら救済後、下位候補ならclassifyBaseの実際のスキャン値を使用する。
  independent_full_gate_* は仮想の各通貨再判定なので最終選択通貨の元値として代用しない。
・original_operational_grade は再マップ・救済・AIゲート後の元native_grade。
  operational_grade は候補があるときのこの運用等級であり、上の基本等級と分けた。
・以前のE〜Hは「元Eだけ」の診断群であり、S/A/B/Cと共通の強さの順序ではない。
  研究群は WITHDRAWN_E_ONLY_* として記録を残し、強さランクや取引条件には使わない。
・通過した代替強度モデルは無いため、strength_grade は空/null、
  strength_status は全件 UNVALIDATED（未検証）とする。
・候補が無い行は operational_grade=UNRANKED。Hなどの弱さランクには落とさない。
・旧 expectedRate は元のルール方向の値であり、類似補正で変わったCの方向・通貨の
  勝率予測として表示しない。類似スコアと旧expectedRateの作用対象を別に記録した。
  サンプル数0の既定値0.5は DEFAULT_ROUTER_FALLBACK と明示し、実測の率と区別する。
  legacy_expected_rate は元TOP1の値の互換項目。選び直した通貨の値は
  selected_target_historical_expected_rate として作用対象の元スキャンactionを明示した。
  この元スキャンでサンプル数0なら歴史統計の率はnull。既定値0.5は
  selected_target_router_expected_rate（ルーターの診断値）にだけ残す。

保持したもの
・2664件の元のaction、ENTRY、方向、通貨、判定分数、勝敗・ラベル、旧等級。
・DRAW=負け。SKIPや日付切替で連敗をリセットしない。
・旧研究ファイル、本番の取引ルール・AIゲート・通貨選択はこの修正では変更しない。
・判定ラベルが未収録の行は outcome_status=UNAVAILABLE とし、元のFalseを実測負けと数えない。
  連敗集計でも未知のENTRY結果を除外し、連敗をリセットしない。

検証結果
・10月6営業日：175勝/307ENTRY = 57.0033%、ENTRY率71.0648%、最大9連敗。
・元E：21勝/47件 = 44.6809%（見送りの仮想結果）。新Eの6勝/10件を元E全体の
  勝率として扱わない。
・元Eの内訳：AIゲート拒否5/7、旧再マップ拒否・救済不成立3/12、
  ルール未一致・救済不成立13/28。
・修正は表示・研究上の分類誤用を防ぐためのもの。勝率を上げたという結果ではない。

見送り理由
NONE：ENTRY
NO_CANDIDATE：候補なし
GATE_REJECT：AIゲート拒否
BASE_REMAP_E_NO_RESCUE：旧ルール再マップE・救済不成立
NO_BASE_MATCH_NO_RESCUE：基本ルール未一致・救済不成立
LEGACY_REASON_UNAVAILABLE：詳細トレース未収録（主に7月/8月の元E）

再実行
Python 3.11以上とpandasが必要。
  python -m pip install -r requirements.txt
  python run_research.py
  python -m unittest -v test_contract.py

ranker.py単体は標準ライブラリだけで利用できる。
  from ranker import assess_candidate
  assessment = assess_candidate(legacy_rule_grade='C', operational_rule_grade='E', action=0,
      native_action=0, entry=False, skip_origin='GATE_REJECT')

成果物
outputs/CORRECTED_CLASSIFICATION_LEDGER.csv.gz：訂正した全2664件
outputs/CORRECTED_OPERATIONAL_SUMMARY.csv：旧運用等級・元E理由の集計
outputs/RESEARCH_CONTRACT_AUDIT.json：不変条件・ラベル非依存・入力/出力SHA256
CONTRACT.json：項目の契約と旧項目からの移行定義

注意する範囲
・JST9時以上15時未満、USDJPY/EURJPY/GBPJPY/AUDJPY、3分判定の研究。
・7月/8月は金曜標本。年全体・3年全体を検証したという結果ではない。
・BTC/JPY、リアルタイム取得、実機の取引約定はこの研究では確認していない。
・10月の結果は既に観察した遡及分析であり、新しい未観測期間の保証ではない。

from pathlib import Path
import sys, json

root = Path(__file__).resolve().parents[1]
app = root / "app/src/main"
vm = (app / "java/jp/gmk/mobile/ui/GmkViewModel.kt").read_text(encoding="utf-8")
prefs = (app / "java/jp/gmk/mobile/data/AppPrefs.kt").read_text(encoding="utf-8")
hist = (app / "java/jp/gmk/mobile/data/HistoryStore.kt").read_text(encoding="utf-8")
main = (app / "java/jp/gmk/mobile/MainActivity.kt").read_text(encoding="utf-8")
manifest = (app / "AndroidManifest.xml").read_text(encoding="utf-8")
service = (app / "java/jp/gmk/mobile/runtime/GmkRuntimeKeepAliveService.kt").read_text(encoding="utf-8")
holder = (app / "java/jp/gmk/mobile/runtime/GmkRuntimeHolder.kt").read_text(encoding="utf-8")
engine = (app / "java/jp/gmk/mobile/domain/LocalRuleEngine.kt").read_text(encoding="utf-8")
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
workflow = (root / ".github/workflows/build.yml").read_text(encoding="utf-8")
repo = (root / "app/src/main/java/jp/gmk/mobile/data/MarketRepository.kt").read_text(encoding="utf-8")
finalrank = (root / "app/src/main/java/jp/gmk/mobile/domain/FinalRankPolicy.kt").read_text(encoding="utf-8")
drawables = list((app / "res/drawable-nodpi").glob("cutin_*.webp"))

checks = {
    "version_current": 'versionCode = 92' in gradle and 'versionName = "0.7.22-research-gensokyo-history-ui"' in gradle,
    "foreground_service_declared": "GmkRuntimeKeepAliveService" in manifest and 'foregroundServiceType="specialUse"' in manifest,
    "single_process_runtime": "GmkRuntimeHolder.get(application)" in service and "GmkRuntimeHolder.get(app)" in main and "GmkViewModel(app)" in holder,
    "service_does_not_cancel_shared_runtime": "shutdownRuntime" not in service,
    "boot_restore_declared": "RECEIVE_BOOT_COMPLETED" in manifest and "GmkBootReceiver" in manifest,
    "1m_auto_pref": "oneMinuteAutoScan" in prefs,
    "1m_auto_scheduler": "startOneMinuteAutoLoop" in vm and 'startOneMinuteScan("AUTO_1M", boundary)' in vm,
    "1m_only_does_not_skip_5m_slots": "prefs.autoScan && now.minute % 5 == 4" in vm,
    "1m_history_saved": "historyStore.add(historyResult)" in vm,
    "1m_outcome_tracking": "scheduleOutcomeTracking(historyResult)" in vm,
    "1m_rank_not_hardcoded_c": 'grade = "C"' not in vm and "top.confidence >= 0.75" in vm and "top.confidence >= 0.53" in vm,
    "1m_and_3m_winrate_split": "val threeRows" in main and "val oneRows" in main,
    "outcome_status_visible": "state.outcomeStatus" in main,
    "atomic_3m_boundary_claim": "claimThreeMinuteBoundary" in prefs and "prefs.claimThreeMinuteBoundary" in vm,
    "atomic_1m_boundary_claim": "claimOneMinuteBoundary" in prefs and "prefs.claimOneMinuteBoundary" in vm,
    "auto_history_dedup": 'result.source.startsWith("AUTO")' in hist,
    "history_capacity_expanded": "MAX_HISTORY_ROWS = 20_000" in hist,
    "github_compile_step": "name: Compile Kotlin" in workflow,
    "research_zip_not_auto_built": "SKIP RESEARCH ZIP" in workflow,
    "keyless_fx_provider": "YahooFinanceChart-keyless" in vm and "fetchYahooCandles" in repo,
    "history_accepts_e_to_i": '"E", "F", "G", "H", "I"' in hist,
    "strict_six_currency_scan": 'スキャン見送り: 6/6必須' in vm,
    "strict_latest_completed_m1": "expectedLastStartMs" in vm and "直近完成1分足欠損" in vm,
    "strict_3m_continuity_90s": "gap > 90_000L" in vm and "1分足不連続" in vm,
    "legacy_skip_status_fixed": 'else if (decision == "SKIP")' in hist,
    "stage2_sample_floor": 'if (r.n < 25) continue' in finalrank,
    "rank_contract_thresholds": 'q >= 0.75 -> "S"' in engine and 'q >= 0.65 -> "A"' in engine and 'q >= 0.58 -> "B"' in engine and 'q >= 0.53 -> "C"' in engine and 'else -> "E"' in engine,
    "sub53_is_skip": 'decision = if (calibrated in setOf("S", "A", "B", "C")) "ENTRY" else "SKIP"' in engine,
    "manual_3m_entry_time_gate": "3分手動見送り: ENTRY時刻が本番時間外" in vm,
    "manual_1m_entry_time_gate": "1分手動見送り: ENTRY時刻が本番時間外" in vm,
    "manual_3m_exact_plus10": "scanStarted.plusSeconds(10)" in vm and "scanStarted.plusSeconds(10).withNano(0)" not in vm,
    "t10_false_missed_guard": "scheduled.plusSeconds(1).isBefore(now)" in vm,
    "divergence_fail_safe": "quote/candle乖離大: fail-safe SKIP" in vm,
    "outcome_exact_minute_open": "fetchMinuteOpenAt(instrument, targetMs)" in vm,
    "outcome_capture_window_90s": "target.plusSeconds(90)" in vm,
    "outcome_no_subsecond_quote_hammer": "delay(3_000)" in vm and "outcomeCaptureSemaphore" in vm,
    "draw_is_directional_lose": "DRAW is directional LOSE by specification" in hist,
    "3m_claim_only_when_startable": "Do not consume the boundary while another operation is still winding down" in vm and "AUTO待機: T-10有効ウィンドウ内で実行中処理の終了待ち" in vm,
    "1m_claim_only_when_startable": "Claim only when the scan can actually start" in vm and "1分AUTO待機: T-10有効ウィンドウ内で実行中処理の終了待ち" in vm,
    "auto_missed_after_window": "AUTO_SCAN_MISSED: T-10有効ウィンドウ内に開始できませんでした" in vm and "1分AUTO_MISSED: T-10有効ウィンドウ内に開始できませんでした" in vm,
    "1m_skip_status_truthful": "53%未満" in vm,

    "scan_does_not_cancel_live_requests": vm.count("repository.cancelInFlightRequests()") == 1,
    "yahoo_scan_payload_reduced": '.addQueryParameter("range", "5d")' not in repo and '.addQueryParameter("range", "1d")' in repo,
    "yahoo_exact_minute_host_fallback": 'query2 can succeed before the exact minute is published' in repo and 'period1' in repo and 'period2' in repo,
    "yahoo_live_gate_tightened": '(age ?: 9999.0) <= 20.0 -> "LIVE"' in repo and 'fx_provider_freshness_gate_seconds", 20' in vm,
    "http_retry_after_honored": 'Retry-After' in repo and 'h.retryAfterMs' in repo,
    "late_outcome_recovery": 'startNow.plusSeconds(20)' in vm,
    "no_scan_cancelall": vm.count("repository.cancelInFlightRequests()") == 1,
    "rate_age_moves_while_busy": "displayed rate age must keep moving" in vm and "age <= 20.0" in vm,
    "full_live_success_timestamp": "providerReturnedFullLive" in vm,
    "network_stats_in_diagnostics": "market_network_stats" in vm and "outcome_network_stats" in vm and "diagnosticStats" in repo,
    "yahoo_fast_host_failover": repo.count("maxAttempts = 1") >= 3,
    "network_timeouts_bounded": ".connectTimeout(3, TimeUnit.SECONDS)" in repo and ".callTimeout(4, TimeUnit.SECONDS)" in repo,
    "cutin_assets_60": len(drawables) == 60,
    "cutin_four_states": all(x in main for x in ["WIN_ADVANTAGE", "LOSE_ADVANTAGE", "WIN_FINAL", "LOSE_FINAL"]),
    "cutin_3m_30s_1m_15s": "if (isOneMinute) 15_000L else 30_000L" in main,
    "cutin_live_only_advantage": 'it.freshnessStatus == "LIVE"' in main and '(it.ageSeconds ?: 999.0) <= 20.0' in main,
    "cutin_final_from_official_history": 'row.resultStatus in setOf("WIN", "LOSE")' in main and 'row.settledAtJst.isNotBlank()' in main,
    "cutin_user_toggle": 'cut_in_enabled' in prefs and 'setCutInEnabled' in vm and 'Switch(checked = state.cutInEnabled' in main,
    "cutin_multi_pending_no_head_block": "Multiple 1m/3m outcomes can overlap" in main and ".minByOrNull { it.third }" in main,
    "cutin_recent_history_bounded_scan": "state.history.take(256)" in main,
    "cutin_dedupe_memory_bounded": "dedupeCutoff" in main and "shownAtMs.entries.removeAll" in main,
    "cutin_noise_deadband": "minMovePct" in main and "movePct < minMovePct" in main,
    "cutin_1m_15s_assets": "cutin_win_adv_1m_01" in main and "cutin_lose_adv_1m_01" in main and "oneMinuteAdvantage" in main,
    "cutin_trigger_jitter_tolerant": "leadMs - 5_000L" in main and "leadMs + 1_000L" in main,
    "history_cached_in_memory": "@Volatile private var cache" in hist and "cache?.let { return it }" in hist,
    "history_disk_io_off_main": "gmk-history-io" in hist and "ioExecutor.execute" in hist,
    "history_writes_coalesced": "pendingWrite" in hist and "writerScheduled" in hist and "scheduleWriterIfNeeded" in hist,
    "1m_auto_explicit_boundary": 'startOneMinuteScan("AUTO_1M", boundary)' in vm and "entryTarget: ZonedDateTime? = null" in (root / "app/src/main/java/jp/gmk/mobile/domain/OneMinuteLocalEngine.kt").read_text(encoding="utf-8"),
    "1m_auto_23h_boundary_blocked": 'boundary.hour in 9..22' in vm and "1分AUTO見送り: ENTRY時刻が本番時間外" in vm,
    "manual_3m_outcome_uses_live_quote": 'exactMinuteOpen = result.source != "MANUAL"' in vm and "manual live" in vm,
    "outcome_recovery_concurrency_bounded": "outcomeCaptureSemaphore = Semaphore(2)" in vm and "outcomeCaptureSemaphore.withPermit" in vm,
    "yahoo_process_concurrency_bounded": "private val yahooSemaphore = Semaphore(2)" in repo and repo.count("yahooSemaphore.withPermit") >= 3,
    "yahoo_quote_small_window": "nowSec - 10L * 60L" in repo and '.addQueryParameter("period2", (nowSec + 60L).toString())' in repo,
    "yahoo_stale_quote_falls_back": "bestStale: RateRow?" in repo and "syntactically successful but stale query2" in repo,
    "yahoo_stale_candle_falls_back": "bestStale: List<Candle>?" in repo and "lag one or more candles behind query1" in repo,
    "power_policy_visible": "batteryOptimizationExempt" in vm and "backgroundRestricted" in vm and "PowerPolicyWarning" in main,
    "power_policy_in_diagnostics": "battery_optimization_exempt" in vm and "background_restricted" in vm,
    "history_gensokyo_theme": "history_gensokyo_bg" in main and "幻想の相場に、弾を放て" in main,
    "history_summary_three_tiles": all(x in main for x in ["HistorySummaryTile", "3分SKIP", "☯"]),
    "history_win_lose_art": "history_reimu_win" in main and "history_youmu_lose" in main,
    "history_status_cards": all(x in main for x in ["✿  WIN", "⚔  LOSE", "⌛ 10秒後待ち"]),
}
failed = [k for k,v in checks.items() if not v]
print(json.dumps(checks, ensure_ascii=False, indent=2))
if failed:
    print("FAILED:", failed)
    sys.exit(1)
print(f"PASS {len(checks)}/{len(checks)}")

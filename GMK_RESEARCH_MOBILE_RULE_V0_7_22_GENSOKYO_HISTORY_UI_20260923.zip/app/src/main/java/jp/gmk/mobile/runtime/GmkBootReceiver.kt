package jp.gmk.mobile.runtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import jp.gmk.mobile.data.AppPrefs

class GmkBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = AppPrefs(context)
        if (!prefs.autoScan && !prefs.oneMinuteAutoScan) return
        ContextCompat.startForegroundService(
            context,
            Intent(context, GmkRuntimeKeepAliveService::class.java)
        )
    }
}

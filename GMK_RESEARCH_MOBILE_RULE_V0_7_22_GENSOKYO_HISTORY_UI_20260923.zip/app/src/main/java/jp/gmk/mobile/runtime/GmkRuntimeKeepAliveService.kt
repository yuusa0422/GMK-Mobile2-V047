
package jp.gmk.mobile.runtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import jp.gmk.mobile.R
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.ui.GmkViewModel

class GmkRuntimeKeepAliveService : Service() {
    private var runtime: GmkViewModel? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("東方相議録 MOBILE")
                .setContentText("AUTOスキャン / 結果追跡をバックグラウンド監視中")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build()
        )

        // Service-owned runtime survives when the activity is merely backgrounded.
        // Boundary claims + HistoryStore state guards prevent duplicate official records
        // if an Activity ViewModel is alive at the same time.
        runtime = GmkRuntimeHolder.get(application)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = AppPrefs(this)
        if (!prefs.autoScan && !prefs.oneMinuteAutoScan) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        // Runtime is process-owned, not service-owned. Do not cancel the shared
        // scheduler/outcome workers merely because Android recreates the service.
        runtime = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "GMK Runtime",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "AUTOスキャンと結果追跡のバックグラウンド実行"
                    setShowBadge(false)
                }
            )
        }
    }

    companion object {
        private const val CHANNEL_ID = "gmk_runtime"
        private const val NOTIFICATION_ID = 2401
    }
}

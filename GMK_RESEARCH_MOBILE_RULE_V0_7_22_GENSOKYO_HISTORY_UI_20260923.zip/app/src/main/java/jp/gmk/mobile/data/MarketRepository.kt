package jp.gmk.mobile.data

import jp.gmk.mobile.domain.Candle
import jp.gmk.mobile.domain.CandleBatch
import jp.gmk.mobile.domain.RateRow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class MarketRepository(private val prefs: AppPrefs) {
    private val requestCount = AtomicLong(0)
    private val requestSuccessCount = AtomicLong(0)
    private val requestFailureCount = AtomicLong(0)
    private val http429Count = AtomicLong(0)
    private val http5xxCount = AtomicLong(0)
    private val lastNetworkError = AtomicReference<String?>(null)

    fun diagnosticStats(): JSONObject = JSONObject()
        .put("requests", requestCount.get())
        .put("success", requestSuccessCount.get())
        .put("failure", requestFailureCount.get())
        .put("http_429", http429Count.get())
        .put("http_5xx", http5xxCount.get())
        .put("last_error", lastNetworkError.get() ?: JSONObject.NULL)

    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .callTimeout(4, TimeUnit.SECONDS)
        .build()

    private val instruments = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
    private val yahooMap = mapOf(
        "USDJPY" to "JPY=X", "EURJPY" to "EURJPY=X", "GBPJPY" to "GBPJPY=X",
        "AUDJPY" to "AUDJPY=X", "NZDJPY" to "NZDJPY=X"
    )

    suspend fun fetchRates(): List<RateRow> = coroutineScope {
        val fxDeferred = async { fetchFxRates() }
        val btcDeferred = async {
            try {
                fetchBitbankTicker()
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                RateRow("BTCJPY", null, null, null, "bitbank unavailable: ${safeError(t)}", null, "UNAVAILABLE")
            }
        }
        val fxMap = fxDeferred.await()
        val btcRow = btcDeferred.await()
        instruments.map { ins ->
            if (ins == "BTCJPY") btcRow
            else fxMap[ins] ?: RateRow(ins, null, null, null, "unavailable", null, "UNAVAILABLE")
        }
    }

    suspend fun fetchRate(instrument: String): RateRow {
        require(instrument in instruments) { "unsupported instrument: $instrument" }

        if (instrument == "BTCJPY") {
            return try {
                fetchBitbankTicker()
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                RateRow("BTCJPY", null, null, null, "bitbank unavailable: ${safeError(t)}", null, "UNAVAILABLE")
            }
        }

        val sym = yahooMap[instrument]
            ?: return RateRow(instrument, null, null, null, "symbol unavailable", null, "UNAVAILABLE")
        return try {
            fetchYahooQuote(instrument, sym)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            RateRow(instrument, null, null, null, "Yahoo unavailable: ${safeError(t)}", null, "UNAVAILABLE")
        }
    }


    suspend fun fetchMinuteOpenAt(instrument: String, targetEpochMs: Long): Candle? {
        require(instrument in instruments) { "unsupported instrument: $instrument" }
        return if (instrument == "BTCJPY") {
            fetchBitbankMinuteAt(targetEpochMs)
        } else {
            val sym = yahooMap[instrument] ?: return null
            fetchYahooMinuteAt(instrument, sym, targetEpochMs)
        }
    }

    private suspend fun fetchYahooMinuteAt(
        instrument: String,
        symbol: String,
        targetEpochMs: Long
    ): Candle? = withContext(Dispatchers.IO) {
        val hosts = listOf("query2.finance.yahoo.com", "query1.finance.yahoo.com")
        var lastError: Throwable? = null
        for (host in hosts) {
            try {
                val targetSec = targetEpochMs / 1000L
                val url = "https://$host/v8/finance/chart/$symbol".toHttpUrl().newBuilder()
                    .addQueryParameter("interval", "1m")
                    .addQueryParameter("period1", (targetSec - 60L).toString())
                    .addQueryParameter("period2", (targetSec + 180L).toString())
                    .addQueryParameter("includePrePost", "true")
                    .addQueryParameter("events", "history")
                    .build()
                val text = yahooSemaphore.withPermit {
                    executeWithRetry(Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build(), maxAttempts = 1)
                }
                val result = JSONObject(text).optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)
                    ?: throw IOException("$instrument: Yahoo chart result empty")
                val ts = result.optJSONArray("timestamp") ?: return@withContext null
                val q = result.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
                    ?: return@withContext null
                val opens = q.optJSONArray("open") ?: JSONArray()
                val highs = q.optJSONArray("high") ?: JSONArray()
                val lows = q.optJSONArray("low") ?: JSONArray()
                val closes = q.optJSONArray("close") ?: JSONArray()
                val vols = q.optJSONArray("volume") ?: JSONArray()
                val n = minOf(ts.length(), opens.length(), highs.length(), lows.length(), closes.length())
                for (i in 0 until n) {
                    if (ts.optLong(i, 0L) != targetSec) continue
                    val o = opens.optDoubleFinite(i) ?: continue
                    val h = highs.optDoubleFinite(i) ?: o
                    val l = lows.optDoubleFinite(i) ?: o
                    val c = closes.optDoubleFinite(i) ?: o
                    return@withContext Candle(targetEpochMs, o, h, l, c, vols.optDoubleFinite(i) ?: 0.0)
                }
                // query2 can succeed before the exact minute is published; try query1 before giving up.
                continue
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                lastError = t
            }
        }
        if (lastError != null) throw IOException("$instrument: Yahoo minute lookup failed: ${lastError?.message ?: "unknown"}")
        null
    }

    private suspend fun fetchBitbankMinuteAt(targetEpochMs: Long): Candle? = withContext(Dispatchers.IO) {
        val jst = java.time.Instant.ofEpochMilli(targetEpochMs).atZone(ZoneId.of("Asia/Tokyo"))
        val date = jst.format(DateTimeFormatter.ofPattern("yyyyMMdd"))
        val text = executeWithRetry(
            Request.Builder().url("https://public.bitbank.cc/btc_jpy/candlestick/1min/$date").build(),
            maxAttempts = 3
        )
        val cs = JSONObject(text).optJSONObject("data")?.optJSONArray("candlestick") ?: return@withContext null
        for (g in 0 until cs.length()) {
            val ohlcv = cs.optJSONObject(g)?.optJSONArray("ohlcv") ?: continue
            for (i in 0 until ohlcv.length()) {
                val a = ohlcv.optJSONArray(i) ?: continue
                if (a.length() < 6) continue
                val ts = a.optLong(5, 0L)
                if (ts != targetEpochMs) continue
                val o = a.optString(0).toFinitePositiveOrNull() ?: return@withContext null
                val h = a.optString(1).toFinitePositiveOrNull() ?: o
                val l = a.optString(2).toFinitePositiveOrNull() ?: o
                val c = a.optString(3).toFinitePositiveOrNull() ?: o
                val v = a.optString(4).toDoubleOrNull() ?: 0.0
                return@withContext Candle(ts, o, h, l, c, v)
            }
        }
        null
    }

    suspend fun fetchAllCandles(): CandleBatch = coroutineScope {
        val results = instruments.map { ins ->
            async {
                try {
                    Triple(ins, normalizeCandles(fetchCandles(ins)), null)
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    Triple(ins, emptyList<Candle>(), safeError(t))
                }
            }
        }.awaitAll()

        CandleBatch(
            candles = results.associate { it.first to it.second },
            errors = results.mapNotNull { row ->
                row.third?.let { row.first to it }
            }.toMap()
        )
    }

    private suspend fun fetchFxRates(): Map<String, RateRow> = coroutineScope {
        yahooMap.map { (ins, sym) ->
            async {
                val row = try {
                    fetchYahooQuote(ins, sym)
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    RateRow(ins, null, null, null, "Yahoo unavailable: ${safeError(t)}", null, "UNAVAILABLE")
                }
                ins to row
            }
        }.awaitAll().toMap()
    }

    private suspend fun fetchYahooQuote(instrument: String, symbol: String): RateRow = withContext(Dispatchers.IO) {
        val hosts = listOf("query2.finance.yahoo.com", "query1.finance.yahoo.com")
        var lastError: Throwable? = null
        var bestStale: RateRow? = null
        for (host in hosts) {
            try {
                val nowSec = System.currentTimeMillis() / 1000L
                val url = "https://$host/v8/finance/chart/$symbol".toHttpUrl().newBuilder()
                    .addQueryParameter("interval", "1m")
                    .addQueryParameter("period1", (nowSec - 10L * 60L).toString())
                    .addQueryParameter("period2", (nowSec + 60L).toString())
                    .addQueryParameter("includePrePost", "true")
                    .addQueryParameter("events", "history")
                    .build()
                val text = yahooSemaphore.withPermit {
                    executeWithRetry(Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build(), maxAttempts = 1)
                }
                val result = JSONObject(text).optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)
                    ?: throw IOException("Yahoo chart result empty")
                val timestamps = result.optJSONArray("timestamp") ?: JSONArray()
                val quote = result.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
                val closes = quote?.optJSONArray("close") ?: JSONArray()

                var lastPrice: Double? = null
                var lastTs = 0L
                val n = minOf(timestamps.length(), closes.length())
                for (i in n - 1 downTo 0) {
                    val c = closes.optDoubleFinite(i) ?: continue
                    val t = timestamps.optLong(i, 0L)
                    if (t > 0L) {
                        lastPrice = c
                        lastTs = t
                        break
                    }
                }

                val meta = result.optJSONObject("meta")
                val metaPrice = meta?.optDoubleOrNull("regularMarketPrice")
                val metaTs = meta?.optLong("regularMarketTime", 0L) ?: 0L

                val useMeta = metaPrice != null && metaTs > 0L && metaTs >= lastTs
                val price = if (useMeta) metaPrice else (lastPrice ?: metaPrice)
                val ts = if (useMeta) metaTs else if (lastTs > 0L) lastTs else metaTs
                val age = if (ts > 0L) (System.currentTimeMillis() / 1000.0 - ts).coerceAtLeast(0.0) else null
                val freshness = when {
                    price == null -> "UNAVAILABLE"
                    (age ?: 9999.0) <= 20.0 -> "LIVE"
                    else -> "LAST"
                }
                val row = RateRow(instrument, price, null, null, "YahooFX ${host.substringBefore('.')} keyless", age, freshness)
                if (freshness == "LIVE") return@withContext row
                if (price != null && (bestStale == null || (age ?: Double.MAX_VALUE) < (bestStale?.ageSeconds ?: Double.MAX_VALUE))) {
                    bestStale = row
                }
                // A syntactically successful but stale query2 response is not good enough;
                // query1 may already have the fresh tick.
                continue
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                lastError = t
            }
        }
        bestStale?.let { return@withContext it }
        throw IOException("Yahoo FX all endpoints failed: ${lastError?.message ?: "unknown"}")
    }

    private suspend fun fetchBitbankTicker(): RateRow = withContext(Dispatchers.IO) {
        val text = executeWithRetry(Request.Builder().url("https://public.bitbank.cc/btc_jpy/ticker").build())
        val d = JSONObject(text).optJSONObject("data") ?: JSONObject()
        val rawBid = d.optString("buy").toFinitePositiveOrNull()
        val rawAsk = d.optString("sell").toFinitePositiveOrNull()
        val bid = rawBid?.takeIf { rawAsk == null || rawAsk >= it }
        val ask = rawAsk?.takeIf { rawBid == null || it >= rawBid }
        val last = d.optString("last").toFinitePositiveOrNull()
        val tsMs = d.optLong("timestamp", 0L)
        val age = if (tsMs > 0) ((System.currentTimeMillis() - tsMs) / 1000.0).coerceAtLeast(0.0) else null
        val price = last ?: if (bid != null && ask != null) (bid + ask) / 2.0 else (bid ?: ask)
        RateRow("BTCJPY", price, bid, ask, "bitbank", age, if (price != null && (age ?: 9999.0) <= 15.0) "LIVE" else if (price != null) "LAST" else "UNAVAILABLE")
    }

    private suspend fun fetchCandles(instrument: String): List<Candle> {
        return if (instrument == "BTCJPY") {
            fetchBitbankCandles()
        } else {
            fetchYahooCandles(instrument, yahooMap.getValue(instrument))
        }
    }

    private suspend fun fetchYahooCandles(instrument: String, symbol: String): List<Candle> = withContext(Dispatchers.IO) {
        val hosts = listOf("query2.finance.yahoo.com", "query1.finance.yahoo.com")
        var lastError: Throwable? = null
        var bestStale: List<Candle>? = null
        for (host in hosts) {
            try {
                val url = "https://$host/v8/finance/chart/$symbol".toHttpUrl().newBuilder()
                    .addQueryParameter("interval", "1m")
                    .addQueryParameter("range", "1d")
                    .addQueryParameter("includePrePost", "true")
                    .build()
                val text = yahooSemaphore.withPermit {
                    executeWithRetry(Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build(), maxAttempts = 1)
                }
                val result = JSONObject(text).optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)
                    ?: throw IOException("$instrument: Yahoo chart result empty")
                val ts = result.optJSONArray("timestamp") ?: throw IOException("$instrument: Yahoo timestamps empty")
                val q = result.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
                    ?: throw IOException("$instrument: Yahoo quote empty")
                val opens = q.optJSONArray("open") ?: JSONArray()
                val highs = q.optJSONArray("high") ?: JSONArray()
                val lows = q.optJSONArray("low") ?: JSONArray()
                val closes = q.optJSONArray("close") ?: JSONArray()
                val vols = q.optJSONArray("volume") ?: JSONArray()
                val out = buildList {
                    val n = minOf(ts.length(), opens.length(), highs.length(), lows.length(), closes.length())
                    val currentMinuteStartMs = (System.currentTimeMillis() / 60_000L) * 60_000L
                    for (i in 0 until n) {
                        val candleMs = ts.optLong(i) * 1000L
                        if (candleMs <= 0L || candleMs >= currentMinuteStartMs) continue
                        val o = opens.optDoubleFinite(i) ?: continue
                        val h = highs.optDoubleFinite(i) ?: continue
                        val l = lows.optDoubleFinite(i) ?: continue
                        val c = closes.optDoubleFinite(i) ?: continue
                        add(Candle(candleMs, o, h, l, c, vols.optDoubleFinite(i) ?: 0.0))
                    }
                }.takeLast(120)
                if (out.isNotEmpty()) {
                    val expectedLastStartMs = ((System.currentTimeMillis() / 60_000L) * 60_000L) - 60_000L
                    val latest = out.last().timeEpochMs
                    if ((expectedLastStartMs - latest).coerceAtLeast(0L) <= 5_000L) return@withContext out
                    if (bestStale == null || latest > bestStale!!.last().timeEpochMs) bestStale = out
                    // query2 can be reachable but lag one or more candles behind query1.
                    continue
                }
                throw IOException("$instrument: Yahoo candles empty")
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                lastError = t
            }
        }
        bestStale?.let { return@withContext it }
        throw IOException("$instrument: Yahoo all endpoints failed: ${lastError?.message ?: "unknown"}")
    }

    private suspend fun fetchBitbankCandles(): List<Candle> = withContext(Dispatchers.IO) {
        val jst = ZoneId.of("Asia/Tokyo")
        val out = mutableListOf<Candle>()

        suspend fun loadDate(z: ZonedDateTime) {
            val date = z.format(DateTimeFormatter.ofPattern("yyyyMMdd"))
            val text = executeWithRetry(
                Request.Builder().url("https://public.bitbank.cc/btc_jpy/candlestick/1min/$date").build()
            )
            val cs = JSONObject(text).optJSONObject("data")?.optJSONArray("candlestick") ?: return
            val currentMinuteStartMs = (System.currentTimeMillis() / 60_000L) * 60_000L
            for (g in 0 until cs.length()) {
                val ohlcv = cs.optJSONObject(g)?.optJSONArray("ohlcv") ?: continue
                for (i in 0 until ohlcv.length()) {
                    val a = ohlcv.optJSONArray(i) ?: continue
                    if (a.length() < 6) continue
                    val open = a.optString(0).toFinitePositiveOrNull() ?: continue
                    val high = a.optString(1).toFinitePositiveOrNull() ?: continue
                    val low = a.optString(2).toFinitePositiveOrNull() ?: continue
                    val close = a.optString(3).toFinitePositiveOrNull() ?: continue
                    val volume = a.optString(4).toDoubleOrNull() ?: 0.0
                    val ts = a.optLong(5, 0L)
                    if (ts <= 0L || ts >= currentMinuteStartMs) continue
                    out += Candle(ts, open, high, low, close, volume)
                }
            }
        }

        val now = ZonedDateTime.now(jst)
        loadDate(now)

        // Just after midnight there may not yet be 30 complete candles.
        if (out.distinctBy { it.timeEpochMs }.size < 30) {
            loadDate(now.minusDays(1))
        }

        normalizeCandles(out).takeLast(120)
    }

    private fun normalizeCandles(input: List<Candle>): List<Candle> {
        val currentMinuteStartMs = (System.currentTimeMillis() / 60_000L) * 60_000L
        return input
            .asSequence()
            .filter { c ->
                c.timeEpochMs > 0L && c.timeEpochMs < currentMinuteStartMs &&
                c.open.isFinite() && c.high.isFinite() && c.low.isFinite() && c.close.isFinite() &&
                c.open > 0.0 && c.high > 0.0 && c.low > 0.0 && c.close > 0.0 &&
                c.high >= maxOf(c.open, c.close) &&
                c.low <= minOf(c.open, c.close) &&
                c.high >= c.low
            }
            .sortedBy { it.timeEpochMs }
            .distinctBy { it.timeEpochMs }
            .toList()
            .takeLast(120)
    }

    fun cancelInFlightRequests() {
        client.dispatcher.cancelAll()
    }

    private class RequestAbortedException : IOException("request aborted")
    private class HttpStatusException(val statusCode: Int, val retryAfterMs: Long?, message: String) : IOException(message)

    private suspend fun executeWithRetry(req: Request, maxAttempts: Int = 2): String {
        var last: Throwable? = null
        repeat(maxAttempts.coerceAtLeast(1)) { attempt ->
            try {
                return executeCancellable(req)
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (h: HttpStatusException) {
                last = h
                val transient = h.statusCode == 408 || h.statusCode == 425 || h.statusCode == 429 || h.statusCode >= 500
                if (!transient || attempt + 1 >= maxAttempts) throw h
                val backoff = (500L * (attempt + 1) * (attempt + 1)).coerceAtMost(5_000L)
                delay(maxOf(backoff, h.retryAfterMs ?: 0L))
            } catch (t: Throwable) {
                last = t
                if (attempt + 1 < maxAttempts) {
                    val backoff = (500L * (attempt + 1) * (attempt + 1)).coerceAtMost(5_000L)
                    delay(backoff)
                }
            }
        }
        throw IOException(last?.message ?: "network request failed", last)
    }

    private suspend fun executeCancellable(req: Request): String =
        suspendCancellableCoroutine { cont ->
            requestCount.incrementAndGet()
            val call = client.newCall(req)

            cont.invokeOnCancellation { call.cancel() }

            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    requestFailureCount.incrementAndGet()
                    val error = if (call.isCanceled()) RequestAbortedException() else e
                    lastNetworkError.set(safeError(error))
                    if (cont.isActive) {
                        runCatching { cont.resumeWith(Result.failure(error)) }
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { r ->
                        val text = r.body?.string().orEmpty()
                        if (!cont.isActive) return

                        if (!r.isSuccessful) {
                            requestFailureCount.incrementAndGet()
                            if (r.code == 429) http429Count.incrementAndGet()
                            if (r.code >= 500) http5xxCount.incrementAndGet()
                            val retryAfterMs = r.header("Retry-After")?.toLongOrNull()?.times(1_000L)?.coerceIn(0L, 30_000L)
                            val err = HttpStatusException(r.code, retryAfterMs, "HTTP ${r.code}: ${text.take(180)}")
                            lastNetworkError.set(safeError(err))
                            runCatching { cont.resumeWith(Result.failure(err)) }
                        } else {
                            requestSuccessCount.incrementAndGet()
                            lastNetworkError.set(null)
                            runCatching { cont.resumeWith(Result.success(text)) }
                        }
                    }
                }
            })
        }

    private fun safeError(t: Throwable): String = (t.message ?: t::class.java.simpleName)
        .replace(Regex("""Bearer\s+[^\s]+""", RegexOption.IGNORE_CASE), "Bearer ***")
        .take(180)

    companion object {
        // Yahoo is an undocumented endpoint. Limit burst concurrency process-wide across
        // live-rate, candle-scan, and outcome-recovery repositories to reduce 429s.
        private val yahooSemaphore = Semaphore(2)
    }

}

private fun JSONObject.optDoubleOrNull(name: String): Double? {
    if (!has(name) || isNull(name)) return null
    val d = optDouble(name, Double.NaN)
    return if (d.isFinite()) d else null
}

private fun JSONArray.optDoubleFinite(index: Int): Double? {
    if (index < 0 || index >= length() || isNull(index)) return null
    val d = optDouble(index, Double.NaN)
    return if (d.isFinite()) d else null
}

private fun String.toFinitePositiveOrNull(): Double? {
    val d = toDoubleOrNull() ?: return null
    return d.takeIf { it.isFinite() && it > 0.0 }
}

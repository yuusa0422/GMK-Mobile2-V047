package jp.gmk.mobile.data

import android.content.Context
import jp.gmk.mobile.domain.HistoryRow
import jp.gmk.mobile.domain.ScanResult
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE)

    fun add(result: ScanResult) {
        val top = result.top1 ?: return
        val current = load().toMutableList()

        if (result.source == "AUTO") {
            current.removeAll { it.source == "AUTO" && it.judgeTimeJst == result.judgeTimeJst }
        }

        current.add(0, HistoryRow(
            id = System.currentTimeMillis(),
            source = result.source,
            atJst = result.atJst,
            instrument = top.instrument,
            direction = top.direction,
            grade = top.grade,
            decision = top.decision,
            candidateRank = top.rank,
            regime = top.regime,
            judgeTimeJst = result.judgeTimeJst
        ))
        save(current.take(200))
    }

    fun load(): List<HistoryRow> {
        fun decode(text: String): List<HistoryRow>? {
            val array = try {
                JSONArray(text)
            } catch (_: Throwable) {
                return null
            }

            return buildList {
                for (i in 0 until array.length()) {
                    val x = array.optJSONObject(i) ?: continue
                    val instrument = x.optString("instrument")
                    val direction = x.optString("direction")
                    if (instrument.isBlank() || direction !in setOf("HIGH", "LOW")) continue

                    val grade = x.optString("grade", x.optString("rank", "D")).uppercase()
                    if (!isKnownGrade(grade)) continue

                    val decision = x.optString("decision").uppercase().ifBlank {
                        if (grade == "D") "SKIP" else "ENTRY"
                    }
                    if (decision !in setOf("ENTRY", "SKIP")) continue

                    add(HistoryRow(
                        id = x.optLong("id").takeIf { it > 0L } ?: System.currentTimeMillis(),
                        source = x.optString("source"),
                        atJst = x.optString("at_jst"),
                        instrument = instrument,
                        direction = direction,
                        grade = grade,
                        decision = decision,
                        candidateRank = x.optInt("candidate_rank", 1).coerceAtLeast(1),
                        regime = x.optString("regime", "UNKNOWN"),
                        judgeTimeJst = x.optString("judge_time_jst", "")
                    ))
                }
            }
        }

        val primary = prefs.getString("items", "[]") ?: "[]"
        decode(primary)?.let { return it }

        // Preserve the broken primary and try the last known-good snapshot.
        prefs.edit().putString("items_corrupt_last", primary.take(200_000)).commit()

        val backup = prefs.getString("items_backup", "[]") ?: "[]"
        val recovered = decode(backup)
        if (recovered != null) {
            prefs.edit()
                .putString("items", backup)
                .putBoolean("history_recovered_from_backup", true)
                .commit()
            return recovered
        }

        return emptyList()
    }

    private fun isKnownGrade(grade: String): Boolean {
        if (grade in setOf("S", "A", "B", "C", "D")) return true
        if (!grade.startsWith("C")) return false
        val n = grade.removePrefix("C").toIntOrNull() ?: return false
        return n in 1..10
    }

    private fun save(rows: List<HistoryRow>) {
        val a = JSONArray()
        rows.forEach { h ->
            a.put(JSONObject()
                .put("id", h.id)
                .put("source", h.source)
                .put("at_jst", h.atJst)
                .put("instrument", h.instrument)
                .put("direction", h.direction)
                .put("grade", h.grade)
                .put("decision", h.decision)
                .put("candidate_rank", h.candidateRank)
                .put("regime", h.regime)
                .put("judge_time_jst", h.judgeTimeJst))
        }
        val payload = a.toString()
        val previous = prefs.getString("items", null)

        // Write the current valid payload as backup before replacing primary.
        val editor = prefs.edit()
        if (!previous.isNullOrBlank()) {
            try {
                JSONArray(previous)
                editor.putString("items_backup", previous)
            } catch (_: Throwable) {
                // Do not promote a corrupt primary into backup.
            }
        }
        editor.putString("items", payload)
        editor.putBoolean("history_recovered_from_backup", false)
        editor.commit()
    }
}

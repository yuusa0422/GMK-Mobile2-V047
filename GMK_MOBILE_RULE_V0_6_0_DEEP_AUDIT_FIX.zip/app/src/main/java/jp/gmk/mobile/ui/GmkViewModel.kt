package jp.gmk.mobile.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import jp.gmk.mobile.BuildConfig
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.domain.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import org.json.JSONArray
import org.json.JSONObject


data class GmkUiState(
    val connected: Boolean = false,
    val busy: Boolean = false,
    val error: String? = null,
    val rateStatus: String? = null,
    val scanStatus: String? = null,
    val rates: List<RateRow> = emptyList(),
    val scan: ScanResult? = null,
    val history: List<HistoryRow> = emptyList(),
    val autoScan: Boolean = true,
    val oandaToken: String = "",
    val oandaAccountId: String = "",
    val oandaEnvironment: String = "practice",
    val yahooFallback: Boolean = true,
    val lastRateUpdateMs: Long = 0L,
    val lastRateSuccessMs: Long = 0L,
    val lastScanAttemptMs: Long = 0L,
    val lastScanSuccessMs: Long = 0L,
    val modeLabel: String = "端末単体",
    val rateLiveCount: Int = 0,
    val rateAvailableCount: Int = 0,
    val scannableCount: Int = 0,
    val lastScanExcluded: Map<String, String> = emptyMap(),
    val lastCandleErrors: Map<String, String> = emptyMap(),
    val lastCandleLatestMs: Map<String, Long> = emptyMap(),
    val quoteCandleDivergencePct: Map<String, Double> = emptyMap()
)

class GmkViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    private val historyStore = HistoryStore(app)
    private val repository = MarketRepository(prefs)
    private val ruleEngine = LocalRuleEngine()
    private val jst = ZoneId.of("Asia/Tokyo")

    private val _state = MutableStateFlow(
        GmkUiState(
            history = historyStore.load(),
            autoScan = prefs.autoScan,
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = prefs.yahooFallback
        )
    )
    val state: StateFlow<GmkUiState> = _state

    private var rateJob: Job? = null
    private var autoJob: Job? = null
    private var lastAutoBoundaryKey: String? = prefs.lastAutoBoundaryKey.takeIf { it.isNotBlank() }
    private var lastSchedulerTickMs: Long = 0L
    private var lastSchedulerElapsedMs: Long = 0L

    init {
        startRateLoop()
        startAutoLoop()
    }

    private fun allRatesAvailable(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rows.all { it.price != null }

    private fun rateLiveCount(rows: List<RateRow>): Int =
        rows.count { it.price != null && it.freshnessStatus == "LIVE" }

    private fun allFresh(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rateLiveCount(rows) == 6

    private fun rateSummary(rows: List<RateRow>): String? {
        if (rows.isEmpty()) return "レート取得待機中"
        val missing = rows.filter { it.price == null }.map { it.instrument }
        val last = rows.filter { it.price != null && it.freshnessStatus != "LIVE" }.map { it.instrument }
        return when {
            missing.isNotEmpty() -> "未取得: ${missing.joinToString(",")}"
            last.isNotEmpty() -> "LIVE ${rateLiveCount(rows)}/6 / LAST: ${last.joinToString(",")}"
            else -> null
        }
    }

    private fun mergeRates(previous: List<RateRow>, incoming: List<RateRow>, elapsedSeconds: Double): List<RateRow> {
        val old = previous.associateBy { it.instrument }

        fun effectiveAge(r: RateRow): Double =
            r.ageSeconds ?: Double.MAX_VALUE

        return incoming.map { candidate ->
            val cached = old[candidate.instrument]

            if (cached?.price == null) {
                candidate
            } else if (candidate.price == null) {
                cached.copy(
                    ageSeconds = effectiveAge(cached) + elapsedSeconds.coerceAtLeast(0.0),
                    freshnessStatus = "LAST",
                    source = "${cached.source.removeSuffix(" cache")} cache"
                )
            } else {
                val cachedAdvancedAge = effectiveAge(cached) + elapsedSeconds.coerceAtLeast(0.0)

                val chooseIncoming = when {
                    candidate.freshnessStatus == "LIVE" && cached.freshnessStatus != "LIVE" -> true
                    candidate.freshnessStatus != "LIVE" && cached.freshnessStatus == "LIVE" &&
                        cachedAdvancedAge <= 75.0 -> false
                    else -> effectiveAge(candidate) <= cachedAdvancedAge
                }

                if (chooseIncoming) {
                    candidate
                } else {
                    cached.copy(
                        ageSeconds = cachedAdvancedAge,
                        freshnessStatus = if (cachedAdvancedAge <= 75.0 && cached.freshnessStatus == "LIVE") "LIVE" else "LAST",
                        source = "${cached.source.removeSuffix(" cache")} cache"
                    )
                }
            }
        }
    }

    private fun startRateLoop() {
        rateJob?.cancel()
        rateJob = viewModelScope.launch {
            while (isActive) {
                if (_state.value.busy) {
                    delay(250)
                    continue
                }

                try {
                    val before = _state.value
                    val attemptStartedMs = System.currentTimeMillis()
                    val elapsed = if (before.lastRateUpdateMs > 0L) {
                        (attemptStartedMs - before.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0

                    val incoming = withTimeout(5_500) { repository.fetchRates() }
                    val completedMs = System.currentTimeMillis()
                    val rows = mergeRates(before.rates, incoming, elapsed)
                    val providerReturnedPrice = incoming.any { it.price != null }

                    _state.value = _state.value.copy(
                        rates = rows,
                        connected = allFresh(rows),
                        rateLiveCount = rateLiveCount(rows),
                        rateAvailableCount = rows.count { it.price != null },
                        rateStatus = rateSummary(rows),
                        lastRateUpdateMs = completedMs,
                        lastRateSuccessMs = if (providerReturnedPrice) completedMs else before.lastRateSuccessMs
                    )
                } catch (te: TimeoutCancellationException) {
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    val cached = s.rates.map { r ->
                        if (r.price != null) {
                            r.copy(
                                ageSeconds = (r.ageSeconds ?: 0.0) + elapsed,
                                freshnessStatus = "LAST",
                                source = "${r.source.removeSuffix(" cache")} cache"
                            )
                        } else r.copy(freshnessStatus = "UNAVAILABLE")
                    }
                    _state.value = s.copy(
                        connected = false,
                        rates = cached,
                        rateLiveCount = 0,
                        rateAvailableCount = cached.count { it.price != null },
                        rateStatus = "レート再取得タイムアウト（表示値はキャッシュ）",
                        lastRateUpdateMs = nowMs
                    )
                } catch (ce: CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    val cached = s.rates.map { r ->
                        if (r.price != null) {
                            r.copy(
                                ageSeconds = (r.ageSeconds ?: 0.0) + elapsed,
                                freshnessStatus = "LAST",
                                source = "${r.source.removeSuffix(" cache")} cache"
                            )
                        } else r.copy(freshnessStatus = "UNAVAILABLE")
                    }
                    _state.value = s.copy(
                        connected = false,
                        rates = cached,
                        rateLiveCount = 0,
                        rateAvailableCount = cached.count { it.price != null },
                        rateStatus = "レート再取得失敗（表示値はキャッシュ）: ${e.message}",
                        lastRateUpdateMs = nowMs
                    )
                }
                delay(6_000)
            }
        }
    }

    private fun latestScheduledT10AtOrBefore(now: ZonedDateTime): ZonedDateTime {
        var m = now.truncatedTo(ChronoUnit.MINUTES)
        while (m.minute % 5 != 4) m = m.minusMinutes(1)
        return m.withSecond(50).withNano(0)
    }

    private fun isExpectedFxWeekendGap(aMs: Long, bMs: Long): Boolean {
        if (aMs <= 0L || bMs <= aMs) return false
        val gapMs = bMs - aMs
        if (gapMs < 24L * 60L * 60L * 1000L) return false

        val a = java.time.Instant.ofEpochMilli(aMs).atZone(java.time.ZoneOffset.UTC)
        val b = java.time.Instant.ofEpochMilli(bMs).atZone(java.time.ZoneOffset.UTC)

        val olderOk = a.dayOfWeek == java.time.DayOfWeek.FRIDAY
        val newerOk = b.dayOfWeek == java.time.DayOfWeek.SUNDAY ||
            b.dayOfWeek == java.time.DayOfWeek.MONDAY

        return olderOk && newerOk && gapMs <= 80L * 60L * 60L * 1000L
    }

    private fun isKnownEntryContractGrade(grade: String): Boolean {
        val g = grade.uppercase()
        if (g in setOf("S", "A", "B", "C", "D")) return true
        if (!g.startsWith("C")) return false
        val n = g.removePrefix("C").toIntOrNull() ?: return false
        return n in 1..10
    }

    private fun startAutoLoop() {
        autoJob?.cancel()
        autoJob = viewModelScope.launch {
            while (isActive) {
                val now = ZonedDateTime.now(jst)
                val nowMs = System.currentTimeMillis()
                val elapsedNow = android.os.SystemClock.elapsedRealtime()

                if (prefs.autoScan) {
                    // Use monotonic elapsed time so manual clock/NTP changes do not create a false MISSED.
                    if (lastSchedulerTickMs > 0L &&
                        lastSchedulerElapsedMs > 0L &&
                        elapsedNow - lastSchedulerElapsedMs > 1_500L) {
                        val previousTick = java.time.Instant.ofEpochMilli(lastSchedulerTickMs).atZone(jst)
                        val scheduled = latestScheduledT10AtOrBefore(now)

                        if (scheduled.isAfter(previousTick) && scheduled.isBefore(now)) {
                            val boundary = scheduled.plusSeconds(10).truncatedTo(ChronoUnit.MINUTES)
                            val key = boundary.toLocalDateTime().toString()

                            if (lastAutoBoundaryKey != key) {
                                lastAutoBoundaryKey = key
                                prefs.lastAutoBoundaryKey = key
                                _state.value = _state.value.copy(
                                    scan = null,
                                    scanStatus = "AUTO_SCAN_MISSED: 端末スリープ/停止中にT-10を通過"
                                )
                            }
                        }
                    }

                    val inSlotWindow = now.minute % 5 == 4 && now.second in 50..54

                    if (inSlotWindow) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()

                        if (lastAutoBoundaryKey != key) {
                            lastAutoBoundaryKey = key
                            prefs.lastAutoBoundaryKey = key

                            if (now.second == 50 && !_state.value.busy) {
                                performScan("AUTO", boundary)
                            } else {
                                _state.value = _state.value.copy(
                                    scan = null,
                                    scanStatus = if (_state.value.busy) {
                                        "AUTO_SCAN_MISSED: T-10時点で別処理実行中"
                                    } else {
                                        "AUTO_SCAN_MISSED: ${now.second}秒開始は許可しません"
                                    }
                                )
                            }
                        }
                    }
                }

                lastSchedulerTickMs = nowMs
                lastSchedulerElapsedMs = elapsedNow
                delay(100)
            }
        }
    }

    private fun millisUntilNextAutoT10(now: ZonedDateTime = ZonedDateTime.now(jst)): Long {
        var candidate = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        while (candidate.minute % 5 != 4 || !candidate.isAfter(now)) {
            candidate = candidate.plusMinutes(1).withSecond(50).withNano(0)
        }
        return java.time.Duration.between(now, candidate).toMillis()
    }

    fun manualScan() {
        if (_state.value.busy) return

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..20_000L) {
                _state.value = _state.value.copy(
                    scanStatus = "手動スキャン待機: AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        viewModelScope.launch { performScan("MANUAL", null) }
    }

    private suspend fun performScan(source: String, autoBoundary: ZonedDateTime?) {
        // Raise the scan lock first so the rate loop cannot start a new request
        // between cancelAll() and the beginning of candle acquisition.
        _state.value = _state.value.copy(
            busy = true,
            scan = null,
            scannableCount = 0,
            lastScanExcluded = emptyMap(),
            lastCandleErrors = emptyMap(),
            lastCandleLatestMs = emptyMap(),
            quoteCandleDivergencePct = emptyMap(),
            lastScanAttemptMs = System.currentTimeMillis(),
            scanStatus = if (source == "AUTO") "AUTOスキャン実行中" else "手動スキャン実行中",
            error = null
        )

        // A non-critical rate refresh must never consume the T-10 scan window.
        repository.cancelInFlightRequests()

        try {
            val batch = if (source == "AUTO") {
                // AUTO starts at T-10. Do not let slow network publish after entry time.
                withTimeout(8_500) { repository.fetchAllCandles() }
            } else {
                withTimeout(18_000) { repository.fetchAllCandles() }
            }

            val candles = batch.candles
            val required = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
            val nowMs = System.currentTimeMillis()
            val latestTimes = required.associateWith { ins ->
                candles[ins].orEmpty().maxOfOrNull { it.timeEpochMs } ?: 0L
            }

            val excluded = linkedMapOf<String, String>()
            val eligible = linkedMapOf<String, List<Candle>>()

            required.forEach { ins ->
                val rows = candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                val fetchError = batch.errors[ins]

                when {
                    fetchError != null -> excluded[ins] = "取得失敗: $fetchError"
                    rows.size < 21 -> excluded[ins] = "1分足不足 ${rows.size}/21"
                    else -> {
                        val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                        val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                        // Timestamp is the beginning of the completed M1 candle.
                        // 240s keeps short provider delays usable without accepting closed-market history.
                        val tail = rows.takeLast(30)
                        val gapPairs = tail.zipWithNext { a, b -> Triple(a.timeEpochMs, b.timeEpochMs, b.timeEpochMs - a.timeEpochMs) }
                        val unexpectedGaps = gapPairs.filter { (a, b, gap) ->
                            gap > 10L * 60_000L &&
                                !(ins != "BTCJPY" && isExpectedFxWeekendGap(a, b))
                        }
                        val spanMs = if (tail.size >= 2) tail.last().timeEpochMs - tail.first().timeEpochMs else Long.MAX_VALUE
                        val hasWeekendBridge = gapPairs.any { (a, b, gap) ->
                            gap > 10L * 60_000L && ins != "BTCJPY" && isExpectedFxWeekendGap(a, b)
                        }

                        when {
                            last <= 0L || ageMs > 240_000L ->
                                excluded[ins] = "1分足STALE ${if (ageMs == Long.MAX_VALUE) "不明" else "${ageMs / 1000}s"}"
                            unexpectedGaps.isNotEmpty() ->
                                excluded[ins] = "1分足大欠損 gap=${unexpectedGaps.maxOf { it.third } / 60_000L}m"
                            !hasWeekendBridge && tail.size >= 30 && spanMs > 45L * 60_000L ->
                                excluded[ins] = "1分足欠損多発 span=${spanMs / 60_000L}m"
                            else -> eligible[ins] = rows
                        }
                    }
                }
            }

            val liveRates = _state.value.rates.associateBy { it.instrument }
            val divergence = linkedMapOf<String, Double>()
            eligible.forEach { (ins, rows) ->
                val q = liveRates[ins]
                val candleClose = rows.lastOrNull()?.close
                if (q?.price != null && q.freshnessStatus == "LIVE" &&
                    candleClose != null && candleClose > 0.0) {
                    val pct = kotlin.math.abs(q.price - candleClose) / candleClose * 100.0
                    divergence[ins] = pct
                }
            }

            val divergenceWarnings = divergence
                .filter { (ins, pct) -> pct >= if (ins == "BTCJPY") 1.50 else 0.50 }
                .map { (ins, pct) -> "$ins quote/candle乖離 ${"%.3f".format(pct)}%" }

            if (eligible.isEmpty()) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = 0,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン待機: " + excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // AUTO result must still be ready before the target frame opens.
            if (source == "AUTO" && autoBoundary != null) {
                val remainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (remainingMs <= 400L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 対象枠開始まで${remainingMs.coerceAtLeast(0)}ms"
                    )
                    return
                }
            }

            val decisionTime = ZonedDateTime.now(jst)
            val result0 = withContext(Dispatchers.Default) {
                ruleEngine.scan(eligible, source, decisionTime, autoBoundary)
            }

            if (source == "AUTO" && autoBoundary != null) {
                val publishRemainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (publishRemainingMs <= 200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 判定完了が対象枠直前/開始後"
                    )
                    return
                }
            }

            if (result0.candidates.isEmpty()) error("有効候補0件")
            if (result0.candidates.size != eligible.size) {
                error("候補数異常: ${result0.candidates.size}/${eligible.size}")
            }

            val expectedRanks = (1..result0.candidates.size).toSet()
            if (result0.candidates.map { it.rank }.toSet() != expectedRanks) {
                error("順位整合性エラー")
            }

            if (result0.candidates.any { it.direction !in setOf("HIGH", "LOW") }) {
                error("方向値エラー")
            }

            if (result0.candidates.any { !isKnownEntryContractGrade(it.grade) }) {
                error("未知ランク検出")
            }

            if (result0.candidates.any {
                    (it.grade == "D" && it.decision != "SKIP") ||
                    (it.grade != "D" && it.decision != "ENTRY")
                }) {
                error("ENTRY/SKIP契約違反")
            }

            val coverageWarning = if (excluded.isNotEmpty()) {
                "部分スキャン ${eligible.size}/6: TOP1は利用可能通貨内の順位 / " +
                    excluded.entries.joinToString(", ") { "${it.key}=${it.value}" }
            } else null

            val result = result0.copy(
                warnings = result0.warnings + listOfNotNull(coverageWarning) + divergenceWarnings
            )

            historyStore.add(result)

            _state.value = _state.value.copy(
                busy = false,
                scan = result,
                history = historyStore.load(),
                lastScanSuccessMs = System.currentTimeMillis(),
                scannableCount = eligible.size,
                lastScanExcluded = excluded,
                lastCandleErrors = batch.errors,
                lastCandleLatestMs = latestTimes,
                quoteCandleDivergencePct = divergence,
                scanStatus = coverageWarning ?: "スキャン完了 ${eligible.size}/6",
                error = null
            )
        } catch (e: TimeoutCancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "${source}スキャン失敗: 市場データ取得タイムアウト",
                error = null
            )
        } catch (ce: CancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = if (source == "AUTO") "AUTOスキャン停止" else "スキャン停止",
                error = null
            )
            throw ce
        } catch (e: Exception) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "スキャン失敗: ${e.message}",
                error = null
            )
        }
    }

    fun buildDiagnosticJson(): String {
        val s = _state.value
        val root = JSONObject()
            .put("generated_at_jst", ZonedDateTime.now(jst).toString())
            .put("app", "GMK MOBILE Rule v${BuildConfig.VERSION_NAME}")
            .put("version_code", BuildConfig.VERSION_CODE)
            .put("connected_6", s.connected)
            .put("available_6", allRatesAvailable(s.rates))
            .put("live_6", allFresh(s.rates))
            .put("busy", s.busy)
            .put("error", s.error ?: JSONObject.NULL)
            .put("rate_status", s.rateStatus ?: JSONObject.NULL)
            .put("scan_status", s.scanStatus ?: JSONObject.NULL)
            .put("auto_scan", s.autoScan)
            .put("oanda_environment", s.oandaEnvironment)
            .put("oanda_token_configured", s.oandaToken.isNotBlank())
            .put("oanda_account_configured", s.oandaAccountId.isNotBlank())
            .put("yahoo_fallback", s.yahooFallback)
            .put("last_rate_update_ms", s.lastRateUpdateMs)
            .put("last_rate_success_ms", s.lastRateSuccessMs)
            .put("last_auto_boundary_key", lastAutoBoundaryKey ?: JSONObject.NULL)
            .put("last_scan_attempt_ms", s.lastScanAttemptMs)
            .put("last_scan_success_ms", s.lastScanSuccessMs)
            .put("rate_live_count", s.rateLiveCount)
            .put("rate_available_count", s.rateAvailableCount)
            .put("scannable_count", s.scannableCount)
            .put("last_scan_excluded", JSONObject(s.lastScanExcluded))
            .put("last_candle_errors", JSONObject(s.lastCandleErrors))
            .put("last_candle_latest_ms", JSONObject(s.lastCandleLatestMs))
            .put("quote_candle_divergence_pct", JSONObject(s.quoteCandleDivergencePct))
            .put("last_scan_full_coverage", s.scan?.candidates?.size == 6)
            .put("last_scan_candidate_count", s.scan?.candidates?.size ?: 0)
        val rates = JSONArray()
        s.rates.forEach { r -> rates.put(JSONObject()
            .put("instrument", r.instrument).put("price", r.price ?: JSONObject.NULL)
            .put("bid", r.bid ?: JSONObject.NULL).put("ask", r.ask ?: JSONObject.NULL)
            .put("source", r.source).put("age_seconds", r.ageSeconds ?: JSONObject.NULL)
            .put("freshness", r.freshnessStatus)) }
        root.put("rates", rates)
        s.scan?.let { scan ->
            val cands = JSONArray()
            scan.candidates.forEach { c -> cands.put(JSONObject()
                .put("rank", c.rank).put("instrument", c.instrument).put("direction", c.direction)
                .put("grade", c.grade).put("probability", c.probability ?: JSONObject.NULL)
                .put("decision", c.decision).put("score", c.score)
                .put("regime", c.regime)
                .put("regime_confidence", c.regimeConfidence)
                .put("reasons", JSONArray(c.reasons))) }
            root.put("last_scan", JSONObject()
                .put("scan_id", scan.scanId).put("source", scan.source).put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst).put("judge_time_jst", scan.judgeTimeJst)
                .put("warnings", JSONArray(scan.warnings)).put("candidates", cands))
        }
        return root.toString(2)
    }

    fun setAuto(value: Boolean) {
        prefs.autoScan = value
        _state.value = _state.value.copy(autoScan = value)
        startAutoLoop()
    }

    fun loadHistory() {
        _state.value = _state.value.copy(history = historyStore.load())
    }

    fun saveSettings(token: String, accountId: String, environment: String, yahooFallback: Boolean) {
        prefs.oandaToken = token
        prefs.oandaAccountId = accountId
        prefs.oandaEnvironment = environment
        prefs.yahooFallback = yahooFallback
        _state.value = _state.value.copy(
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = prefs.yahooFallback,
            rateStatus = "設定を保存しました。レート再接続中",
            error = null
        )
        startRateLoop()
    }

    override fun onCleared() {
        rateJob?.cancel()
        autoJob?.cancel()
        super.onCleared()
    }
}

package jp.gmk.mobile

import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import jp.gmk.mobile.ui.GmkViewModel
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.max

private val Paper = Color(0xFFF6EBDD)
private val Paper2 = Color(0xFFFFF8EE)
private val Wood = Color(0xFF4A3029)
private val Wine = Color(0xFFA63847)
private val WineDark = Color(0xFF6D2430)
private val Ink = Color(0xFF35211E)
private val High = Color(0xFFC73B4D)
private val Low = Color(0xFF315FB6)
private val Gold = Color(0xFFB7893C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Wine, background = Paper)) { GmkApp() }
        }
    }
}

enum class Tab { Scan, History, Settings }

@Composable
fun GmkApp(vm: GmkViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var tab by remember { mutableStateOf(Tab.Scan) }
    val context = LocalContext.current
    val diagnosticLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching {
                val stream = requireNotNull(context.contentResolver.openOutputStream(uri)) { "保存先を開けません" }
                stream.use { out ->
                    out.write(vm.buildDiagnosticJson().toByteArray(Charsets.UTF_8))
                    out.flush()
                }
                true
            }.getOrDefault(false)
            Toast.makeText(
                context,
                if (ok) "診断ログを保存しました" else "診断ログの保存に失敗しました",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
    Scaffold(
        containerColor = Paper,
        bottomBar = { BottomBar(tab) { tab = it; if (it == Tab.History) vm.loadHistory() } }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.Scan -> ScanScreen(state, vm::manualScan, vm::setAuto)
                Tab.History -> HistoryScreen(state.history)
                Tab.Settings -> SettingsScreen(state, vm::saveSettings) { diagnosticLauncher.launch("GMK_DIAGNOSTICS_${System.currentTimeMillis()}.json") }
            }
        }
    }
}

@Composable
private fun ScanScreen(state: GmkUiState, onScan: () -> Unit, onAuto: (Boolean) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Paper)) {
        item {
            Image(
                painterResource(R.drawable.gmk_header), null,
                Modifier.fillMaxWidth().aspectRatio(864f / 415f),
                contentScale = ContentScale.Crop
            )
            StatusStrip(state)
            LocalOnlyStrip()
            ModePanel(state.autoScan, onAuto)
            CountdownPanel(onScan, state.busy)
        }
        item { Top1Card(state.scan?.top1, state.scan?.candidates?.size ?: 0) }
        item { SectionTitle("スキャン結果一覧") }
        val results = state.scan?.candidates.orEmpty()
        if (results.isEmpty()) {
            items(state.rates) { RateOnlyRow(it) }
        } else {
            items(results) { c -> ResultRow(c, state.rates.firstOrNull { it.instrument == c.instrument }) }

            val candidateSet = results.map { it.instrument }.toSet()
            val excludedRates = state.rates.filter { it.instrument !in candidateSet }
            if (excludedRates.isNotEmpty()) {
                item { SectionTitle("今回の判定対象外") }
                items(excludedRates) { RateOnlyRow(it) }
            }
        }

        if (state.lastScanExcluded.isNotEmpty()) {
            item {
                Text(
                    state.lastScanExcluded.entries.joinToString(" / ") { "${it.key}: ${it.value}" },
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    color = WineDark,
                    fontSize = 11.sp
                )
            }
        }

        val divergenceAlerts = state.quoteCandleDivergencePct.filter { (ins, pct) ->
            pct >= if (ins == "BTCJPY") 1.50 else 0.50
        }
        if (divergenceAlerts.isNotEmpty()) {
            item {
                Text(
                    "価格整合注意: " + divergenceAlerts.entries.joinToString(" / ") {
                        "${it.key} ${"%.3f".format(it.value)}%"
                    },
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    color = WineDark,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item { RecentHistoryPreview(state.history) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun LocalOnlyStrip() {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFFEFE3D3)).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("端末単体版", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WineDark)
        Spacer(Modifier.width(8.dp))
        Text("判定・履歴はスマホ内 / クラウド不要", fontSize = 10.sp, color = Ink)
    }
}

@Composable
private fun StatusStrip(state: GmkUiState) {
    val allLive = state.rateLiveCount == 6
    val bg = when {
        allLive -> Color(0xFFE9F1E5)
        state.rateAvailableCount > 0 -> Color(0xFFFFF1D7)
        else -> Color(0xFFF7E0E0)
    }

    Column(
        Modifier.fillMaxWidth().background(bg).padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when {
                    allLive -> "● 6/6 LIVE"
                    state.rateAvailableCount > 0 ->
                        "● LIVE ${state.rateLiveCount}/6  取得 ${state.rateAvailableCount}/6"
                    else -> "● レート取得待機"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (allLive) Color(0xFF416C3C) else WineDark
            )
            Spacer(Modifier.weight(1f))
            if (state.scannableCount > 0) {
                Text("判定可能 ${state.scannableCount}/6", fontSize = 10.sp, color = Ink)
            }
        }

        state.rateStatus?.let {
            Text(it.take(180), fontSize = 10.sp, color = WineDark, maxLines = 2)
        }
        state.scanStatus?.let {
            Text(it.take(220), fontSize = 10.sp, color = Ink, maxLines = 3)
        }
        state.error?.let {
            Text(it.take(180), fontSize = 10.sp, color = WineDark, maxLines = 2)
        }
    }
}

@Composable
private fun ModePanel(auto: Boolean, onAuto: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(10.dp)
            .border(1.dp, Color(0xFFB89A84), RoundedCornerShape(8.dp))
            .background(Paper2).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("判定モード", fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.width(10.dp))
        ModeChip("3分判定", true)
        Spacer(Modifier.width(6.dp))
        ModeChip("5分枠", false)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("AUTO SCAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Switch(checked = auto, onCheckedChange = onAuto)
        }
    }
}

@Composable
private fun ModeChip(text: String, active: Boolean) {
    Box(
        Modifier.background(if (active) Wine else Color(0xFFE5D8CC), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun CountdownPanel(onScan: () -> Unit, busy: Boolean) {
    var seconds by remember { mutableStateOf(nextScanSeconds()) }
    LaunchedEffect(Unit) { while (true) { seconds = nextScanSeconds(); delay(1000) } }
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
        Card(Modifier.weight(0.9f), colors = CardDefaults.cardColors(containerColor = Paper2)) {
            Column(Modifier.padding(12.dp)) {
                Text("次回AUTOまで", fontSize = 12.sp, color = Ink)
                Text(String.format("%02d:%02d", seconds / 60, seconds % 60), fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
        Spacer(Modifier.width(8.dp))
        Button(
            onClick = onScan,
            enabled = !busy,
            modifier = Modifier.weight(1.35f).height(78.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Wine),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(if (busy) "スキャン中…" else "今すぐスキャン  ›", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun nextScanSeconds(): Int {
    val z = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"))
    var boundary = z.truncatedTo(ChronoUnit.MINUTES).withSecond(0).withNano(0)
    val add = (5 - boundary.minute % 5) % 5
    boundary = boundary.plusMinutes(add.toLong())
    var scanAt = boundary.minusSeconds(10)
    if (scanAt.isBefore(z) && ChronoUnit.MILLIS.between(scanAt, z) >= 1000L) {
        scanAt = boundary.plusMinutes(5).minusSeconds(10)
    }
    return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())
}

@Composable
private fun Top1Card(top: ScanCandidate?, coverageCount: Int) {
    Card(
        Modifier.fillMaxWidth().padding(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5EA)),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column {
            Row(Modifier.fillMaxWidth().background(WineDark).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (coverageCount in 1..5) "♛  TOP1（部分 ${coverageCount}/6）" else "♛  TOP1 結果",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            if (top == null) {
                Text("まだスキャン結果がありません", Modifier.padding(18.dp), color = Ink)
            } else {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(top.instrument, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("第${top.rank}位  RANK ${top.grade}", color = Gold, fontWeight = FontWeight.Bold)
                        top.probability?.let { Text("RULE ${(it * 100).toInt()}%", fontSize = 11.sp, color = Color.Gray) }
                        Text(
                            "${top.regime} ${(top.regimeConfidence * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    DirectionBox(top.direction)
                    Spacer(Modifier.width(10.dp))
                    Text(top.decision, color = if (top.decision == "ENTRY") Wine else Color.Gray, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        Modifier.fillMaxWidth().background(Wood).padding(horizontal = 14.dp, vertical = 9.dp),
        color = Color.White,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun ResultRow(c: ScanCandidate, rate: RateRow?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp)
            .border(0.5.dp, Color(0xFFD4C1AF))
            .background(if (c.rank == 1) Color(0xFFFFE4E3) else Paper2)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${c.rank}", Modifier.width(25.dp), fontWeight = FontWeight.Bold, color = Gold)
        Column(Modifier.weight(1f)) {
            Text(c.instrument, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            Text(rate?.price?.let(::formatPrice) ?: "—", fontSize = 11.sp, color = Color.Gray)
            Text("${c.regime} ${(c.regimeConfidence * 100).toInt()}%", fontSize = 10.sp, color = Color.Gray)
        }
        DirectionBox(c.direction)
        Spacer(Modifier.width(10.dp))
        Text(c.grade, Modifier.width(30.dp), fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
        Text(
            c.decision,
            Modifier.width(54.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (c.decision == "ENTRY") Wine else Color.Gray,
            textAlign = TextAlign.End
        )
    }
}

@Composable
private fun RateOnlyRow(r: RateRow) {
    val status = when {
        r.price == null -> "UNAVAILABLE"
        r.freshnessStatus == "LIVE" -> "LIVE"
        r.freshnessStatus == "LAST" -> "LAST"
        else -> r.freshnessStatus
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp)
            .border(0.5.dp, Color(0xFFD4C1AF)).background(Paper2).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(r.instrument, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Ink)
        Column(horizontalAlignment = Alignment.End) {
            Text(r.price?.let(::formatPrice) ?: "—", fontWeight = FontWeight.Bold, color = Ink)
            val ageLabel = r.ageSeconds?.let { " ${it.toInt()}s" } ?: ""
            Text(
                "$status$ageLabel ${r.source}",
                fontSize = 10.sp,
                color = when (status) {
                    "LIVE" -> Color(0xFF416C3C)
                    "LAST" -> Gold
                    else -> WineDark
                }
            )
        }
    }
}

@Composable
private fun DirectionBox(direction: String) {
    val normalized = direction.uppercase()
    val (label, color) = when (normalized) {
        "HIGH" -> "▲ HIGH" to High
        "LOW" -> "▼ LOW" to Low
        else -> "—" to Color.Gray
    }
    Surface(color = color, shape = RoundedCornerShape(6.dp)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun formatPrice(x: Double): String = if (x >= 100000) "%,.0f".format(x) else if (x >= 100) "%.3f".format(x) else "%.5f".format(x)

@Composable
private fun RecentHistoryPreview(rows: List<HistoryRow>) {
    if (rows.isEmpty()) return
    Spacer(Modifier.height(12.dp))
    SectionTitle("最近のスキャン履歴")
    rows.take(5).forEach { h ->
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp)
                .border(0.5.dp, Color(0xFFD4C1AF)).background(Paper2).padding(9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(h.source, Modifier.width(58.dp), fontSize = 10.sp, color = Color.Gray)
            Text(h.instrument, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Ink)
            Text(h.direction, color = if (h.direction == "HIGH") High else Low, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(Modifier.width(10.dp))
            Text(h.grade, fontWeight = FontWeight.Bold, color = Gold)
        }
    }
}

@Composable
private fun HistoryScreen(rows: List<HistoryRow>) {
    Column(Modifier.fillMaxSize().background(Paper)) {
        PageHeader("スキャン履歴")
        if (rows.isEmpty()) {
            Text("履歴はこの端末に保存されます。", Modifier.padding(16.dp), color = Color.Gray)
        } else {
            LazyColumn {
                items(rows) { h ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp)
                            .border(0.5.dp, Color(0xFFD4C1AF)).background(Paper2).padding(12.dp)
                    ) {
                        Column(Modifier.width(90.dp)) {
                            Text(h.source, fontSize = 11.sp)
                            Text(h.atJst.takeLast(14), fontSize = 9.sp, color = Color.Gray)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(h.instrument, fontWeight = FontWeight.Bold)
                            Text("${h.regime} / #${h.candidateRank}", fontSize = 9.sp, color = Color.Gray)
                        }
                        Text(h.direction, color = if (h.direction == "HIGH") High else Low, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text(h.grade, fontWeight = FontWeight.Bold)
                            Text(h.decision, fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: GmkUiState, save: (String, String, String, Boolean) -> Unit, exportDiagnostic: () -> Unit) {
    var token by remember(state.oandaToken) { mutableStateOf(state.oandaToken) }
    var account by remember(state.oandaAccountId) { mutableStateOf(state.oandaAccountId) }
    var env by remember(state.oandaEnvironment) { mutableStateOf(state.oandaEnvironment) }
    var fallback by remember(state.yahooFallback) { mutableStateOf(state.yahooFallback) }

    LazyColumn(Modifier.fillMaxSize().background(Paper).padding(14.dp)) {
        item {
            PageHeader("設定")
            Text("レート取得", fontWeight = FontWeight.Bold, color = Ink)
            Text("スマホから直接取得します。バックエンドURLやPCは使いません。", fontSize = 12.sp, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text("OANDA Personal Access Token", fontWeight = FontWeight.Bold, color = Ink)
            OutlinedTextField(
                token, { token = it }, Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                placeholder = { Text("未設定でもYahoo fallbackは利用可") }
            )
            Spacer(Modifier.height(10.dp))
            Text("OANDA Account ID", fontWeight = FontWeight.Bold, color = Ink)
            OutlinedTextField(account, { account = it }, Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            Text("OANDA環境", fontWeight = FontWeight.Bold, color = Ink)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = env == "practice", onClick = { env = "practice" }, label = { Text("practice") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = env == "live", onClick = { env = "live" }, label = { Text("live") })
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Yahoo FX fallback", fontWeight = FontWeight.Bold, color = Ink)
                    Text("OANDA未設定・障害時の補完。古い値はLAST表示し、判定には使いません。", fontSize = 11.sp, color = Color.Gray)
                }
                Switch(checked = fallback, onCheckedChange = { fallback = it })
            }
            Spacer(Modifier.height(16.dp))
            Button(
                { save(token, account, env, fallback) },
                Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Wine)
            ) { Text("保存") }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = exportDiagnostic,
                modifier = Modifier.fillMaxWidth()
            ) { Text("詳細診断ログを保存") }
            Spacer(Modifier.height(20.dp))
            Text("AUTO SCANはアプリ稼働中のみ、5分境界10秒前（:50）に1回実行。通信・計算が間に合わない結果は対象枠へ出しません。", color = Ink, fontSize = 12.sp)
            Text("AI / OCR / 通知 / Railway / PC連携はこの版には含めません。", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PageHeader(text: String) {
    Text(text, Modifier.fillMaxWidth().padding(vertical = 16.dp), fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun BottomBar(tab: Tab, select: (Tab) -> Unit) {
    Row(Modifier.fillMaxWidth().height(72.dp).background(Wood)) {
        BottomItem("⌕", "スキャン", tab == Tab.Scan) { select(Tab.Scan) }
        BottomItem("▤", "履歴", tab == Tab.History) { select(Tab.History) }
        BottomItem("⚙", "設定", tab == Tab.Settings) { select(Tab.Settings) }
    }
}

@Composable
private fun RowScope.BottomItem(icon: String, text: String, active: Boolean, click: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable(onClick = click)
            .background(if (active) WineDark else Color.Transparent),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = Color.White, fontSize = 22.sp)
        Text(text, color = Color.White, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
    }
}

package jp.gmk.mobile.domain

data class RateRow(
    val instrument: String,
    val price: Double?,
    val bid: Double?,
    val ask: Double?,
    val source: String,
    val ageSeconds: Double?,
    val freshnessStatus: String = "UNKNOWN"
)

data class Candle(
    val timeEpochMs: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0
)

data class CandleBatch(
    val candles: Map<String, List<Candle>>,
    val errors: Map<String, String> = emptyMap()
)

data class ScanCandidate(
    val rank: Int,
    val instrument: String,
    val display: String,
    val direction: String,
    val grade: String,
    val probability: Double?,
    val decision: String,
    val score: Double = 0.0,
    val regime: String = "UNKNOWN",
    val regimeConfidence: Double = 0.0,
    val reasons: List<String> = emptyList()
)

data class ScanResult(
    val scanId: String = "",
    val atJst: String = "",
    val entryTimeJst: String = "",
    val judgeTimeJst: String = "",
    val candidates: List<ScanCandidate> = emptyList(),
    val warnings: List<String> = emptyList(),
    val source: String = "MANUAL"
) {
    val top1: ScanCandidate? get() = candidates.minByOrNull { it.rank.takeIf { n -> n > 0 } ?: 999 }
}

data class HistoryRow(
    val id: Long,
    val source: String,
    val atJst: String,
    val instrument: String,
    val direction: String,
    val grade: String,
    val decision: String,
    val candidateRank: Int = 1,
    val regime: String = "UNKNOWN",
    val judgeTimeJst: String = ""
)

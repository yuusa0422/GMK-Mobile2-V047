"""Out-of-time check of 'any minute' on 2023-24: models trained on the current year only, cuts per hour set on the other two
past-year periods (Y1/Y2/Y3 rotation). Fixed trades = the time-of-day rules (all 8, or the 3 that held) judged at 3 minutes; no B here."""
import json
exec(open('v0758_lib.py').read())
def prep(D, years):
    D = D[D.weekday & D.move3.notna()].reset_index(drop=True)
    D['idio5'] = D.r5 - D.yen5; D['idio15'] = D.r15 - D.yen15; D['idiof1'] = D.f1 - D.yenf1
    D['grade_n'] = D.app_grade.map(GR).astype(float); D['wkend'] = 0.0
    ds = D.date.astype(str)
    D['period'] = (np.where(ds < '2023-06-01', 'Y1', np.where(ds < '2023-11-01', 'Y2', 'Y3')) if years else
                   np.where(ds < '2026-02-01', 'P1', np.where(ds < '2026-06-01', 'P2', 'P3')))
    D['slot'] = D.b - D.b % 300; D['k'] = (D.b % 300) // 60; D['isk0'] = (D.k == 0).astype(float); return D
PM = prep(pd.concat([pd.read_pickle('../work/minute/policy_1.pkl'), pd.read_pickle('../work/minute/policy_2.pkl')], ignore_index=True), False)
PY = prep(pd.concat([pd.read_pickle('../work/minute/ypolicy_1.pkl'), pd.read_pickle('../work/minute/ypolicy_2.pkl')], ignore_index=True), True)
print('current minute rows', len(PM), 'past minute rows', len(PY), 'past slots', PY.slot.nunique(), flush=True)
EX = [('isk0', False)]
ms_all = fit(PM, True, extra=EX); ms_k0 = fit(P, True)
pu, pdn = pred(ms_all, PY, True, extra=EX); A = PY[['b', 'slot', 'k', 'inst', 'hour', 'period', 'move5']].assign(pu=pu, pd=pdn)
B0 = PY[PY.k == 0]; pu0, pd0 = pred(ms_k0, B0, True); K = B0[['b', 'slot', 'k', 'inst', 'hour', 'period', 'move5']].assign(pu=pu0, pd=pd0)
for X in (A, K):
    X['p'] = np.maximum(X.pu, X.pd); X['dir'] = np.where(X.pu >= X.pd, 1, -1); X['w'] = (X.move5 == X.dir).astype(float)
RT = pd.read_pickle('../work/years/rule_trades_years.pkl')
slots = PY[PY.k == 0][['slot', 'hour', 'period']].drop_duplicates('slot')
def run(Mbest, keep):
    R = RT if keep is None else RT[RT.rule.isin(keep)]; fx = dict(zip(R.b, R.win3))
    X = Mbest[~Mbest.slot.isin(set(fx)) & Mbest.slot.isin(set(slots.slot))]
    sel = []
    for te in ('Y1', 'Y2', 'Y3'):
        for h in range(9, 23):
            g = slots[(slots.period != te) & (slots.hour == h)]; need = 0.6 * len(g) - g.slot.isin(set(fx)).sum()
            tr = X[(X.period != te) & (X.hour == h)]
            if len(tr) == 0: continue
            T = float(np.quantile(tr.p, 1 - min(need / len(tr), 1)))
            sel.append(X[(X.period == te) & (X.hour == h) & (X.p >= T)])
    E = pd.concat(sel); fw = np.array([fx[s] for s in slots.slot if s in fx], float)
    tot = (E.w.sum() + fw.sum()) / (len(E) + len(fw))
    return dict(entries_per_slot=round((len(E) + len(fw)) / len(slots) * 100, 1), win=round(tot * 100, 2), model_part=round(E.w.mean() * 100, 2),
                rules=(len(fw), round(fw.mean() * 100, 2) if len(fw) else None), **{p: round(E[E.period == p].w.mean() * 100, 2) for p in ('Y1', 'Y2', 'Y3')})
out = {}
Mall = A.sort_values('p', ascending=False).groupby('b').head(1)
Mk0 = K.sort_values('p', ascending=False).groupby('b').head(1)
for nm, keep in (('all8', None), ('keep3', ['FIX955_POS', 'FIX955_BBZ', 'US0830_F1']), ('none', [])):
    out[f'boundary_{nm}'] = run(Mk0, keep); out[f'anymin_{nm}'] = run(Mall, keep)
    out[f'anymin_boundary_rows_{nm}'] = run(Mall[Mall.k == 0], keep)
    print(nm, '\n  boundary (v0.7.57 model)', out[f'boundary_{nm}'], '\n  any minute (all-minute model)', out[f'anymin_{nm}'],
          '\n  all-minute model, boundary only', out[f'anymin_boundary_rows_{nm}'], flush=True)
json.dump(out, open('../work/v0758_minute_years.json', 'w'), indent=1, default=float)

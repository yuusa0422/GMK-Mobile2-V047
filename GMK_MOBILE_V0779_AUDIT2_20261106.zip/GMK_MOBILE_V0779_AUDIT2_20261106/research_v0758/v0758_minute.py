"""Entry minute inside the 5-minute slot: the app scans every minute and enters at the first minute whose best FX trade reaches the
hour's 'early' cut; at the slot's last minute it enters if the best trade reaches the 'last' cut (cuts set on the training periods so that
S/A/B + C = 60% in every hour). Same 5-minute model (trained on the 5-minute boundary rows of the other two periods)."""
import json, sys
exec(open('v0758_lib.py').read())
TRAIN_ALL = len(sys.argv) > 1 and sys.argv[1] == 'all'
PM = pd.concat([pd.read_pickle('../work/minute/policy_1.pkl'), pd.read_pickle('../work/minute/policy_2.pkl')], ignore_index=True)
PM = PM[PM.weekday & PM.move3.notna()].reset_index(drop=True)
PM['idio5'] = PM.r5 - PM.yen5; PM['idio15'] = PM.r15 - PM.yen15; PM['idiof1'] = PM.f1 - PM.yenf1
PM['grade_n'] = PM.app_grade.map(GR).astype(float); PM['wkend'] = 0.0
PM['period'] = np.where(PM.date.astype(str) < '2026-02-01', 'P1', np.where(PM.date.astype(str) < '2026-06-01', 'P2', 'P3'))
PM['slot'] = PM.b - PM.b % 300; PM['k'] = (PM.b % 300) // 60
PM['isk0'] = (PM.k == 0).astype(float)
print('minute rows', len(PM), 'slots', PM.slot.nunique(), PM.k.value_counts().sort_index().to_dict(), flush=True)
# sanity: k=0 rows equal the research rows
chk = PM[PM.k == 0].merge(P[P.inst != 'BTCJPY'], on=['b', 'inst'], suffixes=('', '_o'))
print('k=0 rows matched', len(chk), 'max |f1 diff|', float((chk.f1 - chk.f1_o).abs().max()), 'max |app_prob diff|', float((chk.app_prob - chk.app_prob_o).abs().max()), flush=True)
key = 'minute_all' if TRAIN_ALL else 'minute'
path = f'../work/v0758_val_{key}_fresh.pkl'
if os.path.exists(path): S = pd.read_pickle(path)
else:
    parts = []
    for te in ('P1', 'P2', 'P3'):
        t0 = time.time()
        tr = PM[PM.period != te] if TRAIN_ALL else P[P.period != te]
        EX = [('isk0', False)] if TRAIN_ALL else None
        ms = fit(tr, True, extra=EX); B = PM[PM.period == te]; pu, pdn = pred(ms, B, True, extra=EX)
        t = B[['b', 'slot', 'k', 'inst', 'hour', 'period', 'move5']].copy(); t['pu'] = pu; t['pd'] = pdn; parts.append(t)
        print('  scored', te, round(time.time() - t0), 's', flush=True)
    S = pd.concat(parts); S.to_pickle(path)
S['p'] = np.maximum(S.pu, S.pd); S['dir'] = np.where(S.pu >= S.pd, 1, -1); S['w'] = (S.move5 == S.dir).astype(float)
M = S.sort_values('p', ascending=False).groupby('b').head(1)                      # best FX trade of each minute
G = M.pivot_table(index='slot', columns='k', values=['p', 'w'], aggfunc='first')
G.columns = [f'{a}{b}' for a, b in G.columns]; G = G.reset_index().rename(columns={'slot': 'b'})
G = G.merge(Wd[['b', 'fix', 'win', 'win5']], on='b', how='inner')
G['hour'] = pd.to_datetime(G.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.hour
G['period'] = np.where(pd.to_datetime(G.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date.astype(str) < '2026-02-01', 'P1',
                       np.where(pd.to_datetime(G.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date.astype(str) < '2026-06-01', 'P2', 'P3'))
G = G[G.p0.notna()].reset_index(drop=True)
print('slots', len(G), 'with all 5 minutes', int(G[[f'p{k}' for k in range(5)]].notna().all(1).sum()), flush=True)
fixw = np.where(G.fix.isin(['S', 'A']), G.win, np.where(G.fix == 'B', G.win5, np.nan))
def choose(D, Ts):
    """first minute k whose best p reaches Ts[k]. Returns chosen k (-1 = skip)."""
    ch = np.full(len(D), -1)
    for k in range(5):
        pk = D[f'p{k}'].values; hit = (ch < 0) & (pk >= Ts[k])
        ch[hit] = k
    return ch
def winof(D, ch):
    w = np.full(len(D), np.nan)
    for k in range(5): w[ch == k] = D[f'w{k}'].values[ch == k]
    return w
res = {}
def run(policy):
    """policy(train_rows_of_hour, share) -> 5 cuts; applied per (test period, hour)."""
    ent = np.zeros(len(G), bool); win = np.full(len(G), np.nan); kk = np.full(len(G), -1)
    for te in ('P1', 'P2', 'P3'):
        for h in range(9, 23):
            tr = G[(G.period != te) & (G.hour == h)]; ts_ = (G.period == te) & (G.hour == h)
            share = (0.6 - (tr.fix != '').mean()) / (1 - (tr.fix != '').mean())
            Ts = policy(tr[tr.fix == ''], share)
            D = G[ts_ & (G.fix == '')]; ch = choose(D, Ts); idx = D.index.values
            ent[idx] = ch >= 0; win[idx] = winof(D, ch); kk[idx] = ch
    fixed = G.fix != ''
    e = ent | fixed; wv = np.where(fixed, fixw, win)
    cov_h = pd.Series(e).groupby([G.period, G.hour]).mean()
    return dict(cover=round(e.mean() * 100, 1), min_hour=round(cov_h.min() * 100, 1), win=round(np.nanmean(wv[e]) * 100, 2),
                **{p: round(np.nanmean(wv[e & (G.period == p).values]) * 100, 2) for p in ('P1', 'P2', 'P3')},
                C=round(np.nanmean(win[ent]) * 100, 2), C_n=int(ent.sum()), minutes=pd.Series(kk[ent]).value_counts().sort_index().to_dict())
def solve_T4(tr, T, share):
    """lowest last-minute cut that keeps coverage at the share on the training rows"""
    early = np.zeros(len(tr), bool)
    for k in range(4): early |= (tr[f'p{k}'].values >= T)
    need = share - early.mean()
    if need <= 0: return np.inf
    rest = tr.p4.values[~early]; rest = rest[np.isfinite(rest)]
    if len(rest) == 0: return -np.inf
    q = 1 - need / (len(rest) / len(tr)); return float(np.quantile(rest, min(max(q, 0), 1)))
# baseline: minute 0 only
def k0only(tr, sh):
    return [float(np.quantile(tr.p0.dropna(), 1 - sh))] + [np.inf] * 4
res['k0_only'] = run(k0only)
print('k0 only', res['k0_only'], flush=True)
# last minute only (k=4) for reference
def k4only(tr, sh):
    return [np.inf] * 4 + [float(np.quantile(tr.p4.dropna(), 1 - sh))]
res['k4_only'] = run(k4only); print('k4 only', res['k4_only'], flush=True)
for k in range(5):
    def kk_only(tr, sh, k=k):
        Ts = [np.inf] * 5; Ts[k] = float(np.quantile(tr[f'p{k}'].dropna(), 1 - sh)); return Ts
    r = run(kk_only); res[f'k{k}_only'] = r; print('minute', k, 'only', r['win'], 'C', r['C'], {p: r[p] for p in ('P1', 'P2', 'P3')}, flush=True)
print('all-minute base rate (best pair, every minute):', {k: round(G[f'w{k}'].mean() * 100, 2) for k in range(5)}, flush=True)
# early cut at the q-quantile of the minute-0 best p, last cut solved for the share; q chosen on the training rows by mean p
for q in ():
    def pol(tr, sh, q=q):
        T = float(np.quantile(tr.p0.dropna(), q)); return [T] * 4 + [solve_T4(tr, T, sh)]
    res[f'early_q{q}'] = run(pol); print('early q', q, res[f'early_q{q}'], flush=True)
# q chosen on the training periods (by the training win rate) -> honest
def pol_auto(tr, sh):
    best = None
    for q in (0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.95):
        T = float(np.quantile(tr.p0.dropna(), q)); Ts = [T] * 4 + [solve_T4(tr, T, sh)]; ch = choose(tr, Ts); w = np.nanmean(winof(tr, ch)[ch >= 0])
        if best is None or w > best[0]: best = (w, Ts)
    return best[1]
res['early_auto'] = run(pol_auto); print('early auto', res['early_auto'], flush=True)
# oracle (not possible live): the best of the five minutes by p (no outcome used) at the same share
def oracle():
    P5 = G[[f'p{k}' for k in range(5)]].values; W5 = G[[f'w{k}' for k in range(5)]].values
    j = np.nanargmax(np.where(np.isfinite(P5), P5, -1), 1); pm = P5[np.arange(len(G)), j]; wm = W5[np.arange(len(G)), j]
    X = G.assign(pm=pm, wm=wm); X['isfix'] = X.fix != ''
    X['rk'] = X[~X.isfix].groupby(['period', 'hour']).pm.rank(ascending=False, method='first')
    n = X.groupby(['period', 'hour']).b.transform('size'); nf = X.groupby(['period', 'hour']).isfix.transform('sum')
    c = (~X.isfix) & (X.rk <= np.ceil(0.6 * n) - nf); e = c | X.isfix; wv = np.where(X.isfix, fixw, X.wm)
    return dict(win=round(np.nanmean(wv[e]) * 100, 2), C=round(X.wm[c].mean() * 100, 2))
res['oracle_best_minute'] = oracle(); print('oracle', res['oracle_best_minute'], flush=True)
json.dump(res, open(f'../work/v0758_{key}.json', 'w'), indent=1, default=str)
# ---- smoothing at the 5-minute boundary: average the model over the last 2/3/5 minutes (same pair, same direction), enter at minute 0 only
S = S.sort_values(['inst', 'b']).reset_index(drop=True)
for n in (2, 3, 5):
    su = S.pu.copy(); sd = S.pd.copy(); cnt = pd.Series(1.0, index=S.index)
    for j in range(1, n):
        ok = (S.inst.shift(j) == S.inst) & (S.b - S.b.shift(j) == 60 * j)
        su = su + np.where(ok, S.pu.shift(j), 0); sd = sd + np.where(ok, S.pd.shift(j), 0); cnt = cnt + ok.astype(float)
    S[f'su{n}'] = su / cnt; S[f'sd{n}'] = sd / cnt
B0 = S[S.k == 0]
for n in (2, 3, 5):
    C = B0[['b', 'inst', 'hour', 'period', 'move5']].assign(pu=B0[f'su{n}'].values, pd=B0[f'sd{n}'].values)
    r, _ = evaluate(C, f'smoothed over {n} minutes (minute 0 entry)'); res[f'smooth{n}'] = r; print(json.dumps(r), flush=True)
C = B0[['b', 'inst', 'hour', 'period', 'move5', 'pu', 'pd']]; r, _ = evaluate(C, 'minute 0, not smoothed'); res['k0_eval'] = r; print(json.dumps(r), flush=True)
json.dump(res, open(f'../work/v0758_{key}.json', 'w'), indent=1, default=str)
# ---- any minute of the hour (not tied to the 5-minute slot), the same number of entries per hour as 60% of the slots
Mx = M[['b', 'hour', 'period', 'p', 'w']].copy(); Mx['slot'] = Mx.b - Mx.b % 300
fixslots = set(G.b[G.fix != '']); Mx = Mx[~Mx.slot.isin(fixslots) & Mx.slot.isin(set(G.b))]
sel = []; 
for te in ('P1', 'P2', 'P3'):
    for h in range(9, 23):
        g = G[(G.period != te) & (G.hour == h)]; need = 0.6 * len(g) - (g.fix != '').sum()
        tr = Mx[(Mx.period != te) & (Mx.hour == h)]; frac = need / len(tr); T = float(np.quantile(tr.p, 1 - frac))
        sel.append(Mx[(Mx.period == te) & (Mx.hour == h) & (Mx.p >= T)])
Sel = pd.concat(sel); fx = G[G.fix != '']
ent_n = len(Sel) + len(fx); w_all = (Sel.w.sum() + np.nansum(fixw[(G.fix != '').values])) / ent_n
res['any_minute'] = dict(entries_per_slot=round(ent_n / len(G) * 100, 1), win=round(w_all * 100, 2), C=round(Sel.w.mean() * 100, 2), C_n=len(Sel),
                         per_period={p: round(Sel[Sel.period == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')})
print('any minute', res['any_minute'], flush=True)
json.dump(res, open(f'../work/v0758_{key}.json', 'w'), indent=1, default=str)

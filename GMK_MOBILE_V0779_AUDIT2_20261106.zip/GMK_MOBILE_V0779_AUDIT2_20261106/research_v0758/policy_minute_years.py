"""One row per (slot, instrument) with features the app can compute at B-10s.
Features are defined so that the Kotlin port (EvidenceModel) reproduces them exactly:
61 contiguous M1 bars ending at OPEN(B-120) + optional live price (backtest proxy: close of the bar opening at B-60)."""
import sys, csv, pickle, bisect, math, gzip, datetime as dt, numpy as np, pandas as pd
JST = dt.timezone(dt.timedelta(hours=9))
FX4 = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY']
SRC = {s: f'/tmp/gmkdata/years/{s}_1m.csv.gz' for s in ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']}
bars = {}
for s, p in SRC.items():
    with gzip.open(p, 'rt') as f:
        rows = [(int(r['epoch_ms']), float(r['open']), float(r['high']), float(r['low']), float(r['close']), float(r.get('volume') or 0)) for r in csv.DictReader(f)]
    rows.sort(); bars[s] = rows
times = {s: [r[0] for r in rows] for s, rows in bars.items()}
index = {s: {r[0]: r for r in rows} for s, rows in bars.items()}

def window(s, B):
    i = bisect.bisect_right(times[s], (B - 120) * 1000)
    w = bars[s][max(0, i - 61):i]
    if len(w) != 61 or w[-1][0] != (B - 120) * 1000 or w[0][0] != (B - 3720) * 1000: return None
    return w

def feats(w, live, btc):
    o = [r[1] for r in w]; h = [r[2] for r in w]; l = [r[3] for r in w]; c = [r[4] for r in w]; v = [r[5] for r in w]
    lg = [math.log(x) for x in c]
    ret = [lg[i] - lg[i - 1] for i in range(1, 61)]
    norm = max(math.sqrt(sum(x * x for x in ret) / 60.0), 1e-8)
    rv30 = math.sqrt(sum(x * x for x in ret[30:]) / 30.0)
    f = {}
    for k in (1, 3, 5, 10, 15, 30, 60): f[f'r{k}'] = (lg[60] - lg[60 - k]) / (norm * math.sqrt(k))
    f['rv60'] = norm * 1e4; f['rv30_60'] = rv30 / norm
    hi15 = max(h[46:61]); lo15 = min(l[46:61]); rg = max(hi15 - lo15, 1e-12)
    f['pos15'] = (c[60] - lo15) / rg * 2 - 1
    hi60 = max(h); lo60 = min(l); f['pos60'] = (c[60] - lo60) / max(hi60 - lo60, 1e-12) * 2 - 1
    s20 = c[41:61]; m20 = sum(s20) / 20.0; sd20 = math.sqrt(max(sum((x - m20) ** 2 for x in s20) / 20.0, 1e-16))
    f['bbz'] = (c[60] - m20) / sd20
    if live is not None and live > 0:
        ll = math.log(live)
        f['f1'] = (ll - lg[60]) / norm; f['f2'] = (ll - lg[59]) / (norm * math.sqrt(2)); f['f5'] = (ll - lg[56]) / (norm * math.sqrt(5))
        f['f15'] = (ll - lg[46]) / (norm * math.sqrt(15))
        hiL = max(hi15, live); loL = min(lo15, live); f['pos15L'] = (live - loL) / max(hiL - loL, 1e-12) * 2 - 1
        f['bbzL'] = (live - m20) / sd20
        f['live_ok'] = 1.0
    else:
        for k in ('f1', 'f2', 'f5', 'f15', 'pos15L', 'bbzL'): f[k] = 0.0
        f['live_ok'] = 0.0
    if btc:
        f['tie58'] = sum(1 for i in range(3, 61) if o[i] == o[i - 3]) / 58.0
        f['zero30'] = sum(1 for i in range(31, 61) if c[i] == c[i - 1]) / 30.0
        f['vol10'] = math.log1p(sum(v[51:61]) / 10.0)
        f['rvjpy'] = norm * c[60]
    else:
        f['tie58'] = f['zero30'] = f['vol10'] = f['rvjpy'] = 0.0
    return f

d = pd.DataFrame(pickle.load(open(sys.argv[1], 'rb')))
d = d[d.move3.notna()]
out = []
for B, g in d.groupby('b', sort=True):
    rows = []
    for r in g.itertuples(index=False):
        w = window(r.inst, B)
        if w is None: continue
        lb = index[r.inst].get((B - 60) * 1000)
        live = lb[4] if lb is not None else None
        f = feats(w, live, r.inst == 'BTCJPY')
        if r.order == 1:
            gate_ok = (r.gate is not None) and not (isinstance(r.gate, float) and math.isnan(r.gate)) and r.gate >= 0.53
            grade = r.fin_rank if (r.fin_rank != 'E' and gate_ok) else 'E'
            adir = 1 if r.fin_dir == 'HIGH' else -1; score = -r.score if r.fin_rev else r.score; prob = r.fin_exp
        else:
            grade = r.base_rank; score = -r.score if r.base_rev else r.score; adir = 1 if score >= 0 else -1; prob = r.base_exp
        f.update(b=B, inst=r.inst, hour=r.hour, wd=r.wd, weekday=r.weekday, order=r.order, app_dir=adir, app_grade=grade,
                 app_score=score, app_prob=prob, regime=r.regime, regconf=r.regimeConfidence, move3=r.move3, move5=r.move5)
        rows.append(f)
    fx = [x for x in rows if x['inst'] in FX4]
    if len(fx) == 4:
        for k, nm in (('r5', 'yen5'), ('r15', 'yen15'), ('f1', 'yenf1')):
            m = sum(x[k] for x in fx) / 4.0
            for x in rows: x[nm] = m if x['inst'] != 'BTCJPY' else 0.0
    else:
        for x in rows: x['yen5'] = x['yen15'] = x['yenf1'] = 0.0
    out += rows
P = pd.DataFrame(out)
P['ts'] = pd.to_datetime(P.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
P['half'] = np.where(P.ts < pd.Timestamp('2026-04-01', tz='Asia/Tokyo'), 'H1', 'H2')
P['date'] = P.ts.dt.date
P = P[P.inst != 'BTCJPY'].reset_index(drop=True); P.to_pickle(sys.argv[2])
print(P.shape, P.inst.value_counts().to_dict(), 'live_ok', P.live_ok.mean())
print(P.app_grade.value_counts().to_dict(), P.regime.value_counts().to_dict())

"""v0.7.58 'every minute, every hour >= 70%': exact app semantics, validated by period rotation and on 2023-24, then production models.
App rule per weekday minute: boundary minute -> time-of-day rule (3 kept) S/A, else B (3-minute model strong + confirmed), else C logic;
other minutes -> C logic. C logic: need = N - entries so far this clock hour (N = ceil(0.7 * slots)), left = 60 - minute;
need >= left -> enter (catch-up); need > 0 -> enter if p >= Q_h(max(need / left, BASE_h / 2)); need <= 0 -> no more C this hour."""
import json, sys, math
exec(open('v0758_lib.py').read()); exec(open('model_export_lib.py').read()); NFEAT = 47
SHARE = 0.7; KEEP = ['FIX955_POS', 'FIX955_BBZ', 'US0830_F1']; QN = 200
def prep(D, years):
    D = D[D.weekday & D.move3.notna()].reset_index(drop=True)
    D['idio5'] = D.r5 - D.yen5; D['idio15'] = D.r15 - D.yen15; D['idiof1'] = D.f1 - D.yenf1
    D['grade_n'] = D.app_grade.map(GR).astype(float); D['wkend'] = 0.0; ds = D.date.astype(str)
    D['period'] = (np.where(ds < '2023-06-01', 'Y1', np.where(ds < '2023-11-01', 'Y2', 'Y3')) if years else
                   np.where(ds < '2026-02-01', 'P1', np.where(ds < '2026-06-01', 'P2', 'P3')))
    D['slot'] = D.b - D.b % 300; D['k'] = (D.b % 300) // 60; D['isk0'] = (D.k == 0).astype(float); return D
PM = prep(pd.concat([pd.read_pickle(f'../work/minute/policy_{i}.pkl') for i in (1, 2)], ignore_index=True), False)
PY = prep(pd.concat([pd.read_pickle(f'../work/minute/ypolicy_{i}.pkl') for i in (1, 2)], ignore_index=True), True)
EX = [('isk0', False)]
RTc = pd.read_pickle('../work/rule_trades_current.pkl'); RTp = pd.read_pickle('../work/years/rule_trades_years.pkl')
def best_minutes(df, pu, pdn):
    X = df[['b', 'slot', 'k', 'inst', 'hour', 'period', 'date', 'move5']].assign(pu=pu, pd=pdn)
    X['p'] = np.maximum(X.pu, X.pd); X['dir'] = np.where(X.pu >= X.pd, 1, -1); X['w'] = (X.move5 == X.dir).astype(float)
    return X.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b').reset_index(drop=True)
def fixed_map(RT, Bfix):
    f = {b: ('SA', w) for b, w in zip(RT[RT.rule.isin(KEEP)].b, RT[RT.rule.isin(KEEP)].win3)}
    if Bfix is not None:
        for b, w in zip(Bfix.b, Bfix.win5):
            if b not in f: f[b] = ('B', w)
    return f
def tables(M, fx, slots_by_hour):
    """per hour: quantile points of the best-trade p over the minutes without a fixed trade, and BASE = C share of those minutes"""
    Q = {}; base = {}
    for h in range(9, 23):
        x = M[(M.hour == h) & ~M.b.isin(fx)].p.values
        Q[h] = np.quantile(x, np.linspace(0, 1, QN + 1)); nfix = sum(1 for b in fx if b in slots_by_hour.get(h, set()))
        base[h] = max(SHARE * len(slots_by_hour.get(h, ())) - nfix, 0) / len(x)
    return Q, base
def qcut(Q, frac):
    """p value with `frac` of the training minutes at or above it (linear in the quantile grid)"""
    frac = min(max(frac, 0.0), 1.0); return float(np.interp(1 - frac, np.linspace(0, 1, QN + 1), Q))
def simulate(M, fx, slots, Q, base):
    """M: best trade per minute (test rows); slots: set of 5-minute boundaries of the test days (the denominator)."""
    out = []; hours = []
    Mi = M.set_index('b'); mins = M.groupby(['date', 'hour'])
    S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
    S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0
        sb = set(g.b); allm = sorted(set(mins.get_group((d, h)).b) if (d, h) in mins.groups else set())
        seq = sorted(set(allm) | (sb & set(fx)))
        for b in seq:
            minute = (b // 60) % 60
            if b in fx and b in sb:
                gr, w = fx[b]; out.append((b, gr, w, 0)); cnt += 1; continue
            if b not in Mi.index: continue
            r = Mi.loc[b]; left = 60 - minute; need = N - cnt
            if need >= left: out.append((b, 'C', r.w, 1)); cnt += 1
            elif need > 0 and r.p >= qcut(Q[h], max(need / left, base[h] / 2)): out.append((b, 'C', r.w, 0)); cnt += 1
        hours.append((d, h, cnt / n))
    E = pd.DataFrame(out, columns=['b', 'g', 'w', 'forced']); H = pd.DataFrame(hours, columns=['date', 'hour', 'rate'])
    return E, H
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
def summary(E, H, nslots, ndays, periods=None):
    r = dict(entries_per_slot=round(len(E) / nslots * 100, 1), per_day=round(len(E) / ndays, 1), win=round(E.w.mean() * 100, 2),
             hours_below=round((H.rate < SHARE - 1e-9).mean() * 100, 2), min_hour_rate=round(H.rate.min() * 100, 1), maxrun=maxrun(E.sort_values('b').w.values),
             forced=round(E.forced.mean() * 100, 1), forced_win=round(E[E.forced == 1].w.mean() * 100, 2) if E.forced.any() else None,
             grades={g: (int(len(x)), round(x.w.mean() * 100, 2)) for g, x in E.groupby('g')})
    if periods is not None:
        pr = E.b.map(periods); r['periods'] = {p: round(E[pr == p].w.mean() * 100, 2) for p in sorted(pr.dropna().unique())}
    return r
slots_cur = set(Wd.b); Bfix = Wd[Wd.fix == 'B'][['b', 'win5']]
per_cur = dict(zip(PM.slot, PM.period)); per_cur.update(dict(zip(PM.b, PM.period)))
def hour_of(bs):
    bs = np.array(sorted(bs)); hh = ((bs + 9 * 3600) // 3600) % 24
    return {h: set(bs[hh == h].tolist()) for h in range(9, 23)}
out = {}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'
    path = f'../work/v0758_val_minute_all_{k}.pkl'
    if os.path.exists(path): Sc = pd.read_pickle(path)
    else:
        parts = []
        for te in ('P1', 'P2', 'P3'):
            ms = fit(PM[PM.period != te], fresh, extra=EX); B = PM[PM.period == te]; pu, pdn = pred(ms, B, fresh, extra=EX)
            t = B[['b', 'slot', 'k', 'inst', 'hour', 'period', 'move5']].copy(); t['pu'] = pu; t['pd'] = pdn; parts.append(t); print('  fit', k, te, flush=True)
        Sc = pd.concat(parts); Sc.to_pickle(path)
    Sc = Sc.merge(PM[['b', 'inst', 'date']], on=['b', 'inst'])
    M = best_minutes(Sc, Sc.pu.values, Sc.pd.values)
    fx = fixed_map(RTc, Bfix)
    Es = []; Hs = []
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs))
        tes = set(b for b in slots_cur if per_cur.get(b) == te)
        E, H = simulate(M[M.period == te], {b: v for b, v in fx.items() if b in tes}, tes, Q, base); Es.append(E); Hs.append(H)
    E = pd.concat(Es); H = pd.concat(Hs)
    ndays = len(set(pd.to_datetime(list(slots_cur), unit='s', utc=True).tz_convert('Asia/Tokyo').date))
    out[f'validation_{k}'] = summary(E, H, len(slots_cur), ndays, per_cur); print('validation', k, json.dumps(out[f'validation_{k}'], default=str), flush=True)
    # production model on the whole year
    ms = fit(PM, fresh, extra=EX); texts = [export(m) for m in ms]
    Xs = np.hstack([design(PM.sample(1500, random_state=7), 1, fresh)[0], PM.sample(1500, random_state=7)[['isk0']].values])
    for m, tx in zip(ms, texts):
        dd = np.abs(eval_text(tx, Xs) - m.predict_proba(Xs)[:, 1]).max(); assert dd < 1e-12, dd; assert len(tx) < 60000, len(tx)
    pu, pdn = pred(ms, PM, fresh, extra=EX); Mp = best_minutes(PM, pu, pdn)
    Q, base = tables(Mp, fx, hour_of(slots_cur))
    E, H = simulate(Mp, fx, slots_cur, Q, base)
    out[f'production_insample_{k}'] = summary(E, H, len(slots_cur), ndays, per_cur); print('production in-sample', k, json.dumps(out[f'production_insample_{k}'], default=str), flush=True)
    # out of time: 2023-24 with the production model and the production tables (exactly what the app would carry)
    pu, pdn = pred(ms, PY, fresh, extra=EX); My = best_minutes(PY, pu, pdn); slots_y = set(PY[PY.k == 0].slot)
    per_y = dict(zip(PY.b, PY.period)); fxy = fixed_map(RTp, None)
    E, H = simulate(My, {b: v for b, v in fxy.items() if b in slots_y}, slots_y, Q, base)
    ndy = len(set(PY.date)); out[f'past_years_{k}'] = summary(E, H, len(slots_y), ndy, per_y); print('2023-24', k, json.dumps(out[f'past_years_{k}'], default=str), flush=True)
    # parity rows (47 inputs) for the Kotlin test
    Sm = PM.sample(150, random_state=11 if fresh else 12); rows = []
    for d in (1, -1):
        Xd = np.hstack([design(Sm, d, fresh)[0], Sm[['isk0']].values]); pp = np.mean([m.predict_proba(Xd)[:, 1] for m in ms], 0)
        rows += [(k, float(p_), ','.join(repr(float(v)) for v in xr)) for p_, xr in zip(pp, Xd)]
    out.setdefault('_prod', {})[k] = dict(texts=texts, Q={h: [float(v) for v in Q[h]] for h in Q}, base={h: float(base[h]) for h in base}, parity=rows)
_, names = design(PM.head(2), 1, True); out['_prod']['features'] = names + ['isk0']
pickle.dump(out['_prod'], open('../work/production_model5_v0758.pkl', 'wb'))
json.dump({k: v for k, v in out.items() if k != '_prod'}, open('../work/v0758_production.json', 'w'), indent=1, default=str)

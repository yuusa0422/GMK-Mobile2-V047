import json
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
Sc = pd.read_pickle('../work/v0758_val_minute_all_fresh.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst'])
M = best_minutes(Sc, Sc.pu.values, Sc.pd.values); fx = fixed_map(RTc, Bfix); Es = []
for te in ('P1', 'P2', 'P3'):
    tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
    Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
    E, H = simulate(M[M.period == te], {b: v for b, v in fx.items() if b in tes}, tes, Q, base); Es.append(E)
E = pd.concat(Es); E['m'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
r0, X0 = evaluate(pd.read_pickle('../work/v0758_val_base_fresh.pkl'), 'v0757'); X0 = X0[X0.grade.isin(['S', 'A', 'B', 'C'])].copy()
X0['m'] = pd.to_datetime(X0.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
t = pd.DataFrame({'v0757_n': X0.groupby('m').size(), 'v0757': X0.groupby('m').twin.mean() * 100, 'v0758_n': E.groupby('m').size(), 'v0758': E.groupby('m').w.mean() * 100}).round(2)
t['diff'] = (t.v0758 - t.v0757).round(2); print(t.to_string()); print('months better', int((t['diff'] > 0).sum()), 'of', len(t))
t.to_csv('../work/v0758_monthly.csv')

"""Per-candidate research frames: every 5-min slot 09:00-22:55 JST every day.
Weekday: 6 instruments (app 6/6 eligibility). Weekend: BTCJPY only.
Usage: frames_build.py <out.pkl> <start YYYY-MM-DD> <end YYYY-MM-DD> sym=path ...   (CSV epoch_ms,open,high,low,close)"""
import sys, csv, pickle, bisect, datetime as dt, gzip
sys.path.insert(0, '.')
import native_engine as N, gmk_policy as P, tech_features as T
JST = dt.timezone(dt.timedelta(hours=9))
FX = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']; ALL = FX + ['BTCJPY']
out_path, d0, d1 = sys.argv[1], dt.date.fromisoformat(sys.argv[2]), dt.date.fromisoformat(sys.argv[3])
src = dict(a.split('=', 1) for a in sys.argv[4:])
bars = {}
for s, p in src.items():
    op = gzip.open if p.endswith('.gz') else open
    with op(p, 'rt') as f:
        rows = [(int(r['epoch_ms']), float(r['open']), float(r['high']), float(r['low']), float(r['close']), float(r.get('volume') or 0)) for r in csv.DictReader(f)]
    rows.sort(); bars[s] = rows
times = {s: [r[0] for r in rows] for s, rows in bars.items()}
index = {s: {r[0]: r for r in rows} for s, rows in bars.items()}
def weekend_gap(a, b):
    if b - a < 86400000: return False
    A = dt.datetime.fromtimestamp(a / 1000, dt.timezone.utc); B = dt.datetime.fromtimestamp(b / 1000, dt.timezone.utc)
    return A.weekday() == 4 and B.weekday() in (6, 0) and b - a <= 80 * 3600000
def context(s, B):
    if s not in times: return None, 'nodata'
    ms = B * 1000; i = bisect.bisect_right(times[s], ms - 120000)
    rows = bars[s][max(0, i - 120):i]
    if len(rows) < 21: return None, 'short'
    if rows[-1][0] != ms - 120000: return None, 'lag'
    tail = rows[-30:]
    gaps = [(a[0], b[0]) for a, b in zip(tail, tail[1:]) if b[0] - a[0] > 90000]
    bridge = any(s != 'BTCJPY' and weekend_gap(a, b) for a, b in gaps)
    if any(not (s != 'BTCJPY' and weekend_gap(a, b)) for a, b in gaps): return None, 'gap'
    if not bridge and len(tail) >= 30 and tail[-1][0] - tail[0][0] > 45 * 60000: return None, 'span'
    return rows, None
def move(s, B, mins=3):
    o = index[s].get(B * 1000); j = index[s].get((B + 60 * mins) * 1000)
    if o is None or j is None: return None
    return (j[1] > o[1]) - (j[1] < o[1])
KEEP = ['b', 'inst', 'hour', 'wd', 'weekday', 'order', 'fin_rank', 'gate', 'fin_dir', 'fin_rev', 'score', 'fin_exp', 'base_rank', 'base_rev', 'base_exp', 'regime', 'regimeConfidence', 'move3', 'move5']
rows_out = []; skipped = {}
t = dt.datetime.combine(d0, dt.time(9), JST)
end = dt.datetime.combine(d1, dt.time(22, 59), JST)
while t <= end:
    if 9 <= t.hour <= 22 and t.weekday() <= 4:
        weekday = t.weekday() <= 4
        req = ALL if weekday else ['BTCJPY']
        ctx = {}; bad = None
        for s in req:
            r, why = context(s, int(t.timestamp()))
            if r is None: bad = why; break
            ctx[s] = r
        if bad: skipped[bad] = skipped.get(bad, 0) + 1
        else:
            B = int(t.timestamp()); h = t.hour
            cands = []
            for s in req:
                x = N.score_instrument(s, ctx[s])
                f = dict(x, direction='HIGH' if x['score'] >= 0 else 'LOW')
                pb = P.classify_base(f, h); pf = P.classify(f, h)
                eff = -x['score'] if pf['reverse'] else x['score']; d = 'HIGH' if eff >= 0 else 'LOW'
                gs = P.gate_score(dict(instrument=s, regime=x['regime'], direction=d, grade=pf['rank'], ruleId=pf['ruleId'], reverse=pf['reverse'],
                     probability=pf['expectedWinRate'], effectiveScore=eff, regimeConfidence=x['regimeConfidence'], hour=h, rawConfidence=x['confidence'],
                     rsi14=x['rsi14'], atrPct=x['atrPct'], agreement=x['agreement'], efficiency=x['efficiency'], emaGapAtr=x['emaGapAtr'])) if pf['rank'] != 'E' else None
                effb = -x['score'] if pb['reverse'] else x['score']
                tf = {}
                cands.append(dict(b=B, hour=h, wd=t.weekday(), weekday=weekday, inst=s, **{k: v for k, v in x.items() if k != 'instrument'},
                     base_rank=pb['rank'], base_rev=pb['reverse'], base_min=pb['minPeriodWinRate'], base_exp=pb['expectedWinRate'], base_rid=pb['ruleId'],
                     fin_rank=pf['rank'], fin_rev=pf['reverse'], fin_exp=pf['expectedWinRate'], fin_n=pf['sampleSize'], fin_rid=pf['ruleId'], fin_stage=pf['stage'],
                     gate=gs, fin_dir=d, base_abs_eff=abs(effb), move3=move(s, B, 3), move5=move(s, B, 5),
                     **{'t_' + k: v for k, v in tf.items()}))
            cands.sort(key=lambda c: (-P.rank_priority(c['base_rank']), -c['base_min'], -c['base_exp'], -c['confidence'], -c['base_abs_eff'], c['inst']))
            for i, c in enumerate(cands): c['order'] = i + 1
            rows_out += [{k: c[k] for k in KEEP} for c in cands]
    t += dt.timedelta(minutes=1)
pickle.dump(rows_out, open(out_path, 'wb'))
print('candidate rows', len(rows_out), 'skipped', skipped)

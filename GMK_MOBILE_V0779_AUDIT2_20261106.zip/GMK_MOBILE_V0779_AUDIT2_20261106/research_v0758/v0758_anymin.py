"""'Any minute' policy in detail: entries per (day, hour), clustering, one-per-pair-per-slot variant, selection strictness, streaks."""
import json, sys
exec(open('v0758_lib.py').read())
key = sys.argv[1] if len(sys.argv) > 1 else 'minute'
S = pd.read_pickle(f'../work/v0758_val_{key}_fresh.pkl')
S['p'] = np.maximum(S.pu, S.pd); S['dir'] = np.where(S.pu >= S.pd, 1, -1); S['w'] = (S.move5 == S.dir).astype(float)
S['date'] = pd.to_datetime(S.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date
Wfix = Wd[['b', 'fix', 'win', 'win5']]; fixslots = set(Wd.b[Wd.fix != '']); slots_all = set(Wd.b)
G = Wfix[Wfix.b.isin(set(S.slot))].copy()
G['hour'] = pd.to_datetime(G.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.hour
G['date'] = pd.to_datetime(G.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date
G['period'] = np.where(G.date.astype(str) < '2026-02-01', 'P1', np.where(G.date.astype(str) < '2026-06-01', 'P2', 'P3'))
G['fw'] = np.where(G.fix.isin(['S', 'A']), G.win, np.where(G.fix == 'B', G.win5, np.nan))
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
def policy(cands, label, share_mult=1.0):
    """cands: candidate rows (one or more per minute); threshold per hour from the other periods so that entries = 60% of slots minus fixed."""
    X = cands[~cands.slot.isin(fixslots) & cands.slot.isin(set(G.b))]
    sel = []
    for te in ('P1', 'P2', 'P3'):
        for h in range(9, 23):
            g = G[(G.period != te) & (G.hour == h)]; need = (0.6 * len(g) - (g.fix != '').sum()) * share_mult
            tr = X[(X.period != te) & (X.hour == h)]; T = float(np.quantile(tr.p, 1 - need / len(tr)))
            sel.append(X[(X.period == te) & (X.hour == h) & (X.p >= T)])
    E = pd.concat(sel)
    F = G[G.fix != ''][['b', 'hour', 'date', 'period', 'fw']].rename(columns={'fw': 'w'})
    A = pd.concat([E[['b', 'hour', 'date', 'period', 'w']], F]).sort_values('b')
    per = A.groupby(['date', 'hour']).size().reindex(pd.MultiIndex.from_frame(G[['date', 'hour']].drop_duplicates()), fill_value=0)
    nslot = G.groupby(['date', 'hour']).size()
    rate = (per / nslot.reindex(per.index)).fillna(0)
    out = dict(label=label, entries_per_slot=round(len(A) / len(G) * 100, 1), win=round(A.w.mean() * 100, 2),
               **{p: round(A[A.period == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')},
               per_day=round(len(A) / G.date.nunique(), 1), maxrun=maxrun(A.w.values),
               hours_below_60=round((rate < 0.6).mean() * 100, 1), hours_zero=round((per == 0).mean() * 100, 1),
               same_pair_next_minute=round(((E.sort_values(['inst', 'b']).groupby('inst').b.diff() == 60).mean()) * 100, 1) if 'inst' in E else None)
    print(json.dumps(out, default=str), flush=True); return out, A
res = {}
M = S.sort_values('p', ascending=False).groupby('b').head(1)        # best pair each minute
if 'full' in sys.argv: res['k0_slots'] = policy(M[M.k == 0], 'slot boundary only (= v0.7.57)')[0]
if 'full' in sys.argv: res['any_minute'] = policy(M, 'any minute, best pair')[0]
# all pairs as candidates (several pairs may enter in the same minute)
if 'full' in sys.argv: res['any_minute_all_pairs'] = policy(S, 'any minute, any pair')[0]
if 'full' in sys.argv: res['strict_0.8'] = policy(M, 'any minute, 80% of the count (fewer entries)', 0.8)[0]
if 'full' in sys.argv: res['loose_1.2'] = policy(M, 'any minute, 120% of the count', 1.2)[0]
json.dump(res, open(f'../work/v0758_anymin_{key}.json', 'w'), indent=1, default=str)
# ---- strict: every actual hour reaches 60% of its slots (catch-up at the slot boundaries when behind)
def strict(cands, label, boundary_only=False):
    X = cands[cands.slot.isin(set(G.b))].copy(); X['k'] = (X.b % 300) // 60
    if boundary_only: X = X[X.k == 0]
    X['hour'] = pd.to_datetime(X.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.hour
    T = {}
    for te in ('P1', 'P2', 'P3'):
        for h in range(9, 23):
            g = G[(G.period != te) & (G.hour == h)]; need = 0.6 * len(g) - (g.fix != '').sum()
            tr = X[(X.period != te) & (X.hour == h) & ~X.slot.isin(fixslots)]; T[(te, h)] = float(np.quantile(tr.p, 1 - need / len(tr)))
    fixw_ = dict(zip(G.b, G.fw)); isfix = dict(zip(G.b, G.fix != '')); out_w = []; out_forced = 0; per_hour = []
    Xg = X.sort_values('b').groupby(['date', 'hour'])
    Gg = G.groupby(['date', 'hour'])
    for (d, h), gs in Gg:
        slots = sorted(gs.b); N = int(np.ceil(0.6 * len(slots))); cnt = 0
        mins = Xg.get_group((d, h)) if (d, h) in Xg.groups else X.iloc[:0]
        bym = {b: r for b, r in zip(mins.b, mins.itertuples(index=False))}
        te = gs.period.iloc[0]; thr = T[(te, h)]
        for j, s in enumerate(slots):
            if isfix[s]:
                out_w.append(fixw_[s]); cnt += 1; continue
            entered_in_slot = False
            for k in range(5):
                r = bym.get(s + 60 * k)
                if r is None: continue
                remaining = len(slots) - j - (1 if k > 0 else 0)
                if r.p >= thr:
                    out_w.append(r.w); cnt += 1; entered_in_slot = True
                elif k == 0 and not entered_in_slot and N - cnt >= len(slots) - j:
                    out_w.append(r.w); cnt += 1; out_forced += 1; entered_in_slot = True
        per_hour.append(cnt / len(slots))
    w = np.array(out_w, float); ph = np.array(per_hour)
    r = dict(label=label, entries_per_slot=round(len(w) / len(G) * 100, 1), win=round(np.nanmean(w) * 100, 2), forced=out_forced,
             hours_below_60=round((ph < 0.6 - 1e-9).mean() * 100, 1), maxrun=maxrun(w[np.isfinite(w)]))
    print(json.dumps(r), flush=True); return r
if 'full' in sys.argv: res['strict_boundary'] = strict(M, 'slot boundary + catch-up (every hour >= 60%)', boundary_only=True)
if 'full' in sys.argv: res['strict_any'] = strict(M, 'any minute + catch-up (every hour >= 60%)')
json.dump(res, open(f'../work/v0758_anymin_{key}.json', 'w'), indent=1, default=str)
# ---- strict with a moving cut: the cut at each minute follows how many entries the hour still needs
def strict_dyn(cands, label, alpha):
    X = cands[cands.slot.isin(set(G.b))].copy()
    X['hour'] = pd.to_datetime(X.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.hour
    Q = {}; base = {}
    for te in ('P1', 'P2', 'P3'):
        for h in range(9, 23):
            g = G[(G.period != te) & (G.hour == h)]; tr = X[(X.period != te) & (X.hour == h) & ~X.slot.isin(fixslots)]
            Q[(te, h)] = np.sort(tr.p.values); base[(te, h)] = (0.6 * len(g) - (g.fix != '').sum()) / len(tr)
    def q(te, h, frac):
        a = Q[(te, h)]; frac = min(max(frac, 0.0), 1.0)
        return -np.inf if frac >= 1 else a[min(int((1 - frac) * len(a)), len(a) - 1)]
    fixw_ = dict(zip(G.b, G.fw)); isfix = dict(zip(G.b, G.fix != '')); W_ = []; per_hour = []; forced = 0
    Xg = X.sort_values('b').groupby(['date', 'hour'])
    for (d, h), gs in G.groupby(['date', 'hour']):
        slots = sorted(gs.b); N = int(np.ceil(0.6 * len(slots))); cnt = 0; te = gs.period.iloc[0]
        mins = Xg.get_group((d, h)) if (d, h) in Xg.groups else X.iloc[:0]
        bym = {b: r for b, r in zip(mins.b, mins.itertuples(index=False))}
        seq = []
        for s in slots:
            if isfix[s]: seq.append(('F', s))
            else: seq += [('M', s + 60 * k) for k in range(5) if (s + 60 * k) in bym]
        nf_left = sum(1 for t, _ in seq if t == 'F')
        for i, (t, b) in enumerate(seq):
            if t == 'F':
                W_.append(fixw_[b]); cnt += 1; nf_left -= 1; continue
            r_left = sum(1 for tt, _ in seq[i:] if tt == 'M'); m = N - cnt - nf_left
            if m >= r_left: thr = -np.inf; forced += 1
            elif m > 0: thr = q(te, h, max(m / r_left, base[(te, h)] * 0.5))
            else: thr = q(te, h, base[(te, h)] * alpha)
            row = bym[b]
            if row.p >= thr: W_.append(row.w); cnt += 1
        per_hour.append(cnt / len(slots))
    w = np.array(W_, float); ph = np.array(per_hour)
    r = dict(label=label, alpha=alpha, entries_per_slot=round(len(w) / len(G) * 100, 1), win=round(np.nanmean(w) * 100, 2),
             hours_below_60=round((ph < 0.6 - 1e-9).mean() * 100, 1), maxrun=maxrun(w[np.isfinite(w)]))
    print(json.dumps(r), flush=True); return r
for a in (0.0, 0.3, 0.6):
    res[f'strict_dyn_{a}'] = strict_dyn(M, 'any minute, moving cut, every hour >= 60%', a)
json.dump(res, open(f'../work/v0758_anymin_{key}.json', 'w'), indent=1, default=str)

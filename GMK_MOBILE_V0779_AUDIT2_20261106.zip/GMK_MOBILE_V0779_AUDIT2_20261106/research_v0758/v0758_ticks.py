"""Tick samples (Oct-Nov 2025, AUD/EUR/GBP/NZD JPY): how much does the 'live price' timing matter, entry delay, last-seconds signals.
Model: fresh 5-minute model trained on P2+P3 (5 seeds), scored on the P1 rows that have tick samples."""
import json, math
exec(open('v0758_lib.py').read())
exec(open('policy_data.py').read().split("d = pd.DataFrame(pickle.load")[0])
TP = ['AUDJPY', 'EURJPY', 'GBPJPY', 'NZDJPY']
T = pd.concat([pd.read_csv(f'/tmp/gmkdata/ticks/tick_samples_{s}.csv.gz').assign(inst=s) for s in TP], ignore_index=True)
T['hs'] = (T.ask_0 - T.bid_0) / 2
print('tick rows', len(T), T.groupby('inst').size().to_dict(), flush=True)
R = P[(P.period == 'P1') & P.inst.isin(TP)].merge(T, on=['b', 'inst'], how='inner')
print('policy rows with ticks', len(R), 'slots', R.b.nunique(), flush=True)
# --- proxy check: bar close of B-60 (bid) vs tick mid at B-1s minus half spread
prox = np.array([index[s].get((b - 60) * 1000, (0, 0, 0, 0, np.nan))[4] for s, b in zip(R.inst, R.b)])
R = R[np.isfinite(prox)].reset_index(drop=True); prox = prox[np.isfinite(prox)]
R = R[[window(s, b) is not None for s, b in zip(R.inst, R.b)]].reset_index(drop=True)
prox = np.array([index[s][(b - 60) * 1000][4] for s, b in zip(R.inst, R.b)])
print('rows with proxy and window', len(R), flush=True)
for k in ('p_m1', 'p_m2', 'p_m3', 'p_m5', 'p_m10'):
    d = (R[k] - R.hs - prox) / prox * 1e4
    print(f'proxy - bid({k}) median {np.median(np.abs(d)):.3f} bp, same {np.mean(np.abs(d) < 0.05) * 100:.1f}%')
# --- variants of the live price
VAR = {'proxy': None, 'm1': 'p_m1', 'm3': 'p_m3', 'm5': 'p_m5', 'm10': 'p_m10', 'm15': 'p_m15', 'm20': 'p_m20', 'm30': 'p_m30', 'm60': 'p_m60'}
FC = ['f1', 'f2', 'f5', 'f15', 'pos15L', 'bbzL']
base_ms = fit(P[P.period != 'P1'], True)
yen_other = P[(P.period == 'P1') & (P.inst == 'USDJPY')][['b', 'f1']].rename(columns={'f1': 'usd_f1'})
res = {}; outs = {}
for v, col in VAR.items():
    Q = R.copy()
    if col is not None:
        rows = []
        for s, b, live in zip(Q.inst, Q.b, Q[col] - Q.hs):
            w = window(s, b); f = feats(w, float(live), False); rows.append([f[c] for c in FC])
        Q[FC] = np.array(rows)
    # yen f1: USDJPY keeps the proxy (no ticks), EUR/GBP/AUD use this variant
    Q = Q.merge(yen_other, on='b', how='left')
    g = Q[Q.inst.isin(['EURJPY', 'GBPJPY', 'AUDJPY'])].groupby('b').f1.agg(['sum', 'size'])
    Q['yenf1'] = (Q.b.map(g['sum']) + Q.usd_f1) / (Q.b.map(g['size']) + 1)
    Q['idiof1'] = Q.f1 - Q.yenf1
    pu, pdn = pred(base_ms, Q, True); Q['pu'] = pu; Q['pd'] = pdn; Q['p'] = np.maximum(pu, pdn); Q['dir'] = np.where(pu >= pdn, 1, -1)
    outs[v] = Q
# common slots (all variants defined) ; per slot best of the 4 pairs; top 60% per hour by p
slots = set.intersection(*[set(Q.dropna(subset=['p']).b) for Q in outs.values()])
for v, Q in outs.items():
    Q = Q[Q.b.isin(slots)]
    best = Q.sort_values('p', ascending=False).groupby('b').head(1).copy()
    best['rk'] = best.groupby('hour').p.rank(ascending=False, pct=True)
    E = best[best.rk <= 0.6]
    w5 = (E.move5 == E.dir).mean(); w3 = (E.move3 == E.dir).mean()
    w3t = (np.sign(E.p_p180 - E.p_p0) == E.dir).mean()
    res[v] = dict(n=len(E), win5=round(w5 * 100, 2), win3=round(w3 * 100, 2), win3_tick=round(w3t * 100, 2), all_win5=round((best.move5 == best.dir).mean() * 100, 2))
    print(v, res[v], flush=True)
# --- entry delay (3-minute, tick to tick, mid): chosen direction of the proxy model, top 60%
Q = outs['proxy'][outs['proxy'].b.isin(slots)]; best = Q.sort_values('p', ascending=False).groupby('b').head(1).copy()
best['rk'] = best.groupby('hour').p.rank(ascending=False, pct=True); E = best[best.rk <= 0.6]
delay = {}
for d, end in ((0, 'p_p180'), (1, 'p_p181'), (2, 'p_p182'), (3, 'p_p183'), (5, 'p_p185'), (7, 'p_p187'), (10, 'p_p190'), (15, 'p_p195')):
    st = 'p_p0' if d == 0 else f'p_p{d}'
    mv = np.sign(E[end] - E[st]); delay[d] = dict(win=round((mv == E.dir).mean() * 100, 2), draw=round((mv == 0).mean() * 100, 2))
for d, st in ((-10, 'p_m10'), (-5, 'p_m5')):
    mv = np.sign(E.p_p180 - E[st]); delay[d] = dict(win=round((mv == E.dir).mean() * 100, 2), note='entry price earlier, end at +180')
print('entry delay 3m', delay, flush=True)
# --- 5-minute with delayed entry: end = M1 open at B+300 (bid), entry = tick bid at B+d
o300 = np.array([index[s].get((b + 300) * 1000, (0, np.nan))[1] for s, b in zip(E.inst, E.b)])
d5 = {}
for d, st in ((0, 'p_p0'), (3, 'p_p3'), (5, 'p_p5'), (10, 'p_p10'), (15, 'p_p15')):
    mv = np.sign(o300 - (E[st] - E.hs)); d5[d] = round((mv == E.dir).mean() * 100, 2)
d5['move5(M1)'] = round((E.move5 == E.dir).mean() * 100, 2)
print('entry delay 5m (end fixed at B+300)', d5, flush=True)
# --- last-seconds signals among the entered 60%: does the move in the last seconds agree with the chosen direction?
sig = {}
for name, a, b_ in (('m30_to_m10', 'p_m30', 'p_m10'), ('m60_to_m10', 'p_m60', 'p_m10'), ('m10_to_m1', 'p_m10', 'p_m1'), ('m20_to_m10', 'p_m20', 'p_m10')):
    s = np.sign(E[b_] - E[a]) * E.dir
    sig[name] = {k: (int((s == k).sum()), round((E[s == k].move5 == E[s == k].dir).mean() * 100, 2)) for k in (-1, 0, 1)}
act = pd.qcut(E.n60.rank(method='first'), 3, labels=['low', 'mid', 'high'])
sig['ticks_n60'] = {k: (int((act == k).sum()), round((E[act == k].move5 == E[act == k].dir).mean() * 100, 2)) for k in ('low', 'mid', 'high')}
spr = pd.qcut((E.hs / E.p_p0 * 1e4).rank(method='first'), 3, labels=['narrow', 'mid', 'wide'])
sig['spread'] = {k: (int((spr == k).sum()), round((E[spr == k].move5 == E[spr == k].dir).mean() * 100, 2)) for k in ('narrow', 'mid', 'wide')}
print('last seconds (n, win5)', json.dumps(sig), flush=True)
json.dump(dict(variants=res, delay3=delay, delay5=d5, signals=sig, rows=len(R), slots=len(slots)), open('../work/v0758_ticks.json', 'w'), indent=1, default=str)

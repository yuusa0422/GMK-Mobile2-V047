"""World markets lead-lag: add the recent moves of EURUSD, EURGBP, XAUUSD, Nikkei (JPNIDXJPY), DAX (DEUIDXEUR), US T-bond (USTBONDTRUSD)
to the 5-minute model and compare with the same rotation. Two timings: up to B (like the live price) and up to B-60 (bars only)."""
import json, sys
exec(open('v0758_lib.py').read())
SYM = ['EURUSD', 'EURGBP', 'XAUUSD', 'JPNIDXJPY', 'DEUIDXEUR', 'USTBONDTRUSD']
slots = np.sort(P.b.unique())
F = pd.DataFrame({'b': slots})
for s in SYM:
    W = pd.read_csv(f'/tmp/gmkdata/world/{s}_1m_raw.csv.gz'); W['m'] = (W.epoch_ms // 60000).astype(np.int64)
    W = W.drop_duplicates('m').set_index('m'); c = np.log(W.close.astype(float))
    full = pd.Series(np.nan, index=np.arange(c.index.min(), c.index.max() + 1)); full.loc[c.index] = c.values
    ret = full.diff(); rv = ret.rolling(60, min_periods=40).std()
    for tag, lag in (('L', 1), ('B', 2)):          # L: last bar = bar opening at B-60 (price at B); B: bar opening at B-120 (price at B-60)
        m = slots // 60 - lag; cm = full.reindex(m).values; v = rv.reindex(m).values; v = np.where(v > 0, v, np.nan)
        for k in (1, 5, 15):
            F[f'w{tag}_{s}_{k}'] = (cm - full.reindex(m - k).values) / (v * np.sqrt(k))
        F[f'w{tag}_{s}_rv'] = v * 1e4
    print(s, 'coverage', round(np.isfinite(F[f'wL_{s}_5']).mean() * 100, 1), '%', flush=True)
D = P.merge(F, on='b', how='left')
out = {}
for tag in ('L', 'B'):
    extra = [(f'w{tag}_{s}_{k}', True) for s in SYM for k in (1, 5, 15)] + [(f'w{tag}_{s}_rv', False) for s in SYM]
    C = cached_validation(True, f'world{tag}', extra=extra, data=D); r, X = evaluate(C, f'world {tag}'); out[tag] = r; print(json.dumps(r), flush=True)
    # where all six markets are present
    full_b = set(F.b[np.isfinite(F[[f'w{tag}_{s}_5' for s in SYM]]).all(1)])
    Cb = pd.read_pickle('../work/v0758_val_base_fresh.pkl')
    r1, _ = evaluate(C[C.b.isin(full_b)], f'world {tag} (full coverage slots)'); r0, _ = evaluate(Cb[Cb.b.isin(full_b)], 'base (same slots)')
    out[tag + '_full'] = [r1, r0]; print(json.dumps(r1)); print(json.dumps(r0), flush=True)
json.dump(out, open('../work/v0758_world.json', 'w'), indent=1, default=float)
F.to_pickle('../work/v0758_world_features.pkl')

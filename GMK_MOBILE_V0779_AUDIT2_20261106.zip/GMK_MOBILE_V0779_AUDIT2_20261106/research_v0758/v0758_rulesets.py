"""Which time-of-day rules to keep: simulate the weekday per-hour-60% policy with all 8 rules / the 3 that held on 2023-24 / 9:55 only / none,
on the current year (rotation, B as in v0.7.57) and on the past years (5-minute model trained on the current year; no B there)."""
import json
exec(open('v0758_lib.py').read())
PY = pd.read_pickle('../work/years/policy_years.pkl'); PY = PY[PY.weekday & PY.move3.notna()].reset_index(drop=True)
PY['idio5'] = np.where(PY.inst == 'BTCJPY', 0.0, PY.r5 - PY.yen5); PY['idio15'] = np.where(PY.inst == 'BTCJPY', 0.0, PY.r15 - PY.yen15)
PY['idiof1'] = np.where(PY.inst == 'BTCJPY', 0.0, PY.f1 - PY.yenf1); PY['grade_n'] = PY.app_grade.map(GR).astype(float); PY['wkend'] = 0.0
PY['period'] = np.where(PY.date.astype(str) < '2023-06-01', 'Y1', np.where(PY.date.astype(str) < '2023-11-01', 'Y2', 'Y3'))
RTc = pd.read_pickle('../work/rule_trades_current.pkl'); RTp = pd.read_pickle('../work/years/rule_trades_years.pkl')
SETS = {'all8': None, 'keep3': ['FIX955_POS', 'FIX955_BBZ', 'US0830_F1'], 'fix955': ['FIX955_POS', 'FIX955_BBZ'], 'none': []}
def sim(C, RT, keep, Bfix):
    C = C.copy(); C['p'] = np.maximum(C.pu, C.pd); C['dir'] = np.where(C.pu >= C.pd, 1, -1)
    X = C.sort_values('p', ascending=False).groupby('b').head(1).copy(); X['w'] = (X.move5 == X.dir).astype(float)
    R = RT if keep is None else RT[RT.rule.isin(keep)]
    X = X.merge(R[['b', 'rule', 'win3']], on='b', how='left'); X['g'] = np.where(X.rule.notna(), 'SA', '')
    if Bfix is not None:
        X = X.merge(Bfix, on='b', how='left'); isb = (X.g == '') & (X.fix == 'B'); X.loc[isb, 'g'] = 'B'; X.loc[isb, 'w'] = X.loc[isb, 'win5']
    X.loc[X.g == 'SA', 'w'] = X.loc[X.g == 'SA', 'win3']
    X['isfix'] = X.g != ''
    X['rk'] = X[~X.isfix].groupby(['period', 'hour']).p.rank(ascending=False, method='first')
    n = X.groupby(['period', 'hour']).b.transform('size'); nf = X.groupby(['period', 'hour']).isfix.transform('sum')
    X.loc[(X.g == '') & (X.rk <= np.ceil(0.6 * n) - nf), 'g'] = 'C'
    E = X[X.g != '']; days = X.b.map(lambda b: b // 86400).nunique()
    return dict(cover=round(len(E) / len(X) * 100, 1), win=round(E.w.mean() * 100, 2),
                periods={p: round(E[E.period == p].w.mean() * 100, 2) for p in sorted(E.period.unique())},
                SA=(int((X.g == 'SA').sum()), round(X[X.g == 'SA'].w.mean() * 100, 2) if (X.g == 'SA').any() else None),
                B=(int((X.g == 'B').sum()), round(X[X.g == 'B'].w.mean() * 100, 2) if (X.g == 'B').any() else None),
                C=(int((X.g == 'C').sum()), round(X[X.g == 'C'].w.mean() * 100, 2)),
                skip=round(X[X.g == ''].w.mean() * 100, 2),
                safe=(round(X.g.isin(['SA', 'B']).sum() / days, 1), round(X[X.g.isin(['SA', 'B'])].w.mean() * 100, 2)))
out = {}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'
    Cc = cached_validation(fresh, 'base')
    ms = fit(P, fresh); FY = PY[PY.inst != 'BTCJPY']; pu, pdn = pred(ms, FY, fresh)
    Cp = FY[['b', 'inst', 'hour', 'period', 'move5']].assign(pu=pu, pd=pdn)
    for nm, keep in SETS.items():
        a = sim(Cc, RTc, keep, Wd[['b', 'fix', 'win5']]); b = sim(Cp, RTp, keep, None)
        out[f'{k}_{nm}'] = dict(current=a, past=b)
        print(k, nm, '\n  current', json.dumps(a), '\n  past   ', json.dumps(b), flush=True)
json.dump(out, open('../work/v0758_rulesets.json', 'w'), indent=1, default=float)

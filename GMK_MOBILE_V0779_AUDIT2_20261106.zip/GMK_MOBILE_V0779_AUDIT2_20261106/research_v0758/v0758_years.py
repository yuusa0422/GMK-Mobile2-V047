"""Past years (2023-01 .. 2024-06, Dukascopy M1, same features as the app):
A) the eight time-of-day rules on data they were never fitted on (3-minute and 5-minute outcomes)
B) the 5-minute model: (1) rotation with the past years added to training, (2) trained on the current year -> scored on the past years,
   (3) trained on the past years only -> scored on the current year."""
import json, math, gzip, csv, bisect, datetime as dt
from zoneinfo import ZoneInfo
exec(open('v0758_lib.py').read())
PY = pd.read_pickle('../work/years/policy_years.pkl')
PY = PY[PY.weekday & PY.move3.notna()].reset_index(drop=True)
PY['idio5'] = np.where(PY.inst == 'BTCJPY', 0.0, PY.r5 - PY.yen5); PY['idio15'] = np.where(PY.inst == 'BTCJPY', 0.0, PY.r15 - PY.yen15)
PY['idiof1'] = np.where(PY.inst == 'BTCJPY', 0.0, PY.f1 - PY.yenf1); PY['grade_n'] = PY.app_grade.map(GR).astype(float); PY['wkend'] = 0.0
PY['period'] = 'Y'
print('past-years weekday rows', len(PY), 'slots', PY.b.nunique(), 'days', PY.date.nunique(), PY.ts.min(), PY.ts.max(), flush=True)
out = {}
# ---------------- A) time-of-day rules ----------------
RULES = [('FIX955_POS', 'Asia/Tokyo', 9 * 60 + 55, 'pos60L', 0.8, True), ('FIX955_BBZ', 'Asia/Tokyo', 9 * 60 + 55, 'bbzL', 1.5, True),
         ('JST1220_POS', 'Asia/Tokyo', 12 * 60 + 20, 'pos60L', 0.8, False), ('JST2250_R15', 'Asia/Tokyo', 22 * 60 + 50, 'r15', 1.0, False),
         ('LON0725_R5', 'Europe/London', 7 * 60 + 25, 'r5', 1.0, False), ('US0830_BBZ', 'America/New_York', 8 * 60 + 30, 'bbzL', 1.5, False),
         ('US0830_F1', 'America/New_York', 8 * 60 + 30, 'f1', 1.0, False), ('UK0930_F1', 'Europe/London', 9 * 60 + 30, 'f1', 1.0, False)]
FXO = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
def minute_of(b, tz):
    t = dt.datetime.fromtimestamp(int(b), ZoneInfo(tz)); return t.hour * 60 + t.minute
bars = {}
for s in FXO:
    with gzip.open(f'/tmp/gmkdata/years/{s}_1m.csv.gz', 'rt') as f:
        rows = sorted((int(float(r['epoch_ms'])), float(r['high']), float(r['low']), float(r['close'])) for r in csv.DictReader(f))
    bars[s] = rows
times = {s: [r[0] for r in v] for s, v in bars.items()}; idx = {s: {r[0]: r for r in v} for s, v in bars.items()}
def pos60L(s, b):
    i = bisect.bisect_right(times[s], (b - 120) * 1000); w = bars[s][max(0, i - 61):i]
    lb = idx[s].get((b - 60) * 1000)
    if len(w) != 61 or lb is None: return np.nan
    live = lb[3]; hi = max(max(r[1] for r in w), live); lo = min(min(r[2] for r in w), live)
    return (live - lo) / max(hi - lo, 1e-12) * 2 - 1
def rule_trades(D, bars_ok=True):
    res = []
    F = D[D.inst.isin(FXO)]
    for b, g in F.groupby('b'):
        for rid, tz, mod, feat, thr, usd in RULES:
            if minute_of(b, tz) != mod: continue
            best = None
            for r in g.itertuples(index=False):
                v = pos60L(r.inst, b) if feat == 'pos60L' else getattr(r, feat)
                if not np.isfinite(v) or abs(v) < thr: continue
                key = (0 if (usd and r.inst == 'USDJPY') else 1, -round(abs(v), 12), FXO.index(r.inst))
                if best is None or key < best[0]: best = (key, r, v)
            if best is not None:
                _, r, v = best; d = -1 if v > 0 else 1
                res.append(dict(b=b, rule=rid, inst=r.inst, dir=d, win3=int(r.move3 == d), win5=int(r.move5 == d) if np.isfinite(r.move5) else np.nan, year=str(r.date)[:4]))
                break
    return pd.DataFrame(res)
RT = rule_trades(PY)
tab = RT.groupby('rule').agg(n=('win3', 'size'), win3=('win3', 'mean'), win5=('win5', 'mean'))
tab.loc['ALL'] = [len(RT), RT.win3.mean(), RT.win5.mean()]
print('A) rules on the past years\n', tab.round(4).to_string(), flush=True)
print('   by year', RT.groupby('year').win3.agg(['size', 'mean']).round(4).to_dict(), flush=True)
out['rules'] = tab.round(4).reset_index().to_dict('records'); RT.to_pickle('../work/years/rule_trades_years.pkl')
# ---------------- B) 5-minute model ----------------
def model_only(C, shares=(0.2, 0.4, 0.51, 0.6, 1.0)):
    C = C.copy(); C['p'] = np.maximum(C.pu, C.pd); C['dir'] = np.where(C.pu >= C.pd, 1, -1)
    best = C.sort_values('p', ascending=False).groupby('b').head(1).copy()
    best['rk'] = best.groupby('hour').p.rank(ascending=False, pct=True); best['w'] = (best.move5 == best.dir).astype(int)
    return {f'{int(s * 100)}%': round(best[best.rk <= s].w.mean() * 100, 2) for s in shares}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'
    # (1) rotation with years added
    C1 = cached_validation(fresh, 'plusyears', train_extra=PY[PY.move5.notna()]); r1, _ = evaluate(C1, f'rotation + past years ({k})')
    C0 = cached_validation(fresh, 'base'); r0, _ = evaluate(C0, f'base ({k})')
    print(json.dumps(r0)); print(json.dumps(r1), flush=True)
    # (2) current year -> past years ; (3) past years -> current year
    ms = fit(P, fresh); FY = PY[PY.inst != 'BTCJPY']; pu, pdn = pred(ms, FY, fresh)
    C2 = FY[['b', 'inst', 'hour', 'move5']].assign(pu=pu, pd=pdn); m2 = model_only(C2)
    ms3 = fit(PY[PY.move5.notna()], fresh); FC = P[P.inst != 'BTCJPY']; pu3, pd3 = pred(ms3, FC, fresh)
    C3 = FC[['b', 'inst', 'hour', 'period', 'move5']].assign(pu=pu3, pd=pd3); r3, _ = evaluate(C3, f'past years only -> current year ({k})')
    m3 = model_only(C3); m0 = model_only(C0)
    print(f'model only, top share per hour ({k}): current->past {m2} | past->current {m3} | rotation (current) {m0}', flush=True)
    print(json.dumps(r3), flush=True)
    out[k] = dict(base=r0, plus_years=r1, past_to_current=r3, model_only=dict(current_to_past=m2, past_to_current=m3, rotation_current=m0))
json.dump(out, open('../work/v0758_years.json', 'w'), indent=1, default=float)

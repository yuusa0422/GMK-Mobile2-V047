"""v0.7.58 research helpers: weekday policy rows with 5-minute outcome, validation models (period rotation) cached,
and the per-hour 60% evaluation used for v0.7.57 (S/A rules at 3 min, B at 5 min, rest by the model)."""
import pandas as pd, numpy as np, pickle, os, time
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
M5 = pd.read_pickle('../work/move5_v0757.pkl')[['b', 'inst', 'move5']]
P = P.merge(M5, on=['b', 'inst'], how='left'); P = P[P.weekday].reset_index(drop=True)
P['period'] = np.where(P.date.astype(str) < '2026-02-01', 'P1', np.where(P.date.astype(str) < '2026-06-01', 'P2', 'P3'))
L = pd.read_pickle('../work/ladder_v0756.pkl'); Wd = L[L.weekday][['b', 'g56', 'inst', 'win', 'tie']].rename(columns={'inst': 'linst'})
Wd = Wd.merge(pd.read_pickle('../work/ladder_at5_v0757.pkl')[['b', 'win5', 'tie5']], on='b', how='left')
Wd['fix'] = np.where(Wd.g56.isin(['S', 'A']) & (Wd.linst != 'BTCJPY'), Wd.g56, np.where((Wd.g56 == 'B') & (Wd.linst != 'BTCJPY'), 'B', ''))

def xy(A, fresh, extra=None):
    Xu = design(A, 1, fresh)[0]; Xd = design(A, -1, fresh)[0]
    if extra:
        eu = np.column_stack([A[c].values * (1 if s else 1) for c, s in extra]); ed = np.column_stack([A[c].values * (-1 if s else 1) for c, s in extra])
        Xu = np.hstack([Xu, eu]); Xd = np.hstack([Xd, ed])
    return Xu, Xd

def fit(A, fresh, seeds=range(5), extra=None, y5=True, cfg=None):
    Xu, Xd = xy(A, fresh, extra); X = np.vstack([Xu, Xd]); mv = A.move5.values if y5 else A.move3.values
    y = np.r_[(mv == 1), (mv == -1)].astype(int); ok = ~np.isnan(np.r_[mv, mv])
    return [HistGradientBoostingClassifier(random_state=s, **(cfg or CFG)).fit(X[ok], y[ok]) for s in seeds]

def pred(ms, df, fresh, extra=None):
    Xu, Xd = xy(df, fresh, extra)
    return np.mean([m.predict_proba(Xu)[:, 1] for m in ms], 0), np.mean([m.predict_proba(Xd)[:, 1] for m in ms], 0)

def evaluate(C, label=''):
    """C: rows (b, inst, hour, period, move5, pu, pd) for FX candidates. Returns per-hour-60% result like v0.7.57."""
    C = C.copy(); C['p'] = np.maximum(C.pu, C.pd); C['dir'] = np.where(C.pu >= C.pd, 1, -1)
    best = C.sort_values('p', ascending=False).groupby('b').head(1)
    X = Wd.merge(best, on='b', how='inner')
    X['nwin'] = (X.move5 == X.dir).astype(int); X['ntie'] = (X.move5 == 0).astype(int)
    X['twin'] = np.where(X.fix.isin(['S', 'A']), X.win, np.where(X.fix == 'B', X.win5, X.nwin))
    X['isfix'] = X.fix != ''
    X['rk'] = X[~X.isfix].groupby(['period', 'hour']).p.rank(ascending=False, method='first')
    n = X.groupby(['period', 'hour']).b.transform('size'); nf = X.groupby(['period', 'hour']).isfix.transform('sum')
    quota = np.ceil(0.6 * n) - nf
    X['grade'] = np.where(X.isfix, X.fix, np.where(X.rk <= quota, 'C', 'D'))
    E = X[X.grade.isin(['S', 'A', 'B', 'C'])]
    r = dict(label=label, slots=len(X), cover=round(len(E) / len(X) * 100, 1), win=round(E.twin.mean() * 100, 2),
             **{p: round(E[E.period == p].twin.mean() * 100, 2) for p in ('P1', 'P2', 'P3')},
             C=round(X[X.grade == 'C'].twin.mean() * 100, 2), D=round(X[X.grade == 'D'].twin.mean() * 100, 2),
             C_n=int((X.grade == 'C').sum()))
    return r, X

def cached_validation(fresh=True, key='base', extra=None, data=None, seeds=range(5), cfg=None, train_extra=None):
    """Rotation: train on the other two periods (+ optional extra training rows), score the FX rows of the held-out period."""
    path = f'../work/v0758_val_{key}_{"fresh" if fresh else "fallback"}.pkl'
    if os.path.exists(path): return pd.read_pickle(path)
    D = P if data is None else data; parts = []
    for te in ('P1', 'P2', 'P3'):
        t0 = time.time(); tr = D[D.period != te]
        if train_extra is not None: tr = pd.concat([tr, train_extra], ignore_index=True)
        ms = fit(tr, fresh, seeds, extra, cfg=cfg); B = D[(D.period == te) & (D.inst != 'BTCJPY')]
        pu, pdn = pred(ms, B, fresh, extra); t = B[['b', 'inst', 'hour', 'period', 'move5']].copy(); t['pu'] = pu; t['pd'] = pdn; parts.append(t)
        print('  val', key, te, len(tr), round(time.time() - t0), 's', flush=True)
    C = pd.concat(parts); C.to_pickle(path); return C

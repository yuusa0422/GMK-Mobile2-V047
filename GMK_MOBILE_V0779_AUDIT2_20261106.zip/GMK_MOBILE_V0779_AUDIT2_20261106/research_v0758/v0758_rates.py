"""Grade rates for the app's tables (validation of the exact app rule, period rotation): S/A of the 3 kept rules, B, C, D (boundary minutes
not entered), October; 55%-mode numbers; per-hour ENTRY share."""
import json
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
OCT = 1790780400
res = {}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'
    Sc = pd.read_pickle(f'../work/v0758_val_minute_all_{k}.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst'])
    M = best_minutes(Sc, Sc.pu.values, Sc.pd.values); fx = fixed_map(RTc, Bfix)
    Es = []
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs))
        tes = set(b for b in slots_cur if per_cur.get(b) == te)
        E, H = simulate(M[M.period == te], {b: v for b, v in fx.items() if b in tes}, tes, Q, base); Es.append(E)
    E = pd.concat(Es)
    sa = Wd[Wd.b.isin(RTc[RTc.rule.isin(KEEP)].b)][['b', 'g56', 'win']]
    D = M[(M.k == 0) & ~M.b.isin(set(E.b)) & ~M.b.isin(set(fx)) & M.b.isin(slots_cur)]
    def rate(x, w='w'): return dict(year=round(x[w].mean(), 4), oct=round(x[x.b >= OCT][w].mean(), 4) if (x.b >= OCT).any() else None, oct_n=int((x.b >= OCT).sum()), n=int(len(x)))
    r = {g: rate(sa[sa.g56 == g], 'win') for g in ('S', 'A')}
    r['B'] = rate(E[E.g == 'B']); r['C'] = rate(E[E.g == 'C']); r['D'] = rate(D)
    r['SAB_only'] = dict(win=round(E[E.g.isin(['SA', 'B'])].w.mean() * 100, 2), per_day=round(E.g.isin(['SA', 'B']).sum() / len(set(PM.date)), 1))
    r['all'] = dict(win=round(E.w.mean() * 100, 2), per_day=round(len(E) / len(set(PM.date)), 1), entries_per_slot=round(len(E) / len(slots_cur) * 100, 1))
    res[k] = r; print(k, json.dumps(r), flush=True)
json.dump(res, open('../work/v0758_rates.json', 'w'), indent=1)

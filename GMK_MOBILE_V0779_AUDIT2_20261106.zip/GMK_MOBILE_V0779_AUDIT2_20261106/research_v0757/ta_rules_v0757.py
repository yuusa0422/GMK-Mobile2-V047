"""v0.7.57: classic technical-analysis signals on the 5 FX pairs, weekday 09:00-22:55 slots, 3-minute outcome open(B)->open(B+180)
(DRAW = loss). Each rule gives a direction where it fires; both the textbook direction and its opposite are scored per period."""
import pandas as pd, numpy as np, json
T = pd.read_pickle('../work/ta_v0757.pkl')
P = pd.read_pickle('../work/policy_data.pkl')[['b', 'inst', 'move3', 'date', 'hour', 'f1']]
X = T.merge(P, on=['b', 'inst'], how='inner')
X['period'] = np.where(X.date.astype(str) < '2026-02-01', 'P1', np.where(X.date.astype(str) < '2026-06-01', 'P2', 'P3'))
sg = lambda cond_up, cond_dn: np.where(cond_up, 1, np.where(cond_dn, -1, 0))
R = {
 'RSI14(1分) 30以下で買い/70以上で売り': sg(X.m1_rsi14 <= 30, X.m1_rsi14 >= 70),
 'RSI14(1分・直前価格) 30/70 逆張り': sg(X.m1_rsi14L <= 30, X.m1_rsi14L >= 70),
 'RSI7(1分) 20/80 逆張り': sg(X.m1_rsi7 <= 20, X.m1_rsi7 >= 80),
 'RSI14(5分) 30/70 逆張り': sg(X.m5_rsi14 <= 30, X.m5_rsi14 >= 70),
 'RSI14(15分) 30/70 逆張り': sg(X.m15_rsi14 <= 30, X.m15_rsi14 >= 70),
 'ストキャス(1分) 20以下でK上抜け買い/80以上でK下抜け売り': sg((X.m1_stk < 20) & (X.m1_stx == 2), (X.m1_stk > 80) & (X.m1_stx == -2)),
 'ストキャス(5分) 同上': sg((X.m5_stk < 20) & (X.m5_stx == 2), (X.m5_stk > 80) & (X.m5_stx == -2)),
 'ボリンジャー(1分) -2σ割れ買い/+2σ超え売り': sg(X.m1_bbp <= -1, X.m1_bbp >= 1),
 'ボリンジャー(1分・直前価格) ±2σ 逆張り': sg(X.m1_bbpL <= -1, X.m1_bbpL >= 1),
 'ボリンジャー(5分) ±2σ 逆張り': sg(X.m5_bbp <= -1, X.m5_bbp >= 1),
 'ボリンジャー(15分) ±2σ 逆張り': sg(X.m15_bbp <= -1, X.m15_bbp >= 1),
 'MACD(1分) ゴールデンクロス買い/デッドクロス売り': sg(X.m1_macdx == 2, X.m1_macdx == -2),
 'MACD(5分) クロス 順張り': sg(X.m5_macdx == 2, X.m5_macdx == -2),
 'MACD(15分) クロス 順張り': sg(X.m15_macdx == 2, X.m15_macdx == -2),
 'EMA20/50(5分) 上なら買い/下なら売り': sg(X.m5_x2050 > 0, X.m5_x2050 < 0),
 'EMA20/50(15分) 順張り': sg(X.m15_x2050 > 0, X.m15_x2050 < 0),
 '一目(15分) 雲の上で買い/下で売り': sg(X.m15_ichi_cloud > 0, X.m15_ichi_cloud < 0),
 '一目(5分) 転換線>基準線で買い': sg(X.m5_ichi_tk > 0, X.m5_ichi_tk < 0),
 'パラボリック(1分) 転換に順張り': sg(X.m1_psar_flip > 0, X.m1_psar_flip < 0),
 'パラボリック(5分) 転換に順張り': sg(X.m5_psar_flip > 0, X.m5_psar_flip < 0),
 'ADX(5分)25以上でDIの向きに順張り': sg((X.m5_adx >= 25) & (X.m5_dis > 0), (X.m5_adx >= 25) & (X.m5_dis < 0)),
 '包み足(1分) の向き': sg(X.m1_engulf > 0, X.m1_engulf < 0),
 '包み足(5分) の向き': sg(X.m5_engulf > 0, X.m5_engulf < 0),
 'ピンバー(1分) 下ヒゲで買い/上ヒゲで売り': sg(X.m1_pin > 0, X.m1_pin < 0),
 'ピンバー(5分) 同上': sg(X.m5_pin > 0, X.m5_pin < 0),
 '赤三兵/黒三兵(1分) 順張り': sg(X.m1_soldiers > 0, X.m1_soldiers < 0),
 '赤三兵/黒三兵(5分) 順張り': sg(X.m5_soldiers > 0, X.m5_soldiers < 0),
 'RSIダイバージェンス(1分) 逆張り': sg(X.m1_div > 0, X.m1_div < 0),
 'RSIダイバージェンス(5分) 逆張り': sg(X.m5_div > 0, X.m5_div < 0),
 'ドンチャン20(5分) 高値更新で買い/安値更新で売り': sg(X.m5_don20 >= 0.98, X.m5_don20 <= -0.98),
 'ピボット S1付近で買い/R1付近で売り': sg(X.piv_s1.abs() <= 0.3, X.piv_r1.abs() <= 0.3),
 'ウィリアムズ%R(1分) -90以下買い/-10以上売り': sg(X.m1_willr <= -90, X.m1_willr >= -10),
 'CCI(1分) -200以下買い/+200以上売り': sg(X.m1_cci <= -200, X.m1_cci >= 200),
 'CCI(5分) ±200 逆張り': sg(X.m5_cci <= -200, X.m5_cci >= 200),
 '平均足(1分) 5本以上同じ色 順張り': sg(X.m1_ha_streak >= 5, X.m1_ha_streak <= -5),
 '平均足(5分) 5本以上 順張り': sg(X.m5_ha_streak >= 5, X.m5_ha_streak <= -5),
 '1分・5分・15分のEMA20の傾きが揃ったら順張り': sg((X.m1_ema20s > 0) & (X.m5_ema20s > 0) & (X.m15_ema20s > 0), (X.m1_ema20s < 0) & (X.m5_ema20s < 0) & (X.m15_ema20s < 0)),
 'RSI(1分)<30 かつ ボリンジャー-2σ割れ（両方）逆張り': sg((X.m1_rsi14 <= 30) & (X.m1_bbp <= -1), (X.m1_rsi14 >= 70) & (X.m1_bbp >= 1)),
 'RSI(5分)<30 かつ 15分の雲の上（押し目買い）': sg((X.m5_rsi14 <= 35) & (X.m15_ichi_cloud > 0), (X.m5_rsi14 >= 65) & (X.m15_ichi_cloud < 0)),
}
days = X.date.nunique(); rows = []
for name, d in R.items():
    m = d != 0
    for side, mult in (('教科書どおり', 1), ('逆', -1)):
        dd = d[m] * mult; y = X[m]
        win = (y.move3.values == dd).astype(float)
        per = {p: win[(y.period == p).values].mean() for p in ('P1', 'P2', 'P3')}
        rows.append(dict(rule=name, side=side, per_day=round(m.sum() / days, 1), n=int(m.sum()), win=round(win.mean() * 100, 2),
                         **{p: round(v * 100, 1) for p, v in per.items()}, all_periods_over_52_6=bool(min(per.values()) > 0.526),
                         draw=round((y.move3.values == 0).mean() * 100, 1)))
df = pd.DataFrame(rows).sort_values('win', ascending=False)
df.to_csv('../work/ta_rules_v0757.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print('base rate (any direction) draw', round((X.move3 == 0).mean() * 100, 2), 'slots x pairs', len(X))
print(df.to_string(index=False))

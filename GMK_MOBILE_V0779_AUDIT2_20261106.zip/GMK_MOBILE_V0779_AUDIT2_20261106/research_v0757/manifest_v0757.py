import hashlib, json
from pathlib import Path
A = Path('v0756/GMK_MOBILE_V0756_ENTRY_SIXTY_20261031'); B = Path('v0757/GMK_MOBILE_V0757_FIVE_MINUTE_20261101')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
mod = ['app/build.gradle.kts', '.github/workflows/build.yml', D + 'MainActivity.kt', D + 'MarketScreens.kt', D + 'domain/EntryMode.kt',
       D + 'domain/EventRules.kt', D + 'domain/EvidenceModel.kt', D + 'domain/EvidencePolicy.kt', D + 'domain/RankStatistics.kt',
       D + 'domain/SignalAlerts.kt', D + 'ui/GmkViewModel.kt',
       'app/src/test/java/AuditFixV0750Test.kt', 'app/src/test/java/ConfirmedRanksV0752Test.kt', 'app/src/test/java/EntrySixtyV0756Test.kt',
       'app/src/test/java/EvidencePolicyTest.kt', 'app/src/test/java/FiftyFiveV0755Test.kt', 'app/src/test/java/LossPatternsV0754Test.kt',
       'app/src/test/java/MoreRulesV0753Test.kt', 'app/src/test/java/SessionRanksV0751Test.kt', 'tools/build_release.py']
for p in mod: assert sha(A / p) != sha(B / p), p
new = [D + 'domain/EvidenceModel5Data.kt', 'app/src/test/java/FiveMinuteV0757Test.kt', 'app/src/test/resources/v0757_model5_parity.txt.gz']
V = json.load(open('work/model5_v0757.json'))
m = {'schema': 1, 'source_baseline_zip': 'GMK_MOBILE_V0756_ENTRY_SIXTY_20261031.zip',
     'change': 'v0.7.57 five-minute: weekday FX only; time-of-day rules S/A judged at 3 minutes; B (3-minute model strong + confirmed FX trade) '
               'and C/D (a 5-minute ensemble with the same 46 inputs, C at or above the hour cut so every hour enters about 60%) judged at 5 minutes. '
               'Weekend unchanged. Judgement length shown as a badge (TOP1, scan list, history), in labels, notes (HZ=) and notification titles. '
               'Version 0.7.57-five-minute (127).',
     'modified_existing': {p: {'v0756_sha256': sha(A / p), 'updated_sha256': sha(B / p)} for p in mod},
     'new_source_files': {p: sha(B / p) for p in new},
     'validation': V}
(B / 'tools/v0757_source_extension.json').write_text(json.dumps(m, ensure_ascii=False, indent=1, default=float) + '\n')
print('ok')

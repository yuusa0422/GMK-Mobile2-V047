"""5-minute outcome for every (slot, instrument) row of policy_data: sign(open(B+300) - open(B)), same price source as move3."""
import pandas as pd, numpy as np
P = pd.read_pickle('../work/policy_data.pkl')[['b', 'inst', 'move3']]
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
out = []
for s, path in SRC.items():
    B = pd.read_csv(path); B['m'] = B.epoch_ms // 60000; o = B.drop_duplicates('m').set_index('m').open
    x = P[P.inst == s].copy(); m0 = x.b // 60
    o0 = o.reindex(m0).values; o3 = o.reindex(m0 + 3).values; o5 = o.reindex(m0 + 5).values
    x['m3chk'] = np.sign(o3 - o0); x['move5'] = np.sign(o5 - o0); x['ok5'] = ~np.isnan(o5)
    out.append(x)
X = pd.concat(out)
print('move3 reproduced', round((X.m3chk == X.move3).mean() * 100, 2), '% ; 5-min available', round(X.ok5.mean() * 100, 2), '%')
print('draw rate 3m', round((X.move3 == 0).mean() * 100, 2), '5m', round((X.move5 == 0).mean() * 100, 2))
X[['b', 'inst', 'move5', 'ok5']].to_pickle('../work/move5_v0757.pkl')

"""Common weekday evaluation for v0.7.57: every hour enters at least 60% of its slots.
S/A (time-of-day rules) and B (confirmed strong trade) are always entered; the rest of each hour's quota is filled with the
highest scores, the cut being the quantile of the score on the training periods (per hour). Train two periods, score the third."""
import pandas as pd, numpy as np
FIXED = ('S', 'A', 'B')
def per_hour(X, score='s', cov=0.6, fixed_col='g56', trade_win='win', trade_tie='tie'):
    """X: one row per weekday slot with hour, period, g56, score column and the win/tie of the trade that would be entered."""
    out = []
    for te in ('P1', 'P2', 'P3'):
        A = X[X.period != te]; B = X[X.period == te]
        need = {}
        for h, a in A.groupby('hour'):
            fx = a[fixed_col].isin(FIXED).mean(); rest = a[~a[fixed_col].isin(FIXED)]
            share = min(1.0, max(0.0, (cov - fx) / max(1 - fx, 1e-9)))
            need[h] = rest[score].quantile(1 - share) if share > 0 else np.inf
        b = B.copy(); cut = b.hour.map(need)
        b['enter'] = b[fixed_col].isin(FIXED) | (b[score] >= cut)
        out.append(b)
    Y = pd.concat(out); E = Y[Y.enter]
    hc = Y.groupby('hour').enter.mean()
    return dict(cover=round(Y.enter.mean() * 100, 1), min_hour=round(hc.min() * 100, 1), win=round(E[trade_win].mean() * 100, 2),
                P1=round(E[E.period == 'P1'][trade_win].mean() * 100, 1), P2=round(E[E.period == 'P2'][trade_win].mean() * 100, 1),
                P3=round(E[E.period == 'P3'][trade_win].mean() * 100, 1), draw=round(E[trade_tie].mean() * 100, 1), n=int(len(E)),
                rest_win=round(E[~E[fixed_col].isin(FIXED)][trade_win].mean() * 100, 2))
if __name__ == '__main__':
    L = pd.read_pickle('../work/ladder_v0756.pkl'); W = L[L.weekday].copy()
    print('ladder R  ', per_hour(W, 'R')); print('ladder E  ', per_hour(W, 'E')); print('ladder p  ', per_hour(W, 'p'))

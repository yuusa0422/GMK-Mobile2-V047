import pandas as pd, numpy as np
FIXED = ('S', 'A', 'B')
def per_hour_rank(X, score, cov=0.6, fixed_col='gfix', trade_win='win', trade_tie='tie'):
    """Every (period, hour): fixed tiers + the best-scored rest slots until 60% (ranking inside the period, like a rolling rank)."""
    X = X.copy(); X['fix'] = X[fixed_col].isin(FIXED)
    X['rk'] = X[~X.fix].groupby(['period', 'hour'])[score].rank(ascending=False, method='first')
    n = X.groupby(['period', 'hour']).b.transform('size'); nf = X.groupby(['period', 'hour']).fix.transform('sum')
    X['enter'] = X.fix | (X.rk <= np.ceil(cov * n) - nf)
    E = X[X.enter]
    return dict(cover=round(X.enter.mean() * 100, 1), min_hour=round(X.groupby(['period', 'hour']).enter.mean().min() * 100, 1),
                win=round(E[trade_win].mean() * 100, 2), **{p: round(E[E.period == p][trade_win].mean() * 100, 1) for p in ('P1', 'P2', 'P3')},
                draw=round(E[trade_tie].mean() * 100, 1), rest_win=round(E[~E.fix][trade_win].mean() * 100, 2))

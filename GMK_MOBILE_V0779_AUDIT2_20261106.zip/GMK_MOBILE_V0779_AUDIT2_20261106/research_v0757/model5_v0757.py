"""v0.7.57 5-minute model: production config of the v0.7.46 ensemble (5 seeds, 150 iterations, 7 leaves, min leaf 2000),
same design as the app (EvidenceFeatures.design), target = 5-minute WIN (DRAW = LOSE), weekday rows of all six instruments.
1) validation by period rotation (FX-only policy: S/A rules 3 min, B 5 min, rest by the 5-minute model, every hour 60%)
2) production ensembles (fresh/fallback), exported texts verified, per-hour cuts, grade rates, Kotlin parity rows."""
import pandas as pd, numpy as np, pickle, json, time, sys
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
exec(open('model_export_lib.py').read()); NFEAT = 46
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
M5 = pd.read_pickle('../work/move5_v0757.pkl')[['b', 'inst', 'move5']]
P = P.merge(M5, on=['b', 'inst'], how='left'); P = P[P.weekday].reset_index(drop=True)
P['period'] = np.where(P.date.astype(str) < '2026-02-01', 'P1', np.where(P.date.astype(str) < '2026-06-01', 'P2', 'P3'))
FX = P.inst != 'BTCJPY'
def fitp(A, fresh, seeds):
    X = np.vstack([design(A, 1, fresh)[0], design(A, -1, fresh)[0]]); y = np.r_[(A.move5.values == 1), (A.move5.values == -1)].astype(int)
    return [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in seeds]
def pred(ms, df, fresh):
    return (np.mean([m.predict_proba(design(df, 1, fresh)[0])[:, 1] for m in ms], 0), np.mean([m.predict_proba(design(df, -1, fresh)[0])[:, 1] for m in ms], 0))
L = pd.read_pickle('../work/ladder_v0756.pkl'); Wd = L[L.weekday][['b', 'g56', 'inst', 'win', 'tie']].rename(columns={'inst': 'linst'})
Wd = Wd.merge(pd.read_pickle('../work/ladder_at5_v0757.pkl')[['b', 'win5', 'tie5']], on='b', how='left')
fixed_sa = Wd.g56.isin(['S', 'A']) & (Wd.linst != 'BTCJPY'); fixed_b = (Wd.g56 == 'B') & (Wd.linst != 'BTCJPY')
Wd['fix'] = np.where(fixed_sa, Wd.g56, np.where(fixed_b, 'B', ''))
out = {}
# ---------------- 1) validation ----------------
for fresh in (True, False):
    parts = []
    for te in ('P1', 'P2', 'P3'):
        t0 = time.time(); ms = fitp(P[P.period != te], fresh, range(5)); B = P[(P.period == te) & FX]
        pu, pdn = pred(ms, B, fresh); t = B[['b', 'inst', 'hour', 'period', 'move5']].copy(); t['pu'] = pu; t['pd'] = pdn; parts.append(t)
        print('validation', 'fresh' if fresh else 'fallback', te, round(time.time() - t0), 's', flush=True)
    C = pd.concat(parts); C['p'] = np.maximum(C.pu, C.pd); C['dir'] = np.where(C.pu >= C.pd, 1, -1)
    best = C.sort_values('p', ascending=False).groupby('b').head(1)
    X = Wd.merge(best, on='b', how='inner')
    X['nwin'] = (X.move5 == X.dir).astype(int); X['ntie'] = (X.move5 == 0).astype(int)
    X['twin'] = np.where(X.fix.isin(['S', 'A']), X.win, np.where(X.fix == 'B', X.win5, X.nwin))
    X['ttie'] = np.where(X.fix.isin(['S', 'A']), X.tie, np.where(X.fix == 'B', X.tie5, X.ntie))
    X['isfix'] = X.fix != ''
    X['rk'] = X[~X.isfix].groupby(['period', 'hour']).p.rank(ascending=False, method='first')
    n = X.groupby(['period', 'hour']).b.transform('size'); nf = X.groupby(['period', 'hour']).isfix.transform('sum')
    quota = np.ceil(0.6 * n) - nf
    X['grade'] = np.where(X.fix != '', X.fix, np.where(X.rk <= quota, 'C', np.where(X.rk <= quota + (n - nf - quota) / 2, 'D', 'E')))
    E = X[X.grade.isin(['S', 'A', 'B', 'C'])]
    r = dict(cover=round(len(E) / len(X) * 100, 1), win=round(E.twin.mean() * 100, 2), **{p: round(E[E.period == p].twin.mean() * 100, 1) for p in ('P1', 'P2', 'P3')},
             draw=round(E.ttie.mean() * 100, 2), min_hour=round(X.assign(e=X.grade.isin(['S', 'A', 'B', 'C'])).groupby(['period', 'hour']).e.mean().min() * 100, 1),
             per_day=round(len(E) / X.b.map(lambda b: b // 86400).nunique(), 1),
             grades={g: dict(n=int(len(x)), win=round(x.twin.mean(), 4), oct=round(x[x.b >= 1790780400].twin.mean(), 4) if (x.b >= 1790780400).any() else None,
                             oct_n=int((x.b >= 1790780400).sum()), **{p: round(x[x.period == p].twin.mean() * 100, 1) for p in ('P1', 'P2', 'P3')})
                     for g, x in X.groupby('grade')},
             hours={int(h): round(x.grade.isin(['S', 'A', 'B', 'C']).mean() * 100, 1) for h, x in X.groupby('hour')},
             s55=dict(n=int(X.grade.isin(['S', 'A', 'B']).sum()), win=round(X[X.grade.isin(['S', 'A', 'B'])].twin.mean() * 100, 2)))
    out['validation_' + ('fresh' if fresh else 'fallback')] = r
    print(('fresh' if fresh else 'fallback'), json.dumps({k: v for k, v in r.items() if k not in ('grades', 'hours')}), flush=True)
    print('  grades', {g: (v['n'], v['win']) for g, v in r['grades'].items()}, flush=True)
json.dump(out, open('../work/model5_v0757.json', 'w'), indent=1, default=float)
# ---------------- 2) production ----------------
prod = {'models': {}, 'texts': {}, 'cuts': {}, 'cuts_de': {}}
for fresh in (True, False):
    t0 = time.time(); ms = fitp(P, fresh, range(5)); texts = [export(m) for m in ms]
    Xs = design(P.sample(1500, random_state=7), 1, fresh)[0]
    for m, tx in zip(ms, texts):
        d = np.abs(eval_text(tx, Xs) - m.predict_proba(Xs)[:, 1]).max(); assert d < 1e-12, d
        assert len(tx) < 60000, len(tx)
    k = 'fresh' if fresh else 'fallback'; prod['texts'][k] = texts; prod['models'][k] = ms
    F = P[FX]; pu, pdn = pred(ms, F, fresh); t = F[['b', 'hour']].copy(); t['p'] = np.maximum(pu, pdn)
    best = t.sort_values('p', ascending=False).groupby('b').head(1).merge(Wd[['b', 'fix']], on='b', how='inner')
    cuts = []; cuts_de = []
    for h in range(9, 23):
        x = best[best.hour == h]; fx_share = (x.fix != '').mean(); rest = x[x.fix == '']
        share = (0.6 - fx_share) / (1 - fx_share)
        c = float(rest.p.quantile(1 - share)); cuts.append(c)
        cuts_de.append(float(rest[rest.p < c].p.quantile(0.5)))
    prod['cuts'][k] = cuts; prod['cuts_de'][k] = cuts_de
    chk = best.assign(cut=best.hour.map(dict(zip(range(9, 23), cuts))))
    cov = ((chk.fix != '') | (chk.p >= chk.cut)).groupby(chk.hour).mean()
    print('production', k, round(time.time() - t0), 's; coverage by hour', cov.round(3).to_dict(), flush=True)
    # parity rows: design rows for both directions of random weekday candidates
    S = P.sample(150, random_state=11 if fresh else 12)
    rows = []
    for d in (1, -1):
        Xd = design(S, d, fresh)[0]; pp = np.mean([m.predict_proba(Xd)[:, 1] for m in ms], 0)
        rows += [(k, float(p_), ','.join(repr(float(v)) for v in xr)) for p_, xr in zip(pp, Xd)]
    prod.setdefault('parity', []).extend(rows)
_, names = design(P.head(2), 1, True); prod['features'] = names; prod['cfg'] = CFG
pickle.dump({k: v for k, v in prod.items() if k != 'models'}, open('../work/production_model5_v0757.pkl', 'wb'))
print('features', len(names), 'cuts fresh', [round(c, 4) for c in prod['cuts']['fresh']])

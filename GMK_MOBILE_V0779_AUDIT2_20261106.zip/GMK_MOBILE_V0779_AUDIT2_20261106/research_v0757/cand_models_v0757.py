"""v0.7.57 weekday candidate models (6 instruments x 2 directions), period rotation; saves out-of-period pu/pd per candidate."""
import pandas as pd, numpy as np, time, sys
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def design(')[0])
H = pd.read_pickle('../work/hyp_fresh.pkl')
EX = ['rv240', 'ac1', 'vr5', 'n120', 'n240', 'r50_dist', 'r100_dist', 'r50_cross', 'r100_cross', 'yen30', 'idio30', 'idio1L', 'idio5L', 'idio15L', 'yen1L', 'minute', 'dow']
P = P.merge(H[['b', 'inst'] + EX].rename(columns={'idio5L': 'idio5L_h'}), on=['b', 'inst'], how='left')
C = pd.read_pickle('../work/context_v0757.pkl')
import os
TARGET = os.environ.get('TARGET', 'move3'); WEEKEND = os.environ.get('WEEKEND') == '1'
if TARGET != 'move3':
    M = pd.read_pickle('../work/move5_v0757.pkl')[['b', 'inst', 'move5']]
    P = P.merge(M, on=['b', 'inst'], how='left'); P['move3'] = P[TARGET]          # the model's target and the scored outcome
P = (P[~P.weekday] if WEEKEND else P[P.weekday]).merge(C, on=['b', 'inst'], how='left')
TA = pd.read_pickle('../work/ta_v0757.pkl')
for p_ in ('m1_', 'm5_', 'm15_'):
    for k in ('rsi7', 'rsi14', 'rsi21', 'stk', 'std'):
        if p_ + k in TA: TA[p_ + k] = (TA[p_ + k] - 50) / 50
    TA[p_ + 'willr'] = (TA[p_ + 'willr'] + 50) / 50
for k in ('m1_rsi14L', 'm1_stkL'): TA[k] = (TA[k] - 50) / 50
TA['m1_willrL'] = (TA['m1_willrL'] + 50) / 50
TA_UNSIGNED = [c for c in TA.columns if any(c.endswith(x) for x in ('bbw', 'adx', 'atrn', 'doji', 'inside'))]
TA_SIGNED = [c for c in TA.columns if c not in TA_UNSIGNED + ['b', 'inst']]
P = P.merge(TA, on=['b', 'inst'], how='left')
P['period'] = np.where(P.date.astype(str) < '2026-02-01', 'P1', np.where(P.date.astype(str) < '2026-06-01', 'P2', 'P3'))
P['mod'] = (P.hour * 60 + P.minute).astype(float); P['ms'] = np.sin(2 * np.pi * P['mod'] / 1440); P['mc'] = np.cos(2 * np.pi * P['mod'] / 1440)
SIGNED_X = ['n120', 'n240', 'yen30', 'idio30', 'idio1L', 'idio5L_h', 'idio15L', 'yen1L', 'r50_dist', 'r100_dist']
UNSIGNED_X = ['rv240', 'ac1', 'vr5', 'r50_cross', 'r100_cross', 'minute', 'dow', 'ms', 'mc']
SIGNED_C = ['c_dopen', 'c_twap', 'c_dpos', 'c_pdpos', 'c_pdc', 'c_n480', 'c_n1440', 'x_rank_n1L', 'x_rank_n5', 'x_rank_n15', 'x_rank_n60']
UNSIGNED_C = ['c_drng', 'c_volx', 'c_pdh', 'c_pdl', 'x_disp_n1L', 'x_disp_n5', 'x_disp_n15', 'x_disp_n60', 'to_nycut', 'gotobi', 'month_end',
              'm00', 'm30', 'm55', 'dom'] + [c for c in C.columns if c.startswith('ev_')]
def design(df, d, level):
    cols = {}
    for c in SIGNED + SIGNED_FRESH: cols[c] = df[c].values * d
    for c in UNSIGNED: cols[c] = df[c].values.astype(float)
    for s in INST: cols['is_' + s] = (df.inst.values == s).astype(float)
    for r in REG: cols['rg_' + r] = (df.regime.values == r).astype(float)
    cols['dir'] = np.full(len(df), float(d))
    if level >= 1:
        for c in SIGNED_X: cols[c] = df[c].values.astype(float) * d
        for c in UNSIGNED_X: cols[c] = df[c].values.astype(float)
        for s in INST: cols['dirx_' + s] = (df.inst.values == s) * float(d)
    if level in (2, 4):
        for c in SIGNED_C: cols[c] = df[c].values.astype(float) * d
        for c in UNSIGNED_C: cols[c] = df[c].values.astype(float)
    if level in (3, 4):
        for c in TA_SIGNED: cols[c] = df[c].values.astype(float) * d
        for c in TA_UNSIGNED: cols[c] = df[c].values.astype(float)
    if level == 5:      # compact technical set: the classic indicators that scored best one by one
        for c in ('m1_rsi14L', 'm1_bbpL', 'm1_cci', 'm5_rsi14', 'm5_bbp', 'm15_ichi_cloud', 'm5_x2050', 'm5_macdh', 'm5_div'): cols[c] = df[c].values.astype(float) * d
        for c in ('m5_adx', 'm1_bbw'): cols[c] = df[c].values.astype(float)
    return np.column_stack([cols[k] for k in cols])
CFG = dict(max_iter=300, learning_rate=0.04, max_leaf_nodes=15, min_samples_leaf=1500, l2_regularization=1.0)
levels = [int(x) for x in sys.argv[1:]] or [0, 1, 2]
for level in levels:
    parts = []
    for te in ('P1', 'P2', 'P3'):
        t0 = time.time(); A = P[P.period != te]; B = P[P.period == te]
        X = np.vstack([design(A, 1, level), design(A, -1, level)]); y = np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int)
        ms_ = [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in range(3)]
        t = B[['b', 'inst', 'hour', 'move3', 'date', 'period']].copy()
        t['pu'] = np.mean([m.predict_proba(design(B, 1, level))[:, 1] for m in ms_], 0)
        t['pd'] = np.mean([m.predict_proba(design(B, -1, level))[:, 1] for m in ms_], 0)
        parts.append(t); print('level', level, te, round(time.time() - t0), 's', flush=True)
    tag = ('we' if WEEKEND else 'wd') + ('' if TARGET == 'move3' else '_' + TARGET)
    pd.concat(parts).to_pickle(f'../work/cand_{tag}_level{level}.pkl')

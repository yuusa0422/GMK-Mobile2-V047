"""v0.7.57 research: day/session/calendar/cross-section context for every (slot, instrument), causal at decision time.
Completed bars: up to the bar opening at B-120; live proxy: close of the bar opening at B-60 (= price at B), as in hyp_features.py."""
import gzip, csv, numpy as np, pandas as pd, datetime as dt
from zoneinfo import ZoneInfo
JST = ZoneInfo('Asia/Tokyo'); NY = ZoneInfo('America/New_York'); LON = ZoneInfo('Europe/London'); CET = ZoneInfo('Europe/Berlin')
INST = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', **{s: f'../hist/combined/{s}_1m.csv.gz' for s in INST[1:]}}
T0 = int(dt.datetime(2025, 9, 29, tzinfo=JST).timestamp()) // 60
T1 = int(dt.datetime(2026, 10, 22, tzinfo=JST).timestamp()) // 60
N = T1 - T0
mins = np.arange(N) + T0
tj = pd.to_datetime(mins * 60, unit='s', utc=True).tz_convert(JST)
dkey = ((mins * 60 + 9 * 3600 - 7 * 3600) // 86400).astype(np.int64)      # trading day starting 07:00 JST
def load(path):
    o = np.full(N, np.nan); h = o.copy(); l = o.copy(); c = o.copy()
    with gzip.open(path, 'rt') as f:
        for r in csv.DictReader(f):
            m = int(r['epoch_ms']) // 60000 - T0
            if 0 <= m < N: o[m] = float(r['open']); h[m] = float(r['high']); l[m] = float(r['low']); c[m] = float(r['close'])
    return o, h, l, c
A = {}
for s, p in SRC.items():
    o, h, l, c = load(p)
    df = pd.DataFrame({'o': o, 'h': h, 'l': l, 'c': c, 'd': dkey})
    df['cf'] = df.c.ffill(); df['lc'] = np.log(df.cf)
    r1 = df.lc.diff()
    df['rv60'] = r1.rolling(60, min_periods=45).std(); df['rv1440'] = r1.rolling(1440, min_periods=600).std()
    g = df.groupby('d')
    df['dopen'] = g.o.transform(lambda x: x.dropna().iloc[0] if x.notna().any() else np.nan)
    df['dhi'] = g.h.cummax(); df['dlo'] = g.l.cummin()
    df['twap'] = g.cf.cumsum() / (g.cf.cumcount() + 1)
    day_hi = g.h.max(); day_lo = g.l.min(); day_cl = g.cf.last()
    df['pdh'] = df.d.map(day_hi.shift(1)); df['pdl'] = df.d.map(day_lo.shift(1)); df['pdc'] = df.d.map(day_cl.shift(1))
    for k in (480, 1440): df[f'lc{k}'] = df.lc.shift(k)
    A[s] = df
    print(s, 'loaded', flush=True)
def at(ts, zone, hh, mm):
    """epoch seconds of hh:mm local (zone) on the local date of ts"""
    l = ts.astimezone(zone); return int(dt.datetime(l.year, l.month, l.day, hh, mm, tzinfo=zone).timestamp())
EVENTS = [(NY, 8, 30, 'ev_ny830'), (NY, 10, 0, 'ev_ny1000'), (LON, 7, 0, 'ev_lon700'), (LON, 9, 30, 'ev_lon930'), (CET, 10, 0, 'ev_cet1000'),
          (JST, 8, 50, 'ev_jp850'), (JST, 10, 30, 'ev_cn1030'), (LON, 8, 0, 'ev_lonopen'), (NY, 9, 30, 'ev_nyopen')]
rows = []
day = dt.date(2025, 10, 1)
while day <= dt.date(2026, 10, 21):
    if day.weekday() < 5:
        nxt = day + dt.timedelta(days=1)
        last_wd_of_month = all((day + dt.timedelta(days=k)).month != day.month or (day + dt.timedelta(days=k)).weekday() >= 5 for k in range(1, 4)) and \
            (day + dt.timedelta(days=1)).month != day.month or (day.weekday() == 4 and (day + dt.timedelta(days=3)).month != day.month)
        gotobi = day.day % 5 == 0 or last_wd_of_month
        for hh in range(9, 23):
            for mm in range(0, 60, 5):
                ts = dt.datetime(day.year, day.month, day.day, hh, mm, tzinfo=JST); B = int(ts.timestamp())
                bm = B // 60 - T0; t = bm - 2; tl = bm - 1
                if t < 1500 or bm + 3 >= N: continue
                base = dict(b=B)
                for z, eh, em, nm in EVENTS:
                    e = at(ts, z, eh, em); base[nm] = (B - e) / 60.0          # minutes since the event time today (negative = before)
                nycut = at(ts, NY, 10, 0); base['to_nycut'] = (nycut - B) / 60.0
                base['gotobi'] = float(gotobi); base['month_end'] = float(last_wd_of_month)
                base['m_of_h'] = float(mm); base['m00'] = float(mm == 0); base['m30'] = float(mm == 30); base['m55'] = float(mm == 55)
                base['dom'] = float(day.day)
                for s, df in A.items():
                    r = df.iloc[t]; live = df.cf.iat[tl]
                    if np.isnan(r.cf) or np.isnan(live) or not (r.rv60 > 0): continue
                    sig_h = r.rv60 * np.sqrt(60)
                    rec = dict(base, inst=s)
                    L = np.log(live)
                    rec['c_dopen'] = (L - np.log(r.dopen)) / sig_h if r.dopen > 0 else np.nan
                    rec['c_twap'] = (L - np.log(r.twap)) / sig_h
                    rng = r.dhi - r.dlo
                    rec['c_dpos'] = (live - r.dlo) / rng * 2 - 1 if rng > 0 else 0.0
                    rec['c_drng'] = np.log(rng / live / sig_h) if rng > 0 else np.nan
                    prng = r.pdh - r.pdl
                    rec['c_pdpos'] = (live - r.pdl) / prng * 2 - 1 if prng > 0 else np.nan
                    rec['c_pdh'] = (np.log(r.pdh) - L) / sig_h; rec['c_pdl'] = (L - np.log(r.pdl)) / sig_h
                    rec['c_pdc'] = (L - np.log(r.pdc)) / sig_h
                    rec['c_n480'] = (r.lc - r.lc480) / (r.rv60 * np.sqrt(480)); rec['c_n1440'] = (r.lc - r.lc1440) / (r.rv60 * np.sqrt(1440))
                    rec['c_volx'] = np.log(r.rv60 / r.rv1440) if r.rv1440 > 0 else np.nan
                    rows.append(rec)
    day += dt.timedelta(days=1)
    if day.day == 1: print(day, len(rows), flush=True)
D = pd.DataFrame(rows)
# cross-section among the 5 FX: rank of the instrument's recent moves (-1..1) and dispersion, from hyp_features n5/n15/n60
H = pd.read_pickle('../work/hyp_fresh.pkl')[['b', 'inst', 'n5', 'n15', 'n60', 'n1L']]
D = D.merge(H, on=['b', 'inst'], how='left')
fx = D.inst != 'BTCJPY'
for k in ('n1L', 'n5', 'n15', 'n60'):
    rk = D[fx].groupby('b')[k].rank(pct=True) * 2 - 1
    D.loc[fx, f'x_rank_{k}'] = rk
    D.loc[fx, f'x_disp_{k}'] = D[fx].groupby('b')[k].transform('std')
D = D.drop(columns=['n5', 'n15', 'n60', 'n1L'])
D.to_pickle('../work/context_v0757.pkl'); print(D.shape)

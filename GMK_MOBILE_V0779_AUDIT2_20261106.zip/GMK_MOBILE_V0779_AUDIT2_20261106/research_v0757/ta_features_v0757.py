"""v0.7.57 technical-analysis battery for every weekday (slot, FX instrument), causal at decision time.
1m indicators on completed bars up to the bar opening at B-120 (index t); 'live' 1m indicators at t+1 (the research live price at B);
5m bars end at t (bins of 5 minutes whose last minute is t); 15m bars end at t (3 alignments). Classic definitions."""
import gzip, csv, numpy as np, pandas as pd, datetime as dt
from zoneinfo import ZoneInfo
JST = ZoneInfo('Asia/Tokyo')
FX = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', **{s: f'../hist/combined/{s}_1m.csv.gz' for s in FX[1:]}}
T0 = int(dt.datetime(2025, 9, 1, tzinfo=JST).timestamp()) // 60
T1 = int(dt.datetime(2026, 10, 22, tzinfo=JST).timestamp()) // 60
N = T1 - T0
P = pd.read_pickle('../work/policy_data.pkl'); P = P[P.weekday & P.inst.isin(FX)][['b', 'inst']]

def load(path):
    o = np.full(N, np.nan); h = o.copy(); l = o.copy(); c = o.copy()
    with gzip.open(path, 'rt') as f:
        for r in csv.DictReader(f):
            m = int(r['epoch_ms']) // 60000 - T0
            if 0 <= m < N: o[m] = float(r['open']); h[m] = float(r['high']); l[m] = float(r['low']); c[m] = float(r['close'])
    return pd.DataFrame({'o': o, 'h': h, 'l': l, 'c': c})

def ema(x, n): return x.ewm(span=n, adjust=False, min_periods=n).mean()
def rsi(c, n):
    d = c.diff(); up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False, min_periods=n).mean(); dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))
def atr(df, n):
    pc = df.c.shift(); tr = pd.concat([df.h - df.l, (df.h - pc).abs(), (df.l - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
def psar(df, step=0.02, mx=0.2):
    h, l = df.h.values, df.l.values; n = len(h); out = np.full(n, np.nan); trend = np.zeros(n)
    i0 = np.argmax(~np.isnan(h)); up = True; sar = l[i0]; ep = h[i0]; af = step
    for i in range(i0 + 1, n):
        if np.isnan(h[i]): out[i] = out[i - 1]; trend[i] = trend[i - 1]; continue
        sar = sar + af * (ep - sar)
        if up:
            if l[i] < sar: up = False; sar = ep; ep = l[i]; af = step
            elif h[i] > ep: ep = h[i]; af = min(af + step, mx)
        else:
            if h[i] > sar: up = True; sar = ep; ep = h[i]; af = step
            elif l[i] < ep: ep = l[i]; af = min(af + step, mx)
        out[i] = sar; trend[i] = 1 if up else -1
    return pd.Series(trend, index=df.index), pd.Series(out, index=df.index)

def indicators(df, p):
    """df: OHLC bars (forward-filled closes); returns DataFrame of indicators with prefix p."""
    c, h, l, o = df.c, df.h, df.l, df.o
    a14 = atr(df, 14); out = {}
    for n in (7, 14, 21): out[f'rsi{n}'] = rsi(c, n)
    ll14 = l.rolling(14).min(); hh14 = h.rolling(14).max(); k = 100 * (c - ll14) / (hh14 - ll14).replace(0, np.nan); d = k.rolling(3).mean()
    out['stk'] = k; out['std'] = d; out['stx'] = np.sign(k - d) - np.sign(k.shift() - d.shift())     # +2 = K crossed above D
    m = ema(c, 12) - ema(c, 26); s = ema(m, 9); out['macdh'] = (m - s) / a14; out['macd'] = m / a14
    out['macdx'] = np.sign(m - s) - np.sign((m - s).shift())
    ma20 = c.rolling(20).mean(); sd20 = c.rolling(20).std()
    out['bbp'] = (c - ma20) / (2 * sd20).replace(0, np.nan); out['bbw'] = np.log((4 * sd20 / c).replace(0, np.nan))
    for n in (5, 20, 50, 100, 200): out[f'ema{n}d'] = (c - ema(c, n)) / a14
    for n in (20, 50): out[f'ema{n}s'] = (ema(c, n) - ema(c, n).shift(3)) / a14
    out['x2050'] = np.sign(ema(c, 20) - ema(c, 50))
    # ADX / DI
    upm = h.diff(); dnm = -l.diff()
    pdm = np.where((upm > dnm) & (upm > 0), upm, 0.0); ndm = np.where((dnm > upm) & (dnm > 0), dnm, 0.0)
    pdi = 100 * pd.Series(pdm, index=df.index).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean() / a14
    ndi = 100 * pd.Series(ndm, index=df.index).ewm(alpha=1 / 14, adjust=False, min_periods=14).mean() / a14
    dx = 100 * (pdi - ndi).abs() / (pdi + ndi).replace(0, np.nan); out['adx'] = dx.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean(); out['dis'] = (pdi - ndi) / (pdi + ndi).replace(0, np.nan)
    tp = (h + l + c) / 3; out['cci'] = (tp - tp.rolling(20).mean()) / (0.015 * tp.rolling(20).apply(lambda x: np.mean(np.abs(x - x.mean())), raw=True)).replace(0, np.nan) if p == 'm5_' else (tp - tp.rolling(20).mean()) / (0.015 * (tp - tp.rolling(20).mean()).abs().rolling(20).mean()).replace(0, np.nan)
    out['willr'] = -100 * (hh14 - c) / (hh14 - ll14).replace(0, np.nan)
    out['roc10'] = (c / c.shift(10) - 1) / (a14 / c)
    out['atrn'] = np.log(a14 / c)
    for n in (20, 55): out[f'don{n}'] = 2 * (c - l.rolling(n).min()) / (h.rolling(n).max() - l.rolling(n).min()).replace(0, np.nan) - 1
    out['kelt'] = (c - ema(c, 20)) / (2 * a14)
    # Ichimoku (tenkan 9, kijun 26, cloud shifted 26)
    tenkan = (h.rolling(9).max() + l.rolling(9).min()) / 2; kijun = (h.rolling(26).max() + l.rolling(26).min()) / 2
    sa = ((tenkan + kijun) / 2).shift(26); sb = ((h.rolling(52).max() + l.rolling(52).min()) / 2).shift(26)
    top = np.maximum(sa, sb); bot = np.minimum(sa, sb)
    out['ichi_cloud'] = np.where(c > top, 1.0, np.where(c < bot, -1.0, 0.0)); out['ichi_tk'] = (tenkan - kijun) / a14; out['ichi_kd'] = (c - kijun) / a14
    tr, sv = psar(df); out['psar'] = tr; out['psar_flip'] = tr - tr.shift(); out['psar_d'] = (c - sv) / a14
    # Heikin-Ashi colour streak
    hac = (o + h + l + c) / 4; hao = hac.copy(); hv = hac.values; ov = o.values; hov = np.full(len(hv), np.nan)
    for i in range(len(hv)):
        hov[i] = (ov[i] + hv[i]) / 2 if i == 0 or np.isnan(hov[i - 1]) else (hov[i - 1] + hv[i - 1]) / 2
    col = np.sign(hv - hov); st = np.zeros(len(col))
    for i in range(1, len(col)): st[i] = st[i - 1] + col[i] if col[i] == np.sign(st[i - 1]) or st[i - 1] == 0 else col[i]
    out['ha_streak'] = pd.Series(st, index=df.index).clip(-8, 8)
    # candles
    body = c - o; rng = (h - l).replace(0, np.nan); upw = h - np.maximum(o, c); low = np.minimum(o, c) - l
    out['engulf'] = np.where((body > 0) & (body.shift() < 0) & (c >= o.shift()) & (o <= c.shift()), 1.0, np.where((body < 0) & (body.shift() > 0) & (c <= o.shift()) & (o >= c.shift()), -1.0, 0.0))
    out['pin'] = np.where((low > 2 * body.abs()) & (low > upw * 2), 1.0, np.where((upw > 2 * body.abs()) & (upw > low * 2), -1.0, 0.0))
    out['doji'] = (body.abs() / rng < 0.1).astype(float)
    out['inside'] = ((h < h.shift()) & (l > l.shift())).astype(float)
    out['soldiers'] = np.where((body > 0) & (body.shift() > 0) & (body.shift(2) > 0), 1.0, np.where((body < 0) & (body.shift() < 0) & (body.shift(2) < 0), -1.0, 0.0))
    # RSI divergence over 14 bars: price at a new 14-bar extreme while RSI is not
    r = out['rsi14']
    out['div'] = np.where((c >= c.rolling(14).max()) & (r < r.rolling(14).max() - 5), -1.0, np.where((c <= c.rolling(14).min()) & (r > r.rolling(14).min() + 5), 1.0, 0.0))
    return pd.DataFrame({p + k: v for k, v in out.items()}, index=df.index)

def tf_bars(df, ids):
    g = pd.DataFrame({'o': df.o, 'h': df.h, 'l': df.l, 'c': df.c, 'id': ids})
    b = g.groupby('id').agg(o=('o', 'first'), h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
    b = b.dropna(how='all'); b['c'] = b.c.ffill(); b['o'] = b.o.fillna(b.c); b['h'] = b.h.fillna(b[['o', 'c']].max(axis=1)); b['l'] = b.l.fillna(b[['o', 'c']].min(axis=1))
    return b

out = []
for s in FX:
    df = load(SRC[s]); have = df.c.notna()
    df['c'] = df.c.ffill(); df['o'] = df.o.fillna(df.c); df['h'] = df.h.fillna(df[['o', 'c']].max(axis=1)); df['l'] = df.l.fillna(df[['o', 'c']].min(axis=1))
    bs = P[P.inst == s].b.values; bm = bs // 60 - T0; t = bm - 2
    I1 = indicators(df, 'm1_')
    rec = pd.DataFrame({'b': bs, 'inst': s})
    keep1 = [c for c in I1.columns]
    rec = pd.concat([rec, I1.iloc[t][keep1].reset_index(drop=True)], axis=1)
    live = I1.iloc[t + 1][['m1_rsi14', 'm1_bbp', 'm1_stk', 'm1_willr', 'm1_kelt', 'm1_ema20d', 'm1_macdh']].reset_index(drop=True)
    rec = pd.concat([rec, live.add_suffix('L')], axis=1)
    m = np.arange(N)
    I5 = indicators(tf_bars(df, (m + 1) // 5), 'm5_')
    rec = pd.concat([rec, I5.reindex((t + 1) // 5).reset_index(drop=True)], axis=1)
    parts = []
    for a in (3, 8, 13):
        I15 = indicators(tf_bars(df, (m + 14 - a) // 15), 'm15_'); parts.append((a, I15))
    v15 = pd.DataFrame(index=range(len(t)), columns=parts[0][1].columns, dtype=float)
    for a, I15 in parts:
        sel = np.where(t % 15 == a)[0]
        v15.iloc[sel] = I15.reindex((t[sel] + 14 - a) // 15).values
    rec = pd.concat([rec, v15], axis=1)
    # daily classic pivots from the previous JST trading day (07:00-07:00)
    day = (m + T0) * 60 + 9 * 3600 - 7 * 3600; day = day // 86400
    D = pd.DataFrame({'d': day, 'h': df.h, 'l': df.l, 'c': df.c}).groupby('d').agg(h=('h', 'max'), l=('l', 'min'), c=('c', 'last'))
    Pv = (D.h + D.l + D.c) / 3; R1 = 2 * Pv - D.l; S1 = 2 * Pv - D.h; R2 = Pv + (D.h - D.l); S2 = Pv - (D.h - D.l)
    dd = day[t]; price = df.c.values[t + 1]; a14 = atr(df, 14).values[t]
    for nm, ser in (('pv', Pv), ('r1', R1), ('s1', S1), ('r2', R2), ('s2', S2)):
        lv = ser.shift(1).reindex(dd).values; rec[f'piv_{nm}'] = (price - lv) / a14
    out.append(rec); print(s, rec.shape, flush=True)
T = pd.concat(out, ignore_index=True)
for c in T.columns:
    if c not in ('b', 'inst'): T[c] = pd.to_numeric(T[c], errors='coerce').astype('float32')
T.to_pickle('../work/ta_v0757.pkl'); print(T.shape, T.isna().mean().sort_values().tail(5).to_dict())

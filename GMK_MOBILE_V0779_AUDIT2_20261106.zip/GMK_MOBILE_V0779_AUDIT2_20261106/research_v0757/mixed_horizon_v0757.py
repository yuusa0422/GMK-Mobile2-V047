"""v0.7.57: per slot choose 3-minute or 5-minute judgement, whichever the models expect to win more often.
Both horizons' candidate models are out-of-period (period rotation). Probabilities are re-calibrated per horizon on the other two
periods (logistic on logit p) so a 3-minute and a 5-minute probability mean the same thing. Every hour >= 60% ENTRY."""
import pandas as pd, numpy as np, json, sys
from sklearn.linear_model import LogisticRegression
from wd_rank_eval_v0757 import per_hour_rank
L = pd.read_pickle('../work/ladder_v0756.pkl'); W = L[L.weekday].copy()
W = W.merge(pd.read_pickle('../work/ladder_at5_v0757.pkl')[['b', 'win5', 'tie5']], on='b', how='left')
def logit(p): p = np.clip(p, 1e-4, 1 - 1e-4); return np.log(p / (1 - p))
res = {}
for level in [int(x) for x in sys.argv[1:]] or [0, 5]:
    C3 = pd.read_pickle(f'../work/cand_wd_level{level}.pkl').rename(columns={'pu': 'u3', 'pd': 'd3', 'move3': 'm3'})
    C5 = pd.read_pickle(f'../work/cand_wd_move5_level{level}.pkl').rename(columns={'pu': 'u5', 'pd': 'd5', 'move3': 'm5'})
    C = C3.merge(C5[['b', 'inst', 'u5', 'd5', 'm5']], on=['b', 'inst'])
    # long format: one row per (slot, instrument, direction, horizon)
    rows = []
    for hz, u, d, m in ((3, 'u3', 'd3', 'm3'), (5, 'u5', 'd5', 'm5')):
        for dr, col in ((1, u), (-1, d)):
            t = C[['b', 'inst', 'hour', 'period']].copy(); t['hz'] = hz; t['dir'] = dr; t['p'] = C[col].values
            t['win'] = (C[m].values == dr).astype(int); t['tie'] = (C[m].values == 0).astype(int); rows.append(t)
    Lg = pd.concat(rows, ignore_index=True)
    # calibration per horizon on the other periods
    Lg['pc'] = np.nan
    for te in ('P1', 'P2', 'P3'):
        for hz in (3, 5):
            A = Lg[(Lg.period != te) & (Lg.hz == hz)]; B = (Lg.period == te) & (Lg.hz == hz)
            # fit only on each slot's top candidates of this horizon (the region where choices are made)
            Atop = A.sort_values('p', ascending=False).groupby('b').head(2)
            m = LogisticRegression(C=1.0).fit(logit(Atop.p.values)[:, None], Atop.win)
            Lg.loc[B, 'pc'] = m.predict_proba(logit(Lg.loc[B, 'p'].values)[:, None])[:, 1]
    for fx_only in (False, True):
        G = Lg[Lg.inst != 'BTCJPY'] if fx_only else Lg
        out = {}
        for name, hzs, key in (('3分だけ', (3,), 'pc'), ('5分だけ', (5,), 'pc'), ('高い方（較正後）', (3, 5), 'pc'), ('高い方（生の確率）', (3, 5), 'p')):
            g = G[G.hz.isin(hzs)]
            best = g.sort_values(key, ascending=False).groupby('b').head(1)
            X = W[['b', 'g56', 'inst', 'win', 'tie', 'win5', 'tie5']].rename(columns={'inst': 'linst', 'win': 'lw3', 'tie': 'lt3'}).merge(
                best[['b', 'inst', 'hz', 'period', 'hour', key, 'win', 'tie']].rename(columns={key: 'score'}), on='b')
            X['g0'] = 'R_'
            a = per_hour_rank(X, 'score', fixed_col='g0')
            # with the ladder's S/A fixed at 3 minutes and B fixed at 5 minutes (FX-only pools keep only FX ladder trades)
            fixed = X.g56.isin(['S', 'A', 'B']) & ((X.linst != 'BTCJPY') | (not fx_only))
            X['gfix'] = np.where(fixed, X.g56, 'R_')
            X['twin'] = np.where(fixed & X.g56.isin(['S', 'A']), X.lw3, np.where(fixed, X.win5, X.win))
            X['ttie'] = np.where(fixed & X.g56.isin(['S', 'A']), X.lt3, np.where(fixed, X.tie5, X.tie))
            b = per_hour_rank(X, 'score', trade_win='twin', trade_tie='ttie')
            share5 = round((X.hz == 5).mean() * 100, 1)
            out[name] = dict(model=a, ladder=b, share5=share5)
            print(f'level{level} {"為替だけ" if fx_only else "6通貨 "} {name:10s} | モデルだけ {a["win"]} ({a["P1"]}/{a["P2"]}/{a["P3"]}) | S/A(3分)+B(5分)+モデル {b["win"]} ({b["P1"]}/{b["P2"]}/{b["P3"]}) 引分 {b["draw"]} | 5分を選んだ割合 {share5}%', flush=True)
        res[f'level{level}_{"fx" if fx_only else "all"}'] = out
json.dump(res, open('../work/mixed_horizon_v0757.json', 'w'), indent=1, default=float)

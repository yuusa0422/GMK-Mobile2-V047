"""v0.7.57: 3-minute vs 5-minute judgement with the same pipeline. Models retrained on each horizon (period rotation);
every hour >= 60% ENTRY; ladder S/A/B kept fixed (scored at the same horizon); second stage = the v0.7.48 rank-strength inputs."""
import pandas as pd, numpy as np, json, sys
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from wd_rank_eval_v0757 import per_hour_rank
L = pd.read_pickle('../work/ladder_v0756.pkl'); W = L[L.weekday].copy()
A5 = pd.read_pickle('../work/ladder_at5_v0757.pkl')[['b', 'win5', 'tie5']]
W = W.merge(A5, on='b', how='left')
P = pd.read_pickle('../work/policy_data.pkl')[['b', 'inst', 'f1', 'r15', 'rv60']]
P['dow'] = pd.to_datetime(P.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.dayofweek
levels = [int(x) for x in sys.argv[1:]] or [0, 1, 5]
res = {}
for level in levels:
    for hz in (3, 5):
        Cd = pd.read_pickle(f'../work/cand_wd_level{level}.pkl' if hz == 3 else f'../work/cand_wd_move5_level{level}.pkl')
        for fx_only in (False, True):
            c = Cd[Cd.inst != 'BTCJPY'] if fx_only else Cd
            c = c.assign(p=np.maximum(c.pu, c.pd), ndir=np.where(c.pu >= c.pd, 1, -1))
            nb = c.sort_values('p', ascending=False).groupby('b').head(1)[['b', 'inst', 'ndir', 'p', 'move3', 'hour']].rename(columns={'inst': 'ninst', 'move3': 'nmove'})
            nb = nb.merge(P, left_on=['b', 'ninst'], right_on=['b', 'inst'], how='left').drop(columns=['inst'])
            X = W[['b', 'period', 'g56', 'inst', 'win', 'tie', 'win5', 'tie5']].merge(nb, on='b', how='inner')
            X['nwin'] = (X.nmove == X.ndir).astype(int); X['ntie'] = (X.nmove == 0).astype(int)
            lw, lt = ('win', 'tie') if hz == 3 else ('win5', 'tie5')
            fixed = X.g56.isin(['S', 'A', 'B']) & ((X.inst != 'BTCJPY') | (not fx_only))
            X['gfix'] = np.where(fixed, X.g56, 'R_'); X['twin'] = np.where(fixed, X[lw], X.nwin); X['ttie'] = np.where(fixed, X[lt], X.ntie)
            X['g0'] = 'R_'
            out = {'model_alone': per_hour_rank(X, 'p', fixed_col='g0', trade_win='nwin', trade_tie='ntie'),
                   'ladder_SAB_plus_model': per_hour_rank(X, 'p', trade_win='twin', trade_tie='ttie')}
            # second stage with the v0.7.48 rank-strength inputs
            X['pct'] = X.groupby('period').p.rank(pct=True); X['hinge'] = np.maximum(X.pct - 0.9, 0) * 10
            X['af1'] = X.f1.abs().clip(0, 4); X['lrv'] = np.log(X.rv60.clip(1e-6)); fx = X.ninst != 'BTCJPY'
            X['fx_fade_big'] = (fx & (X.f1 * X.ndir <= -2.5)).astype(float); X['btc_follow'] = ((~fx) & (X.f1 * X.ndir >= 0.5) & (X.f1 * X.ndir < 3)).astype(float)
            X['fx_fade15'] = (fx & (X.r15 * X.ndir <= -1.5)).astype(float); X['btc_af1'] = ((~fx) & (X.af1 >= 0.5) & (X.af1 < 3)).astype(float)
            X['h9'] = (X.hour == 9).astype(float); X['h10'] = (X.hour == 10).astype(float); X['mon'] = (X.dow == 0).astype(float)
            F = ['pct', 'hinge', 'af1', 'lrv', 'fx_fade_big', 'btc_follow', 'fx_fade15', 'btc_af1', 'h9', 'h10', 'mon']
            X['s2'] = np.nan
            for te in ('P1', 'P2', 'P3'):
                A = X[X.period != te]; B = X.period == te
                med = A[F].median(); sc = StandardScaler().fit(A[F].fillna(med))
                m = LogisticRegression(C=0.1, max_iter=3000).fit(sc.transform(A[F].fillna(med)), A.nwin)
                X.loc[B, 's2'] = m.predict_proba(sc.transform(X.loc[B, F].fillna(med)))[:, 1]
            out['model_plus_strength'] = per_hour_rank(X, 's2', fixed_col='g0', trade_win='nwin', trade_tie='ntie')
            out['ladder_SAB_plus_strength'] = per_hour_rank(X, 's2', trade_win='twin', trade_tie='ttie')
            # coverage curve (not per hour): top share of slots by the second-stage score inside each period
            X['rk'] = X.groupby('period').s2.rank(ascending=False, pct=True)
            out['curve'] = {str(cv): round(X[X.rk <= cv].nwin.mean() * 100, 2) for cv in (0.1, 0.2, 0.3, 0.4, 0.6, 0.8, 1.0)}
            tag = f'level{level}_{hz}m_{"fx" if fx_only else "all"}'; res[tag] = out
            print(tag, ' | '.join(f"{k} {v['win']} ({v['P1']}/{v['P2']}/{v['P3']})" for k, v in out.items() if k != 'curve'), '| curve', out['curve'], flush=True)
json.dump(res, open('../work/horizon_eval_v0757.json', 'w'), indent=1, default=float)

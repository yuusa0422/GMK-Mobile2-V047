exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
for name, insts in (('yen5', JPY), ('yen5+BTC/JPY+ETH/JPY', JPY + ['BTCJPY', 'ETHJPY']), ('yen5+4 crypto', JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD'])):
    r, y, E, Ey = run('base_yencrypto', insts)
    print(name, 'ROT', json.dumps(r), flush=True); print(name, 'Y2324', json.dumps(y), flush=True)
    C = E[E.g == 'C']; print('   crypto share', round(C.inst.isin(['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']).mean() * 100, 1),
          'by month crypto win', C[C.inst.isin(['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD'])].groupby(C.b.map(MON)).w.mean().mul(100).round(1).to_dict(), flush=True)

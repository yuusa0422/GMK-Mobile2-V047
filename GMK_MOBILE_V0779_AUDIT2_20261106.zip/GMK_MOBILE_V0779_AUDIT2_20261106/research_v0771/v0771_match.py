"""theoption crypto trades vs candidate price sources: does the move from entry to judgement have the same direction?"""
import numpy as np, pandas as pd
T = pd.read_pickle('theoption_trades.pkl')
sec = lambda s: ((pd.to_datetime(s).dt.tz_localize('Asia/Tokyo') - pd.Timestamp('1970-01-01', tz='UTC')).dt.total_seconds()).astype('int64')
def m1(path):
    d = pd.read_csv(path, usecols=['epoch_ms', 'open', 'close']); d['t'] = d.epoch_ms // 1000; return d.drop_duplicates('t').set_index('t').sort_index()
CI = '../crypto_in'
usdjpy = m1('../hist_v0765/USDJPY_merged.csv.gz')
src = {'bitbank BTC/JPY': ('BTC/JPY', m1('../hist_v0765/BTCJPY_1m.csv.gz'), False),
       'Coinbase BTC/USD x USD/JPY': ('BTC/JPY', m1(f'{CI}/GMK_CRYPTO_M1_coinbase_cur/coinbase/BTCUSD_1m.csv.gz'), True),
       'Binance BTC/USDT x USD/JPY': ('BTC/JPY', m1(f'{CI}/GMK_CRYPTO_M1_binance_cur/binance/BTCUSD_1m.csv.gz'), True),
       'Coinbase BTC/USD only': ('BTC/JPY', m1(f'{CI}/GMK_CRYPTO_M1_coinbase_cur/coinbase/BTCUSD_1m.csv.gz'), False),
       'Coinbase ETH/USD x USD/JPY': ('ETH/JPY', m1(f'{CI}/GMK_CRYPTO_M1_coinbase_cur/coinbase/ETHUSD_1m.csv.gz'), True),
       'Binance ETH/USDT x USD/JPY': ('ETH/JPY', m1(f'{CI}/GMK_CRYPTO_M1_binance_cur/binance/ETHUSD_1m.csv.gz'), True),
       'Coinbase BTC/USD (BTC/USD trades)': ('BTC/USD', m1(f'{CI}/GMK_CRYPTO_M1_coinbase_cur/coinbase/BTCUSD_1m.csv.gz'), False),
       'Binance BTC/USDT (BTC/USD trades)': ('BTC/USD', m1(f'{CI}/GMK_CRYPTO_M1_binance_cur/binance/BTCUSD_1m.csv.gz'), False)}
rows = []
for name, (sym, d, fx) in src.items():
    x = T[(T.sym == sym) & T.dur.isin([60.0, 180.0, 300.0])].copy(); x['ts'] = sec(x.t0); x['tj'] = sec(x.t1)
    off = x.ts % 60; x = x[(off <= 5) | (off >= 55)]
    rnd = lambda t: np.where(t % 60 >= 55, t - t % 60 + 60, t - t % 60)
    a = pd.Series(rnd(x.ts.values), index=x.index); b = pd.Series(rnd(x.tj.values), index=x.index)
    p0 = a.map(d.open); p1 = b.map(d.open)
    if fx: p0 = p0 * a.map(usdjpy.open); p1 = p1 * b.map(usdjpy.open)
    ok = p0.notna() & p1.notna(); x = x[ok]; p0 = p0[ok]; p1 = p1[ok]
    sgn = np.where(x.side == 'HIGH', 1, -1); sw = np.sign(p1 - p0) == sgn; tw = x.res == 'WIN'
    lvl = (x.rate_f / p0 - 1) * 100
    rows.append(dict(source=name, trades=len(x), same_result=round((sw == tw).mean() * 100, 1),
                     **{f'same_{int(k)}s': round((sw[x.dur == k] == tw[x.dur == k]).mean() * 100, 1) for k in (60.0, 180.0, 300.0)},
                     n_300=int((x.dur == 300.0).sum()), level_gap_pct=round(lvl.median(), 3), theoption_win=round(tw.mean() * 100, 1)))
print(pd.DataFrame(rows).to_string(index=False))

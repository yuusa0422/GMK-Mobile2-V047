"""Candle-only features at weekday 5-minute boundaries (09:00-22:55 JST) for any pair, exactly as policy_minute_v0765.feats
(61 contiguous M1 bars ending at OPEN(B-120), live proxy = close of the bar opening at B-60), plus new inputs:
r240/r1440 (4 h / 1 day trend, same normalisation), basket moves (yen basket for JPY pairs, USD basket for USD pairs), outcomes move3/move5."""
import sys, numpy as np, pandas as pd
H = '..'
SRC = {
 'cur': {'USDJPY': (f'{H}/hist_v0765/USDJPY_merged.csv.gz', 1), 'EURJPY': (f'{H}/hist_v0765/EURJPY_1m.csv.gz', 1), 'GBPJPY': (f'{H}/hist_v0765/GBPJPY_1m.csv.gz', 1),
         'AUDJPY': (f'{H}/hist_v0765/AUDJPY_1m.csv.gz', 1), 'NZDJPY': (f'{H}/hist_v0765/NZDJPY_1m.csv.gz', 1),
         'EURUSD': (f'{H}/in_PAIRS_M_1793753274/EURUSD_1m_raw.csv.gz', 1e5), 'AUDUSD': (f'{H}/in_PAIRS_M_1793753274/AUDUSD_1m_raw.csv.gz', 1e5), 'BTCJPY': (f'{H}/crypto_in/syn/BTCJPY_cur.csv.gz', 1), 'ETHJPY': (f'{H}/crypto_in/syn/ETHJPY_cur.csv.gz', 1), 'BTCUSD': (f'{H}/crypto_in/syn/BTCUSD_cur.csv.gz', 1), 'ETHUSD': (f'{H}/crypto_in/syn/ETHUSD_cur.csv.gz', 1)},
 'y': {**{s: (f'/tmp/gmkdata/years/{s}_1m.csv.gz', 1) for s in ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']},
       'EURUSD': (f'{H}/pairs2324_in/d4b4e1c3-pair_EURUSD_3/EURUSD_1m_raw.csv.gz', 1e5), 'AUDUSD': (f'{H}/pairs2324_in/18465790-pair_AUDUSD_2/AUDUSD_1m_raw.csv.gz', 1e5), 'BTCJPY': (f'{H}/crypto_in/syn/BTCJPY_y.csv.gz', 1), 'ETHJPY': (f'{H}/crypto_in/syn/ETHJPY_y.csv.gz', 1), 'BTCUSD': (f'{H}/crypto_in/syn/BTCUSD_y.csv.gz', 1), 'ETHUSD': (f'{H}/crypto_in/syn/ETHUSD_y.csv.gz', 1)}}
which = sys.argv[1]; WK = len(sys.argv) > 2 and sys.argv[2] == 'wkend'; src = SRC[which]
if WK: src = {k: v for k, v in src.items() if k in ('BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD')}
def load(path, sc):
    d = pd.read_csv(path, usecols=['epoch_ms', 'open', 'high', 'low', 'close']); d['t'] = d.epoch_ms // 1000
    d = d.drop_duplicates('t').set_index('t').sort_index()
    return d[['open', 'high', 'low', 'close']] / sc
bars = {s: load(p, sc) for s, (p, sc) in src.items()}
t0 = min(b.index.min() for b in bars.values()); t1 = max(b.index.max() for b in bars.values())
grid = np.arange(t0 - t0 % 60 - 2000 * 60, t1 + 2000 * 60, 60)
# boundaries: weekday 09:00-22:55 JST, minute % 5 == 0
B = grid[grid % 300 == 0]; ts = pd.to_datetime(B, unit='s', utc=True).tz_convert('Asia/Tokyo')
keep = ((ts.dayofweek >= 5) if WK else (ts.dayofweek <= 4)) & (ts.hour >= 9) & (ts.hour <= 22); B = B[keep]; B = B[(B > t0 + 1500 * 60) & (B < t1 - 600)]
idx = lambda t: ((t - grid[0]) // 60).astype(np.int64)
out = []
for s, d in bars.items():
    g = d.reindex(grid); o, h, l, c = (g[k].values for k in ('open', 'high', 'low', 'close'))
    lg = np.log(c); ok = ~np.isnan(c)
    i60 = idx(B - 120)                      # last window bar (opens at B-120)
    win_ok = np.ones(len(B), bool)
    cs = np.r_[0, np.cumsum(ok.astype(int))]
    win_ok &= (cs[i60 + 1] - cs[i60 - 60]) == 61                    # 61 contiguous bars B-3720 .. B-120
    ret = np.r_[np.nan, np.diff(lg)]; r2 = np.nan_to_num(ret ** 2)
    c2 = np.r_[0, np.cumsum(r2)]
    ss60 = c2[i60 + 1] - c2[i60 - 59]; ss30 = c2[i60 + 1] - c2[i60 - 29]
    norm = np.maximum(np.sqrt(np.maximum(ss60, 0) / 60.0), 1e-8); rv30 = np.sqrt(np.maximum(ss30, 0) / 30.0)
    F = dict(b=B, inst=s)
    L60 = lg[i60]
    for k in (1, 3, 5, 10, 15, 30, 60): F[f'r{k}'] = (L60 - lg[i60 - k]) / (norm * np.sqrt(k))
    for k in (240, 1440):                                           # new: longer trend (bar k minutes back must exist)
        F[f'r{k}'] = (L60 - lg[i60 - k]) / (norm * np.sqrt(k))
    F['rv60'] = norm * 1e4; F['rv30_60'] = rv30 / norm
    def roll(arr, n, fn):
        st = np.lib.stride_tricks.sliding_window_view(np.nan_to_num(arr, nan=np.nan), n)
        return fn(st, axis=1)
    hmax15 = pd.Series(h).rolling(15).max().values; lmin15 = pd.Series(l).rolling(15).min().values
    hmax61 = pd.Series(h).rolling(61).max().values; lmin61 = pd.Series(l).rolling(61).min().values
    m20 = pd.Series(c).rolling(20).mean().values; sd20 = np.sqrt(np.maximum(pd.Series(c).rolling(20).var(ddof=0).values, 1e-16))
    hi15, lo15 = hmax15[i60], lmin15[i60]; c60 = c[i60]
    F['pos15'] = (c60 - lo15) / np.maximum(hi15 - lo15, 1e-12) * 2 - 1
    F['pos60'] = (c60 - lmin61[i60]) / np.maximum(hmax61[i60] - lmin61[i60], 1e-12) * 2 - 1
    F['bbz'] = (c60 - m20[i60]) / sd20[i60]
    live = c[idx(B - 60)]; lok = ~np.isnan(live); ll = np.log(live)
    F['f1'] = (ll - L60) / norm; F['f2'] = (ll - lg[i60 - 1]) / (norm * np.sqrt(2)); F['f5'] = (ll - lg[i60 - 4]) / (norm * np.sqrt(5))
    F['f15'] = (ll - lg[i60 - 14]) / (norm * np.sqrt(15))
    hiL = np.maximum(hi15, live); loL = np.minimum(lo15, live); F['pos15L'] = (live - loL) / np.maximum(hiL - loL, 1e-12) * 2 - 1
    F['bbzL'] = (live - m20[i60]) / sd20[i60]
    ob = o[idx(B)]; o3 = o[idx(B + 180)]; o5 = o[idx(B + 300)]
    F['move3'] = np.sign(o3 - ob); F['move5'] = np.sign(o5 - ob)
    Fd = pd.DataFrame(F); Fd = Fd[win_ok & lok & ~np.isnan(ob)]
    out.append(Fd); print(s, len(Fd), flush=True)
D = pd.concat(out, ignore_index=True)
# baskets: yen basket (as the app: mean over USDJPY, EURJPY, GBPJPY, AUDJPY) and USD basket (USDJPY, -EURUSD, -AUDUSD), JPY weakness / USD strength = +
for nm, members in (('yen', {'USDJPY': 1, 'EURJPY': 1, 'GBPJPY': 1, 'AUDJPY': 1}), ('usd', {'USDJPY': 1, 'EURUSD': -1, 'AUDUSD': -1})):
    for k in ('r5', 'r15', 'f1', 'r60'):
        X = D[D.inst.isin(members)].assign(v=lambda x: x[k] * x.inst.map(members)).pivot(index='b', columns='inst', values='v')
        D[f'{nm}_{k}'] = D.b.map(X.mean(axis=1).where(X.notna().sum(axis=1) == len(members)))
# the pair's own basket (signed as the pair: JPY pairs use the yen basket, XXXUSD pairs minus the USD basket)
CRYPTO = ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']; isb = D.inst.isin(CRYPTO); isj = D.inst.str.endswith('JPY') & ~isb
for k in ('r5', 'r15', 'f1', 'r60'):
    D[f'bask_{k}'] = np.where(isb, 0.0, np.where(isj, D[f'yen_{k}'], -D[f'usd_{k}']))
    D[f'idio_{k}'] = D[k] - D[f'bask_{k}']
    D[f'usdx_{k}'] = np.where(isb, 0.0, D[f'usd_{k}'] * np.where(D.inst.str.startswith('USD'), 1, -1))   # USD move in the pair's direction (new input)
ts = pd.to_datetime(D.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); D['hour'] = ts.dt.hour; D['date'] = ts.dt.date; D['minute'] = ts.dt.minute; D['wd'] = ts.dt.dayofweek
ds = D.date.astype(str)
D['period'] = np.where(ds < '2023-06-01', 'Y1', np.where(ds < '2023-11-01', 'Y2', 'Y3')) if which == 'y' else np.where(ds < '2026-02-01', 'P1', np.where(ds < '2026-06-01', 'P2', 'P3'))
D.to_pickle(f'../work/v0770_F_{which}_' + ('wkend' if WK else 'crypto') + '.pkl'); print(which, D.shape, D.inst.value_counts().to_dict(), flush=True)

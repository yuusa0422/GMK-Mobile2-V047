"""Exact 5-minute app replay of candle-only score files: rotation (current year) and 2023-24 (production fit, in-sample tables)."""
exec(open('v0770_lab.py').read())
RTp = pd.read_pickle('../work/years/rule_trades_years.pkl'); Fy_all = fixed_lookup(RTp, None)
ALL7 = JPY + ['EURUSD', 'AUDUSD']
def years(ins, ys, insts, **kw):
    C, M = build(ins[ins.inst.isin(insts)]); Q, base = tables(M[M.b.isin(slots_cur)], fx, hour_of(slots_cur))
    Cy, My = build(ys[ys.inst.isin(insts)]); slots_y = set(ys[ys.inst.isin(JPY)].b)
    E = sim(Cy, {b: v for b, v in Fy_all.items() if b in slots_y}, slots_y, Q, base, **kw)
    ndy = len(set(pd.to_datetime(list(slots_y), unit='s', utc=True).tz_convert('Asia/Tokyo').date)); s10, mx = streak_stats(E.w.values)
    return dict(win=round(E.w.mean() * 100, 2), n=len(E), per_day=round(len(E) / ndy, 1), C=round(E[E.g == 'C'].w.mean() * 100, 2), maxrun=mx,
                hours_below=round(E.attrs['hours_below'] * 100, 2), pairs={k: (int(len(x)), round(x.w.mean() * 100, 1)) for k, x in E[E.g == 'C'].groupby('inst')}), E
def run(tag, insts, **kw):
    rot = pd.read_pickle(f'../work/v0770_sc_{tag}_rot.pkl'); ins = pd.read_pickle(f'../work/v0770_sc_{tag}_ins.pkl'); ys = pd.read_pickle(f'../work/v0770_sc_{tag}_y.pkl')
    E = rotation(rot, insts=insts, **kw); r = summ(E); r['pairs'] = {k: (int(len(x)), round(x.w.mean() * 100, 1)) for k, x in E[E.g == 'C'].groupby('inst')}
    y, Ey = years(ins, ys, insts, **kw)
    return r, y, E, Ey
if __name__ == '__main__':
    for tag, insts in [(a.split(':')[0], JPY if a.split(':')[1] == 'yen' else ALL7) for a in sys.argv[1:]]:
        r, y, E, Ey = run(tag, insts)
        print(tag, len(insts), 'ROT', json.dumps(r), flush=True); print(tag, len(insts), 'Y2324', json.dumps(y), flush=True)

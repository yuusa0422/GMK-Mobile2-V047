"""v0.7.71 weekday 5-minute model: candle-only inputs, pool = 5 yen crosses + BTC/JPY, ETH/JPY, BTC/USD, ETH/USD (Coinbase x USD/JPY,
theoption's rate source matches 92%). Production fit on the whole current year (fresh: live-price inputs; fallback: live block = 0),
5 seeds each, exported for Kotlin (GMKEV1), hour tables for 5-minute slots, parity rows, rotation rates with the app rule (pace 0.8)."""
import sys, json, pickle, numpy as np, pandas as pd, time
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('v0770_models.py').read().split("if __name__ == '__main__':")[0])
SEEDS5 = range(5)
INST9 = YEN + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
S_, F_, U_ = FEATS['base']
def design_app(D, d, fresh):
    cols = [D[c].values * d for c in S_] + [(D[c].values * d) if fresh else np.zeros(len(D)) for c in F_] + [D[c].values.astype(float) for c in U_]
    cols += [(D.inst.values == s).astype(float) for s in INST9] + [np.full(len(D), float(d))]
    return np.column_stack(cols)
NAMES = S_ + F_ + U_ + ['is_' + s for s in INST9] + ['dir']
def fit_app(D, fresh):
    X = np.vstack([design_app(D, 1, fresh), design_app(D, -1, fresh)]); y = np.r_[D.move5.values == 1, D.move5.values == -1].astype(int)
    return [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in SEEDS5]
def pred_app(ms, D, fresh):
    return (np.mean([m.predict_proba(design_app(D, 1, fresh))[:, 1] for m in ms], 0), np.mean([m.predict_proba(design_app(D, -1, fresh))[:, 1] for m in ms], 0))
if __name__ == '__main__':
    exec(open('model_export_lib.py').read()); NFEAT = len(NAMES)
    Dc = load('cur', True); Dc = Dc[Dc.inst.isin(INST9)].reset_index(drop=True); Dy = load('y', True); Dy = Dy[Dy.inst.isin(INST9)].reset_index(drop=True)
    out = {'features': NAMES, 'insts': INST9}
    for fresh in (True, False):
        k = 'fresh' if fresh else 'fallback'; t0 = time.time()
        # rotation scores (validation, the same setup) for the rates
        parts = []
        for te in ('P1', 'P2', 'P3'):
            ms = fit_app(Dc[Dc.period != te], fresh); T = Dc[Dc.period == te]; pu, pdn = pred_app(ms, T, fresh)
            parts.append(T[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=pu, pd=pdn))
        pd.concat(parts, ignore_index=True).to_pickle(f'../work/v0771_sc_{k}_rot.pkl')
        ms = fit_app(Dc, fresh)
        texts = [export(m) for m in ms]
        Xs = design_app(Dc.sample(1500, random_state=7), 1, fresh)
        for m, tx in zip(ms, texts):
            dd = np.abs(eval_text(tx, Xs) - m.predict_proba(Xs)[:, 1]).max(); assert dd < 1e-12, dd
        pu, pdn = pred_app(ms, Dc, fresh); Dc[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=pu, pd=pdn).to_pickle(f'../work/v0771_sc_{k}_ins.pkl')
        pu, pdn = pred_app(ms, Dy, fresh); Dy[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=pu, pd=pdn).to_pickle(f'../work/v0771_sc_{k}_y.pkl')
        Sm = Dc.sample(120, random_state=11 if fresh else 12); rows = []
        for d in (1, -1):
            Xd = design_app(Sm, d, fresh); pp = np.mean([m.predict_proba(Xd)[:, 1] for m in ms], 0)
            rows += [(float(p_), ','.join(repr(float(v)) for v in xr)) for p_, xr in zip(pp, Xd)]
        out[k] = dict(texts=texts, parity=rows); print(k, 'done', round(time.time() - t0), 's', flush=True)
    pickle.dump(out, open('../work/v0771_production.pkl', 'wb')); print('PRODUCTION_DONE', flush=True)

"""v0.7.70 research lab: the weekday 5-minute AUTO with the exact app rules (12 slots an hour, 9 entries, catch-up, same-direction
penalty 0.03, fixed S/A 3-minute and B 5-minute trades), current model rotated P1/P2/P3 (each period scored by models not fit on it,
hour tables from the other two periods). Hooks: per-candidate judge length, threshold adjustment, extra candidate pairs."""
import sys, json, math, bisect
_argv = sys.argv[:]
sys.argv = ['x', '../work/v0765_5m_cur.pkl', 'lab', 'five']
exec(open('v0765_sim_5min.py').read().split("F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); res = {}")[0])
sys.argv = _argv
F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix)
JPY = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
PACE = {'a': 1.0, 'f': 0.5, 'k': 0.0}
MON = lambda b: pd.to_datetime(b, unit='s', utc=True).tz_convert('Asia/Tokyo').strftime('%Y-%m')

def build(S, extra=()):
    """S: one row per (boundary, pair) with pu, pd (5-min), move5 and optional pu3, pd3, move3 + extra columns."""
    cols = ['b', 'inst', 'hour', 'period', 'move5'] + [c for c in ('pu3', 'pd3', 'move3') if c in S] + list(extra)
    up = S[cols].assign(p=S.pu, dir=1); dn = S[cols].assign(p=S.pd, dir=-1)
    if 'pu3' in S: up['p3'] = S.pu3; dn['p3'] = S.pd3
    A = pd.concat([up, dn], ignore_index=True)
    A['dr'] = np.r_[1 - S.pu.values - S.pd.values, 1 - S.pu.values - S.pd.values]
    A['w5'] = (A.move5 == A.dir).astype(float)
    if 'move3' in A: A['w3'] = (A.move3 == A.dir).astype(float); A['d3'] = (A.move3 == 0).astype(float)
    A['d5'] = (A.move5 == 0).astype(float)
    A = A.sort_values(['b', 'p'], ascending=[True, False])
    C = {b: g for b, g in A.groupby('b', sort=True)}
    M = A.groupby('b').head(1)[['b', 'hour', 'period', 'p']]
    return C, M

def sim(C, Fx, slots, Q, base, lam=0.03, judge=None, adj=None):
    """judge(row) -> 3 or 5 (default 5); adj(row) -> amount added to p for the threshold test only."""
    out = []; S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
    S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour; opens = []; hours = []
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0
        for b in sorted(g.b):
            minute = (b // 60) % 60; opens = [o for o in opens if o[0] > b]
            if b in Fx:
                gr, w, inst, dd, L_ = Fx[b]; out.append(dict(b=b, g=gr, w=w, dir=dd, inst=inst, forced=0, L=L_ // 60, minute=minute)); cnt += 1
                opens.append((b + L_, dd)); continue
            if b not in C: continue
            g2 = C[b]; nh = sum(1 for o in opens if o[1] == 1); nl = sum(1 for o in opens if o[1] == -1)
            sc = g2.p.values - lam * np.where(g2.dir.values == 1, nh, nl) - (PACE['k'] * g2.dr.values if PACE['k'] and 'dr' in g2 else 0.0)
            r = g2.iloc[int(np.argmax(sc))]
            left = (60 - minute + 4) // 5; need = N - cnt
            pt = r.p + (adj(r) if adj else 0.0)
            if need >= left: forced = 1
            elif need > 0 and pt >= qcut(Q[h], max(PACE['a'] * need / left, base[h] * PACE['f'])): forced = 0
            else: continue
            L = judge(r) if judge else 5
            w = r.w3 if L == 3 else r.w5
            out.append(dict(b=b, g='C', w=float(w), dir=int(r.dir), inst=r.inst, forced=forced, L=L, minute=minute, p=float(r.p),
                            **{k: r[k] for k in r.index if k not in ('b', 'inst', 'hour', 'period', 'dir', 'p')}))
            cnt += 1; opens.append((b + 60 * L, int(r.dir)))
        hours.append(cnt / n)
    E = pd.DataFrame(out); E.attrs['hours_below'] = float(np.mean(np.array(hours) < SHARE - 1e-9)); return E

def rotation(S, insts=JPY, extra=(), **kw):
    C, M = build(S[S.inst.isin(insts)], extra); Es = []
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
        Ct = {b: v for b, v in C.items() if per_cur.get(b - b % 300) == te}
        E = sim(Ct, {b: v for b, v in F.items() if b in tes}, tes, Q, base, **kw); E['per'] = te; Es.append(E)
    E = pd.concat(Es).sort_values('b').reset_index(drop=True); E.attrs['hours_below'] = float(np.mean([e.attrs['hours_below'] for e in Es])); return E

NDAYS = len(set(PM.date))
def summ(E):
    s10, mx = streak_stats(E.w.values); so = E.b >= 1788188400
    return dict(win=round(E.w.mean() * 100, 2), n=len(E), per_day=round(len(E) / NDAYS, 1), P=[round(E[E.per == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')],
                sep_oct=round(E[so].w.mean() * 100, 2), streak10=s10, maxrun=mx, hours_below=round(E.attrs['hours_below'] * 100, 2),
                C=round(E[E.g == 'C'].w.mean() * 100, 2), three=int((E.L == 3).sum()))

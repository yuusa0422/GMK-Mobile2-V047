"""theoption-like crypto series: Coinbase X/USD 1-minute OHLC (x USD/JPY close of the same minute, carried over weekends for the JPY pairs)."""
import numpy as np, pandas as pd, os
CI = '../crypto_in'; os.makedirs(f'{CI}/syn', exist_ok=True)
for per, cb, fxp in (('cur', f'{CI}/GMK_CRYPTO_M1_coinbase_cur/coinbase', '../hist_v0765/USDJPY_merged.csv.gz'),
                     ('y', f'{CI}/GMK_CRYPTO_M1_coinbase_y2324/coinbase', '/tmp/gmkdata/years/USDJPY_1m.csv.gz')):
    fxd = pd.read_csv(fxp, usecols=['epoch_ms', 'open', 'close']).drop_duplicates('epoch_ms').set_index('epoch_ms').sort_index()
    for coin in ('BTC', 'ETH'):
        d = pd.read_csv(f'{cb}/{coin}USD_1m.csv.gz').drop_duplicates('epoch_ms').set_index('epoch_ms').sort_index()
        d.reset_index().to_csv(f'{CI}/syn/{coin}USD_{per}.csv.gz', index=False)
        # the same instant on both legs: open x USD/JPY open, close x USD/JPY close (carried over FX gaps and weekends);
        # high / low x the middle of the minute's USD/JPY open and close, kept around the open and close
        u = d.index.union(fxd.index); fo = fxd.open.reindex(u); fc = fxd.close.reindex(u)
        fo = fo.fillna(fc.shift(1)).ffill().reindex(d.index); fc = fc.ffill().reindex(d.index); fm = (fo + fc) / 2
        o = d.open * fo; c = d.close * fc
        j = pd.DataFrame({'open': o, 'high': np.maximum(np.maximum(o, c), d.high * fm), 'low': np.minimum(np.minimum(o, c), d.low * fm),
                          'close': c, 'volume': d.volume}).dropna()
        j.reset_index().to_csv(f'{CI}/syn/{coin}JPY_{per}.csv.gz', index=False); print(per, coin, len(j), flush=True)

"""Candle-only direction model at 5-minute boundaries: rotation P1/P2/P3 scores + production fit scored on 2023-24."""
import sys, numpy as np, pandas as pd, time
from sklearn.ensemble import HistGradientBoostingClassifier
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
SEEDS = range(3)
YEN = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']; ALL7 = YEN + ['EURUSD', 'AUDUSD']
BASE_S = ['r1', 'r3', 'r5', 'r10', 'r15', 'r30', 'r60', 'pos15', 'pos60', 'bbz', 'bask_r5', 'idio_r5', 'bask_r15', 'idio_r15']
BASE_F = ['f1', 'f2', 'f5', 'f15', 'pos15L', 'bbzL', 'bask_f1', 'idio_f1']
BASE_U = ['rv60', 'rv30_60', 'hour']
NEW_S = ['r240', 'r1440', 'bask_r60', 'idio_r60', 'usdx_r5', 'usdx_r15', 'usdx_f1', 'usdx_r60']
NEW_U = ['vr', 'wd']
def load(which, btc=False):
    D = pd.read_pickle(f'../work/v0770_F_{which}' + ('_crypto' if btc else '') + '.pkl'); vr = pd.read_pickle(f'../work/v0770_vr_{which}.pkl')
    D['vr'] = (((D.b - 60) // 900) * 900).map(vr).astype(float); return D
def design(D, d, S, Fr, U, insts):
    cols = [D[c].values * d for c in S] + [D[c].values * d for c in Fr] + [D[c].values.astype(float) for c in U]
    cols += [(D.inst.values == s).astype(float) for s in insts] + [np.full(len(D), float(d))]
    return np.column_stack(cols)
def fit(D, feats, insts):
    Xu = design(D, 1, *feats, insts); Xd = design(D, -1, *feats, insts); X = np.vstack([Xu, Xd])
    y = np.r_[D.move5.values == 1, D.move5.values == -1].astype(int)
    return [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in SEEDS]
def pred(ms, D, feats, insts):
    Xu = design(D, 1, *feats, insts); Xd = design(D, -1, *feats, insts)
    return np.mean([m.predict_proba(Xu)[:, 1] for m in ms], 0), np.mean([m.predict_proba(Xd)[:, 1] for m in ms], 0)
FEATS = {'base': (BASE_S, BASE_F, BASE_U), 'new': (BASE_S + NEW_S, BASE_F, BASE_U + NEW_U),
         'base_vr': (BASE_S, BASE_F, BASE_U + ['vr']), 'new_novr': (BASE_S + NEW_S, BASE_F, BASE_U + ['wd'])}
if __name__ == '__main__':
    fname, train = sys.argv[1], sys.argv[2]; feats = FEATS[fname]; insts = {'yen': YEN, 'all': ALL7, 'yenbtc': YEN + ['BTCJPY'], 'yencrypto': YEN + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']}[train]
    Dc = load('cur', train in ('yenbtc', 'yencrypto')); Dy = load('y', train in ('yenbtc', 'yencrypto')); Dc = Dc[Dc.inst.isin(insts)].reset_index(drop=True); Dy = Dy[Dy.inst.isin(insts)].reset_index(drop=True)
    parts = []
    for te in ('P1', 'P2', 'P3'):
        t0 = time.time(); ms = fit(Dc[Dc.period != te], feats, insts); T = Dc[Dc.period == te]; pu, pdn = pred(ms, T, feats, insts)
        parts.append(T[['b', 'inst', 'hour', 'period', 'move3', 'move5', 'vr', 'rv60', 'f1']].assign(pu=pu, pd=pdn)); print(fname, train, te, round(time.time() - t0), 's', flush=True)
    pd.concat(parts, ignore_index=True).to_pickle(f'../work/v0770_sc_{fname}_{train}_rot.pkl')
    ms = fit(Dc, feats, insts)
    pu, pdn = pred(ms, Dc, feats, insts); Dc[['b', 'inst', 'hour', 'period', 'move3', 'move5', 'vr', 'rv60', 'f1']].assign(pu=pu, pd=pdn).to_pickle(f'../work/v0770_sc_{fname}_{train}_ins.pkl')
    pu, pdn = pred(ms, Dy, feats, insts); Dy[['b', 'inst', 'hour', 'period', 'move3', 'move5', 'vr', 'rv60', 'f1']].assign(pu=pu, pd=pdn).to_pickle(f'../work/v0770_sc_{fname}_{train}_y.pkl')
    print('DONE', fname, train, flush=True)

"""v0.7.71 weekend model (Sat/Sun 09:00-22:55 JST, 3-minute judging) over BTC/JPY, ETH/JPY, BTC/USD, ETH/USD (Coinbase x USD/JPY):
candle-only inputs + weekend flag, trained on every crypto 5-minute boundary (weekday + weekend) of 2025-10-01..2026-11-05, target
3-minute WIN. Production fit (fresh / backup, 5 seeds), per-hour cuts for the top 8% (B) and top 60% (C) of weekend slots,
rotation rates (P1/P2/P3), 2023-24 check, Kotlin export and parity rows."""
import json, pickle, hashlib, gzip, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('v0770_models.py').read().split("if __name__ == '__main__':")[0])
exec(open('model_export_lib.py').read())
CR = ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']; S_, F_, U_ = FEATS['base']
NAMES = S_ + F_ + U_ + ['wkend'] + ['is_' + s for s in CR] + ['dir']; NFEAT = len(NAMES)
def prep(which):
    a = pd.read_pickle(f'../work/v0770_F_{which}_crypto.pkl'); a = a[a.inst.isin(CR)].assign(wkend=0.0)
    w = pd.read_pickle(f'../work/v0770_F_{which}_wkend.pkl').assign(wkend=1.0)
    return pd.concat([a, w], ignore_index=True)
def des(D, d, fresh):
    cols = [D[c].values * d for c in S_] + [(D[c].values * d) if fresh else np.zeros(len(D)) for c in F_]
    cols += [D[c].values.astype(float) for c in U_ + ['wkend']] + [(D.inst.values == s).astype(float) for s in CR] + [np.full(len(D), float(d))]
    return np.column_stack(cols)
def fitw(D, fresh, seeds=range(5)):
    D = D[D.move3.notna()]; X = np.vstack([des(D, 1, fresh), des(D, -1, fresh)]); y = np.r_[D.move3.values == 1, D.move3.values == -1].astype(int)
    return [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in seeds]
def predw(ms, D, fresh): return np.mean([m.predict_proba(des(D, 1, fresh))[:, 1] for m in ms], 0), np.mean([m.predict_proba(des(D, -1, fresh))[:, 1] for m in ms], 0)
def best(D, pu, pdn):
    A = pd.concat([D[['b', 'inst', 'hour', 'move3']].assign(p=pu, dir=1), D[['b', 'inst', 'hour', 'move3']].assign(p=pdn, dir=-1)])
    A['w'] = (A.move3 == A.dir).astype(float); return A.sort_values('p', ascending=False).groupby('b').head(1)
def cuts(Bt, x): return {h: float(g.p.quantile(1 - x)) for h, g in Bt.groupby('hour')}
Cc = prep('cur'); Cy = prep('y'); out = {'features': NAMES, 'insts': CR}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'; parts = []
    for te in ('P1', 'P2', 'P3'):
        ms = fitw(Cc[Cc.period != te], fresh, range(3))
        tr = Cc[(Cc.period != te) & (Cc.wkend == 1)]; Bt = best(tr, *predw(ms, tr, fresh))
        tw = Cc[(Cc.period == te) & (Cc.wkend == 1) & Cc.move3.notna()]; Be = best(tw, *predw(ms, tw, fresh))
        b8, c60 = cuts(Bt, 0.08), cuts(Bt, 0.60)
        Be['g'] = np.where(Be.p >= Be.hour.map(b8), 'B', np.where(Be.p >= Be.hour.map(c60), 'C', 'D')); parts.append(Be.assign(per=te))
    R = pd.concat(parts).reset_index(drop=True); mo = pd.to_datetime(R.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
    rates = {g: (round(float(x.w.mean()), 4), round(float(x[x.mo == '2026-10'].w.mean()), 4) if (x.mo == '2026-10').any() else None, int((x.mo == '2026-10').sum()))
             for g, x in R.assign(mo=mo.values).groupby('g')}
    ms = fitw(Cc, fresh); texts = [export(m) for m in ms]
    Xs = des(Cc.sample(1500, random_state=7), 1, fresh)
    for m, tx in zip(ms, texts): assert np.abs(eval_text(tx, Xs) - m.predict_proba(Xs)[:, 1]).max() < 1e-12; assert len(tx.encode()) < 65000
    tr = Cc[Cc.wkend == 1]; Bt = best(tr, *predw(ms, tr, fresh)); b8, c60 = cuts(Bt, 0.08), cuts(Bt, 0.60)
    ty = Cy[(Cy.wkend == 1) & Cy.move3.notna()]; By = best(ty, *predw(ms, ty, fresh))
    yB = By[By.p >= By.hour.map(b8)]; ndy = ty.date.nunique(); ndc = Cc[Cc.wkend == 1].date.nunique()
    Sm = Cc[Cc.wkend == 1].sample(120, random_state=21 if fresh else 22); rows = []
    for d in (1, -1):
        Xd = des(Sm, d, fresh); pp = np.mean([m.predict_proba(Xd)[:, 1] for m in ms], 0)
        rows += [(float(p_), ','.join(repr(float(v)) for v in xr)) for p_, xr in zip(pp, Xd)]
    out[k] = dict(texts=texts, b8=[b8[h] for h in range(9, 23)], c60=[c60[h] for h in range(9, 23)], parity=rows, rates=rates,
                  rotation_B=dict(win=round(R[R.g == 'B'].w.mean() * 100, 2), per_day=round((R.g == 'B').sum() / ndc, 1),
                                  periods=[round(R[(R.g == 'B') & (R.per == p)].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')],
                                  pairs={i: round(v * 100, 1) for i, v in R[R.g == 'B'].groupby('inst').w.mean().items()}),
                  y2324_B=dict(win=round(yB.w.mean() * 100, 2), per_day=round(len(yB) / ndy, 1)))
    print(k, json.dumps({x: out[k][x] for x in ('rates', 'rotation_B', 'y2324_B')}), flush=True)
pickle.dump(out, open('../work/v0771_weekend_production.pkl', 'wb')); print('WEEKEND_DONE', flush=True)

"""Weekend (Sat/Sun 09:00-22:55 JST, 3-minute judging): candle-only crypto model on the theoption-like series (Coinbase x USD/JPY),
pool BTC/JPY only vs the four 90% cryptos; enter the top X% of slots (hour thresholds from the training data). Compared with the
app's current weekend B (bitbank inputs) re-judged on the same theoption-like price."""
import numpy as np, pandas as pd, json
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('v0770_models.py').read().split("if __name__ == '__main__':")[0])
CR = ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
S_, F_, U_ = FEATS['base']
def prep(which):
    a = pd.read_pickle(f'../work/v0770_F_{which}_crypto.pkl'); a = a[a.inst.isin(CR)].assign(wkend=0.0)
    w = pd.read_pickle(f'../work/v0770_F_{which}_wkend.pkl').assign(wkend=1.0)
    return pd.concat([a, w], ignore_index=True)
def des(D, d, insts):
    cols = [D[c].values * d for c in S_ + F_] + [D[c].values.astype(float) for c in U_ + ['wkend']] + [(D.inst.values == s).astype(float) for s in insts] + [np.full(len(D), float(d))]
    return np.column_stack(cols)
def fitw(D, insts):
    D = D[D.move3.notna()]; X = np.vstack([des(D, 1, insts), des(D, -1, insts)]); y = np.r_[D.move3.values == 1, D.move3.values == -1].astype(int)
    return [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in range(3)]
def predw(ms, D, insts):
    return np.mean([m.predict_proba(des(D, 1, insts))[:, 1] for m in ms], 0), np.mean([m.predict_proba(des(D, -1, insts))[:, 1] for m in ms], 0)
def best(D, pu, pdn):
    A = pd.concat([D[['b', 'inst', 'hour', 'move3']].assign(p=pu, dir=1), D[['b', 'inst', 'hour', 'move3']].assign(p=pdn, dir=-1)])
    A['w'] = (A.move3 == A.dir).astype(float); return A.sort_values('p', ascending=False).groupby('b').head(1)
def thresholds(Bt, x): return {h: g.p.quantile(1 - x) for h, g in Bt.groupby('hour')}
def pick(Be, th): return Be[Be.p >= Be.hour.map(th)]
Cc = prep('cur'); Cy = prep('y'); res = {}
for name, insts in (('BTC/JPY only', ['BTCJPY']), ('4 cryptos', CR)):
    Dc = Cc[Cc.inst.isin(insts)]; Dy = Cy[Cy.inst.isin(insts)]
    rows = {x: [] for x in (0.08, 0.15, 0.25, 1.0)}
    for te in ('P1', 'P2', 'P3'):
        ms = fitw(Dc[Dc.period != te], insts)
        tr = Dc[(Dc.period != te) & (Dc.wkend == 1)]; Bt = best(tr, *predw(ms, tr, insts))
        tw = Dc[(Dc.period == te) & (Dc.wkend == 1) & Dc.move3.notna()]; Be = best(tw, *predw(ms, tw, insts))
        for x in rows: rows[x].append(pick(Be, thresholds(Bt, x)) if x < 1 else Be)
    ms = fitw(Dc, insts); tr = Dc[Dc.wkend == 1]; Bt = best(tr, *predw(ms, tr, insts))
    ty = Dy[(Dy.wkend == 1) & Dy.move3.notna()]; By = best(ty, *predw(ms, ty, insts))
    ndc = Dc[Dc.wkend == 1].date.nunique(); ndy = ty.date.nunique()
    for x, parts in rows.items():
        E = pd.concat(parts); Ey = pick(By, thresholds(Bt, x)) if x < 1 else By
        res[f'{name} top{int(x*100)}%'] = dict(cur=round(E.w.mean() * 100, 2), cur_per_day=round(len(E) / ndc, 1), y2324=round(Ey.w.mean() * 100, 2), y_per_day=round(len(Ey) / ndy, 1),
                                               pairs={k: round(v * 100, 1) for k, v in E.groupby('inst').w.mean().items()})
        print(name, f'top{int(x*100)}%', json.dumps(res[f'{name} top{int(x*100)}%']), flush=True)
# the app's current weekend B (bitbank inputs, old models) judged on the theoption-like BTC/JPY
L = pd.read_pickle('../work/ladder_v0756.pkl'); W = L[~L.weekday].copy()
s = pd.read_csv('../crypto_in/syn/BTCJPY_cur.csv.gz'); s['t'] = s.epoch_ms // 1000; s = s.drop_duplicates('t').set_index('t')
o0 = W.b.map(s.open); o3 = (W.b + 180).map(s.open); W = W[o0.notna() & o3.notna()]; W['w2'] = (np.sign((W.b + 180).map(s.open) - W.b.map(s.open)) == W.dir).astype(float)
B = W[W.g56 == 'B']; print('current app weekend B: theoption-like', round(B.w2.mean() * 100, 2), 'bitbank', round(B.win.mean() * 100, 2), 'n', len(B), 'per day', round(len(B) / W.date.nunique(), 1), flush=True)

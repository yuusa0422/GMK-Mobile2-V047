"""v0.7.71 Python-vs-Kotlin parity fixtures of the weekday hour rule: the nine-pair tables (EvidenceSlot9Data.kt, read from the
Kotlin source) and PACE 0.8: cut = quantile of the hour for max(0.8 x need / left, BASE / 2); left = (60 - minute + 4) // 5.
Lines as v0.7.66: 'cut|fresh|hour|minute|entries|expected', 'hour|fresh|hour|seed|p(:00),...,p(:55)|fixed minutes|entered minutes',
'slots|fresh|hour|minute|entries|slots|expected'.  Usage: gen_hour_fixture_v0771.py EvidenceSlot9Data.kt rule.txt.gz slots.txt.gz"""
import math, gzip, re, sys, numpy as np
kt, fx_rule, fx_slots = sys.argv[1:4]; QN = 200; PACE = 0.8
src = open(kt).read(); T = {}
for k, nm in (('fresh', 'FRESH'), ('fallback', 'FALLBACK')):
    block = src[src.index(f'val {nm}_QUANTILES'):src.index(f'val {nm}_BASE')]
    rows = [list(map(float, r.split(','))) for r in re.findall(r'doubleArrayOf\(([^)]*)\)', block)]
    base = list(map(float, re.search(rf'val {nm}_BASE = doubleArrayOf\(([^)]*)\)', src).group(1).split(',')))
    assert len(rows) == 14 and all(len(r) == QN + 1 for r in rows) and len(base) == 14
    T[k] = {'Q': {h: rows[h - 9] for h in range(9, 23)}, 'base': {h: base[h - 9] for h in range(9, 23)}}
def qcut(Q, frac):
    frac = min(max(frac, 0.0), 1.0); return float(np.interp(1 - frac, np.linspace(0, 1, QN + 1), Q))
def cut(k, h, minute, entries, slots=12):
    N = math.ceil(0.7 * slots - 1e-9); need = N - entries; left = min(max((60 - minute + 4) // 5, 1), 12)
    if need >= left: return -math.inf
    if need <= 0: return math.inf
    return qcut(np.array(T[k]['Q'][h]), max(PACE * need / left, T[k]['base'][h] / 2))
rng = np.random.default_rng(71); L = []
for k in ('fresh', 'fallback'):
    for h in range(9, 23):
        for minute in (0, 1, 7, 15, 30, 44, 50, 51, 55, 59):
            for e in (0, 1, 3, 5, 8, 9, 11):
                L.append(f'cut|{k}|{h}|{minute}|{e}|{cut(k, h, minute, e)!r}')
        for seed in range(6):
            Q = np.array(T[k]['Q'][h]); p = np.interp(rng.random(12), np.linspace(0, 1, QN + 1), Q)
            fixed = sorted(rng.choice(np.arange(0, 60, 5), size=int(rng.integers(0, 3)), replace=False).tolist())
            if seed == 0: p = p - 0.05
            cnt = 0; entered = []
            for i, minute in enumerate(range(0, 60, 5)):
                if minute in fixed: cnt += 1; entered.append(minute); continue
                if p[i] >= cut(k, h, minute, cnt): cnt += 1; entered.append(minute)
            L.append(f'hour|{k}|{h}|{seed}|' + ','.join(repr(float(x)) for x in p) + '|' + ','.join(map(str, fixed)) + '|' + ','.join(map(str, entered)))
with gzip.GzipFile(fx_rule, 'wb', mtime=0) as f: f.write(('\n'.join(L) + '\n').encode())
S = []
for k in ('fresh', 'fallback'):
    for h in (9, 12, 16, 22):
        for slots in (12, 11, 8, 4, 1, 0):
            for minute in (0, 20, 41, 50, 57):
                for e in (0, 1, 2, 3, 6):
                    S.append(f'slots|{k}|{h}|{minute}|{e}|{slots}|{cut(k, h, minute, e, slots)!r}')
with gzip.GzipFile(fx_slots, 'wb', mtime=0) as f: f.write(('\n'.join(S) + '\n').encode())
print('rule lines', len(L), 'slots lines', len(S))

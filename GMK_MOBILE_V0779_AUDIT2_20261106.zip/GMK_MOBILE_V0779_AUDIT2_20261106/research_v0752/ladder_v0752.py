"""v0.7.52 candidate ladder + losing-streak rules, replayed on the out-of-period year."""
import pandas as pd, numpy as np, json
D = pd.read_pickle('../work/enriched_v0752.pkl')
E = pd.read_pickle('../work/event_signals_v0751.pkl')[['b', 'inst', 'dir', 'win', 'rank']].rename(columns={'inst': 'r_inst', 'dir': 'r_dir', 'win': 'r_win', 'rank': 'r_rank'})
D = D.merge(E, on='b', how='left')
fx = D.inst != 'BTCJPY'
D['agree'] = (fx & (D.f1_rel <= -2.5)) | (~fx & D.f1_rel.between(1, 3, inclusive='left'))
wk = {'S': 'B', 'A': 'B', 'B': 'C', 'C': 'C'}; we = {'S': 'B', 'A': 'C', 'B': 'C'}
D['g51'] = np.where(D.weekday, D.grade.map(lambda g: wk.get(g, g)), D.grade.map(lambda g: we.get(g, g)))
# v0.7.52: weekday B splits: B with a confirming last-minute move -> B, other v0.7.48 S/A -> C ; v0.7.48 B/C -> C
D['g52'] = D.g51
strong = D.weekday & D.grade.isin(['S', 'A'])
D.loc[strong & D.agree, 'g52'] = 'B'; D.loc[strong & ~D.agree, 'g52'] = 'C'
ev = D.r_rank.notna()
for c in ('g51', 'g52'): D.loc[ev, c] = D.loc[ev, 'r_rank']
D.loc[ev, 'win'] = D.loc[ev, 'r_win']
D['oct'] = D.date.astype(str).str[5:7] == '10'
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
def summary(T, col):
    T = T.sort_values('b'); e = T[T[col].isin(['S', 'A', 'B', 'C'])]
    daily = e.groupby('date').win.apply(lambda s: maxrun(s.values))
    return dict(entry=round(len(e) / len(T) * 100, 1), per_day=round(len(e) / T.date.nunique(), 1), win=round(e.win.mean() * 100, 2), maxrun=maxrun(e.win.values),
                days_8plus=round((daily >= 8).mean() * 100, 1), oct=round(e[e.oct].win.mean() * 100, 2))
W = D[D.weekday]
for col in ('g51', 'g52'):
    t = W.groupby(col).agg(n=('win', 'size'), win=('win', 'mean')); t['per_day'] = t.n / W.date.nunique()
    for p in ('P1', 'P2', 'P3'): t[p] = W[W.period == p].groupby(col).win.mean()
    t['oct'] = W[W.oct].groupby(col).win.mean(); t['maxrun'] = W.sort_values('b').groupby(col).win.apply(lambda s: maxrun(s.values))
    print('==', col, summary(W, col)); print(t.round(3).to_string())
# streak rules on the weekday entry sequence (v0.7.52 ladder)
seq = W.sort_values('b'); seq = seq[seq.g52.isin(['S', 'A', 'B', 'C'])]
def pause_rule(k, m):
    taken = []; losses = 0; skip_until = -1
    for i, (b, w, d) in enumerate(zip(seq.b.values, seq.win.values, seq.date.values)):
        if b < skip_until: continue
        taken.append((w, d)); losses = losses + 1 if w == 0 else 0
        if losses >= k: skip_until = b + m * 300; losses = 0
    T = pd.DataFrame(taken, columns=['win', 'date'])
    daily = T.groupby('date').win.apply(lambda s: maxrun(s.values))
    return dict(rule=f'{k}連敗で{m}枠休む', per_day=round(len(T) / W.date.nunique(), 1), win=round(T.win.mean() * 100, 2), maxrun=maxrun(T.win.values), days_8plus=round((daily >= 8).mean() * 100, 1))
rules = [pause_rule(k, m) for k in (3, 4, 5) for m in (1, 3, 6, 12)]
for r in rules: print(r)
for keep, name in ((['S', 'A', 'B'], 'S/A/Bだけ'), (['S', 'A'], 'S/Aだけ'), (['S', 'A', 'B', 'C'], '全部')):
    e = W.sort_values('b'); e = e[e.g52.isin(keep)]; daily = e.groupby('date').win.apply(lambda s: maxrun(s.values))
    print(name, 'per_day', round(len(e) / W.date.nunique(), 1), 'win', round(e.win.mean() * 100, 2), 'maxrun', maxrun(e.win.values), 'days8+', round((daily >= 8).mean() * 100, 1),
          'oct', round(e[e.oct].win.mean() * 100, 2))
D.to_pickle('../work/ladder_v0752.pkl'); json.dump(rules, open('../work/streak_rules_v0752.json', 'w'), ensure_ascii=False)

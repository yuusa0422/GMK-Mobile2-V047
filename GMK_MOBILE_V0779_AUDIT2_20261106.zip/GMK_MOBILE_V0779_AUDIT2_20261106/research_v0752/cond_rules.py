"""Pre-specified condition rules on every instrument (not only the model's choice), one trade per slot, by period."""
import pandas as pd, numpy as np
from rule_mine import load
F = load()                      # weekday, live_ok rows, with session columns, y = sign(move3), period, octyr
X = pd.read_pickle('../work/design_x_fresh.pkl')[['b', 'inst', 'dir', 'win', 'grade']].rename(columns={'inst': 'm_inst', 'dir': 'm_dir', 'win': 'm_win', 'grade': 'g48'})
EV = set(pd.read_pickle('../work/event_signals_v0751.pkl').b)
FX = F[(F.inst != 'BTCJPY') & ~F.b.isin(EV)].copy(); BT = F[(F.inst == 'BTCJPY') & ~F.b.isin(EV)].copy()
def per_slot(D, mask, val, sign):
    S = D[mask].copy(); S['st'] = val[mask].abs(); S = S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b')
    S['dir'] = sign[mask.values][S.index.map(lambda i: list(D[mask].index).index(i))] if False else np.sign(val[S.index]) * sign
    return S
rows = []
def ev(name, D, m, v, s):
    S = D[m].copy(); S['st'] = v[m].abs(); S = S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b')
    S['dir'] = np.sign(v[S.index]) * s; S['win'] = (S.y * S.dir > 0).astype(float)
    S = S.merge(X, on='b', how='left'); agree = (S.m_inst == S.inst) & (S.m_dir == S.dir)
    r = dict(rule=name, n=len(S), per_day=len(S) / F.date.nunique(), win=S.win.mean(), model_same_slot=S.m_win.mean(), agree_share=agree.mean(),
             win_agree=S[agree].win.mean(), win_disagree=S[~agree].win.mean())
    for p in ('P1', 'P2', 'P3'): r[p] = S[S.period == p].win.mean()
    r['O25'] = S[S.octyr == 'O25'].win.mean(); r['O26'] = S[S.octyr == 'O26'].win.mean(); r['n_oct'] = int((S.octyr != '').sum())
    rows.append(r)
for t in (1.5, 2.0, 2.5, 3.0, 4.0): ev(f'FX 1分急変 |f1|>={t} 逆張り', FX, FX.f1.abs() >= t, FX.f1, -1)
for t in (1.5, 2.0, 2.5, 3.0): ev(f'FX 15分 |r15|>={t} 逆張り', FX, FX.r15.abs() >= t, FX.r15, -1)
for t in (1.5, 2.0, 2.5): ev(f'FX 5分 |r5|>={t} 逆張り', FX, FX.r5.abs() >= t, FX.r5, -1)
ev('FX 60分の端(±1)&|f1|>=1 逆張り', FX, (FX.pos60L.abs() >= 0.999) & (FX.f1.abs() >= 1), FX.pos60L, -1)
for lo, hi in ((0.5, 3.0), (1.0, 3.0), (0.5, 1.5)): ev(f'BTC 1分 {lo}<=|f1|<{hi} 順張り', BT, BT.f1.abs().between(lo, hi, inclusive='left'), BT.f1, 1)
ev('BTC 1分 |f1|>=3 逆張り', BT, BT.f1.abs() >= 3, BT.f1, -1)
R = pd.DataFrame(rows); pd.set_option('display.width', 250)
print(R.round(3).to_string())
R.to_pickle('../work/cond_rules.pkl')

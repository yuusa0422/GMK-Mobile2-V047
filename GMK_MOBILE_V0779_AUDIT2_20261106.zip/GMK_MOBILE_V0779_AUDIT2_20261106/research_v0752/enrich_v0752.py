"""Chosen-trade dataset (out-of-period stage 1) enriched with candle shape, session, cross-market context, trade-relative signs."""
import pandas as pd, numpy as np
from session_feats import add_session
X = pd.read_pickle('../work/design_x_fresh.pkl')
F = pd.read_pickle('../work/pattern_frame.pkl')
keep = ['b', 'inst', 'body_r', 'up_w', 'lo_w', 'bar_dir', 'engulf', 'streak', 'brk15', 'brk60', 'rsi', 'hh3', 'll3', 'rdist', 'rng_x', 'dmean60', 'pos60L', 'pos60', 'pos15', 'bbz', 'r3', 'r10', 'r30', 'f15', 'yen5', 'yen15']
D = X.merge(F[keep], on=['b', 'inst'], how='left', suffixes=('', '_pf'))
# cross-market context at the slot (FX only): how many FX moved the same way in the last minute, dispersion
FX = F[(F.inst != 'BTCJPY')]
g = FX.groupby('b')
ctx = pd.DataFrame({'fx_f1_mean': g.f1.mean(), 'fx_f1_absmean': g.f1.apply(lambda s: s.abs().mean()), 'fx_r15_mean': g.r15.mean(), 'fx_rv_mean': g.rv60.mean(),
                    'fx_pos60_mean': g.pos60L.mean()}).reset_index()
D = D.merge(ctx, on='b', how='left')
# best-vs-second gap among all candidates (single-model OOS probabilities)
O = pd.read_pickle('../work/evidence_model_oos.pkl')[True][['b', 'inst', 'p_up', 'p_dn']]
O['pmax'] = O[['p_up', 'p_dn']].max(axis=1)
srt = O.sort_values(['b', 'pmax'], ascending=[True, False])
second = srt.groupby('b').pmax.nth(1).rename('p_second'); first = srt.groupby('b').pmax.first().rename('p_first')
D = D.join(first, on='b').join(second, on='b')
D['gap2'] = D.p_first - D.p_second
D['margin'] = D.p - D.p_opp
D = add_session(D)
d = D.dir
for c in ['f1', 'f2', 'f5', 'r1', 'r3', 'r5', 'r10', 'r15', 'r30', 'r60', 'pos15L', 'bbzL', 'pos60L', 'pos60', 'pos15', 'bbz', 'dmean60', 'rdist', 'yenf1', 'yen5', 'yen15',
          'bar_dir', 'engulf', 'streak', 'brk15', 'brk60', 'fx_f1_mean', 'fx_r15_mean', 'fx_pos60_mean', 'f15']:
    if c in D: D[c + '_rel'] = D[c] * d
D['rsi_rel'] = (D.rsi - 50) * d
D['hhll_rel'] = (D.hh3 - D.ll3) * d
D['period'] = np.where(D.date.astype(str) < '2026-02-01', 'P1', np.where(D.date.astype(str) < '2026-06-01', 'P2', 'P3'))
D['rwin'] = ((D.move3 * -D.dir) > 0).astype(float)          # reversed trade wins (draw = loss both ways)
D.to_pickle('../work/enriched_v0752.pkl')
print(D.shape, D.weekday.mean(), D[['win', 'rwin', 'tie']].mean().round(4).to_dict())

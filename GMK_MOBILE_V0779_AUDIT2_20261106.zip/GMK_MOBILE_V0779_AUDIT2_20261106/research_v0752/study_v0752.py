import pandas as pd, numpy as np, json, warnings
warnings.filterwarnings('ignore')
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
D = pd.read_pickle('../work/enriched_v0752.pkl')
FEATS = ['pct', 'E', 'margin', 'gap2', 'p', 'abs_f1', 'abs_r1', 'lrv', 'rv30_60', 'tie58', 'zero30', 'regconf', 'body_r', 'up_w', 'lo_w', 'rng_x', 'rsi',
         'fx_f1_absmean', 'fx_rv_mean', 'hour', 'dow', 'jst_min', 'lon_min', 'ny_min', 'minute'] + [c for c in D.columns if c.endswith('_rel')]
FEATS = [f for f in FEATS if f in D.columns]
def single_scan(W, tag):
    rows = []
    for f in FEATS:
        x = W[f]
        if x.nunique() <= 6: bins = x
        else: bins = pd.qcut(x.rank(method='first'), 5, labels=False)
        for v, s in W.groupby(bins):
            r = dict(seg=tag, feature=f, bin=str(v), lo=float(x[s.index].min()), hi=float(x[s.index].max()), n=len(s), win=s.win.mean(), rwin=s.rwin.mean())
            for p in ('P1', 'P2', 'P3'): r[p] = s[s.period == p].win.mean(); r['r' + p] = s[s.period == p].rwin.mean()
            r['oct'] = s[s.october == 1].win.mean()
            rows.append(r)
    R = pd.DataFrame(rows)
    R['min3'] = R[['P1', 'P2', 'P3']].min(axis=1); R['max3'] = R[['P1', 'P2', 'P3']].max(axis=1); R['rmin3'] = R[['rP1', 'rP2', 'rP3']].min(axis=1)
    return R
pd.set_option('display.width', 250)
out = {}
for wk, tag in ((True, 'weekday'), (False, 'weekend')):
    W = D[D.weekday == wk]
    R = single_scan(W, tag); R.to_pickle(f'../work/single_scan_{tag}.pkl')
    base = W.win.mean()
    print(f'== {tag} base win {base:.4f} rwin {W.rwin.mean():.4f}')
    print('-- stable winners (all three periods >= base+2pt)')
    print(R[R.min3 >= base + 0.02].sort_values('min3', ascending=False).head(15)[['feature', 'bin', 'lo', 'hi', 'n', 'win', 'P1', 'P2', 'P3', 'oct']].round(3).to_string())
    print('-- stable losers (all three <= base-2pt)')
    print(R[R.max3 <= base - 0.02].sort_values('max3').head(15)[['feature', 'bin', 'lo', 'hi', 'n', 'win', 'P1', 'P2', 'P3', 'rwin', 'rmin3', 'oct']].round(3).to_string())
    print('-- reversal winners (reversed trade >= 53% in all three periods)')
    print(R[R.rmin3 >= 0.53].sort_values('rmin3', ascending=False).head(10)[['feature', 'bin', 'lo', 'hi', 'n', 'win', 'rwin', 'rP1', 'rP2', 'rP3']].round(3).to_string())
    # ML second stage, rotation by period
    FE = [f for f in FEATS if W[f].notna().sum() > 1000 and W[f].nunique() > 1]
    print('ML features', len(FE), 'dropped', sorted(set(FEATS) - set(FE)))
    P = np.full(len(W), np.nan); PL = np.full(len(W), np.nan)
    for t in ('P1', 'P2', 'P3'):
        tr = (W.period != t).values; te = (W.period == t).values
        m = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.04, max_iter=250, min_samples_leaf=300, l2_regularization=1.0, random_state=1)
        m.fit(W[FE][tr], W.win[tr]); P[te] = m.predict_proba(W[FE][te])[:, 1]
    W = W.assign(pml=P)
    W['dec'] = W.groupby('period').pml.transform(lambda s: pd.qcut(s.rank(method='first'), 10, labels=False))
    W['decE'] = W.groupby('period').E.transform(lambda s: pd.qcut(s.rank(method='first'), 10, labels=False))
    t = W.groupby('dec').agg(n=('win', 'size'), win=('win', 'mean'), rwin=('rwin', 'mean'))
    for p in ('P1', 'P2', 'P3'): t[p] = W[W.period == p].groupby('dec').win.mean()
    t['oct'] = W[W.october == 1].groupby('dec').win.mean()
    tE = W.groupby('decE').agg(winE=('win', 'mean'))
    print('-- ML decile (out of period) vs strength E decile'); print(t.join(tE).round(3).to_string())
    W[['b', 'pml', 'dec']].to_pickle(f'../work/ml_oos_{tag}.pkl')

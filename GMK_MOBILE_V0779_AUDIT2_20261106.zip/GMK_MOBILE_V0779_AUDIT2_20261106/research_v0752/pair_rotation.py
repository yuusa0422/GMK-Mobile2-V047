"""Pair-condition rotation on the app's chosen weekday trades: win patterns (upgrade) and lose patterns (reverse), with chance benchmark."""
import pandas as pd, numpy as np, itertools, json
D = pd.read_pickle('../work/enriched_v0752.pkl'); D = D[D.weekday].reset_index(drop=True)
EV = set(pd.read_pickle('../work/event_signals_v0751.pkl').b); D = D[~D.b.isin(EV)].reset_index(drop=True)
FEATS = ['pct', 'E', 'margin', 'p', 'abs_f1', 'abs_r1', 'lrv', 'rv30_60', 'regconf', 'body_r', 'up_w', 'lo_w', 'rng_x', 'rsi', 'fx_f1_absmean', 'fx_rv_mean', 'hour', 'dow'] + \
        [c for c in D.columns if c.endswith('_rel') and D[c].nunique() > 3]
Q = {}
for f in FEATS:
    x = D[f]
    Q[f] = (x.astype(int).clip(-3, 3) + 3).values if x.nunique() <= 7 else pd.qcut(x.rank(method='first'), 5, labels=False).values
names = list(Q)
def run(win, rwin, per, min_n=150, hi=0.58, lo=0.43):
    res = {'win': [], 'rev': []}
    for test in ('P1', 'P2', 'P3'):
        tr = per != test; te = per == test
        up_rows = []; rev_rows = []
        for a, b in itertools.combinations(names, 2):
            code = Q[a] * 10 + Q[b]
            df = pd.DataFrame({'c': code, 'w': win, 'r': rwin, 'p': per})
            g_tr = df[tr].groupby(['c', 'p']).w.agg(['sum', 'size']).unstack()
            n_tr = g_tr['size'].sum(axis=1); rate_tr = g_tr['sum'].sum(axis=1) / n_tr
            per_min = (g_tr['sum'] / g_tr['size']).min(axis=1); per_max = (g_tr['sum'] / g_tr['size']).max(axis=1)
            ok_up = (n_tr >= min_n) & (rate_tr >= hi) & (per_min >= hi - 0.03)
            ok_dn = (n_tr >= min_n) & (rate_tr <= lo) & (per_max <= lo + 0.03)
            if ok_up.any() or ok_dn.any():
                g_te = df[te].groupby('c').agg(w=('w', 'sum'), r=('r', 'sum'), n=('w', 'size'))
                for c in ok_up[ok_up].index:
                    if c in g_te.index: up_rows.append((f'{a}={c // 10}&{b}={c % 10}', g_te.loc[c, 'n'], g_te.loc[c, 'w']))
                for c in ok_dn[ok_dn].index:
                    if c in g_te.index: rev_rows.append((f'{a}={c // 10}&{b}={c % 10}', g_te.loc[c, 'n'], g_te.loc[c, 'r']))
        res['win'].append((test, len(up_rows), int(sum(x[1] for x in up_rows)), sum(x[2] for x in up_rows) / max(sum(x[1] for x in up_rows), 1)))
        res['rev'].append((test, len(rev_rows), int(sum(x[1] for x in rev_rows)), sum(x[2] for x in rev_rows) / max(sum(x[1] for x in rev_rows), 1)))
    return res
per = D.period.values
real = run(D.win.values, D.rwin.values, per)
print('REAL win patterns (test period, cells, trades(with overlap), test win):', real['win'])
print('REAL lose patterns reversed (test period, cells, trades, reversed win):', real['rev'])
rng = np.random.default_rng(3); sh = D.groupby('date').win.transform(lambda s: rng.permutation(s.values)).values
chance = run(sh, 1 - sh, per)
print('CHANCE win:', chance['win']); print('CHANCE rev:', chance['rev'])
json.dump({'real': real, 'chance': chance}, open('../work/pair_rotation.json', 'w'), default=float)

"""Use the model's recent hit rate (every slot's best trade over the last hour, outcomes known at decision time: slots B-65..B-10 min)
to move the hour rule's cut: adj = k x (0.5 - hit). Same entries per hour (the 70% rule), only which slots of the hour.
Rotation P1/P2/P3 and 2023-24 (production fit, in-sample tables). Also adj from the slot-best result 10 minutes ago only."""
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
src = sys.argv[1] if len(sys.argv) > 1 else 'v0771_sc_fresh'
rot = pd.read_pickle(f'../work/{src}_rot.pkl'); ins = pd.read_pickle('../work/v0771_sc_fresh_ins.pkl'); ys = pd.read_pickle('../work/v0771_sc_fresh_y.pkl')
def hits(S):
    C, _ = build(S[S.inst.isin(INST9)])
    W = pd.Series({b: float(C[b].iloc[0].w5) for b in C}).sort_index(); bs = W.index.values; ws = W.values; cs = np.r_[0, np.cumsum(ws)]
    lo = np.searchsorted(bs, bs - 3900); hi = np.searchsorted(bs, bs - 600, side='right'); n = hi - lo
    h = np.where(n >= 6, (cs[hi] - cs[lo]) / np.maximum(n, 1), 0.5)
    i10 = np.searchsorted(bs, bs - 600); prev = np.where((i10 < len(bs)) & (bs[np.minimum(i10, len(bs) - 1)] == bs - 600), ws[np.minimum(i10, len(bs) - 1)], 0.5)
    return dict(zip(bs, h)), dict(zip(bs, prev))
Hc, Pc = hits(rot); Hi, Pi = hits(ins); Hy, Py = hits(ys)
for kind in ('hit', 'prev'):
    for k in ((0.0, 0.01, 0.02, 0.04) if kind == 'hit' else (0.01, 0.02)):
        Hm = {**(Hc if kind == 'hit' else Pc)}; Hm2 = {**(Hi if kind == 'hit' else Pi), **(Hy if kind == 'hit' else Py)}
        E = rotation(rot, insts=INST9, adj=lambda r: k * (0.5 - Hm.get(r.b, 0.5))); r_ = summ(E)
        y, _ = years(ins, ys, INST9, adj=lambda r: k * (0.5 - Hm2.get(r.b, 0.5)))
        print(kind, k, json.dumps(dict(win=r_['win'], P=r_['P'], sep_oct=r_['sep_oct'], per_day=r_['per_day'], y2324=y['win'], y_per_day=y['per_day'])), flush=True)

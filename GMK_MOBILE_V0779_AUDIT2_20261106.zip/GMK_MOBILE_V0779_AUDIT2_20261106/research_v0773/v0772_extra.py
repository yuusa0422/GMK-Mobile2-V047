"""v0.7.72 extra columns at the weekday 5-minute boundaries (same grid as v0770_feat): normalised 5- and 10-minute moves from the
boundary OPEN (ret5n, ret10n, move10) for learning weights / horizons, and crypto volume inputs from the Coinbase 1-minute volume
(window bars B-3720..B-120 only, the forming bar is not used): relvol1 = volume of the last bar / mean volume of the 60 bars,
relvol5 = mean of the last 5 / mean of 60, vflow5 = sum(sign(close-open) x volume) / sum(volume) over the last 5 bars. FX rows: NaN."""
import sys, numpy as np, pandas as pd
exec(open('v0770_feat.py').read().split("which = sys.argv[1]")[0])
which = sys.argv[1]; src = {k: v for k, v in SRC[which].items() if k not in ('EURUSD', 'AUDUSD')}
CR = ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
def loadv(path, sc):
    d = pd.read_csv(path); d['t'] = d.epoch_ms // 1000; d = d.drop_duplicates('t').set_index('t').sort_index()
    for c in ('open', 'high', 'low', 'close'): d[c] = d[c] / sc
    if 'volume' not in d: d['volume'] = np.nan
    return d[['open', 'close', 'volume']]
bars = {s: loadv(p, sc) for s, (p, sc) in src.items()}
t0 = min(b.index.min() for b in bars.values()); t1 = max(b.index.max() for b in bars.values())
grid = np.arange(t0 - t0 % 60 - 2000 * 60, t1 + 2000 * 60, 60)
B = grid[grid % 300 == 0]; ts = pd.to_datetime(B, unit='s', utc=True).tz_convert('Asia/Tokyo')
keep = (ts.dayofweek <= 4) & (ts.hour >= 9) & (ts.hour <= 22); B = B[keep]; B = B[(B > t0 + 1500 * 60) & (B < t1 - 900)]
idx = lambda t: ((t - grid[0]) // 60).astype(np.int64)
out = []
for s, d in bars.items():
    g = d.reindex(grid); o, c, v = g.open.values, g.close.values, g.volume.values
    lg = np.log(c); ret = np.r_[np.nan, np.diff(lg)]; c2 = np.r_[0, np.cumsum(np.nan_to_num(ret ** 2))]
    i60 = idx(B - 120); norm = np.maximum(np.sqrt(np.maximum(c2[i60 + 1] - c2[i60 - 59], 0) / 60.0), 1e-8)
    ob = o[idx(B)]; o5 = o[idx(B + 300)]; o10 = o[idx(B + 600)]
    F = pd.DataFrame(dict(b=B, inst=s, ret5n=np.log(o5 / ob) / (norm * np.sqrt(5)), ret10n=np.log(o10 / ob) / (norm * np.sqrt(10)), move10=np.sign(o10 - ob)))
    if s in CR:
        V = np.stack([v[i60 - 59 + k] for k in range(60)], axis=1); m60 = np.nanmean(V, axis=1)
        sg = np.stack([np.sign(c[i60 - 4 + k] - o[i60 - 4 + k]) for k in range(5)], axis=1); V5 = V[:, 55:]
        F['relvol1'] = V[:, 59] / np.maximum(m60, 1e-12); F['relvol5'] = V5.mean(axis=1) / np.maximum(m60, 1e-12)
        F['vflow5'] = (sg * V5).sum(axis=1) / np.maximum(V5.sum(axis=1), 1e-12)
    out.append(F)
X = pd.concat(out, ignore_index=True); X.to_pickle(f'../work/v0772_extra_{which}.pkl')
print(which, len(X), X.groupby('inst')[['ret5n', 'relvol1', 'relvol5', 'vflow5']].mean().round(3).to_string())

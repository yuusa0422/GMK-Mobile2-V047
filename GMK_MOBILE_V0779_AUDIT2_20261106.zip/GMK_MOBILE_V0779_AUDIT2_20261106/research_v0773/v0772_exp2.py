"""v0.7.72 research 2 (same entry count): how the weekday nine-pair model learns. Variants: wmag (weight = size of the 5-minute move),
h10 (average with a model of the 10-minute direction), vol (crypto volume inputs), split (separate FX / crypto models), nodraw
(draws left out of the training rows; still losses when scored), div (+ a differently built model), hp1 / hp2 (other settings).
Rotation P1/P2/P3, fresh design, seeds so..so+ns-1. Usage: v0772_exp2.py name@ns@so ..."""
import sys, time
exec(open('v0772_exp.py').read().split("\nif __name__ == '__main__':")[0])
X0 = pd.read_pickle('../work/v0772_extra_cur.pkl')
Dc = add(load('cur', True)); Dc = Dc[Dc.inst.isin(INST9) & Dc.move5.notna()].merge(X0, on=['b', 'inst'], how='left').reset_index(drop=True)
import os
if any(a.split('@')[0] in ('ind', 'tvin') for a in sys.argv[1:]):
    Dc = Dc.merge(pd.read_pickle('../work/v0772_ext_cur.pkl')[['b', 'inst', 'rsi', 'macdh', 'ma520', 'stoch']], on=['b', 'inst'], how='left')
    if os.path.exists('../work/v0772_tv_cur.pkl'): Dc = Dc.merge(pd.read_pickle('../work/v0772_tv_cur.pkl'), on=['b', 'inst'], how='left')
VOL_S, VOL_U = ['vflow5'], ['relvol1', 'relvol5']
def design(D, d, name):
    S, Fr, U = S0, F0, U0
    if name == 'vol': S, U = S0 + VOL_S, U0 + VOL_U
    if name == 'ind': S = S0 + ['rsi', 'macdh', 'ma520', 'stoch']
    if name == 'tvin': S = S0 + ['tvr', 'tv_ma', 'tv_osc']
    return des(D, d, S, Fr, U)
def fit(tr, name, seeds, label='move5', cfg=None):
    if name == 'nodraw': tr = tr[tr[label] != 0]
    X = np.vstack([design(tr, 1, name), design(tr, -1, name)]); y = np.r_[tr[label].values == 1, tr[label].values == -1].astype(int)
    w = None
    if name == 'wmag': a = np.clip(np.abs(np.nan_to_num(tr.ret5n.values)), 0.1, 3.0); w = np.r_[a, a]
    c = dict(CFG); c.update(cfg or {})
    return [HistGradientBoostingClassifier(random_state=s, **c).fit(X, y, sample_weight=w) for s in seeds]
def pred(ms, T, name):
    return (np.mean([m.predict_proba(design(T, 1, name))[:, 1] for m in ms], 0), np.mean([m.predict_proba(design(T, -1, name))[:, 1] for m in ms], 0))
HP = {'hp1': dict(learning_rate=0.05, max_iter=250), 'hp2': dict(max_leaf_nodes=15, min_samples_leaf=4000), 'div2': dict(learning_rate=0.03, max_iter=400, max_leaf_nodes=15, min_samples_leaf=4000)}
for arg in sys.argv[1:]:
    name, ns, so = (arg.split('@') + ['5', '0'])[:3]; seeds = range(int(so), int(so) + int(ns)); tag = f'{name}_s{ns}_o{so}'; t0 = time.time(); parts = []
    for te in ('P1', 'P2', 'P3'):
        tr = Dc[Dc.period != te]; T = Dc[Dc.period == te]
        if name == 'split':
            pu = np.zeros(len(T)); pdn = np.zeros(len(T))
            for grp in (YEN, CR):
                mt = T.inst.isin(grp).values; ms = fit(tr[tr.inst.isin(grp)], 'base', seeds); a, b = pred(ms, T[mt], 'base'); pu[mt] = a; pdn[mt] = b
        elif name == 'h10':
            ms = fit(tr, 'base', seeds); a, b = pred(ms, T, 'base')
            m10 = fit(tr[tr.move10.notna()], 'base', seeds, label='move10'); c, d = pred(m10, T, 'base'); pu, pdn = (a + c) / 2, (b + d) / 2
        elif name == 'div':
            ms = fit(tr, 'base', seeds); a, b = pred(ms, T, 'base'); m2 = fit(tr, 'base', seeds, cfg=HP['div2']); c, d = pred(m2, T, 'base'); pu, pdn = (a + c) / 2, (b + d) / 2
        else:
            ms = fit(tr, name, seeds, cfg=HP.get(name)); pu, pdn = pred(ms, T, name)
        parts.append(T[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=pu, pd=pdn))
    pd.concat(parts, ignore_index=True).to_pickle(f'../work/v0772_rot_{tag}.pkl'); print('TRAINED', tag, round(time.time() - t0), 's', flush=True)

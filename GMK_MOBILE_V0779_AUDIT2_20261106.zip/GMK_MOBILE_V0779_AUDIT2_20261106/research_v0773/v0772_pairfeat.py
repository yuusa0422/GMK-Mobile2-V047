"""v0.7.72 crypto pair inputs: the BTC/ETH ratio (log BTC close - log ETH close, Coinbase USD minute bars) at every 5-minute boundary B,
with the window of the candle model (61 closes ending at the bar opening at B-120, live = close of the bar opening at B-60):
rr5 / rr15 / rr60 = ratio move over 5 / 15 / 60 minutes in units of the ratio's 1-minute volatility (60 returns), rpos60 = position
of the last close in the 61 closes (-1 .. +1), rbbz = (last - mean of 20) / sd of 20, rf1 = live ratio - last close (in vol units).
BTC rows use these, ETH rows the negatives (ETH relative to BTC). NaN unless all 61 closes and the live bar of both coins exist."""
import sys, numpy as np, pandas as pd
which = sys.argv[1]
def load(p):
    d = pd.read_csv(p, usecols=['epoch_ms', 'close']); d['t'] = d.epoch_ms // 1000
    return d.drop_duplicates('t').set_index('t').close.sort_index()
b_ = load(f'../crypto_in/syn/BTCUSD_{which}.csv.gz'); e_ = load(f'../crypto_in/syn/ETHUSD_{which}.csv.gz')
t0, t1 = max(b_.index.min(), e_.index.min()), min(b_.index.max(), e_.index.max())
grid = np.arange(t0 - t0 % 60, t1 + 60, 60)
rc = (np.log(b_.reindex(grid).values) - np.log(e_.reindex(grid).values))
B = grid[(grid % 300 == 0) & (grid >= grid[0] + 130 * 60) & (grid <= grid[-1] - 60)]
idx = lambda t: ((t - grid[0]) // 60).astype(np.int64)
i60 = idx(B - 120); il = idx(B - 60)
W = np.stack([rc[i60 - 60 + k] for k in range(61)], axis=1)          # 61 closes, oldest first
ok = ~np.isnan(W).any(axis=1) & ~np.isnan(rc[il])
ret = np.diff(W, axis=1); norm = np.maximum(np.sqrt((ret ** 2).mean(axis=1)), 1e-8)
last = W[:, 60]
F = pd.DataFrame({'b': B})
for k in (5, 15, 60): F[f'rr{k}'] = (last - W[:, 60 - k]) / (norm * np.sqrt(k))
lo, hi = W.min(axis=1), W.max(axis=1); F['rpos60'] = (last - lo) / np.maximum(hi - lo, 1e-12) * 2 - 1
m20 = W[:, 41:].mean(axis=1); sd20 = np.sqrt(np.maximum(W[:, 41:].var(axis=1), 1e-16)); F['rbbz'] = (last - m20) / sd20
F['rf1'] = (rc[il] - last) / norm
F.loc[~ok, ['rr5', 'rr15', 'rr60', 'rpos60', 'rbbz', 'rf1']] = np.nan
F.to_pickle(f'../work/v0772_pair_{which}.pkl'); print(which, len(F), 'ok', int(ok.sum()), F.describe().loc[['mean', 'std']].round(3).to_string())

"""TradingView-style technical rating (tradingview-ta "RECOMMENDATION") on 1-minute bars, at the bar opening at B-120 (the last bar the
app's decision sees): moving averages (close vs SMA/EMA 10, 20, 30, 50, 100, 200) and oscillators (RSI14, Stochastic %K14/%D3,
CCI20, MACD 12/26/9, Momentum10, Williams %R14) -> each +1 buy / -1 sell / 0 neutral, rating = (mean MA + mean OSC) / 2 in [-1, 1]
(TradingView: > 0.5 STRONG_BUY, > 0.1 BUY, < -0.1 SELL, < -0.5 STRONG_SELL). Needs 230 bars back; NaN otherwise."""
import sys, numpy as np, pandas as pd
exec(open('v0770_feat.py').read().split("which = sys.argv[1]")[0])
which = sys.argv[1]; src = {k: v for k, v in SRC[which].items() if k not in ('EURUSD', 'AUDUSD')}
def loadc(path, sc):
    d = pd.read_csv(path, usecols=['epoch_ms', 'high', 'low', 'close']); d['t'] = d.epoch_ms // 1000
    return d.drop_duplicates('t').set_index('t').sort_index()[['high', 'low', 'close']] / sc
out = []
for s, (p, sc) in src.items():
    d = loadc(p, sc); t0, t1 = d.index.min(), d.index.max(); grid = np.arange(t0 - t0 % 60, t1 + 60, 60)
    g = d.reindex(grid); c = g.close; h = g.high; l = g.low
    feats = {}
    ma = [np.sign(c - c.rolling(n).mean()) for n in (10, 20, 30, 50, 100, 200)] + [np.sign(c - c.ewm(span=n, adjust=False).mean()) for n in (10, 20, 30, 50, 100, 200)]
    dlt = c.diff(); up = dlt.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); dn = (-dlt.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    rsi = 100 - 100 / (1 + up / dn.replace(0, np.nan)); rsi_s = np.where(rsi < 30, 1, np.where(rsi > 70, -1, 0))
    k = 100 * (c - l.rolling(14).min()) / (h.rolling(14).max() - l.rolling(14).min()); kk = k.rolling(3).mean(); dd = kk.rolling(3).mean()
    st_s = np.where((kk < 20) & (kk > dd), 1, np.where((kk > 80) & (kk < dd), -1, 0))
    tp = (h + l + c) / 3; cci = (tp - tp.rolling(20).mean()) / (0.015 * tp.rolling(20).apply(lambda x: np.mean(np.abs(x - x.mean())), raw=True))
    cci_s = np.where(cci < -100, 1, np.where(cci > 100, -1, 0))
    macd = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean(); sig = macd.ewm(span=9, adjust=False).mean(); macd_s = np.sign(macd - sig)
    mom = c - c.shift(10); mom_s = np.sign(mom - mom.shift(1))
    wr = -100 * (h.rolling(14).max() - c) / (h.rolling(14).max() - l.rolling(14).min()); wr_s = np.where(wr < -80, 1, np.where(wr > -20, -1, 0))
    MA = pd.concat(ma, axis=1).mean(axis=1); OSC = pd.DataFrame({'a': rsi_s, 'b': st_s, 'c': cci_s, 'd': macd_s, 'e': mom_s, 'f': wr_s}, index=grid).mean(axis=1)
    rating = (MA + OSC) / 2
    valid = c.notna().rolling(230).sum() == 230
    rating = rating.where(valid)
    B = grid[grid % 300 == 0]; R = pd.DataFrame({'b': B, 'inst': s, 'tvr': rating.reindex(B - 120).values, 'tv_ma': MA.where(valid).reindex(B - 120).values,
                                                  'tv_osc': OSC.where(valid).reindex(B - 120).values})
    out.append(R.dropna()); print(s, len(R.dropna()), flush=True)
X = pd.concat(out, ignore_index=True); X.to_pickle(f'../work/v0772_tv_{which}.pkl'); print(X[['tvr', 'tv_ma', 'tv_osc']].describe().round(3).to_string())

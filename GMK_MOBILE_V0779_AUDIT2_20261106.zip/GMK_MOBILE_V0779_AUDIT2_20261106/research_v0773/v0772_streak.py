"""Losing streaks: are they more than chance? Outcomes known at decision time only (5-minute trades: the trade entered 10+ minutes
before). (1) win rate of an ENTRY after the last known k entries were all losses / wins; (2) the model's recent hit rate on every slot's
best trade (entered or not) over the last hour, as known at decision time, vs the next ENTRY's win; (3) longest losing streak and the
number of 5+ loss streaks vs a shuffled order (same days, same win rate)."""
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
rot = pd.read_pickle('../work/v0771_sc_fresh_rot.pkl'); E = rotation(rot, insts=INST9).sort_values('b').reset_index(drop=True)
E['day'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.date
E['jm'] = np.where(E.g.isin(['S', 'A']), 3, 5)
# (1) previous known outcomes within the day
rows = []
for day, g in E.groupby('day'):
    bs = g.b.values; ws = g.w.values; ends = bs + g.jm.values * 60
    for i in range(len(g)):
        known = ws[(ends <= bs[i] - 10)][-3:]
        rows.append((len(known), known.tolist(), ws[i]))
R = pd.DataFrame(rows, columns=['n', 'last', 'w'])
for k in (1, 2, 3):
    sub = R[R.n >= k]; lastk = sub['last'].map(lambda x: tuple(x[-k:]))
    t = sub.groupby(lastk).w.agg(['mean', 'size']); t['mean'] = (t['mean'] * 100).round(2); print('last', k, 'known results ->', t.to_string().replace('\n', ' | '))
# (2) model hit rate over the last hour of slots (all slots' best trade, outcome known)
C, _ = build(rot[rot.inst.isin(INST9)])
S = pd.DataFrame([(b, float(C[b].iloc[0].w5)) for b in sorted(C)], columns=['b', 'w5']).set_index('b').w5
hit = []
for b in E.b.values:
    win_ = S.loc[b - 3600 - 300:b - 600]; hit.append(win_.mean() if len(win_) >= 6 else np.nan)
E['hit1h'] = hit
q = pd.qcut(E.hit1h, 5, duplicates='drop'); print('model hit rate last hour (all slots) quintile -> ENTRY win', (E.groupby(q).w.mean() * 100).round(2).to_dict())
# (3) streaks vs shuffled
def streaks(ws):
    runs = []; c = 0
    for x in ws:
        if x == 0: c += 1
        else:
            if c: runs.append(c)
            c = 0
    if c: runs.append(c)
    return np.array(runs)
real = np.concatenate([streaks(g.w.values) for _, g in E.groupby('day')])
rng = np.random.default_rng(1); sh = []
for _ in range(20):
    sh.append(np.concatenate([streaks(rng.permutation(g.w.values)) for _, g in E.groupby('day')]))
print('loss streaks >=5 per 1000 trades: real', round((real >= 5).sum() / len(E) * 1000, 2), 'shuffled', round(np.mean([(s >= 5).sum() for s in sh]) / len(E) * 1000, 2),
      '| >=8 real', int((real >= 8).sum()), 'shuffled', round(np.mean([(s >= 8).sum() for s in sh]), 1), '| longest real', int(real.max()), 'shuffled', round(np.mean([s.max() for s in sh]), 1))

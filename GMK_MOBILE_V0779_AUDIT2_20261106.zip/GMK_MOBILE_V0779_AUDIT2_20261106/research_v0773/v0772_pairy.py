"""2023-24 check (data never used for fitting): production-style fit on the whole current year for base and pair (5 seeds), scored on
2023-24 with the app replay and hour tables from the in-sample current-year scores (as v0770_eval.years)."""
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
exec(open('v0772_exp.py').read().split("\nif __name__ == '__main__':")[0])
PACE['a'] = 0.8
Dc = add(load('cur', True)); Dc = Dc[Dc.inst.isin(INST9) & Dc.move5.notna()].reset_index(drop=True)
Dy = add(load('y', True)); Dy = Dy[Dy.inst.isin(INST9)].reset_index(drop=True)
for name in sys.argv[1:] or ('base', 'pair'):
    S, Fr, U, cfg, _ = V[name]
    X = np.vstack([des(Dc, 1, S, Fr, U), des(Dc, -1, S, Fr, U)]); y = np.r_[Dc.move5.values == 1, Dc.move5.values == -1].astype(int)
    ms = [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y) for s in range(5)]; del X, y
    sc = lambda T: T[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=np.mean([m.predict_proba(des(T, 1, S, Fr, U))[:, 1] for m in ms], 0),
                                                                           pd=np.mean([m.predict_proba(des(T, -1, S, Fr, U))[:, 1] for m in ms], 0))
    yv, Ey = years(sc(Dc), sc(Dy), INST9)
    print(name, 'Y2324', json.dumps({k: yv[k] for k in ('win', 'n', 'per_day', 'C')}),
          'by year', {k: round(x.w.mean() * 100, 2) for k, x in Ey.groupby(pd.to_datetime(Ey.b, unit='s').dt.year)}, flush=True)

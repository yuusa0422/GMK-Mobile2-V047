"""v0.7.72 research inputs from the window of the candle model (61 closes ending at the bar opening at B-120, live = close at B-60):
(a) indicator signals (ぴっとこ style): RSI(14) centred, MACD(12,26,9) histogram and MA5-MA20 in volatility units, stochastic %K(14) centred;
(b) the chart shape (JFX / LION style similar-chart search): the last 60 minutes as 12 points (cumulative move every 5 minutes, in
volatility units, relative to the last close) plus the live move. Weekday 5-minute boundaries, the nine pairs."""
import sys, numpy as np, pandas as pd
exec(open('v0770_feat.py').read().split("which = sys.argv[1]")[0])
which = sys.argv[1]; src = {k: v for k, v in SRC[which].items() if k not in ('EURUSD', 'AUDUSD')}
def loadc(path, sc):
    d = pd.read_csv(path, usecols=['epoch_ms', 'close']); d['t'] = d.epoch_ms // 1000
    return d.drop_duplicates('t').set_index('t').close.sort_index() / sc
bars = {s: loadc(p, sc) for s, (p, sc) in src.items()}
t0 = min(b.index.min() for b in bars.values()); t1 = max(b.index.max() for b in bars.values())
grid = np.arange(t0 - t0 % 60 - 2000 * 60, t1 + 2000 * 60, 60)
B = grid[grid % 300 == 0]; ts = pd.to_datetime(B, unit='s', utc=True).tz_convert('Asia/Tokyo')
keep = (ts.dayofweek <= 4) & (ts.hour >= 9) & (ts.hour <= 22); B = B[keep]; B = B[(B > t0 + 1500 * 60) & (B < t1 - 900)]
idx = lambda t: ((t - grid[0]) // 60).astype(np.int64)
def ema(x, n):
    a = 2.0 / (n + 1); out = np.empty_like(x); out[:, 0] = x[:, 0]
    for k in range(1, x.shape[1]): out[:, k] = a * x[:, k] + (1 - a) * out[:, k - 1]
    return out
out = []
for s, c in bars.items():
    g = c.reindex(grid).values; lg = np.log(g); i60 = idx(B - 120); il = idx(B - 60)
    W = np.stack([lg[i60 - 60 + k] for k in range(61)], axis=1); ok = ~np.isnan(W).any(axis=1)
    ret = np.diff(W, axis=1); norm = np.maximum(np.sqrt(np.nanmean(ret ** 2, axis=1)), 1e-8); last = W[:, 60]
    up = np.clip(ret[:, -14:], 0, None).mean(axis=1); dn = np.clip(-ret[:, -14:], 0, None).mean(axis=1)
    F = pd.DataFrame(dict(b=B, inst=s))
    F['rsi'] = (up / np.maximum(up + dn, 1e-12) - 0.5) * 2
    P = np.where(np.isnan(W), 0, W); macd = ema(P, 12) - ema(P, 26); sig = ema(macd, 9); F['macdh'] = (macd[:, -1] - sig[:, -1]) / norm
    F['ma520'] = (P[:, -5:].mean(axis=1) - P[:, -20:].mean(axis=1)) / norm
    hi = W[:, -14:].max(axis=1); lo = W[:, -14:].min(axis=1); F['stoch'] = ((last - lo) / np.maximum(hi - lo, 1e-12) - 0.5) * 2
    for j, k in enumerate(range(0, 60, 5)): F[f'sh{j}'] = (W[:, k] - last) / (norm * np.sqrt(60 - k))
    F['shL'] = (lg[il] - last) / norm
    F.loc[~ok, [c for c in F.columns if c not in ('b', 'inst')]] = np.nan
    out.append(F)
X = pd.concat(out, ignore_index=True); X.to_pickle(f'../work/v0772_ext_{which}.pkl'); print(which, len(X), X[['rsi', 'macdh', 'ma520', 'stoch', 'sh0', 'shL']].describe().loc[['mean', 'std']].round(3).to_string())

exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
rows = {}
for n in ('base_s5', 'base_s5_o5', 'ratio_s5', 'ratio_s5_o5', 'pair_s5', 'pair_s5_o5'):
    E = rotation(pd.read_pickle(f'../work/v0772_rot_{n}.pkl'), insts=INST9); rows[n] = (E.groupby(E.b.map(MON)).w.mean() * 100).round(1)
T = pd.DataFrame(rows); T['base'] = T[['base_s5', 'base_s5_o5']].mean(axis=1); T['ratio'] = T[['ratio_s5', 'ratio_s5_o5']].mean(axis=1); T['pair'] = T[['pair_s5', 'pair_s5_o5']].mean(axis=1)
print(T[['base', 'ratio', 'pair']].round(2).to_string())

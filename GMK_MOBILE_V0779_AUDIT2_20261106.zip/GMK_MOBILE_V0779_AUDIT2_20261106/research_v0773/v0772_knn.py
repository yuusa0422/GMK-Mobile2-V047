"""Similar-chart search (JFX 未来予測チャート / ヒロセ さきよみLION style) and the TradingView-style rating, scored with the exact app
replay (same entry count). knn: for each pair, the 200 most similar 60-minute shapes (12 points + live move, volatility units) among the
other periods' slots of that pair; P(HIGH) / P(LOW) = share of those whose next 5 minutes went up / down. Alone and blended with the
nine-pair model (its out-of-sample rotation scores). tv: follow (or fade) the TradingView-style rating, alone and blended."""
import time
from sklearn.neighbors import KDTree
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
R = pd.read_pickle('../work/v0772_rot_base_s5.pkl')
X = pd.read_pickle('../work/v0772_ext_cur.pkl'); SH = [f'sh{j}' for j in range(12)] + ['shL']
R = R.merge(X[['b', 'inst'] + SH], on=['b', 'inst'], how='left')
K = int(sys.argv[1]) if len(sys.argv) > 1 else 200
R['ku'] = np.nan; R['kd'] = np.nan; t0 = time.time()
for s in INST9:
    for te in ('P1', 'P2', 'P3'):
        tr = R[(R.inst == s) & (R.period != te)].dropna(subset=SH); T = R[(R.inst == s) & (R.period == te)].dropna(subset=SH)
        if len(tr) < K or T.empty: continue
        tree = KDTree(np.clip(tr[SH].values, -6, 6)); _, ix = tree.query(np.clip(T[SH].values, -6, 6), k=K)
        mv = tr.move5.values[ix]; R.loc[T.index, 'ku'] = (mv == 1).mean(axis=1); R.loc[T.index, 'kd'] = (mv == -1).mean(axis=1)
    print('knn', s, round(time.time() - t0), 's', flush=True)
R['ku'] = R.ku.fillna(0.49); R['kd'] = R.kd.fillna(0.49)
cols = ['b', 'inst', 'hour', 'period', 'move3', 'move5']
def ev(name, pu, pdn):
    E = rotation(R[cols].assign(pu=pu, pd=pdn), insts=INST9); r = summ(E)
    print(name, json.dumps(dict(win=r['win'], P=r['P'], sep_oct=r['sep_oct'], C=r['C'], per_day=r['per_day'])), flush=True)
ev('model', R.pu, R.pd)
ev(f'knn{K} alone', R.ku, R.kd)
for w in (0.2, 0.4):
    ev(f'model+knn w{w}', (1 - w) * R.pu + w * R.ku, (1 - w) * R.pd + w * R.kd)
import os
if os.path.exists('../work/v0772_tv_cur.pkl'):
    T = pd.read_pickle('../work/v0772_tv_cur.pkl'); R = R.merge(T, on=['b', 'inst'], how='left'); tv = R.tvr.fillna(0.0)
    print('tv coverage', round(R.tvr.notna().mean(), 3), flush=True)
    ev('tv follow alone', 0.5 + 0.05 * tv, 0.5 - 0.05 * tv)
    ev('tv fade alone', 0.5 - 0.05 * tv, 0.5 + 0.05 * tv)
    for w in (0.2, 0.4):
        ev(f'model+tv follow w{w}', (1 - w) * R.pu + w * (0.5 + 0.05 * tv), (1 - w) * R.pd + w * (0.5 - 0.05 * tv))
        ev(f'model+tv fade w{w}', (1 - w) * R.pu + w * (0.5 - 0.05 * tv), (1 - w) * R.pd + w * (0.5 + 0.05 * tv))

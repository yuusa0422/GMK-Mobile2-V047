"""CSV for the user: why the win rate was ~53%, how losses break down, what was tested, the v0.7.55 '55% or more only' result."""
import pandas as pd, numpy as np, json, csv
rows = []
def sec(t): rows.append([]); rows.append(['■ ' + t])
pc = lambda x: '' if x is None or (isinstance(x, float) and np.isnan(x)) else f'{x * 100:.1f}%'
P3 = ('P1', 'P2', 'P3')
D = pd.read_pickle('../work/ladder_v0755.pkl'); L54 = json.load(open('../work/ladder_v0754.json')); L55 = json.load(open('../work/ladder_v0755.json'))
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
sec('1. 勝率が52〜53%だった原因：ENTRYの9割が勝率52%前後の取引（平日・1年・別期間で採点）')
rows.append(['区分', '1日の回数', '勝率', '期間1', '期間2', '期間3', '10月'])
W = D[D.weekday]; days = W.date.nunique()
for name, m in (('S（時間帯ルール＋サイン重なり）', W.g54 == 'S'), ('A（時間帯ルール）', W.g54 == 'A'), ('B（強い取引×直前1分の一致）', W.g54 == 'B'),
                ('C（その他のENTRY）', W.g54 == 'C')):
    x = W[m]; rows.append([name, round(len(x) / days, 1), pc(x.win.mean())] + [pc(x[x.period == p].win.mean()) for p in P3] + [pc(x[x.oct].win.mean())])
x = W[W.g54.isin(['S', 'A', 'B', 'C'])]; rows.append(['v0.7.54 のENTRY全部', round(len(x) / days, 1), pc(x.win.mean())] + [pc(x[x.period == p].win.mean()) for p in P3] + [pc(x[x.oct].win.mean())])
rows.append(['→', 'ENTRY 110回のうち97回がC（52.2%）。S/A/Bだけなら57.6%。Cの中を形・時間帯・曜日・56項目の学習モデルで調べても、別の期間で55%を超える部分は見つからない（v0.7.52の研究）。'])
E = D[~D.weekday]; edays = E.date.nunique()
rows.append(['土日 v0.7.54 B（一番強い取引）', round((E.g54 == 'B').sum() / edays, 1), pc(E[E.g54 == 'B'].win.mean())] + [pc(E[(E.g54 == 'B') & (E.period == p)].win.mean()) for p in P3])
for name, m in (('　うち 60分の値幅の逆側から（下側で買う/上側で売る）', (E.grade == 'S') & (E.pos60_rel <= 0)), ('　うち 値動きを追いかける（上側で買う/下側で売る）', (E.grade == 'S') & (E.pos60_rel > 0))):
    x = E[m]; rows.append([name, round(len(x) / edays, 1), pc(x.win.mean())] + [pc(x[x.period == p].win.mean()) for p in P3] + [pc(x[x.oct].win.mean())])
sec('2. 土日の「追いかけない」条件の検証（見る前に書き出した6つの条件 → 2つの期間で選び、残りの期間で採点）')
WF = json.load(open('../work/weekend_filter_v0755.json'))
rows.append(['採点した期間', '選ばれた条件', 'その期間の勝率', '回数', '条件なしの勝率'])
for h, k, w, n, base in WF['rotation']: rows.append([h, k + '（値幅の逆側から）' if 'pos60' in k else k, pc(w), n, pc(base)])
rows.append(['偶然の確認', f"勝敗をシャッフルしたデータで同じ手順: 平均 +{WF['shuffle_gain_mean'] * 100:.1f}pt。実際は +{WF['gain'] * 100:.1f}pt（偶然でこれ以上になる確率 {WF['p'] * 100:.1f}%）"])
rows.append(['仕組み', '土日のBTCは取引が薄く、上がった後は戻りやすい。v0.7.54で「60分の流れに乗るCは負ける」と分かっていた（別の取引）のと同じ傾向。平日には効かない（平日Bで試すと逆）。'])
sec('3. ENTRYの負けの内訳（v0.7.55のENTRY・1年）')
rows.append(['区分', '取引数', '負け', 'うち引き分け', 'うち逆に動いた', '負けの多い時間（勝率）', '負けの多い通貨（勝率）'])
for wkd, seg in ((True, '平日 S/A/B'), (False, '土日 B')):
    x = D[(D.weekday == wkd) & D.g55.isin(['S', 'A', 'B'])]
    lose = x[x.win == 0]
    hr = x.groupby('hour').win.mean().sort_values().head(2); ins = x.groupby('inst').win.mean().sort_values().head(2)
    rows.append([seg, len(x), len(lose), f"{int(lose.tie.sum())}（{lose.tie.mean() * 100:.0f}%）", f"{int((1 - lose.tie).sum())}（{(1 - lose.tie.mean()) * 100:.0f}%）",
                 ' / '.join(f'{h}時 {pc(v)}' for h, v in hr.items()), ' / '.join(f'{i} {pc(v)}' for i, v in ins.items())])
rows.append(['時間・通貨別', '一番低い時間帯・通貨でも3つの期間で安定して50%を下回るものは無い（期間ごとに入れ替わる）'])
sec('4. 連敗（v0.7.55のENTRYだけ・同じ日の中）')
rows.append(['区分', '最大連敗', '5連敗以上の日', '勝率50%未満の日', '直近20回の勝率が低い時（下位25%）の次の勝率', '高い時（上位25%）の次の勝率'])
for wkd, seg in ((True, '平日'), (False, '土日')):
    e = D[(D.weekday == wkd) & D.g55.isin(['S', 'A', 'B'])].sort_values('b').copy(); r = L55[('weekday' if wkd else 'weekend') + '_ENTRY']
    e['prev'] = e.win.shift(1).rolling(20).mean(); q = pd.qcut(e.prev, 4, labels=False, duplicates='drop'); g = e.groupby(q).win.mean()
    rows.append([seg, r['maxrun'], f"{r['days5']}%", f"{r['days_below50']}%", pc(g.iloc[0]), pc(g.iloc[-1])])
rows.append(['→', '負けが続いた後も次の勝率は変わらない（流れは無い）。「◯連敗したら休む」は勝率を上げず、取り逃しが増えるだけなので入れていない。'])
sec('5. B（直前1分の一致）の中で負けやすい形はあるか（14項目×4段階・期間ごと）')
rows.append(['結果', '直前1分の大きさ・円全体の動き・ボラティリティ・15分/60分の流れ・60分の位置・時間・モデルの確信度など14項目、どれも3つの期間で同じ向きの差は無し → Bはそのまま'])
rows.append(['2026年9月', 'B（為替）が37回で24.3%と大きく負けた月がある（その月はデータも12日分のみ）。翌月は52.5%に戻り、前の月の成績から次の月は予測できない'])
sec('6. 研究とアプリの差：直前価格を取る時刻（研究=エントリー直前の価格、アプリ=10秒前のスキャン時の価格）')
S = json.load(open('../work/stale_sim_v0755.json'))
rows.append(['直前価格の古さ', 'S（時間帯ルール）', 'A（時間帯ルール）', 'B', 'Bになる回数（研究=100%）', '米指標NY8:30（20分平均）'])
for s_ in (0, 10, 20, 30):
    r = S[f'rules_{s_}s']; b = S[f'B_{s_}s']
    rows.append([f'{s_}秒前' + ('（研究）' if s_ == 0 else ''), pc(r['grade_S']['win']), pc(r['grade_A']['win']), pc(b['win']), f"{b['kept'] * 100:.0f}%", pc(r['US0830_BBZ']['win'])])
rows.append(['見方', '1分の中は不規則に動くと仮定し、エントリーの s 秒前の価格を作って同じ判定をした場合。10秒前なら S 約-3pt、B 約-0.5pt。古いほどBの回数が減る。完全に60秒古い価格では米指標NY8:30は 50.7% まで落ちる（最後の1分に強みが集中）'])
rows.append(['対策（v0.7.55）', 'スキャンの最後（締め切りの約2秒前まで）に為替の価格をもう一度取得して、できるだけ新しい価格で判定。使った価格が何秒前かを結果に残し、診断ログで「何秒前の価格だと何勝何敗」を集計'])
rows.append(['結果の判定の取得元', '2026年10月1〜21日（v0.7.49の判定）: 同じ取引をYahooの1分足で判定しても研究のDukascopyで判定しても勝率はほぼ同じ（55.0% / 55.1%）→ 判定のずれは原因ではない'])
rows.append(['判断に使う1分足の取得元', '同じ枠をアプリと同じYahooの1分足で判断すると 54.0%、研究と同じDukascopyだと 55.1%（約-1pt）。22%の枠で選ぶ通貨か向きが変わり、その枠ではYahoo側 47.6% / Dukascopy側 53.0%（296回）。回数が少なく偶然の範囲（約1.3σ）だが、Yahooの1分足の細かい違いでBの一致判定がずれる可能性がある → 診断ログで実際の結果を確認'])
sec('7. v0.7.55 の成績（1年・別期間で採点）')
rows.append(['区分', 'ランク', '回数', '1日あたり', '勝率', '期間1', '期間2', '期間3', '10月', '最大連敗', 'ENTRY/見送り'])
for wkd, seg in (('weekday', '平日'), ('weekend', '土日')):
    for g in 'SABDEFGH':
        r = L55[wkd].get(g)
        if r: rows.append([seg, g, int(r['n']), round(r['per_day'], 1), pc(r['win']), pc(r['P1']), pc(r['P2']), pc(r['P3']), pc(r['oct']), r['maxrun'], 'ENTRY' if g in 'SAB' else '見送り'])
for k, lab in (('weekday_ENTRY', '平日 ENTRY全部'), ('weekend_ENTRY', '土日 ENTRY全部')):
    r = L55[k]; rows.append([lab, '', '', r['per_day'], f"{r['win']}%", f"{r['P1']}%", f"{r['P2']}%", f"{r['P3']}%", f"{r['oct']}%", r['maxrun']])
rows.append(['（前）v0.7.54', '平日 ENTRY全部', '', 110.2, '52.9%', '', '', '', '52.6%', 14])
rows.append(['（前）v0.7.54', '土日 ENTRY全部', '', 21.5, '54.0%', '', '', '', '54.7%', 8])
rows.append(['月別（平日ENTRY）'] + [f'{m} {v}%' for m, v in L55['weekday_ENTRY']['months'].items()])
rows.append(['月別（土日ENTRY）'] + [f'{m} {v}%' for m, v in L55['weekend_ENTRY']['months'].items()])
rows.append(['実際の見込み', 'S/Aは同じ1年で選んだルールで偶然の分も含む・直前価格の時刻差・1分足の取得元の差（各-0.5〜1pt）もあるため、実際は平日・土日とも55〜56%を見込む'])
with open('../pages/GMK_負けの原因と55パーセント化.csv', 'w', newline='', encoding='utf-8-sig') as f: csv.writer(f).writerows(rows[1:])
print(len(rows))

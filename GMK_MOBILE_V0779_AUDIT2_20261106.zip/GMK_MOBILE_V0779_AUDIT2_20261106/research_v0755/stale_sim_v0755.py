"""How much of the research edge survives when the live price is taken s seconds before entry (the app scans at T-10 s,
Yahoo quotes may lag further). Research: live = close of the bar opening at B-60 (= the price at B).
Model: inside that bar the price path is a Brownian bridge from its open (B-60) to its close (B); the price at B-s is drawn
from the bridge (mean O + t(C-O), sd = sigma_1m * sqrt(t(1-t)), t = (60-s)/60), clipped to the bar's low/high.
This keeps the information the app really has (the first 60-s seconds of the minute) and removes the last s seconds.
Entry and result are unchanged: OPEN(B) -> OPEN(B+3m). 40 draws per row."""
import numpy as np, pandas as pd, json, math, sys
src = open('policy_data.py').read().split("d = pd.DataFrame(pickle.load(open('../work/frames_year.pkl'")[0]
exec(src)                                         # bars, index, window(), feats()
from ranks_v0753 import EVENTS
from rule_mine import load
K = 40; rng = np.random.default_rng(755)
FXS = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
COL = {'JST': 'jst_min', 'LON': 'lon_min', 'NY': 'ny_min'}
TH = {'pos60L': 0.8, 'bbzL': 1.5, 'r5': 1.0, 'r15': 1.0, 'f1': 1.0}
def base(inst, B):
    w = window(inst, B); fb = index[inst].get((B - 60) * 1000)
    if w is None or fb is None: return None
    c = np.array([r[4] for r in w]); h = np.array([r[2] for r in w]); l = np.array([r[3] for r in w])
    lg = np.log(c); ret = np.diff(lg); norm = max(math.sqrt((ret ** 2).mean()), 1e-8)
    m20 = c[41:61].mean(); sd20 = math.sqrt(max(((c[41:61] - m20) ** 2).mean(), 1e-16))
    r5 = (lg[60] - lg[55]) / (norm * math.sqrt(5)); r15 = (lg[60] - lg[45]) / (norm * math.sqrt(15))
    return dict(O=fb[1], H=fb[2], L=fb[3], C=fb[4], c60=c[60], norm=norm, m20=m20, sd20=sd20, hi=h.max(), lo=l.min(), r5=r5, r15=r15)
def lives(b, s):
    if s == 0: return np.full(K, b['C'])
    t = (60 - s) / 60
    x = b['O'] + t * (b['C'] - b['O']) + rng.standard_normal(K) * b['norm'] * b['C'] * math.sqrt(t * (1 - t))
    return np.clip(x, b['L'], b['H'])
def vals(b, live):
    hiL = np.maximum(b['hi'], live); loL = np.minimum(b['lo'], live)
    return {'pos60L': (live - loL) / np.maximum(hiL - loL, 1e-12) * 2 - 1, 'bbzL': (live - b['m20']) / b['sd20'],
            'f1': (np.log(live) - math.log(b['c60'])) / b['norm'], 'r5': np.full(K, b['r5']), 'r15': np.full(K, b['r15'])}
F = load(); FX = F[F.inst != 'BTCJPY']
y = {(bb, i): v for bb, i, v in zip(FX.b, FX.inst, FX.y)}
per = dict(zip(FX.b, FX.period))
SECS = [0, 10, 20, 30]
res = {}
# ---- time-of-day rules (selection over the five FX as in EventRules.match) ----
slots = {}
for eid, g, clock, mod, feat, th, usd, label in EVENTS:
    for bb in sorted(set(FX[FX[COL[clock]] == mod].b)): slots.setdefault(bb, []).append((eid, feat, th, usd))
for s in SECS:
    win = {}; cnt = {}; win_s = {}; cnt_s = {}
    for bb, rules in slots.items():
        B = {i: base(i, bb) for i in FXS}; V = {i: vals(B[i], lives(B[i], s)) for i in FXS if B[i] is not None and (bb, i) in y}
        if not V: continue
        for k in range(K):
            for eid, feat, th, usd in rules:
                best = None
                for o, i in enumerate(FXS):
                    if i not in V: continue
                    v = V[i][feat][k]
                    if abs(v) < th: continue
                    key = (0 if (usd and i == 'USDJPY') else 1, -abs(v), o)
                    if best is None or key < best[0]: best = (key, i, v)
                if best is None: continue
                _, i, v = best
                w = float(y[(bb, i)] * -np.sign(v) > 0)
                conf = sum(1 for f, t in TH.items() if f != feat and abs(V[i][f][k]) >= t and np.sign(V[i][f][k]) == np.sign(v))
                p = per[bb]
                win[(eid, p)] = win.get((eid, p), 0) + w; cnt[(eid, p)] = cnt.get((eid, p), 0) + 1
                gk = ('S' if conf >= 3 else 'A', p); win_s[gk] = win_s.get(gk, 0) + w; cnt_s[gk] = cnt_s.get(gk, 0) + 1
                break
    r = {}
    for eid in [e[0] for e in EVENTS]:
        n = sum(cnt.get((eid, p), 0) for p in ('P1', 'P2', 'P3'))
        r[eid] = dict(n=round(n / K, 1), win=round(sum(win.get((eid, p), 0) for p in ('P1', 'P2', 'P3')) / max(n, 1), 4),
                      **{p: round(win.get((eid, p), 0) / max(cnt.get((eid, p), 0), 1), 3) for p in ('P1', 'P2', 'P3')})
    for g in ('S', 'A'):
        n = sum(cnt_s.get((g, p), 0) for p in ('P1', 'P2', 'P3'))
        r['grade_' + g] = dict(n=round(n / K, 1), win=round(sum(win_s.get((g, p), 0) for p in ('P1', 'P2', 'P3')) / max(n, 1), 4),
                               **{p: round(win_s.get((g, p), 0) / max(cnt_s.get((g, p), 0), 1), 3) for p in ('P1', 'P2', 'P3')})
    res[f'rules_{s}s'] = r; print('rules', s, 's', json.dumps(r, ensure_ascii=False))
# ---- weekday B tier: the confirming last-minute move recomputed with the earlier price (model grade kept) ----
L = pd.read_pickle('../work/ladder_v0754.pkl')
Bt = L[L.weekday & (L.g54 == 'B') & L.r_rank.isna()]
for s in SECS:
    w = n = 0; wp = {}; np_ = {}
    for bb, i, d, win_, p in zip(Bt.b, Bt.inst, Bt.dir, Bt.win, Bt.period):
        b = base(i, bb)
        if b is None: continue
        f1 = (np.log(lives(b, s)) - math.log(b['c60'])) / b['norm'] * d
        ok = (f1 >= 1) & (f1 < 3) if i == 'BTCJPY' else (f1 <= -2.5)
        w += ok.sum() * win_; n += ok.sum(); wp[p] = wp.get(p, 0) + ok.sum() * win_; np_[p] = np_.get(p, 0) + ok.sum()
    res[f'B_{s}s'] = dict(kept=round(n / K / len(Bt), 3), win=round(w / max(n, 1), 4), **{p: round(wp.get(p, 0) / max(np_.get(p, 1), 1), 3) for p in ('P1', 'P2', 'P3')})
    print('B tier', s, 's', res[f'B_{s}s'])
json.dump(res, open('../work/stale_sim_v0755.json', 'w'), indent=1, ensure_ascii=False)

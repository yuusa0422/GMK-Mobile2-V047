"""Weekend top tier (v0.7.48 S = v0.7.54 B): which 'do not chase' filter keeps it above 55%? Rotation over periods + shuffle baseline.
Filters are written down before scoring (mechanism: weekend BTC reverts; the v0.7.54 study found following the 60-minute move lost
on weekend C trades, a different set of trades)."""
import pandas as pd, numpy as np, json, itertools, sys
D = pd.read_pickle('../work/ladder_v0754.pkl')
E = D[(~D.weekday) & (D.grade == 'S')].copy().reset_index(drop=True)
FILT = {'r60_rel<=0.3': lambda x: x.r60_rel <= 0.3, 'r15_rel<=0.3': lambda x: x.r15_rel <= 0.3, 'pos60_rel<=0': lambda x: x.pos60_rel <= 0,
        'f1_rel<=0': lambda x: x.f1_rel <= 0, 'bbzL_rel<=0': lambda x: x.bbzL_rel <= 0, 'pos15L_rel<=0': lambda x: x.pos15L_rel <= 0,
        'none': lambda x: pd.Series(True, index=x.index)}
def rotate(X, y):
    out = []
    for hold in ('P1', 'P2', 'P3'):
        tr = X.period != hold
        best = None
        for k, f in FILT.items():
            m = f(X)
            if (m & tr).sum() < 0.4 * tr.sum(): continue
            r = y[m & tr].mean()
            if best is None or r > best[0]: best = (r, k)
        k = best[1]; m = FILT[k](X)
        out.append((hold, k, round(float(y[m & ~tr].mean()), 4), int((m & ~tr).sum()), round(float(y[~tr].mean()), 4)))
    return out
real = rotate(E, E.win)
print('real', real)
rng = np.random.default_rng(55); gains = []
for i in range(int(sys.argv[1]) if len(sys.argv) > 1 else 200):
    ys = E.groupby('date').win.transform(lambda s: rng.permutation(s.values))
    r = rotate(E, ys); gains.append(np.mean([a[2] - a[4] for a in r]))
g_real = np.mean([a[2] - a[4] for a in real])
print('held-out gain real', round(g_real, 4), 'shuffle mean', round(float(np.mean(gains)), 4), 'p', float(np.mean(np.array(gains) >= g_real)))
P = lambda x: [round(x[x.period == p].win.mean(), 4) for p in ('P1', 'P2', 'P3')]
for k, f in FILT.items():
    x = E[f(E)]; print(k, len(x), round(x.win.mean(), 4), P(x), 'oct', round(x[x.oct].win.mean(), 4), int(x.oct.sum()))
json.dump({'rotation': real, 'gain': g_real, 'shuffle_gain_mean': float(np.mean(gains)), 'p': float(np.mean(np.array(gains) >= g_real))},
          open('../work/weekend_filter_v0755.json', 'w'), indent=1)

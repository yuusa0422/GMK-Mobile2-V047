"""v0.7.55 ladder ('55%以上だけENTRY'): weekday S/A (rules) and B (strong model trade + confirming last-minute move) enter;
every former C is skipped. Weekend: the strongest model tier enters only when it does not chase the hour (pos60 x direction <= 0).
Skips keep their order: weekday D = former C (10-22h), E = v0.7.48 D, F = v0.7.48 E + 09h C; weekend D = S chasing + A/B/C, E = D/E."""
import pandas as pd, numpy as np, json
D = pd.read_pickle('../work/ladder_v0754.pkl').sort_values('b')
model = D.r_rank.isna(); wk = D.weekday
g = D.g54.copy()
g[model & wk & (D.g54 == 'C')] = 'D'
g[model & wk & (D.grade == 'D')] = 'E'
g[model & wk & (D.g54 == 'E')] = 'F'                          # v0.7.48 E and 09h C
we = model & ~wk
g[we & (D.grade == 'S') & (D.pos60_rel <= 0)] = 'B'
g[we & (D.grade == 'S') & (D.pos60_rel > 0)] = 'D'
g[we & D.grade.isin(['A', 'B', 'C'])] = 'D'
g[we & D.grade.isin(['D', 'E'])] = 'E'
D['g55'] = g
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
out = {}
for wkd, seg in ((True, 'weekday'), (False, 'weekend')):
    W = D[D.weekday == wkd]; days = W.date.nunique()
    t = W.groupby('g55').agg(n=('win', 'size'), win=('win', 'mean'), draw=('tie', 'mean')); t['per_day'] = t.n / days
    for p in ('P1', 'P2', 'P3'): t[p] = W[W.period == p].groupby('g55').win.mean()
    t['oct'] = W[W.oct].groupby('g55').win.mean(); t['oct_n'] = W[W.oct].groupby('g55').size(); t['maxrun'] = W.groupby('g55').win.apply(lambda s: maxrun(s.values))
    print(seg); print(t.round(4).to_string()); out[seg] = t.round(4).to_dict('index')
    e = W[W.g55.isin(['S', 'A', 'B'])]; daily = e.groupby('date').win.agg(['size', 'sum'])
    dr = e.groupby('date').win.apply(lambda s: maxrun(s.values))
    r = dict(per_day=round(len(e) / days, 2), win=round(e.win.mean() * 100, 2), **{p: round(e[e.period == p].win.mean() * 100, 2) for p in ('P1', 'P2', 'P3')},
             oct=round(e[e.oct].win.mean() * 100, 2), oct_n=int(e.oct.sum()), maxrun=maxrun(e.win.values), days5=round((dr >= 5).mean() * 100, 1),
             days_below50=round(((daily['sum'] / daily['size']) < 0.5).mean() * 100, 1), draw=round(e.tie.mean() * 100, 2),
             months={m: round(x.win.mean() * 100, 1) for m, x in e.groupby(e.date.astype(str).str[:7])})
    print('ENTRY', r); out[seg + '_ENTRY'] = r
json.dump(out, open('../work/ladder_v0755.json', 'w'), indent=1, default=float, ensure_ascii=False)
D.to_pickle('../work/ladder_v0755.pkl')

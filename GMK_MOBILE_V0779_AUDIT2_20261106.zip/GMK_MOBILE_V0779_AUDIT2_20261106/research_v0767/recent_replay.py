"""The app as it is on days it never saw (2026-10-22 .. 2026-11-04 16:00 JST): production 5-minute model, production tables,
v0.7.66 (5-minute AUTO, slot tables) vs v0.7.65 (every weekday minute, minute tables). No fixed S/A/B trades on these days."""
import sys, json, pickle
sys.argv = ['x', '../work/v0765_5m_cur.pkl', 'recent', 'five']
exec(open('v0765_sim_5min.py').read().split("F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); res = {}")[0])
EX = [('isk0', False)]
ms = fit(PM, True, extra=EX)                                       # = production (same rows, seeds); parity checked in v0765_slot5_tables
PM2 = pd.read_pickle('../work/v0765_PM_ext2.pkl'); T = PM2[PM2.date.astype(str) >= '2026-10-22'].reset_index(drop=True); del PM2
pu, pdn = pred(ms, T, True, extra=EX); del ms
Sc = T[['b', 'inst', 'hour', 'date', 'move5', 'f1']].assign(pu=pu, pd=pdn, period='T')
slots_t = set(T[T.k == 0].b)
T5 = json.load(open('../v0766/GMK_MOBILE_V0766_FIVE_MINUTE_20261104/research_v0766/v0766_slot5_tables.json'))['fresh']
prod = pickle.load(open('../work/production_model5_v0758.pkl', 'rb'))['fresh']
def run(S, Q, base, five):
    global FIVE
    FIVE = five; C, M = cands(S, 'all'); E = simulate(C, {}, slots_t, Q, base, 0.0)
    E['day'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%m-%d'); s10, mx = streak_stats(E.sort_values('b').w.values)
    return dict(win=round(E.w.mean() * 100, 2), n=len(E), per_day=round(len(E) / E.day.nunique(), 1), max_streak=mx, hours_below_70=round(E.attrs['hours_below'] * 100, 1),
                oct=round(E[E.day < '11'].w.mean() * 100, 2), n_oct=int((E.day < '11').sum()), nov=round(E[E.day >= '11'].w.mean() * 100, 2), n_nov=int((E.day >= '11').sum()),
                by_day={d: round(g.w.mean() * 100, 1) for d, g in E.groupby('day')})
r5 = run(Sc[Sc.b % 300 == 0], {int(h): np.array(v) for h, v in T5['Q'].items()}, {int(h): float(v) for h, v in T5['base'].items()}, True)
print('V0766_FIVE_MINUTE', json.dumps(r5), flush=True)
r1 = run(Sc, {int(h): np.array(v) for h, v in prod['Q'].items()}, {int(h): float(v) for h, v in prod['base'].items()}, False)
print('V0765_EVERY_MINUTE', json.dumps(r1), flush=True)

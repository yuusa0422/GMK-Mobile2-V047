"""Year replay of the v0.7.51 ranks: the model trade (out-of-period stage 1 + strength ladder) with the event rules on top."""
import pandas as pd, numpy as np, json
X = pd.read_pickle('../work/design_x_fresh.pkl')
E = pd.read_pickle('../work/event_signals_v0751.pkl')[['b', 'inst', 'dir', 'win', 'event', 'rank']].rename(columns={'inst': 'r_inst', 'dir': 'r_dir', 'win': 'r_win', 'rank': 'r_rank'})
X = X.merge(E, on='b', how='left')
wkmap = {'S': 'B', 'A': 'B', 'B': 'C', 'C': 'C'}; wemap = {'S': 'B', 'A': 'C', 'B': 'C'}
X['g'] = np.where(X.weekday, X.grade.map(lambda g: wkmap.get(g, g)), X.grade.map(lambda g: wemap.get(g, g)))
ev = X.r_rank.notna()
X.loc[ev, 'g'] = X.loc[ev, 'r_rank']; X.loc[ev, 'win'] = X.loc[ev, 'r_win']
X['entry'] = X.g.isin(['S', 'A', 'B', 'C'])
X['oct'] = X.date.astype(str).str[5:7] == '10'
def maxrun(w):
    m = c = 0
    for v in w:
        c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
out = {}
for wk, seg in ((True, 'weekday'), (False, 'weekend')):
    W = X[X.weekday == wk].sort_values('b'); days = W.date.nunique()
    t = W.groupby('g').agg(n=('win', 'size'), win=('win', 'mean')); t['share'] = t.n / len(W); t['per_day'] = t.n / days
    t['H1'] = W[W.half == 'H1'].groupby('g').win.mean(); t['H2'] = W[W.half == 'H2'].groupby('g').win.mean()
    t['oct'] = W[W.oct].groupby('g').win.mean(); t['oct_n'] = W[W.oct].groupby('g').size()
    t['maxrun'] = W.groupby('g').win.apply(lambda s: maxrun(s.values))
    e = W[W.entry]
    head = dict(entry=round(len(e) / len(W) * 100, 1), win=round(e.win.mean() * 100, 2), per_day=round(len(e) / days, 1), maxrun=maxrun(e.win.values),
                oct_win=round(e[e.oct].win.mean() * 100, 2), H1=round(e[e.half == 'H1'].win.mean() * 100, 2), H2=round(e[e.half == 'H2'].win.mean() * 100, 2))
    if wk: head['min_hour_entry'] = round(W.groupby('hour').entry.mean().min() * 100, 1)
    out[seg] = dict(head=head, ranks={g: {k: (round(float(v) * 100, 1) if k in ('win', 'share', 'H1', 'H2', 'oct') else (round(float(v), 1) if k == 'per_day' else int(v))) for k, v in r.items() if pd.notna(v)} for g, r in t.iterrows()})
    print(seg, head); print(t.round(3).to_string())
json.dump(out, open('../work/ladder_v0751.json', 'w'), indent=1, ensure_ascii=False)

"""DST-aware market-session features for 5-minute entry slots (entry time ts in JST)."""
import pandas as pd, numpy as np
GOTOBI = {5, 10, 15, 20, 25, 30}
def add_session(X, ts_col='ts'):
    ts = pd.to_datetime(X[ts_col])
    if ts.dt.tz is None: ts = ts.dt.tz_localize('Asia/Tokyo')
    ts = ts.dt.tz_convert('Asia/Tokyo')
    lon = ts.dt.tz_convert('Europe/London'); ny = ts.dt.tz_convert('America/New_York')
    X = X.copy()
    X['jst_min'] = ts.dt.hour * 60 + ts.dt.minute
    X['lon_min'] = lon.dt.hour * 60 + lon.dt.minute
    X['ny_min'] = ny.dt.hour * 60 + ny.dt.minute
    X['minute'] = ts.dt.minute
    X['dow'] = ts.dt.dayofweek + 1                      # 1=Mon .. 7=Sun
    X['dom'] = ts.dt.day
    last = (ts + pd.Timedelta(days=1)).dt.month != ts.dt.month
    # gotobi: 5/10/../30 or month end; when that day is a weekend the business day before carries it
    X['gotobi'] = (ts.dt.day.isin(GOTOBI) | last).astype(int)
    X['month'] = ts.dt.month
    X['october'] = (ts.dt.month == 10).astype(int)
    X['eu_summer'] = (lon.dt.strftime('%Z') == 'BST').astype(int)
    X['us_summer'] = (ny.dt.strftime('%Z') == 'EDT').astype(int)
    j, l, n = X.jst_min, X.lon_min, X.ny_min
    conds = [
        j < 9 * 60 + 45,
        j < 10 * 60 + 10,
        j < 12 * 60,
        j < 15 * 60,
        (j >= 15 * 60) & (l < 8 * 60),
        (l >= 8 * 60) & (l < 10 * 60),
        (l >= 10 * 60) & (l < 13 * 60),
        (l >= 13 * 60) & (n < 8 * 60 + 30),
        (n >= 8 * 60 + 30) & (n < 9 * 60 + 30),
        n >= 9 * 60 + 30,
    ]
    names = ['T1_東京朝', 'T2_仲値前後', 'T3_東京午前', 'T4_東京午後', 'E0_欧州準備', 'E1_ロンドン序盤', 'E2_ロンドン午前', 'U0_NY準備', 'U1_米指標の時間', 'U2_NY序盤']
    X['session'] = np.select(conds, names, default='?')
    return X
SESSIONS = ['T1_東京朝', 'T2_仲値前後', 'T3_東京午前', 'T4_東京午後', 'E0_欧州準備', 'E1_ロンドン序盤', 'E2_ロンドン午前', 'U0_NY準備', 'U1_米指標の時間', 'U2_NY序盤']

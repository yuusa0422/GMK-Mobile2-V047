"""Does session / weekday / October context improve the out-of-period ranking of the app's chosen trade?"""
import pandas as pd, numpy as np, json
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from session_feats import add_session, SESSIONS
X = add_session(pd.read_pickle('../work/design_x_fresh.pkl'))
d = X.date.astype(str)
X['period'] = np.where(d < '2026-02-01', 'P1', np.where(d < '2026-06-01', 'P2', 'P3'))
X['octyr'] = np.where(X.october == 1, np.where(d < '2026-01-01', 'O25', 'O26'), '')
X['fade'] = (X.f1 * X.dir < 0).astype(float); X['follow'] = (X.f1 * X.dir > 0).astype(float)
X['btc'] = (X.inst == 'BTCJPY').astype(float)
base = ['E']  # v0.7.48 production strength (computed with the production strength model: in-sample for the strength part)
strength_inputs = ['pct', 'abs_f1', 'abs_r1', 'lrv', 'tie58', 'zero30', 'fade', 'follow', 'btc']
def design(D, ctx):
    M = D[strength_inputs].copy()
    M['hinge'] = np.maximum(D.pct - 0.9, 0) * 10
    M['fx_fade_big'] = ((D.btc == 0) & (D.f1 * D.dir < 0) & (D.abs_f1 >= 2.5)).astype(float)
    M['btc_follow'] = ((D.btc == 1) & (D.f1 * D.dir > 0) & D.abs_f1.between(0.5, 3)).astype(float)
    M['fx_fade15'] = ((D.btc == 0) & (D.r15 * D.dir <= -1.5)).astype(float)
    if 'session' in ctx:
        for s in SESSIONS[1:]: M['s_' + s] = (D.session == s).astype(float)
    if 'sessfade' in ctx:
        for s in SESSIONS: M['sf_' + s] = ((D.session == s) & (D.fade == 1)).astype(float)
    if 'dow' in ctx:
        for k in (2, 3, 4, 5): M[f'dow{k}'] = (D.dow == k).astype(float)
    if 'oct' in ctx:
        M['oct'] = D.october.astype(float)
        if 'session' in ctx:
            for s in SESSIONS: M['os_' + s] = ((D.session == s) & (D.october == 1)).astype(float)
    if 'fix' in ctx:
        M['fix955'] = (D.jst_min == 9 * 60 + 55).astype(float)
        M['fix955_fade'] = ((D.jst_min == 9 * 60 + 55) & (D.pos60L * D.dir < -0.6)).astype(float) if 'pos60L' in D else 0.0
    return M
W = X[X.weekday].reset_index(drop=True)
res = {}
def topq(p, y, q=0.2):
    k = int(len(p) * q); o = np.argsort(-p); return float(y[o[:k]].mean()), float(y[o[-k:]].mean())
for name, ctx, wt in [('strength', [], 1), ('+session', ['session'], 1), ('+session+fade', ['session', 'sessfade'], 1),
                      ('+dow', ['dow'], 1), ('+session+dow', ['session', 'dow'], 1), ('+session+dow+oct', ['session', 'dow', 'oct'], 1),
                      ('+session+dow+oct w5', ['session', 'dow', 'oct'], 5), ('+all+fix', ['session', 'sessfade', 'dow', 'oct', 'fix'], 1)]:
    out = {}
    for fold_col, tests in (('period', ['P1', 'P2', 'P3']), ('octyr', ['O25', 'O26'])):
        P = np.full(len(W), np.nan)
        for t in tests:
            tr = W[fold_col] != t; te = W[fold_col] == t
            Mtr = design(W[tr], ctx); Mte = design(W[te], ctx)
            sw = np.where(W[tr].october == 1, wt, 1.0)
            m = LogisticRegression(C=0.05, max_iter=2000).fit(Mtr, W.win[tr], sample_weight=sw)
            P[te.values] = m.predict_proba(Mte)[:, 1]
        ok = ~np.isnan(P); y = W.win.values[ok]
        hi, lo = topq(P[ok], y)
        out[fold_col] = dict(auc=round(roc_auc_score(y, P[ok]), 4), top20=round(hi, 4), bottom20=round(lo, 4), n=int(ok.sum()))
    res[name] = out; print(name, out)
y = W.win.values; print('production E (in-sample strength) auc', round(roc_auc_score(y, W.E), 4), 'top/bottom', [round(v, 4) for v in topq(W.E.values, y)])
o = W.octyr != ''; print('E on Octobers', round(roc_auc_score(y[o], W.E[o]), 4), [round(v, 4) for v in topq(W.E[o].values, y[o])])
json.dump(res, open('../work/rank_ctx.json', 'w'), indent=1)

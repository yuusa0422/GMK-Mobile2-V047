import pandas as pd, numpy as np, json, sys
from rule_mine import load
import minute_mine as mm
F = load(); L = mm.cells(F)
rng = np.random.default_rng(11); Fs = F.copy(); Fs['y'] = Fs.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values)); Ls = mm.cells(Fs)
part = F.period.values
def run(F, L, min_n, each, allr, fam=None):
    out = []
    LL = L if fam is None else L[L.cell.str.contains(fam)]
    for test in ('P1', 'P2', 'P3'):
        tr = np.where(F.period != test)[0]; te = np.where(F.period == test)[0]
        sel = mm.select(LL, tr, part, min_n=min_n, min_each=each, min_all=allr); P = mm.pick(LL, sel, te)
        out.append((len(sel), len(P), P.win.sum(), len(P) / F.date[F.period == test].nunique()))
    for o in ('O25', 'O26'):
        tr = np.where(F.octyr != o)[0]; te = np.where(F.octyr == o)[0]
        sel = mm.select(LL, tr, part, min_n=min_n, min_each=each, min_all=allr); P = mm.pick(LL, sel, te)
        out.append((len(sel), len(P), P.win.sum(), len(P) / F.date[F.octyr == o].nunique()))
    rot = out[:3]; octs = out[3:]
    w = sum(x[2] for x in rot) / max(sum(x[1] for x in rot), 1); wo = sum(x[2] for x in octs) / max(sum(x[1] for x in octs), 1)
    return dict(rot_win=round(w, 3), rot_trades=sum(x[1] for x in rot), per_day=round(np.mean([x[3] for x in rot]), 2), cells=[x[0] for x in rot],
                per_period=[round(x[2] / x[1], 3) if x[1] else None for x in rot], oct_win=round(wo, 3), oct_trades=sum(x[1] for x in octs),
                oct_each=[round(x[2] / x[1], 3) if x[1] else None for x in octs])
for (mn, each, allr, fam) in [(120, .55, .58, None), (150, .57, .60, None), (150, .58, .61, None), (150, .60, .62, None), (150, .57, .60, 'fade'), (150, .58, .61, 'fade'), (200, .58, .60, 'fade')]:
    print(mn, each, allr, fam, 'REAL', run(F, L, mn, each, allr, fam))
    print(mn, each, allr, fam, 'CHANCE', run(Fs, Ls, mn, each, allr, fam))

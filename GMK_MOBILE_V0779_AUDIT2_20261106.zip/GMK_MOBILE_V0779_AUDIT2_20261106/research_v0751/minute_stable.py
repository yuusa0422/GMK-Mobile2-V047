import pandas as pd, numpy as np, json
from rule_mine import load
import minute_mine as mm
F = load(); L = mm.cells(F); part = F.period.values
def stable(F, L, seeds_label):
    sel_sets = {}; tests = {}
    for test in ('P1', 'P2', 'P3'):
        tr = np.where(F.period != test)[0]; te = np.where(F.period == test)[0]
        sel = mm.select(L, tr, part)
        sel_sets[test] = set(sel.index)
        tests[test] = L[L.row.isin(te) & L.cell.isin(sel.index)].groupby('cell').win.agg(['size', 'mean'])
    allc = set.intersection(*sel_sets.values()); two = {c for c in set.union(*sel_sets.values()) if sum(c in s for s in sel_sets.values()) >= 2}
    rows = []
    for c in sorted(two):
        r = dict(cell=c, n_sel=sum(c in s for s in sel_sets.values()))
        for t in ('P1', 'P2', 'P3'):
            if c in tests[t].index: r[t] = round(tests[t].loc[c, 'mean'], 3); r['n' + t] = int(tests[t].loc[c, 'size'])
        rows.append(r)
    return len(allc), len(two), pd.DataFrame(rows)
a, b, T = stable(F, L, 'real'); print('REAL selected in all 3:', a, ' in >=2:', b); print(T.to_string())
res = {'real': [a, b]}
for seed in (11, 12, 13, 14, 15):
    rng = np.random.default_rng(seed); Fs = F.copy(); Fs['y'] = Fs.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values))
    a2, b2, T2 = stable(Fs, mm.cells(Fs), 'chance'); print('CHANCE seed', seed, 'all3', a2, '>=2', b2); res[f'chance{seed}'] = [a2, b2]
    if len(T2): print(T2.to_string())
json.dump(res, open('../work/minute_stable.json', 'w'))

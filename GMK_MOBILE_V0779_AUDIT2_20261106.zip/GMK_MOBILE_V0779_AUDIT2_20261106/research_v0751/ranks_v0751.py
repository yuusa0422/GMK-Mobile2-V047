"""v0.7.51 rank table: event rules (S/A) + v0.7.48 strength ladder for the model trade (B/C, D..H). All rates out-of-period."""
import pandas as pd, numpy as np, json
from rule_mine import load
EVENTS = [  # id, rank, clock, minute, feature, threshold, usd_first, label
    ('FIX955_POS', 'S', 'JST', 9 * 60 + 55, 'pos60L', 0.8, True, '仲値(9:55)・60分の端からの戻り'),
    ('JST1220_POS', 'A', 'JST', 12 * 60 + 20, 'pos60L', 0.8, False, '昼(12:20)・60分の端からの戻り'),
    ('JST2250_R15', 'A', 'JST', 22 * 60 + 50, 'r15', 1.0, False, 'NY午前(22:50)・15分の動きの戻り'),
    ('LON0725_R5', 'A', 'LON', 7 * 60 + 25, 'r5', 1.0, False, '欧州勢参入前(ロンドン7:25)・5分の動きの戻り'),
]
ORDER = {'USDJPY': 0, 'EURJPY': 1, 'GBPJPY': 2, 'AUDJPY': 3, 'NZDJPY': 4}
def match_rows(FX):
    out = []
    for i, (eid, rank, clock, mod, feat, th, usd, label) in enumerate(EVENTS):
        col = {'JST': 'jst_min', 'LON': 'lon_min'}[clock]
        S = FX[(FX[col] == mod) & (FX[feat].abs() >= th)].copy(); S['st'] = S[feat].abs().round(12)
        S['k'] = np.where(usd & (S.inst == 'USDJPY'), 0, 1); S['ord'] = S.inst.map(ORDER)
        S = S.sort_values(['b', 'k', 'st', 'ord'], ascending=[True, True, False, True], kind='mergesort').drop_duplicates('b')
        S['dir'] = -np.sign(S[feat]); S['event'] = eid; S['rank'] = rank; S['prio'] = i; S['label'] = label
        out.append(S)
    return pd.concat(out).sort_values(['b', 'prio']).drop_duplicates('b')
if __name__ == '__main__':
    F = load(); FX = F[F.inst != 'BTCJPY'].copy()
    E = match_rows(FX); E['win'] = (E.y * E.dir > 0).astype(float)
    res = {'events': {}, 'weekday': {}, 'weekend': {}, 'fallback': {}}
    days = F.date.nunique()
    for eid, g in E.groupby('event'):
        res['events'][eid] = dict(n=len(g), win=g.win.mean(), per_day=len(g) / days, oct=g[g.october == 1].win.mean(), oct_n=int((g.october == 1).sum()),
                                  P1=g[g.period == 'P1'].win.mean(), P2=g[g.period == 'P2'].win.mean(), P3=g[g.period == 'P3'].win.mean())
    for r in ('S', 'A'):
        g = E[E['rank'] == r]
        res['weekday'][r] = dict(n=len(g), win=g.win.mean(), per_day=len(g) / days, oct=g[g.october == 1].win.mean(), oct_n=int((g.october == 1).sum()))
    X = pd.read_pickle('../work/design_x_fresh.pkl'); X['oct'] = X.date.astype(str).str[5:7] == '10'
    for wk, m in ((True, {'S': 'B', 'A': 'B', 'B': 'C', 'C': 'C'}), (False, {'S': 'B', 'A': 'C', 'B': 'C'})):
        W = X[X.weekday == wk].assign(g=lambda d: d.grade.map(lambda g: m.get(g, g)))
        if wk: W = W[~W.b.isin(E.b)]
        for g, s in W.groupby('g'):
            res['weekday' if wk else 'weekend'][g] = dict(n=len(s), win=s.win.mean(), oct=s[s.oct].win.mean(), oct_n=int(s.oct.sum()),
                                                          share=len(s) / (X.weekday == wk).sum())
    Y = pd.read_pickle('../work/design_x_fallback.pkl')
    for wk, m in ((True, {'S': 'B', 'A': 'B', 'B': 'C', 'C': 'C'}), (False, {'S': 'B', 'A': 'C', 'B': 'C'})):
        W = Y[Y.weekday == wk].assign(g=lambda d: d.grade.map(lambda g: m.get(g, g)))
        res['fallback']['weekday' if wk else 'weekend'] = {g: dict(n=len(s), win=s.win.mean()) for g, s in W.groupby('g')}
    json.dump(res, open('../work/ranks_v0751.json', 'w'), indent=1, default=float, ensure_ascii=False)
    print(json.dumps(res, indent=1, default=lambda x: round(float(x), 4), ensure_ascii=False))
    E.to_pickle('../work/event_signals_v0751.pkl')

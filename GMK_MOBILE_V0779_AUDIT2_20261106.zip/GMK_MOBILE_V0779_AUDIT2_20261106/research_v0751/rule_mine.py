"""Session rules: (session x instrument | session x weekday | Tokyo-fix x USDJPY x gotobi) x simple price rule.
Selection is always done on training rows only; reported rates are on rows not used for selection."""
import pandas as pd, numpy as np, json, sys
from session_feats import add_session, SESSIONS
RULES = {  # name: (mask fn, direction fn)
    'fade_f1': (lambda d: d.f1.abs() >= 0.5, lambda d: -np.sign(d.f1)),
    'follow_f1': (lambda d: d.f1.abs() >= 0.5, lambda d: np.sign(d.f1)),
    'fade_f1_big': (lambda d: d.f1.abs() >= 2.0, lambda d: -np.sign(d.f1)),
    'follow_f1_big': (lambda d: d.f1.abs() >= 2.0, lambda d: np.sign(d.f1)),
    'fade_r5': (lambda d: d.r5.abs() >= 1.0, lambda d: -np.sign(d.r5)),
    'follow_r5': (lambda d: d.r5.abs() >= 1.0, lambda d: np.sign(d.r5)),
    'fade_r15': (lambda d: d.r15.abs() >= 1.0, lambda d: -np.sign(d.r15)),
    'follow_r15': (lambda d: d.r15.abs() >= 1.0, lambda d: np.sign(d.r15)),
    'fade_pos60': (lambda d: d.pos60L.abs() >= 0.8, lambda d: -np.sign(d.pos60L)),
    'follow_pos60': (lambda d: d.pos60L.abs() >= 0.8, lambda d: np.sign(d.pos60L)),
    'HIGH': (lambda d: d.f1 == d.f1, lambda d: pd.Series(1.0, index=d.index)),
    'LOW': (lambda d: d.f1 == d.f1, lambda d: pd.Series(-1.0, index=d.index)),
}
INST = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']
def load():
    F = pd.read_pickle('../work/pattern_frame.pkl')
    F = add_session(F[F.weekday & (F.live_ok == 1)])
    F['y'] = np.sign(F.move3.fillna(0))
    d = F.date.astype(str)
    F['period'] = np.where(d < '2026-02-01', 'P1', np.where(d < '2026-06-01', 'P2', 'P3'))
    F['octyr'] = np.where(F.october == 1, np.where(d < '2026-01-01', 'O25', 'O26'), '')
    return F.reset_index(drop=True)
def cells(F):
    """Long table: one row per (instrument-slot, matching cell) with the cell's trade direction and win."""
    out = []
    keys = {'si': F.session + '|' + F.inst, 'sd': F.session + '|dow' + F.dow.astype(str)}
    fixmask = F.session.isin(['T1_東京朝', 'T2_仲値前後']) & (F.inst == 'USDJPY')
    for rn, (mf, df) in RULES.items():
        m = mf(F); d = df(F)
        for kname, key in keys.items():
            sel = m.values
            out.append(pd.DataFrame({'row': np.where(sel)[0], 'cell': (key[sel] + '|' + rn).values, 'dir': d[sel].values}))
        sel = (m & fixmask).values
        out.append(pd.DataFrame({'row': np.where(sel)[0], 'cell': (F.session[sel] + '|USDJPY|gotobi' + F.gotobi[sel].astype(str) + '|' + rn).values, 'dir': d[sel].values}))
    L = pd.concat(out, ignore_index=True)
    L['win'] = (F.y.values[L.row] * L.dir.values > 0).astype(float)
    L['b'] = F.b.values[L.row]; L['inst'] = F.inst.values[L.row]
    return L
def select(L, train_rows, min_n=100, min_each=0.55, min_all=0.57, parts=None):
    T = L[L.row.isin(train_rows)]
    g = T.groupby('cell').win.agg(['size', 'mean'])
    g = g[(g['size'] >= min_n) & (g['mean'] >= min_all)]
    if parts is not None:   # every part (period) must also reach min_each
        P = T.assign(part=parts[T.row.values]).groupby(['cell', 'part']).win.mean().unstack()
        ok = P.reindex(g.index).min(axis=1) >= min_each
        g = g[ok]
    return g.rename(columns={'size': 'n_train', 'mean': 'rate_train'})
def pick(L, sel, rows):
    """Per slot: the matching selected cell with the highest training rate (ties: larger n)."""
    T = L[L.row.isin(rows) & L.cell.isin(sel.index)].join(sel, on='cell')
    T = T.sort_values(['b', 'rate_train', 'n_train'], ascending=[True, False, False])
    # conflicting directions on the same instrument-slot are dropped
    return T.drop_duplicates('b')
if __name__ == '__main__':
    F = load(); L = cells(F)
    print('rows', len(F), 'cell-rows', len(L), 'cells', L.cell.nunique())
    res = {}
    # 1) rotation over the three periods: select on two, test on the third
    for test in ('P1', 'P2', 'P3'):
        tr = np.where(F.period != test)[0]; te = np.where(F.period == test)[0]
        sel = select(L, tr, parts=F.period.values)
        P = pick(L, sel, te)
        res[f'rot_{test}'] = dict(cells=len(sel), trades=len(P), per_day=len(P) / F.date[F.period == test].nunique(), win=P.win.mean(),
                                  train_rate=P.rate_train.mean())
    # 2) October folds: select without that October, test on it
    for o in ('O25', 'O26'):
        tr = np.where(F.octyr != o)[0]; te = np.where(F.octyr == o)[0]
        sel = select(L, tr, parts=F.period.values)
        P = pick(L, sel, te)
        res[f'oct_{o}'] = dict(cells=len(sel), trades=len(P), per_day=len(P) / F.date[F.octyr == o].nunique(), win=P.win.mean(), train_rate=P.rate_train.mean())
    # 3) chance: shuffle outcomes within (instrument, date) then run the same rotation
    rng = np.random.default_rng(7); Fs = F.copy()
    Fs['y'] = Fs.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values))
    Ls = cells(Fs)
    for test in ('P1', 'P2', 'P3'):
        tr = np.where(Fs.period != test)[0]; te = np.where(Fs.period == test)[0]
        sel = select(Ls, tr, parts=Fs.period.values); P = pick(Ls, sel, te)
        res[f'chance_{test}'] = dict(cells=len(sel), trades=len(P), win=P.win.mean() if len(P) else None)
    print(json.dumps(res, indent=1, default=float))
    json.dump(res, open('../work/rule_rotation.json', 'w'), indent=1, default=float)

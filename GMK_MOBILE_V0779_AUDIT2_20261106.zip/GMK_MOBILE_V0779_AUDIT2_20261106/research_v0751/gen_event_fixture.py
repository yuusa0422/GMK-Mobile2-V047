"""Parity fixture for the Kotlin EventRules: real event-minute slots, raw windows + live prices -> expected rule trade."""
import gzip, sys, random, numpy as np, pandas as pd
src = open('policy_data.py').read().split("d = pd.DataFrame(pickle.load(open('../work/frames_year.pkl'")[0]
exec(src)                                         # bars, index, window(), feats()
from app_sim import pattern_raw
from ranks_v0751 import EVENTS, match_rows
from rule_mine import load
R = lambda x: repr(float(x))
FXS = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
F = load(); FX = F[F.inst != 'BTCJPY'].copy()
E = match_rows(FX)
rng = random.Random(51)
picks = []
for eid in [e[0] for e in EVENTS]:
    g = E[E.event == eid]
    picks += rng.sample(sorted(g.b.unique()), 6)
w = E[(E.event == 'LON0725_R5') & (E.jst_min == 16 * 60 + 25)]          # London rule in winter time (16:25 JST)
picks += rng.sample(sorted(set(w.b) - set(picks)), 3)
ties = E[(E.event == 'FIX955_POS')]
tie_b = [b for b, g in FX[FX.b.isin(ties.b)].groupby('b') if (g.pos60L.abs() >= 0.8).sum() >= 2]
picks += rng.sample(sorted(set(tie_b) - set(picks)), min(3, len(set(tie_b) - set(picks))))
for col, mod in (('jst_min', 595), ('jst_min', 740), ('jst_min', 1370), ('lon_min', 445)):   # rule minutes without a trade
    cand = sorted(set(FX[FX[col] == mod].b) - set(E.b))
    picks += rng.sample(cand, 2)
picks += rng.sample(sorted(set(FX[FX.jst_min == 600].b)), 2)          # 10:00: no rule at all
lines = []
for B in sorted(set(picks)):
    g = FX[FX.b == B]
    lines.append(f'SLOT|{B}|0|{int(g.hour.iloc[0])}')
    for inst in FXS:
        win = window(inst, B)
        lb = index[inst].get((B - 60) * 1000)
        if win is None or lb is None: continue
        live = lb[4]
        for bar in win: lines.append('BAR|' + inst + '|' + '|'.join([str(int(bar[0]))] + [R(x) for x in bar[1:]]))
        f = feats(win, live, False); pr = pattern_raw(win, live, inst)
        lines.append(f'LIVE|{inst}|{R(live)}')
        lines.append(f'EXPV|{inst}|{R(pr["pos60L"])}|{R(f["r5"])}|{R(f["r15"])}')
    m = E[E.b == B]
    if len(m): r = m.iloc[0]; lines.append(f'EXPM|{r.event}|{r.inst}|{"HIGH" if r.dir > 0 else "LOW"}|{R(r[{"FIX955_POS": "pos60L", "JST1220_POS": "pos60L", "JST2250_R15": "r15", "LON0725_R5": "r5"}[r.event]])}')
    else: lines.append('EXPM|NONE')
    lines.append('END')
with gzip.open(sys.argv[1], 'wt') as f: f.write('\n'.join(lines) + '\n')
print('slots', len(set(picks)), 'matched', sum(1 for l in lines if l.startswith('EXPM|') and 'NONE' not in l), 'lines', len(lines))

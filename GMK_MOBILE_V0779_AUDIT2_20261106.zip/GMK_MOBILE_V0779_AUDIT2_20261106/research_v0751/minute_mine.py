"""Event-minute rules: entry minute on the JST / London / New York clock x instrument group x price rule.
Rotation over P1/P2/P3 (select on two, test on the third) + October folds + shuffled-outcome chance."""
import pandas as pd, numpy as np, json
from rule_mine import load
RULES = {
    'fade_f1': (lambda d: d.f1.abs() >= 0.5, lambda d: -np.sign(d.f1)),
    'follow_f1': (lambda d: d.f1.abs() >= 0.5, lambda d: np.sign(d.f1)),
    'fade_r5': (lambda d: d.r5.abs() >= 1.0, lambda d: -np.sign(d.r5)),
    'follow_r5': (lambda d: d.r5.abs() >= 1.0, lambda d: np.sign(d.r5)),
    'fade_r15': (lambda d: d.r15.abs() >= 1.0, lambda d: -np.sign(d.r15)),
    'follow_r15': (lambda d: d.r15.abs() >= 1.0, lambda d: np.sign(d.r15)),
    'fade_pos60': (lambda d: d.pos60L.abs() >= 0.8, lambda d: -np.sign(d.pos60L)),
    'follow_pos60': (lambda d: d.pos60L.abs() >= 0.8, lambda d: np.sign(d.pos60L)),
}
def keys(F):
    j = 'JST|' + (F.jst_min // 60).astype(str).str.zfill(2) + ':' + (F.jst_min % 60).astype(str).str.zfill(2)
    l = 'LON|' + (F.lon_min - 480).astype(str); n = 'NY|' + (F.ny_min - 510).astype(str)
    l = l.where((F.lon_min - 480).between(-60, 240)); n = n.where((F.ny_min - 510).between(-90, 120))
    return [j, l, n]
def cells(F):
    out = []
    grp = np.where(F.inst == 'BTCJPY', 'BTC', 'FX')
    for rn, (mf, df) in RULES.items():
        m = mf(F).values; d = df(F).values
        for k in keys(F):
            ok = m & k.notna().values
            for g in (pd.Series(grp, index=F.index), F.inst):
                out.append(pd.DataFrame({'row': np.where(ok)[0], 'cell': (k[ok] + '|' + g[ok] + '|' + rn).values, 'dir': d[ok]}))
    L = pd.concat(out, ignore_index=True)
    L['win'] = (F.y.values[L.row] * L.dir.values > 0).astype(float); L['b'] = F.b.values[L.row]
    return L
def select(L, tr, part, min_n=120, min_each=0.55, min_all=0.58):
    T = L[L.row.isin(tr)]
    g = T.groupby('cell').win.agg(['size', 'mean']); g = g[(g['size'] >= min_n) & (g['mean'] >= min_all)]
    P = T[T.cell.isin(g.index)].assign(p=part[T[T.cell.isin(g.index)].row.values]).groupby(['cell', 'p']).win.agg(['mean', 'size'])
    mn = P['mean'].unstack().min(axis=1); sz = P['size'].unstack().min(axis=1)
    g = g[(mn.reindex(g.index) >= min_each) & (sz.reindex(g.index) >= 30)]
    return g.rename(columns={'size': 'n_train', 'mean': 'rate_train'})
def pick(L, sel, te):
    T = L[L.row.isin(te) & L.cell.isin(sel.index)].join(sel, on='cell')
    return T.sort_values(['b', 'rate_train', 'n_train'], ascending=[True, False, False]).drop_duplicates('b')
def evaluate(F, L, tag):
    res = {}; part = F.period.values
    for test in ('P1', 'P2', 'P3'):
        tr = np.where(F.period != test)[0]; te = np.where(F.period == test)[0]
        sel = select(L, tr, part); P = pick(L, sel, te)
        per = L[L.row.isin(te) & L.cell.isin(sel.index)].groupby('cell').win.agg(['size', 'mean'])
        res[f'{tag}_rot_{test}'] = dict(cells=len(sel), trades=len(P), per_day=len(P) / max(F.date[F.period == test].nunique(), 1),
                                       win=float(P.win.mean()) if len(P) else None, train=float(P.rate_train.mean()) if len(P) else None,
                                       cells_list=sel.join(per).round(3).reset_index().values.tolist())
    for o in ('O25', 'O26'):
        tr = np.where(F.octyr != o)[0]; te = np.where(F.octyr == o)[0]
        sel = select(L, tr, part); P = pick(L, sel, te)
        res[f'{tag}_oct_{o}'] = dict(cells=len(sel), trades=len(P), per_day=len(P) / max(F.date[F.octyr == o].nunique(), 1),
                                    win=float(P.win.mean()) if len(P) else None)
    return res
if __name__ == '__main__':
    F = load(); L = cells(F)
    print('cells', L.cell.nunique())
    res = evaluate(F, L, 'real')
    rng = np.random.default_rng(11); Fs = F.copy()
    Fs['y'] = Fs.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values))
    res.update(evaluate(Fs, cells(Fs), 'chance'))
    for k, v in res.items():
        print(k, {a: (round(b, 3) if isinstance(b, float) else b) for a, b in v.items() if a != 'cells_list'})
    for k in ('real_rot_P1', 'real_rot_P2', 'real_rot_P3'):
        print('==', k)
        for c in res[k]['cells_list']: print('  ', c)
    json.dump(res, open('../work/minute_rotation.json', 'w'), indent=1, default=float, ensure_ascii=False)

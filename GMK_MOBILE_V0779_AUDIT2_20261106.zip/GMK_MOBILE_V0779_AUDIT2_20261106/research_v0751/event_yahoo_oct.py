"""Event rules on the app's own data source (Yahoo FX 1m) for October 2026 vs Dukascopy for the same slots."""
import csv, gzip, math, bisect, numpy as np, pandas as pd
exec(open('policy_data.py').read().split("SRC = {")[0])
src = open('policy_data.py').read(); exec('def feats' + src.split('def feats', 1)[1].split("d = pd.DataFrame(pickle.load")[0])
from app_sim import window_from, pattern_raw
from session_feats import add_session
from event_rules import EVENTS
FXS = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
def load_hist(p):
    with gzip.open(p, 'rt') as f:
        rows = sorted((int(r['epoch_ms']), float(r['open']), float(r['high']), float(r['low']), float(r['close']), float(r.get('volume') or 0)) for r in csv.DictReader(f))
    return [r[0] for r in rows], rows
SRCH = {'USDJPY': '../hist/USDJPY_merged.csv.gz'}
for s in FXS[1:]: SRCH[s] = f'../hist/combined/{s}_1m.csv.gz'
duka = {s: load_hist(p) for s, p in SRCH.items()}
yah = {}
for s in FXS:
    d = pd.read_csv(f'../m1/yahoo/{s}_1m_JST.csv'); rows = sorted(zip(d.epoch_ms.astype(int), d.open, d.high, d.low, d.close, d.volume.fillna(0)))
    yah[s] = ([r[0] for r in rows], rows)
idx = {k: {s: {r[0]: r for r in a} for s, (t, a) in v.items()} for k, v in (('duka', duka), ('yahoo', yah))}
slots = pd.date_range('2026-10-01', '2026-10-22 23:00', freq='5min', tz='Asia/Tokyo')
S = add_session(pd.DataFrame({'ts': slots}))
S = S[(S.dow <= 5) & S.jst_min.between(9 * 60, 22 * 60 + 55)]
want = set()
for eid, rank, clock, mod, feat, th, label in EVENTS:
    col = {'JST': 'jst_min', 'LON': 'lon_min', 'NY': 'ny_min'}[clock]; want |= set(S[S[col] == mod].ts)
rows = []
for src_name, bars in (('duka', duka), ('yahoo', yah)):
    I = idx[src_name]
    for ts in sorted(want):
        B = int(ts.timestamp())
        for s in FXS:
            t, a = bars[s]; w = window_from(t, a, B)
            if w is None: continue
            live_bar = I[s].get((B - 60) * 1000)
            if live_bar is None: continue
            live = live_bar[4]; f = feats(w, live, False); f.update(pattern_raw(w, live, s))
            o0 = I[s].get(B * 1000); o3 = I[s].get((B + 180) * 1000)
            y = np.sign(o3[1] - o0[1]) if o0 and o3 else np.nan
            rows.append(dict(src=src_name, ts=ts, b=B, inst=s, y=y, f1=f['f1'], r5=f['r5'], r15=f['r15'], pos60L=f['pos60L']))
R = add_session(pd.DataFrame(rows))
for src_name in ('duka', 'yahoo'):
    D = R[R.src == src_name]; out = []
    for eid, rank, clock, mod, feat, th, label in EVENTS:
        col = {'JST': 'jst_min', 'LON': 'lon_min', 'NY': 'ny_min'}[clock]
        X = D[(D[col] == mod) & (D[feat].abs() >= th)].copy(); X['st'] = X[feat].abs()
        X = X.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b'); X['dir'] = -np.sign(X[feat]); X['event'] = eid
        out.append(X)
    E = pd.concat(out); E['win'] = (E.y * E.dir > 0).astype(float)
    print(src_name, E.groupby('event').win.agg(['size', 'mean']).round(3).to_dict('index'), 'ALL', round(E.win.mean(), 3), len(E))
Dk = R[R.src == 'duka'].set_index(['b', 'inst']); Yh = R[R.src == 'yahoo'].set_index(['b', 'inst'])
J = Dk.join(Yh, lsuffix='_d', rsuffix='_y', how='inner')
for c in ('f1', 'r5', 'r15', 'pos60L'): print(c, 'corr duka/yahoo', round(J[c + '_d'].corr(J[c + '_y']), 3))
print('same outcome sign', round((J.y_d == J.y_y).mean(), 3))

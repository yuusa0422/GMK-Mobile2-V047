"""Losing streaks of v0.7.58 (validation, period rotation, exact app rule): are they chance or caused by something?
1) every streak >= 10: time, pairs, directions, spacing, overlap with open trades, catch-up share, hour
2) independence baseline: the same outcomes shuffled (keeps the win rate) -> expected streaks
3) what precedes a loss: open trades on the same pair/direction, same-direction yen exposure, last resolved results"""
import json, math
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
Lw = pd.read_pickle('../work/ladder_v0756.pkl')[['b', 'inst', 'dir']].rename(columns={'inst': 'binst', 'dir': 'bdir'})
Sc = pd.read_pickle('../work/v0758_val_minute_all_fresh.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst'])
Sc['p'] = np.maximum(Sc.pu, Sc.pd); Sc['dir'] = np.where(Sc.pu >= Sc.pd, 1, -1); Sc['w'] = (Sc.move5 == Sc.dir).astype(float)
M = Sc.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b').reset_index(drop=True)
fxr = RTc[RTc.rule.isin(KEEP)].set_index('b')
Bd = Bfix.merge(Lw, on='b', how='left').set_index('b')
def fixed_info(b):
    if b in fxr.index: r = fxr.loc[b]; return ('SA', float(r.win3), r.inst, int(r.dir), 180)
    if b in Bd.index: r = Bd.loc[b]; return ('B', float(r.win5), r.binst, int(r.bdir) if pd.notna(r.bdir) else 0, 300)
    return None
def sim_detail(M, slots, Q, base):
    out = []; Mi = M.set_index('b'); mins = M.groupby(['date', 'hour'])
    S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0; sb = set(g.b)
        allm = set(mins.get_group((d, h)).b) if (d, h) in mins.groups else set()
        for b in sorted(allm | {x for x in sb if fixed_info(x)}):
            minute = (b // 60) % 60
            fi = fixed_info(b) if b in sb else None
            if fi:
                out.append(dict(b=b, g=fi[0], w=fi[1], inst=fi[2], dir=fi[3], forced=0, p=np.nan, end=b + fi[4])); cnt += 1; continue
            if b not in Mi.index: continue
            r = Mi.loc[b]; left = 60 - minute; need = N - cnt
            if need >= left: forced = 1
            elif need > 0 and r.p >= qcut(Q[h], max(need / left, base[h] / 2)): forced = 0
            else: continue
            out.append(dict(b=b, g='C', w=r.w, inst=r.inst, dir=int(r.dir), forced=forced, p=r.p, end=b + 300)); cnt += 1
    return pd.DataFrame(out)
fx = fixed_map(RTc, Bfix); Es = []
for te in ('P1', 'P2', 'P3'):
    tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
    Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
    E = sim_detail(M[M.period == te], tes, Q, base); E['period'] = te; Es.append(E)
E = pd.concat(Es).sort_values('b').reset_index(drop=True)
E['ts'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
print('entries', len(E), 'win', round(E.w.mean() * 100, 2), flush=True)
# ---- streaks
def streaks(w):
    runs = []; c = 0; start = 0
    for i, v in enumerate(w):
        if v == 0:
            if c == 0: start = i
            c += 1
        else:
            if c: runs.append((start, c)); c = 0
    if c: runs.append((start, c))
    return runs
R = streaks(E.w.values); long = [(s, c) for s, c in R if c >= 10]
rng = np.random.default_rng(0); sh = []
for _ in range(300):
    w = rng.permutation(E.w.values); rr = streaks(w); sh.append((sum(1 for _, c in rr if c >= 10), max(c for _, c in rr)))
sh = np.array(sh)
res = dict(entries=len(E), win=round(E.w.mean() * 100, 2), streaks_ge10=len(long), max_streak=max(c for _, c in R),
           shuffled_ge10_mean=round(sh[:, 0].mean(), 1), shuffled_ge10_p95=int(np.percentile(sh[:, 0], 95)), shuffled_max_mean=round(sh[:, 1].mean(), 1),
           shuffled_max_p95=int(np.percentile(sh[:, 1], 95)))
print(json.dumps(res), flush=True)
rows = []
for s, c in long:
    x = E.iloc[s:s + c]
    span = (x.b.iloc[-1] - x.b.iloc[0]) / 60
    pairs = x.inst.value_counts().to_dict(); dirs = (x.dir * 1).value_counts().to_dict()
    yen_dir = x.dir.mean()   # all JPY crosses: +1 = all HIGH (yen weaker)
    rows.append(dict(start=str(x.ts.iloc[0])[:16], n=c, minutes=round(span), pairs=pairs, dirs=dirs, same_dir_share=round(max((x.dir == 1).mean(), (x.dir == -1).mean()), 2),
                     forced=int(x.forced.sum()), grades=x.g.value_counts().to_dict(), hours=sorted(set(x.ts.dt.hour))))
for r_ in rows: print(r_)
# ---- loss precursors (all entries): open trades on the same pair & direction, same-direction open trades, last resolved results
E['open_same'] = 0; E['open_samedir'] = 0; E['open_n'] = 0; E['prev_resolved_losses'] = 0
ends = E[['b', 'end', 'inst', 'dir', 'w']].values
import bisect
bs = E.b.values; order_end = np.argsort(E.end.values); end_sorted = E.end.values[order_end]
for i in range(len(E)):
    b, inst, d = E.b.iat[i], E.inst.iat[i], E.dir.iat[i]
    j0 = bisect.bisect_left(bs, b - 300)
    o = E.iloc[j0:i]; o = o[o.end > b]
    E.at[i, 'open_n'] = len(o); E.at[i, 'open_same'] = int(((o.inst == inst) & (o.dir == d)).sum()); E.at[i, 'open_samedir'] = int((o.dir == d).sum())
    # results known at b: trades whose end <= b, most recent first
    k = bisect.bisect_right(end_sorted, b); known = E.w.values[order_end[:k]][::-1]
    c = 0
    for v in known:
        if v == 0: c += 1
        else: break
    E.at[i, 'prev_resolved_losses'] = c
def tab(col, cap):
    v = E[col].clip(upper=cap); return {int(k): (int(len(g)), round(g.w.mean() * 100, 2)) for k, g in E.groupby(v)}
res['by_open_same_pair_dir'] = tab('open_same', 3); res['by_open_same_dir'] = tab('open_samedir', 5); res['by_prev_resolved_losses'] = tab('prev_resolved_losses', 6)
res['by_forced'] = {int(k): (int(len(g)), round(g.w.mean() * 100, 2)) for k, g in E.groupby('forced')}
for k in ('by_open_same_pair_dir', 'by_open_same_dir', 'by_prev_resolved_losses', 'by_forced'): print(k, res[k], flush=True)
res['streaks'] = rows
json.dump(res, open('../work/v0758_streaks.json', 'w'), indent=1, default=str)
E.to_pickle('../work/v0758_entries_detail.pkl')

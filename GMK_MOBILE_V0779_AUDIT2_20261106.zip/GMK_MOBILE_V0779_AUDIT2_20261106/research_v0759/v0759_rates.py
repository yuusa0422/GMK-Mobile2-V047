"""v0.7.59 (same-direction penalty 0.03): grade rates of the exact app rule (period rotation) - C, D (boundary minutes not entered,
the penalized choice), October; 55%-mode; per period; streaks. Also the 2023-24 check with the production model and tables."""
import json
src = open('v0758_streakfix2.py').read(); exec(src.split("V = {'v0758'")[0])
LAM = 0.03; OCT = 1790780400
def simulate_r(C, F, slots, Q, base, lam=LAM):
    out = []; skips = []
    S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour
    cb = np.array(sorted(C)); opens = []; hours = []
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0; sb = set(g.b)
        lo = bisect.bisect_left(cb, g.b.min()); hi = bisect.bisect_left(cb, g.b.min() + 3600)
        for b in sorted(set(cb[lo:hi].tolist()) | {x for x in sb if x in F}):
            minute = (b // 60) % 60; opens = [o for o in opens if o[0] > b]
            if b in F and b in sb:
                gr, w, inst, dd, L_ = F[b]; out.append((b, gr, w, inst, dd, 0)); cnt += 1; opens.append((b + L_, dd)); continue
            if b not in C: continue
            ps, insts, dirs, ws = C[b]; nopen = {1: sum(1 for o in opens if o[1] == 1), -1: sum(1 for o in opens if o[1] == -1)}
            best = None
            for p, i, dd, w in zip(ps, insts, dirs, ws):
                sc = p - lam * nopen[dd]
                if best is None or sc > best[0]: best = (sc, p, i, dd, w)
            _, p, i, dd, w = best; left = 60 - minute; need = N - cnt
            if need >= left: forced = 1
            elif need > 0 and p >= qcut(Q[h], max(need / left, base[h] / 2)): forced = 0
            else:
                if b in sb: skips.append((b, w))
                continue
            out.append((b, 'C', w, i, dd, forced)); cnt += 1; opens.append((b + 300, dd))
        hours.append(cnt / n)
    E = pd.DataFrame(out, columns=['b', 'g', 'w', 'inst', 'dir', 'forced']); E.attrs['hours_below'] = float(np.mean(np.array(hours) < SHARE - 1e-9))
    return E, pd.DataFrame(skips, columns=['b', 'w'])
Sc = pd.read_pickle('../work/v0758_val_minute_all_fresh.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst']); Sc['p'] = np.maximum(Sc.pu, Sc.pd)
res = {}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'
    Sc = pd.read_pickle(f'../work/v0758_val_minute_all_{k}.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst']); Sc['p'] = np.maximum(Sc.pu, Sc.pd)
    M = Sc.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b').reset_index(drop=True)
    C = cand_table(Sc); F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); Es = []; Ds = []; hb = []
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
        Ct = {b: v for b, v in C.items() if per_cur.get(b - b % 300) == te}
        E, D = simulate_r(Ct, {b: v for b, v in F.items() if b in tes}, tes, Q, base); Es.append(E); Ds.append(D); hb.append(E.attrs['hours_below'])
    E = pd.concat(Es); D = pd.concat(Ds); E.attrs['hours_below'] = float(np.mean(hb))
    rate = lambda x: dict(year=round(x.w.mean(), 4), oct=round(x[x.b >= OCT].w.mean(), 4), oct_n=int((x.b >= OCT).sum()), n=int(len(x)))
    r = summarize(E, len(set(PM.date)), len(slots_cur), per_cur); r.update(C=rate(E[E.g == 'C']), D=rate(D), B=rate(E[E.g == 'B']), SA=rate(E[E.g == 'SA']))
    res[k] = r; print(k, json.dumps(r), flush=True)
json.dump(res, open('../work/v0759_rates.json', 'w'), indent=1)

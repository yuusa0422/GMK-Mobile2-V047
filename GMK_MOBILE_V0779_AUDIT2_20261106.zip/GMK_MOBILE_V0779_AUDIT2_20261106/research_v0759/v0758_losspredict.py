"""Can a loss be told apart at entry time? A classifier on every real-time state of the v0.7.58 entries (period rotation):
market state, yen context, hour/minute, the open trades' marks, recent results, catch-up. AUC on held-out periods, and the win rate
if the worst-scored fifth were replaced; the market-state part also scored on 2023-24 entries."""
import json, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
E = pd.read_pickle('../work/v0758_entries_states2.pkl'); E = E[E.g == 'C'].copy()
E['h'] = E.ts.dt.hour; E['minute'] = E.ts.dt.minute; E['dow'] = E.ts.dt.dayofweek
MKT = ['h', 'minute', 'dow', 'dir', 's_r1', 's_r5', 's_r15', 's_r30', 's_r60', 's_pos15', 's_pos60', 's_bbz', 's_f1', 'rv60', 'rv30_60',
       's_yen30m', 's_yen60m', 's_yen120m', 's_yen240m', 's_yen_consist30', 's_yen_pos240', 'yen_vol_ratio', 'forced']
POL = ['n_open_same', 'n_under', 'worst_mtm', 'prev_resolved_losses', 'open_samedir', 'open_n']
POL = [c for c in POL if c in E.columns]
res = {}
for name, cols in (('market', MKT), ('market+positions', MKT + POL)):
    aucs = {}; parts = []
    for te in ('P1', 'P2', 'P3'):
        tr, ts = E[E.period != te], E[E.period == te]
        m = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=200, random_state=0)
        m.fit(tr[cols].values, (tr.w == 0).astype(int)); s = m.predict_proba(ts[cols].values)[:, 1]
        aucs[te] = round(roc_auc_score((ts.w == 0).astype(int), s), 4); parts.append(ts.assign(loss_score=s))
    X = pd.concat(parts); q = X.groupby('period').loss_score.rank(pct=True)
    res[name] = dict(auc=aucs, win_by_score_fifth={int(k): round(g.w.mean() * 100, 2) for k, g in X.groupby(np.minimum((q * 5).astype(int), 4))},
                     win_without_worst_fifth=round(X[q < 0.8].w.mean() * 100, 2), win_all=round(X.w.mean() * 100, 2))
    print(name, json.dumps(res[name]), flush=True)
# trained on the whole current year, scored on 2023-24 entries (market part only; positions are not reconstructed there)
P = pd.read_pickle('../work/v0758_past_entries_states.pkl')
cols = ['dir', 's_r15', 's_yen30m', 's_yen120m']
m = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=200, random_state=0)
m.fit(E[cols].assign(h=E.h).values, (E.w == 0).astype(int))
s = m.predict_proba(P[cols].assign(h=P.hour).values)[:, 1]
res['past_auc_small'] = round(roc_auc_score((P.w == 0).astype(int), s), 4); print('2023-24 AUC (hour, direction, 15-min move, yen 30/120 min):', res['past_auc_small'])
json.dump(res, open('../work/v0758_losspredict.json', 'w'), indent=1)

"""Second round: soft same-direction penalty, caps, and the hour rule compliance; best ones also on 2023-24 (production model + tables)."""
import json
exec(open('v0758_streakfix.py').read().split("if __name__ == '__main__':")[0])
def simulate_w(C, F, slots, Q, base, cap=None, lam=0.0, cap_hi=None, free_forced=False):
    """cap: max open trades in one direction; lam: choose by p - lam * open trades in that direction;
    cap_hi: a candidate above the hour's top-5% p may exceed the cap by one"""
    out = []
    S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour
    cb = np.array(sorted(C)); opens = []; hours = []
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0; sb = set(g.b)
        lo = bisect.bisect_left(cb, g.b.min()); hi = bisect.bisect_left(cb, g.b.min() + 3600)
        mins = sorted(set(cb[lo:hi].tolist()) | {x for x in sb if x in F})
        top5 = qcut(Q[h], 0.05)
        for b in mins:
            minute = (b // 60) % 60; opens = [o for o in opens if o[0] > b]
            if b in F and b in sb:
                gr, w, inst, dd, L_ = F[b]; out.append((b, gr, w, inst, dd, 0)); cnt += 1; opens.append((b + L_, dd)); continue
            if b not in C: continue
            ps, insts, dirs, ws = C[b]; nopen = {1: sum(1 for o in opens if o[1] == 1), -1: sum(1 for o in opens if o[1] == -1)}
            best = None; catch = (N - cnt) >= (60 - minute)
            for p, i, dd, w in zip(ps, insts, dirs, ws):
                if cap is not None and not (free_forced and catch) and nopen[dd] >= cap and not (cap_hi and p >= top5 and nopen[dd] < cap + 1): continue
                sc = p - lam * nopen[dd]
                if best is None or sc > best[0]: best = (sc, p, i, dd, w)
            if best is None: continue
            _, p, i, dd, w = best; left = 60 - minute; need = N - cnt
            if need >= left: forced = 1
            elif need > 0 and p >= qcut(Q[h], max(need / left, base[h] / 2)): forced = 0
            else: continue
            out.append((b, 'C', w, i, dd, forced)); cnt += 1; opens.append((b + 300, dd))
        hours.append(cnt / n)
    E = pd.DataFrame(out, columns=['b', 'g', 'w', 'inst', 'dir', 'forced']); E.attrs['hours_below'] = float(np.mean(np.array(hours) < SHARE - 1e-9)); return E
def summarize(E, ndays, nslots, per):
    s10, mx = streak_stats(E.sort_values('b').w.values)
    pr = E.b.map(lambda b: per.get(b - b % 300))
    return dict(win=round(E.w.mean() * 100, 2), per_day=round(len(E) / ndays, 1), entries_per_slot=round(len(E) / nslots * 100, 1), streaks_ge10=s10, max_streak=mx,
                high_share=round((E.dir == 1).mean() * 100, 1), forced=round(E.forced.mean() * 100, 1), hours_below_70=round(E.attrs.get('hours_below', 0) * 100, 2),
                periods={p: round(E[pr == p].w.mean() * 100, 2) for p in sorted(pr.dropna().unique())})
V = {'cap2_free': dict(cap=2, free_forced=True), 'cap3_free': dict(cap=3, free_forced=True), 'lam0.03': dict(lam=0.03), 'cap2_free_lam0.01': dict(cap=2, free_forced=True, lam=0.01)}
V_OLD = {'v0758': {}, 'cap2': dict(cap=2), 'cap3': dict(cap=3), 'cap2_hi': dict(cap=2, cap_hi=True), 'lam0.005': dict(lam=0.005), 'lam0.01': dict(lam=0.01),
     'lam0.02': dict(lam=0.02), 'lam0.04': dict(lam=0.04), 'cap3_lam0.01': dict(cap=3, lam=0.01)}
Sc = pd.read_pickle('../work/v0758_val_minute_all_fresh.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst']); Sc['p'] = np.maximum(Sc.pu, Sc.pd)
M = Sc.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b').reset_index(drop=True)
C = cand_table(Sc); F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); tabs = {}
for te in ('P1', 'P2', 'P3'):
    tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
    tabs[te] = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs))
ndays = len(set(PM.date)); res = {}
for name, kw in V.items():
    Es = []; hb = []
    for te in ('P1', 'P2', 'P3'):
        Q, base = tabs[te]; tes = set(b for b in slots_cur if per_cur.get(b) == te)
        Ct = {b: v for b, v in C.items() if per_cur.get(b - b % 300) == te}
        E = simulate_w(Ct, {b: v for b, v in F.items() if b in tes}, tes, Q, base, **kw); hb.append(E.attrs['hours_below']); Es.append(E)
    E = pd.concat(Es); E.attrs['hours_below'] = float(np.mean(hb))
    res[name] = summarize(E, ndays, len(slots_cur), per_cur); print('current', name, json.dumps(res[name]), flush=True)
# 2023-24 with the production model and the production tables
ms = fit(PM, True, extra=EX); pu, pdn = pred(ms, PY, True, extra=EX)
Sy = PY[['b', 'inst', 'hour', 'period', 'date', 'move5']].assign(pu=pu, pd=pdn); Sy['p'] = np.maximum(Sy.pu, Sy.pd)
pu0, pd0 = pred(ms, PM, True, extra=EX); Sp = PM[['b', 'inst', 'hour', 'period', 'date', 'move5']].assign(pu=pu0, pd=pd0); Sp['p'] = np.maximum(Sp.pu, Sp.pd)
Mp = Sp.sort_values('p', ascending=False).groupby('b').head(1); Qp, basep = tables(Mp, fx, hour_of(slots_cur))
Cy = cand_table(Sy); slots_y = set(PY[PY.k == 0].slot); Fy = fixed_lookup(RTp, None); per_y = dict(zip(PY.slot, PY.period))
for name in V:
    E = simulate_w(Cy, {b: v for b, v in Fy.items() if b in slots_y}, slots_y, Qp, basep, **V[name])
    res['past_' + name] = summarize(E, len(set(PY.date)), len(slots_y), per_y); print('2023-24', name, json.dumps(res['past_' + name]), flush=True)
json.dump(res, open('../work/v0758_streakfix3.json', 'w'), indent=1)

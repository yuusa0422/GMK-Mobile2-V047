"""How v0.7.58 loses: market state at entry for trades inside losing streaks (>= 6) vs the rest, and win rate by state.
States (signed by the trade direction: + = with the recent move, - = against it): pair moves r1..r60, yen factor 5/15/30/60/120/240 min,
yen trend consistency (share of the last 30 minutes moving the same way), position in the 4-hour yen range, volatility, hour."""
import json, math, gzip, csv
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
E = pd.read_pickle('../work/v0758_entries_detail.pkl').sort_values('b').reset_index(drop=True)
# ---- yen index per minute from the M1 bars (mean log move of USD/EUR/GBP/AUD vs JPY), as the app could compute from its candles
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
lr = []
for s, p in SRC.items():
    B = pd.read_csv(p); B['m'] = (B.epoch_ms // 60000).astype(np.int64); c = B.drop_duplicates('m').set_index('m').close
    full = pd.Series(np.nan, index=np.arange(c.index.min(), c.index.max() + 1)); full.loc[c.index] = np.log(c.values); lr.append(full.diff())
Y = pd.concat(lr, axis=1).mean(axis=1, skipna=False)          # 1-minute yen-cross move (NaN when any pair is missing)
cum = Y.fillna(0).cumsum(); vol = Y.rolling(60, min_periods=40).std()
def yfeat(bs):
    m = bs // 60 - 1                                            # last closed bar = the one opening at B-60 (price at ~B, like the live price)
    f = {}
    for k in (5, 15, 30, 60, 120, 240):
        f[f'yen{k}m'] = (cum.reindex(m).values - cum.reindex(m - k).values) / (vol.reindex(m).values * np.sqrt(k))
    sgn = np.sign(Y)
    f['yen_consist30'] = np.array([np.nan if not np.isfinite(x) else x for x in (sgn.rolling(30, min_periods=20).mean().reindex(m).values)])
    hi = cum.rolling(240, min_periods=120).max(); lo = cum.rolling(240, min_periods=120).min()
    f['yen_pos240'] = ((cum.reindex(m).values - lo.reindex(m).values) / np.maximum(hi.reindex(m).values - lo.reindex(m).values, 1e-12)) * 2 - 1
    f['yen_vol_ratio'] = (Y.rolling(15, min_periods=10).std().reindex(m).values / Y.rolling(240, min_periods=120).std().reindex(m).values)
    return pd.DataFrame(f)
E = pd.concat([E, yfeat(E.b.values)], axis=1)
E = E.merge(PM[['b', 'inst', 'r1', 'r5', 'r15', 'r30', 'r60', 'pos15', 'pos60', 'bbz', 'f1', 'yen5', 'yen15', 'rv60', 'rv30_60', 'regime']], on=['b', 'inst'], how='left')
for c in ['yen5m', 'yen15m', 'yen30m', 'yen60m', 'yen120m', 'yen240m', 'yen_consist30', 'yen_pos240', 'r1', 'r5', 'r15', 'r30', 'r60', 'pos15', 'pos60', 'bbz', 'f1']:
    E['s_' + c] = E[c] * E.dir                                  # + = trade goes with the move / is at the high end for HIGH
# streak membership
runs = np.zeros(len(E), int); c = 0; start = 0
w = E.w.values
for i in range(len(E) + 1):
    if i < len(E) and w[i] == 0:
        if c == 0: start = i
        c += 1
    else:
        if c: runs[start:start + c] = c
        c = 0
E['run'] = runs; E['in_streak6'] = E.run >= 6
out = {'n': len(E), 'win': round(E.w.mean() * 100, 2), 'streak6_share': round(E.in_streak6.mean() * 100, 1)}
cols = [c for c in E.columns if c.startswith('s_')] + ['yen_vol_ratio', 'rv60', 'rv30_60']
diff = {}
for c in cols:
    a = E.loc[E.in_streak6, c].dropna(); b_ = E.loc[~E.in_streak6 & (E.w == 1), c].dropna()
    diff[c] = dict(streak=round(a.median(), 3), wins=round(b_.median(), 3), d=round((a.mean() - b_.mean()) / (E[c].std() + 1e-12), 3))
out['streak_vs_wins'] = dict(sorted(diff.items(), key=lambda kv: -abs(kv[1]['d'])))
print('streak trades vs winning trades (standardized difference d):'); [print(' ', k, v) for k, v in list(out['streak_vs_wins'].items())[:12]]
# win rate by quintile of the strongest states (period-wise, to see stability)
bins = {}
for c in [k for k, _ in list(out['streak_vs_wins'].items())[:8]]:
    q = pd.qcut(E[c].rank(method='first'), 5, labels=False)
    t = E.assign(q=q).groupby(['q']).agg(n=('w', 'size'), win=('w', 'mean'), lo=(c, 'min'), hi=(c, 'max'))
    t['win'] = (t.win * 100).round(2); t[['lo', 'hi']] = t[['lo', 'hi']].round(2)
    per = E.assign(q=q).groupby(['q', 'period']).w.mean().unstack().mul(100).round(1)
    bins[c] = t.join(per).reset_index().to_dict('records'); print(c); print(t.join(per).to_string())
out['quintiles'] = bins
json.dump(out, open('../work/v0758_losspattern.json', 'w'), indent=1, default=str)
E.to_pickle('../work/v0758_entries_states.pkl')

"""2023-24 entries of v0.7.58 (production model + production tables) with their market state, to check whether the loss patterns
found on the current year (Tokyo lunch fades, trades against the 2-hour yen trend) also hold on years the app never saw."""
import json, math
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
def yen_index(paths):
    lr = []
    for p in paths:
        B = pd.read_csv(p); B['m'] = (B.epoch_ms // 60000).astype(np.int64); c = B.drop_duplicates('m').set_index('m').close
        full = pd.Series(np.nan, index=np.arange(c.index.min(), c.index.max() + 1)); full.loc[c.index] = np.log(c.values); lr.append(full.diff())
    return pd.concat(lr, axis=1).mean(axis=1, skipna=False)
def ymove(Y, bs, k):
    cum = Y.fillna(0).cumsum(); vol = Y.rolling(60, min_periods=40).std(); m = bs // 60 - 1
    return (cum.reindex(m).values - cum.reindex(m - k).values) / (vol.reindex(m).values * np.sqrt(k))
ms = fit(PM, True, extra=EX)
pu, pdn = pred(ms, PM, True, extra=EX); Mp = best_minutes(PM, pu, pdn); fx = fixed_map(RTc, Bfix); Q, base = tables(Mp, fx, hour_of(slots_cur))
pu, pdn = pred(ms, PY, True, extra=EX)
X = PY[['b', 'slot', 'k', 'inst', 'hour', 'period', 'date', 'move5', 'r15']].assign(pu=pu, pd=pdn); X['p'] = np.maximum(X.pu, X.pd); X['dir'] = np.where(X.pu >= X.pd, 1, -1)
X['w'] = (X.move5 == X.dir).astype(float); My = X.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b').reset_index(drop=True)
slots_y = set(PY[PY.k == 0].slot); fxy = {b: v for b, v in fixed_map(RTp, None).items() if b in slots_y}
# entries with their minute rows (simulate() keeps b; the C rows map back to My)
E, H = simulate(My, fxy, slots_y, Q, base)
C = E[E.g == 'C'].merge(My[['b', 'inst', 'dir', 'r15', 'hour', 'period']], on='b', how='left')
Yp = yen_index([f'/tmp/gmkdata/years/{s}_1m.csv.gz' for s in ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY']])
C['s_yen120m'] = ymove(Yp, C.b.values, 120) * C.dir; C['s_yen30m'] = ymove(Yp, C.b.values, 30) * C.dir; C['s_r15'] = C.r15 * C.dir
def show(X, name):
    f = X.s_r15 < -1
    print(name, 'n', len(X), 'win', round(X.w.mean() * 100, 2), '| fade15', round(X[f].w.mean() * 100, 2), int(f.sum()), 'other', round(X[~f].w.mean() * 100, 2),
          '| with 2h', round(X[X.s_yen120m > 0].w.mean() * 100, 2), int((X.s_yen120m > 0).sum()), 'against', round(X[X.s_yen120m < 0].w.mean() * 100, 2),
          '| with 30m', round(X[X.s_yen30m > 0].w.mean() * 100, 2), 'against', round(X[X.s_yen30m < 0].w.mean() * 100, 2), flush=True)
show(C[C.hour.isin([12, 13])], '2023-24 12-13h'); show(C[C.hour == 16], '2023-24 16h'); show(C[~C.hour.isin([12, 13, 16])], '2023-24 other')
print('by hour', C.groupby('hour').w.mean().mul(100).round(1).to_dict())
C.to_pickle('../work/v0758_past_entries_states.pkl')

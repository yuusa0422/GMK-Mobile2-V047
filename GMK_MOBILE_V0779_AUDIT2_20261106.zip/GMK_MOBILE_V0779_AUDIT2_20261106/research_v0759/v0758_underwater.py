"""Real-time state the app can see: are the open trades of the same direction under water right now (price since their entry)?
For each new entry: n open same-direction trades, how many are losing at this moment, and what the alternatives at this minute
(other pairs, other direction, waiting) would have won."""
import json, bisect
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
E = pd.read_pickle('../work/v0758_entries_states.pkl').sort_values('b').reset_index(drop=True)
E['end'] = np.where(E.g == 'SA', E.b + 180, E.b + 300)
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
LP = {}; VOL = {}
for s, p in SRC.items():
    B = pd.read_csv(p); B['m'] = (B.epoch_ms // 60000).astype(np.int64); B = B.drop_duplicates('m').set_index('m')
    LP[s] = np.log(B.open); VOL[s] = np.log(B.close).diff().rolling(60, min_periods=40).std()
def px(s, b): return LP[s].get(b // 60, np.nan)                 # open of the minute starting at b (= the research entry price)
nu = []; nopen = []; worst = []
bs = E.b.values
for i in range(len(E)):
    b, d = E.b.iat[i], E.dir.iat[i]
    j0 = bisect.bisect_left(bs, b - 300); o = E.iloc[j0:i]; o = o[(o.end > b) & (o.dir == d) & o.inst.notna()]
    m = []
    for r in o.itertuples(index=False):
        v = VOL[r.inst].get(b // 60, np.nan)
        if r.inst in LP and np.isfinite(v) and v > 0: m.append(d * (px(r.inst, b - 60) - px(r.inst, r.b)) / v)   # price at ~B-10s vs entry
    m = np.array(m); nopen.append(len(m)); nu.append(int((m < 0).sum()) if len(m) else 0); worst.append(m.min() if len(m) else np.nan)
E['n_open_same'] = nopen; E['n_under'] = nu; E['worst_mtm'] = worst
E['state'] = np.select([E.n_open_same == 0, E.n_under == 0, E.n_under < E.n_open_same], ['no open', 'open all winning', 'open mixed'], 'open all losing')
t = E.groupby('state').agg(n=('w', 'size'), win=('w', 'mean')); t['win'] = (t.win * 100).round(2)
per = E.groupby(['state', 'period']).w.mean().unstack().mul(100).round(1); print(t.join(per).to_string(), flush=True)
t2 = E[E.n_open_same > 0].groupby(pd.cut(E.worst_mtm, [-99, -3, -2, -1, -0.5, 0, 0.5, 1, 2, 99])).agg(n=('w', 'size'), win=('w', 'mean'))
t2['win'] = (t2.win * 100).round(2); print('by the worst open same-direction trade (sigma since its entry)'); print(t2.to_string(), flush=True)
# alternatives at the same minute for 'open all losing'
Sc = pd.read_pickle('../work/v0758_val_minute_all_fresh.pkl')
A = pd.concat([Sc[['b', 'inst', 'move5']].assign(p=Sc.pu, dir=1), Sc[['b', 'inst', 'move5']].assign(p=Sc.pd, dir=-1)]); A['w'] = (A.move5 == A.dir).astype(float)
L = E[E.state == 'open all losing'][['b', 'inst', 'dir', 'w', 'period']]
opp = A.merge(L[['b', 'dir']].assign(dir=-L.dir), on=['b', 'dir']).sort_values('p', ascending=False).groupby('b').head(1)
same_other = A.merge(L[['b', 'dir', 'inst']].rename(columns={'inst': 'linst'}), on=['b', 'dir']); same_other = same_other[same_other.inst != same_other.linst].sort_values('p', ascending=False).groupby('b').head(1)
# waiting: the same pair/direction 1..4 minutes later (entry price later, 5-minute judgement from there)
wait = {}
for k in (1, 2, 3, 5, 10):
    x = L.assign(b2=L.b + 60 * k).merge(A.rename(columns={'b': 'b2'}), left_on=['b2', 'inst', 'dir'], right_on=['b2', 'inst', 'dir'], suffixes=('', '_l'))
    wait[k] = (len(x), round(x.w_l.mean() * 100, 2))
res = dict(states=t.join(per).reset_index().to_dict('records'),
           all_losing=dict(n=len(L), current=round(L.w.mean() * 100, 2), opposite_best=round(opp.w.mean() * 100, 2), same_dir_other_pair=round(same_other.w.mean() * 100, 2),
                           same_trade_later=wait))
print(json.dumps(res['all_losing']), flush=True)
json.dump(res, open('../work/v0758_underwater.json', 'w'), indent=1, default=str)
E.to_pickle('../work/v0758_entries_states2.pkl')

"""Streak fixes under the same every-hour-70% rule. Candidates per minute = 5 pairs x 2 directions (the 5-minute model's p of each).
Variants: cap on open trades in the same direction (all five are yen crosses, so the same direction is the same yen bet);
block a direction after L resolved losses in a row in that direction for T minutes; both. Metrics: win, streaks >= 10, max streak."""
import json, math, sys, bisect
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
Lw = pd.read_pickle('../work/ladder_v0756.pkl')[['b', 'inst', 'dir']].rename(columns={'inst': 'binst', 'dir': 'bdir'})
def cand_table(Sc):
    """b -> (p array desc, inst array, dir array, win array) over the 10 pair-direction candidates"""
    A = pd.concat([Sc[['b', 'inst', 'hour', 'period', 'date', 'move5']].assign(p=Sc.pu, dir=1), Sc[['b', 'inst', 'hour', 'period', 'date', 'move5']].assign(p=Sc.pd, dir=-1)])
    A['w'] = (A.move5 == A.dir).astype(float); A = A.sort_values(['b', 'p'], ascending=[True, False])
    C = {}
    for b, g in A.groupby('b', sort=True): C[b] = (g.p.values, g.inst.values, g.dir.values, g.w.values)
    return C
def fixed_lookup(RT, Bfix):
    F = {}
    r = RT[RT.rule.isin(KEEP)]
    for b, w, i, d in zip(r.b, r.win3, r.inst, r.dir): F[b] = ('SA', float(w), i, int(d), 180)
    if Bfix is not None:
        x = Bfix.merge(Lw, on='b', how='left')
        for b, w, i, d in zip(x.b, x.win5, x.binst, x.bdir):
            if b not in F: F[b] = ('B', float(w), i, int(d) if pd.notna(d) else 0, 300)
    return F
def simulate_v(C, F, slots, Q, base, cap=None, block_L=None, block_T=0):
    out = []
    S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour
    cb = np.array(sorted(C)); opens = []   # (end, dir)
    resolved = []                          # (end, dir, w) appended when entered; read when end <= now
    blocked_until = {1: -1, -1: -1}
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0; sb = set(g.b)
        lo = bisect.bisect_left(cb, g.b.min()); hi = bisect.bisect_left(cb, g.b.min() + 3600)
        mins = sorted(set(cb[lo:hi].tolist()) | {x for x in sb if x in F})
        for b in mins:
            minute = (b // 60) % 60
            opens = [o for o in opens if o[0] > b]
            if block_L:
                for dd in (1, -1):
                    seq = []
                    for x in reversed(resolved):
                        if x[1] != dd or x[0] > b: continue
                        seq.append(x)
                        if len(seq) == block_L: break
                    if len(seq) == block_L and all(x[2] == 0 for x in seq) and max(x[0] for x in seq) + block_T * 60 > b:
                        blocked_until[dd] = max(blocked_until[dd], max(x[0] for x in seq) + block_T * 60)
                if len(resolved) > 200: resolved = resolved[-200:]
            if b in F and b in sb:
                gr, w, inst, dd, L_ = F[b]; out.append((b, gr, w, inst, dd, 0)); cnt += 1; opens.append((b + L_, dd)); resolved.append((b + L_, dd, w)); continue
            if b not in C: continue
            ps, insts, dirs, ws = C[b]; pick = None
            for p, i, dd, w in zip(ps, insts, dirs, ws):
                if cap is not None and sum(1 for o in opens if o[1] == dd) >= cap: continue
                if block_L and blocked_until[dd] > b: continue
                pick = (p, i, dd, w); break
            if pick is None: continue
            left = 60 - minute; need = N - cnt
            if need >= left: forced = 1
            elif need > 0 and pick[0] >= qcut(Q[h], max(need / left, base[h] / 2)): forced = 0
            else: continue
            out.append((b, 'C', pick[3], pick[1], pick[2], forced)); cnt += 1; opens.append((b + 300, pick[2])); resolved.append((b + 300, pick[2], pick[3]))
    return pd.DataFrame(out, columns=['b', 'g', 'w', 'inst', 'dir', 'forced'])
def streak_stats(w):
    runs = []; c = 0
    for v in w:
        if v == 0: c += 1
        else:
            if c: runs.append(c); c = 0
    if c: runs.append(c)
    return sum(1 for r in runs if r >= 10), max(runs)
def run_current(variants):
    Sc = pd.read_pickle('../work/v0758_val_minute_all_fresh.pkl').merge(PM[['b', 'inst', 'date']], on=['b', 'inst'])
    Sc['p'] = np.maximum(Sc.pu, Sc.pd)
    M = Sc.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b').reset_index(drop=True); M['w'] = 0.0
    C = cand_table(Sc); F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); res = {}
    tabs = {}
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        tabs[te] = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs))
    for name, kw in variants.items():
        Es = []
        for te in ('P1', 'P2', 'P3'):
            Q, base = tabs[te]; tes = set(b for b in slots_cur if per_cur.get(b) == te)
            Ct = {b: v for b, v in C.items() if per_cur.get(b - b % 300) == te}
            E = simulate_v(Ct, {b: v for b, v in F.items() if b in tes}, tes, Q, base, **kw); E['period'] = te; Es.append(E)
        E = pd.concat(Es).sort_values('b'); s10, mx = streak_stats(E.w.values)
        res[name] = dict(win=round(E.w.mean() * 100, 2), per_day=round(len(E) / len(set(PM.date)), 1), entries_per_slot=round(len(E) / len(slots_cur) * 100, 1),
                         streaks_ge10=s10, max_streak=mx, **{p: round(E[E.period == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')},
                         forced=round(E.forced.mean() * 100, 1))
        print(name, json.dumps(res[name]), flush=True)
    return res
if __name__ == '__main__':
    V = {'v0758': {}, 'cap1': dict(cap=1), 'cap2': dict(cap=2), 'cap3': dict(cap=3),
         'block3_30': dict(block_L=3, block_T=30), 'block2_20': dict(block_L=2, block_T=20), 'block3_60': dict(block_L=3, block_T=60),
         'cap2_block3_30': dict(cap=2, block_L=3, block_T=30)}
    res = run_current(V)
    json.dump(res, open('../work/v0758_streakfix.json', 'w'), indent=1)

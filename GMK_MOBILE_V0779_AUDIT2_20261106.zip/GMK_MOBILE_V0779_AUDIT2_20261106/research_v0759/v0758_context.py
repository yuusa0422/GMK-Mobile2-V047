"""Give the every-minute 5-minute model the longer yen context (30/60/120/240-minute yen-cross index moves, 30-minute consistency,
position in the 4-hour range, short/long volatility ratio), so it can learn when moves continue (e.g. Tokyo lunch) instead of fading them.
Rotation validation with the exact app rule, streaks, by-hour; then production on the year -> 2023-24."""
import json, sys
src = open('v0758_production.py').read(); exec(src.split("out = {}")[0])
def streak_stats(w):
    runs = []; c = 0
    for v in w:
        if v == 0: c += 1
        else:
            if c: runs.append(c); c = 0
    if c: runs.append(c)
    return sum(1 for r in runs if r >= 10), max(runs)
CAP = sys.argv[1] if len(sys.argv) > 1 else 'ctx'
def yen_index(paths):
    lr = []
    for p in paths:
        B = pd.read_csv(p); B['m'] = (B.epoch_ms // 60000).astype(np.int64); c = B.drop_duplicates('m').set_index('m').close
        full = pd.Series(np.nan, index=np.arange(c.index.min(), c.index.max() + 1)); full.loc[c.index] = np.log(c.values); lr.append(full.diff())
    idx = pd.concat(lr, axis=1).index
    return pd.concat(lr, axis=1).mean(axis=1, skipna=False)
def yfeat(Y, bs):
    cum = Y.fillna(0).cumsum(); vol = Y.rolling(60, min_periods=40).std(); m = bs // 60 - 1; f = {'b': bs}
    for k in (30, 60, 120, 240):
        f[f'yen{k}m'] = np.clip((cum.reindex(m).values - cum.reindex(m - k).values) / (vol.reindex(m).values * np.sqrt(k)), -8, 8)
    f['yen_consist30'] = np.sign(Y).rolling(30, min_periods=20).mean().reindex(m).values
    hi = cum.rolling(240, min_periods=120).max(); lo = cum.rolling(240, min_periods=120).min()
    f['yen_pos240'] = ((cum.reindex(m).values - lo.reindex(m).values) / np.maximum(hi.reindex(m).values - lo.reindex(m).values, 1e-12)) * 2 - 1
    f['yen_vol_ratio'] = np.clip(Y.rolling(15, min_periods=10).std().reindex(m).values / Y.rolling(240, min_periods=120).std().reindex(m).values, 0, 6)
    return pd.DataFrame(f)
cur_paths = ['../hist/USDJPY_merged.csv.gz'] + [f'../hist/combined/{s}_1m.csv.gz' for s in ['EURJPY', 'GBPJPY', 'AUDJPY']]
past_paths = [f'/tmp/gmkdata/years/{s}_1m.csv.gz' for s in ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY']]
Yc = yen_index(cur_paths); Yp = yen_index(past_paths)
CTX = ['yen30m', 'yen60m', 'yen120m', 'yen240m', 'yen_consist30', 'yen_pos240', 'yen_vol_ratio']
PMc = PM.merge(yfeat(Yc, np.sort(PM.b.unique())), on='b', how='left'); PYc = PY.merge(yfeat(Yp, np.sort(PY.b.unique())), on='b', how='left')
EXc = [('isk0', False)] + [(c, c not in ('yen_vol_ratio',)) for c in CTX]
cfg = dict(CFG, max_leaf_nodes=15) if CAP == 'ctx15' else (dict(CFG, max_leaf_nodes=15) if CAP == 'base15' else CFG)
ex = EXc if CAP.startswith('ctx') else EX
print('context coverage', {c: round(np.isfinite(PMc[c]).mean() * 100, 1) for c in CTX}, flush=True)
path = f'../work/v0758_val_{CAP}_fresh.pkl'
if os.path.exists(path): Sc = pd.read_pickle(path)
else:
    parts = []
    for te in ('P1', 'P2', 'P3'):
        ms = fit(PMc[PMc.period != te], True, extra=ex, cfg=cfg); B = PMc[PMc.period == te]; pu, pdn = pred(ms, B, True, extra=ex)
        parts.append(B[['b', 'slot', 'k', 'inst', 'hour', 'period', 'move5']].assign(pu=pu, pd=pdn)); print('  fit', CAP, te, flush=True)
    Sc = pd.concat(parts); Sc.to_pickle(path)
Sc = Sc.merge(PM[['b', 'inst', 'date']], on=['b', 'inst'])
M = best_minutes(Sc, Sc.pu.values, Sc.pd.values); fx = fixed_map(RTc, Bfix); Es = []
for te in ('P1', 'P2', 'P3'):
    tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
    Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
    E, H = simulate(M[M.period == te], {b: v for b, v in fx.items() if b in tes}, tes, Q, base); Es.append(E)
E = pd.concat(Es).sort_values('b'); E['h'] = ((E.b + 9 * 3600) // 3600) % 24
s10, mx = streak_stats(E.w.values); pr = E.b.map(lambda b: per_cur.get(b - b % 300))
r = dict(variant=CAP, win=round(E.w.mean() * 100, 2), streaks_ge10=s10, max_streak=mx, periods={p: round(E[pr == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')},
         lunch=round(E[E.h.isin([12, 13])].w.mean() * 100, 2), h16=round(E[E.h == 16].w.mean() * 100, 2), per_day=round(len(E) / len(set(PM.date)), 1))
print('validation', json.dumps(r), flush=True)
# production on the year -> 2023-24 (production tables)
ms = fit(PMc, True, extra=ex, cfg=cfg); pu, pdn = pred(ms, PMc, True, extra=ex); Mp = best_minutes(PMc, pu, pdn)
Q, base = tables(Mp, fx, hour_of(slots_cur))
pu, pdn = pred(ms, PYc, True, extra=ex); My = best_minutes(PYc, pu, pdn); slots_y = set(PY[PY.k == 0].slot); fxy = fixed_map(RTp, None)
E, H = simulate(My, {b: v for b, v in fxy.items() if b in slots_y}, slots_y, Q, base); E = E.sort_values('b'); E['h'] = ((E.b + 9 * 3600) // 3600) % 24
s10, mx = streak_stats(E.w.values); per_y = dict(zip(PY.slot, PY.period)); pr = E.b.map(lambda b: per_y.get(b - b % 300))
r2 = dict(win=round(E.w.mean() * 100, 2), streaks_ge10=s10, max_streak=mx, periods={p: round(E[pr == p].w.mean() * 100, 2) for p in ('Y1', 'Y2', 'Y3')},
          lunch=round(E[E.h.isin([12, 13])].w.mean() * 100, 2))
print('2023-24', json.dumps(r2), flush=True)
json.dump(dict(validation=r, past=r2), open(f'../work/v0758_context_{CAP}.json', 'w'), indent=1)

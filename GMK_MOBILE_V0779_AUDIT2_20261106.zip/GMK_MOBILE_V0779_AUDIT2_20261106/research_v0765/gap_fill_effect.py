"""v0.7.65 check: how much the rebuilt 08:59 JST candle changes the model inputs. Dukascopy history (which has the real candle),
weekdays 2025-10 .. 2026-10, every scan B from 9:01 to 10:01 JST whose window contains 08:59: inputs from the real window vs the
window with 08:59 rebuilt the app's way (open = previous close, close = next open, high/low = max/min, volume 0)."""
import csv, gzip, math, sys, datetime as dt, json
import numpy as np
src = open(sys.argv[1]).read(); exec(src[src.index('def feats'):src.index('d = pd.DataFrame')])   # policy_data.feats, unchanged
JST = dt.timezone(dt.timedelta(hours=9)); out = {}
for s in sys.argv[2:]:
    sym, path = s.split('=')
    with gzip.open(path, 'rt') as f: rows = {int(r['epoch_ms']): (int(r['epoch_ms']), float(r['open']), float(r['high']), float(r['low']), float(r['close']), float(r.get('volume') or 0)) for r in csv.DictReader(f)}
    days = sorted({dt.datetime.fromtimestamp(t / 1000, JST).date() for t in rows}); D = {k: [] for k in ('r1', 'r5', 'r15', 'r60', 'rv60', 'pos15', 'pos60', 'bbz', 'f1')}; n = 0
    for day in days:
        if day.weekday() >= 5: continue
        t859 = int(dt.datetime(day.year, day.month, day.day, 8, 59, tzinfo=JST).timestamp()) * 1000
        if not all(t859 + k * 60000 in rows for k in (-1, 0, 1)): continue
        p, x, q = rows[t859 - 60000], rows[t859], rows[t859 + 60000]
        fill = (t859, p[4], max(p[4], q[1]), min(p[4], q[1]), q[1], 0.0)
        for m in range(1, 62):
            B = (t859 // 1000) + 60 + m * 60                       # 9:01 .. 10:01 JST
            w = [rows.get((B - 3720 + i * 60) * 1000) for i in range(61)]
            live = rows.get((B - 60) * 1000)
            if any(r is None for r in w) or live is None: continue
            wf = [fill if r[0] == t859 else r for r in w]
            a = feats(w, live[4], False); b = feats(wf, live[4], False); n += 1
            for k in D: D[k].append(b[k] - a[k])
    out[sym] = {'windows': n, **{k: {'mean_abs': round(float(np.mean(np.abs(v))), 4), 'p99_abs': round(float(np.quantile(np.abs(v), 0.99)), 4),
                                    'share_changed': round(float(np.mean(np.abs(np.array(v)) > 1e-9)), 3)} for k, v in D.items()}}
    print(sym, json.dumps(out[sym]), flush=True)
json.dump(out, open('gap_fill_effect.json', 'w'), indent=1)

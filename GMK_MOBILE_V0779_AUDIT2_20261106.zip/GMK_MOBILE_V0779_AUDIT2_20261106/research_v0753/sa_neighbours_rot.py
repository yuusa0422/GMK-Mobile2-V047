import pandas as pd, numpy as np, json
from rule_mine import load
F = load(); FX0 = F[F.inst != 'BTCJPY'].copy()
EV = pd.read_pickle('../work/event_signals_v0751.pkl'); evb = set(EV.b)
RULES = {'pos60L>=0.8': ('pos60L', 0.8), 'pos60L>=0.6': ('pos60L', 0.6), 'r15>=1': ('r15', 1.0), 'r15>=1.5': ('r15', 1.5), 'r5>=1': ('r5', 1.0), 'r5>=1.5': ('r5', 1.5),
         'f1>=1': ('f1', 1.0), 'f1>=1.5': ('f1', 1.5), 'bbzL>=2': ('bbzL', 2.0)}
TIMES = {'JST 9:55': ('jst_min', 595), 'JST 12:20': ('jst_min', 740), 'JST 22:50': ('jst_min', 1370), 'LON 7:25': ('lon_min', 445)}
def trades(FX):
    out = []
    for tname, (col, t0) in TIMES.items():
        for off in (-10, -5, 0, 5, 10):
            for rname, (feat, th) in RULES.items():
                S = FX[(FX[col] == t0 + off) & (FX[feat].abs() >= th)].copy()
                if not len(S): continue
                S['st'] = S[feat].abs(); S = S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b')
                S['win'] = (S.y * -np.sign(S[feat]) > 0).astype(float); S['cell'] = f'{tname}{off:+d} fade {rname}'
                out.append(S[['b', 'cell', 'win', 'period']])
    return pd.concat(out)
def rot(T, hi=0.58, min_n=50):
    res = []; allp = []
    for test in ('P1', 'P2', 'P3'):
        tr = T[T.period != test]
        g = tr.groupby('cell').win.agg(['size', 'mean']); pm = tr.groupby(['cell', 'period']).win.mean().unstack().min(axis=1)
        sel = g[(g['size'] >= min_n) & (g['mean'] >= hi) & (pm.reindex(g.index) >= hi - 0.03)]
        te = T[(T.period == test) & T.cell.isin(sel.index) & ~T.b.isin(evb)].join(sel['mean'].rename('tr'), on='cell')
        te = te.sort_values(['b', 'tr'], ascending=[True, False]).drop_duplicates('b')
        res.append((test, len(sel), len(te), round(te.win.mean(), 3) if len(te) else None)); allp.append(te)
    P = pd.concat(allp); return res, (round(P.win.mean(), 4) if len(P) else None), len(P)
T = trades(FX0)
for hi in (0.58, 0.60, 0.62):
    print('REAL hi', hi, rot(T, hi))
for seed in (1, 2, 3):
    rng = np.random.default_rng(seed); FXs = FX0.copy(); FXs['y'] = FXs.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values))
    Ts = trades(FXs); print('CHANCE seed', seed, [rot(Ts, hi)[1:] for hi in (0.58, 0.60, 0.62)])

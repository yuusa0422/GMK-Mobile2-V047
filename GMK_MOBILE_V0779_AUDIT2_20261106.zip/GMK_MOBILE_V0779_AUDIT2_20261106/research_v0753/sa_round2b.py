"""Round 2b: (4) relaxed thresholds of the adopted rules (marginal trades only), (5) BTC on weekdays at the adopted minutes,
(6) the confluence subset at every listed event minute that was not adopted, pooled as one family."""
import pandas as pd, numpy as np
from rule_mine import load
from ranks_v0753 import EVENTS, match_rows
from sa_round2 import FX, TH, OLD, NEW, F
pd.set_option('display.width', 250)
COL = {'JST': 'jst_min', 'LON': 'lon_min', 'NY': 'ny_min'}
def P(w, per):
    return [round(w[per == p].mean(), 3) for p in ('P1', 'P2', 'P3')]
# (4) relaxed thresholds: trades that appear only when the threshold is lowered to 75% of the original
base = match_rows(FX); base_b = set(base.b)
print('(4) relaxed thresholds, marginal slots only')
for eid, g, clock, mod, feat, th, usd, label in EVENTS:
    S = FX[(FX[COL[clock]] == mod) & (FX[feat].abs() >= th * 0.75) & (FX[feat].abs() < th) & ~FX.b.isin(base_b)].copy()
    S['st'] = S[feat].abs(); S = S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b')
    w = (S.y * -np.sign(S[feat]) > 0).astype(float).values
    print(f'  {eid:12s} n={len(S):4d} win={w.mean():.3f}', P(w, S.period.values))
# (5) BTC weekday at the adopted minutes (fade, and follow for the record)
B = F[F.inst == 'BTCJPY']
print('(5) BTC on weekdays at the adopted minutes')
for eid, g, clock, mod, feat, th, usd, label in EVENTS:
    S = B[(B[COL[clock]] == mod) & (B[feat].abs() >= th)]
    w = (S.y * -np.sign(S[feat]) > 0).astype(float).values
    print(f'  {eid:12s} n={len(S):4d} fade={w.mean():.3f}', P(w, S.period.values))
# (6) confluence subset (>=3 of the 4 other fades agree) at every listed event minute that was not adopted, pooled
adopted = {'Tokyo fix 9:55 JST', 'UK data 9:30 London', 'US data 8:30 NY', 'Tokyo lunch 12:20 JST', 'NY 22:50 JST', 'London 7:25'}
rows = []
for name, (col, t0) in {**OLD, **NEW}.items():
    if name in adopted: continue
    M = FX[FX[col] == t0]
    for feat, th in TH.items():
        S = M[M[feat].abs() >= th].copy()
        S['extra'] = sum(((S[f].abs() >= t) & (np.sign(S[f]) == np.sign(S[feat]))).astype(int) for f, t in TH.items() if f != feat)
        S = S[S.extra >= 3]; S['st'] = S[feat].abs(); S['w'] = (S.y * -np.sign(S[feat]) > 0).astype(float)
        rows.append(S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b').assign(event=name))
C = pd.concat(rows).drop_duplicates('b')
print('(6) pooled confluence at non-adopted event minutes: n', len(C), 'per day', round(len(C) / F.date.nunique(), 2), 'win', round(C.w.mean(), 3), P(C.w.values, C.period.values),
      'oct', round(C[C.october == 1].w.mean(), 3), int((C.october == 1).sum()))
print(C.groupby('event').w.agg(['size', 'mean']).round(3).sort_values('mean').to_string())

"""Pre-registered market-event minutes (official fixes, option cuts, scheduled data times) x fade rules."""
import pandas as pd, numpy as np, json
from rule_mine import load
F = load(); FX = F[F.inst != 'BTCJPY'].copy()
ts = pd.to_datetime(FX.ts)
for name, tz in (('cet', 'Europe/Berlin'), ('bjs', 'Asia/Shanghai')):
    t = ts.dt.tz_convert(tz); FX[name + '_min'] = t.dt.hour * 60 + t.dt.minute
EV = pd.read_pickle('../work/event_signals_v0751.pkl'); evb = set(EV.b)
EVENTS = {
    'Tokyo fix 9:55 JST': ('jst_min', 595), 'CNY fix 9:15 Beijing': ('bjs_min', 555), 'Tokyo cut 15:00 JST': ('jst_min', 900),
    'UK data 7:00 London': ('lon_min', 420), 'EZ data 10:00 CET': ('cet_min', 600), 'UK data 9:30 London': ('lon_min', 570),
    'ECB fix 14:15 CET': ('cet_min', 855), 'US data 8:30 NY': ('ny_min', 510), 'NY open 9:30 NY': ('ny_min', 570),
    'London open 8:00': ('lon_min', 480), 'Frankfurt open 8:00 CET': ('cet_min', 480), 'Tokyo lunch 12:20 JST': ('jst_min', 740),
    'NY 22:50 JST': ('jst_min', 1370), 'London 7:25': ('lon_min', 445),
}
RULES = [('f1', 1.0), ('r5', 1.0), ('r15', 1.0), ('pos60L', 0.8), ('bbzL', 1.5)]
rows = []
for ename, (col, t0) in EVENTS.items():
    for feat, th in RULES:
        S = FX[(FX[col] == t0) & (FX[feat].abs() >= th)].copy()
        if len(S) < 60: continue
        S['st'] = S[feat].abs(); S = S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b')
        w = (S.y * -np.sign(S[feat]) > 0).astype(float)
        ps = [w[S.period == p].mean() for p in ('P1', 'P2', 'P3')]
        rows.append(dict(event=ename, rule=f'fade {feat}>={th}', n=len(S), per_day=len(S) / F.date.nunique(), win=w.mean(), P1=ps[0], P2=ps[1], P3=ps[2], min3=min(ps),
                         oct=w[S.october == 1].mean(), oct_n=int((S.october == 1).sum()), new=int((~S.b.isin(evb)).sum()), new_win=w[~S.b.isin(evb).values].mean()))
R = pd.DataFrame(rows); pd.set_option('display.width', 260)
print('cells', len(R)); print(R.sort_values('min3', ascending=False).head(20).round(3).to_string())
R.to_pickle('../work/sa_events_prereg.pkl')

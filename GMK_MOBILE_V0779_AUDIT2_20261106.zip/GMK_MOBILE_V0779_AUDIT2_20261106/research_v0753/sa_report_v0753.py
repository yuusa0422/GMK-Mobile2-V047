"""CSV for the user: how S/A were increased in v0.7.53 and what was rejected."""
import pandas as pd, numpy as np, json, csv
from ranks_v0753 import TH
rows = []
def sec(t): rows.append([]); rows.append(['■ ' + t])
pc = lambda x: '' if x is None or (isinstance(x, float) and np.isnan(x)) else f'{x * 100:.1f}%'
L = json.load(open('../work/ladder_v0753.json'))
sec('v0.7.53 平日のランク（1年分・作ったのとは別の期間で採点。期間1=2025/10-2026/01 期間2=2026/02-05 期間3=2026/06-10）')
rows.append(['ランク', '回数', '勝率', '1日あたり', '期間1', '期間2', '期間3', '10月(2年分)', '10月の回数', '最大連敗'])
for g in 'SABCDE':
    r = L['weekday'][g]; rows.append([g, r['n'], pc(r['win']), f"{r['per_day']:.2f}", pc(r['P1']), pc(r['P2']), pc(r['P3']), pc(r['oct']), r['oct_n'], r['maxrun']])
for k, lab in (('weekday_SA', 'S+Aだけ'), ('weekday_SAB', 'S+A+Bだけ'), ('weekday_SABC', 'S〜C全部')):
    r = L[k]; rows.append([lab, '', f"{r['win']:.1f}%", r['per_day'], '', '', '', f"{r['oct']:.1f}%", '', r['maxrun']])
rows.append(['（v0.7.52）S', 124, '67.7%', '0.50', '67.5%', '62.8%', '73.2%', '61.5%', 13, 3])
rows.append(['（v0.7.52）A', 370, '61.4%', '1.50', '66.7%', '59.8%', '57.5%', '68.9%', 45, ''])
E = pd.read_pickle('../work/event_signals_v0753.pkl')
sec('時間帯ルールごと（S=ほかの逆張りサイン4つ中3つ以上が同じ向き / A=それ以外）')
rows.append(['ルール', '時刻(日本時間)', '回数', '勝率', 'うちS', 'Sの勝率', 'うちA', 'Aの勝率', '期間1', '期間2', '期間3', '10月'])
JT = {'FIX955_POS': '9:55', 'FIX955_BBZ': '9:55', 'JST1220_POS': '12:20', 'JST2250_R15': '22:50', 'LON0725_R5': '15:25(夏)/16:25(冬・10/26〜)',
      'US0830_BBZ': '21:30(夏)/22:30(冬・11/2〜)', 'US0830_F1': '21:30(夏)/22:30(冬・11/2〜)', 'UK0930_F1': '17:30(夏)/18:30(冬・10/26〜)'}
for eid, g in E.groupby('event', sort=False):
    s, a = g[g['rank'] == 'S'], g[g['rank'] == 'A']
    rows.append([eid, JT[eid], len(g), pc(g.win.mean()), len(s), pc(s.win.mean() if len(s) else np.nan), len(a), pc(a.win.mean()),
                 pc(g[g.period == 'P1'].win.mean()), pc(g[g.period == 'P2'].win.mean()), pc(g[g.period == 'P3'].win.mean()), pc(g[g.october == 1].win.mean())])
sec('Sの決め方の検証：ほかの逆張りサインが何個同じ向きか（時間帯ルールの取引だけ）')
rows.append(['同じ向きの数', '回数', '勝率', '期間1', '期間2', '期間3'])
for k, g in E.groupby('extra'):
    rows.append([k, len(g), pc(g.win.mean())] + [pc(g[g.period == p].win.mean()) for p in ('P1', 'P2', 'P3')])
rows.append(['入れ替え検証', '2つの期間で「何個以上をSにするか」を選び、残りの期間で採点 → 3回とも「3個以上」が選ばれた'])
for hold in ('P1', 'P2', 'P3'):
    H = E[E.period == hold]
    rows.append([f'採点した期間 {hold}', '', f"S {pc(H[H.extra >= 3].win.mean())}（{(H.extra >= 3).sum()}回）", f"A {pc(H[H.extra < 3].win.mean())}（{(H.extra < 3).sum()}回）"])
sec('1回目の候補（見る前に決めた14の時刻 × 5つの逆張り = 70個。合格 = 60回以上・3つの期間すべて55%以上・全体58%以上）')
R1 = pd.read_pickle('../work/sa_events_prereg.pkl')
rows.append(['時刻', 'ルール', '回数', '勝率', '期間1', '期間2', '期間3', '10月', '結果'])
for _, r in R1.sort_values('min3', ascending=False).iterrows():
    ok = r.n >= 60 and r.min3 >= 0.55 and r.win >= 0.58
    rows.append([r.event, r.rule, r.n, pc(r.win), pc(r.P1), pc(r.P2), pc(r.P3), pc(r.oct), '合格' if ok else ''])
rows.append(['勝敗をシャッフルしたデータで同じことをすると、偶然の合格は平均0.35個。実際は既存以外で4つ合格（米8:30×2・英9:30・9:55の2つ目）'])
sec('2回目の候補（さらに20の時刻 × 5 = 100個。同じ合格基準）')
R2 = pd.read_pickle('../work/sa_round2_events.pkl')
rows.append(['時刻', 'サイン', '回数', '勝率', '期間1', '期間2', '期間3', '10月', '結果'])
for _, r in R2.sort_values('min3', ascending=False).iterrows():
    rows.append([r.event, r.feat, r.n, pc(r.win), pc(r.P1), pc(r.P2), pc(r.P3), pc(r.oct), '合格' if r['pass'] else ''])
rows.append(['合格はロンドン12:00の2つ（同じ時刻・ほぼ同じ取引）。シャッフルでも平均0.75個合格し、2個以上は14%の確率で偶然起きる → 採用しない'])
sec('採用しなかったもの（別の期間で勝てなかった）')
for t in ('時間帯ルール以外の取引で「逆張りサインの重なり」を使う: B・Cとも期間ごとにバラバラ（50〜55%）',
          '20の追加時刻で「サインが3つ以上重なった」取引だけをまとめる: 53.1%（期間 56.3 / 51.0 / 52.4%）',
          'ルールのしきい値を下げて回数を増やす: 増えた分は 35〜72%（ほとんどが50%前後か以下）',
          '平日のBTCに同じ時刻のルール: 39〜56%',
          '9:55で残ったr15・f1: 47%・52%',
          '土日（BTC）の時間帯ルール: 3つの期間で安定するものなし'):
    rows.append([t])
with open('../pages/GMK_SとAを増やす研究.csv', 'w', newline='', encoding='utf-8-sig') as f:
    csv.writer(f).writerows(rows[1:])
print(len(rows))

import pandas as pd, numpy as np, json
D = pd.read_pickle('../work/enriched_v0752.pkl')
E = pd.read_pickle('../work/event_signals_v0753.pkl')[['b', 'inst', 'dir', 'win', 'rank']].rename(columns={'inst': 'r_inst', 'dir': 'r_dir', 'win': 'r_win', 'rank': 'r_rank'})
D = D.merge(E, on='b', how='left')
fx = D.inst != 'BTCJPY'
D['agree'] = (fx & (D.f1_rel <= -2.5)) | (~fx & D.f1_rel.between(1, 3, inclusive='left'))
we = {'S': 'B', 'A': 'C', 'B': 'C'}
D['g'] = np.where(D.weekday, np.where(D.grade.isin(['S', 'A']), np.where(D.agree, 'B', 'C'), np.where(D.grade.isin(['B', 'C']), 'C', D.grade)), D.grade.map(lambda g: we.get(g, g)))
ev = D.r_rank.notna(); D.loc[ev, 'g'] = D.loc[ev, 'r_rank']; D.loc[ev, 'win'] = D.loc[ev, 'r_win']
D['oct'] = D.date.astype(str).str[5:7] == '10'
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
out = {}
for wk, seg in ((True, 'weekday'), (False, 'weekend')):
    W = D[D.weekday == wk].sort_values('b'); days = W.date.nunique()
    t = W.groupby('g').agg(n=('win', 'size'), win=('win', 'mean')); t['per_day'] = t.n / days; t['share'] = t.n / len(W)
    for p in ('P1', 'P2', 'P3'): t[p] = W[W.period == p].groupby('g').win.mean()
    t['oct'] = W[W.oct].groupby('g').win.mean(); t['oct_n'] = W[W.oct].groupby('g').size(); t['maxrun'] = W.groupby('g').win.apply(lambda s: maxrun(s.values))
    print(seg); print(t.round(4).to_string()); out[seg] = t.round(4).to_dict('index')
    for keep in (['S', 'A'], ['S', 'A', 'B'], ['S', 'A', 'B', 'C']):
        e = W[W.g.isin(keep)]; daily = e.groupby('date').win.apply(lambda s: maxrun(s.values))
        r = dict(per_day=round(len(e) / days, 1), win=round(e.win.mean() * 100, 2), maxrun=maxrun(e.win.values), days8=round((daily >= 8).mean() * 100, 1), oct=round(e[e.oct].win.mean() * 100, 2))
        print(''.join(keep), r); out[seg + '_' + ''.join(keep)] = r
json.dump(out, open('../work/ladder_v0753.json', 'w'), indent=1, default=float, ensure_ascii=False)
D.to_pickle('../work/ladder_v0753.pkl')

"""Parity fixture for the v0.7.53 Kotlin EventRules: real rule-minute slots, raw windows + live prices -> expected rule trade,
its value, the confluence count and the grade (scripts/ranks_v0753.py)."""
import gzip, sys, random, numpy as np, pandas as pd
src = open('policy_data.py').read().split("d = pd.DataFrame(pickle.load(open('../work/frames_year.pkl'")[0]
exec(src)                                         # bars, index, window(), feats()
from app_sim import pattern_raw
from ranks_v0753 import EVENTS, match_rows
from rule_mine import load
R = lambda x: repr(float(x))
FXS = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
F = load(); FX = F[F.inst != 'BTCJPY'].copy()
E = match_rows(FX)
rng = random.Random(53)
picks = []
def add(bs, k):
    c = sorted(set(bs) - set(picks)); picks.extend(rng.sample(c, min(k, len(c))))
for eid in [e[0] for e in EVENTS]:
    add(E[E.event == eid].b, 5)
add(E[E['rank'] == 'S'].b, 8)                                                    # confluence S trades of several rules
add(E[(E.event == 'LON0725_R5') & (E.jst_min == 16 * 60 + 25)].b, 2)             # London 7:25 in winter time (16:25 JST)
add(E[(E.event == 'UK0930_F1') & (E.jst_min == 18 * 60 + 30)].b, 2)              # London 9:30 in winter time (18:30 JST)
add(E[E.event.str.startswith('US0830') & (E.jst_min == 22 * 60 + 30)].b, 3)      # New York 8:30 in winter time (22:30 JST)
add(E[E.event.str.startswith('US0830') & (E.jst_min == 21 * 60 + 30)].b, 2)      # New York 8:30 in summer time (21:30 JST)
ties = E[E.event == 'FIX955_POS']
add([b for b, g in FX[FX.b.isin(ties.b)].groupby('b') if (g.pos60L.abs() >= 0.8).sum() >= 2], 2)
for col, mod in (('jst_min', 595), ('jst_min', 740), ('jst_min', 1370), ('lon_min', 445), ('ny_min', 510), ('lon_min', 570)):
    add(set(FX[FX[col] == mod].b) - set(E.b), 2)                                  # rule minutes without a trade
add(set(FX[FX.jst_min == 600].b), 2)                                              # 10:00: no rule at all
lines = []
for B in sorted(set(picks)):
    g = FX[FX.b == B]
    lines.append(f'SLOT|{B}|0|{int(g.hour.iloc[0])}')
    for inst in FXS:
        win = window(inst, B)
        lb = index[inst].get((B - 60) * 1000)
        if win is None or lb is None: continue
        live = lb[4]
        for bar in win: lines.append('BAR|' + inst + '|' + '|'.join([str(int(bar[0]))] + [R(x) for x in bar[1:]]))
        f = feats(win, live, False); pr = pattern_raw(win, live, inst)
        lines.append(f'LIVE|{inst}|{R(live)}')
        lines.append(f'EXPV|{inst}|{R(pr["pos60L"])}|{R(f["r5"])}|{R(f["r15"])}|{R(f["bbzL"])}|{R(f["f1"])}')
    m = E[E.b == B]
    if len(m): r = m.iloc[0]; lines.append(f'EXPM|{r.event}|{r.inst}|{"HIGH" if r.dir > 0 else "LOW"}|{R(r.value)}|{int(r.extra)}|{r["rank"]}')
    else: lines.append('EXPM|NONE')
    lines.append('END')
with gzip.open(sys.argv[1], 'wt') as f: f.write('\n'.join(lines) + '\n')
ms = [l.split('|') for l in lines if l.startswith('EXPM|') and 'NONE' not in l]
print('slots', len(set(picks)), 'matched', len(ms), 'S', sum(m[6] == 'S' for m in ms), 'events', sorted({m[1] for m in ms}), 'lines', len(lines))

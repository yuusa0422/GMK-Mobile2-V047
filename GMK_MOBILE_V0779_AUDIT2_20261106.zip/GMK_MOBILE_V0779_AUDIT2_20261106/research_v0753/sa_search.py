"""More S/A candidates. Every family: cells selected on two periods (each >= hi-0.02, pooled >= hi, n >= min_n), scored on the third;
per slot the selected cell with the best training rate trades. Chance: outcomes shuffled within (instrument, date)."""
import pandas as pd, numpy as np, json, itertools
from rule_mine import load
F = load()                                   # weekday live rows + session cols, y, period, octyr
F['idio_f1'] = np.where(F.inst != 'BTCJPY', F.f1 - F.yenf1, np.nan)
F['idio_r5'] = np.where(F.inst != 'BTCJPY', F.r5 - F.yen5, np.nan)
F['rsi_c'] = F.rsi - 50
F['rv_q'] = F.groupby('inst').rv60.transform(lambda s: pd.qcut(s.rank(method='first'), 5, labels=False))
F['ses3'] = np.where(F.session.str.startswith('T'), 'TOKYO', np.where(F.session.str.startswith('E'), 'EUROPE', 'US'))
EV = pd.read_pickle('../work/event_signals_v0751.pkl')
SIG = ['f1', 'r5', 'r15', 'pos60L', 'bbzL', 'dmean60', 'rsi_c', 'idio_f1', 'idio_r5', 'pos15L']
TH = {'f1': [1.5, 2.0, 2.5, 3.0, 3.5], 'r5': [1.5, 2.0, 2.5, 3.0], 'r15': [1.5, 2.0, 2.5, 3.0], 'pos60L': [0.8, 0.95], 'bbzL': [2.0, 2.5, 3.0],
      'dmean60': [2.0, 3.0, 4.0], 'rsi_c': [25, 35], 'idio_f1': [1.5, 2.0, 2.5], 'idio_r5': [1.5, 2.0, 2.5], 'pos15L': [0.95]}
def cells(F):
    out = []
    grp_inst = F.inst.values; grp_fx = np.where(F.inst == 'BTCJPY', 'BTC', 'FX')
    ses = F.ses3.values; rvq = F.rv_q.values
    for s in SIG:
        v = F[s].values
        for t in TH[s]:
            m = np.abs(v) >= t
            for mode, sg in (('fade', -1), ('follow', 1)):
                d = np.sign(v) * sg
                for gname, g in (('fx', grp_fx), ('inst', grp_inst)):
                    for fname, fv in (('all', np.array(['*'] * len(F))), ('ses', ses), ('rv', rvq.astype(str))):
                        ok = m & ~np.isnan(v)
                        key = np.char.add(np.char.add(np.char.add(f'{s}>={t}|{mode}|', g.astype(str)), '|' + fname + '='), fv.astype(str))
                        out.append(pd.DataFrame({'row': np.where(ok)[0], 'cell': key[ok], 'dir': d[ok]}))
    L = pd.concat(out, ignore_index=True)
    L['win'] = (F.y.values[L.row] * L.dir.values > 0).astype(np.float32); L['b'] = F.b.values[L.row]
    return L
def select(L, tr, part, min_n, hi):
    T = L[L.row.isin(tr)]
    g = T.groupby('cell').win.agg(['size', 'mean']); g = g[(g['size'] >= min_n) & (g['mean'] >= hi)]
    if not len(g): return g.rename(columns={'size': 'n_train', 'mean': 'rate_train'})
    P = T[T.cell.isin(g.index)].assign(p=part[T[T.cell.isin(g.index)].row.values]).groupby(['cell', 'p']).win.mean().unstack().min(axis=1)
    g = g[P.reindex(g.index) >= hi - 0.02]
    return g.rename(columns={'size': 'n_train', 'mean': 'rate_train'})
def evaluate(F, L, min_n, hi, exclude_b=()):
    part = F.period.values; res = []; picked = []
    for test in ('P1', 'P2', 'P3'):
        tr = np.where(F.period != test)[0]; te = np.where(F.period == test)[0]
        sel = select(L, tr, part, min_n, hi)
        T = L[L.row.isin(te) & L.cell.isin(sel.index) & ~L.b.isin(exclude_b)].join(sel, on='cell')
        T = T.sort_values(['b', 'rate_train', 'n_train'], ascending=[True, False, False]).drop_duplicates('b')
        res.append((test, len(sel), len(T), float(T.win.mean()) if len(T) else None, len(T) / F.date[F.period == test].nunique()))
        picked.append(T.assign(test=test))
    P = pd.concat(picked) if picked else pd.DataFrame()
    return res, P
if __name__ == '__main__':
    L = cells(F); print('cells', L.cell.nunique(), 'rows', len(L))
    rng = np.random.default_rng(21); Fs = F.copy(); Fs['y'] = Fs.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values)); Ls = cells(Fs)
    out = {}
    for min_n, hi in ((300, 0.56), (300, 0.58), (200, 0.60), (150, 0.62)):
        r, P = evaluate(F, L, min_n, hi, exclude_b=set(EV.b)); rc, _ = evaluate(Fs, Ls, min_n, hi, exclude_b=set(EV.b))
        pooled = P.win.mean() if len(P) else None
        print(f'n>={min_n} hi>={hi}: REAL', [(t, c, n, round(w, 3) if w else None, round(d, 2)) for t, c, n, w, d in r], 'pooled', round(pooled, 4) if pooled else None,
              '| CHANCE', [(t, c, n, round(w, 3) if w else None) for t, c, n, w, d in rc])
        out[f'{min_n}_{hi}'] = dict(real=r, chance=rc, pooled=pooled)
        if len(P): P.to_pickle(f'../work/sa_picked_{min_n}_{hi}.pkl')
    json.dump(out, open('../work/sa_search.json', 'w'), default=float)

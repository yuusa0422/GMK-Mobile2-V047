"""v0.7.53 rule set: v0.7.51 rules + Tokyo-fix Bollinger extension + US data 8:30 NY and UK data 9:30 London.
Grade: S when >=3 of the 4 other fade signals point the same way as the rule value (confluence), else A."""
import pandas as pd, numpy as np, json
from rule_mine import load
EVENTS = [  # id, grade, clock, minute, feature, threshold, usd_first, label
    ('FIX955_POS', 'S', 'JST', 595, 'pos60L', 0.8, True, '仲値(9:55)・60分の高値/安値の端からの戻り'),
    ('FIX955_BBZ', 'A', 'JST', 595, 'bbzL', 1.5, True, '仲値(9:55)・20分平均から1.5σ以上離れた動きの戻り'),
    ('JST1220_POS', 'A', 'JST', 740, 'pos60L', 0.8, False, '昼(12:20)・60分の高値/安値の端からの戻り'),
    ('JST2250_R15', 'A', 'JST', 1370, 'r15', 1.0, False, 'NY午前(22:50)・15分の大きな動きの戻り'),
    ('LON0725_R5', 'A', 'LON', 445, 'r5', 1.0, False, '欧州勢の参入前(ロンドン7:25)・5分の大きな動きの戻り'),
    ('US0830_BBZ', 'A', 'NY', 510, 'bbzL', 1.5, False, '米指標の発表時刻(NY8:30)・20分平均から1.5σ以上離れた動きの戻り'),
    ('US0830_F1', 'A', 'NY', 510, 'f1', 1.0, False, '米指標の発表時刻(NY8:30)・直前1分の動きの戻り'),
    ('UK0930_F1', 'A', 'LON', 570, 'f1', 1.0, False, '英指標の発表時刻(ロンドン9:30)・直前1分の動きの戻り'),
]
TH = {'pos60L': 0.8, 'bbzL': 1.5, 'r5': 1.0, 'r15': 1.0, 'f1': 1.0}
ORDER = {'USDJPY': 0, 'EURJPY': 1, 'GBPJPY': 2, 'AUDJPY': 3, 'NZDJPY': 4}
COL = {'JST': 'jst_min', 'LON': 'lon_min', 'NY': 'ny_min'}
def match_rows(FX):
    out = []
    for i, (eid, g, clock, mod, feat, th, usd, label) in enumerate(EVENTS):
        S = FX[(FX[COL[clock]] == mod) & (FX[feat].abs() >= th)].copy(); S['st'] = S[feat].abs().round(12)
        S['k'] = np.where(usd & (S.inst == 'USDJPY'), 0, 1); S['ord'] = S.inst.map(ORDER)
        S = S.sort_values(['b', 'k', 'st', 'ord'], ascending=[True, True, False, True], kind='mergesort').drop_duplicates('b')
        S['dir'] = -np.sign(S[feat]); S['event'] = eid; S['rank'] = g; S['prio'] = i; S['feat'] = feat; S['value'] = S[feat]
        out.append(S)
    E = pd.concat(out).sort_values(['b', 'prio']).drop_duplicates('b').copy()
    E['extra'] = [sum(1 for f, t in TH.items() if f != r.feat and abs(r[f]) >= t and np.sign(r[f]) == np.sign(r.value)) for _, r in E.iterrows()]
    E['rank'] = np.where(E.extra >= 3, 'S', 'A')
    return E
if __name__ == '__main__':
    F = load(); FX = F[F.inst != 'BTCJPY'].copy()
    E = match_rows(FX); E['win'] = (E.y * E.dir > 0).astype(float)
    days = F.date.nunique(); res = {'events': {}, 'grades': {}}
    for eid, g in E.groupby('event', sort=False):
        res['events'][eid] = dict(n=len(g), win=g.win.mean(), per_day=len(g) / days, oct=g[g.october == 1].win.mean(), oct_n=int((g.october == 1).sum()),
                                  P1=g[g.period == 'P1'].win.mean(), P2=g[g.period == 'P2'].win.mean(), P3=g[g.period == 'P3'].win.mean())
    for r in ('S', 'A'):
        g = E[E['rank'] == r]
        res['grades'][r] = dict(n=len(g), win=g.win.mean(), per_day=len(g) / days, oct=g[g.october == 1].win.mean(), oct_n=int((g.october == 1).sum()),
                                P1=g[g.period == 'P1'].win.mean(), P2=g[g.period == 'P2'].win.mean(), P3=g[g.period == 'P3'].win.mean())
    print(json.dumps(res, indent=1, default=lambda x: round(float(x), 4), ensure_ascii=False))
    E.to_pickle('../work/event_signals_v0753.pkl'); json.dump(res, open('../work/ranks_v0753.json', 'w'), indent=1, default=float, ensure_ascii=False)

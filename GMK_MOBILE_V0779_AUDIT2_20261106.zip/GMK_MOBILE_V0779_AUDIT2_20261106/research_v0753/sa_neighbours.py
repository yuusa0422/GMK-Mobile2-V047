import pandas as pd, numpy as np
from rule_mine import load
F = load(); FX = F[F.inst != 'BTCJPY'].copy()
EV = pd.read_pickle('../work/event_signals_v0751.pkl'); evb = set(EV.b)
RULES = {'pos60L>=0.8': ('pos60L', 0.8), 'pos60L>=0.6': ('pos60L', 0.6), 'r15>=1': ('r15', 1.0), 'r15>=1.5': ('r15', 1.5), 'r5>=1': ('r5', 1.0), 'r5>=1.5': ('r5', 1.5),
         'f1>=1': ('f1', 1.0), 'f1>=1.5': ('f1', 1.5), 'bbzL>=2': ('bbzL', 2.0)}
TIMES = {'JST 9:55': ('jst_min', 595), 'JST 12:20': ('jst_min', 740), 'JST 22:50': ('jst_min', 1370), 'LON 7:25': ('lon_min', 445)}
rows = []
for tname, (col, t0) in TIMES.items():
    for off in (-10, -5, 0, 5, 10):
        for rname, (feat, th) in RULES.items():
            S = FX[(FX[col] == t0 + off) & (FX[feat].abs() >= th)].copy()
            if not len(S): continue
            S['st'] = S[feat].abs(); S = S.sort_values(['b', 'st'], ascending=[True, False]).drop_duplicates('b')
            S['win'] = (S.y * -np.sign(S[feat]) > 0).astype(float)
            r = dict(time=tname, off=off, rule='fade ' + rname, n=len(S), win=S.win.mean(), new_slots=int((~S.b.isin(evb)).sum()))
            for p in ('P1', 'P2', 'P3'): r[p] = S[S.period == p].win.mean(); r['n' + p] = int((S.period == p).sum())
            r['oct'] = S[S.october == 1].win.mean(); r['min3'] = min(r['P1'], r['P2'], r['P3'])
            rows.append(r)
R = pd.DataFrame(rows); pd.set_option('display.width', 250)
print('cells', len(R)); print(R[R.min3 >= 0.56].sort_values('min3', ascending=False).round(3).to_string())
R.to_pickle('../work/sa_neighbours.pkl')
# weekend BTC
from session_feats import add_session
P = pd.read_pickle('../work/pattern_frame.pkl'); W = add_session(P[(~P.weekday) & (P.live_ok == 1)]); W['y'] = np.sign(W.move3.fillna(0))
d = W.date.astype(str); W['period'] = np.where(d < '2026-02-01', 'P1', np.where(d < '2026-06-01', 'P2', 'P3'))
wr = []
for tie_max in (0.0, 0.05, 0.1, 1.0):
    for z_max in (0.0, 0.1, 1.0):
        for feat, lo, hi, mode in (('f1', 1, 3, 1), ('f1', 0.5, 3, 1), ('f1', 2, 99, -1), ('r5', 1.5, 99, 1), ('r5', 1.5, 99, -1), ('r15', 1.5, 99, 1), ('r15', 1.5, 99, -1), ('pos60L', 0.95, 2, 1), ('pos60L', 0.95, 2, -1)):
            m = (W.tie58 <= tie_max) & (W.zero30 <= z_max) & W[feat].abs().between(lo, hi, inclusive='left')
            S = W[m]; 
            if len(S) < 200: continue
            w = (S.y * np.sign(S[feat]) * mode > 0).astype(float)
            r = dict(tie_max=tie_max, zero_max=z_max, rule=f"{'follow' if mode > 0 else 'fade'} {feat} {lo}-{hi}", n=len(S), per_day=len(S) / W.date.nunique(), win=w.mean())
            for p in ('P1', 'P2', 'P3'): r[p] = w[S.period == p].mean()
            r['min3'] = min(r['P1'], r['P2'], r['P3']); r['oct'] = w[S.october == 1].mean()
            wr.append(r)
WR = pd.DataFrame(wr); print('weekend cells', len(WR)); print(WR.sort_values('min3', ascending=False).head(12).round(3).to_string())

"""Round 2 of the S/A search (v0.7.53), every candidate written down before looking at its result.

Part 1: more liquidity / data-release minutes x the same 5 fade rules. Pass = n>=60, pooled >=58%, every period >=55%.
         The same selection on outcomes shuffled within (instrument, date) gives the number of passes expected by chance.
Part 2: the confluence S test (rule trade + >=3 of the 4 other fade signals agree) on every passing event.
Part 3: non-event model trades: does fade confluence lift the model trade (rotation over periods)?
"""
import pandas as pd, numpy as np, json, sys
from rule_mine import load
TH = {'pos60L': 0.8, 'bbzL': 1.5, 'r5': 1.0, 'r15': 1.0, 'f1': 1.0}
F = load(); FX = F[F.inst != 'BTCJPY'].copy()
ts = pd.to_datetime(FX.ts)
for name, tz in (('cet', 'Europe/Berlin'), ('bjs', 'Asia/Shanghai'), ('syd', 'Australia/Sydney')):
    t = ts.dt.tz_convert(tz); FX[name + '_min'] = t.dt.hour * 60 + t.dt.minute
DAYS = F.date.nunique()
OLD = {  # round 1 list (already tested)
    'Tokyo fix 9:55 JST': ('jst_min', 595), 'CNY fix 9:15 Beijing': ('bjs_min', 555), 'Tokyo cut 15:00 JST': ('jst_min', 900),
    'UK data 7:00 London': ('lon_min', 420), 'EZ data 10:00 CET': ('cet_min', 600), 'UK data 9:30 London': ('lon_min', 570),
    'ECB fix 14:15 CET': ('cet_min', 855), 'US data 8:30 NY': ('ny_min', 510), 'NY open 9:30 NY': ('ny_min', 570),
    'London open 8:00': ('lon_min', 480), 'Frankfurt open 8:00 CET': ('cet_min', 480), 'Tokyo lunch 12:20 JST': ('jst_min', 740),
    'NY 22:50 JST': ('jst_min', 1370), 'London 7:25': ('lon_min', 445),
}
NEW = {  # round 2 list
    'Tokyo open 9:00 JST': ('jst_min', 540), 'Tokyo 9:30 JST': ('jst_min', 570), 'Tokyo 10:00 JST': ('jst_min', 600),
    'Tokyo 10:30 JST': ('jst_min', 630), 'AU data 11:30 Sydney': ('syd_min', 690), 'CN data 10:00 Beijing': ('bjs_min', 600),
    'TSE AM close 11:30 JST': ('jst_min', 690), 'TSE PM open 12:30 JST': ('jst_min', 750), 'TSE close 15:30 JST': ('jst_min', 930),
    'JST 14:00': ('jst_min', 840), 'Xetra open 9:00 CET': ('cet_min', 540), 'EZ data 11:00 CET': ('cet_min', 660),
    'London 12:00': ('lon_min', 720), 'London 13:00': ('lon_min', 780), 'NY 8:00': ('ny_min', 480), 'US PMI 9:45 NY': ('ny_min', 585),
    'US data 8:15 NY': ('ny_min', 495), 'US 9:00 NY': ('ny_min', 540), 'Tokyo 16:00 JST': ('jst_min', 960), 'Tokyo 17:00 JST': ('jst_min', 1020),
}


def cell_stats(S, feat, y):
    w = (y * -np.sign(S[feat].values) > 0).astype(float)
    ps = [w[(S.period == p).values].mean() for p in ('P1', 'P2', 'P3')]
    return w, ps


def scan(events, y_col='y'):
    rows, picks = [], {}
    for ename, (col, t0) in events.items():
        for feat, th in TH.items():
            S = FX[(FX[col] == t0) & (FX[feat].abs() >= th)].copy()
            if len(S) < 60: continue
            S['st'] = S[feat].abs().round(12); S = S.sort_values(['b', 'st'], ascending=[True, False], kind='mergesort').drop_duplicates('b')
            if len(S) < 60: continue
            w, ps = cell_stats(S, feat, S[y_col].values)
            rows.append(dict(event=ename, feat=feat, n=len(S), per_day=len(S) / DAYS, win=w.mean(), P1=ps[0], P2=ps[1], P3=ps[2], min3=min(ps),
                             oct=w[(S.october == 1).values].mean(), oct_n=int((S.october == 1).sum())))
            picks[(ename, feat)] = S
    R = pd.DataFrame(rows)
    R['pass'] = (R.n >= 60) & (R.win >= 0.58) & (R.min3 >= 0.55)
    return R, picks


if __name__ == '__main__':
    pd.set_option('display.width', 260)
    R, picks = scan(NEW)
    print('part 1 cells', len(R), 'pass', int(R['pass'].sum()))
    print(R.sort_values('min3', ascending=False).head(15).round(3).to_string())
    # chance baseline: shuffle outcomes within (instrument, date)
    rng = np.random.default_rng(53); passes = []
    for k in range(int(sys.argv[1]) if len(sys.argv) > 1 else 100):
        FX['ys'] = FX.groupby(['inst', 'date']).y.transform(lambda s: rng.permutation(s.values))
        Rs, _ = scan(NEW, 'ys'); passes.append(int(Rs['pass'].sum()))
    print('shuffled passes mean', np.mean(passes), 'p(>=observed)', np.mean(np.array(passes) >= R['pass'].sum()), 'dist', np.bincount(passes))
    R.to_pickle('../work/sa_round2_events.pkl')
    # part 2: confluence on passing cells (and on all cells, for the record)
    out = []
    for (ename, feat), S in picks.items():
        extra = sum(((S[f].abs() >= t) & (np.sign(S[f]) == np.sign(S[feat]))).astype(int) for f, t in TH.items() if f != feat)
        w = (S.y * -np.sign(S[feat]) > 0).astype(float)
        hi = extra >= 3
        out.append(dict(event=ename, feat=feat, n_hi=int(hi.sum()), win_hi=w[hi].mean(), n_lo=int((~hi).sum()), win_lo=w[~hi].mean()))
    C = pd.DataFrame(out); print('part 2 confluence on all round-2 cells'); print(C.round(3).to_string())
    print('pooled hi', round((C.n_hi * C.win_hi.fillna(0)).sum() / C.n_hi.sum(), 4), int(C.n_hi.sum()), 'lo', round((C.n_lo * C.win_lo).sum() / C.n_lo.sum(), 4))
    C.to_pickle('../work/sa_round2_confluence.pkl')

"""Parity fixture for v0.7.61: the hour quota on the hour's available slots (research: N = ceil(0.7 x slots with data in that hour)).
Lines: 'slots|fresh|hour|minute|entries|slots|expected cut'."""
import pickle, math, gzip, sys, numpy as np
M = pickle.load(open('../work/production_model5_v0758.pkl', 'rb')); out = sys.argv[1]; QN = 200
def qcut(Q, frac):
    frac = min(max(frac, 0.0), 1.0); return float(np.interp(1 - frac, np.linspace(0, 1, QN + 1), Q))
def cut(k, h, minute, entries, slots):
    N = math.ceil(0.7 * slots - 1e-9); need = N - entries; left = 60 - minute
    if need >= left: return -math.inf
    if need <= 0: return math.inf
    return qcut(np.array(M[k]['Q'][h]), max(need / left, M[k]['base'][h] / 2))
L = []
for k in ('fresh', 'fallback'):
    for h in (9, 12, 16, 22):
        for slots in (12, 11, 8, 4, 1, 0):
            for minute in (0, 20, 41, 50, 57):
                for e in (0, 1, 2, 3, 6):
                    L.append(f'slots|{k}|{h}|{minute}|{e}|{slots}|{cut(k, h, minute, e, slots)!r}')
with gzip.open(out, 'wt') as f: f.write('\n'.join(L) + '\n')
print('lines', len(L))

"""Is there a validated 1-minute trade? Fade / follow the last minute (live proxy = close of the bar opening at T-60) on FX and BTC,
result OPEN(T+1) vs OPEN(T), per period. One trade per minute (largest |f1| instrument). Also the 3-minute horizon for comparison."""
import numpy as np, pandas as pd
from onemin_sim_v0754 import load, ORDER, T0, N
entry = pd.to_datetime((np.arange(N) + T0) * 60, unit='s', utc=True).tz_convert('Asia/Tokyo')   # index i = entry minute T
hour = entry.hour.values; wd = entry.dayofweek.values < 5; d = entry.strftime('%Y-%m-%d').values
period = np.where(d < '2026-02-01', 'P1', np.where(d < '2026-06-01', 'P2', 'P3'))
F = {}; M1 = {}; M3 = {}
for s in ORDER:
    g = load(s); o, c = g[:, 0], g[:, 3]
    lc = np.log(c); r = np.diff(lc, prepend=np.nan)
    sd = pd.Series(r).rolling(60, min_periods=55).std(ddof=0).values
    # at entry T (index i): live = close of bar i-1 (opening T-60), last completed = bar i-2
    live = np.r_[np.nan, c[:-1]]; prev = np.r_[np.nan, np.nan, c[:-2]]; sdp = np.r_[np.nan, np.nan, sd[:-2]]
    F[s] = (np.log(live) - np.log(prev)) / sdp
    oT = o; oT1 = np.r_[o[1:], np.nan]; oT3 = np.r_[o[3:], np.nan, np.nan, np.nan]
    M1[s] = np.sign(oT1 - oT); M3[s] = np.sign(oT3 - oT)
act = (hour >= 9) & (hour <= 22)
out = []
for seg, mask, insts in (('weekday FX', act & wd, ORDER[:5]), ('weekday BTC', act & wd, ['BTCJPY']), ('weekend BTC', act & ~wd, ['BTCJPY'])):
    f = np.vstack([F[s] for s in insts]); m1 = np.vstack([M1[s] for s in insts]); m3 = np.vstack([M3[s] for s in insts])
    af = np.where(np.isnan(f), -1, np.abs(f)); best = af.argmax(axis=0); cols = np.arange(N)
    fb = f[best, cols]; m1b = m1[best, cols]; m3b = m3[best, cols]
    for th in (1.0, 2.0, 2.5, 3.0):
        sel = mask & (np.abs(fb) >= th) & ~np.isnan(m1b) & ~np.isnan(m3b)
        for name, dirv in (('fade', -np.sign(fb)), ('follow', np.sign(fb))):
            w1 = (m1b == dirv)[sel]; w3 = (m3b == dirv)[sel]; per = period[sel]
            out.append(dict(seg=seg, th=th, rule=name, n=int(sel.sum()), per_day=sel.sum() / len(set(d[sel])), win1=w1.mean(), draw1=(m1b == 0)[sel].mean(),
                            **{f'1m_{p}': w1[per == p].mean() for p in ('P1', 'P2', 'P3')}, win3=w3.mean(), **{f'3m_{p}': w3[per == p].mean() for p in ('P1', 'P2', 'P3')}))
R = pd.DataFrame(out); pd.set_option('display.width', 250); print(R.round(3).to_string()); R.to_pickle('../work/onemin_fade_v0754.pkl')

import numpy as np, pandas as pd
R = pd.read_pickle('../work/onemin_raw_v0754.pkl')
ORDER = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']
T0 = pd.Timestamp('2025-10-01', tz='Asia/Tokyo').value // 60_000_000_000
N = len(R['USDJPY'])
entry = pd.to_datetime((np.arange(N) + 2 + T0) * 60, unit='s', utc=True).tz_convert('Asia/Tokyo')
hour = entry.hour.values; wd = entry.dayofweek.values < 5
active = (hour >= 9) & (hour <= 22)
rows = []
for k in np.where(active)[0]:
    insts = ORDER if wd[k] else ['BTCJPY']
    if not all(R[s].ok.values[k] for s in insts): continue
    cand = [(bool(R[s].sct.values[k]), -R[s].conf.values[k], -abs(R[s].score.values[k]), s) for s in insts]
    cand.sort(); sct, nconf, nsc, s = cand[0]
    if sct: continue                                     # app refuses to publish a guarded TOP1
    sc = R[s].score.values[k]; conf = -nconf; mv = R[s].move.values[k]
    rows.append((k, s, 1 if sc >= 0 else -1, conf, mv, wd[k], hour[k]))
D = pd.DataFrame(rows, columns=['k', 'inst', 'dir', 'conf', 'move', 'weekday', 'hour'])
D['ts'] = entry[D.k.values]; d = D.ts.dt.strftime('%Y-%m-%d')
D['period'] = np.where(d < '2026-02-01', 'P1', np.where(d < '2026-06-01', 'P2', 'P3'))
D['grade'] = pd.cut(D.conf, [0, 0.53, 0.58, 0.65, 0.75, 1.0], right=False, labels=['E', 'C', 'B', 'A', 'S'])
D['win'] = (D.move == D.dir).astype(int); D['draw'] = (D.move == 0).astype(int); D['rev'] = (D.move == -D.dir).astype(int)
D.to_pickle('../work/onemin_trades_v0754.pkl')
pd.set_option('display.width', 220)
for wk, seg in ((True, '平日'), (False, '土日')):
    X = D[D.weekday == wk]; E = X[X.grade != 'E']
    print(f'\n==== 1分ボード {seg}: ENTRY {len(E)} ({len(E)/X.ts.dt.date.nunique():.0f}/日) 勝率 {E.win.mean():.4f} 引分 {E.draw.mean():.4f} 反対向き {E.rev.mean():.4f}')
    t = E.groupby('grade', observed=True).agg(n=('win', 'size'), win=('win', 'mean'), draw=('draw', 'mean'), rev=('rev', 'mean'))
    for p in ('P1', 'P2', 'P3'): t[p] = E[E.period == p].groupby('grade', observed=True).win.mean()
    print(t.round(4).to_string())
    t = E.groupby('inst').agg(n=('win', 'size'), win=('win', 'mean'), draw=('draw', 'mean'), rev=('rev', 'mean')); print(t.round(4).to_string())
    print('by period: win', [round(E[E.period == p].win.mean(), 4) for p in ('P1', 'P2', 'P3')], 'rev', [round(E[E.period == p].rev.mean(), 4) for p in ('P1', 'P2', 'P3')])

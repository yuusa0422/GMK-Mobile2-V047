"""v0.7.54 1-minute rule candidate, computed exactly as the Kotlin EvidenceFeatures f1: 61 contiguous completed bars ending at the
bar opening at T-120 s, norm = RMS of the 60 one-minute log returns, live = close of the bar opening at T-60 (proxy for the quote
at T-10 s). One trade per minute: the FX instrument with the largest |f1|; fade it. Result OPEN(T+1) vs OPEN(T)."""
import numpy as np, pandas as pd, json
from onemin_sim_v0754 import load, ORDER, T0, N
entry = pd.to_datetime((np.arange(N) + T0) * 60, unit='s', utc=True).tz_convert('Asia/Tokyo')
hour = entry.hour.values; minute = entry.minute.values; wd = entry.dayofweek.values < 5; d = entry.strftime('%Y-%m-%d').values
period = np.where(d < '2026-02-01', 'P1', np.where(d < '2026-06-01', 'P2', 'P3')); octo = entry.month.values == 10
FXS = ORDER[:5]; f = []; m1 = []
for s in FXS:
    g = load(s); o, c = g[:, 0], g[:, 3]; lc = np.log(c); r = np.diff(lc, prepend=np.nan)
    rr = pd.Series(r * r).rolling(60, min_periods=60).mean().values          # bars j-59..j returns -> RMS over 60 returns (needs 61 bars)
    full = pd.Series(np.isnan(c).astype(float)).rolling(61, min_periods=61).sum().values == 0
    norm = np.maximum(np.sqrt(rr), 1e-8)
    j = np.arange(N) - 2                                                       # last completed bar index for entry i
    ok = (j >= 0); jj = np.clip(j, 0, N - 1)
    live = np.r_[np.nan, c[:-1]]
    fi = np.where(ok & full[jj], (np.log(live) - lc[jj]) / norm[jj], np.nan)
    f.append(fi); m1.append(np.sign(np.r_[o[1:], np.nan] - o))
f = np.vstack(f); m1 = np.vstack(m1)
af = np.where(np.isnan(f), -1, np.abs(f)); best = af.argmax(axis=0); cols = np.arange(N)
fb = f[best, cols]; mb = m1[best, cols]; inst = np.array(FXS)[best]
base = (hour >= 9) & (hour <= 22) & wd & ~np.isnan(fb) & ~np.isnan(mb)
T = pd.DataFrame({'f1': fb, 'move': mb, 'inst': inst, 'hour': hour, 'minute': minute, 'period': period, 'oct': octo, 'date': d})[base]
T['win'] = (T.move == -np.sign(T.f1)).astype(int); T['draw'] = (T.move == 0).astype(int); T['a'] = T.f1.abs()
days = T.date.nunique(); out = {}
for th in (2.0, 2.5, 3.0, 3.5, 4.0):
    S = T[T.a >= th]
    out[th] = dict(n=len(S), per_day=round(len(S) / days, 1), win=round(S.win.mean(), 4), draw=round(S.draw.mean(), 4),
                   **{p: round(S[S.period == p].win.mean(), 4) for p in ('P1', 'P2', 'P3')}, oct=round(S[S.oct].win.mean(), 4), oct_n=int(S.oct.sum()))
    print(th, out[th])
# rotation: threshold chosen on two periods (max win with >= 10/day), scored on the third
rot = []
for hold in ('P1', 'P2', 'P3'):
    tr = T[T.period != hold]; dtr = tr.date.nunique()
    best_th = max([th for th in (2.0, 2.5, 3.0, 3.5, 4.0) if (tr.a >= th).sum() / dtr >= 10], key=lambda th: tr[tr.a >= th].win.mean())
    H = T[(T.period == hold) & (T.a >= best_th)]; rot.append((hold, best_th, round(H.win.mean(), 4), len(H))); print('rotation', hold, best_th, round(H.win.mean(), 4), len(H))
S = T[T.a >= 3.0]
print(S.groupby('inst').win.agg(['size', 'mean']).round(4).T.to_string()); print(S.groupby('hour').win.agg(['size', 'mean']).round(3).T.to_string())
json.dump({'thresholds': out, 'rotation': rot}, open('../work/onemin_rule_v0754.json', 'w'), indent=1, default=float)
T.to_pickle('../work/onemin_rule_v0754.pkl')

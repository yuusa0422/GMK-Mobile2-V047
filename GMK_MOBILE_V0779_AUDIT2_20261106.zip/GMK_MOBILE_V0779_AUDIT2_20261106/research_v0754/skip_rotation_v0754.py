"""Rotation for the skip idea: contexts (hour, weekday, instrument, quantile bins of 12 relative features) are selected as
'losing' on two periods (C trades, n>=300, win <= overall-2pt in both) and scored on the third. Shuffle baseline: outcomes
permuted within (instrument, date)."""
import pandas as pd, numpy as np, json, sys
D = pd.read_pickle('../work/ladder_v0753.pkl').sort_values('b')
D = D[(D.g == 'C') & D.r_rank.isna()].copy()
FEATS = ['f1_rel', 'r1_rel', 'r5_rel', 'r15_rel', 'r60_rel', 'pos60_rel', 'pos15L_rel', 'bbzL_rel', 'yenf1_rel', 'rv60', 'rsi_rel', 'p']
def contexts(X):
    keys = {'hour': X.hour.astype(str), 'dow': X.dow.astype(str), 'inst': X.inst.astype(str)}
    for f in FEATS:
        if X[f].nunique() > 5: keys[f] = pd.qcut(X[f].rank(method='first'), 5, labels=False).astype(str)
    return keys
def run(X, ycol):
    res = []
    for hold in ('P1', 'P2', 'P3'):
        tr = X.period != hold; te = ~tr
        sel_masks = []
        for k, key in contexts(X).items():
            for v in key.unique():
                m = (key == v)
                ok = True
                for p in [q for q in ('P1', 'P2', 'P3') if q != hold]:
                    s = X[m & (X.period == p)]; base = X[X.period == p][ycol].mean()
                    if len(s) < 150 or s[ycol].mean() > base - 0.02: ok = False; break
                if ok: sel_masks.append(m)
        if not sel_masks: res.append((hold, 0, np.nan, X[te][ycol].mean(), 0)); continue
        m = np.logical_or.reduce(sel_masks)
        res.append((hold, len(sel_masks), X[te & m][ycol].mean(), X[te & ~m][ycol].mean(), int((te & m).sum())))
    return res
out = {}
for wk, seg in ((True, 'weekday'), (False, 'weekend')):
    X = D[D.weekday == wk].copy(); X['w'] = X.win.astype(float)
    r = run(X, 'w'); out[seg] = r; print(seg, 'real', [(h, n, round(a, 4), round(b, 4), c) for h, n, a, b, c in r])
    rng = np.random.default_rng(1)
    gaps = []
    for i in range(int(sys.argv[1]) if len(sys.argv) > 1 else 20):
        X['ws'] = X.groupby(['inst', 'date']).w.transform(lambda s: rng.permutation(s.values))
        rs = run(X, 'ws'); gaps.append(np.nanmean([b - a for h, n, a, b, c in rs if n]) if any(n for h, n, a, b, c in rs) else 0.0)
        out[seg + '_shuffle_ncells'] = out.get(seg + '_shuffle_ncells', []) + [sum(n for h, n, a, b, c in rs)]
    print(seg, 'shuffle mean gap (rest - selected) on held-out', round(float(np.mean(gaps)), 4), 'cells', np.mean(out[seg + '_shuffle_ncells']))
json.dump(out, open('../work/skip_rotation_v0754.json', 'w'), default=float, indent=1)

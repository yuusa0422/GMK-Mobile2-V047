"""CSV for the user: losing patterns, their causes, what was tried to turn them into wins, and the v0.7.54 result."""
import pandas as pd, numpy as np, json, csv
rows = []
def sec(t): rows.append([]); rows.append(['■ ' + t])
pc = lambda x: '' if x is None or (isinstance(x, float) and np.isnan(x)) else f'{x * 100:.1f}%'
P3 = ('P1', 'P2', 'P3')
# 1) 1-minute board
T = pd.read_pickle('../work/onemin_trades_v0754.pkl')
sec('1分ボード（アプリの1分判定）を1年分の実データで再現：勝ちに数えたのは「1分後の始値が入った向きに動いた」だけ（同値=負け）')
rows.append(['区分', '回数', '1日あたり', '勝率', '引き分け', '反対向きに入ったら', '期間1', '期間2', '期間3'])
for wk, seg in ((True, '平日'), (False, '土日')):
    X = T[(T.weekday == wk) & (T.grade != 'E')]; days = X.ts.dt.date.nunique()
    rows.append([seg + ' 全体', len(X), round(len(X) / days), pc(X.win.mean()), pc(X.draw.mean()), pc(X.rev.mean())] + [pc(X[X.period == p].win.mean()) for p in P3])
    for g in ('S', 'A', 'B', 'C'):
        Y = X[X.grade == g]
        if len(Y): rows.append([f'{seg} 等級{g}', len(Y), '', pc(Y.win.mean()), pc(Y.draw.mean()), pc(Y.rev.mean())] + [pc(Y[Y.period == p].win.mean()) for p in P3])
    if wk:
        for inst, Y in X.groupby('inst'): rows.append([f'{seg} {inst}', len(Y), '', pc(Y.win.mean()), pc(Y.draw.mean()), pc(Y.rev.mean())] + [pc(Y[Y.period == p].win.mean()) for p in P3])
rows.append(['原因', '1分ボードは「直前の勢いに順張り」する簡易ルール。FXは1〜3分では行き過ぎが戻りやすく（逆張りが有利）、順張りは負ける。BTCは1分では値動きが止まりやすく引き分け（土日42%）が多い。'])
F = pd.read_pickle('../work/onemin_rule_v0754.pkl'); J = json.load(open('../work/onemin_rule_v0754.json'))
sec('1分で勝てる形はあるか：FXで直前1分に大きく動いた通貨を逆張り（1分判定）')
rows.append(['動きの大きさ', '回数', '1日あたり', '勝率', '期間1', '期間2', '期間3', '10月(2年分)'])
for th, r in J['thresholds'].items(): rows.append([f'{th}σ以上', r['n'], r['per_day'], pc(r['win']), pc(r['P1']), pc(r['P2']), pc(r['P3']), pc(r['oct'])])
S = F[F.a >= 3.0].copy(); S['ym'] = S.date.str[:7]
rows.append(['3σ以上の月別'] + [f"{ym} {pc(g.win.mean())}" for ym, g in S.groupby('ym')])
rows.append(['結論', '1年では53.6%だが、2026年9月49.5%・10月41.6%と直近で崩れている。1分で使える形は無い → 1分ボードは参考表示（ENTRYしない）にする。'])
# 2) streaks
st = json.load(open('../work/streak_v0754.json'))
sec('3分の連敗は偶然以上か（ENTRYの並び・同じ日の中の連敗）')
rows.append(['区分', '取引数', '勝率', '5連敗以上 実際', '独立なら', '8連敗以上 実際', '独立なら', '10連敗以上 実際', '独立なら', '負けの次の勝率', '勝ちの次の勝率', '2連敗の次'])
for seg, lab in (('weekday', '平日'), ('weekend', '土日')):
    r = st[seg]
    rows.append([lab, r['trades'], pc(r['win']), r['runs_observed']['5'], round(r['runs_iid_mean']['5']), r['runs_observed']['8'], round(r['runs_iid_mean']['8']),
                 r['runs_observed']['10'], round(r['runs_iid_mean']['10']), pc(r['win_after_loss']), pc(r['win_after_win']), pc(r['win_after_2loss'])])
rows.append(['結論', '平日の連敗の回数は「1回ごとに独立で勝率52.7%」から計算される回数とほぼ同じ（8連敗以上 44回 vs 37回、偶然の範囲）。負けた次も勝ちやすさは変わらない。土日はむしろ少ない。連敗を減らすには、勝率の低い取引を減らすしかない。'])
# 3) contexts
L = pd.read_pickle('../work/loss_causes_v0754.pkl')
sec('負けやすい場面の候補（モデルの取引だけ・1年・期間ごと）。「反対向き」は同じ場面で逆に入った場合（引き分けは両方負け）')
rows.append(['区分', '場面', '回数', '勝率', '引き分け', '期間1', '期間2', '期間3', '反対向き'])
for seg, lab in (('weekday', '平日'), ('weekend', '土日')):
    X = L[L.seg == seg]
    for idx, r in X.iterrows():
        if r.n < 300: continue
        rows.append([lab, idx, int(r.n), pc(r.win), pc(r.draw), pc(r.P1), pc(r.P2), pc(r.P3), pc(r.rev)])
# 4) variants
V = json.load(open('../work/skip_variants_v0754.json'))
sec('負けている場面を見送りにした場合（累積・1年・別期間で作ったモデル）')
rows.append(['見送りに加えたもの', '区分', '1日の回数', '勝率', '期間1', '期間2', '期間3', '10月', '最大連敗', '8連敗以上の日', '見送った取引の勝率', 'その期間別', '反対向きなら'])
for k, r in V.items():
    name, seg = k.split('|')
    rows.append([name, seg, r['per_day'], f"{r['win']}%", f"{r['P1']}%", f"{r['P2']}%", f"{r['P3']}%", f"{r['oct']}%", r['maxrun'], f"{r['days8']}%",
                 '' if r['moved_win'] is None else f"{r['moved_win']}%", '' if r['moved_P'] is None else ' / '.join(f'{x}%' for x in r['moved_P']),
                 '' if r['moved_rev'] is None else f"{r['moved_rev']}%"])
rows.append(['採用', '9時台のC（3期間とも50%未満）と土日のC（3期間とも50.8%以下・10月46.2%）。「直前1分の逆張りが無いFXのC」と「月曜のC」は期間1で逆の結果になるため不採用。'])
rows.append(['9時台の原因', '仲値(9:55)に向けた実需の売買で一方向に動くが、順張りも 45〜51% で勝てない。仲値の瞬間(9:55)だけは戻りが強く、ここはS/Aのルールで取る。'])
rows.append(['土日の原因', '土日のBTCは取引が薄く、3分で値段が動かない（引き分け 12〜15%）。向きの当たりは引き分けを除くと54〜58%あるが、引き分けが負けになるためCは負け越す。引き分けを予測するモデル（別期間でAUC 0.73）も試したが、静かな時間は向きが当たるが引き分けが多く、動く時間は引き分けが少ないが向きが当たりにくく、勝率は上がらない。'])
# 5) new ladder
N = json.load(open('../work/ladder_v0754.json'))
sec('v0.7.54 のランク（1年・別期間）')
rows.append(['区分', 'ランク', '回数', '勝率', '1日あたり', '期間1', '期間2', '期間3', '10月', '最大連敗'])
for seg, lab in (('weekday', '平日'), ('weekend', '土日')):
    for g in 'SABCDEFGH':
        r = N[seg].get(g)
        if r: rows.append([lab, g, int(r['n']), pc(r['win']), round(r['per_day'], 1), pc(r['P1']), pc(r['P2']), pc(r['P3']), pc(r['oct']), r['maxrun']])
for k, lab in (('weekday_SA', '平日 S/Aだけ'), ('weekday_SAB', '平日 S〜B'), ('weekday_SABC', '平日 ENTRY全部'), ('weekend_SAB', '土日 ENTRY全部(Bのみ)')):
    r = N[k]; rows.append([lab, '', '', f"{r['win']}%", r['per_day'], f"{r['P1']}%", f"{r['P2']}%", f"{r['P3']}%", f"{r['oct']}%", r['maxrun'], f"8連敗以上の日 {r['days8']}%"])
sec('祝日の確認（時間帯ルール）')
rows.append(['日本の祝日の9:55/12:20', '16回 62.5%（祝日以外 63.4%）→ 差なし'])
rows.append(['米国の祝日の米指標/22:50', '9回 77.8%（祝日以外 63.9%）→ 差なし（回数が少ない）'])
with open('../pages/GMK_負けパターンの原因と対策.csv', 'w', newline='', encoding='utf-8-sig') as f:
    csv.writer(f).writerows(rows[1:])
print(len(rows))

"""Cause analysis of losses (weekday FX+BTC and weekend BTC) on the v0.7.53 ladder, model trades only (rule trades excluded:
their features belong to the model instrument). Each hypothesis is a small, mechanism-motivated split; shown per period."""
import pandas as pd, numpy as np
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400)
out = []
def tab(X, name, key):
    g = X.groupby(key, observed=True)
    t = pd.DataFrame({'n': g.size(), 'win': g.win.mean(), 'draw': g.tie.mean()})
    for p in ('P1', 'P2', 'P3'): t[p] = X[X.period == p].groupby(key, observed=True).win.mean()
    t['rev'] = 1 - t.win - t.draw   # reversed trade: draws lose both ways
    t.index = [f'{name}={i}' for i in t.index]
    return t
for wk, seg in ((True, 'weekday'), (False, 'weekend')):
    X = pd.read_pickle(f'../work/streak_v0754_{seg}.pkl')
    X = X[X.r_rank.isna()].copy()
    X['fx'] = np.where(X.inst == 'BTCJPY', 'BTC', 'FX')
    T = [tab(X, 'all', 'fx')]
    T.append(tab(X, 'hour', X.hour))
    T.append(tab(X, 'inst', 'inst'))
    T.append(tab(X, 'dow', 'dow'))
    for col, edges in (('r60_rel', [-9, -2, -1, -0.3, 0.3, 1, 2, 9]), ('r15_rel', [-9, -2, -1, -0.3, 0.3, 1, 2, 9]), ('f1_rel', [-30, -2.5, -1, -0.3, 0.3, 1, 2.5, 30]),
                       ('pos60_rel', [-1.01, -0.8, -0.4, 0, 0.4, 0.8, 1.01]), ('yenf1_rel', [-30, -1.5, -0.5, 0.5, 1.5, 30])):
        for fx in ('FX', 'BTC'):
            S = X[X.fx == fx]
            if len(S) < 500: continue
            T.append(tab(S, f'{fx}:{col}', pd.cut(S[col], edges)))
    for fx in ('FX', 'BTC'):
        S = X[X.fx == fx]
        if len(S) < 500: continue
        T.append(tab(S, f'{fx}:rv60_q', pd.qcut(S.rv60, 5, labels=['q1low', 'q2', 'q3', 'q4', 'q5high'])))
        T.append(tab(S, f'{fx}:grade', 'g'))
        T.append(tab(S, f'{fx}:dir', 'dir'))
        if fx == 'BTC':
            T.append(tab(S, 'BTC:zero30_q', pd.qcut(S.zero30.rank(method='first'), 5, labels=['q1', 'q2', 'q3', 'q4', 'q5'])))
    R = pd.concat(T); R['min3'] = R[['P1', 'P2', 'P3']].min(axis=1); R['max3'] = R[['P1', 'P2', 'P3']].max(axis=1)
    R['seg'] = seg; out.append(R)
    print(f'\n===== {seg}  (model trades {len(X)}, win {X.win.mean():.4f}, draw {X.tie.mean():.4f})')
    print(R.round(3).to_string())
pd.concat(out).to_pickle('../work/loss_causes_v0754.pkl')

"""Replay of the app's 1-minute board (OneMinuteLocalEngine, GMK_V0735_NATIVE_1M) on one year of real 1-minute candles.
Entry T = every minute 09:00-22:59 JST; scan at T-10 s sees completed bars up to the one opening at T-120 s.
Result = OPEN(T+1) vs OPEN(T) (the app's 1-minute judge), draw = lose. Weekdays six instruments, weekends BTCJPY."""
import gzip, csv, numpy as np, pandas as pd
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
ORDER = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']
T0 = pd.Timestamp('2025-10-01', tz='Asia/Tokyo').value // 60_000_000_000; T1 = pd.Timestamp('2026-10-22', tz='Asia/Tokyo').value // 60_000_000_000
N = T1 - T0
def load(s):
    with gzip.open(SRC[s], 'rt') as f:
        a = np.array([(int(r['epoch_ms']) // 60000, float(r['open']), float(r['high']), float(r['low']), float(r['close'])) for r in csv.DictReader(f)])
    g = np.full((N, 4), np.nan); m = (a[:, 0] >= T0) & (a[:, 0] < T1); idx = (a[m, 0] - T0).astype(int); g[idx] = a[m, 1:]
    return g
def ema_global(c, period):
    a = 2.0 / (period + 1.0); out = np.full_like(c, np.nan); e = np.nan
    for i, v in enumerate(c):
        if np.isnan(v): e = np.nan; continue
        e = v if np.isnan(e) else e + a * (v - e); out[i] = e
    return out
def win_view(x, w):
    return np.lib.stride_tricks.sliding_window_view(x, w)          # row k = x[k .. k+w-1]
def tanh(x): return np.tanh(x)
def main():
  res = {}
  for s in ORDER:
      g = load(s); o, h, l, c = g[:, 0], g[:, 1], g[:, 2], g[:, 3]
      # j = index of the last completed bar (opens at T-120 s) for entry minute T = j + 2
      j = np.arange(N)
      ok60 = np.r_[np.zeros(59, bool), ~np.isnan(win_view(c, 60)).any(axis=1)]
      def back(x, k): return np.r_[np.full(k, np.nan), x[:-k]]
      ret1 = c / back(c, 1) - 1; ret2 = c / back(c, 2) - 1
      e3 = ema_global(c, 3); e8 = ema_global(c, 8)
      spread = (e3 - e8) / c
      pe3 = back(e3, 2); pe8 = back(e8, 2); prevSpread = (pe3 - pe8) / back(c, 2)
      d = np.diff(c, prepend=np.nan)
      dv = win_view(np.r_[np.full(6, np.nan), d], 7)   # last 7 diffs ending at j (rsi7 uses 8 closes -> 7 diffs)
      gains = np.nansum(np.where(dv > 0, dv, 0), axis=1); losses = np.nansum(np.where(dv < 0, -dv, 0), axis=1)
      rs = np.where(losses > 1e-12, gains / np.maximum(losses, 1e-300), np.inf)
      rsi = np.where(gains + losses <= 1e-12, 50.0, np.where(losses <= 1e-12, 100.0, 100 - 100 / (1 + rs)))
      cv12 = win_view(np.r_[np.full(11, np.nan), c], 12); m12 = cv12.mean(axis=1); sd12 = np.sqrt(np.maximum(((cv12 - m12[:, None]) ** 2).mean(axis=1), 1e-16))
      bb = (c - m12) / sd12
      pc = back(c, 1); tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
      atr = win_view(np.r_[np.full(6, np.nan), tr], 7).mean(axis=1) / c
      body = (c - o) / c
      score = np.clip(0.34 * tanh(ret1 / 0.0007) + 0.20 * tanh(ret2 / 0.001) + 0.20 * tanh(spread / 0.0007) + 0.12 * np.clip((rsi - 50) / 20, -1, 1)
                      + 0.08 * tanh(bb / 1.0) + 0.06 * tanh(body / 0.0006), -1, 1)
      # regime on the last 8 closes
      c8 = win_view(np.r_[np.full(7, np.nan), c], 8); dd = np.diff(c8, axis=1)
      travel = np.abs(dd).sum(axis=1); net = np.abs(c8[:, -1] - c8[:, 0]); eff = np.where(travel <= 1e-12, 0, np.clip(net / np.maximum(travel, 1e-300), 0, 1))
      sg = np.sign(dd); nz = sg != 0
      flips = np.zeros(N); cnt = nz.sum(axis=1)
      for r in range(N):
          if cnt[r] > 1:
              v = sg[r][nz[r]]; flips[r] = (v[1:] != v[:-1]).sum() / (len(v) - 1)
      alt = flips
      def ema8w(x, period):
          a = 2.0 / (period + 1); wts = np.array([(1 - a) ** 7] + [a * (1 - a) ** (7 - k) for k in range(1, 8)]); return x @ wts
      rs8 = (ema8w(c8, 3) - ema8w(c8, 8)) / c8[:, -1]
      regime = np.select([(alt >= 0.65) & (eff <= 0.35), (eff >= 0.55) & (rs8 > 0), (eff >= 0.55) & (rs8 < 0), eff <= 0.30], ['CHOPPY', 'TREND_UP', 'TREND_DOWN', 'RANGE'], 'TRANSITION')
      dirn = np.sign(score)
      curT = np.sign(spread); prevT = np.sign(prevSpread)
      switch = (curT != 0) & (prevT != 0) & (curT != prevT)
      sct = switch & (dirn != 0) & (dirn != curT)
      agree = np.where(score >= 0, (np.c_[ret1, ret2, spread, rsi - 50, bb, body] > 0).sum(axis=1), (np.c_[ret1, ret2, spread, rsi - 50, bb, body] < 0).sum(axis=1)) / 6.0
      volp = np.clip((atr - 0.001) / 0.004, 0, 0.12)
      conf = np.clip(0.5 + np.abs(score) * 0.34 + agree * 0.08 - volp, 0.5, 0.9)
      conf = np.where(sct, np.minimum(conf, 0.51), conf); conf = np.where(regime == 'CHOPPY', np.maximum(conf - 0.03, 0.5), conf)
      # outcome for entry T = j + 2: OPEN(T+1) vs OPEN(T)
      oT = np.r_[o[2:], np.nan, np.nan]; oT1 = np.r_[o[3:], np.nan, np.nan, np.nan]
      res[s] = pd.DataFrame({'j': j, 'ok': ok60 & ~np.isnan(oT) & ~np.isnan(oT1), 'score': score, 'conf': conf, 'sct': sct, 'regime': regime,
                             'move': np.sign(oT1 - oT), 'ret1': ret1, 'spread': spread})
      print(s, 'ok minutes', int(res[s].ok.sum()))
  pd.to_pickle(res, '../work/onemin_raw_v0754.pkl')
if __name__ == '__main__':
    main()

"""v0.7.54 losing-streak anatomy on the v0.7.53 ladder (one trade per slot, out of sample).
1) are long losing runs more frequent than chance? (i.i.d. shuffle vs within-day shuffle)
2) what do trades inside long runs have in common? (relative-to-direction features, draws, hour, instrument)
3) day-level: what makes a bad day?"""
import pandas as pd, numpy as np, json
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
D = pd.read_pickle('../work/ladder_v0753.pkl').sort_values('b')
ev = D.r_rank.notna()
D['t_inst'] = np.where(ev, D.r_inst, D.inst); D['t_dir'] = np.where(ev, D.r_dir, D.dir)
E = D[D.g.isin(list('SABC'))].copy()
def runs(w, dates):
    """within-day run length of each loss (0 for wins)"""
    out = np.zeros(len(w), int); i = 0; n = len(w)
    while i < n:
        if w[i] == 0:
            j = i
            while j + 1 < n and w[j + 1] == 0 and dates[j + 1] == dates[i]: j += 1
            out[i:j + 1] = j - i + 1; i = j + 1
        else: i += 1
    return out
def count_runs(w, dates, k):
    r = runs(w, dates); starts = np.r_[True, (r[1:] != r[:-1]) | (dates[1:] != dates[:-1]) | (w[1:] != w[:-1])]
    return int(((r >= k) & starts & (w == 0)).sum())
rng = np.random.default_rng(54); res = {}
for wk, seg in ((True, 'weekday'), (False, 'weekend')):
    X = E[E.weekday == wk].copy(); w = X.win.values.astype(int); dts = X.date.astype(str).values
    X['run'] = runs(w, dts)
    obs = {k: count_runs(w, dts, k) for k in (5, 6, 8, 10)}
    iid = {k: [] for k in obs}; day = {k: [] for k in obs}
    for _ in range(200):
        a = rng.permutation(w)
        b = X.groupby('date').win.transform(lambda s: rng.permutation(s.values)).values.astype(int)
        for k in obs: iid[k].append(count_runs(a, dts, k)); day[k].append(count_runs(b, dts, k))
    res[seg] = {'trades': len(X), 'win': X.win.mean(), 'runs_observed': obs, 'runs_iid_mean': {k: float(np.mean(v)) for k, v in iid.items()},
                'runs_iid_p': {k: float(np.mean(np.array(v) >= obs[k])) for k, v in iid.items()},
                'runs_withinday_mean': {k: float(np.mean(v)) for k, v in day.items()}}
    # lag-1 dependence within day
    X['prev'] = X.groupby('date').win.shift(1); X['prev2'] = X.groupby('date').win.shift(2)
    res[seg]['win_after_win'] = X[X.prev == 1].win.mean(); res[seg]['win_after_loss'] = X[X.prev == 0].win.mean()
    res[seg]['win_after_2loss'] = X[(X.prev == 0) & (X.prev2 == 0)].win.mean()
    # daily dispersion vs binomial
    dd = X.groupby('date').win.agg(['mean', 'size']); p = X.win.mean()
    res[seg]['daily_sd'] = dd['mean'].std(); res[seg]['binomial_sd'] = float(np.sqrt((p * (1 - p) / dd['size']).mean()))
    X.to_pickle(f'../work/streak_v0754_{seg}.pkl')
print(json.dumps(res, indent=1, default=float))
json.dump(res, open('../work/streak_v0754.json', 'w'), indent=1, default=float)

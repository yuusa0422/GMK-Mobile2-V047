import jp.gmk.mobile.domain.*
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

fun main(args: Array<String>) {
    val jst = ZoneId.of("Asia/Tokyo")
    var cur: Long = 0; var want: List<String> = emptyList(); val bars = linkedMapOf<String, MutableList<Candle>>()
    var n = 0; var same = 0; var sameDir = 0; var confDiff = 0.0
    for (line in File(args[0]).readLines()) {
        val p = line.split('|')
        when (p[0]) {
            "SLOT" -> { cur = p[1].toLong(); want = p.drop(2); bars.clear() }
            "BAR" -> bars.getOrPut(p[1]) { mutableListOf() } += Candle(p[2].toLong(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble(), 0.0)
            "END" -> {
                val entry = ZonedDateTime.ofInstant(Instant.ofEpochSecond(cur), jst)
                val r = OneMinuteLocalEngine().scan(bars, entry.minusSeconds(10), entry)
                val t = r.top1!!
                n++; if (t.instrument == want[0] && t.direction == want[1]) same++
                if (t.direction == want[1]) sameDir++
                if (t.instrument == want[0]) confDiff = maxOf(confDiff, kotlin.math.abs(t.confidence - want[2].toDouble()))
            }
        }
    }
    println("slots=$n same_top1=$same same_direction=$sameDir max_conf_diff_when_same_inst=$confDiff")
}

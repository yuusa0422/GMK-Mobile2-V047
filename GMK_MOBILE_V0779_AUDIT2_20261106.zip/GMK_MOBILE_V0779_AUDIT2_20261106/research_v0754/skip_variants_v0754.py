"""Policy variants that move stable losing contexts from C (ENTRY) to D (SKIP). Scored per period; streaks on the ENTRY sequence."""
import pandas as pd, numpy as np, json
D = pd.read_pickle('../work/ladder_v0753.pkl').sort_values('b')
fx = D.inst != 'BTCJPY'; model = D.r_rank.isna()
C = (D.g == 'C') & model
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
def day_runs(e):
    return e.groupby('date').win.apply(lambda s: maxrun(s.values))
V = {
    'v0.7.53': pd.Series(False, index=D.index),
    '+9時台のC': C & D.weekday & (D.hour == 9),
    '+直前1分の逆張りが無いFXのC': C & D.weekday & fx & (D.f1_rel > -0.3),
    '+月曜のC': C & D.weekday & (D.dow == 1),
    '+土日の流れに乗るC(60分)': C & ~D.weekday & (D.r60_rel > 0.3),
}
cum = pd.Series(False, index=D.index); out = {}
for name, m in V.items():
    cum = cum | m
    for wk, seg in ((True, '平日'), (False, '土日')):
        W = D[D.weekday == wk]; e = W[W.g.isin(list('SABC')) & ~cum[W.index]]; days = W.date.nunique()
        moved = W[cum[W.index] & W.g.isin(list('SABC'))]
        dr = day_runs(e)
        r = dict(per_day=round(len(e) / days, 1), win=round(e.win.mean() * 100, 2), **{p: round(e[e.period == p].win.mean() * 100, 2) for p in ('P1', 'P2', 'P3')},
                 oct=round(e[e.oct].win.mean() * 100, 2), maxrun=maxrun(e.win.values), days8=round((dr >= 8).mean() * 100, 1), days6=round((dr >= 6).mean() * 100, 1),
                 moved=len(moved), moved_win=round(moved.win.mean() * 100, 2) if len(moved) else None,
                 moved_P=[round(moved[moved.period == p].win.mean() * 100, 1) for p in ('P1', 'P2', 'P3')] if len(moved) else None,
                 moved_rev=round((1 - moved.win - moved.tie).mean() * 100, 2) if len(moved) else None)
        out[f'{name}|{seg}'] = r; print(name, seg, r)
json.dump(out, open('../work/skip_variants_v0754.json', 'w'), ensure_ascii=False, indent=1)

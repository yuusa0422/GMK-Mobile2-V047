"""Dump 300 random weekday entry minutes (six instruments, 60 completed bars each) + the Python replay's TOP1 for a Kotlin check."""
import numpy as np, pandas as pd, random, sys
from onemin_sim_v0754 import load, ORDER, T0, N
D = pd.read_pickle('../work/onemin_trades_v0754.pkl')
G = {s: load(s) for s in ORDER}
rng = random.Random(7); ks = rng.sample(sorted(D[D.weekday].k.values), 300) + rng.sample(sorted(D[~D.weekday].k.values), 100)
out = []
for k in ks:
    r = D[D.k == k].iloc[0]
    entry_min = k + 2 + T0                      # epoch minutes of the entry
    insts = ORDER if r.weekday else ['BTCJPY']
    out.append(f'SLOT|{entry_min * 60}|{r.inst}|{"HIGH" if r.dir > 0 else "LOW"}|{r.conf:.6f}')
    for s in insts:
        g = G[s]
        for j in range(k - 59, k + 1):
            o, h, l, c = g[j]
            out.append(f'BAR|{s}|{(j + T0) * 60000}|{float(o)!r}|{float(h)!r}|{float(l)!r}|{float(c)!r}')
    out.append('END')
open(sys.argv[1], 'w').write('\n'.join(out) + '\n'); print(len(ks))

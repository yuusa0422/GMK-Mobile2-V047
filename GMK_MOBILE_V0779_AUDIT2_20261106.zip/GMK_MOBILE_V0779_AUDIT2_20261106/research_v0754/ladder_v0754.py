"""v0.7.54 ladder: v0.7.53 + weekday 9:00-9:55 model C -> E (skip) + weekend: model S -> B (ENTRY), A/B/C -> D (skip), D/E -> E."""
import pandas as pd, numpy as np, json
D = pd.read_pickle('../work/ladder_v0753.pkl').sort_values('b')
model = D.r_rank.isna()
g = D.g.copy()
g[model & D.weekday & (D.g == 'C') & (D.hour == 9)] = 'E'
we = model & ~D.weekday
g[we & (D.g == 'C')] = 'D'
g[we & D.g.isin(['D', 'E'])] = 'E'
D['g54'] = g
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
out = {}
for wk, seg in ((True, 'weekday'), (False, 'weekend')):
    W = D[D.weekday == wk]; days = W.date.nunique()
    t = W.groupby('g54').agg(n=('win', 'size'), win=('win', 'mean')); t['per_day'] = t.n / days
    for p in ('P1', 'P2', 'P3'): t[p] = W[W.period == p].groupby('g54').win.mean()
    t['oct'] = W[W.oct].groupby('g54').win.mean(); t['oct_n'] = W[W.oct].groupby('g54').size(); t['maxrun'] = W.groupby('g54').win.apply(lambda s: maxrun(s.values))
    print(seg); print(t.round(4).to_string()); out[seg] = t.round(4).to_dict('index')
    for keep in (['S', 'A'], ['S', 'A', 'B'], ['S', 'A', 'B', 'C']):
        e = W[W.g54.isin(keep)]
        if not len(e): continue
        daily = e.groupby('date').win.apply(lambda s: maxrun(s.values))
        r = dict(per_day=round(len(e) / days, 1), win=round(e.win.mean() * 100, 2), maxrun=maxrun(e.win.values), days8=round((daily >= 8).mean() * 100, 1),
                 days6=round((daily >= 6).mean() * 100, 1), oct=round(e[e.oct].win.mean() * 100, 2), **{p: round(e[e.period == p].win.mean() * 100, 2) for p in ('P1', 'P2', 'P3')})
        print(''.join(keep), r); out[seg + '_' + ''.join(keep)] = r
json.dump(out, open('../work/ladder_v0754.json', 'w'), indent=1, default=float, ensure_ascii=False)
D.to_pickle('../work/ladder_v0754.pkl')

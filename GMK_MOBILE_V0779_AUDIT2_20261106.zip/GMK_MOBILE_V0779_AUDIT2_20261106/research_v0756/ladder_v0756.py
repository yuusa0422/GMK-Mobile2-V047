"""v0.7.56 'ENTRY 60%': the user asked for ENTRY on at least 60% of slots, skipping the worst 40%.
Weekday: S/A/B as v0.7.55, plus C = former C (v0.7.55 D, 10-22h) whose rank strength R is in the top part, so that S+A+B+C = 60%.
Weekend: B as v0.7.55, plus C = every slot whose strength E is in the top 60% (minus B).
Rates are other-half (cross-fitted) E/R; the app uses fixed cuts on the production models fitted on the year (strength_production.json)."""
import pickle, json, numpy as np, pandas as pd
exec(open('design_x.py').read().split("if __name" + "__")[0])
L = pd.read_pickle('../work/ladder_v0755.pkl').sort_values('b').reset_index(drop=True)
P = json.load(open('../work/strength_production.json'))
SS = pickle.load(open('../work/strength_slots.pkl', 'rb'))
COVER = 0.60
def prod(x, spec):
    X = F(x, spec['cols']); return 1 / (1 + np.exp(-(X @ np.array(spec['coef']) + spec['intercept'])))
def maxrun(w):
    m = c = 0
    for v in w: c = c + 1 if v == 0 else 0; m = max(m, c)
    return m
out = {'cover': COVER}
# ---------------- fresh (live price) ----------------
S = SS[True].copy(); wd = S.weekday
S['pr'] = np.nan; S['pe'] = np.nan
S.loc[wd, 'pr'] = prod(S[wd], P['models']['fresh']['weekday_rank']); S.loc[wd, 'pe'] = prod(S[wd], P['models']['fresh']['weekday_entry'])
S.loc[~wd, 'pe'] = prod(S[~wd], P['models']['fresh']['weekend'])
assert S.b.is_unique and L.b.is_unique
L = L.merge(S[['b', 'pr', 'pe']], on='b', how='left'); assert L.pe.notna().all()
g = L.g55.copy(); W = L.weekday
# weekday C
n_wd = W.sum(); need = int(round(COVER * n_wd)) - L[W & L.g55.isin(['S', 'A', 'B'])].shape[0]
Dm = W & (L.g55 == 'D')
share_c = need / Dm.sum()
cut_R = float(np.quantile(L.loc[Dm, 'R'], 1 - share_c))          # other-half R (validation)
cut_pr = float(np.quantile(L.loc[Dm, 'pr'], 1 - share_c))        # production r (app)
g[Dm & (L.R >= cut_R)] = 'C'
agree = ((L.loc[Dm, 'R'] >= cut_R) == (L.loc[Dm, 'pr'] >= cut_pr)).mean()
# weekend C: E in the top 60% of weekend slots, minus B
E_ = ~W
cut_E = float(np.quantile(L.loc[E_, 'E'], 1 - COVER)); cut_pe = float(np.quantile(L.loc[E_, 'pe'], 1 - COVER))
inC = E_ & (L.g55 != 'B') & (L.E >= cut_E)
g[inC] = 'C'
# weekend skips: D = v0.7.48 D not in C, E = v0.7.48 E (and anything else of v0.7.55 D/E not in C)
g[E_ & ~inC & (L.g55 == 'D')] = 'D'
g[E_ & ~inC & (L.g55 == 'E') & (L.grade == 'D')] = 'D'
g[E_ & ~inC & (L.g55 == 'E') & (L.grade != 'D')] = 'E'
L['g56'] = g
agree_we = ((L.loc[E_, 'E'] >= cut_E) == (L.loc[E_, 'pe'] >= cut_pe)).mean()
out['fresh_cuts'] = dict(weekday_c_share_of_former_c=share_c, weekday_rank_cut_oos=cut_R, weekday_rank_cut_production=cut_pr, weekday_assignment_agreement=float(agree),
                         weekend_cut_oos=cut_E, weekend_cut_production=cut_pe, weekend_assignment_agreement=float(agree_we))
print(json.dumps(out['fresh_cuts'], indent=1))
for wkd, seg in ((True, 'weekday'), (False, 'weekend')):
    X = L[L.weekday == wkd]; days = X.date.nunique()
    t = X.groupby('g56').agg(n=('win', 'size'), win=('win', 'mean'), draw=('tie', 'mean')); t['per_day'] = t.n / days
    for p in ('P1', 'P2', 'P3'): t[p] = X[X.period == p].groupby('g56').win.mean()
    t['oct'] = X[X.oct].groupby('g56').win.mean(); t['oct_n'] = X[X.oct].groupby('g56').size()
    print(seg); print(t.round(4).to_string()); out[seg] = t.round(4).to_dict('index')
    for mode, grades in (('55', ['S', 'A', 'B']), ('60', ['S', 'A', 'B', 'C'])):
        e = X[X.g56.isin(grades)]; daily = e.groupby('date').win.agg(['size', 'sum'])
        r = dict(share=round(len(e) / len(X) * 100, 1), per_day=round(len(e) / days, 1), win=round(e.win.mean() * 100, 2),
                 **{p: round(e[e.period == p].win.mean() * 100, 2) for p in ('P1', 'P2', 'P3')}, oct=round(e[e.oct].win.mean() * 100, 2),
                 maxrun=maxrun(e.win.values), draw=round(e.tie.mean() * 100, 1),
                 days_below50=round(((daily['sum'] / daily['size']) < 0.5).mean() * 100, 1),
                 hours={int(h): [round(len(x) / len(X[X.hour == h]) * 100), round(x.win.mean() * 100, 1)] for h, x in e.groupby('hour')})
        print(seg, mode, r); out[f'{seg}_{mode}'] = r
# coverage curve (by tier then R / E) for the report
curve = {}
for wkd, seg, order, key in ((True, 'weekday', {'S': 0, 'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6}, 'R'), (False, 'weekend', {'B': 0, 'C': 1, 'D': 2, 'E': 3, 'F': 4, 'G': 5, 'H': 6}, 'E')):
    X = L[L.weekday == wkd].copy(); X['t'] = X.g56.map(order); X = X.sort_values(['t', key], ascending=[True, False]); n = len(X); days = X.date.nunique(); res = []
    for cov in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 1.0):
        s = X.iloc[:int(n * cov)]
        res.append(dict(cover=cov, per_day=round(len(s) / days, 1), win=round(s.win.mean() * 100, 2), **{p: round(s[s.period == p].win.mean() * 100, 1) for p in ('P1', 'P2', 'P3')}))
    curve[seg] = res
out['curve'] = curve
# expected stake units per day for several payouts (win returns payout x stake; loss and draw lose the stake as the app scores draws)
pay = {}
for seg in ('weekday', 'weekend'):
    for mode in ('55', '60'):
        r = out[f'{seg}_{mode}']
        pay[f'{seg}_{mode}'] = {str(k): round(r['per_day'] * (r['win'] / 100 * k - 1), 2) for k in (1.80, 1.85, 1.90, 1.95, 2.00)}
out['units_per_day'] = pay; print(json.dumps(pay, indent=0))
# ---------------- fallback (stale live price) ----------------
B = pd.read_pickle('../work/design_x_fallback.pkl').sort_values('b').reset_index(drop=True)
SF = SS[False].copy(); wdf = SF.weekday
SF['pr'] = np.nan; SF['pe'] = np.nan
SF.loc[wdf, 'pr'] = prod(SF[wdf], P['models']['fallback']['weekday_rank']); SF.loc[~wdf, 'pe'] = prod(SF[~wdf], P['models']['fallback']['weekend'])
B = B.merge(SF[['b', 'pr', 'pe']], on='b', how='left')
Wf = B.weekday
rules_share = L[W & L.g55.isin(['S', 'A'])].shape[0] / n_wd
Df = Wf & B.grade.isin(['S', 'A', 'B', 'C']) & (B.hour != 9)
share_f = (COVER - rules_share) * Wf.sum() / Df.sum()
fcut_R = float(np.quantile(B.loc[Df, 'R'], 1 - share_f)); fcut_pr = float(np.quantile(B.loc[Df, 'pr'], 1 - share_f))
fC = Df & (B.R >= fcut_R)
Ef = ~Wf
fcut_E = float(np.quantile(B.loc[Ef, 'E'], 1 - COVER)); fcut_pe = float(np.quantile(B.loc[Ef, 'pe'], 1 - COVER))
# fallback weekend B = S against the hour (v0.7.55); C = the rest of the top 60%
fB = Ef & (B.grade == 'S') & (L.set_index('b').reindex(B.b).pos60_rel.values <= 0)
fCw = Ef & ~fB & (B.E >= fcut_E)
fb = dict(weekday_c_share_of_former_c=share_f, weekday_rank_cut_oos=fcut_R, weekday_rank_cut_production=fcut_pr,
          weekday_C=dict(n=int(fC.sum()), win=round(B[fC].win.mean() * 100, 2), **{p: round(B[fC & (B.period == p)].win.mean() * 100, 2) if 'period' in B else None for p in ('P1', 'P2', 'P3')}) if 'period' in B else dict(n=int(fC.sum()), win=round(B[fC].win.mean() * 100, 2)),
          weekday_D_rest=dict(n=int((Df & ~fC).sum()), win=round(B[Df & ~fC].win.mean() * 100, 2)),
          weekend_cut_oos=fcut_E, weekend_cut_production=fcut_pe,
          weekend_C=dict(n=int(fCw.sum()), win=round(B[fCw].win.mean() * 100, 2)),
          weekend_rest_vD=dict(n=int((Ef & ~fB & ~fCw & (B.grade == 'D')).sum()), win=round(B[Ef & ~fB & ~fCw & (B.grade == 'D')].win.mean() * 100, 2)),
          weekend_rest_vE=dict(n=int((Ef & ~fB & ~fCw & (B.grade == 'E')).sum()), win=round(B[Ef & ~fB & ~fCw & (B.grade == 'E')].win.mean() * 100, 2)),
          weekday_cover=round(((Wf & B.grade.isin(['S', 'A', 'B', 'C']) & (B.hour != 9) & (B.R >= fcut_R)).sum() / Wf.sum() + rules_share) * 100, 1),
          weekend_cover=round((fB | fCw).sum() / Ef.sum() * 100, 1))
out['fallback'] = fb; print(json.dumps(fb, indent=1))
json.dump(out, open('../work/ladder_v0756.json', 'w'), indent=1, default=float, ensure_ascii=False)
L.to_pickle('../work/ladder_v0756.pkl')

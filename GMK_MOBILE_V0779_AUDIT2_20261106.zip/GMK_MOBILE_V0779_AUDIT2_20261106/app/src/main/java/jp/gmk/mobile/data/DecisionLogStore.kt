package jp.gmk.mobile.data

import jp.gmk.mobile.domain.DecisionLog
import java.io.File

/**
 * v0.7.73: the decision log file (gmk_decision_log.jsonl in the app's files): appended once per AUTO slot, trimmed to the newest
 * [DecisionLog.KEEP] lines through a temporary file when it passes [DecisionLog.TRIM_AT]. A failure never affects the decision or the
 * history (the caller ignores it); broken lines are skipped when read.
 */
class DecisionLogStore(dir: File) {
    private val file = File(dir, "gmk_decision_log.jsonl")
    private val lock = Any()
    private var lines = -1

    fun append(line: String) = synchronized(lock) {
        if (lines < 0) lines = if (file.exists()) file.useLines { s -> s.count() } else 0
        file.appendText(line.replace('\n', ' ') + "\n"); lines++
        if (lines > DecisionLog.TRIM_AT) {
            val keep = file.readLines().filter { DecisionLog.complete(it) }.takeLast(DecisionLog.KEEP)
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(keep.joinToString("\n", postfix = "\n"))
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file) }
            lines = keep.size
        }
    }

    fun recent(n: Int): List<String> = synchronized(lock) {
        try { if (!file.exists()) emptyList() else file.readLines().filter { DecisionLog.complete(it) }.takeLast(n) } catch (_: Exception) { emptyList() }
    }

    fun size(): Int = synchronized(lock) { try { if (!file.exists()) 0 else file.useLines { s -> s.count { DecisionLog.complete(it) } } } catch (_: Exception) { 0 } }
}

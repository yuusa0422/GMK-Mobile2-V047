package jp.gmk.mobile.domain

import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.79: the stored times read without java.time's text parser. The screens and statistics read every row's time each time the
 * history changes (every minute with the 1-minute judgment): ZonedDateTime.parse of 20,000 rows took 0.1-0.2 s on a desktop per panel,
 * several times that on a phone, on the main thread (the screen stuttered and the AUTO scheduler could pass its T-10 window).
 * The app writes "2026-11-06T10:05:00+09:00" / "2026-11-06T10:10+09:00" (seconds left out when zero) and, for some times, a fraction;
 * exactly that form (4-digit year 1900-2999, 'T', optional seconds and 1-9 fraction digits, then 'Z' or +HH:MM / -HH:MM up to 18:00) is
 * read here, every other text (a zone region "[Asia/Tokyo]", lower case, other forms) goes to ZonedDateTime.parse as before, so the
 * result is always the same as ZonedDateTime.parse(text).toInstant() (null where that threw).
 */
object FastTime {
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    /** The instant of [s], or null when ZonedDateTime.parse could not read it. */
    @JvmStatic
    fun instant(s: String): Instant? = fast(s) ?: try { ZonedDateTime.parse(s).toInstant() } catch (e: RuntimeException) { null }

    /** Epoch milliseconds of [s] (as ZonedDateTime.parse(s).toInstant().toEpochMilli()), or null. */
    @JvmStatic
    fun epochMs(s: String): Long? = instant(s)?.let { try { it.toEpochMilli() } catch (e: ArithmeticException) { null } }

    /** [s] in JST (as ZonedDateTime.parse(s).withZoneSameInstant(Asia/Tokyo)), or null. */
    @JvmStatic
    fun jst(s: String): ZonedDateTime? = instant(s)?.let { try { it.atZone(JST) } catch (e: RuntimeException) { null } }

    private fun digit(s: String, i: Int): Int { val c = s[i]; return if (c in '0'..'9') c - '0' else -1 }
    private fun two(s: String, i: Int): Int { val a = digit(s, i); val b = digit(s, i + 1); return if (a < 0 || b < 0) -1 else a * 10 + b }

    /** Days from 1970-01-01 of a valid proleptic Gregorian date (H. Hinnant's days_from_civil). */
    private fun epochDay(y0: Int, m: Int, d: Int): Long {
        val y = (if (m <= 2) y0 - 1 else y0).toLong()
        val era = Math.floorDiv(y, 400L)
        val yoe = y - era * 400L
        val mp = ((m + 9) % 12).toLong()
        val doy = (153L * mp + 2L) / 5L + d - 1L
        val doe = yoe * 365L + yoe / 4L - yoe / 100L + doy
        return era * 146097L + doe - 719468L
    }

    private fun monthLength(y: Int, m: Int): Int = when (m) {
        2 -> if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) 29 else 28
        4, 6, 9, 11 -> 30
        else -> 31
    }

    /** The fast form only; null for anything else (the caller then asks ZonedDateTime.parse). */
    internal fun fast(s: String): Instant? {
        val n = s.length
        if (n < 17 || s[4] != '-' || s[7] != '-' || s[10] != 'T' || s[13] != ':') return null
        val y1 = two(s, 0); val y2 = two(s, 2)
        if (y1 < 0 || y2 < 0) return null
        val year = y1 * 100 + y2
        if (year < 1900 || year > 2999) return null
        val month = two(s, 5); val day = two(s, 8); val hour = two(s, 11); val minute = two(s, 14)
        if (month !in 1..12 || day < 1 || day > monthLength(year, month) || hour !in 0..23 || minute !in 0..59) return null
        var i = 16
        var second = 0; var nano = 0
        if (i < n && s[i] == ':') {
            if (i + 3 > n) return null
            second = two(s, i + 1)
            if (second !in 0..59) return null
            i += 3
            if (i < n && s[i] == '.') {
                i++
                var digits = 0
                while (i < n && digit(s, i) >= 0) { if (digits == 9) return null; nano = nano * 10 + digit(s, i); digits++; i++ }
                if (digits == 0) return null
                repeat(9 - digits) { nano *= 10 }
            }
        }
        if (i >= n) return null
        val offsetSeconds: Int
        when (s[i]) {
            'Z' -> { if (i + 1 != n) return null; offsetSeconds = 0 }
            '+', '-' -> {
                if (i + 6 != n || s[i + 3] != ':') return null
                val oh = two(s, i + 1); val om = two(s, i + 4)
                if (oh !in 0..18 || om !in 0..59 || (oh == 18 && om != 0)) return null
                offsetSeconds = (oh * 3600 + om * 60) * (if (s[i] == '-') -1 else 1)
            }
            else -> return null
        }
        val local = epochDay(year, month, day) * 86_400L + hour * 3600L + minute * 60L + second
        return Instant.ofEpochSecond(local - offsetSeconds, nano.toLong())
    }
}

package jp.gmk.mobile.domain

import java.time.Instant

/**
 * v0.7.71: theoption's crypto rates (FXCM / LMAX) follow the large US exchanges. On the user's own theoption trades (3/5 minutes, entry
 * within 5 s of a minute), Coinbase BTC-USD x USD/JPY gave the same result 90.9% of the time (bitbank BTC/JPY: 67%), ETH/JPY 93.3%,
 * price level within 0.01% (research_v0771). Weekday 5-minute AUTO chooses among the five yen crosses and these four
 * (one year, scored on other periods: 53.31% vs 52.08% with the yen crosses only; 2023-24 52.55% vs 51.75%).
 *
 * Coinbase Exchange public REST (no key): /products/{BTC-USD|ETH-USD}/candles?granularity=60 and /products/{id}/ticker.
 * X/JPY = X/USD x USD/JPY at the same instant: open x USD/JPY open, close x USD/JPY close (carried over FX gaps and weekends).
 */
object CryptoPairs {
    val ALL = listOf("BTCJPY", "ETHJPY", "BTCUSD", "ETHUSD")
    val PRODUCTS = listOf("BTC-USD", "ETH-USD")
    private val DISPLAY = mapOf("BTCJPY" to "BTC/JPY", "ETHJPY" to "ETH/JPY", "BTCUSD" to "BTC/USD", "ETHUSD" to "ETH/USD")

    fun isCrypto(instrument: String): Boolean = instrument in ALL
    fun display(instrument: String): String = DISPLAY[instrument] ?: instrument
    fun product(instrument: String): String? = when (instrument) {
        "BTCJPY", "BTCUSD" -> "BTC-USD"
        "ETHJPY", "ETHUSD" -> "ETH-USD"
        else -> null
    }
    fun inYen(instrument: String): Boolean = isCrypto(instrument) && instrument.endsWith("JPY")

    private fun valid(o: Double, h: Double, l: Double, c: Double): Boolean =
        listOf(o, h, l, c).all { it.isFinite() && it > 0.0 } && h >= maxOf(o, c) && l <= minOf(o, c)

    private val ROW = Regex("""\[\s*([-0-9.eE+]+)\s*,\s*([-0-9.eE+]+)\s*,\s*([-0-9.eE+]+)\s*,\s*([-0-9.eE+]+)\s*,\s*([-0-9.eE+]+)\s*,\s*([-0-9.eE+]+)\s*]""")

    /** Coinbase candles: [[time s, low, high, open, close, volume], ...] (newest first) -> minute candles, oldest first, one per minute. */
    fun parseCandles(text: String): List<Candle> {
        val out = HashMap<Long, Candle>()
        for (m in ROW.findAll(text)) {
            val v = m.groupValues.drop(1).map { it.toDoubleOrNull() ?: Double.NaN }
            val t = v[0]; if (!t.isFinite() || t <= 0.0) continue
            val lo = v[1]; val hi = v[2]; val op = v[3]; val cl = v[4]; val vol = v[5]
            if (!valid(op, hi, lo, cl)) continue
            val ms = t.toLong() * 1000L
            if (ms % 60_000L != 0L) continue
            out[ms] = Candle(ms, op, hi, lo, cl, if (vol.isFinite() && vol >= 0.0) vol else 0.0)
        }
        return out.values.sortedBy { it.timeEpochMs }
    }

    private val PRICE = Regex(""""price"\s*:\s*"?([0-9.eE+-]+)"?""")
    private val TIME = Regex(""""time"\s*:\s*"([^"]+)"""")

    /** Coinbase ticker {"price":"...","time":"2026-11-05T10:15:30.123456Z",...} -> (price, epoch ms), or null. */
    fun parseTicker(text: String): Pair<Double, Long>? {
        val p = PRICE.find(text)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val t = TIME.find(text)?.groupValues?.get(1)?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() } ?: return null
        return if (p.isFinite() && p > 0.0 && t > 0L) p to t else null
    }

    // ---- backup source: Binance public market data (data-api.binance.vision, no key). BTC/USDT and ETH/USDT move with Coinbase
    // BTC-USD / ETH-USD: on the user's theoption trades the same result 92.1% (BTC) / 92.3% (ETH) as Coinbase, price level -0.09%
    // (USDT), so a pair's candles and live price always come from ONE source within a scan, and a result's judge price from the
    // same source as its entry price.

    /** Coinbase product -> Binance symbol. */
    fun binanceSymbol(product: String): String? = when (product) { "BTC-USD" -> "BTCUSDT"; "ETH-USD" -> "ETHUSDT"; else -> null }

    private val KLINE = Regex("""\[\s*([0-9]+)\s*,\s*"([-0-9.eE+]+)"\s*,\s*"([-0-9.eE+]+)"\s*,\s*"([-0-9.eE+]+)"\s*,\s*"([-0-9.eE+]+)"\s*,\s*"([-0-9.eE+]+)"""")

    /** Binance klines [[open time ms, "open", "high", "low", "close", "volume", close time, ...], ...] -> minute candles, oldest first. */
    fun parseBinanceKlines(text: String): List<Candle> {
        val out = HashMap<Long, Candle>()
        for (m in KLINE.findAll(text)) {
            val ms = m.groupValues[1].toLongOrNull() ?: continue
            if (ms <= 0L || ms % 60_000L != 0L) continue
            val v = m.groupValues.drop(2).map { it.toDoubleOrNull() ?: Double.NaN }
            val op = v[0]; val hi = v[1]; val lo = v[2]; val cl = v[3]; val vol = v[4]
            if (!valid(op, hi, lo, cl)) continue
            out[ms] = Candle(ms, op, hi, lo, cl, if (vol.isFinite() && vol >= 0.0) vol else 0.0)
        }
        return out.values.sortedBy { it.timeEpochMs }
    }

    private val TRADE_TIME = Regex(""""time"\s*:\s*([0-9]+)""")

    /** Binance newest trade [{"id":..,"price":"..","qty":"..","time":1730000000000,...}] -> (price, epoch ms), or null. */
    fun parseBinanceTrade(text: String): Pair<Double, Long>? {
        val p = PRICE.find(text)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
        val t = TRADE_TIME.find(text)?.groupValues?.get(1)?.toLongOrNull() ?: return null
        return if (p.isFinite() && p > 0.0 && t > 0L) p to t else null
    }

    /** "Coinbase" / "Binance" from a recorded rate source ("Coinbase 1m open", "Binance manual live", ...), else null. */
    fun sourceOf(recorded: String?): String? = when {
        recorded == null -> null
        recorded.startsWith("Coinbase") -> "Coinbase"
        recorded.startsWith("Binance") -> "Binance"
        else -> null
    }

    /**
     * X/JPY minute candles from X/USD and USD/JPY minute candles (exact port of scripts/v0771_syn.py): along the union of the two
     * minute grids, USD/JPY open = its open, else the previous minute's USD/JPY close, else carried; USD/JPY close carried forward.
     * open = X open x USD/JPY open, close = X close x USD/JPY close, high/low = X high/low x the middle of the two, kept around open/close.
     */
    fun toYen(coin: List<Candle>, usdjpy: List<Candle>): List<Candle> {
        val fxOpen = HashMap<Long, Double>(); val fxClose = HashMap<Long, Double>()
        for (c in usdjpy) if (c.open > 0.0 && c.close > 0.0 && c.open.isFinite() && c.close.isFinite()) { fxOpen[c.timeEpochMs] = c.open; fxClose[c.timeEpochMs] = c.close }
        val coinBy = coin.associateBy { it.timeEpochMs }
        val times = (coinBy.keys + fxOpen.keys).toSortedSet()
        var prevRawClose: Double? = null; var fo: Double? = null; var fc: Double? = null
        val out = ArrayList<Candle>(coin.size)
        for (t in times) {
            val oRaw = fxOpen[t]; val cRaw = fxClose[t]
            fo = oRaw ?: prevRawClose ?: fo
            fc = cRaw ?: fc
            prevRawClose = cRaw
            val x = coinBy[t] ?: continue
            val a = fo ?: continue; val b = fc ?: continue
            val o = x.open * a; val c = x.close * b; val mid = (a + b) / 2.0
            out.add(Candle(t, o, maxOf(maxOf(o, c), x.high * mid), minOf(minOf(o, c), x.low * mid), c, x.volume))
        }
        return out
    }

    /** USD/JPY may lag the crypto price by this much and still count as the same moment (it moves far less than BTC/ETH). */
    const val FX_LEG_MAX_LAG_MS = 60_000L

    /**
     * X/JPY live price = X/USD x USD/JPY. Its time is the crypto quote's time when USD/JPY is at most [FX_LEG_MAX_LAG_MS] older
     * (or FX is closed: weekends keep the last USD/JPY), otherwise the USD/JPY time (so a stale FX leg makes the price stale).
     */
    fun liveYen(coin: EvidencePolicy.LiveQuote, usdjpy: EvidencePolicy.LiveQuote?, fxOpen: Boolean): EvidencePolicy.LiveQuote? {
        val fx = usdjpy ?: return null
        if (!(fx.price.isFinite() && fx.price > 0.0 && coin.price.isFinite() && coin.price > 0.0)) return null
        val at = if (!fxOpen || coin.epochMs - fx.epochMs <= FX_LEG_MAX_LAG_MS) coin.epochMs else fx.epochMs
        return EvidencePolicy.LiveQuote(coin.price * fx.price, at)
    }
}

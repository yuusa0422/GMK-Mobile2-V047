package jp.gmk.mobile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import kotlinx.coroutines.delay
import java.time.ZonedDateTime

/**
 * v0.7.74 history screen (リプレイ帳): 3分 / 5分 result tiles of the current versions (1・10・15分 only with the old history),
 * 残機, the per-grade table (スペルカード取得履歴, newest version first, older versions folded), the live monitor, the grade filter
 * and the result cards. The 1-minute board and the v0.7.42-43 similarity-rank filter are gone (no new rows since v0.7.67).
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun HistoryScreen(rows: List<HistoryRow>, onOpenChart: (HistoryRow) -> Unit) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val hasPendingJudge = rows.any { it.resultStatus == "WAIT_JUDGE" }
    LaunchedEffect(hasPendingJudge) {
        if (hasPendingJudge) while (true) { nowMs = System.currentTimeMillis(); delay(1000) }
    }
    var includeLegacy by rememberSaveable { mutableStateOf(false) }
    var rankFilter by rememberSaveable { mutableStateOf("すべて") }
    val visibleRows = remember(rows, rankFilter) { rows.filter { RankFilter.matches(it, rankFilter) } }
    val keyedRows = remember(visibleRows) { HistoryListKeys.of(visibleRows) }
    val counted = remember(rows, includeLegacy) { rows.filter { ExpiryProfiles.includes(it, false, includeLegacy) } }
    val stats = remember(counted) { historyStatistics(counted) }
    // v0.7.78: the 残機 and losing streaks of the 5-minute / 3-minute trades; the 1-minute judgment apart (they were mixed into one run)
    val combined = remember(counted) { historyCombinedStatistics(counted.filter { !RankStatistics.isOneMinute(it) }) }
    val combinedM1 = remember(counted) { historyCombinedStatistics(counted.filter { OneMinutePolicy.isPolicy(it) }) }

    Box(Modifier.fillMaxSize().background(Gmk.Night)) {
        Image(painterResource(R.drawable.history_gensokyo_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.5f)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x55120A2A), Color(0xBB07142A), Color(0xEE071020)))))
        DanmakuBackdrop(Modifier.fillMaxSize(), alpha = 0.12f)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item(key = "summary") {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0xCC2A0D26), Color(0x6610162A))))
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("リプレイ帳", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("予測結果の記録 — 幻想の相場に、弾を放て", fontSize = 11.sp, color = Color(0xFFE6C8FF))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("博麗神社", color = Gmk.ShrineRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("GMK MOBILE", color = Gmk.Muted, fontSize = 10.sp)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        HistorySummaryTile(Modifier.weight(1f), "3分判定", "S・A・土日", summaryText(stats.getValue(3)), Gmk.Three)
                        HistorySummaryTile(Modifier.weight(1f), "5分判定", "B・C（平日）", summaryText(stats.getValue(5)), Gmk.Five)
                        // v0.7.75: the 1-minute judgment (crypto, every minute)
                        if (stats.getValue(1).let { s -> s.resolved() > 0 || s.pending > 0 })
                            HistorySummaryTile(Modifier.weight(1f), "1分判定", "仮想通貨・毎分", summaryText(stats.getValue(1)), Gmk.Cyan)
                    }
                    // the old engines' expiries appear only with the old history and only when they have results
                    val legacy = listOf(10, 15).filter { includeLegacy && stats.getValue(it).let { s -> s.resolved() > 0 || s.pending > 0 } }
                    if (legacy.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            legacy.forEach { m -> HistorySummaryTile(Modifier.weight(1f), "${m}分判定", "旧バージョン", summaryText(stats.getValue(m)), Gmk.Purple) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    val streak = combined.currentLossStreak
                    Text("残機 ${ShrineBoard.lives(streak)}  ${ShrineBoard.livesNote(streak)}", color = if (streak >= 3) Gmk.Lose else Gmk.Pink,
                        fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("最大${combined.maxConsecutiveLosses}連敗・3連敗以上 ${combined.runsAtLeast3}回・5連敗以上 ${combined.runsAtLeast5}回（見送り・判定待ち・取得失敗では連敗は途切れません）",
                        color = Gmk.Text, fontSize = 11.sp)
                    if (combinedM1.resolved() > 0) Text("1分判定: 今 ${combinedM1.currentLossStreak}連敗・最大${combinedM1.maxConsecutiveLosses}連敗・5連敗以上 ${combinedM1.runsAtLeast5}回",
                        color = Gmk.Text, fontSize = 11.sp)
                    // v0.7.77: the chance level of losing streaks at the 70% ENTRY
                    Text("連敗の目安（平日毎時70%・1年の検証）: 3連敗以上 1日5.5回・5連敗以上 1日1.1回・7連敗以上 4日に1回・10連敗以上 月に1回ほど。" +
                        "勝率53%で毎日約100回入ると偶然でもこのくらい起きます", color = Gmk.Muted, fontSize = 10.sp)
                    Text("見送り ${stats.values.sumOf { it.skips }}件・判定待ち ${stats.values.sumOf { it.pending }}件・取得失敗 ${stats.values.sumOf { it.missed }}件は勝率に入りません。同値は負け。",
                        color = Gmk.Muted, fontSize = 10.sp)
                    if (stats.getValue(0).resolved() > 0) Text("判定時刻不明 ${stats.getValue(0).resolved()}件は勝率に入りません。", color = Gmk.Muted, fontSize = 10.sp)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (includeLegacy) "集計: 旧バージョンも含む" else "集計: 更新後の記録", color = Gmk.Text, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { includeLegacy = !includeLegacy }) { Text(if (includeLegacy) "今の等級だけに戻す" else "旧履歴も含める", fontSize = 11.sp, color = Gmk.Cyan) }
                    }
                    Spacer(Modifier.height(6.dp))
                    RankStatsPanel(rows)
                    // v0.7.77: 称号
                    Spacer(Modifier.height(6.dp))
                    AchievementsPanel(rows)
                    Spacer(Modifier.height(8.dp))
                    Text("一覧を運用等級で絞り込み（上の集計は変わりません）", color = Gmk.Muted, fontSize = 10.sp)
                    RankFilterChips(rows, rankFilter) { rankFilter = it }
                }
            }
            // v0.7.77: today's report (文々。新聞 号外)
            item(key = "bunbunmaru") { BunbunmaruCard(rows) }
            if (rows.isEmpty()) {
                item(key = "empty") {
                    ShrinePanel(Modifier.padding(22.dp), accent = Gmk.Purple) {
                        Text("リプレイはまだありません", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                        Text("ENTRYと判定結果が、ここに記録されます。", color = Gmk.Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    }
                }
            } else if (visibleRows.isEmpty()) {
                item(key = "empty-filter") { Text("運用等級 $rankFilter の記録はありません", Modifier.padding(16.dp), color = Gmk.Muted, fontSize = 12.sp) }
            } else {
                // v0.7.79: each card keyed by its row, so the list stays where it is when a new row comes in at the top (every minute
                // with the 1-minute judgment it moved by one card while reading)
                items(keyedRows, key = { it.first }) { (_, h) -> HistoryCard(h, nowMs, onOpenChart) }
            }
        }
    }
}

private fun summaryText(s: OutcomeStatistics.Summary): String {
    val wr = s.winRate() ?: return if (s.pending > 0) "判定待ち ${s.pending}" else "確定なし"
    return "${s.wins}勝 ${s.losses}敗\n${"%.2f".format(wr)}%\n最大${s.maxConsecutiveLosses}連敗"
}

@Composable
private fun HistoryCard(h: HistoryRow, nowMs: Long, onOpenChart: (HistoryRow) -> Unit) {
    val isWin = h.decision == "ENTRY" && h.resultStatus == "WIN"
    val isLose = h.decision == "ENTRY" && h.resultStatus == "LOSE"
    val isWaiting = h.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
    val oneMinute = OneMinutePolicy.isPolicy(h)
    val evidence = RankStatistics.evidenceVersion(h.policyVersion) != null || oneMinute
    val minutes = expiryMinutes(h.entryTimeJst, h.judgeTimeJst, if (h.source.contains("1M")) 1 else 3)
    val statusColor = when {
        isWin -> Gmk.Win
        isLose -> Gmk.Lose
        isWaiting -> Gmk.Purple
        h.resultStatus.contains("MISSED") || h.resultStatus.contains("MISSING") || h.resultStatus.startsWith("INVALID") -> Gmk.Warn
        else -> Gmk.Muted
    }
    val directionColor = if (h.direction == "HIGH") Gmk.High else Gmk.Low
    val statusText = when {
        h.decision == "SKIP" -> if (h.resultStatus in setOf("WIN", "LOSE")) "見送り（入っていたら ${h.resultStatus}）" else if (isWaiting) "見送り（観察中）" else "見送り"
        isLose && h.entryRate != null && h.entryRate == h.judgeRate -> "被弾 LOSE（同値）"
        else -> when (h.resultStatus) {
            "WIN" -> "✿ 異変解決 WIN"
            "LOSE" -> "被弾 LOSE"
            "WAIT_ENTRY" -> "⌛ ENTRY待ち"
            "WAIT_JUDGE" -> if ((parseJstMs(h.judgeTimeJst) ?: Long.MAX_VALUE) <= nowMs) {
                if (h.source == "MANUAL") "⌛ 判定時刻到達・対象秒レート取得中" else "⌛ 判定時刻到達・対象分OPEN配信待ち"
            } else "⌛ ${minutes}分判定待ち"
            "ENTRY_RATE_MISSED" -> "⚠ ENTRY取得失敗"
            "JUDGE_RATE_MISSED" -> "⚠ 判定取得失敗"
            "ENTRY_RATE_MISSING" -> "⚠ ENTRY不明"
            "INVALID_RATE_DATA" -> "⚠ 保存レート異常・集計除外"
            "INVALID_TIMING_DATA" -> "⚠ 保存時刻異常・追跡除外"
            "LEGACY_NO_OUTCOME" -> "旧履歴・結果なし"
            else -> h.resultStatus
        }
    }
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            .border(1.dp, statusColor.copy(alpha = 0.72f), RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(listOf(if (isWin) Color(0xDD1C1A2E) else if (isLose) Color(0xDD2A1020) else Color(0xDD0B2140), Color(0xEE081329))), RoundedCornerShape(14.dp))
            .clickable { onOpenChart(h) }
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(36.dp).background(directionColor.copy(alpha = 0.18f), RoundedCornerShape(18.dp))
                        .border(1.dp, directionColor.copy(alpha = 0.75f), RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) { Text(if (h.direction == "HIGH") "↗" else "↘", color = directionColor, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(pairLabel(h.instrument), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, maxLines = 1, softWrap = false)
                        Spacer(Modifier.width(8.dp))
                        Text(h.direction, color = directionColor, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, softWrap = false,
                            modifier = Modifier.background(directionColor.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
                                .border(1.dp, directionColor.copy(alpha = 0.7f), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 2.dp))
                        if (evidence) { Spacer(Modifier.width(8.dp)); JudgeBadge(minutes) }
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(statusText, color = statusColor, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        modifier = Modifier.background(statusColor.copy(alpha = 0.10f), RoundedCornerShape(8.dp))
                            .border(1.dp, statusColor.copy(alpha = 0.72f), RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 5.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("運用等級 ${h.grade}${h.assessment?.subGrade?.let { subGradeSuffix(it) } ?: ""}  •  ${h.source}  •  ${h.regime}", fontSize = 12.sp, color = Gmk.Gold, fontWeight = FontWeight.Bold)
            // v0.7.76: C1 / C2 / C3 with the probability, the place in the hour and the validated rate
            h.assessment?.subGrade?.let { Spacer(Modifier.height(4.dp)); SubGradeStrip(it, compact = true); Spacer(Modifier.height(4.dp)) }
            if (evidence) {
                h.assessment?.correctionLabel?.let { Text(it, fontSize = 11.sp, color = Gmk.Cyan) }
                if (!oneMinute && ObservationPolicy.tracks(h)) Text("見送りの観察: 入っていたらの結果を記録（勝率・連敗には入りません）", fontSize = 10.sp, color = Gmk.Muted)
            } else {
                Text("旧バージョンの記録（${h.policyVersion}）", fontSize = 10.sp, color = Gmk.Muted)
                if (h.decision == "SKIP" && h.skipReasonLabel.isNotBlank()) Text("見送り: ${h.skipReasonLabel}", fontSize = 10.sp, color = Gmk.Muted)
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(statusColor.copy(alpha = 0.22f)))
            Spacer(Modifier.height(8.dp))
            Text("スキャン  ${formatJstTime(h.atJst)}", fontSize = 11.sp, color = Gmk.Muted)
            Text("ENTRY・市場参考  ${formatJstTime(h.entryTimeJst)}  ${h.entryRate?.let(::formatPrice) ?: "—"}", fontSize = 12.sp, color = Gmk.Text)
            Text("${minutes}分後・市場参考  ${formatJstTime(h.judgeTimeJst)}  ${h.judgeRate?.let(::formatPrice) ?: "—"}", fontSize = 12.sp, color = Gmk.Text)
            if (h.entryRateSource.isNotBlank() || h.judgeRateSource.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text("ENTRY: ${h.entryRateSource.ifBlank { "—" }} / 判定: ${h.judgeRateSource.ifBlank { "—" }}", fontSize = 9.sp, color = Gmk.Faint)
                Text("取得遅延 ENTRY=${h.entryCaptureDelayMs?.let { "${it}ms" } ?: "—"} / 判定=${h.judgeCaptureDelayMs?.let { "${it}ms" } ?: "—"}  " +
                    "${if (h.entryRateSource.endsWith(" 1m open")) "対象分OPENの配信待ち" else "provider age"} ENTRY=${h.entryProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"} / 判定=${h.judgeProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"}",
                    fontSize = 9.sp, color = Gmk.Faint)
            }
            if (isWin || isLose) {
                Spacer(Modifier.height(8.dp))
                Image(
                    painter = painterResource(if (isWin) R.drawable.history_reimu_win else R.drawable.history_youmu_lose),
                    contentDescription = null,
                    modifier = Modifier.align(Alignment.End).width(if (isWin) 112.dp else 140.dp).height(if (isWin) 112.dp else 100.dp)
                        .testTag("history-result-art-${h.id}"),
                    contentScale = ContentScale.Crop,
                    alpha = 0.85f
                )
            }
        }
    }
}

/** v0.7.50: results by operational grade (スペルカード取得履歴): the newest version's tables, older versions folded. */
@Composable
internal fun RankStatsPanel(rows: List<HistoryRow>) {
    val tables = remember(rows) { RankStatistics.tables(rows) }
    var showOld by rememberSaveable { mutableStateOf(false) }
    val newest = tables.firstOrNull()?.title?.substringBefore(' ')
    val shown = if (showOld) tables else tables.filter { it.title.substringBefore(' ') == newest || it.title.startsWith("1分判定") }
    ShrinePanel(accent = Gmk.Gold.copy(alpha = .55f)) {
        Text("スペルカード取得履歴（運用等級別）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (tables.isEmpty()) Text("まだ等級つきの記録がありません", color = Gmk.Muted, fontSize = 11.sp)
        shown.forEach { table ->
            Spacer(Modifier.height(5.dp))
            Text(table.title, color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            table.counts.forEach { count -> Text(RankStatistics.lineText(table, count), color = Gmk.Text, fontSize = 11.sp) }
        }
        if (tables.size > shown.size || showOld) {
            Text(if (showOld) "▲ 今のバージョンだけ表示" else "▼ 前のバージョン（${tables.size - shown.size}表）も表示", color = Gmk.Cyan, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().clickable { showOld = !showOld }.padding(vertical = 8.dp))
        }
        val share = remember(rows) { RankStatistics.entryShareText(rows) }
        if (share.isNotEmpty()) Text("ENTRYの割合（今のバージョン・自動・5分の区切りあたり）: $share", color = Gmk.Text, fontSize = 11.sp)
        // v0.7.73: the newest ENTRY trades against the 1-year check, and the losing streak
        val monitor = remember(rows) { RankStatistics.monitorText(RankStatistics.monitor(rows)) }
        Text(monitor, color = if (monitor.contains("要注意")) Color(0xFFFF8A80) else Gmk.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(RankStatistics.NOTE, color = Gmk.Muted, fontSize = 10.sp)
    }
}

/** Grade filter of the list; the 1-minute chip only while such old rows exist. */
@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun RankFilterChips(rows: List<HistoryRow>, selected: String, onSelect: (String) -> Unit) {
    val counts = remember(rows) { RankFilter.filters.associateWith { label -> rows.count { RankFilter.matches(it, label) } } }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        RankFilter.filters.filter { (it != "1分" && it !in SubGrades.LABELS) || counts.getValue(it) > 0 || selected == it }.forEach { label ->
            Box(Modifier.testTag("rank-filter-$label")) {
                ChoiceChip("$label (${counts.getValue(label)})", selected == label, Gmk.ShrineRed) { onSelect(label) }
            }
        }
    }
}

@Composable
private fun HistorySummaryTile(modifier: Modifier, title: String, sub: String, value: String, accent: Color) {
    Column(
        modifier.border(1.dp, accent.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.16f), Color(0xCC09142B))), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(sub, color = Gmk.Muted, fontSize = 10.sp)
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

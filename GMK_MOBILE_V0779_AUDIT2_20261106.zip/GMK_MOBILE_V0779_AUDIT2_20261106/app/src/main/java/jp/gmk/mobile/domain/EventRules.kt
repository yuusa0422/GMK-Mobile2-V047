package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign

/**
 * v0.7.53 time-of-day rules ("時間帯ルール"), port of scripts/ranks_v0753.py (README_V0753.txt).
 *
 * v0.7.51 research: every entry minute on the JST / London / New York clock x instrument x simple price rule (about 17,000
 * cells), selected on two of the three periods (2025-10..2026-01 / 2026-02..05 / 2026-06..10) and scored on the third;
 * four rules survived (9:55 fix, 12:20, 22:50, London 7:25). v0.7.53 round 1: a list of 14 market-event minutes written down
 * before looking (fixes, option cuts, scheduled data times) x the same 5 fade rules = 70 cells; pass = every period >= 55%.
 * Shuffled outcomes pass 0.35 cells on average; 4 new cells passed: US data 8:30 New York (two rules), UK data 9:30 London
 * and a second 9:55 fix rule. Round 2 (20 more minutes, 100 cells) found nothing beyond chance and is not used.
 *
 * Grade: S when at least 3 of the 4 other fade signals point the same way as the rule's own value (an over-extended move on
 * every horizon at a liquidity time), otherwise A. The threshold 3 was chosen on two periods in every rotation; held out
 * S won 70.4 / 72.3 / 63.4%, A 62.6 / 59.4 / 58.2%.
 *   S  68.2% (239 trades, 1.0/day; Octobers 76.9% of 26)      A  60.1% (606 trades, 2.5/day; Octobers 59.5% of 79)
 * Expect both nearer the low end: the confluence split and the round-1 cells were chosen on the same year.
 *
 * Inputs (identical to the research rows): the 61-candle window of [EvidenceFeatures.window] and the instrument's own live
 * quote taken within 40 s before entry; r5 / r15 / f1 / bbzLive are [EvidenceFeatures.Instrument] values, pos60L places the live
 * price in the 61-minute high/low range extended by the live price (-1 = low end, +1 = high end). Direction = against the value.
 * Only exact 5-minute AUTO boundaries on weekdays qualify (the research entry time).
 */
object EventRules {
    enum class Clock(val zone: ZoneId) { JST(ZoneId.of("Asia/Tokyo")), LONDON(ZoneId.of("Europe/London")), NEW_YORK(ZoneId.of("America/New_York")) }
    /** The five fade signals and their thresholds (pos60L 0.8 of the range, 20-minute Bollinger 1.5 sigma, moves 1 sigma). */
    enum class Feature(val threshold: Double) { POS60L(0.8), BBZL(1.5), R5(1.0), R15(1.0), F1(1.0) }

    data class Rule(
        val id: String, val clock: Clock, val minuteOfDay: Int, val feature: Feature, val usdFirst: Boolean, val label: String,
        val rate: Double, val trades: Int, val octoberRate: Double, val octoberTrades: Int
    ) { val threshold: Double get() = feature.threshold }

    /** Priority order: at the same minute the first rule with a qualifying instrument decides. */
    val RULES = listOf(
        Rule("FIX955_POS", Clock.JST, 9 * 60 + 55, Feature.POS60L, true, "仲値(9:55)・60分の高値/安値の端からの戻り", 0.6774, 124, 0.6154, 13),
        Rule("FIX955_BBZ", Clock.JST, 9 * 60 + 55, Feature.BBZL, true, "仲値(9:55)・20分平均から1.5σ以上離れた動きの戻り", 0.6078, 51, 0.4444, 9),
        Rule("JST1220_POS", Clock.JST, 12 * 60 + 20, Feature.POS60L, false, "昼(12:20)・60分の高値/安値の端からの戻り", 0.5922, 103, 0.6667, 9),
        Rule("JST2250_R15", Clock.JST, 22 * 60 + 50, Feature.R15, false, "NY午前(22:50)・15分の大きな動きの戻り", 0.6538, 130, 0.7895, 19),
        Rule("LON0725_R5", Clock.LONDON, 7 * 60 + 25, Feature.R5, false, "欧州勢の参入前(ロンドン7:25)・5分の大きな動きの戻り", 0.5912, 137, 0.5882, 17),
        Rule("US0830_BBZ", Clock.NEW_YORK, 8 * 60 + 30, Feature.BBZL, false, "米指標の発表時刻(NY8:30)・20分平均から1.5σ以上離れた動きの戻り", 0.6467, 150, 0.5714, 21),
        Rule("US0830_F1", Clock.NEW_YORK, 8 * 60 + 30, Feature.F1, false, "米指標の発表時刻(NY8:30)・直前1分の動きの戻り", 0.5806, 31, 1.0, 3),
        Rule("UK0930_F1", Clock.LONDON, 9 * 60 + 30, Feature.F1, false, "英指標の発表時刻(ロンドン9:30)・直前1分の動きの戻り", 0.5882, 119, 0.6429, 14),
    )
    val FX_ORDER = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY")
    /** S when at least this many of the 4 other fade signals agree with the rule value. */
    const val S_CONFLUENCE = 3

    data class Match(val rule: Rule, val instrument: String, val direction: String, val value: Double, val confluence: Int) {
        val grade: String get() = if (confluence >= S_CONFLUENCE) "S" else "A"
    }

    /**
     * v0.7.58: the rules that also held on 2023-01..2024-02 (data they were never fitted on): 9:55 fix POS 62.9% (151),
     * 9:55 fix BBZ 58.9% (56), NY 8:30 F1 62.5% (32). The other five fell to 38.8-52.3% there (all eight 51.5%, 1020 trades),
     * so they are no longer used; those minutes are judged by the 5-minute model like any other minute.
     */
    val ACTIVE_IDS = setOf("FIX955_POS", "FIX955_BBZ", "US0830_F1")
    /** Every rule of [RULES] (the research tests check the mechanics of the retired ones too). */
    val ALL_IDS: Set<String> get() = RULES.map { it.id }.toSet()

    /** Rules whose clock time equals this entry; empty unless a weekday exact 5-minute boundary inside the session. */
    fun rulesAt(entry: ZonedDateTime, active: Set<String> = ACTIVE_IDS): List<Rule> {
        if (entry.second != 0 || entry.nano != 0 || entry.minute % 5 != 0) return emptyList()
        if (!TradingSession.fxOpen(entry)) return emptyList()
        val noFixing = JapanHolidays.isBankHoliday(entry)       // v0.7.63: no Tokyo fixing on Japanese bank holidays
        return RULES.filter { r ->
            if (r.id !in active) return@filter false
            if (noFixing && r.id.startsWith("FIX955")) return@filter false
            val t = entry.withZoneSameInstant(r.clock.zone)
            t.hour * 60 + t.minute == r.minuteOfDay
        }
    }

    /** Live price inside the 61-minute range extended by itself: -1 low end .. +1 high end (scripts/app_sim.py pattern_raw). */
    fun pos60L(window: List<Candle>, live: Double): Double {
        var hi60 = window[0].high; var lo60 = window[0].low
        for (c in window) { hi60 = max(hi60, c.high); lo60 = min(lo60, c.low) }
        val hiL = max(hi60, live); val loL = min(lo60, live)
        return (live - loL) / max(hiL - loL, 1e-12) * 2 - 1
    }

    fun value(feature: Feature, x: EvidenceFeatures.Instrument, window: List<Candle>, live: Double): Double = when (feature) {
        Feature.POS60L -> pos60L(window, live)
        Feature.BBZL -> x.bbzLive
        Feature.R5 -> x.r5
        Feature.R15 -> x.r15
        Feature.F1 -> x.f1
    }

    fun value(rule: Rule, x: EvidenceFeatures.Instrument, window: List<Candle>, live: Double): Double = value(rule.feature, x, window, live)

    /** How many of the other fade signals are past their threshold on the same side as [v] (0..4). */
    fun confluence(rule: Rule, x: EvidenceFeatures.Instrument, window: List<Candle>, live: Double, v: Double): Int =
        Feature.values().count { f ->
            if (f == rule.feature) return@count false
            val o = value(f, x, window, live)
            o.isFinite() && abs(o) >= f.threshold && sign(o) == sign(v)
        }

    private fun tieKey(v: Double): Double = Math.rint(abs(v) * 1e12) / 1e12

    /**
     * The rule trade for this entry, or null. [live] = each instrument's own live quote (null when missing or stale);
     * an instrument without a live quote or without a full 61-minute window is not considered (as in the research rows).
     */
    fun match(entry: ZonedDateTime, candles: Map<String, List<Candle>>, live: Map<String, Double?>, active: Set<String> = ACTIVE_IDS): Match? {
        val b = entry.toEpochSecond()
        for (rule in rulesAt(entry, active)) {
            var best: Match? = null; var bestKey: Triple<Int, Double, Int>? = null
            for ((order, inst) in FX_ORDER.withIndex()) {
                val px = live[inst] ?: continue
                if (!(px.isFinite() && px > 0.0)) continue
                val bars = candles[inst] ?: continue
                val w = EvidenceFeatures.window(bars, b) ?: continue
                val x = EvidenceFeatures.instrument(inst, bars, b, px) ?: continue
                val v = value(rule, x, w, px)
                if (!v.isFinite() || abs(v) < rule.threshold) continue
                // usdFirst: USDJPY before any other; then the larger |value|; then the fixed instrument order.
                val key = Triple(if (rule.usdFirst && inst == "USDJPY") 0 else 1, -tieKey(v), order)
                if (bestKey == null || compareValuesBy(key, bestKey, { it.first }, { it.second }, { it.third }) < 0) {
                    bestKey = key; best = Match(rule, inst, if (v > 0) "LOW" else "HIGH", v, confluence(rule, x, w, px, v))
                }
            }
            if (best != null) return best
        }
        return null
    }
}

/**
 * v0.7.51 October calendar: entries in these windows are not taken (precaution around scheduled central-bank
 * announcements; there is no win-rate evidence for or against these single events). Times are JST.
 *  - ECB rate decision 29 Oct 2026 14:15 CET (= 22:15 JST after the 25 Oct clock change), press conference 14:45 CET.
 *  - Bank of Japan meeting 29-30 Oct 2026: the decision time is not fixed (usually around noon); the Governor's press
 *    conference is normally at 15:30 JST.
 *  - FOMC 27-28 Oct 2026: statement 2:00 pm EDT = 03:00 JST 29 Oct, outside the session (no window needed).
 */
object MarketCalendar {
    data class Window(val start: ZonedDateTime, val end: ZonedDateTime, val label: String)
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    private fun at(d: Int, h: Int, m: Int): ZonedDateTime = ZonedDateTime.of(2026, 10, d, h, m, 0, 0, JST)
    val WINDOWS = listOf(
        Window(at(29, 22, 10), at(29, 23, 0), "ECBの政策金利発表(22:15)と会見(22:45)"),
        Window(at(30, 11, 30), at(30, 13, 30), "日銀の政策決定の発表（昼ごろ・時刻は当日まで未定）"),
        Window(at(30, 15, 25), at(30, 16, 30), "日銀総裁の会見(15:30)"),
    )
    /** The window this entry falls in ([start, end)), or null. */
    fun caution(entry: ZonedDateTime): Window? =
        WINDOWS.firstOrNull { !entry.isBefore(it.start) && entry.isBefore(it.end) }
}

/**
 * v0.7.56 rank table (README_V0756.txt). The grades are the same in every [EntryMode]; the mode decides whether C is ENTRY.
 * Weekday: S/A = time-of-day rules (S = rule + confluence, see [EventRules]); B = a strong model trade (v0.7.48 S/A) that a
 * confirming last-minute move agrees with (FX: the trade fades a 1-minute spike of 2.5 sigma or more; BTC: the trade follows a
 * 1..3 sigma 1-minute move). C = the former C (v0.7.48 S/A/B/C at 10-22h without the confirming move) whose rank strength r is
 * at least [weekdayCut] - 71% of the former C, so that S+A+B+C = 60% of weekday slots: 52.8% (52.3 / 53.3 / 52.8).
 * D = the rest of the former C (50.8%), E = v0.7.48 D (50.5%), F = v0.7.48 E and the 09h former C (48.8%).
 * Weekend (BTC): B = the strongest model tier (v0.7.48 S) when it does not chase the hour (pos60 x direction <= 0): 57.1%.
 * C = every other slot whose strength e is at least [weekendCut] (top 60% of weekend slots): 47.9% (draws 14.1%).
 * D = the rest of v0.7.48 D (41.7%), E = v0.7.48 E (41.0%), F..H unchanged.
 * Rates: one year, out of sample (strength fitted on the other half). The cuts are the same quantiles on the production
 * strength models (strength_production.json), which pick the same C as the out-of-sample strengths for 88.6% (weekday) and
 * 97.1% (weekend) of the slots.
 */
object RankLadder {
    data class Rate(val year: Double, val october: Double?, val octoberTrades: Int?)
    /**
     * v0.7.58 weekday (README_V0758.txt): FX only, every minute, every clock hour >= 70% ENTRY. S/A = the 3 kept time-of-day rules
     * (3 minutes); B = strong + confirmed 3-minute-model trade at a 5-minute boundary (5 minutes); C = the every-minute 5-minute model
     * at or above the hour's moving cut (5 minutes); D = boundary minutes not entered. One year, scored on other periods
     * (research_v0759/v0759_rates.py, with the v0.7.59 same-direction penalty): S 80.0% / A 58.9% / B 57.6% / C 53.2% / D 51.2%;
     * all 53.50% at 103/day (75% of slots, periods 53.4 / 54.3 / 52.8); 2023-24 with the production tables 52.7%. S+A+B 58.7% at 5.2/day.
     */
    private val FRESH_WEEKDAY = mapOf(
        "S" to Rate(0.8000, 1.0, 2), "A" to Rate(0.5894, 0.5556, 9), "B" to Rate(0.5756, 0.5000, 40),
        "C" to Rate(0.5309, 0.5329, 1321), "D" to Rate(0.5089, 0.4814, 457))      // v0.7.71: nine pairs (research_v0771, pace 0.8)
    // v0.7.71: weekend B/C/D = the four-crypto weekend model (top 8% / top 60% / rest, 3 minutes, research_v0771); E..H = the bitbank backup
    private val FRESH_WEEKEND = mapOf(
        "B" to Rate(0.6121, 0.6140, 114), "C" to Rate(0.5489, 0.5407, 738), "D" to Rate(0.5148, 0.4758, 660), "E" to Rate(0.4096, 0.4000, 300),
        "F" to Rate(0.3460, 0.3496, 226), "G" to Rate(0.3057, 0.2857, 182), "H" to Rate(0.2598, 0.2066, 213))
    private val FALLBACK_WEEKDAY = mapOf(
        "S" to Rate(0.8000, 1.0, 2), "A" to Rate(0.5894, 0.5556, 9),          // B needs the live price (no backup B)
        "C" to Rate(0.5196, 0.5113, 1322), "D" to Rate(0.5112, 0.5482, 456))      // v0.7.71: nine pairs (research_v0771, pace 0.8)

    /** v0.7.57: judgement length of a weekday grade (time-of-day rules 3 minutes, everything else 5); weekend always 3. */
    fun judgeMinutes(weekend: Boolean, grade: String): Int = if (weekend || grade in setOf("S", "A", "I")) 3 else 5

    /**
     * v0.7.59: score penalty per open trade in the same direction when the 5-minute model picks a weekday trade (all five pairs are
     * yen crosses, so stacked same-direction trades lose together). Research_v0759: losing streaks >= 10 per year 57 -> 32,
     * longest 19 -> 16, win 53.72% -> 53.50% (2023-24: 59 -> 37 streaks, 52.90% -> 52.70%).
     */
    const val SAME_DIRECTION_PENALTY = 0.03

    /** v0.7.58: weekday ENTRY share required in every clock hour (12 five-minute slots -> at least 9 entries). */
    const val HOUR_SHARE = 0.7
    /** v0.7.71: share of the remaining need asked of each slot (research_v0770: 0.8 raised every period and 2023-24 by about 0.1 point). */
    const val PACE = 0.8
    fun hourQuota(slots: Int = 12): Int = kotlin.math.ceil(HOUR_SHARE * slots - 1e-9).toInt()

    /** The probability with [frac] of the year's 5-minute slots of hour [hourJst] at or above it (linear on the quantile grid). */
    fun quantileCut(fresh: Boolean, hourJst: Int, frac: Double): Double {
        val q = (if (fresh) EvidenceSlot9Data.FRESH_QUANTILES else EvidenceSlot9Data.FALLBACK_QUANTILES)[(hourJst - 9).coerceIn(0, 13)]
        val x = (1.0 - frac.coerceIn(0.0, 1.0)) * (q.size - 1); val i = kotlin.math.floor(x).toInt().coerceIn(0, q.size - 1)
        if (i >= q.size - 1) return q[q.size - 1]
        return q[i] + (x - i) * (q[i + 1] - q[i])
    }
    fun baseShare(fresh: Boolean, hourJst: Int): Double =
        (if (fresh) EvidenceSlot9Data.FRESH_BASE else EvidenceSlot9Data.FALLBACK_BASE)[(hourJst - 9).coerceIn(0, 13)]

    /** [need] entries still needed this hour, [left] 5-minute slots left (this one included); catch-up = enter regardless; full = quota met. */
    data class MinuteCut(val cut: Double, val need: Int, val left: Int, val catchUp: Boolean, val full: Boolean)

    /**
     * v0.7.58 C rule of a weekday minute (research_v0758/v0758_production.py): need = ceil(0.7 x the hour's slots) - entries so far
     * this clock hour (12 slots -> 9; v0.7.61: the slots the app runs, as the research counts the slots with data),
     * left = the 5-minute slots left in the hour (v0.7.66; it was 60 - minute while the AUTO ran every weekday minute).
     * need >= left -> enter (catch-up); need > 0 -> enter at or above the hour's quantile cut for max(need / left, BASE / 2)
     * of the 5-minute slots (tables EvidenceSlot5Data); need <= 0 -> no more C this hour (S/A/B still enter).
     */
    fun minuteCut(fresh: Boolean, hourJst: Int, minuteOfHour: Int, hourEntries: Int, hourSlots: Int = 12, lossStreak: Int = 0): MinuteCut {
        // v0.7.61: the quota is 70% of this hour's 5-minute slots the app runs (the research: the slots with data in that hour),
        // so an hour joined late or with failed scans is not squeezed into nine entries
        val need = hourQuota(hourSlots.coerceIn(0, 12)) - hourEntries; val left = ((60 - minuteOfHour + 4) / 5).coerceIn(1, 12)
        if (need >= left) return MinuteCut(Double.NEGATIVE_INFINITY, need, left, catchUp = true, full = false)
        if (need <= 0) return MinuteCut(Double.POSITIVE_INFINITY, need, left, catchUp = false, full = true)
        // v0.7.71: early in the hour wait a little longer for a strong trade (PACE 0.8; the hour still reaches 70% by catching up)
        val frac0 = maxOf(PACE * need.toDouble() / left, baseShare(fresh, hourJst) / 2.0)
        // v0.7.77 連敗結界: on a losing streak of StreakGuard.K or more, ask this slot for a stronger trade (the catch-up above is unchanged)
        val frac = if (StreakGuard.active(lossStreak)) frac0 * StreakGuard.PICKY else frac0
        return MinuteCut(quantileCut(fresh, hourJst, frac), need, left, catchUp = false, full = false)
    }
    private val FALLBACK_WEEKEND = mapOf(
        "B" to Rate(0.5657, 0.6327, 98), "C" to Rate(0.5336, 0.5282, 746), "D" to Rate(0.5152, 0.5120, 668), "E" to Rate(0.3963, null, null),
        "F" to Rate(0.3518, null, null), "G" to Rate(0.3296, null, null), "H" to Rate(0.2635, null, null))
    /** Grades entered in every mode (C depends on [EntryMode]). */
    val ENTRY_GRADES = EntryMode.ENTRY_BASE
    private val MODEL_ENTRY = setOf("S", "A", "B", "C")

    /** Production rank strength r (weekday) / strength e (weekend) at or above which a model trade is C. */
    const val FRESH_WEEKDAY_C_CUT = 0.5126473828714029
    const val FALLBACK_WEEKDAY_C_CUT = 0.500316186307408
    const val FRESH_WEEKEND_C_CUT = 0.4122092384871319
    const val FALLBACK_WEEKEND_C_CUT = 0.4087182577634557
    fun weekdayCut(fresh: Boolean): Double = if (fresh) FRESH_WEEKDAY_C_CUT else FALLBACK_WEEKDAY_C_CUT
    fun weekendCut(fresh: Boolean): Double = if (fresh) FRESH_WEEKEND_C_CUT else FALLBACK_WEEKEND_C_CUT

    fun rate(fresh: Boolean, weekend: Boolean, grade: String): Rate? = when {
        fresh && !weekend -> FRESH_WEEKDAY
        fresh -> FRESH_WEEKEND
        !weekend -> FALLBACK_WEEKDAY
        else -> FALLBACK_WEEKEND
    }[grade]

    const val FX_SPIKE_SIGMA = 2.5
    const val BTC_FOLLOW_LOW = 1.0
    const val BTC_FOLLOW_HIGH = 3.0

    /**
     * The last-minute move confirms the trade: FX fades a spike of [FX_SPIKE_SIGMA] sigma or more (f1 x direction <= -2.5),
     * BTC follows a move of 1..3 sigma (1 <= f1 x direction < 3). [f1] = live price vs the last closed minute, in 60-minute sigmas.
     */
    fun confirms(instrument: String, direction: Int, f1: Double): Boolean {
        val rel = f1 * direction
        return if (instrument == "BTCJPY") rel >= BTC_FOLLOW_LOW && rel < BTC_FOLLOW_HIGH else rel <= -FX_SPIKE_SIGMA
    }

    /**
     * v0.7.48 strength grade of the model trade -> v0.7.56 grade. [confirmed] matters for weekday S/A, [hourJst] for weekday
     * 09h, [againstHour] (pos60 x direction <= 0) for the weekend S tier, [rank] (weekday r) / [strength] (weekend e) for C.
     * Weekday: S/A confirmed -> B; other S/A and B/C -> C when rank >= the cut else D (09h -> F); D -> E; E -> F.
     * Weekend: S against the hour -> B; anything else with strength >= the cut -> C; S/A/B/C/D below the cut -> D; E -> E;
     * F..H unchanged. NaN rank/strength never reaches C.
     */
    fun modelGrade(v0748: String, weekend: Boolean, confirmed: Boolean = false, hourJst: Int = -1, againstHour: Boolean = false,
                   rank: Double = Double.NaN, strength: Double = Double.NaN, fresh: Boolean = true): String =
        if (weekend) when {
            v0748 == "S" && againstHour -> "B"
            v0748 in MODEL_ENTRY || v0748 == "D" -> if (strength >= weekendCut(fresh)) "C" else "D"
            v0748 == "E" -> if (strength >= weekendCut(fresh)) "C" else "E"
            else -> v0748
        } else when (v0748) {
            "S", "A" -> if (confirmed) "B" else if (hourJst == PRE_FIX_HOUR) "F" else if (rank >= weekdayCut(fresh)) "C" else "D"
            "B", "C" -> if (hourJst == PRE_FIX_HOUR) "F" else if (rank >= weekdayCut(fresh)) "C" else "D"
            "D" -> "E"
            "E" -> "F"
            else -> v0748
        }

    const val PRE_FIX_HOUR = 9

    /** The weekend S tier enters only when it does not chase the hour: buy in the lower half / sell in the upper half. */
    fun againstHour(pos60: Double?, direction: Int): Boolean = pos60 != null && pos60.isFinite() && pos60 * direction <= 0.0

    /**
     * Why a model trade is skipped although the v0.7.48 strength would have entered it, or it is C under a mode that does not
     * enter C (null = it enters, or the plain strength reason applies). [grade] = [modelGrade] of the trade.
     */
    fun demotion(v0748: String, weekend: Boolean, confirmed: Boolean, hourJst: Int, againstHour: Boolean = false,
                 grade: String = modelGrade(v0748, weekend, confirmed, hourJst, againstHour), mode: EntryMode = EntryMode.FIFTY_FIVE): String? {
        if (v0748 !in MODEL_ENTRY && grade != "C") return null
        return when {
            mode.enters(grade, weekend) -> null
            grade == "C" && weekend -> (if (v0748 == "S") "強い取引でも60分の値幅の上側で買う／下側で売る（追いかける）形。" else "") +
                "土日のC（1年47.9%・引き分け14%）。土日をENTRY 60%にすると49.1%になるため、設定「${mode.label}」では土日は55%以上のBだけ"
            grade == "C" -> "平日のC（1年52.8%・55%未満）。設定「${mode.label}」では55%以上が確認できたS/A/Bだけ入る"
            weekend && v0748 == "S" -> "土日の強い取引でも、60分の値幅の上側で買う／下側で売る（追いかける）形は1年49.3%。値幅の逆側から入る時だけENTRY"
            weekend -> "土日の普通の強さの取引は1年48.3%（引き分けが多い）。土日は強い取引を値幅の逆側から入る時だけENTRY"
            hourJst == PRE_FIX_HOUR -> "9時台（仲値の前）の取引は1年48.8%（3期間とも50%未満）。値動きに規則性が無い時間"
            else -> "旧Cのうち強さが下位（1年50.8%）。ENTRY 60%に入らない下位40%の側"
        }
    }
}

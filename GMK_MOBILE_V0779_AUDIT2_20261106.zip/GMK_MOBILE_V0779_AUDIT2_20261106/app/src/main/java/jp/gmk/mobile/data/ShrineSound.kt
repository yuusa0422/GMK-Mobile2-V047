package jp.gmk.mobile.data

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * v0.7.77 効果音 (setting, OFF by default): short sounds synthesised on the device (no sound files): スペルカード宣言 when a new
 * 5-minute ENTRY is declared, a bright chime for WIN and the falling「ピチューン」for LOSE. Played on the game stream; any audio failure
 * is ignored (the app works the same without sound).
 */
object ShrineSound {
    enum class Kind { ENTRY, WIN, LOSE }
    const val RATE = 22050

    /** 16-bit mono PCM of [kind] (pure; also used by the tests). */
    fun samples(kind: Kind): ShortArray = when (kind) {
        // rising sweep 600 -> 1600 Hz, 0.22 s
        Kind.ENTRY -> sweep(600.0, 1600.0, 0.22, 0.45)
        // C6 - E6 - G6 - C7 arpeggio
        Kind.WIN -> concat(listOf(1046.5, 1318.5, 1568.0, 2093.0).map { tone(it, 0.075, 0.40) })
        // ピチューン: falling sweep 1800 -> 220 Hz with a fast decay, 0.40 s
        Kind.LOSE -> sweep(1800.0, 220.0, 0.40, 0.55)
    }

    private fun tone(freq: Double, seconds: Double, gain: Double): ShortArray {
        val n = (RATE * seconds).toInt()
        return ShortArray(n) { i ->
            val t = i.toDouble() / RATE; val env = exp(-6.0 * t / seconds) * minOf(1.0, i / 60.0)
            (sin(2 * PI * freq * t) * env * gain * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun sweep(f0: Double, f1: Double, seconds: Double, gain: Double): ShortArray {
        val n = (RATE * seconds).toInt(); var phase = 0.0
        return ShortArray(n) { i ->
            val x = i.toDouble() / n; val f = f0 * Math.pow(f1 / f0, x)
            phase += 2 * PI * f / RATE
            val env = exp(-3.0 * x) * minOf(1.0, i / 60.0) * minOf(1.0, (n - i) / 120.0)
            (sin(phase) * env * gain * Short.MAX_VALUE).toInt().toShort()
        }
    }

    private fun concat(parts: List<ShortArray>): ShortArray {
        val out = ShortArray(parts.sumOf { it.size }); var k = 0
        for (p in parts) { p.copyInto(out, k); k += p.size }
        return out
    }

    fun play(kind: Kind) {
        Thread {
            runCatching {
                val pcm = samples(kind)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(pcm.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                try {
                    track.write(pcm, 0, pcm.size)
                    track.play()
                    Thread.sleep(pcm.size * 1000L / RATE + 150L)
                } finally { runCatching { track.stop() }; track.release() }
            }
        }.apply { isDaemon = true; name = "gmk-sound" }.start()
    }

    /** v0.7.78: false in マナーモード / silent (the ringer is not normal): the sounds respect the phone's sound mode. */
    fun audible(context: Context): Boolean = runCatching {
        (context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager)?.ringerMode == AudioManager.RINGER_MODE_NORMAL
    }.getOrDefault(false)

    /** The cut-in type name (CutInEventQueue.Kind) -> its sound; the mid-trade 優勢 cut-ins stay silent. */
    fun forCutIn(type: String): Kind? = when (type) {
        "WIN_FINAL" -> Kind.WIN
        "LOSE_FINAL" -> Kind.LOSE
        else -> null
    }
}

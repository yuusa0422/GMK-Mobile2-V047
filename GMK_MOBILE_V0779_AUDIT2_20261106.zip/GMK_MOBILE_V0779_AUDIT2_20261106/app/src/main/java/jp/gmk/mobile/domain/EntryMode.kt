package jp.gmk.mobile.domain

/**
 * v0.7.58: weekday C is entered on every minute so that every clock hour reaches 70% (README_V0758.txt); the keys stay for saved settings.
 * v0.7.57: weekday numbers are the FX-only 3/5-minute policy (README_V0757.txt); C on weekdays = the 5-minute model above the hour's cut.
 * v0.7.56: how many slots the 3-minute policy enters (README_V0756.txt). The grades are the same in every mode; only whether C
 * is ENTRY changes. C = the 60% tier: weekday former C whose rank strength is in the top part (S+A+B+C = 60% of weekday slots),
 * weekend every slot whose strength is in the top 60% (minus B).
 * One year, scored on other periods (research_v0756/ladder_v0756.py):
 *   FIFTY_FIVE  weekday S/A/B  9.9% of slots, 13.6/day, 57.6%   weekend B  7.8%, 13.1/day, 57.1%
 *   WEEKDAY_60  weekday S/A/B/C 60%, 82.5/day, 53.6%            weekend B (as FIFTY_FIVE)
 *   ALL_60      weekday as WEEKDAY_60                          weekend B/C 60%, 100.8/day, 49.1% (draws 12.8%)
 * No ordering of the year reaches 55% at 60% of slots (weekday 55% holds up to about 20%, weekend up to about 10%).
 */
enum class EntryMode(val key: String, val label: String, val weekdayC: Boolean, val weekendC: Boolean, val summary: String) {
    FIFTY_FIVE("55", "55%優先", false, false, "平日 約3%（1日5回・58.7%・為替のみ）／土日 約8%（14回・61.2%・仮想通貨4つ）"),
    WEEKDAY_60("60W", "平日70%", true, false, "平日 5分ごと・どの1時間も70%以上（1日103回・53.4%・円5ペア＋仮想通貨4つ）／土日 約8%（14回・61.2%・仮想通貨4つ）"),
    ALL_60("60", "毎日（土日60%）", true, true, "平日 どの1時間も70%以上（1日103回・53.4%）／土日 60%（101回・55.7%）");

    /** Grades this mode enters (time-of-day rules S/A are always entered unless a caution window applies). */
    fun entryGrades(weekend: Boolean): Set<String> =
        if (if (weekend) weekendC else weekdayC) ENTRY_WITH_C else ENTRY_BASE

    fun enters(grade: String, weekend: Boolean): Boolean = grade in entryGrades(weekend)

    companion object {
        val ENTRY_BASE = setOf("S", "A", "B")
        val ENTRY_WITH_C = setOf("S", "A", "B", "C")
        /** The user asked for ENTRY on at least 60% of slots; weekends at 60% are 49.1%, so weekends stay at B by default. */
        val DEFAULT = WEEKDAY_60
        fun parse(key: String?): EntryMode = values().firstOrNull { it.key == key } ?: DEFAULT
    }
}

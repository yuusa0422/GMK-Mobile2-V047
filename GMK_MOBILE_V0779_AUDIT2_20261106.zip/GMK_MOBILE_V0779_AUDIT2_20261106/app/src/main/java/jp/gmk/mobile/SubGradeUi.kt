package jp.gmk.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.SubGrade
import jp.gmk.mobile.domain.SubGrades
import java.util.Locale

/*
 * v0.7.76: the strength inside grade C on screen - C1 / C2 / C3 with the model's probability of winning, the place in the hour
 * (霊力ゲージ: 100% = the strongest slot of that hour) and the validated win rate of the sub-grade. Display only.
 */

/** v0.7.78: "（C1）", or "（C1から昇格）" for a promoted C1 (was "B（B↑C1）"). */
internal fun subGradeSuffix(sub: SubGrade): String = if (sub.promoted) "（${sub.label}から昇格）" else "（${sub.label}）"

internal fun subColor(sub: SubGrade): Color = when {
    sub.promoted -> Gmk.Gold
    sub.label == "C1" -> Gmk.Pink
    sub.label == "C2" -> Gmk.Cyan
    else -> Gmk.Muted
}

private fun pc(x: Double) = String.format(Locale.US, "%.1f%%", x * 100.0)

internal fun topLabel(top: Double): String {
    val t = top * 100.0
    return if (t < 1.0) "上位1%以内" else "上位${String.format(Locale.US, "%.0f", kotlin.math.ceil(t - 1e-6))}%"
}

/** "C1 上位10%まで・C2 30%まで・C3 それより下" for [segment]. */
internal fun bandsLabel(segment: String): String = SubGrades.BANDS[segment].orEmpty().joinToString("・") { b ->
    if (b.maxTop > 1.0) "${b.label} それより下" else "${b.label} 上位${String.format(Locale.US, "%.0f", b.maxTop * 100)}%まで"
}

/** The sub-grade strip: badge + spell card, three percentages and the 霊力ゲージ. [compact] = the history list. */
@Composable
internal fun SubGradeStrip(sub: SubGrade, compact: Boolean = false) {
    val color = subColor(sub)
    Column(
        Modifier.fillMaxWidth()
            .background(color.copy(alpha = .10f), RoundedCornerShape(10.dp))
            .border(1.dp, color.copy(alpha = .70f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = if (compact) 6.dp else 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.background(color.copy(alpha = .22f), RoundedCornerShape(6.dp)).border(1.dp, color, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) { Text(sub.shown, color = color, fontWeight = FontWeight.Bold, fontSize = if (compact) 14.sp else 18.sp, maxLines = 1, softWrap = false) }
            Spacer(Modifier.width(8.dp))
            Text(SubGrades.spellCard(sub), color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = if (compact) 11.sp else 13.sp, maxLines = 1)
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PercentCell(Modifier.weight(1f), "勝つ確率", pc(sub.probability), Gmk.Text, compact)
            PercentCell(Modifier.weight(1f), "その時間の", topLabel(sub.top), color, compact)
            PercentCell(Modifier.weight(1f), "${sub.label}の検証", sub.rate?.let(::pc) ?: "—", if ((sub.rate ?: 0.0) >= 0.55) Gmk.Gold else Gmk.Text, compact)
        }
        Spacer(Modifier.height(5.dp))
        val power = (1.0 - sub.top).coerceIn(0.0, 1.0).toFloat()
        Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0x553A4A6E), RoundedCornerShape(3.dp))) {
            Box(Modifier.fillMaxWidth(power.coerceAtLeast(0.02f)).height(6.dp)
                .background(Brush.horizontalGradient(listOf(Gmk.Purple, color)), RoundedCornerShape(3.dp)))
        }
        Text("霊力 ${String.format(Locale.US, "%.0f", power * 100.0)}%（${bandsLabel(sub.segment)}）" +
            (if (sub.rate == null) "・予備モデルのため検証なし" else ""), color = Gmk.Faint, fontSize = 9.sp, maxLines = 2)
    }
}

@Composable
private fun PercentCell(modifier: Modifier, title: String, value: String, color: Color, compact: Boolean) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = Gmk.Muted, fontSize = 9.sp, maxLines = 1)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = if (compact) 13.sp else 16.sp, maxLines = 1, softWrap = false)
    }
}

/** One line of percentages for a trade without a sub-grade (B, S/A, D...): the model probability and the grade's validated rate. */
@Composable
internal fun PercentLine(probability: Double?, validated: Double?, grade: String, probabilityTitle: String = "勝つ確率") {
    if (probability == null && validated == null) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        if (probability != null && probability.isFinite()) PercentCell(Modifier.weight(1f), probabilityTitle, pc(probability), Gmk.Text, false)
        if (validated != null) PercentCell(Modifier.weight(1f), "${grade}の検証", pc(validated), if (validated >= 0.55) Gmk.Gold else Gmk.Text, false)
    }
}

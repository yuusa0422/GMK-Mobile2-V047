package jp.gmk.mobile.domain

/**
 * v0.7.71 weekday 5-minute model inputs (exact port of scripts/v0771_production.py design_app): only the pair's own 61 one-minute
 * candles and live price ([EvidenceFeatures.instrument]) and the yen basket, so it works for any pair. Pool = the five yen crosses +
 * BTC/JPY, ETH/JPY, BTC/USD, ETH/USD ([CryptoPairs]).
 *
 * Order (35): signed by the direction d (+1 HIGH, -1 LOW): r1 r3 r5 r10 r15 r30 r60 pos15 pos60 bbz bask5 idio5 bask15 idio15;
 * live block, signed (zeros in the backup model): f1 f2 f5 f15 pos15L bbzL baskF1 idioF1; unsigned: rv60 rv30/60 hour;
 * one-hot of the 9 pairs; d. Basket = the mean of the four major yen crosses (USD/EUR/GBP/AUD-JPY), NaN unless all four have a
 * window (as the research rows); crypto pairs have no basket (0) and idio = their own move.
 */
object CandleModel9 {
    val INSTRUMENTS = TradingSession.FX + CryptoPairs.ALL
    const val FEATURE_COUNT = 35

    data class Basket(val r5: Double, val r15: Double, val f1: Double)

    fun basket(byInstrument: Map<String, EvidenceFeatures.Instrument>): Basket {
        val fx = EvidenceFeatures.FX4.mapNotNull { byInstrument[it] }
        if (fx.size != 4) return Basket(Double.NaN, Double.NaN, Double.NaN)
        var a = 0.0; var b = 0.0; var c = 0.0
        for (x in fx) { a += x.r5; b += x.r15; c += x.f1 }
        return Basket(a / 4.0, b / 4.0, c / 4.0)
    }

    fun design(x: EvidenceFeatures.Instrument, basket: Basket, hourJst: Int, direction: Int, fresh: Boolean): DoubleArray {
        val d = direction.toDouble()
        val crypto = CryptoPairs.isCrypto(x.instrument)
        val b5 = if (crypto) 0.0 else basket.r5; val b15 = if (crypto) 0.0 else basket.r15; val bf1 = if (crypto) 0.0 else basket.f1
        val out = DoubleArray(FEATURE_COUNT); var i = 0
        fun put(v: Double) { out[i++] = v }
        put(x.r1 * d); put(x.r3 * d); put(x.r5 * d); put(x.r10 * d); put(x.r15 * d); put(x.r30 * d); put(x.r60 * d)
        put(x.pos15 * d); put(x.pos60 * d); put(x.bbz * d)
        put(b5 * d); put((x.r5 - b5) * d); put(b15 * d); put((x.r15 - b15) * d)
        if (fresh) {
            put(x.f1 * d); put(x.f2 * d); put(x.f5 * d); put(x.f15 * d); put(x.pos15Live * d); put(x.bbzLive * d); put(bf1 * d); put((x.f1 - bf1) * d)
        } else repeat(8) { put(0.0) }
        put(x.rv60); put(x.rv30over60); put(hourJst.toDouble())
        for (s in INSTRUMENTS) put(if (x.instrument == s) 1.0 else 0.0)
        put(d)
        check(i == FEATURE_COUNT)
        return out
    }
}

/**
 * v0.7.71 weekend model inputs (exact port of scripts/v0771_weekend_prod.py des): the same candle inputs for the four cryptos (no
 * basket: 0, idio = own move), then rv60 rv30/60 hour, weekend flag (1), one-hot of BTC/JPY ETH/JPY BTC/USD ETH/USD, d (31 inputs).
 */
object CandleModelW {
    val INSTRUMENTS = CryptoPairs.ALL
    const val FEATURE_COUNT = 31

    fun design(x: EvidenceFeatures.Instrument, hourJst: Int, direction: Int, fresh: Boolean): DoubleArray {
        val d = direction.toDouble()
        val out = DoubleArray(FEATURE_COUNT); var i = 0
        fun put(v: Double) { out[i++] = v }
        put(x.r1 * d); put(x.r3 * d); put(x.r5 * d); put(x.r10 * d); put(x.r15 * d); put(x.r30 * d); put(x.r60 * d)
        put(x.pos15 * d); put(x.pos60 * d); put(x.bbz * d)
        put(0.0); put(x.r5 * d); put(0.0); put(x.r15 * d)
        if (fresh) {
            put(x.f1 * d); put(x.f2 * d); put(x.f5 * d); put(x.f15 * d); put(x.pos15Live * d); put(x.bbzLive * d); put(0.0); put(x.f1 * d)
        } else repeat(8) { put(0.0) }
        put(x.rv60); put(x.rv30over60); put(hourJst.toDouble()); put(1.0)
        for (s in INSTRUMENTS) put(if (x.instrument == s) 1.0 else 0.0)
        put(d)
        check(i == FEATURE_COUNT)
        return out
    }
}

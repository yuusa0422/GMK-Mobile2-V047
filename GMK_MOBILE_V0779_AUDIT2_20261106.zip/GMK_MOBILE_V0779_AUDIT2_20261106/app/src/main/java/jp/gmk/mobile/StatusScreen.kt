package jp.gmk.mobile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState

internal fun latestCandidateStatusText(state: GmkUiState): String = state.scan?.let { scan ->
    scan.top1?.let {
        "【${expiryMinutes(scan.entryTimeJst, scan.judgeTimeJst, 3)}分判定】${pairLabel(it.instrument)} ${it.direction} 運用等級 ${it.grade} ${it.decision}" +
            (it.assessment?.correctionLabel?.let { r -> " • $r" } ?: "")
    }
} ?: "なし"

/** v0.7.74 status screen (神社の帳簿): feeds, scanner, settings and the diagnostics export. */
@Composable
fun StatusScreen(state: GmkUiState, setCutInEnabled: (Boolean) -> Unit, exportDiagnostic: () -> Unit,
                 setSignalNotify: (Boolean) -> Unit = {}, setNotifyMinGrade: (String) -> Unit = {}, setEntryMode: (String) -> Unit = {},
                 setPromoteC1: (Boolean) -> Unit = {}, setSoundOn: (Boolean) -> Unit = {}, setKeepScreenOn: (Boolean) -> Unit = {}) {
    val fetchAge = remember(state.rates, state.lastRateUpdateMs) {
        state.rates.associate { it.instrument to (it.fetchAgeSeconds ?: if (state.lastRateUpdateMs > 0) ((System.currentTimeMillis() - state.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0) else null) }
    }
    val chartSyncStatus = when {
        state.chartLoading -> "取得中"
        state.chartError != null -> "注意"
        state.chartUpdatedAtMs > 0L -> "同期済"
        else -> "未取得"
    }
    val strengthSyncStatus = when {
        state.strengthLoading -> "取得中"
        state.strengthErrors.isNotEmpty() -> "一部注意"
        state.strengthUpdatedAtMs > 0L -> "更新済"
        else -> "未取得"
    }
    Column(Modifier.fillMaxSize().background(Gmk.Night).verticalScroll(rememberScrollState()).padding(12.dp)) {
        Image(painterResource(R.drawable.gmk_header), "東方相議録", Modifier.fillMaxWidth().aspectRatio(864f / 300f).clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
        Spacer(Modifier.height(8.dp))
        Text("神社の帳簿（状態・診断）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text("取得品質 / スキャン / 設定 / カットイン", color = Gmk.Muted, fontSize = 12.sp)
        StatusPanel("取得とスキャン") {
            StatusLine("レート元", if (state.rates.isNotEmpty() || state.cryptoRates.isNotEmpty()) "FX Yahoo • 仮想通貨 Coinbase（予備 Binance）• BTC bitbank（土日の予備）" else "接続待ち")
            // v0.7.71: crypto pairs (theoption's crypto rates follow Coinbase; Binance is the backup when Coinbase cannot be reached)
            val cryptoLive = state.cryptoRates.filter { it.freshnessStatus == "LIVE" }
            StatusLine("仮想通貨（平日5分・土日）", "LIVE ${cryptoLive.size}/${state.cryptoRates.size.coerceAtLeast(4)}" +
                cryptoLive.map { it.source.substringBefore('×') }.distinct().joinToString("・").let { if (it.isEmpty()) "" else "（$it）" })
            StatusLine("FX＋BTC(bitbank) 有効 / LIVE", "${state.rateAvailableCount}/6  •  ${state.rateLiveCount}/6")
            StatusLine("レート更新", state.lastRateUpdateMs.takeIf { it > 0 }?.let(::formatClock) ?: "未取得")
            StatusLine("スキャン", if (state.busy) "実行中" else "待機")
            StatusLine("AUTO（5分ごと）", if (state.autoScan) "ON" else "OFF")
            StatusLine("1分AUTO（毎分・80%）", if (state.m1Auto) "ON" else "OFF")
            state.m1Status?.let { StatusLine("1分の状態", it) }
            StatusLine("直近候補", latestCandidateStatusText(state))
            StatusLine("判定可能 / 対象", "${state.scannableCount} / ${state.rateAvailableCount}")
            state.error?.let { StatusLine("最終エラー", it, Gmk.Warn) }
            StatusLine("通信 / 失敗 / 取消", "${state.networkRequestCount} / ${state.networkFailureCount} / ${state.networkCancelledCount}")
            StatusLine("HTTP 429 / 5xx", "${state.network429Count} / ${state.network5xxCount}")
            state.lastNetworkError?.let { StatusLine("最終通信エラー", it, Gmk.Warn) }
            state.scanStatus?.let { StatusLine("スキャン状態", it) }
            state.rateStatus?.let { StatusLine("取得状態", it) }
        }
        StatusPanel("通貨ペアごとの取得状態") {
            // v0.7.79: BTC/JPY is in both lists (bitbank and the four crypto pairs); each is named so the two are told apart
            (state.rates.map { it to (if (it.instrument == "BTCJPY") "（bitbank・土日の予備）" else "") } +
                state.cryptoRates.map { it to (if (it.instrument == "BTCJPY") "（仮想通貨4つ）" else "") }).forEach { (rate, tag) ->
                val age = rate.ageSeconds
                val quality = when {
                    rate.freshnessStatus == "LIVE" -> "FRESH"
                    rate.price == null -> "STALE"
                    age != null && age > 120.0 -> "STALE"
                    else -> "LAG"
                }
                val freshColor = when (quality) { "FRESH" -> Gmk.Win; "LAG" -> Gmk.Warn; else -> Gmk.Lose }
                Column(Modifier.fillMaxWidth().padding(top = 8.dp).border(1.dp, freshColor.copy(alpha = .4f), RoundedCornerShape(8.dp)).padding(9.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(pairLabel(rate.instrument) + tag, Modifier.weight(1f), color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(quality, color = freshColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text("${rate.source} • ${rate.price?.let(::formatPrice) ?: "価格なし"}", color = Gmk.Muted, fontSize = 10.sp)
                    val receivedAt = fetchAge[rate.instrument]?.let { formatClock(System.currentTimeMillis() - (it * 1000.0).toLong()) } ?: "—"
                    Text("受信目安 $receivedAt • provider age ${rate.ageSeconds?.let { "%.1fs".format(it) } ?: "—"} / fetch age ${fetchAge[rate.instrument]?.let { "%.1fs".format(it) } ?: "—"}", color = Gmk.Muted, fontSize = 10.sp)
                    rate.bid?.let { Text("bid ${formatPrice(it)} / ask ${rate.ask?.let(::formatPrice) ?: "—"}", color = Gmk.Muted, fontSize = 10.sp) }
                }
            }
        }
        StatusPanel("チャート・強弱連携") {
            StatusLine("チャート", "${pairLabel(state.chartInstrument)} ${state.chartTimeframe} • ${state.chartCandles.size}本 • $chartSyncStatus")
            if (state.chartSource.isNotBlank()) StatusLine("チャートの足", state.chartSource)
            state.chartError?.let { StatusLine("チャート警告", it, Gmk.Warn) }
            StatusLine("チャート更新", state.chartUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "未取得")
            StatusLine("通貨強弱", "${state.strengthTimeframe} • ${state.strengthCandles.count { it.value.isNotEmpty() }}/6 • $strengthSyncStatus")
            StatusLine("強弱更新", state.strengthUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "未取得")
            if (state.strengthErrors.isNotEmpty()) StatusLine("強弱エラー", state.strengthErrors.entries.joinToString { "${it.key}: ${it.value}" }, Gmk.Warn)
        }
        StatusPanel("ENTRYの量") {
            // v0.7.56: how many slots are entered. One year, scored on other periods.
            val mode = EntryMode.parse(state.entryMode)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                EntryMode.values().forEach { m ->
                    TextButton(onClick = { setEntryMode(m.key) }) {
                        Text(if (mode == m) "●${m.label}" else m.label, fontSize = 12.sp, color = if (mode == m) Gmk.Win else Gmk.Muted)
                    }
                }
            }
            Text("いま: ${mode.summary}", color = Gmk.Text, fontSize = 11.sp)
            Text("1年の検証（平日は円の5ペア＋仮想通貨4つを5分ごとに判定・時間帯ルールは3分判定、ほかは5分判定）: 55%優先 = S/A/Bだけ（58.7%）。" +
                "平日70% = どの1時間も12枠中9回以上ENTRY（途中から動いた時間は動いた枠の70%。Cも入る、合計53.4%・1日103回・同じ向きの重ね入りは控えめ）。" +
                "土日は仮想通貨4つの土日モデル: B（上位8%）61.2%・1日14回。毎日（土日60%） = 土日もCが入る（3分判定・合計55.7%）。次の判定から切り替わります。", color = Gmk.Muted, fontSize = 10.sp)
        }
        StatusPanel("神社の設定（効果音・画面）") {
            // v0.7.77: display-only settings
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("効果音 ${if (state.soundOn) "ON" else "OFF"}", color = Gmk.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("新しい5分ENTRYでスペルカード宣言の音。結果が出たら WINで勝利の音・LOSEで「ピチューン」（5分・3分の取引と1分のB）。" +
                        "音量はメディアの音量。マナーモード・サイレント中は鳴りません", color = Gmk.Muted, fontSize = 10.sp)
                }
                Switch(checked = state.soundOn, onCheckedChange = setSoundOn)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("画面をつけたまま ${if (state.keepScreenOn) "ON" else "OFF"}", color = Gmk.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("アプリを開いている間は画面が消えない（取引中に見続ける時に。電池は多めに使います）", color = Gmk.Muted, fontSize = 10.sp)
                }
                Switch(checked = state.keepScreenOn, onCheckedChange = setKeepScreenOn)
            }
        }
        StatusPanel("Cの中の強さ（v0.7.76）") {
            // v0.7.76: C1 / C2 / C3 and the optional promotion of the weekday C1 to B
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("C1をBに昇格 ${if (state.promoteC1) "ON" else "OFF"}（平日5分・土日）", color = Gmk.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("ONにすると平日5分のC1（その時間の上位10%・56.8%）と土日のC1（上位8〜15%・59.2%）をBとして入る・通知・カットイン。" +
                        "55%優先でも平日C1が入り、土日はどのモードでもC1が入る（平日 約13回/日・土日 約12回/日 増える）。1分のC1はCのまま", color = Gmk.Muted, fontSize = 10.sp)
                }
                Switch(checked = state.promoteC1, onCheckedChange = setPromoteC1)
            }
            SubGrades.BANDS.forEach { (seg, bands) ->
                val name = when (seg) { SubGrades.WEEKDAY -> "平日5分"; SubGrades.WEEKEND -> "土日3分"; SubGrades.M1_WEEKDAY -> "1分・平日"; else -> "1分・土日" }
                Text("$name: " + bands.joinToString("／") { b -> "${b.label} ${String.format(java.util.Locale.US, "%.1f%%", b.rate * 100.0)}" +
                    (b.y2324?.let { y -> "（23〜24年 ${String.format(java.util.Locale.US, "%.1f%%", y * 100.0)}）" } ?: "") }, color = Gmk.Text, fontSize = 11.sp)
            }
            Text("C1 / C2 / C3 = その時間の判定の中で上位何%か（平日5分 ${bandsLabel(SubGrades.WEEKDAY)}、土日 ${bandsLabel(SubGrades.WEEKEND)}、1分 ${bandsLabel(SubGrades.M1_WEEKDAY)}）。" +
                "検証%は1年分を作ったのとは別の期間で採点した勝率。比べる基準: 平日B 57.6%・土日B 61.2%・1.9倍の損益分岐 52.6%。", color = Gmk.Muted, fontSize = 10.sp)
        }
        StatusPanel("通知") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("シグナル通知 ${if (state.signalNotify) "ON" else "OFF"}", color = Gmk.Text, fontSize = 12.sp)
                    Text("ENTRY（${state.notifyMinGrade}以上）と、時間帯ルール（S/A候補）の2分前をスマホに通知", color = Gmk.Muted, fontSize = 10.sp)
                }
                Switch(checked = state.signalNotify, onCheckedChange = setSignalNotify)
            }
            Text("通知する等級", color = Gmk.Muted, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                listOf("A" to "S/Aだけ", "B" to "S〜B", "C" to "全ENTRY").forEach { (grade, label) ->
                    TextButton(onClick = { setNotifyMinGrade(grade) }) {
                        Text(if (state.notifyMinGrade == grade) "●$label" else label, fontSize = 12.sp, color = if (state.notifyMinGrade == grade) Gmk.Win else Gmk.Muted)
                    }
                }
            }
            Text("1年の検証（平日・円の5ペア＋仮想通貨4つ・5分ごと）: S/Aだけ 64.6%（1日0.8回・3分判定）・S〜B 58.7%（5.2回）・S〜C 53.4%（103回・ほぼ5分判定）。土日はB 61.2%（13.9回・仮想通貨4つ）。" +
                "通知の題名に【3分判定】【5分判定】が出ます。", color = Gmk.Muted, fontSize = 10.sp)
        }
        StatusPanel("カットイン / 実行環境") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("カットイン ${if (state.cutInEnabled) "ON" else "OFF"}", color = Gmk.Text, fontSize = 12.sp)
                    Text("表示 ${state.cutInShownCount}回 • 最終 ${state.lastCutInType ?: "なし"}", color = Gmk.Muted, fontSize = 10.sp)
                }
                Switch(checked = state.cutInEnabled, onCheckedChange = setCutInEnabled)
            }
            StatusLine("最終カットイン候補", "${state.lastCutInInstrument?.let(::pairLabel) ?: "—"} • ${state.lastCutInAtJst ?: "—"}")
            state.lastCutInSuppressedReason?.let { StatusLine("抑制理由", it, Gmk.Warn) }
            StatusLine("電池最適化除外", if (state.batteryOptimizationExempt) "はい" else "いいえ")
            StatusLine("バックグラウンド制限", if (state.backgroundRestricted) "あり" else "なし")
            StatusLine("バックグラウンド追跡", if (state.runtimeServiceRunning) "動作中" else if (state.runtimeServiceError != null) "開始失敗" else "待機")
            if (state.runtimeServiceError != null) StatusLine("追跡の復旧", "開始できませんでした。アプリを開くと再試行します", Gmk.Warn)
            Text("優勢: 判定30秒前の確認条件を満たしたとき。確定: WIN/LOSE保存後。", color = Gmk.Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = exportDiagnostic, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("JSON診断ログを保存", color = Gmk.Cyan, fontSize = 14.sp) }
        Text("ログには時刻、ペア、bid/ask/last、provider/fetch age、freshness、候補、ENTRY/判定、結果、判定ログ、カットイン、連携状態、ネットワーク失敗数を含みます。",
            color = Gmk.Muted, fontSize = 10.sp, modifier = Modifier.padding(7.dp))
    }
}

@Composable
private fun StatusPanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Spacer(Modifier.height(8.dp))
    ShrinePanel {
        Text(title, color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        content()
    }
}

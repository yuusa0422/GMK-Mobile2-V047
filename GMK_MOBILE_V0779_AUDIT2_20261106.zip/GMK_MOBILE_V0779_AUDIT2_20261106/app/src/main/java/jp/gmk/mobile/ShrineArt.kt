package jp.gmk.mobile

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

/**
 * v0.7.75: the shrine's own drawings, made of plain shapes (no character art): the red-and-white yin-yang orb (陰陽玉) and a faint
 * danmaku (bullet-curtain) pattern behind the screens.
 */

/** Red-and-white yin-yang orb; turns while [spinning] (scan running). */
@Composable
internal fun YinYangOrb(size: Dp, spinning: Boolean = false, modifier: Modifier = Modifier) {
    if (spinning) {
        val turn = rememberInfiniteTransition(label = "orb")
        val angle by turn.animateFloat(0f, 360f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "orb-angle")
        Canvas(modifier.size(size)) { rotate(angle) { drawOrb() } }
    } else {
        Canvas(modifier.size(size)) { rotate(-30f) { drawOrb() } }
    }
}

private fun DrawScope.drawOrb() {
    val r = size.minDimension / 2f * 0.92f
    val c = center
    val red = Color(0xFFE0284A); val white = Color(0xFFFFF4E4)
    val box = Size(r * 2, r * 2); val tl = Offset(c.x - r, c.y - r)
    drawCircle(white, radius = r, center = c)
    drawArc(red, startAngle = 90f, sweepAngle = 180f, useCenter = true, topLeft = tl, size = box)
    drawCircle(red, radius = r / 2f, center = Offset(c.x, c.y - r / 2f))
    drawCircle(white, radius = r / 2f, center = Offset(c.x, c.y + r / 2f))
    drawCircle(white, radius = r / 6f, center = Offset(c.x, c.y - r / 2f))
    drawCircle(red, radius = r / 6f, center = Offset(c.x, c.y + r / 2f))
    drawCircle(Color(0xFF3A0C18), radius = r, center = c, style = Stroke(width = r * 0.08f))
}

/** A faint bullet-curtain pattern (rings of small bullets from a few emitters), drawn once behind a screen. */
@Composable
internal fun DanmakuBackdrop(modifier: Modifier = Modifier, alpha: Float = 0.16f) {
    val colors = listOf(Color(0xFFFF4F91), Color(0xFF35D9FF), Color(0xFF9E6CFF), Color(0xFFFFC76A), Color(0xFFE0284A))
    Canvas(modifier) {
        val emitters = listOf(Offset(size.width * 0.82f, size.height * 0.18f), Offset(size.width * 0.12f, size.height * 0.55f),
            Offset(size.width * 0.70f, size.height * 0.86f))
        val step = 34.dp.toPx(); val bullet = 2.6.dp.toPx()
        emitters.forEachIndexed { e, o ->
            for (k in 1..6) {
                val n = 10 + 4 * k; val ring = step * k; val twist = (k * 9 + e * 23).toFloat()
                val col = colors[(k + e) % colors.size].copy(alpha = alpha * (1f - k / 8f))
                for (i in 0 until n) {
                    val a = Math.toRadians((360.0 / n) * i + twist)
                    drawCircle(col, radius = bullet * (if (i % 2 == 0) 1f else 0.7f), center = Offset(o.x + ring * cos(a).toFloat(), o.y + ring * sin(a).toFloat()))
                }
            }
        }
    }
}

package jp.gmk.mobile.domain

import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.7.75 1-minute judgment inputs (research_v0775/onemin_prod_v0775.py `features` + `des`). Per X/USD product (BTC-USD, ETH-USD):
 * the 61 minutes opening at entry-61 min .. entry-1 min, the last one being the forming minute closed at the live price; X/JPY pairs
 * use their X/USD inputs (a constant USD/JPY factor does not change any input), their result is read in yen.
 */
object CandleModelM1 {
    val PAIRS = listOf("BTCJPY", "ETHJPY", "BTCUSD", "ETHUSD")
    fun productOf(pair: String): String? = when (pair) { "BTCJPY", "BTCUSD" -> "BTCUSD"; "ETHJPY", "ETHUSD" -> "ETHUSD"; else -> null }
    val SIGNED = listOf("r1", "r2", "r3", "r5", "r10", "r15", "r30", "r60", "pos15", "pos60", "bbz", "body", "gap", "body2", "up5", "up15", "cr_r1", "cr_r5")
    val UNSIGNED = listOf("rv60", "rv15_60", "rng", "rng2", "vol2")
    val FEATURES: List<String> = SIGNED + listOf("wk_with", "wk_against") + UNSIGNED + listOf("hour", "minute", "wkend") + PAIRS.map { "is_$it" } + "dir"
    val FEATURE_COUNT: Int = FEATURES.size
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    const val WINDOW = 61

    /**
     * One product's inputs for the entry minute [entryMs] (exact minute), or null when a finished minute of the window is missing.
     * The forming minute (opening at entry-1 min) takes its open / high / low from its candle when present (else the previous close)
     * and the live price [live] as its close.
     */
    fun product(candles: List<Candle>, live: Double, entryMs: Long): Map<String, Double>? {
        if (!live.isFinite() || live <= 0.0) return null
        val byT = HashMap<Long, Candle>(candles.size * 2); for (c in candles) byT[c.timeEpochMs] = c
        val n = WINDOW
        val o = DoubleArray(n); val h = DoubleArray(n); val l = DoubleArray(n); val c = DoubleArray(n); val v = DoubleArray(n)
        for (k in 0 until n) {
            val t = entryMs - (n - k) * 60_000L
            val bar = byT[t]
            if (k < n - 1) {
                if (bar == null || !(bar.close > 0.0) || !(bar.open > 0.0)) return null
                o[k] = bar.open; h[k] = bar.high; l[k] = bar.low; c[k] = bar.close; v[k] = bar.volume
            } else {
                val op = bar?.open?.takeIf { it > 0.0 } ?: c[k - 1]
                o[k] = op; h[k] = max(bar?.high ?: op, max(op, live)); l[k] = min(bar?.low ?: op, min(op, live)); c[k] = live; v[k] = bar?.volume ?: Double.NaN
            }
        }
        val lg = DoubleArray(n) { ln(c[it]) }
        val ret = DoubleArray(n) { if (it == 0) Double.NaN else lg[it] - lg[it - 1] }
        val i = n - 1
        var s60 = 0.0; for (k in i - 59..i) s60 += ret[k] * ret[k]
        var s15 = 0.0; for (k in i - 14..i) s15 += ret[k] * ret[k]
        val norm = max(sqrt(max(s60, 0.0) / 60.0), 1e-8)
        val n15 = sqrt(max(s15, 0.0) / 15.0)
        val x = LinkedHashMap<String, Double>()
        for (kk in intArrayOf(1, 2, 3, 5, 10, 15, 30, 60)) x["r$kk"] = (lg[i] - lg[i - kk]) / (norm * sqrt(kk.toDouble()))
        var h15 = Double.NEGATIVE_INFINITY; var l15 = Double.POSITIVE_INFINITY
        for (k in i - 14..i) { h15 = max(h15, h[k]); l15 = min(l15, l[k]) }
        var h60 = Double.NEGATIVE_INFINITY; var l60 = Double.POSITIVE_INFINITY
        for (k in i - 59..i) { h60 = max(h60, h[k]); l60 = min(l60, l[k]) }
        x["pos15"] = (c[i] - l15) / max(h15 - l15, 1e-12) * 2 - 1
        x["pos60"] = (c[i] - l60) / max(h60 - l60, 1e-12) * 2 - 1
        var m = 0.0; for (k in i - 19..i) m += c[k]; m /= 20.0
        var vv = 0.0; for (k in i - 19..i) vv += (c[k] - m) * (c[k] - m); vv /= 20.0
        x["bbz"] = (c[i] - m) / sqrt(max(vv, 1e-16))
        val lo = ln(o[i])
        x["body"] = (lg[i] - lo) / norm; x["gap"] = (lo - lg[i - 1]) / norm; x["body2"] = (lg[i - 1] - ln(o[i - 1])) / norm
        fun updown(from: Int): Double { var u = 0; var d = 0; for (k in from..i) { if (ret[k] > 0) u++ else if (ret[k] < 0) d++ }; return (u - d).toDouble() }
        x["up5"] = updown(i - 4); x["up15"] = updown(i - 14)
        x["uw"] = (ln(h[i]) - max(lo, lg[i])) / norm; x["lw"] = (min(lo, lg[i]) - ln(l[i])) / norm
        x["rv60"] = norm * 1e4; x["rv15_60"] = n15 / norm
        x["rng"] = (ln(h[i]) - ln(l[i])) / norm; x["rng2"] = (ln(h[i - 1]) - ln(l[i - 1])) / norm
        var vs = 0.0; for (k in 0 until i) vs += v[k]
        val vm = vs / 60.0
        x["vol2"] = if (vm.isFinite() && vm > 0.0 && v[i - 1].isFinite()) v[i - 1] / vm else Double.NaN
        return x
    }

    /** The design row of [pair] in direction [dir] (+1 HIGH / -1 LOW) from its product's inputs and the crypto basket (mean r1 / r5). */
    fun design(pair: String, inputs: Map<String, Double>, basket: Pair<Double, Double>, entryMs: Long, dir: Int): DoubleArray {
        val d = dir.toDouble()
        val t = Instant.ofEpochMilli(entryMs).atZone(JST)
        val out = DoubleArray(FEATURE_COUNT); var j = 0
        for (f in SIGNED) out[j++] = d * when (f) { "cr_r1" -> basket.first; "cr_r5" -> basket.second; else -> inputs.getValue(f) }
        out[j++] = if (dir == 1) inputs.getValue("uw") else inputs.getValue("lw")
        out[j++] = if (dir == 1) inputs.getValue("lw") else inputs.getValue("uw")
        for (f in UNSIGNED) out[j++] = inputs.getValue(f)
        out[j++] = t.hour.toDouble(); out[j++] = t.minute.toDouble(); out[j++] = if (t.dayOfWeek.value >= 6) 1.0 else 0.0
        for (p in PAIRS) out[j++] = if (p == pair) 1.0 else 0.0
        out[j++] = d
        check(j == FEATURE_COUNT)
        return out
    }
}

/**
 * v0.7.75 1-minute judgment: every minute 09:00-22:59 JST, every day, the four crypto pairs; entry at the minute (:00 s), judged on the
 * minute OPEN 60 s later (a draw loses). The best pair x direction of the minute is entered so that every hour has at least 80% of its
 * minutes ENTRY (the user's setting): it is entered when its probability is in the top need/left of that hour's distribution, always
 * when the minutes left equal the entries still needed, never once the 80% is reached. Grade B = top 5% of the hour, C = the rest of
 * ENTRY, D = SKIP. One year (each period scored by a model fit on the other two, thresholds from the other periods): see [NOTE].
 */
object OneMinutePolicy {
    /** Starts with the 1-minute prefix ([RankStatistics.ONE_MINUTE_POLICY]) so the history keeps these rows with the 1-minute results. */
    const val POLICY_TAG = "GMK_V0735_NATIVE_1M_V0775_M1"
    const val SHARE = 0.8
    const val GRADE_B = 0.05
    const val MINUTES = 60
    val NEEDED: Int = kotlin.math.ceil(SHARE * MINUTES - 1e-9).toInt()
    const val NOTE = EvidenceModelM1Data.NOTE

    val ensemble: EvidenceEnsemble by lazy {
        EvidenceEnsemble(EvidenceModelM1Data.texts().indices.map {
            EvidenceTreeModel.parse(EvidenceModelM1Data.texts()[it], EvidenceModelM1Data.SHA256[it], CandleModelM1.FEATURE_COUNT)
        })
    }

    fun isPolicy(row: HistoryRow): Boolean = row.policyVersion == POLICY_TAG

    /** The decision runs [DECISION_LEAD_MS] before the entry minute (T-10). */
    const val DECISION_LEAD_MS = 10_000L
    /** A live price at most this much older than the decision time (T-10) is used. */
    const val LIVE_MAX_AGE_MS = 8_000L

    /**
     * v0.7.78: a live price of time [quoteMs] is fresh enough for the entry minute [entryMs]: from 8 s before the decision (T-18 s) up to
     * 1 s after the entry. Up to v0.7.77 the app asked for T-8 s or newer while it decides at T-10 s, so most minutes were skipped as
     * having no fresh price.
     */
    fun liveFresh(quoteMs: Long, entryMs: Long): Boolean = quoteMs >= entryMs - DECISION_LEAD_MS - LIVE_MAX_AGE_MS && quoteMs <= entryMs + 1_000L

    /**
     * v0.7.78: the ENTRY minutes the hour still needs: 80% of the minutes the app runs in that hour ([seenBefore] minutes already decided
     * by the 1-minute AUTO + the minutes left, this one included), like the 5-minute rule's hour slots (v0.7.61). Without [seenBefore]
     * every earlier minute of the hour counts (48 of 60). Up to v0.7.77 a start or restart in the middle of the hour made every minute
     * left a forced ENTRY.
     */
    fun neededInHour(entry: ZonedDateTime, enteredThisHour: Int, seenBefore: Int? = null): Int {
        val t = entry.withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
        val seen = (seenBefore ?: t.minute).coerceAtLeast(enteredThisHour).coerceIn(0, t.minute)
        return kotlin.math.ceil(SHARE * (seen + MINUTES - t.minute) - 1e-9).toInt()
    }

    /** Cut-ins: every 5-minute row; of the 1-minute rows (up to 48 an hour) only grade B (the top 5%), so they do not cover the screen. */
    fun showsCutIn(row: HistoryRow): Boolean = !isPolicy(row) || row.grade == "B"

    class Choice(val instrument: String, val direction: String, val probability: Double, val scores: List<EvidencePolicy.PairScore>)

    /**
     * Probabilities of every pair x direction for the entry minute [entry] from the X/USD candles ([usdCandles] by product "BTCUSD" /
     * "ETHUSD") and their live prices; pairs whose product has no full window or no live price are left out.
     */
    fun scores(usdCandles: Map<String, List<Candle>>, live: Map<String, Double>, entry: ZonedDateTime): List<EvidencePolicy.PairScore> {
        val e = entry.toInstant().toEpochMilli()
        val inputs = LinkedHashMap<String, Map<String, Double>>()
        for (p in listOf("BTCUSD", "ETHUSD")) {
            val c = usdCandles[p] ?: continue; val q = live[p] ?: continue
            CandleModelM1.product(c, q, e)?.let { inputs[p] = it }
        }
        if (inputs.isEmpty()) return emptyList()
        val b = inputs["BTCUSD"]; val et = inputs["ETHUSD"]
        val basket = (if (b != null && et != null) (b.getValue("r1") + et.getValue("r1")) / 2 else Double.NaN) to
            (if (b != null && et != null) (b.getValue("r5") + et.getValue("r5")) / 2 else Double.NaN)
        val m = ensemble
        return CandleModelM1.PAIRS.mapNotNull { pair ->
            val x = inputs[CandleModelM1.productOf(pair)] ?: return@mapNotNull null
            EvidencePolicy.PairScore(pair, m.probability(CandleModelM1.design(pair, x, basket, e, 1)), m.probability(CandleModelM1.design(pair, x, basket, e, -1)))
        }
    }

    /** The best pair x direction (pairs in [CandleModelM1.PAIRS] order, HIGH before LOW on a tie), or null without any score. */
    fun choose(scores: List<EvidencePolicy.PairScore>): Choice? {
        var best: Triple<String, String, Double>? = null
        for (s in scores) for ((d, p) in listOf("HIGH" to s.high, "LOW" to s.low)) if (p.isFinite() && (best == null || p > best.third)) best = Triple(s.instrument, d, p)
        val b = best ?: return null
        return Choice(b.first, b.second, b.third, scores)
    }

    /** The probability of the hour's distribution that leaves the top [x] (0..1) above it: quantile 1-x, linear between the table points. */
    fun threshold(weekend: Boolean, hour: Int, x: Double): Double {
        val t = EvidenceModelM1Data.table(weekend, hour) ?: return Double.POSITIVE_INFINITY
        val q = (1.0 - x.coerceIn(0.0, 1.0)) * (t.size - 1)
        val lo = kotlin.math.floor(q).toInt().coerceIn(0, t.size - 1); val hi = (lo + 1).coerceAtMost(t.size - 1)
        return t[lo] + (t[hi] - t[lo]) * (q - lo)
    }

    /** Grade and decision of the minute [entry] whose best probability is [p], with [enteredThisHour] ENTRY minutes already in its hour. */
    fun decide(entry: ZonedDateTime, p: Double, enteredThisHour: Int, seenBefore: Int? = null): Pair<String, String> {
        val t = entry.withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
        val weekend = t.dayOfWeek.value >= 6
        val left = MINUTES - t.minute; val need = neededInHour(entry, enteredThisHour, seenBefore) - enteredThisHour
        if (need <= 0) return "D" to "SKIP"
        if (need >= left || p >= threshold(weekend, t.hour, need.toDouble() / left)) {
            return (if (p >= threshold(weekend, t.hour, GRADE_B)) "B" else "C") to "ENTRY"
        }
        return "D" to "SKIP"
    }

    /** v0.7.76: C1 / C2 / C3 of a C minute by its place in the hour's table (explanation only; null for B / D). */
    fun subGrade(entry: ZonedDateTime, p: Double, grade: String): SubGrade? {
        if (grade != "C") return null
        val t = entry.withZoneSameInstant(ZoneId.of("Asia/Tokyo")); val weekend = t.dayOfWeek.value >= 6
        return SubGrades.of(if (weekend) SubGrades.M1_WEEKEND else SubGrades.M1_WEEKDAY, "C", SubGrades.oneMinute(weekend, t.hour, p), p, true)
    }

    /** ENTRY minutes of AUTO 1-minute rows in the same JST hour as [entry] (the app recounts them from the history after a restart). */
    fun enteredInHour(rows: List<HistoryRow>, entry: ZonedDateTime): Int {
        val t = entry.withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
        val key = t.toLocalDate().toString() + "T" + t.hour
        val prefix = t.toLocalDate().toString() + "T" + String.format(java.util.Locale.US, "%02d", t.hour)
        return rows.count { r ->
            r.source == "AUTO_1M" && r.decision == "ENTRY" && isPolicy(r) && run {
                // v0.7.78: a "+09:00" string is compared by its text (no parse per row); anything else is parsed
                val s = r.entryTimeJst
                if (s.length >= 13 && s.endsWith("+09:00")) s.startsWith(prefix)
                else runCatching { ZonedDateTime.parse(s).withZoneSameInstant(ZoneId.of("Asia/Tokyo")).let { it.toLocalDate().toString() + "T" + it.hour } }.getOrNull() == key
            }
        }
    }

    /**
     * The scan of minute [entry] for the history: rank 1 = the chosen pair x direction with [grade] / [decision], the other pairs (their
     * better direction) as reference ranks. Judged 60 s after entry. [source] = "AUTO_1M" or "MANUAL_1M".
     */
    fun result(source: String, entry: ZonedDateTime, at: ZonedDateTime, c: Choice, grade: String, decision: String, reason: String,
               sub: SubGrade? = subGrade(entry, c.probability, grade)): ScanResult {
        val trace = CandidateActionTrace(c.instrument, c.direction, "未記録", null, null, grade, decision, 1)
        val assessment = CandidateAssessment("未記録", null, null, grade, decision, RuleSelectionStage.LEGACY_BASE,
            if (decision == "SKIP") CandidateSkipReason.UNKNOWN else null, null, null, null, trace, trace, null, reason, subGrade = sub)
        val others = c.scores.filter { it.instrument != c.instrument }
            .map { s -> if (s.high >= s.low) Triple(s.instrument, "HIGH", s.high) else Triple(s.instrument, "LOW", s.low) }
            .sortedByDescending { it.third }
        val candidates = listOf(ScanCandidate(1, c.instrument, CryptoPairs.display(c.instrument), c.direction, grade, c.probability, decision,
            score = c.probability, regime = "1M", assessment = assessment)) +
            others.mapIndexed { k, (inst, dir, p) -> ScanCandidate(k + 2, inst, CryptoPairs.display(inst), dir, "D", p, "SKIP", score = p, regime = "1M") }
        return ScanResult("M1-$source-${entry.toEpochSecond()}", at.toString(), entry.toString(), entry.plusSeconds(60).toString(), candidates,
            source = source, policyVersion = POLICY_TAG)
    }

    /** "1分判定 ETH/USD HIGH B ENTRY p=0.5421" - the reason line of a 1-minute row. */
    fun reason(c: Choice, grade: String, decision: String, entered: Int, entry: ZonedDateTime, seenBefore: Int? = null): String {
        val t = entry.withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
        val seen = (seenBefore ?: t.minute).coerceAtLeast(entered).coerceIn(0, t.minute)
        val share = "この1時間 ENTRY ${entered + if (decision == "ENTRY") 1 else 0}/${seen + 1}分（80%以上に保つ）"
        val need = neededInHour(entry, entered, seenBefore) - entered
        return when {
            // v0.7.78: a skip is "secured" only when the hour already has its 80%; otherwise the minute was below the hour's bar
            decision != "ENTRY" && need <= 0 -> "1分: 80%を確保済みのため見送り（${"%.4f".format(c.probability)}）・$share"
            decision != "ENTRY" -> "1分: この時間の基準に届かず見送り（${"%.4f".format(c.probability)}・80%まであと${need}回／残り${MINUTES - t.minute - 1}分）・$share"
            grade == "B" -> "1分 B: この時間の上位5%（${"%.4f".format(c.probability)}）・$share"
            else -> "1分 C: 80%を保つENTRY（${"%.4f".format(c.probability)}）・$share" +
                (subGrade(entry, c.probability, grade)?.let { " / Cの中の強さ ${SubGrades.text(it)}" } ?: "")
        }
    }
}

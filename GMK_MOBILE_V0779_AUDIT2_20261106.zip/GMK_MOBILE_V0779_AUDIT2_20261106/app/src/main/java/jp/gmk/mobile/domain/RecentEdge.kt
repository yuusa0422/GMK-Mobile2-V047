package jp.gmk.mobile.domain

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.62: is the model's edge there right now? The win rate of this version's own ENTRY results over the last 10 finished
 * weekdays (today not included). Research (out of sample, 1 year): when the last 10 days were below 50%, the next day won 50.0%
 * (otherwise 53.8%); in Sep-Oct 2026 the edge disappeared (46.8% / 48.8%). Entries are not changed - this is a warning only.
 */
object RecentEdge {
    const val DAYS = 10
    const val MIN_DAYS = 3
    const val MIN_ROWS_PER_DAY = 20
    const val BREAK_EVEN = 1.0 / 1.9
    const val STOP = 0.50
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    enum class Level { COLLECTING, GOOD, BELOW_BREAK_EVEN, STOP }
    data class State(val level: Level, val days: Int, val wins: Int, val total: Int) {
        val rate: Double get() = if (total > 0) wins.toDouble() / total else Double.NaN
    }

    fun of(rows: List<HistoryRow>, today: LocalDate, policyTag: String): State {
        val byDay = HashMap<LocalDate, IntArray>()
        for (r in rows) {
            if (r.decision != "ENTRY" || r.candidateRank != 1 || !r.policyVersion.startsWith(policyTag)) continue
            if (r.resultStatus != "WIN" && r.resultStatus != "LOSE") continue
            val t = r.entryTimeJst
            // JST stamps carry the date in the first 10 characters (no parse for the ~20,000-row history); others are converted
            val day = (if (t.length >= 16 && t.endsWith("+09:00")) runCatching { LocalDate.parse(t.substring(0, 10)) }.getOrNull()
                       else runCatching { ZonedDateTime.parse(t).withZoneSameInstant(JST).toLocalDate() }.getOrNull()) ?: continue
            if (day.dayOfWeek.value > 5 || !day.isBefore(today)) continue
            val c = byDay.getOrPut(day) { IntArray(2) }; c[1]++; if (r.resultStatus == "WIN") c[0]++
        }
        val days = byDay.entries.filter { it.value[1] >= MIN_ROWS_PER_DAY }.sortedByDescending { it.key }.take(DAYS)
        val wins = days.sumOf { it.value[0] }; val total = days.sumOf { it.value[1] }
        if (days.size < MIN_DAYS) return State(Level.COLLECTING, days.size, wins, total)
        val rate = wins.toDouble() / total
        return State(if (rate < STOP) Level.STOP else if (rate < BREAK_EVEN) Level.BELOW_BREAK_EVEN else Level.GOOD, days.size, wins, total)
    }

    fun label(s: State): String = when (s.level) {
        Level.COLLECTING -> "直近の成績: 集計中（${s.days}日分・${MIN_DAYS}日でお知らせ開始）"
        Level.GOOD -> "直近${s.days}日の勝率 ${"%.1f".format(s.rate * 100)}%（${s.wins}/${s.total}）: 損益分岐 52.6% 以上"
        Level.BELOW_BREAK_EVEN -> "注意: 直近${s.days}日の勝率 ${"%.1f".format(s.rate * 100)}%（${s.wins}/${s.total}）が損益分岐 52.6% 未満"
        Level.STOP -> "停止推奨: 直近${s.days}日の勝率 ${"%.1f".format(s.rate * 100)}%（${s.wins}/${s.total}）。過去1年、この状態の翌日は50.0%でした。実際のお金での取引は控えてください"
    }
}

package jp.gmk.mobile.domain

import java.util.Locale

/**
 * v0.7.73 decision log: one JSON line per AUTO slot with every pair's HIGH / LOW probability (the same model and inputs as the decision,
 * [EvidencePolicy.scores9] / [EvidencePolicy.scoresWeekend]) and what the app did. Kept on the phone (last [KEEP] slots, about 18
 * weekdays) and sent in the diagnostics, so the live decisions can be checked against the research replay and later research can use
 * the phone's own slots (pairs skipped included).
 * {"b":<entry epoch s>,"k":"wd"|"we","m":<mode>,"f":1|0,"top":"BTCJPY HIGH C ENTRY","note":"...","p":[["USDJPY",0.51234,0.48766],...]}
 */
object DecisionLog {
    const val KEEP = 3000
    const val TRIM_AT = 3600

    private fun q(s: String): String {
        val b = StringBuilder("\"")
        for (c in s) when {
            c == '"' -> b.append("\\\"")
            c == '\\' -> b.append("\\\\")
            c < ' ' -> b.append(' ')
            else -> b.append(c)
        }
        return b.append('"').toString()
    }
    private fun n(x: Double): String = if (x.isFinite()) String.format(Locale.US, "%.5f", x) else "null"

    fun line(entryEpochSec: Long, weekday: Boolean, mode: String, scores: EvidencePolicy.SlotScores?, instrument: String, direction: String,
             grade: String, decision: String, note: String): String {
        val p = scores?.pairs?.joinToString(",", "[", "]") { "[${q(it.instrument)},${n(it.high)},${n(it.low)}]" } ?: "[]"
        return "{\"b\":$entryEpochSec,\"k\":${q(if (weekday) "wd" else "we")},\"m\":${q(mode)},\"f\":${if (scores?.fresh == true) 1 else 0}," +
            "\"top\":${q("$instrument $direction $grade $decision")},\"note\":${q(note.take(240))},\"p\":$p}"
    }

    /** True for a complete line (a crash in the middle of an append leaves a broken last line, which is skipped). */
    fun complete(line: String): Boolean = line.startsWith("{\"b\":") && line.endsWith("]}")
}

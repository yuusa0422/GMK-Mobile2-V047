package jp.gmk.mobile.domain

/**
 * v0.7.64: "runs" market indicator (display only - decisions and the 70% entry rule are unchanged).
 * Exact port of research_v0764/run_regime_app.py: the last 240 completed 15-minute candles of each yen cross,
 * r15 = ln(close_i / close_{i-1}) only for bars 15 minutes apart, r60 = sum of four consecutive r15,
 * VR = var(r60) / (4 var(r15)) (sample variances; >= 100 r15 and >= 40 r60); the yen value = mean over the pairs that have one (>= 3 of 5).
 * VR > 1: 15-minute moves kept going for the next hour (Sep-Oct 2026 type). Research (current model, 1 year out of sample):
 * VR <= 1.0 won 54.0% (72.5% of entries), 1.0-1.1 won 52.6% (18.7%), > 1.1 won 51.3% (8.8%).
 */
object RunRegime {
    val PAIRS = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY")
    const val BARS = 240
    const val STEP_MS = 15 * 60_000L
    const val WARN = 1.0
    const val HOT = 1.1
    enum class Level { UNKNOWN, CALM, RUNS, STRONG_RUNS }
    data class State(val level: Level, val yen: Double?, val pairs: Map<String, Double?>, val updatedAtMs: Long)

    /** VR of one pair from its completed 15-minute candles (null when there is not enough data). */
    fun pairVr(candles: List<Candle>, nowMs: Long): Double? {
        val done = candles.filter { it.timeEpochMs + STEP_MS <= nowMs && it.close > 0.0 && it.close.isFinite() }
            .sortedBy { it.timeEpochMs }.distinctBy { it.timeEpochMs }.takeLast(BARS)
        if (done.size < 5) return null
        val r = DoubleArray(done.size - 1) { i ->
            if (done[i + 1].timeEpochMs - done[i].timeEpochMs == STEP_MS) kotlin.math.ln(done[i + 1].close) - kotlin.math.ln(done[i].close) else Double.NaN
        }
        val r15 = r.filter { !it.isNaN() }
        if (r15.size < 100) return null
        val r60 = ArrayList<Double>()
        for (i in 3 until r.size) {
            var s = 0.0; var ok = true
            for (j in i - 3..i) { if (r[j].isNaN()) { ok = false; break }; s += r[j] }
            if (ok) r60.add(s)
        }
        if (r60.size < 40) return null
        val v15 = sampleVar(r15); if (!(v15 > 0.0)) return null
        return sampleVar(r60) / (4.0 * v15)
    }

    private fun sampleVar(x: List<Double>): Double {
        var m = 0.0; for (v in x) m += v; m /= x.size
        var s = 0.0; for (v in x) s += (v - m) * (v - m)
        return s / (x.size - 1)
    }

    fun of(candles: Map<String, List<Candle>>, nowMs: Long): State {
        val pairs = PAIRS.associateWith { p -> candles[p]?.let { pairVr(it, nowMs) } }
        val vals = pairs.values.filterNotNull()
        val yen = if (vals.size >= 3) vals.sum() / vals.size else null
        val level = when { yen == null -> Level.UNKNOWN; yen > HOT -> Level.STRONG_RUNS; yen > WARN -> Level.RUNS; else -> Level.CALM }
        return State(level, yen, pairs, nowMs)
    }

    fun label(s: State?): String = when (s?.level) {
        null, Level.UNKNOWN -> "相場: 集計中（15分足72時間分を取得中）"
        Level.CALM -> "相場: 戻りやすい（続きやすさ ${"%.2f".format(s.yen)}）過去1年この状態の勝率 54.0%"
        Level.RUNS -> "注意: 走りやすい相場（続きやすさ ${"%.2f".format(s.yen)}）過去1年この状態の勝率 52.6%（9〜10月型）"
        Level.STRONG_RUNS -> "警戒: とても走りやすい相場（続きやすさ ${"%.2f".format(s.yen)}）過去1年この状態の勝率 51.3%。逆張りが走られやすい"
    }
}

package jp.gmk.mobile.domain

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.74: the shrine-style display of the prediction screen (display only; no decision, rank, rate or result reads it).
 * - [spellCard]: the TOP1's operational grade as a Reimu spell card name.
 * - [lives]: the current losing streak of ENTRY results as 残機 (5 lives; one lost per loss in a row).
 * - [today]: today's (JST) ENTRY results of the current policy as the 賽銭箱 tally; at the 1.9x payout a win is +0.9 stake, a loss -1.
 */
object ShrineBoard {
    const val LIVES = 5
    const val PAYOUT = 1.9
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    fun spellCard(grade: String, decision: String): String = when {
        decision != "ENTRY" -> if (grade == "I") "判定不能「霧の湖」" else "結界「見送りの陣」"
        grade == "S" -> "「夢想天生」"
        grade == "A" -> "霊符「夢想封印」"
        grade == "B" -> "神技「八方鬼縛陣」"
        grade == "C" -> "夢符「封魔陣」"
        else -> "符の準備中"
    }

    /** v0.7.76: the spell card of a candidate - its C1 / C2 / C3 (or promoted C1) when it has one. */
    fun spellCard(c: ScanCandidate): String =
        c.assessment?.subGrade?.takeIf { c.decision == "ENTRY" || it.promoted }?.let { SubGrades.spellCard(it) } ?: spellCard(c.grade, c.decision)

    /** "★★★☆☆" for 2 losses in a row: one ☆ per loss in a row, at most [LIVES]. */
    fun lives(lossStreak: Int): String {
        val left = (LIVES - lossStreak).coerceIn(0, LIVES)
        return "★".repeat(left) + "☆".repeat(LIVES - left)
    }

    /**
     * v0.7.77: how often losing streaks come by chance at the weekday 5-minute AUTO (every hour 70%; one year scored on other periods:
     * 102.5 entries a day at 53.4%): streaks of at least k losses per day. They are as frequent as
     * chance gives for that win rate (shuffled results: 3+ 5.55, 5+ 1.20, 7+ 0.26, 10+ 0.026 a day; research_v0777/v0777_hours.py).
     */
    val STREAK_ODDS: List<Pair<Int, Double>> = listOf(3 to 5.47, 5 to 1.14, 7 to 0.24, 10 to 0.032)

    /** How usual a current losing streak of [k] is (empty below 3). */
    fun streakVerdict(k: Int): String = when {
        k < 3 -> ""
        k < 5 -> "3連敗以上は1日に何度も起きる（毎時70%で1日5.5回）"
        k < 7 -> "5連敗以上は偶然でも1日に1回ほど起きる（1日1.1回）"
        k < 10 -> "7連敗以上は数日に1回（4日に1回）"
        else -> "10連敗以上は月に1回ほど（1年で8回）。続く時は相場が変わった可能性も"
    }

    fun livesNote(lossStreak: Int): String = when {
        lossStreak <= 0 -> "無傷"
        lossStreak < 3 -> "被弾 ${lossStreak}（${lossStreak}連敗中）"
        lossStreak < LIVES -> "被弾注意 ${lossStreak}連敗中"
        else -> "満身創痍 ${lossStreak}連敗中"
    }

    /** Settled ENTRY rows of the current evidence policies only (older engines are not counted on the shrine board). */
    fun current(rows: List<HistoryRow>): List<HistoryRow> = rows.filter { RankStatistics.evidenceVersion(it.policyVersion) != null }

    /** Losses in a row at the newest end of the current policy's ENTRY results (SKIP / pending / missing do not reset it). */
    fun lossStreak(rows: List<HistoryRow>): Int = historyCombinedStatistics(current(rows)).currentLossStreak

    class Tally(val wins: Int, val losses: Int, val draws: Int, val pending: Int) {
        val resolved: Int get() = wins + losses
        val rate: Double? get() = if (resolved > 0) wins.toDouble() / resolved else null
        /** Stakes won (+) or lost (-) at the 1.9x payout: a win returns 0.9 of the stake, a loss (a draw too) costs 1. */
        val units: Double get() = wins * (PAYOUT - 1.0) - losses
    }

    fun today(rows: List<HistoryRow>, today: LocalDate): Tally = tally(current(rows), today)

    /** v0.7.75: today's 1-minute judgment results (AUTO and manual 1-minute rows of [OneMinutePolicy]). */
    fun todayOneMinute(rows: List<HistoryRow>, today: LocalDate): Tally = tally(rows.filter { OneMinutePolicy.isPolicy(it) }, today)

    /** Losses in a row at the newest end of the 1-minute judgment's ENTRY results. */
    fun lossStreakOneMinute(rows: List<HistoryRow>): Int = historyCombinedStatistics(rows.filter { OneMinutePolicy.isPolicy(it) }).currentLossStreak

    private fun tally(rows: List<HistoryRow>, today: LocalDate): Tally {
        var w = 0; var l = 0; var d = 0; var p = 0
        val key = today.toString()
        for (r in rows) {
            if (r.decision != "ENTRY") continue
            // v0.7.78: the day from the text when it is written in JST (no parse of every row each minute)
            if (jstDayKey(r.entryTimeJst) != key) continue
            when (r.resultStatus) {
                "WIN" -> w++
                "LOSE" -> { l++; if (r.entryRate != null && r.entryRate == r.judgeRate) d++ }
                "WAIT_ENTRY", "WAIT_JUDGE" -> p++
            }
        }
        return Tally(w, l, d, p)
    }

    fun tallyText(t: Tally): String {
        if (t.resolved == 0) return if (t.pending > 0) "判定待ち ${t.pending}件" else "まだ奉納なし"
        val rate = "%.1f".format(100.0 * (t.rate ?: 0.0))
        val units = "%+.1f".format(t.units)
        return "${t.wins}勝 ${t.losses}敗  $rate%  ${units}口" + (if (t.draws > 0) "（グレイズ=同値負け ${t.draws}）" else "") +
            (if (t.pending > 0) "  判定待ち ${t.pending}" else "")
    }

    /**
     * v0.7.75: the time of day as a shooting-game stage (display only): weekday 09-10 仲値 .. 21-22 米国指標, weekends the Extra stage
     * (crypto only), outside 09:00-22:59 a break.
     */
    fun stage(t: ZonedDateTime): String {
        val j = t.withZoneSameInstant(JST); val h = j.hour
        if (h !in 9..22) return "休憩中 — 神社でお茶（本番 09:00〜22:59）"
        if (j.dayOfWeek.value >= 6) return "Extra Stage「仮想通貨の宴」"
        return when (h) {
            9, 10 -> "Stage 1「仲値の刻」"
            11, 12 -> "Stage 2「東京の昼下がり」"
            13, 14, 15 -> "Stage 3「午後の結界」"
            16, 17 -> "Stage 4「欧州の夜明け」"
            18, 19, 20 -> "Stage 5「紅い霧の欧州」"
            else -> "Stage 6「米国指標の嵐」"
        }
    }

    /** v0.7.75 HI-SCORE: the best day (JST) of the current policy's ENTRY results in stakes, or null without a settled day. */
    fun hiScore(rows: List<HistoryRow>): Pair<LocalDate, Double>? {
        val byDay = HashMap<LocalDate, Double>()
        for (r in current(rows)) {
            if (r.decision != "ENTRY" || r.resultStatus !in setOf("WIN", "LOSE")) continue
            val day = jstDayKey(r.entryTimeJst)?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: continue
            byDay[day] = (byDay[day] ?: 0.0) + if (r.resultStatus == "WIN") PAYOUT - 1.0 else -1.0
        }
        return byDay.entries.maxWithOrNull(compareBy<Map.Entry<LocalDate, Double>> { it.value }.thenBy { it.key })?.let { it.key to it.value }
    }
}

package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.max

/** v0.7.62: the "次回AUTOまで" countdown follows the scans that really run. */
object AutoClock {
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    /** Seconds to the next AUTO scan that will run: T-10 before an entry minute :00, :05, ... inside 09:00-23:00 JST, weekday and
     *  weekend (v0.7.66: back to 5 minutes on weekdays; v0.7.58-v0.7.65 scanned every weekday minute). Outside the hours it counts
     *  down to the first scan of the session. A scan that started less than a second ago still shows 0. */
    /**
     * v0.7.75: the one rule for when the 5-minute AUTO scans - at T-10 of an entry at :00, :05, ..., i.e. during the minutes :X4 / :X9 -
     * used by both the view model's scheduler and this countdown. v0.7.67-v0.7.69 scanned every weekday minute because the scheduler
     * kept its own copy of the rule (the countdown, which the tests checked, stayed at 5 minutes).
     */
    fun isScanMinute(t: ZonedDateTime): Boolean = t.withZoneSameInstant(JST).minute % 5 == 4

    fun nextAutoScanSeconds(now: ZonedDateTime): Int {
        val z = now.withZoneSameInstant(JST)
        var entry = z.truncatedTo(ChronoUnit.MINUTES)
        repeat(4 * 24 * 60) {
            val scanAt = entry.minusSeconds(10)
            val ahead = !scanAt.isBefore(z) || ChronoUnit.MILLIS.between(scanAt, z) < 1000L
            val runs = TradingSession.isActive(entry) && isScanMinute(scanAt)
            if (ahead && runs) return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())
            entry = entry.plusMinutes(1)
        }
        return 0
    }

    /** What the AUTO does at the next scan, in the words of the screen (v0.7.66: weekday and weekend both every 5 minutes). */
    fun scheduleText(now: ZonedDateTime): String {
        val next = now.withZoneSameInstant(JST).plusSeconds(nextAutoScanSeconds(now) + 10L)
        return if (TradingSession.isWeekday(next)) "平日: 5分ごとにスキャン（S/Aは3分判定・B/Cは5分判定）" else "土日: 5分ごとにスキャン・3分判定"
    }

    fun countdownText(seconds: Int): String =
        if (seconds >= 3600) String.format("%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
        else String.format("%02d:%02d", seconds / 60, seconds % 60)
}

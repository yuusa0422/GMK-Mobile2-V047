package jp.gmk.mobile.domain

/**
 * v0.7.79: the keys of the history list (リプレイ帳). Without keys the list kept its place by position, so each new row at the top
 * (every minute with the 1-minute judgment) moved what the user was reading by one card. The key is the row's identity
 * ([HistoryArchivePlan.key]: id, scan id, scan time; it stays the same while the result is filled in); a repeated key (an old duplicate
 * row) gets "#2", "#3", ... after a separator no key contains, because the list needs every key once.
 */
object HistoryListKeys {
    fun of(rows: List<HistoryRow>): List<Pair<String, HistoryRow>> {
        val seen = HashMap<String, Int>(rows.size * 2)
        return rows.map { r ->
            val k = HistoryArchivePlan.key(r)
            val n = (seen[k] ?: 0) + 1
            seen[k] = n
            (if (n == 1) k else "$k\u0000#$n") to r
        }
    }
}

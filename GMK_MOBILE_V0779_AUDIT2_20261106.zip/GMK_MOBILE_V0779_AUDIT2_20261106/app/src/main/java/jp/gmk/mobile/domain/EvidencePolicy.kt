package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.floor

/**
 * v0.7.57 final ENTRY decision. Runs after the native scan and every optional overlay.
 * v0.7.57 change (README_V0757.txt): weekday = FX only, time-of-day rules S/A judged at 3 minutes, everything else at 5 minutes.
 *   B = the 3-minute model's strong + confirmed FX trade (57.6% at 5 minutes); C = the best FX trade of a 5-minute model
 *   ([EvidenceModel5Data], same 46 inputs) at or above the hour's cut, so every hour enters about 60% of its slots with S/A/B:
 *   53.25% at 82.6/day (periods 52.6 / 53.9 / 53.3; 3-minute judgement of the same design 52.0%). D = 5-minute trades below the cut.
 *   Weekend unchanged (3 minutes). The judgement length is in the label (【3分判定】/【5分判定】), the note (HZ=) and judgeTimeJst.
 * v0.7.56 change (README_V0756.txt): the user's setting [EntryMode] decides how many slots are entered. Grades are the same in
 *   every mode: C = the 60% tier (weekday former C with rank strength in the top 71% -> S+A+B+C = 60% of weekday slots, 52.8%;
 *   weekend every slot in the top 60% by strength minus B, 47.9%). Weekday 60%: 82.5/day at 53.6% (periods 53.1 / 54.2 / 53.5);
 *   weekend 60%: 100.8/day at 49.1%. 55% is not reached at 60% of slots by any ordering of the year (55% holds up to about 20%
 *   of weekday slots and 10% of weekend slots). The note records MODE=<key>.
 * v0.7.55 change (README_V0755.txt): ENTRY only where one year scored on other periods is 55% or more. Weekday S/A (rules) and
 *   B (strong + confirmed) enter, every former C is skipped (D, 52.2%); weekend the strongest tier enters only when it does not
 *   chase the hour (B, 57.1%). Weekday ENTRY 57.6% at 13.6/day (was 52.9% at 110), weekend 57.1% at 13.1/day (was 54.0% at 21.5).
 *   The note records the age of the live price used (qage) so real results can be checked by age.
 * v0.7.54 change (README_V0754.txt): losing contexts skipped - weekday 09:00-09:55 model C (48.8%) -> E, weekend model C (48.3%)
 *   -> D (weekend ENTRY = B only, 54.0%). Losing streaks on weekdays are at the level independent 52.7% trades produce.
 * v0.7.53 change (README_V0753.txt): more time-of-day rules - US data 8:30 New York (2), UK data 9:30 London and a second
 *   9:55 fix rule, from a list of event minutes written down before looking - and the rule grade is S when at least 3 of the
 *   4 other fade signals agree (else A). S 68.2% at 1.0/day (was 67.7% at 0.5/day), A 60.1% at 2.5/day (was 61.4% at 1.5/day);
 *   S+A 3.4/day at 62.4% (was 2.0/day).
 * v0.7.52 change (README_V0752.txt): weekday B = strong model trade (v0.7.48 S/A) confirmed by the last-minute move
 *   (FX fades a >= 2.5 sigma 1-minute spike / BTC follows a 1..3 sigma move): 56.3% (10/day; periods 54.6 / 58.3 / 56.6);
 *   every other ENTRY is C (52.0%). Win/lose pattern searches inside B and C (single features, pairs, a 56-feature model)
 *   found nothing that held on the held-out periods, and reversing losing patterns lost (39.5-48.2%).
 * v0.7.51 change (README_V0751.txt): ranks rebuilt from out-of-period evidence only.
 *   - S/A = time-of-day rules ([EventRules]): weekday Tokyo fix 9:55 (S), Tokyo lunch 12:20, New York morning 22:50 JST and
 *     London 7:25 (A); the rule trade replaces the model's choice at those minutes. One year S 67.7% / A 61.4%.
 *   - B/C = the model trade by the v0.7.48 strength ladder (weekday S+A -> B 54.3%, B+C -> C 51.6%; weekend S -> B 54.0%,
 *     A+B -> C 48.3%); D..H = v0.7.48 skips with their reasons.
 *   - the v0.7.49 pattern grades and reversals are no longer used: on periods they were not found in, pattern trades won
 *     53.3% (all entries 52.5%) and reversals 45.5% (52.7% unreversed).
 *   - October calendar ([MarketCalendar]): ECB 29 Oct and BOJ 30 Oct announcement windows are not entered.
 *   - session/weekday/October context added to the ranking model did not improve the out-of-period order
 *     (October-weighted training ranked the other October worse), so the model ladder is unchanged.
 *   - rolling distributions are kept across app restarts ([exportState]/[importState]).
 * v0.7.49 change (user decision: the chart patterns found in the year are treated as real):
 *   - the chosen trade matching a same-direction WIN pattern -> ENTRY, grade by the pattern's one-year rate
 *     (S >= 65%, A >= 62%, B otherwise); a REVERSAL pattern (the chosen side loses, the other side won >= 56% in every
 *     period) -> trade the opposite side, graded the same way; other ENTRY -> C; skips keep D..H (v0.7.48 strength).
 *   - one-year rates by grade are those of the data the patterns were found in (weekday S 64.7 / A 61.7 / B 56.7 / C 49.7).
 *     Other-period check (patterns found on two periods, scored on the third): same-direction >= 62% patterns 53.3%,
 *     reversal 45.5% vs 52.7% unreversed. See README_V0749.txt.
 * v0.7.48 change: second-stage strength (EvidenceStrength) decides ENTRY and the S..H ladder; every skip has a reason.
 *   Weekday: ENTER the strongest 85% of the rolling 288 slots (was 74%); S/A/B/C by a rank strength that also knows
 *   09h/10h/Monday; skipped slots D (upper half) / E. Weekend: ENTER when strength >= fixed cut (about 55%, was 47%);
 *   S/A/B/C and D..H by strength. Out of sample (other half): weekday 52.5% (was 52.5% at 74%), S 54.8 / A 54.1 /
 *   B 52.9 / C 51.1 / D 50.5 / E 48.8; weekend 49.6% (was 49.4% at 47%), S 54.0 / A 50.2 / B 47.0 / C 47.3 /
 *   D 41.7 / E 42.2 / F 38.0 / G 33.6 / H 25.9. Reversing skipped trades never helped (24-48%).
 * v0.7.47 change: grade S = top 10% of recent slots (entries unchanged; S/A/B/C are all ENTRY).
 *   Out of sample (rolling rule, other-half model): weekday S 54.0% (both halves 54.4 / 53.5, about 15 per day,
 *   max 11 losses in a row on S alone), A 53.3%, B 51.6%, C 52.2%; weekend S 52.8%, A 49.7%, B 47.6%.
 * v0.7.46 change: the model is the average of five seeds (EvidenceEnsemble). Same inputs and rule; less variance.
 *   Out of sample, same number of entries: weekday 52.5% (both halves 52.4 / 52.5), October 2025 51.8%,
 *   October 2026 52.0%, days with 8+ losses 12.7% (single model 17.5%).
 * v0.7.45 change: weekend BTC uses a 576-slot window (about two weekend days) and a 47% quota, so quiet,
 * draw-heavy weekend days receive fewer entries and active days more (weekend entry count unchanged on average).
 * Loss/streak study: weekday losses are independent (autocorrelation ~0, runs test, daily dispersion 1.0);
 * weekend losses cluster by day (quiet days: 35% draws, 43.6% wins vs 53.2% on active days).
 *
 * Research (README_V0744.txt, one year of real 1-minute candles 2025-10-01..2026-10-21, the app's
 * exact six-instrument scan, true JST clock, DRAW = LOSE, model trained on one half and tested on the other):
 *  - current app: weekday 50.5% at 73.9% of slots, weekend BTC 47.6% at 46.1% (15% draws), max 18 losses.
 *  - this policy, same number of entries: weekday 51.9% (A 53.1 / B 51.7 / C 50.8), weekend 49.3%
 *    (A 50.8 / B 47.6; BTC 57.8% when draws are excluded). Backup model without a live price: 50.7% / 47.8%.
 *  - the gain comes mainly from the last minute before entry (fade sharp FX moves, follow BTC moves on
 *    bitbank) and from avoiding draw-prone BTC moments; see README_V0744.txt for the full table.
 *
 * Decision (every 5-minute slot, 09:00-22:55 JST, weekday six instruments, weekend BTCJPY):
 *  1) score every candidate instrument x {HIGH, LOW} with the gradient-boosted evidence model
 *     (fresh model when every candidate has a live quote taken within 40 s before entry, else backup model)
 *  2) take the best (instrument, direction); hour-adjust its probability
 *  3) percentile of the hour-adjusted probability among recent slots (rolling 288 weekday / 576 weekend AUTO slots;
 *     one-year table until 96 slots are seen), then the second-stage strength (EvidenceStrength)
 *  4) weekday: ENTER the top 85% of recent strengths; weekend: ENTER when strength >= the one-year 55% cut
 *  5) grades S/A/B/C (ENTRY) and D..H (SKIP, with the reason that pulled the strength down); I = no decision possible
 */
object EvidencePolicy {
    const val VERSION = "V0771_CRYPTO9"
    const val POLICY_TAG = "GMK_V0740_V0759_EVIDENCE"

    /** v0.7.58: exact 5-minute boundary (time-of-day rules, B and the rolling distributions are boundary-only, as in the research). */
    fun isBoundary(entry: ZonedDateTime): Boolean = entry.second == 0 && entry.nano == 0 && entry.minute % 5 == 0
    fun isBoundaryText(entryTimeJst: String): Boolean = runCatching { isBoundary(ZonedDateTime.parse(entryTimeJst)) }.getOrDefault(false)
    const val MAX_STATE_AGE_SEC = 21L * 24 * 3600
    const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER
    const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER
    const val WEEKDAY_BUFFER_SIZE = 288
    const val WEEKEND_BUFFER_SIZE = 576
    const val BUFFER_MIN = 96
    fun bufferLimit(weekend: Boolean): Int = if (weekend) WEEKEND_BUFFER_SIZE else WEEKDAY_BUFFER_SIZE
    const val LIVE_MAX_AGE_MS = 40_000L
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    data class LiveQuote(val price: Double, val epochMs: Long)
    /** [inputs] carries the chosen instrument's strength inputs (pct is filled in by [decide]); null = neutral inputs. */
    data class Choice(val instrument: String, val direction: String, val probability: Double, val adjusted: Double, val fresh: Boolean,
                      val inputs: EvidenceStrength.Inputs? = null, val patternCodes: IntArray? = null)
    data class Decision(val choice: Choice, val pct: Double, val strength: Double, val rankStrength: Double, val enter: Boolean, val grade: String,
                        val fromSeed: Boolean, val reasonGroup: String, val reason: String)

    private class Models(val entry: EvidenceStrength.Model, val rank: EvidenceStrength.Model)
    private fun models(fresh: Boolean, weekend: Boolean): Models = when {
        fresh && !weekend -> Models(EvidenceStrengthData.FRESH_WEEKDAY_ENTRY, EvidenceStrengthData.FRESH_WEEKDAY_RANK)
        fresh -> Models(EvidenceStrengthData.FRESH_WEEKEND, EvidenceStrengthData.FRESH_WEEKEND)
        !weekend -> Models(EvidenceStrengthData.FALLBACK_WEEKDAY_ENTRY, EvidenceStrengthData.FALLBACK_WEEKDAY_RANK)
        else -> Models(EvidenceStrengthData.FALLBACK_WEEKEND, EvidenceStrengthData.FALLBACK_WEEKEND)
    }

    /** v0.7.51 one-year out-of-period rate of a final grade ([RankLadder]). */
    fun gradeRate(fresh: Boolean, weekend: Boolean, grade: String): Double? = RankLadder.rate(fresh, weekend, grade)?.year

    /** One-year validated win rates of the v0.7.48 strength ladder (strength fitted on the other half, same decision rule). */
    fun validatedRate(fresh: Boolean, weekend: Boolean, grade: String): Double? = when {
        fresh && !weekend -> EvidenceStrengthData.FRESH_WEEKDAY_VALIDATED
        fresh -> EvidenceStrengthData.FRESH_WEEKEND_VALIDATED
        !weekend -> EvidenceStrengthData.FALLBACK_WEEKDAY_VALIDATED
        else -> EvidenceStrengthData.FALLBACK_WEEKEND_VALIDATED
    }[grade]

    // ---------------- live quotes ----------------

    fun quotesFromRates(rows: List<RateRow>): Map<String, LiveQuote> = rows.mapNotNull { r ->
        val p = r.price; val t = r.sourceEpochMs
        if (p != null && p.isFinite() && p > 0.0 && t != null && t > 0L && r.freshnessStatus == "LIVE") r.instrument to LiveQuote(p, t) else null
    }.toMap()

    fun newestQuotes(vararg sources: Map<String, LiveQuote>): Map<String, LiveQuote> {
        val out = HashMap<String, LiveQuote>()
        for (s in sources) for ((k, q) in s) { val old = out[k]; if (old == null || q.epochMs > old.epochMs) out[k] = q }
        return out
    }

    /** Live price for [instrument] taken in [B-40 s, B+1 s]; null when missing or stale. */
    fun freshPrice(quotes: Map<String, LiveQuote>, instrument: String, boundaryEpochSec: Long): Double? {
        val q = quotes[instrument] ?: return null
        val b = boundaryEpochSec * 1000L
        return if (q.price.isFinite() && q.price > 0.0 && q.epochMs >= b - LIVE_MAX_AGE_MS && q.epochMs <= b + 1_000L) q.price else null
    }

    // ---------------- adaptive threshold state ----------------

    private class Buffer { val boundaries = ArrayDeque<Long>(); val values = ArrayDeque<Double>(); val strengths = ArrayDeque<Double>() }
    private val buffers = ConcurrentHashMap<String, Buffer>()
    private fun key(fresh: Boolean, weekend: Boolean) = (if (fresh) "fresh" else "fallback") + "|" + (if (weekend) "weekend" else "weekday")

    @Synchronized fun resetState() = buffers.clear()

    private const val STATE_HEADER = "GMK_EVIDENCE_STATE_V1"
    private val STATE_KEYS = setOf(key(true, false), key(true, true), key(false, false), key(false, true))

    /**
     * v0.7.51: the rolling distributions as text (one line per buffer: key<TAB>boundary,adjusted,strength;...).
     * Up to v0.7.50 they lived in memory only, so every app restart used the one-year seed again for the next 96 AUTO slots.
     */
    @Synchronized fun exportState(): String {
        val sb = StringBuilder(STATE_HEADER)
        for (name in buffers.keys.sorted()) {
            val buf = buffers.getValue(name)
            sb.append('\n').append(name).append('\t')
            for (i in 0 until buf.values.size) sb.append(if (i == 0) "" else ";").append(buf.boundaries[i]).append(',').append(buf.values[i]).append(',').append(buf.strengths[i])
        }
        return sb.toString()
    }

    /**
     * Restores [exportState] text when nothing has been recorded yet in this process. Any malformed line rejects the whole
     * text (seed is used instead); entries older than [MAX_STATE_AGE_SEC] are dropped. Returns the number of slots restored.
     */
    @Synchronized fun importState(text: String?, nowEpochSec: Long): Int {
        if (text.isNullOrBlank() || buffers.values.any { it.values.isNotEmpty() }) return 0
        val lines = text.split('\n')
        if (lines.first() != STATE_HEADER) return 0
        val parsed = HashMap<String, Buffer>()
        for (line in lines.drop(1)) {
            if (line.isBlank()) continue
            val tab = line.indexOf('\t')
            if (tab < 0) return 0
            val name = line.substring(0, tab)
            val items = line.substring(tab + 1).split(';').filter { it.isNotEmpty() }
            if (name !in STATE_KEYS || name in parsed) return 0
            val buf = Buffer(); var last = Long.MIN_VALUE
            for (item in items) {
                val f = item.split(',')
                if (f.size != 3) return 0
                val boundary = f[0].toLongOrNull() ?: return 0
                val adjusted = f[1].toDoubleOrNull() ?: return 0
                val strength = f[2].toDoubleOrNull() ?: return 0
                if (boundary <= last || boundary > nowEpochSec + 600L || !adjusted.isFinite() || !strength.isFinite()) return 0
                last = boundary
                if (nowEpochSec - boundary > MAX_STATE_AGE_SEC) continue
                buf.boundaries.addLast(boundary); buf.values.addLast(adjusted); buf.strengths.addLast(strength)
            }
            val limit = bufferLimit(name.endsWith("weekend"))
            while (buf.values.size > limit) { buf.values.removeFirst(); buf.boundaries.removeFirst(); buf.strengths.removeFirst() }
            parsed[name] = buf
        }
        buffers.clear(); buffers.putAll(parsed)
        return parsed.values.sumOf { it.values.size }
    }
    @Synchronized fun bufferSize(fresh: Boolean, weekend: Boolean): Int = buffers[key(fresh, weekend)]?.values?.size ?: 0

    /** numpy.quantile(..., method="linear") */
    fun quantile(values: List<Double>, q: Double): Double {
        require(values.isNotEmpty())
        val a = values.sorted(); val pos = q * (a.size - 1)
        val lo = floor(pos).toInt(); val hi = ceil(pos).toInt()
        return a[lo] + (a[hi] - a[lo]) * (pos - lo)
    }

    /** Share of [values] strictly below [a] (numpy: (ref < a).mean()). */
    fun shareBelow(values: Collection<Double>, a: Double): Double {
        var n = 0; for (v in values) if (v < a) n++
        return n.toDouble() / values.size
    }

    /** Percentile of [a] in the one-year table (201 quantiles), linear between points. Used until 96 slots are seen. */
    fun seedPct(table: DoubleArray, a: Double): Double {
        if (a <= table.first()) return 0.0
        if (a >= table.last()) return 1.0
        var i = 0
        while (i < table.size - 2 && table[i + 1] <= a) i++
        val span = table[i + 1] - table[i]
        val frac = if (span > 0.0) (a - table[i]) / span else 0.0
        return (i + frac) / (table.size - 1)
    }

    private fun seedTable(fresh: Boolean, weekend: Boolean): DoubleArray = when {
        fresh && !weekend -> EvidenceStrengthData.FRESH_WEEKDAY_ADJ_QUANTILES
        fresh -> EvidenceStrengthData.FRESH_WEEKEND_ADJ_QUANTILES
        !weekend -> EvidenceStrengthData.FALLBACK_WEEKDAY_ADJ_QUANTILES
        else -> EvidenceStrengthData.FALLBACK_WEEKEND_ADJ_QUANTILES
    }

    /** Neutral inputs for callers without candle features (tests): no last-minute move, average volatility. */
    fun neutralInputs(choice: Choice, hourJst: Int = 12, dayOfWeek: Int = 3) = EvidenceStrength.Inputs(
        choice.instrument, if (choice.direction == "HIGH") 1 else -1, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, hourJst, dayOfWeek)

    fun hourOffset(fresh: Boolean, weekend: Boolean, hourJst: Int): Double {
        val arr = when {
            fresh && !weekend -> EvidenceModelData.FRESH_WEEKDAY_HOUR_OFFSET
            fresh -> EvidenceModelData.FRESH_WEEKEND_HOUR_OFFSET
            !weekend -> EvidenceModelData.FALLBACK_WEEKDAY_HOUR_OFFSET
            else -> EvidenceModelData.FALLBACK_WEEKEND_HOUR_OFFSET
        }
        return arr[(hourJst - 9).coerceIn(0, arr.size - 1)]
    }

    /** Strength decision; [record] appends this slot to the rolling distributions (AUTO slots only). */
    @Synchronized
    fun decide(choice: Choice, weekend: Boolean, boundaryEpochSec: Long, record: Boolean): Decision {
        val buf = buffers.getOrPut(key(choice.fresh, weekend)) { Buffer() }
        val fromSeed = buf.values.size < BUFFER_MIN
        val pct = if (fromSeed) seedPct(seedTable(choice.fresh, weekend), choice.adjusted) else shareBelow(buf.values, choice.adjusted)
        val x = (choice.inputs ?: neutralInputs(choice)).copy(pct = pct)
        val m = models(choice.fresh, weekend)
        val e = EvidenceStrength.probability(m.entry, x)
        val r = if (weekend) e else EvidenceStrength.probability(m.rank, x)
        val enter: Boolean
        val grade: String
        if (!weekend) {
            val strengthSeed = buf.strengths.size < BUFFER_MIN
            val q = if (strengthSeed) null else shareBelow(buf.strengths, e)
            val seedEnter = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKDAY_SEED_ENTER else EvidenceStrengthData.FALLBACK_WEEKDAY_SEED_ENTER
            val seedDe = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKDAY_SEED_DE else EvidenceStrengthData.FALLBACK_WEEKDAY_SEED_DE
            enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE
            val upperSkip = if (q == null) e >= seedDe else q >= (1.0 - WEEKDAY_ENTRY_RATE) / 2.0
            val c = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKDAY_RANK_CUTS else EvidenceStrengthData.FALLBACK_WEEKDAY_RANK_CUTS
            grade = if (enter) (if (r >= c[0]) "S" else if (r >= c[1]) "A" else if (r >= c[2]) "B" else "C") else if (upperSkip) "D" else "E"
        } else {
            val c = if (choice.fresh) EvidenceStrengthData.FRESH_WEEKEND_CUTS else EvidenceStrengthData.FALLBACK_WEEKEND_CUTS
            enter = e >= c[0]
            grade = if (enter) (if (e >= c[1]) "S" else if (e >= c[2]) "A" else if (e >= c[3]) "B" else "C")
                else if (e >= c[4]) "D" else if (e >= c[5]) "E" else if (e >= c[6]) "F" else if (e >= c[7]) "G" else "H"
        }
        val group = EvidenceStrength.dominantGroup(if (enter) m.rank else m.entry, x, weakest = !enter)
        val reason = (if (enter) EvidenceStrength.REASON_STRONG else EvidenceStrength.REASON_SKIP).getValue(group)
        if (record && buf.boundaries.lastOrNull() != boundaryEpochSec) {
            buf.boundaries.addLast(boundaryEpochSec); buf.values.addLast(choice.adjusted); buf.strengths.addLast(e)
            while (buf.values.size > bufferLimit(weekend)) { buf.values.removeFirst(); buf.boundaries.removeFirst(); buf.strengths.removeFirst() }
        }
        return Decision(choice, pct, e, r, enter, grade, fromSeed, group, reason)
    }

    // ---------------- model choice ----------------

    /** Best (instrument, direction) for this slot, or null when no candidate has a 61-minute window. */
    fun choose(native: ScanResult, candles: Map<String, List<Candle>>, quotes: Map<String, LiveQuote>, entry: ZonedDateTime,
               fiveMinute: Boolean = false, openByDirection: Map<String, Int> = emptyMap()): Choice? {
        val j = entry.withZoneSameInstant(JST)
        val weekend = !TradingSession.isWeekday(j)
        val b = entry.toEpochSecond()
        val boundary = isBoundary(entry)
        // v0.7.57: the 5-minute model chooses among the five FX pairs only (weekday); the 3-minute model keeps its pool
        val pool = native.candidates.filter { if (fiveMinute) it.instrument != "BTCJPY" else (!weekend || it.instrument == "BTCJPY") }
            .sortedBy { EvidenceFeatures.INSTRUMENTS.indexOf(it.instrument).let { i -> if (i < 0) 99 else i } }
        if (pool.isEmpty()) return null
        val live = pool.associate { it.instrument to freshPrice(quotes, it.instrument, b) }
        val fresh = live.values.all { it != null }
        val feats = LinkedHashMap<String, EvidenceFeatures.Instrument>()
        for (c in pool) EvidenceFeatures.instrument(c.instrument, candles[c.instrument].orEmpty(), b, if (fresh) live[c.instrument] else null)?.let { feats[c.instrument] = it }
        if (feats.isEmpty()) return null
        val yen = EvidenceFeatures.yenFactor(feats)
        val model = if (fiveMinute) (if (fresh) EvidenceEnsemble.fresh5 else EvidenceEnsemble.fallback5)
            else if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback
        var best: Choice? = null; var bestScore = Double.NEGATIVE_INFINITY
        for (c in pool) {
            val x = feats[c.instrument] ?: continue
            for (d in intArrayOf(1, -1)) {
                val x0 = EvidenceFeatures.design(x, yen, c, j.hour, weekend, d, fresh)
                // v0.7.58: the every-minute 5-minute model has one more input, isk0 (1 = exact 5-minute boundary)
                val p = model.probability(if (fiveMinute) x0 + doubleArrayOf(if (boundary) 1.0 else 0.0) else x0)
                // v0.7.59: on the five yen crosses the same direction is the same yen bet; every open trade in that direction lowers
                // its score (the trade's probability itself is unchanged and is what the hour's cut is compared with)
                val score = if (fiveMinute) p - RankLadder.SAME_DIRECTION_PENALTY * (openByDirection[if (d == 1) "HIGH" else "LOW"] ?: 0) else p
                if (best == null || score > bestScore) {
                    bestScore = score
                    best = Choice(c.instrument, if (d == 1) "HIGH" else "LOW", p, if (fiveMinute) p else p - hourOffset(fresh, weekend, j.hour), fresh,
                        EvidenceStrength.Inputs.of(x, d, j.hour, j.dayOfWeek.value))
                }
            }
        }
        return best
    }

    /**
     * v0.7.71 weekday 5-minute trade: the candle-only model ([CandleModel9], [EvidenceEnsemble.fresh9]) over the five yen crosses
     * ([candles], live prices [quotes]) and the four cryptos ([crypto] candles from Coinbase, live prices [cryptoQuotes]).
     * fresh = every yen cross has a live price taken in [B-40 s, B+1 s]; then a crypto pair without one is left out of the pool
     * (never decided on a stale price). Without fresh yen prices the backup model decides (live block = 0), crypto included.
     */
    fun choose9(candles: Map<String, List<Candle>>, crypto: Map<String, List<Candle>>, quotes: Map<String, LiveQuote>,
                cryptoQuotes: Map<String, LiveQuote>, entry: ZonedDateTime, openByDirection: Map<String, Int> = emptyMap()): Choice? {
        val m = prep9(candles, crypto, quotes, cryptoQuotes, entry) ?: return null
        var best: Choice? = null; var bestScore = Double.NEGATIVE_INFINITY
        for (s in CandleModel9.INSTRUMENTS) {
            val x = m.feats[s] ?: continue
            for (d in intArrayOf(1, -1)) {
                val p = m.model.probability(CandleModel9.design(x, m.basket, m.hour, d, m.fresh))
                val score = p - RankLadder.SAME_DIRECTION_PENALTY * (openByDirection[if (d == 1) "HIGH" else "LOW"] ?: 0)
                if (best == null || score > bestScore) {
                    bestScore = score
                    best = Choice(s, if (d == 1) "HIGH" else "LOW", p, p, m.fresh, EvidenceStrength.Inputs.of(x, d, m.hour, m.dayOfWeek))
                }
            }
        }
        return best
    }

    private class Prepared(val hour: Int, val dayOfWeek: Int, val fresh: Boolean, val feats: Map<String, EvidenceFeatures.Instrument>,
                           val basket: CandleModel9.Basket, val model: EvidenceEnsemble)

    /** The inputs of [choose9] (pool, fresh / backup model, features, basket); [scores9] reads the same ones. */
    private fun prep9(candles: Map<String, List<Candle>>, crypto: Map<String, List<Candle>>, quotes: Map<String, LiveQuote>,
                      cryptoQuotes: Map<String, LiveQuote>, entry: ZonedDateTime): Prepared? {
        val j = entry.withZoneSameInstant(JST); val b = entry.toEpochSecond()
        val fxPool = TradingSession.FX.filter { candles[it] != null }
        val fresh = fxPool.isNotEmpty() && fxPool.all { freshPrice(quotes, it, b) != null }
        val feats = LinkedHashMap<String, EvidenceFeatures.Instrument>()
        for (s in fxPool) EvidenceFeatures.instrument(s, candles[s].orEmpty(), b, if (fresh) freshPrice(quotes, s, b) else null)?.let { feats[s] = it }
        for (s in CryptoPairs.ALL) {
            val rows = crypto[s] ?: continue
            val live = freshPrice(cryptoQuotes, s, b)
            if (fresh && live == null) continue
            EvidenceFeatures.instrument(s, rows, b, if (fresh) live else null)?.let { feats[s] = it }
        }
        if (feats.isEmpty()) return null
        return Prepared(j.hour, j.dayOfWeek.value, fresh, feats, CandleModel9.basket(feats), if (fresh) EvidenceEnsemble.fresh9 else EvidenceEnsemble.fallback9)
    }

    /** v0.7.73 decision log: every pair's HIGH / LOW probability of one slot (same model and inputs as the decision). */
    data class PairScore(val instrument: String, val high: Double, val low: Double)
    data class SlotScores(val fresh: Boolean, val pairs: List<PairScore>)

    fun scores9(candles: Map<String, List<Candle>>, crypto: Map<String, List<Candle>>, quotes: Map<String, LiveQuote>,
                cryptoQuotes: Map<String, LiveQuote>, entry: ZonedDateTime): SlotScores? {
        val m = prep9(candles, crypto, quotes, cryptoQuotes, entry) ?: return null
        return SlotScores(m.fresh, CandleModel9.INSTRUMENTS.mapNotNull { s -> m.feats[s]?.let { x ->
            PairScore(s, m.model.probability(CandleModel9.design(x, m.basket, m.hour, 1, m.fresh)), m.model.probability(CandleModel9.design(x, m.basket, m.hour, -1, m.fresh))) } })
    }

    fun scoresWeekend(crypto: Map<String, List<Candle>>, cryptoQuotes: Map<String, LiveQuote>, entry: ZonedDateTime): SlotScores? {
        val j = entry.withZoneSameInstant(JST); val b = entry.toEpochSecond()
        val withLive = CryptoPairs.ALL.filter { crypto[it] != null && freshPrice(cryptoQuotes, it, b) != null }
        val fresh = withLive.isNotEmpty()
        val pool = if (fresh) withLive else CryptoPairs.ALL.filter { crypto[it] != null }
        val model = if (fresh) EvidenceEnsemble.freshW else EvidenceEnsemble.fallbackW
        val rows = pool.mapNotNull { s -> EvidenceFeatures.instrument(s, crypto[s].orEmpty(), b, if (fresh) freshPrice(cryptoQuotes, s, b) else null)?.let { x ->
            PairScore(s, model.probability(CandleModelW.design(x, j.hour, 1, fresh)), model.probability(CandleModelW.design(x, j.hour, -1, fresh))) } }
        return if (rows.isEmpty()) null else SlotScores(fresh, rows)
    }

    /**
     * v0.7.71 weekend trade: the weekend model over the four cryptos (Coinbase). fresh when at least one pair has a live price taken in
     * [B-40 s, B+1 s] (pairs without one are left out); with none, the backup model over all four. null when no pair has a window.
     */
    fun chooseWeekend(crypto: Map<String, List<Candle>>, cryptoQuotes: Map<String, LiveQuote>, entry: ZonedDateTime): Choice? {
        val j = entry.withZoneSameInstant(JST); val b = entry.toEpochSecond()
        val withLive = CryptoPairs.ALL.filter { crypto[it] != null && freshPrice(cryptoQuotes, it, b) != null }
        val fresh = withLive.isNotEmpty()
        val pool = if (fresh) withLive else CryptoPairs.ALL.filter { crypto[it] != null }
        var best: Choice? = null
        val model = if (fresh) EvidenceEnsemble.freshW else EvidenceEnsemble.fallbackW
        for (s in pool) {
            val x = EvidenceFeatures.instrument(s, crypto[s].orEmpty(), b, if (fresh) freshPrice(cryptoQuotes, s, b) else null) ?: continue
            for (d in intArrayOf(1, -1)) {
                val p = model.probability(CandleModelW.design(x, j.hour, d, fresh))
                if (best == null || p > best.probability) best = Choice(s, if (d == 1) "HIGH" else "LOW", p, p, fresh, EvidenceStrength.Inputs.of(x, d, j.hour, j.dayOfWeek.value))
            }
        }
        return best
    }

    /** v0.7.71 weekend decision: B = the top 8% of weekend slots (every mode), C = the top 60% (only in the "毎日（土日60%）" mode), else D. */
    private fun weekendCrypto(native: ScanResult, result: ScanResult, wk: Choice, mode: EntryMode, entry: ZonedDateTime, quoteAgeMs: Long?,
                              promoteC1: Boolean = false): ScanResult {
        val h = (entry.withZoneSameInstant(JST).hour - 9).coerceIn(0, 13)
        val b8 = (if (wk.fresh) EvidenceModelWData.FRESH_B8 else EvidenceModelWData.FALLBACK_B8)[h]
        val c60 = (if (wk.fresh) EvidenceModelWData.FRESH_C60 else EvidenceModelWData.FALLBACK_C60)[h]
        val grade0 = if (wk.probability >= b8) "B" else if (wk.probability >= c60) "C" else "D"
        // v0.7.76: C1 / C2 / C3 by the place in the weekend hour's table ([EvidenceSlotWData]); B / C / D stay on B8 / C60
        val sub = if (grade0 == "C") SubGrades.promote(SubGrades.of(SubGrades.WEEKEND, "C",
            SubGrades.weekend(wk.fresh, entry.withZoneSameInstant(JST).hour, wk.probability), wk.probability, wk.fresh), promoteC1) else null
        val grade = if (sub?.promoted == true) "B" else grade0
        val enter = mode.enters(grade, true)
        val minutes = 3
        fun pc(x: Double) = "%.1f%%".format(x * 100.0)
        val table = RankLadder.rate(wk.fresh, true, grade)
        val rateText = sub?.rate?.let { "検証 ${pc(it)}" } ?: table?.let { "検証 ${pc(it.year)}" + (it.october?.let { o -> "・10月 ${pc(o)}" } ?: "") } ?: "検証の記録なし"
        val shown = sub?.shown ?: grade
        val subText = sub?.let { " / Cの中の強さ ${SubGrades.text(it)}" } ?: ""
        val ageText = quoteAgeMs?.let { "直前価格 ${String.format(java.util.Locale.US, "%.1f", it / 1000.0)}秒前" } ?: "直前価格なし"
        val modelLabel = if (wk.fresh) ageText else "直前価格なし・予備モデル"
        val pair = CryptoPairs.display(wk.instrument)
        val label = "【3分判定】" + when {
            enter -> "土日モデル $shown（仮想通貨4つ・$rateText）$pair ${wk.direction} / 3分で勝つ確率 ${pc(wk.probability)}" +
                // v0.7.78: a promoted C1 is below the top-8% bar (it read as if it had passed it)
                (if (sub?.promoted == true) "（上位8%の基準 ${pc(b8)} 未満のC1から昇格）" else "（上位8%の基準 ${pc(b8)}）") + "$subText / $modelLabel" +
                (if (grade == "C") " / 設定「${mode.label}」で入るC" else "")
            else -> "見送り $shown（土日・$rateText）理由: 3分で勝つ確率 ${pc(wk.probability)} が上位8%の基準 ${pc(b8)} 未満$subText" +
                (if (sub?.label == "C1" && sub.rate != null) "（このC1は設定「C1をBに昇格」をONにするとBで入る）" else "") + " / $pair ${wk.direction} / $modelLabel"
        }
        val action = if (enter) "ENTRY" else "SKIP"
        val target = native.candidates.firstOrNull { it.instrument == wk.instrument }
            ?: ScanCandidate(rank = 1, instrument = wk.instrument, display = pair, direction = wk.direction, grade = grade, probability = wk.probability,
                decision = action, reasons = listOf("Coinbase"))
        val nativeTop = native.top1 ?: target
        val note = "$VERSION WEEKEND p=${"%.4f".format(wk.probability)} b8=${"%.4f".format(b8)} c60=${"%.4f".format(c60)} ${if (wk.fresh) "freshW" else "fallbackW"}" +
            " qage=${quoteAgeMs?.let { "${it}ms" } ?: "none"} MODE=${mode.key} HZ=3" +
            (sub?.let { " SUB=${it.label} top=${"%.4f".format(it.top)}${if (it.promoted) " PROMOTED" else ""}" } ?: "") + " -> $grade/$action ${wk.instrument} ${wk.direction}"
        val chosen = target.copy(rank = 1, direction = wk.direction, grade = grade, decision = action, probability = wk.probability,
            reasons = listOf("判定: ${minutes}分", note) + target.reasons.filterNot { it.startsWith("判定:") },
            assessment = CandidateAssessmentFactory.correction(target, nativeTop, wk.direction, grade, action, minutes, label,
                if (enter) null else CandidateSkipReason.LOW_EXPECTANCY).copy(subGrade = sub))
        val others = native.candidates.filter { it.instrument != target.instrument }.mapIndexed { i, c -> c.copy(rank = i + 2) }
        val suffix = if (result.policyVersion.endsWith("_3M_FIXED")) "_3M_FIXED" else ""
        val warnings = result.warnings + listOfNotNull(if (wk.fresh) null else "$VERSION: 仮想通貨の直前価格が40秒以内に取れない → 予備モデル")
        return native.copy(judgeTimeJst = entry.plusMinutes(minutes.toLong()).toString(), candidates = listOf(chosen) + others,
            warnings = warnings.distinct(), policyVersion = POLICY_TAG + suffix)
    }

    // ---------------- final decision ----------------

    /** [mode] = the user's ENTRY amount setting (the app passes it; the library default is the conservative 55% mode). */
    fun apply(native: ScanResult, result: ScanResult, candles: Map<String, List<Candle>>, quotes: Map<String, LiveQuote> = emptyMap(),
              mode: EntryMode = EntryMode.FIFTY_FIVE, hourEntries: Int = 0, openHigh: Int = 0, openLow: Int = 0, hourSlots: Int = 12,
              crypto: Map<String, List<Candle>> = emptyMap(), cryptoQuotes: Map<String, LiveQuote> = emptyMap(),
              promoteC1: Boolean = false, lossStreak: Int = 0): ScanResult {
        val entry = runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return skipTop(result, "エントリー時刻不明")
        if (!TradingSession.isActive(entry)) return skipTop(result, "${TradingSession.LABEL} 外", entry)
        val weekend = !TradingSession.isWeekday(entry.withZoneSameInstant(JST))
        // v0.7.71: weekends are decided by the four-crypto weekend model (Coinbase); the bitbank BTC/JPY rule below is the backup
        if (weekend && MarketCalendar.caution(entry) == null) {
            val wk = runCatching { chooseWeekend(crypto, cryptoQuotes, entry) }.getOrNull()
            if (wk != null) return weekendCrypto(native, result, wk, mode, entry,
                cryptoQuotes[wk.instrument]?.let { (entry.toEpochSecond() * 1000L - it.epochMs).coerceAtLeast(0L) }, promoteC1)
        }
        val choice = runCatching { choose(native, candles, quotes, entry) }.getOrNull() ?: return skipTop(result, "1分足61本の連続データ不足", entry)
        val b = entry.toEpochSecond()
        // The model decision is always taken (and recorded for AUTO) so the rolling distributions stay continuous.
        val boundary = isBoundary(entry)
        // v0.7.58: the rolling distributions stay on the 5-minute boundaries (weekday AUTO also scans the minutes between them)
        val decision = decide(choice, weekend, b, record = native.source == "AUTO" && boundary)
        val caution = MarketCalendar.caution(entry)
        val ruleFound = if (caution != null) null else runCatching {
            EventRules.match(entry, candles, EvidenceFeatures.INSTRUMENTS.associateWith { freshPrice(quotes, it, b) })
        }.getOrNull()
        // v0.7.57: weekday trades are FX only (theoption's BTC price is not bitbank's, so bitbank-judged BTC results are not theoption's)
        val ruleMatch = if (!weekend && ruleFound?.instrument == "BTCJPY") null else ruleFound
        val dirInt = if (choice.direction == "HIGH") 1 else -1
        val inputs = choice.inputs
        val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)
        val hourJst = entry.withZoneSameInstant(JST).hour
        val chosenLive = freshPrice(quotes, choice.instrument, b)
        val pos60 = runCatching { candles[choice.instrument]?.let { EvidenceFeatures.instrument(choice.instrument, it, b, chosenLive)?.pos60 } }.getOrNull()
        val againstHour = RankLadder.againstHour(pos60, dirInt)
        val modelGrade = RankLadder.modelGrade(decision.grade, weekend, confirmed, hourJst, againstHour, decision.rankStrength, decision.strength, choice.fresh)
        // v0.7.57 weekday: B = the 3-minute model's strong + confirmed FX trade (judged at 5 minutes); otherwise the 5-minute model decides
        val weekdayB = !weekend && boundary && ruleMatch == null && modelGrade == "B" && choice.instrument != "BTCJPY"
        // v0.7.71: the weekday 5-minute trade comes from the candle-only model over the yen crosses and the four cryptos
        val five = if (!weekend && ruleMatch == null && !weekdayB) runCatching {
            choose9(candles, crypto, quotes, cryptoQuotes, entry, mapOf("HIGH" to openHigh, "LOW" to openLow))
        }.getOrNull() else null
        if (!weekend && ruleMatch == null && !weekdayB && five == null) return skipTop(result, "為替の1分足61本の連続データ不足", entry)
        // v0.7.58: every clock hour >= 70% ENTRY. The cut follows how many entries this hour still needs and the minutes left.
        val minuteOfHour = entry.withZoneSameInstant(JST).minute
        val mc = five?.let { RankLadder.minuteCut(it.fresh, hourJst, minuteOfHour, hourEntries, hourSlots, lossStreak) }
        val cut = mc?.cut
        val fiveGrade0 = if (five != null && mc != null) (if (five.probability >= mc.cut) "C" else "D") else null
        // v0.7.76: C1 / C2 / C3 = the C trade's place in the hour's table (the one the cut comes from); C1 may be promoted to B (setting)
        val sub = if (five != null && fiveGrade0 == "C" && caution == null)
            SubGrades.promote(SubGrades.of(SubGrades.WEEKDAY, "C", SubGrades.weekday(five.fresh, hourJst, five.probability), five.probability, five.fresh), promoteC1)
        else null
        val fiveGrade = if (sub?.promoted == true) "B" else fiveGrade0
        val trade = five ?: choice
        val demoted = when {
            weekend -> if (ruleMatch == null && (decision.enter || modelGrade == "C"))
                RankLadder.demotion(decision.grade, weekend, confirmed, hourJst, againstHour, modelGrade, mode) else null
            fiveGrade == "C" && !mode.enters("C", false) ->
                "平日のC（1年${RankLadder.rate(five?.fresh ?: true, false, "C")?.let { "%.1f%%".format(it.year * 100.0) } ?: "—"}・55%未満）。設定「${mode.label}」では55%以上が確認できたS/A/Bだけ入る" +
                    (if (sub?.label == "C1" && sub.rate != null) "（このC1は検証${"%.1f%%".format(sub.rate!! * 100.0)}。設定「C1をBに昇格」をONにするとBで入る）" else "")
            else -> null
        }
        val instrument = ruleMatch?.instrument ?: trade.instrument
        // v0.7.71: a crypto pair the 6-pair scan does not list (ETH/JPY, BTC/USD, ETH/USD) becomes its own candidate
        val target = native.candidates.firstOrNull { it.instrument == instrument }
            ?: (if (CryptoPairs.isCrypto(instrument)) ScanCandidate(rank = 1, instrument = instrument, display = CryptoPairs.display(instrument),
                direction = trade.direction, grade = "C", probability = trade.probability, decision = "SKIP", reasons = listOf("Coinbase")) else null)
            ?: return skipTop(result, "候補なし", entry)
        val nativeTop = native.top1 ?: target
        val finalDirection = ruleMatch?.direction ?: trade.direction
        val enter = caution == null && when {
            ruleMatch != null -> true
            weekend -> demoted == null && mode.enters(modelGrade, true)
            weekdayB -> true
            else -> (fiveGrade == "C" && mode.enters("C", false)) || fiveGrade == "B"
        }
        val grade = when {
            caution != null -> if (weekend) (if (decision.enter || modelGrade == "C") "D" else modelGrade) else "D"
            ruleMatch != null -> ruleMatch.grade
            weekend -> modelGrade
            weekdayB -> "B"
            else -> fiveGrade!!
        }
        val minutes = RankLadder.judgeMinutes(weekend, grade)
        val hz = "【${minutes}分判定】"
        fun pc(x: Double) = "%.1f%%".format(x * 100.0)
        val tradeFresh = if (five != null) five.fresh else choice.fresh
        val table = RankLadder.rate(tradeFresh, weekend, grade)
        val rateText = when {
            caution != null -> "検証の数字なし"
            ruleMatch != null && table != null -> "検証 $grade ${pc(table.year)}" + (table.october?.let { "・10月 ${pc(it)}" } ?: "") +
                " / このルール ${pc(ruleMatch.rule.rate)}（${ruleMatch.rule.trades}回）"
            sub?.rate != null -> "検証 ${pc(sub.rate!!)}"
            table != null -> "検証 ${pc(table.year)}" + (table.october?.let { "・10月 ${pc(it)}" } ?: "")
            else -> "検証の記録なし"
        }
        val pct = "%.1f".format(choice.probability * 100.0)
        // v0.7.55: age of the live price used for the chosen instrument (the research live price is the last price before entry).
        val quoteAgeMs = (if (five != null && CryptoPairs.isCrypto(instrument) && ruleMatch == null && !weekend) cryptoQuotes[instrument] else quotes[instrument])
            ?.let { (b * 1000L - it.epochMs).coerceAtLeast(0L) }
        val ageText = quoteAgeMs?.let { "直前価格 ${String.format(java.util.Locale.US, "%.1f", it / 1000.0)}秒前" } ?: "直前価格なし"
        val modelLabel = if (tradeFresh) ageText else "直前価格なし・予備モデル"
        val seg = if (weekend) "土日BTC" else "平日"
        val label = hz + when {
            caution != null -> "見送り $grade（注意）${caution.label}の時間のため見送り（$rateText）"
            ruleMatch != null -> {
                val v = ruleMatch.value
                val what = when (ruleMatch.rule.feature) {
                    EventRules.Feature.POS60L -> "60分の${if (v > 0) "高値" else "安値"}側の端（${"%+.2f".format(v)}）"
                    EventRules.Feature.R5 -> "直前5分で${if (v > 0) "上昇" else "下落"}（${"%+.1f".format(v)}σ）"
                    EventRules.Feature.R15 -> "直前15分で${if (v > 0) "上昇" else "下落"}（${"%+.1f".format(v)}σ）"
                    EventRules.Feature.BBZL -> "20分平均より${if (v > 0) "上" else "下"}に離れた（${"%+.1f".format(v)}σ）"
                    EventRules.Feature.F1 -> "直前1分で${if (v > 0) "上昇" else "下落"}（${"%+.1f".format(v)}σ）"
                }
                "時間帯ルール $grade（${ruleMatch.rule.label}）${ruleMatch.instrument} $finalDirection: $what、ほかのサイン ${ruleMatch.confluence}/4 も同じ向き" +
                    " → 戻りを狙う（$rateText）/ $ageText"
            }
            !weekend && five != null && mc != null -> {
                val quota = "この1時間 ${hourEntries}回・70%（${RankLadder.hourQuota(hourSlots.coerceIn(0, 12))}回/${hourSlots}枠）まであと${mc.need.coerceAtLeast(0)}回（残り${mc.left}枠）・保有中 HIGH $openHigh / LOW $openLow"
                val p5 = "5分で勝つ確率 ${pc(five.probability)}" + when {
                    mc.catchUp -> "・残り時間で70%を満たすための入り"
                    mc.full -> "・この1時間は70%に到達"
                    else -> "・今の基準 ${pc(mc.cut)}" + (if (StreakGuard.active(lossStreak)) "（${lossStreak}連敗中の連敗結界で基準を上げる）" else "")
                }
                val shown = sub?.shown ?: grade
                val subText = sub?.let { " / Cの中の強さ ${SubGrades.text(it)}" } ?: ""
                if (enter) "5分モデル $shown（$seg・$rateText）${CryptoPairs.display(five.instrument)} ${five.direction} / $p5${if (mc.catchUp) "" else " 以上"}$subText / $quota / $modelLabel" +
                    (if (grade == "C") " / 設定「${mode.label}」で入るC" + (if (sub?.label == "C1") "" else "（55%未満）") else "")
                else if (demoted != null) "見送り $shown（$seg・$rateText）理由: $demoted$subText / ${five.instrument} ${five.direction} / $modelLabel"
                else "見送り $grade（$seg・$rateText）理由: ${if (mc.full) "この1時間は70%に到達" else "$p5 未満"} / $quota / ${five.instrument} ${five.direction} / $modelLabel"
            }
            demoted != null -> "見送り $grade（$seg・$rateText）理由: $demoted / ${choice.direction} / $modelLabel"
            enter -> {
                val confirmText = if (confirmed && inputs != null) {
                    if (choice.instrument == "BTCJPY") " / 直前1分の勢い（${"%+.1f".format(inputs.f1)}σ）に順張りで一致"
                    else " / 直前1分の急変（${"%+.1f".format(inputs.f1)}σ）の逆張りで一致"
                } else if (weekend && againstHour) " / 60分の値幅の${if (dirInt > 0) "下側で買う" else "上側で売る"}（追いかけない）" else ""
                val strongText = if (decision.enter) "強み: ${decision.reason}" else "強さ ${"%.1f".format(decision.strength * 100.0)}%（土日の上位60%）"
                val modeText = if (grade == "C") " / 設定「${mode.label}」で入るC（55%未満・1年${table?.let { pc(it.year) } ?: "—"}）" else ""
                "検証モデル $grade（$seg・$rateText）${if (weekend) "" else "${choice.instrument} "}$finalDirection$confirmText / $strongText / $modelLabel$modeText"
            }
            else -> "見送り $grade（$seg・$rateText）理由: ${decision.reason} / ${choice.direction} 強さ ${"%.1f".format(decision.strength * 100.0)}% / $modelLabel"
        }
        val ruleNote = ruleMatch?.let { " RULE=${it.rule.id} ${it.instrument} v=${"%.4f".format(it.value)} c=${it.confluence}" } ?: (caution?.let { " CAUTION" } ?: "")
        val fiveNote = five?.let { " FIVE=${it.instrument} ${it.direction} p5=${"%.4f".format(it.probability)} cut=${"%.4f".format(cut)} ${if (it.fresh) "fresh5" else "fallback5"}" +
            (mc?.let { m -> " H=$hourEntries need=${m.need} left=${m.left} slots=$hourSlots${if (m.catchUp) " CATCHUP" else ""}${if (m.full) " FULL" else ""}" } ?: "") +
            (if (StreakGuard.active(lossStreak)) " STREAK=$lossStreak" else "") } ?: ""
        val minuteNote = (if (boundary) "" else " MINUTE") + " OPEN=H$openHigh/L$openLow" +
            (sub?.let { " SUB=${it.label} top=${"%.4f".format(it.top)}${if (it.promoted) " PROMOTED" else ""}" } ?: "")
        val btcNote = if (!weekend && ruleFound?.instrument == "BTCJPY") " RULE_BTC_IGNORED" else ""
        val note = "$VERSION p=$pct% adj=${"%+.4f".format(choice.adjusted)} pct=${"%.3f".format(decision.pct)} e=${"%.4f".format(decision.strength)}" +
            " r=${"%.4f".format(decision.rankStrength)} ${if (decision.fromSeed) "seed" else "rolling"} ${if (choice.fresh) "fresh" else "fallback"}" +
            " ${decision.reasonGroup} v0748=${decision.grade}${if (confirmed) " CONFIRMED" else ""}${if (demoted != null) " DEMOTED" else ""}${if (weekend && againstHour) " AGAINST_HOUR" else ""}" +
            " qage=${quoteAgeMs?.let { "${it}ms" } ?: "none"} MODE=${mode.key} HZ=$minutes$minuteNote$fiveNote$btcNote$ruleNote -> $grade/${if (enter) "ENTRY" else "SKIP"} $instrument $finalDirection"
        val action = if (enter) "ENTRY" else "SKIP"
        val chosen = target.copy(
            rank = 1, direction = finalDirection, grade = grade, decision = action,
            probability = if (ruleMatch != null) table?.year ?: ruleMatch.rule.rate else trade.probability,
            reasons = listOf("判定: ${minutes}分", note) + target.reasons.filterNot { it.startsWith("判定:") },
            assessment = CandidateAssessmentFactory.correction(target, nativeTop, finalDirection, grade, action, minutes, label,
                if (enter) null else CandidateSkipReason.LOW_EXPECTANCY).copy(subGrade = sub)
        )
        val others = native.candidates.filter { it.instrument != target.instrument }.mapIndexed { i, c -> c.copy(rank = i + 2) }
        val suffix = if (result.policyVersion.endsWith("_3M_FIXED")) "_3M_FIXED" else ""
        val warnings = result.warnings + listOfNotNull(if (tradeFresh) null else "$VERSION: 直前価格が40秒以内に取れない通貨あり → 予備モデル")
        return native.copy(judgeTimeJst = entry.plusMinutes(minutes.toLong()).toString(), candidates = listOf(chosen) + others,
            warnings = warnings.distinct(), policyVersion = POLICY_TAG + suffix)
    }

    /**
     * Fail-safe: keep the overlay result but never ENTER; the top slot is marked I (no evidence decision possible).
     * v0.7.50: the I row carries this policy's tag, a 3-minute judge time and the reason as its label, so it is counted
     * and shown with the other 3-minute ranks instead of under a leftover horizon policy/expiry.
     */
    private fun skipTop(result: ScanResult, why: String, entry: ZonedDateTime? = null): ScanResult {
        val top = result.top1 ?: return result
        if (top.grade == "I" && top.decision == "SKIP") return result
        val note = "$VERSION: ${CandidateSkipReason.OBSERVE_ONLY.label} ($why) -> I/SKIP（判定不能）"
        val label = "判定不能 I（$why・観察のみ）"
        val judge = entry?.plusMinutes(3)?.toString() ?: result.judgeTimeJst
        val assessment = top.assessment?.let { a ->
            a.copy(operationalGrade = "I", decision = "SKIP", skipReason = CandidateSkipReason.OBSERVE_ONLY,
                chosenAction = a.chosenAction.copy(operationalGrade = "I", decision = "SKIP",
                    judgeMinutes = if (entry != null) 3 else a.chosenAction.judgeMinutes),
                correctionLabel = label)
        }
        val updated = top.copy(grade = "I", decision = "SKIP", reasons = top.reasons + note, assessment = assessment)
        val suffix = if (result.policyVersion.endsWith("_3M_FIXED")) "_3M_FIXED" else ""
        return result.copy(candidates = result.candidates.map { if (it.rank == top.rank) updated else it },
            judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)
    }
}

/** Newest Yahoo meta quote seen while fetching scan candles (written by MarketRepository). */
object LiveQuoteBoard {
    private val quotes = ConcurrentHashMap<String, EvidencePolicy.LiveQuote>()
    fun record(instrument: String, price: Double, epochMs: Long) {
        if (!(price.isFinite() && price > 0.0) || epochMs <= 0L) return
        quotes.merge(instrument, EvidencePolicy.LiveQuote(price, epochMs)) { old, new -> if (new.epochMs >= old.epochMs) new else old }
    }
    fun snapshot(): Map<String, EvidencePolicy.LiveQuote> = HashMap(quotes)
    fun clear() = quotes.clear()
}

package jp.gmk.mobile.domain

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

/*
 * v0.7.77 幻想郷 extras (display only; no decision, grade, rate or result reads them):
 * - [Difficulty]: each hour's validated win rate as a shooting-game difficulty (Easy / Normal / Hard / Lunatic).
 * - [RunningTrades]: the trades still running with the seconds to their judgement and whether the live price leads now.
 * - [Achievements]: 称号 unlocked from the history (幻想郷縁起).
 * - [Bunbunmaru]: today's report (文々。新聞 号外).
 */

private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
private fun pc(x: Double) = String.format(Locale.US, "%.1f%%", x * 100.0)
/** v0.7.79: [FastTime] (the same time as ZonedDateTime.parse(s).withZoneSameInstant(JST), without the text parser for the stored form). */
private fun jst(s: String): ZonedDateTime? = FastTime.jst(s)

/**
 * v0.7.78: the JST day ("2026-11-06") of a stored time without parsing it when it is written in JST ("...+09:00", what the app writes
 * for the 5-minute rows); anything else is parsed. The screen asks this of every row each time the history changes (every minute).
 */
fun jstDayKey(s: String): String? =
    if (s.length >= 16 && s.endsWith("+09:00")) s.substring(0, 10) else jst(s)?.toLocalDate()?.toString()

/** v0.7.78: the newly settled results to sound: rows that were waiting ([pending], from [pendingOf] of the previous history) and are now WIN / LOSE. */
object SoundCues {
    private val WAIT = setOf("WAIT_ENTRY", "WAIT_JUDGE")
    /** Waiting ENTRY rows whose result gets a cut-in (every 5-minute row, 1-minute B only). */
    fun pendingOf(rows: List<HistoryRow>): Set<String> =
        rows.asSequence().filter { it.decision == "ENTRY" && it.resultStatus in WAIT && OneMinutePolicy.showsCutIn(it) }.map { it.scanId }.toSet()
    /** The newest row of [pending] that is now WIN or LOSE, or null. */
    fun settled(pending: Set<String>, rows: List<HistoryRow>): HistoryRow? =
        if (pending.isEmpty()) null else rows.firstOrNull { it.scanId in pending && it.resultStatus in setOf("WIN", "LOSE") }
}

/**
 * Hour difficulty: the mean of the one-year rotation (scored on other periods) and 2023-24 win rates of every ENTRY of that hour
 * (weekday: the 5-minute AUTO, all grades; weekend: the weekend model's top 60%; research_v0777/v0777_hours.py).
 * Lunatic < 52.0%, Hard < 52.6% (the 1.9x break-even), Normal < 53.5%, Easy otherwise.
 */
object Difficulty {
    val WEEKDAY: Map<Int, Double> = mapOf(9 to 0.5229, 10 to 0.5258, 11 to 0.5316, 12 to 0.5308, 13 to 0.5151, 14 to 0.5357, 15 to 0.5222,
        16 to 0.5399, 17 to 0.5231, 18 to 0.5257, 19 to 0.5421, 20 to 0.5308, 21 to 0.5357, 22 to 0.5381)
    val WEEKEND: Map<Int, Double> = mapOf(9 to 0.5638, 10 to 0.5426, 11 to 0.5382, 12 to 0.5544, 13 to 0.5253, 14 to 0.5479, 15 to 0.5591,
        16 to 0.5440, 17 to 0.5422, 18 to 0.5592, 19 to 0.5713, 20 to 0.5724, 21 to 0.5552, 22 to 0.5620)

    data class Level(val name: String, val rate: Double, val hour: Int, val weekend: Boolean)

    fun level(rate: Double): String = when {
        rate < 0.520 -> "Lunatic"
        rate < 0.526 -> "Hard"
        rate < 0.535 -> "Normal"
        else -> "Easy"
    }

    /** The difficulty of the hour of [t], or null outside 09:00-22:59 JST. */
    fun of(t: ZonedDateTime): Level? {
        val j = t.withZoneSameInstant(JST); val weekend = j.dayOfWeek.value >= 6
        val rate = (if (weekend) WEEKEND else WEEKDAY)[j.hour] ?: return null
        return Level(level(rate), rate, j.hour, weekend)
    }

    /** "難易度 Lunatic（この時間の検証 51.5%）" */
    fun text(l: Level): String = "難易度 ${l.name}（${l.hour}時台の検証 ${pc(l.rate)}）"
}

/** The trades still running: seconds to the judgement and whether the live price is on the trade's side now (a draw loses). */
object RunningTrades {
    data class Trade(val row: HistoryRow, val price: Double?, val secondsLeft: Long, val totalSeconds: Long) {
        val direction: Int get() = if (row.direction == "HIGH") 1 else -1
        /** true = winning now, false = losing now (equal counts as losing), null = no entry rate or live price yet. */
        val leading: Boolean? get() { val e = row.entryRate ?: return null; val p = price ?: return null; return (p - e) * direction > 0.0 }
        val diff: Double? get() { val e = row.entryRate ?: return null; val p = price ?: return null; return (p - e) * direction }
        val progress: Float get() = if (totalSeconds <= 0) 1f else (1.0 - secondsLeft.toDouble() / totalSeconds).coerceIn(0.0, 1.0).toFloat()
    }

    /** ENTRY rows waiting for their result, newest first, with the live price of [prices] (instrument -> price). */
    fun of(rows: List<HistoryRow>, prices: Map<String, Double>, nowMs: Long, limit: Int = 6): List<Trade> = rows.asSequence()
        .filter { it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") }
        .mapNotNull { r ->
            val e = jst(r.entryTimeJst)?.toInstant()?.toEpochMilli() ?: return@mapNotNull null
            val j = jst(r.judgeTimeJst)?.toInstant()?.toEpochMilli() ?: return@mapNotNull null
            if (j + 120_000L < nowMs) return@mapNotNull null          // long past: the result is being fetched
            Trade(r, prices[r.instrument], ((j - nowMs) / 1000L).coerceAtLeast(0L), ((j - e) / 1000L).coerceAtLeast(1L))
        }
        .sortedBy { it.secondsLeft }.take(limit).toList()

    /** "3:07" */
    fun clock(seconds: Long): String = "${seconds / 60}:${String.format(Locale.US, "%02d", seconds % 60)}"
}

/** 称号: unlocked from the settled ENTRY results (5-minute evidence policy and the 1-minute judgment). */
object Achievements {
    data class Def(val id: String, val title: String, val how: String)
    data class Got(val def: Def, val atJst: String?) { val unlocked: Boolean get() = atJst != null }

    val ALL = listOf(
        Def("first", "初陣「はじめての異変解決」", "はじめてのWIN"),
        Def("win5", "博麗の勘", "5連勝"),
        Def("win10", "「夢想天生」", "10連勝"),
        Def("nomiss", "ノーミスクリア", "1時間に5回以上ENTRYして全勝"),
        Def("comeback", "残機回復", "3連敗以上のあとに3連勝"),
        Def("saisen", "賽銭箱いっぱい", "1日で+10口以上"),
        Def("c1", "夢境「二重大結界」", "C1（昇格したC1も）で5勝"),
        Def("spell", "スペルカードコンプリート", "S・A・B・C1・C2・C3 のすべてで勝つ"),
        Def("graze", "グレイズの達人", "同値（グレイズ）10回"),
        Def("extra", "Extra Stage クリア", "土日に10勝"),
        Def("danmaku", "弾幕の申し子", "1分判定で100勝"),
        Def("win100", "異変解決の専門家", "通算100勝"),
        Def("win500", "幻想郷の守護者", "通算500勝"),
        Def("win1000", "楽園の素敵な巫女", "通算1000勝")
    )

    private fun counted(r: HistoryRow) = r.decision == "ENTRY" && r.resultStatus in setOf("WIN", "LOSE") &&
        (RankStatistics.evidenceVersion(r.policyVersion) != null || OneMinutePolicy.isPolicy(r))

    fun of(rows: List<HistoryRow>): List<Got> {
        val done = rows.filter(::counted).mapNotNull { r -> jst(r.entryTimeJst)?.let { it to r } }.sortedBy { it.first }
        val at = HashMap<String, String>()
        fun unlock(id: String, r: HistoryRow) { if (id !in at) at[id] = r.entryTimeJst }
        val five = done.filter { !OneMinutePolicy.isPolicy(it.second) }
        var wins = 0; var run = 0; var lossRun = 0; var recovering = false; var comebackWins = 0; var draws = 0; var weekendWins = 0; var c1 = 0
        val graded = HashSet<String>()
        for ((t, r) in five) {
            val win = r.resultStatus == "WIN"
            if (win) {
                wins++; run++; if (lossRun >= 3) { recovering = true; comebackWins = 0 }; lossRun = 0
                if (recovering) { comebackWins++; if (comebackWins >= 3) { unlock("comeback", r); recovering = false } }
                if (wins == 1) unlock("first", r); if (run >= 5) unlock("win5", r); if (run >= 10) unlock("win10", r)
                if (wins >= 100) unlock("win100", r); if (wins >= 500) unlock("win500", r); if (wins >= 1000) unlock("win1000", r)
                if (t.dayOfWeek.value >= 6) { weekendWins++; if (weekendWins >= 10) unlock("extra", r) }
                val sub = r.assessment?.subGrade
                if (sub?.label == "C1" && (r.grade == "C" || sub.promoted)) { c1++; if (c1 >= 5) unlock("c1", r) }
                graded.add(sub?.label ?: r.grade)
                if (graded.containsAll(listOf("S", "A", "B", "C1", "C2", "C3"))) unlock("spell", r)
            } else {
                run = 0; lossRun++; recovering = false
                if (r.entryRate != null && r.entryRate == r.judgeRate) { draws++; if (draws >= 10) unlock("graze", r) }
            }
        }
        // a clock hour with >= 5 settled entries, all won; a day with >= +10 stakes
        five.groupBy { it.first.toLocalDate().toString() + "T" + it.first.hour }.values.forEach { g ->
            if (g.size >= 5 && g.all { it.second.resultStatus == "WIN" }) unlock("nomiss", g.last().second)
        }
        five.groupBy { it.first.toLocalDate() }.values.forEach { g ->
            var u = 0.0
            for ((_, r) in g) { u += if (r.resultStatus == "WIN") ShrineBoard.PAYOUT - 1.0 else -1.0; if (u >= 10.0 - 1e-9) { unlock("saisen", r); break } }
        }
        val m1Wins = done.filter { OneMinutePolicy.isPolicy(it.second) && it.second.resultStatus == "WIN" }
        if (m1Wins.size >= 100) unlock("danmaku", m1Wins[99].second)
        return ALL.map { Got(it, at[it.id]) }
    }
}

/** 文々。新聞 号外: today's results told by the crow tengu reporter (display only). */
object Bunbunmaru {
    data class Report(val headline: String, val lines: List<String>, val comment: String)

    fun today(rows: List<HistoryRow>, today: LocalDate): Report {
        val day = today.toString()
        val todays = rows.filter { r -> r.decision == "ENTRY" && r.resultStatus in setOf("WIN", "LOSE") && jstDayKey(r.entryTimeJst) == day }
        val five = todays.filter { r -> RankStatistics.evidenceVersion(r.policyVersion) != null }
            .mapNotNull { r -> jst(r.entryTimeJst)?.let { it to r } }.sortedBy { it.first }
        val m1 = todays.count { OneMinutePolicy.isPolicy(it) }
        val m1Wins = todays.count { OneMinutePolicy.isPolicy(it) && it.resultStatus == "WIN" }
        if (five.isEmpty() && m1 == 0) return Report("本日はまだ取材中です", emptyList(), "あやや、まだ判定が出ていませんね。最初の異変解決を待っています！")
        val wins = five.count { it.second.resultStatus == "WIN" }; val losses = five.size - wins
        val units = wins * (ShrineBoard.PAYOUT - 1.0) - losses
        val lines = ArrayList<String>()
        val headline = if (five.isEmpty()) "本日の5分判定はまだありません" else
            "霊夢さん本日 ${wins}勝${losses}敗（${pc(wins.toDouble() / five.size)}・${String.format(Locale.US, "%+.1f", units)}口）"
        if (five.isNotEmpty()) {
            val expected = five.map { (_, r) -> r.assessment?.subGrade?.rate ?: EvidencePolicy.gradeRate(true, RankStatistics.isWeekend(r.entryTimeJst) ?: false, r.grade) ?: 0.5 }.average()
            lines += "検証の見込み ${pc(expected)} に対して実績 ${pc(wins.toDouble() / five.size)}"
            var best = 0; var worst = 0; var w = 0; var l = 0
            for ((_, r) in five) { if (r.resultStatus == "WIN") { w++; l = 0 } else { l++; w = 0 }; best = maxOf(best, w); worst = maxOf(worst, l) }
            lines += "最長の連勝 $best・最長の連敗 $worst"
            // v0.7.78: a 当たりペア wins at least half (2 wins or more), a 苦戦した時間 is below the 52.6% break-even
            five.groupBy { it.second.instrument }.mapValues { (_, g) -> g.count { it.second.resultStatus == "WIN" } to g.size }
                .entries.filter { it.value.second >= 3 && it.value.first >= 2 && it.value.first * 2 >= it.value.second }
                .maxByOrNull { it.value.first.toDouble() / it.value.second }
                ?.let { (k, v) -> lines += "本日の当たりペア ${CryptoPairs.display(k)} ${v.first}勝${v.second - v.first}敗" }
            five.groupBy { it.first.hour }.mapValues { (_, g) -> g.count { it.second.resultStatus == "WIN" } to g.size }
                .entries.filter { it.value.second >= 4 && it.value.first.toDouble() / it.value.second < 0.526 }
                .minByOrNull { it.value.first.toDouble() / it.value.second }
                ?.let { (h, v) -> lines += "苦戦した時間 ${h}時台 ${v.first}勝${v.second - v.first}敗" }
        }
        if (m1 > 0) lines += "1分判定 ${m1Wins}勝${m1 - m1Wins}敗（${pc(m1Wins.toDouble() / m1)}）"
        val comment = when {
            five.isEmpty() -> "1分の弾幕は激しいですね。損益分岐は52.6%です！"
            units >= 5.0 -> "清く正しい射命丸です！今日の巫女は絶好調、賽銭箱がにぎやかですよ！"
            units > 0.0 -> "じわじわと勝ち越し中。この調子で異変を解決していきましょう！"
            units > -5.0 -> "少し被弾気味ですが、1日の上下は検証でも普通にある幅です。"
            else -> "今日は被弾が多めでした…。連敗は偶然でも起きます。明日の博麗の勘に期待！"
        }
        return Report(headline, lines, comment)
    }
}

/** The shooting-game HUD of today's 5-minute / 3-minute ENTRY results (display only). */
object ShrineHud {
    data class Hud(val score: Long, val hiScore: Long, val lives: Int, val bombs: Int, val power: Double, val graze: Int, val points: Int, val winStreak: Int)

    /** Settled ENTRY rows of the evidence policies by JST day (v0.7.78: the day from the text; a row is parsed only within its day). */
    private fun settledByDay(rows: List<HistoryRow>): Map<String, List<HistoryRow>> = rows.asSequence()
        .filter { r -> r.decision == "ENTRY" && r.resultStatus in setOf("WIN", "LOSE") && RankStatistics.evidenceVersion(r.policyVersion) != null }
        .mapNotNull { r -> jstDayKey(r.entryTimeJst)?.let { it to r } }.groupBy({ it.first }, { it.second })
    private fun ordered(day: List<HistoryRow>) = day.mapNotNull { r -> jst(r.entryTimeJst)?.let { it to r } }.sortedBy { it.first }

    /** Score of one day: a win is 9,000 + 1,000 x the win streak it makes (a streak pays), a loss 0. */
    private fun score(day: List<Pair<ZonedDateTime, HistoryRow>>): Long {
        var s = 0L; var run = 0
        for ((_, r) in day) { if (r.resultStatus == "WIN") { run++; s += 9_000L + 1_000L * run } else run = 0 }
        return s
    }

    fun of(rows: List<HistoryRow>, today: LocalDate, lossStreak: Int = ShrineBoard.lossStreak(rows)): Hud {
        val byDay = settledByDay(rows)
        val day = ordered(byDay[today.toString()].orEmpty())
        val wins = day.count { it.second.resultStatus == "WIN" }
        val rate = if (day.isEmpty()) null else wins.toDouble() / day.size
        var run = 0; for ((_, r) in day.asReversed()) { if (r.resultStatus == "WIN") run++ else break }
        val score = score(day)
        return Hud(score, maxOf(score, byDay.values.maxOfOrNull { score(ordered(it)) } ?: 0L), ShrineBoard.LIVES - lossStreak.coerceIn(0, ShrineBoard.LIVES),
            day.count { it.second.grade in setOf("S", "A", "B") }, rate?.let { ((it - 0.45) / 0.15 * 4.0).coerceIn(0.0, 4.0) } ?: 0.0,
            day.count { it.second.resultStatus == "LOSE" && it.second.entryRate != null && it.second.entryRate == it.second.judgeRate }, wins, run)
    }

    /** "ラストスペル発動中！ 5連勝" from 5 wins in a row, the 夢想天生 state from 10. */
    fun lastSpell(winStreak: Int): String = when {
        winStreak >= 10 -> "「夢想天生」状態！ ${winStreak}連勝"
        winStreak >= 5 -> "ラストスペル発動中！ ${winStreak}連勝"
        winStreak >= 3 -> "${winStreak}連勝中・博麗の勘が冴えている"
        else -> ""
    }

    /** Each pair's character (display only). */
    val CHARACTERS: Map<String, String> = mapOf("USDJPY" to "博麗霊夢", "EURJPY" to "レミリア・スカーレット", "GBPJPY" to "十六夜咲夜",
        "AUDJPY" to "チルノ", "NZDJPY" to "大妖精", "BTCJPY" to "霧雨魔理沙", "ETHJPY" to "アリス・マーガトロイド", "BTCUSD" to "魂魄妖夢", "ETHUSD" to "西行寺幽々子")
    fun character(instrument: String): String? = CHARACTERS[instrument]

    /** 博麗神社のおみくじ: one fortune per day from the date (a game only; it reads no market data and changes nothing). */
    val OMIKUJI = listOf("大吉" to "賽銭箱があふれる予感。でも欲張らずに", "中吉" to "勘が冴える日。B・C1の札を大事に", "小吉" to "こつこつ異変解決。損益分岐は52.6%",
        "吉" to "いつもどおりが一番。お茶でも飲みながら", "末吉" to "午後の結界（13時台）に気をつけて", "凶" to "被弾しても慌てない。連敗は偶然でも起きる")
    fun omikuji(day: LocalDate): Pair<String, String> = OMIKUJI[Math.floorMod(day.toEpochDay() * 7919L + 13L, OMIKUJI.size.toLong()).toInt()]
}

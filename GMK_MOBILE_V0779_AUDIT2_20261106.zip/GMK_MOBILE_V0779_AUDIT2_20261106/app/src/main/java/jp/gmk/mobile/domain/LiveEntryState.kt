package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/**
 * v0.7.60: what the weekday rule needs from the history at an entry time, in one pass over the rows (the app calls it every minute,
 * just before its publish deadline). [hourEntries] = this policy's ENTRY decisions earlier in the same clock hour (every grade, AUTO and
 * MANUAL); [openHigh] / [openLow] = this policy's ENTRY trades entered before the entry and judged after it (still running).
 * Rows of other days are skipped without parsing when their entry time is a JST string (the app writes JST); anything else is parsed.
 */
object LiveEntryState {
    /** [hourSlots] = this hour's 5-minute slots the app runs: AUTO slot rows already stored (not I = no data) + the slots still ahead. */
    data class State(val hourEntries: Int, val openHigh: Int, val openLow: Int, val hourSlots: Int = 12)
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    fun of(rows: List<HistoryRow>, entryTimeJst: String, policyTag: String): State {
        val entry = runCatching { ZonedDateTime.parse(entryTimeJst).withZoneSameInstant(JST) }.getOrNull() ?: return State(0, 0, 0, 12)
        val hourStart = entry.truncatedTo(ChronoUnit.HOURS)
        val from = if (entry.minusMinutes(10).isBefore(hourStart)) entry.minusMinutes(10) else hourStart   // a trade runs at most 5 minutes
        val days = setOf(from.toLocalDate().toString(), entry.toLocalDate().toString())
        var hour = 0; var high = 0; var low = 0; var seen = 0
        for (r in rows) {
            if (r.candidateRank != 1 || !r.policyVersion.startsWith(policyTag)) continue
            if (r.decision != "ENTRY") {
                // a stored 5-minute slot of this hour (AUTO keeps every slot row; I = no data, which the research has no slot for)
                if (r.source == "AUTO" && r.grade != "I" && r.entryTimeJst.endsWith("+09:00").not().or(r.entryTimeJst.take(10) in days)) {
                    val e = runCatching { ZonedDateTime.parse(r.entryTimeJst).withZoneSameInstant(JST) }.getOrNull()
                    if (e != null && e.second == 0 && e.minute % 5 == 0 && !e.isBefore(hourStart) && e.isBefore(entry)) seen++
                }
                continue
            }
            val t = r.entryTimeJst
            if (t.length >= 10 && t.endsWith("+09:00") && t.substring(0, 10) !in days) continue
            val e = runCatching { ZonedDateTime.parse(t).withZoneSameInstant(JST) }.getOrNull() ?: continue
            if (!e.isBefore(entry) || e.isBefore(from)) continue
            if (!e.isBefore(hourStart)) {
                hour++
                if (r.source == "AUTO" && e.second == 0 && e.minute % 5 == 0) seen++
            }
            val j = runCatching { ZonedDateTime.parse(r.judgeTimeJst) }.getOrNull() ?: continue
            if (j.isAfter(entry)) { if (r.direction == "HIGH") high++ else if (r.direction == "LOW") low++ }
        }
        val ahead = (entry.minute..59).count { it % 5 == 0 }
        return State(hour, high, low, seen + ahead)
    }
}

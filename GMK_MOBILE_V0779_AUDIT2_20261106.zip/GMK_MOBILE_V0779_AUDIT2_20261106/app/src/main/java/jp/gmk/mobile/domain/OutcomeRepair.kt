package jp.gmk.mobile.domain

import java.time.Duration
import java.time.ZonedDateTime

/**
 * v0.7.68: a result whose price could not be fetched in time (network down, phone asleep) stayed "取得失敗" until the app was
 * restarted (only the start-up recovery reopened it), so a real ENTRY could be missing from the win rate and the losing streak
 * for many hours (2026-11-03 20:26 USDJPY: 20 hours). The app now retries such rows while it runs.
 *
 * Due rows: ENTRY or followed SKIP ("if entered") rows of AUTO / 1-minute (minute-aligned, so the exact minute OPEN can be read
 * from the provider's history), marked ENTRY_RATE_MISSED / JUDGE_RATE_MISSED, judged at least [MIN_AGE_MINUTES] ago and at most
 * [MAX_AGE_HOURS] ago, each retried at most [MAX_ATTEMPTS] times in one run, ENTRY rows first, oldest judge time first.
 */
object OutcomeRepair {
    const val MIN_AGE_MINUTES = 3L
    const val MAX_AGE_HOURS = 24L
    const val MAX_ATTEMPTS = 3
    const val BATCH = 8
    const val INTERVAL_MS = 10L * 60L * 1000L
    val MISSED = setOf("ENTRY_RATE_MISSED", "JUDGE_RATE_MISSED")

    fun due(rows: List<HistoryRow>, now: ZonedDateTime, attempts: Map<String, Int>): List<HistoryRow> =
        rows.asSequence()
            .filter { it.resultStatus in MISSED && it.source != "MANUAL" && it.scanId.isNotBlank() }
            .filter { it.decision == "ENTRY" || ObservationPolicy.tracks(it) }
            .filter { (attempts[it.scanId] ?: 0) < MAX_ATTEMPTS }
            .mapNotNull { r -> runCatching { ZonedDateTime.parse(r.judgeTimeJst) }.getOrNull()?.let { r to it } }
            .filter { (_, j) -> !j.isAfter(now.minusMinutes(MIN_AGE_MINUTES)) && Duration.between(j, now).toHours() < MAX_AGE_HOURS }
            .sortedWith(compareBy<Pair<HistoryRow, ZonedDateTime>>({ if (it.first.decision == "ENTRY") 0 else 1 }, { it.second.toInstant() }))
            .take(BATCH).map { it.first }.toList()
}

/** v0.7.68: what happened to each AUTO slot (newest kept), so a gap in the history can be explained from the diagnostics. */
object AutoSlotLog {
    private const val KEEP = 400
    private val rows = ArrayDeque<String>()
    private val counts = LinkedHashMap<String, Int>()

    @Synchronized fun record(boundaryKey: String, outcome: String, detail: String = "") {
        val kind = outcome.substringBefore(':')
        counts[kind] = (counts[kind] ?: 0) + 1
        rows.addLast(if (detail.isBlank()) "$boundaryKey $outcome" else "$boundaryKey $outcome ${detail.take(120)}")
        while (rows.size > KEEP) rows.removeFirst()
    }
    @Synchronized fun recent(): List<String> = rows.toList()
    @Synchronized fun counts(): Map<String, Int> = LinkedHashMap(counts)
    @Synchronized fun clear() { rows.clear(); counts.clear() }
}

package jp.gmk.mobile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Every pair the decisions use: the five yen crosses and (v0.7.74) the four crypto pairs. */
internal val chartInstruments = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY") + CryptoPairs.ALL
private val timeframes = listOf("1m", "5m", "15m", "1h", "4h", "1d")
private val strengthPairs = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
private val CHART_HEIGHT = 300.dp

/**
 * v0.7.74 chart (幻想チャート): the newest 60 bars by default (30 / 60 / 120 / 240 to choose) with the price scale fitted to them and
 * price labels beside the chart; before, a whole day of 1-minute bars was squeezed into the screen width. Indicators are computed
 * over every fetched bar and only drawn for the visible ones.
 */
@Composable
fun ChartScreen(
    state: GmkUiState,
    instrument: String,
    timeframe: String,
    focusHistory: HistoryRow?,
    autoFollowScan: Boolean,
    onToggleAutoFollow: () -> Unit,
    onInstrument: (String) -> Unit,
    onTimeframe: (String) -> Unit,
    onRefresh: (String, String, Long?) -> Unit
) {
    val focusMs = remember(focusHistory?.id) { focusHistory?.entryTimeJst?.let(::parseJstMs) }
    LaunchedEffect(instrument, timeframe, focusHistory?.id) {
        onRefresh(instrument, timeframe, focusMs)
        if (focusHistory == null) {
            while (true) {
                delay(60_000L)
                onRefresh(instrument, timeframe, null)
            }
        }
    }
    var span by rememberSaveable { mutableStateOf(ChartWindow.DEFAULT_SPAN) }
    val candles = state.chartCandles.takeIf { state.chartInstrument == instrument && state.chartTimeframe == timeframe }.orEmpty()
    val rate = (state.cryptoRates + state.rates).firstOrNull { it.instrument == instrument }
    val bollinger = remember(candles) { bollingerBands(candles) }
    val macdRows = remember(candles) { macd(candles) }
    val window = remember(candles, span, focusMs) { ChartWindow.range(candles.map { it.timeEpochMs }, span, focusMs) }
    val visible = if (window.isEmpty()) emptyList() else candles.subList(window.first, window.last + 1)
    val visibleBands = if (window.isEmpty()) emptyList() else window.map { bollinger.getOrNull(it) }
    val visibleMacd = if (window.isEmpty()) emptyList() else window.map { macdRows.getOrNull(it) }
    val last = visible.lastOrNull()
    val latestBand = visibleBands.lastOrNull()
    val latestMacd = visibleMacd.lastOrNull()
    val scanTop = state.scan?.top1?.takeIf { it.instrument == instrument }
    var chartNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val plannedEntry = latestScanEntry(state, instrument, chartNowMs)
    LaunchedEffect(plannedEntry?.first) {
        val target = plannedEntry?.first ?: return@LaunchedEffect
        val delayMs = target - System.currentTimeMillis()
        if (delayMs > 0L) delay(delayMs)
        chartNowMs = System.currentTimeMillis()
    }
    val strengthForPair = remember(state.strengthCandles) { currencyRelativeStrength(state.strengthCandles) }
    // v0.7.78: the 1-minute rows (48 an hour) only on the 1-minute chart; they filled the 60 markers of the BTC / ETH charts
    val historyRows = remember(state.history, instrument, timeframe) {
        state.history.filter { it.instrument == instrument && it.decision == "ENTRY" && (timeframe == "1m" || !RankStatistics.isOneMinute(it)) }.take(60)
    }
    val period = timeframesToMs(timeframe)
    val start = visible.firstOrNull()?.timeEpochMs ?: 0L
    val end = (visible.lastOrNull()?.timeEpochMs ?: 0L) + period
    val drawEnd = max(end, plannedEntry?.first?.plus(period) ?: 0L)
    val markers = remember(historyRows, focusHistory) { (historyRows + listOfNotNull(focusHistory?.takeIf { it.decision == "ENTRY" })).distinctBy { it.id } }
    val range = remember(visible, visibleBands, markers, start, drawEnd) {
        ChartWindow.priceRange(buildList {
            visible.forEach { add(it.high); add(it.low) }
            visibleBands.filterNotNull().forEach { add(it.upper); add(it.lower) }
            markers.forEach { h ->
                if (parseJstMs(h.entryTimeJst)?.let { it in start until drawEnd } == true) h.entryRate?.let(::add)
                if (parseJstMs(h.judgeTimeJst)?.let { it in start until drawEnd } == true) h.judgeRate?.let(::add)
            }
        })
    }

    Column(Modifier.fillMaxSize().background(Gmk.Night).verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2A1240), Gmk.Night))).padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                YinYangOrb(24.dp, spinning = state.chartLoading)
                Spacer(Modifier.width(8.dp))
                Text("幻想チャート", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.weight(1f))
                ChoiceChip("SCAN追従 ${if (autoFollowScan) "ON" else "OFF"}", autoFollowScan, Gmk.Cyan, onToggleAutoFollow)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                chartInstruments.forEach { pair -> ChoiceChip(pairLabel(pair), pair == instrument, if (CryptoPairs.isCrypto(pair)) Gmk.Gold else Gmk.Pink) { onInstrument(pair) } }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                timeframes.forEach { tf -> ChoiceChip(tf, tf == timeframe, Gmk.Purple) { onTimeframe(tf) } }
                Spacer(Modifier.width(6.dp))
                Text("表示", color = Gmk.Muted, fontSize = 11.sp)
                ChartWindow.SPANS.forEach { n -> ChoiceChip("${n}本", n == span, Gmk.Cyan) { span = n } }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(pairLabel(instrument), color = Gmk.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${state.chartSource.ifBlank { if (CryptoPairs.isCrypto(instrument)) "Coinbase" else "Yahoo Finance" }} • $timeframe • ${visible.size}/${candles.size}本",
                        color = Gmk.Muted, fontSize = 10.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(rate?.price?.let(::formatPrice) ?: "—", color = if (rate?.freshnessStatus == "LIVE") Gmk.Pink else Gmk.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("${rate?.freshnessStatus ?: "取得待ち"}  更新 ${state.chartUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "—"}", color = Gmk.Muted, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OhlcCell("始", last?.open); OhlcCell("高", last?.high); OhlcCell("安", last?.low); OhlcCell("終", last?.close)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                PriceChart(Modifier.weight(1f), visible, visibleBands, markers, period, start, drawEnd, range, plannedEntry?.first, plannedEntry?.second)
                Column(Modifier.width(66.dp).height(CHART_HEIGHT).padding(start = 4.dp, top = 2.dp, bottom = 2.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    range?.let { (lo, hi) -> ChartWindow.levels(lo, hi).forEach { Text(formatPrice(it), color = Gmk.Muted, fontSize = 9.sp, maxLines = 1, softWrap = false) } }
                }
            }
            Row(Modifier.fillMaxWidth().padding(end = 66.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(visible.firstOrNull()?.timeEpochMs?.let(::formatClock)?.take(5) ?: "", color = Gmk.Muted, fontSize = 10.sp)
                Text(visible.getOrNull(visible.size / 2)?.timeEpochMs?.let(::formatClock)?.take(5) ?: "", color = Gmk.Muted, fontSize = 10.sp)
                Text(last?.timeEpochMs?.let(::formatClock)?.take(5) ?: "", color = Gmk.Muted, fontSize = 10.sp)
            }
            Text(if (state.chartLoading && candles.isEmpty()) "足を取得中…" else if (candles.isEmpty()) "足なし" else
                "ローソク足 • ボリンジャー(20, 2) ${latestBand?.let { "上 ${formatPrice(it.upper)} / 中 ${formatPrice(it.middle)} / 下 ${formatPrice(it.lower)}" } ?: ""}",
                color = Gmk.Muted, fontSize = 10.sp)
            state.chartError?.let { Text(it, color = Gmk.Warn, fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp)) }
        }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("MACD (12, 26, 9)", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(latestMacd?.let { "${formatSmall(it.macd)} / ${formatSmall(it.signal)} / ${formatSmall(it.histogram)}" } ?: "—", color = Gmk.Cyan, fontSize = 10.sp)
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth()) {
                MacdChart(Modifier.weight(1f), visibleMacd)
                Spacer(Modifier.width(66.dp))
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), accent = Gmk.Pink.copy(alpha = .5f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📰 文々。速報", color = Gmk.Pink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Text(if (rate?.freshnessStatus == "LIVE") "LIVE" else "取得確認", color = if (rate?.freshnessStatus == "LIVE") Gmk.Win else Gmk.Gold, fontSize = 10.sp)
            }
            Spacer(Modifier.height(4.dp))
            val comments = buildList {
                if (rate == null || rate.price == null) add("リアルタイム価格を取得できていません")
                else if (rate.freshnessStatus != "LIVE") add("取得遅延注意: provider age ${rate.ageSeconds?.let { "%.1f秒".format(it) } ?: "不明"}")
                if (scanTop != null) add("スキャンTOP1: ${scanTop.direction} / 運用等級 ${scanTop.grade} / ${scanTop.assessment?.correctionLabel ?: "理由未記録"}")
                if (plannedEntry != null) add("ENTRY予定: ${plannedEntry.second} • ${formatClock(plannedEntry.first)}")
                val strengthGap = strengthForPair[instrument.removeSuffix("JPY")]?.let { base -> strengthForPair["JPY"]?.let { base - it } }
                if (strengthGap != null && instrument.endsWith("JPY")) {
                    val aligned = scanTop?.let { (it.direction == "HIGH" && strengthGap > 0.0) || (it.direction == "LOW" && strengthGap < 0.0) }
                    add("通貨強弱（参考）: ${"%+.2f".format(strengthGap)}% • ${when (aligned) { true -> "方向一致"; false -> "逆行に注意"; null -> "方向比較" }}")
                }
                // v0.7.79: the 1-minute rows only on the 1-minute chart, like the markers (a 5-minute chart showed the last 1-minute result)
                val settled = state.history.firstOrNull { it.instrument == instrument && it.decision == "ENTRY" && it.resultStatus in setOf("WIN", "LOSE") &&
                    (timeframe == "1m" || !RankStatistics.isOneMinute(it)) }
                if (settled != null) add("直近の結果: ${settled.resultStatus} • ${settled.direction} • ${formatJstTime(settled.entryTimeJst)}")
                if (state.history.any { it.instrument == instrument && it.decision == "ENTRY" && it.resultStatus == "WAIT_JUDGE" &&
                        (timeframe == "1m" || !RankStatistics.isOneMinute(it)) }) add("判定待ち: ENTRY後の結果取得中")
                if (last != null && latestBand != null) {
                    val pos = (last.close - latestBand.lower) / (latestBand.upper - latestBand.lower).coerceAtLeast(1e-12)
                    if (pos >= 0.90) add("ボリンジャー上限付近。反転を含めて次の足を確認")
                    else if (pos <= 0.10) add("ボリンジャー下限付近。反発の有無を確認")
                }
                if (latestMacd != null && visibleMacd.size >= 2) {
                    val before = visibleMacd[visibleMacd.lastIndex - 1]
                    if (before != null && before.macd >= before.signal && latestMacd.macd < latestMacd.signal) add("MACDデッドクロス")
                    else if (before != null && before.macd <= before.signal && latestMacd.macd > latestMacd.signal) add("MACDゴールデンクロス")
                }
                if (focusHistory != null) add(if (isSelectedFocusVisible(visible, focusHistory, timeframe)) "選んだ履歴のENTRY・判定位置をチャートに表示中" else "選んだ履歴は表示中の足の範囲外です（下に価格・時刻）")
                if (isEmpty()) add("スキャンと市場データを待っています")
            }
            comments.take(5).forEach { Text("• $it", color = Gmk.Text, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        }

        focusHistory?.let { HistoryFocusCard(it) }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text("チャートの印", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("点線 = ENTRY（色: 緑 WIN・赤 LOSE・紫 判定待ち）、実線 = 判定時刻、紫の点線 = 次のENTRY予定、金の点線 = いまの終値。履歴をタップするとその時刻の足を開きます。",
                color = Gmk.Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PriceChart(
    modifier: Modifier, candles: List<Candle>, bands: List<BollingerPoint?>, events: List<HistoryRow>, period: Long, start: Long, end: Long,
    range: Pair<Double, Double>?, plannedEntryMs: Long?, plannedDirection: String?
) {
    Canvas(modifier.height(CHART_HEIGHT).background(Color(0xCC09142B), RoundedCornerShape(6.dp))) {
        val (lo, hi) = range ?: run {
            drawLine(Gmk.Muted.copy(alpha = .5f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.dp.toPx())
            return@Canvas
        }
        if (candles.isEmpty()) return@Canvas
        val top = 8.dp.toPx()
        val bottom = size.height - 8.dp.toPx()
        val height = (bottom - top).coerceAtLeast(1f)
        fun y(price: Double): Float = bottom - ((price - lo) / (hi - lo).coerceAtLeast(1e-12)).toFloat() * height
        fun x(time: Long): Float = (((time - start).toDouble() / (end - start).coerceAtLeast(1L)) * size.width).toFloat().coerceIn(0f, size.width)
        val candleWidth = (period.toDouble() / (end - start).coerceAtLeast(period).toDouble() * size.width * .62).toFloat().coerceAtLeast(1.5f)
        for (i in 0..4) {
            val gy = top + height * i / 4f
            drawLine(Color(0x334E6A99), Offset(0f, gy), Offset(size.width, gy), 1.dp.toPx())
        }
        candles.forEach { c ->
            val cx = x(c.timeEpochMs + period / 2L)
            val color = if (c.close >= c.open) Gmk.Cyan else Gmk.Pink
            drawLine(color.copy(alpha = .9f), Offset(cx, y(c.high)), Offset(cx, y(c.low)), 1.2.dp.toPx())
            val yOpen = y(c.open); val yClose = y(c.close)
            drawRect(color, Offset(cx - candleWidth / 2f, min(yOpen, yClose)), Size(candleWidth, max(1.5.dp.toPx(), abs(yOpen - yClose))))
        }
        val upper = Path(); val mid = Path(); val lower = Path()
        var started = false
        bands.forEachIndexed { i, p ->
            if (p == null) { started = false; return@forEachIndexed }
            val px = x(candles[i].timeEpochMs + period / 2L)
            if (!started) { upper.moveTo(px, y(p.upper)); mid.moveTo(px, y(p.middle)); lower.moveTo(px, y(p.lower)); started = true }
            else { upper.lineTo(px, y(p.upper)); mid.lineTo(px, y(p.middle)); lower.lineTo(px, y(p.lower)) }
        }
        drawPath(upper, Gmk.Pink.copy(alpha = .8f), style = Stroke(1.3.dp.toPx()))
        drawPath(mid, Color(0xFF81A8FF), style = Stroke(1.dp.toPx()))
        drawPath(lower, Color(0xFF4C9DFF), style = Stroke(1.3.dp.toPx()))
        // the newest close as a gold dotted line across the chart
        val lastY = y(candles.last().close)
        drawLine(Gmk.Gold.copy(alpha = .8f), Offset(0f, lastY), Offset(size.width, lastY), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())))
        events.forEach { h ->
            val color = when (h.resultStatus) { "WIN" -> Gmk.Win; "LOSE" -> Gmk.Lose; else -> Gmk.Purple }
            parseJstMs(h.entryTimeJst)?.takeIf { it in start until end }?.let { t ->
                val ex = x(t)
                drawLine(color, Offset(ex, top), Offset(ex, bottom), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx())))
                h.entryRate?.takeIf { it.isFinite() && it > 0.0 }?.let { drawCircle(if (h.direction == "HIGH") Gmk.High else Gmk.Low, radius = 4.dp.toPx(), center = Offset(ex, y(it))) }
            }
            parseJstMs(h.judgeTimeJst)?.takeIf { it in start until end }?.let { t ->
                val jx = x(t)
                drawLine(color.copy(alpha = .85f), Offset(jx, top), Offset(jx, bottom), 1.dp.toPx())
                h.judgeRate?.takeIf { it.isFinite() && it > 0.0 }?.let { drawCircle(color, radius = 4.dp.toPx(), center = Offset(jx, y(it))) }
            }
        }
        if (plannedEntryMs != null && plannedEntryMs in start until end) {
            val px = x(plannedEntryMs)
            drawLine(Gmk.Purple, Offset(px, top), Offset(px, bottom), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 3.dp.toPx())))
            drawCircle(if (plannedDirection == "HIGH") Gmk.High else Gmk.Low, radius = 5.dp.toPx(), center = Offset(px, top + 6.dp.toPx()))
        }
    }
}

@Composable
private fun MacdChart(modifier: Modifier, rows: List<MacdPoint?>) {
    Canvas(modifier.height(110.dp).background(Color(0xBB0B1530), RoundedCornerShape(6.dp))) {
        val valid = rows.filterNotNull()
        if (valid.isEmpty()) return@Canvas
        val extent = valid.flatMap { listOf(it.macd, it.signal, it.histogram) }.maxOf { abs(it) }.coerceAtLeast(1e-12)
        val mid = size.height / 2f
        drawLine(Color(0x556D82AB), Offset(0f, mid), Offset(size.width, mid), 1.dp.toPx())
        val slot = size.width / rows.size.coerceAtLeast(1)
        val macdPath = Path(); val signalPath = Path()
        var started = false
        rows.forEachIndexed { i, p ->
            if (p == null) return@forEachIndexed
            val cx = slot * (i + .5f)
            fun py(v: Double) = mid - (v / extent).toFloat() * (size.height * .43f)
            val bar = p.histogram.toFloat() / extent.toFloat() * (size.height * .36f)
            drawRect(if (bar >= 0) Gmk.Cyan.copy(alpha = .78f) else Gmk.Pink.copy(alpha = .78f), Offset(cx - max(1.dp.toPx(), slot * .32f), mid - bar.coerceAtLeast(0f)),
                Size(max(2.dp.toPx(), slot * .64f), max(1.dp.toPx(), abs(bar))))
            if (!started) { macdPath.moveTo(cx, py(p.macd)); signalPath.moveTo(cx, py(p.signal)); started = true }
            else { macdPath.lineTo(cx, py(p.macd)); signalPath.lineTo(cx, py(p.signal)) }
        }
        drawPath(macdPath, Gmk.Cyan, style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round))
        drawPath(signalPath, Color(0xFFFFA33B), style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
    }
}

/** MACD values (small numbers): 5 significant decimals for FX, 2 for crypto-sized values. */
private fun formatSmall(v: Double): String = if (abs(v) >= 10) "%.2f".format(v) else "%.5f".format(v)

@Composable
private fun OhlcCell(label: String, value: Double?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Gmk.Muted, fontSize = 10.sp)
        Text(value?.let(::formatPrice) ?: "—", color = Gmk.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HistoryFocusCard(row: HistoryRow) {
    ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), accent = Gmk.Pink.copy(alpha = .6f)) {
        Text("選んだ履歴 • ${pairLabel(row.instrument)} ${row.direction}", color = Gmk.Pink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("ENTRY ${formatJstTime(row.entryTimeJst)} @ ${row.entryRate?.let(::formatPrice) ?: "取得なし"}", color = Gmk.Text, fontSize = 12.sp)
        Text("判定 ${formatJstTime(row.judgeTimeJst)} @ ${row.judgeRate?.let(::formatPrice) ?: "取得なし"} • ${row.resultStatus}", color = Gmk.Text, fontSize = 12.sp)
        Text("${row.source} / 運用等級 ${row.grade} / ${row.regime}", color = Gmk.Muted, fontSize = 11.sp)
        row.assessment?.correctionLabel?.let { Text(it, color = Gmk.Cyan, fontSize = 11.sp) }
        if (row.decision == "SKIP" && row.skipReasonLabel.isNotBlank()) Text("見送り: ${row.skipReasonLabel}", color = Gmk.Muted, fontSize = 11.sp)
    }
}

@Composable
fun CurrencyStrengthScreen(state: GmkUiState, onRefresh: (String) -> Unit, onSelectPair: (String) -> Unit) {
    var timeframe by remember { mutableStateOf(state.strengthTimeframe.ifBlank { "1h" }) }
    var session by remember { mutableStateOf("全時間") }
    var filter by remember { mutableStateOf("すべて") }
    LaunchedEffect(timeframe) {
        onRefresh(timeframe)
        while (true) { delay(120_000L); onRefresh(timeframe) }
    }
    val sessions = listOf("全時間", "東京", "欧州", "米国")
    val filteredCandles = remember(state.strengthCandles, session) { state.strengthCandles.mapValues { (_, c) -> filterSessionWindow(c, session) } }
    val values = remember(filteredCandles) { currencyRelativeStrength(filteredCandles) }
    val allowedPairs = when (filter) {
        "メジャー" -> setOf("USDJPY", "EURJPY", "GBPJPY")
        "高金利" -> setOf("AUDJPY", "NZDJPY")
        "暗号資産" -> setOf("BTCJPY")
        else -> strengthPairs.toSet()
    }
    val candidates = strengthPairs.filter { it in allowedPairs }
        .mapNotNull { pair -> values[pair.removeSuffix("JPY")]?.let { pair to it } }
        .sortedByDescending { abs(it.second - (values["JPY"] ?: 0.0)) }
    val currencies = listOf("JPY", "USD", "EUR", "GBP", "AUD", "NZD", "BTC")
    val top = state.scan?.top1
    // v0.7.79: the three sessions once per candle update (they were computed again at every redraw of the screen)
    val sessionScores = remember(state.strengthCandles) {
        listOf("東京", "欧州", "米国").associateWith { name -> currencyRelativeStrength(state.strengthCandles.mapValues { (_, list) -> filterSessionWindow(list, name) }) }
    }

    Column(Modifier.fillMaxSize().background(Gmk.Night).verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2A1240), Gmk.Night))).padding(14.dp)) {
            Text("勢力図（通貨強弱）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("幻想郷の勢力図 — 円の5ペアとBTC/JPY（bitbank）の確定足から算出・対JPY変化率", color = Gmk.Muted, fontSize = 11.sp)
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                sessions.forEach { ChoiceChip(it, it == session, Gmk.Pink) { session = it } }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                timeframes.forEach { ChoiceChip(it, it == timeframe, Gmk.Purple) { timeframe = it } }
            }
        }
        if (state.strengthLoading) Text("通貨足を取得中…", color = Gmk.Cyan, modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp), fontSize = 12.sp)
        if (state.strengthErrors.isNotEmpty()) Text("一部データなし: ${state.strengthErrors.keys.joinToString()}", color = Gmk.Warn, modifier = Modifier.padding(horizontal = 14.dp), fontSize = 11.sp)

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("勢力ランキング", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text("更新 ${state.strengthUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "—"}", color = Gmk.Muted, fontSize = 10.sp)
            }
            val ranked = currencies.mapNotNull { c -> values[c]?.let { c to it } }.filter { (c, _) -> filter != "暗号資産" || c == "BTC" }.sortedByDescending { it.second }
            if (ranked.isEmpty()) {
                Text("必要な確定足がまだありません", color = Gmk.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            } else {
                val lowest = ranked.minOf { it.second }
                val spread = (ranked.maxOf { it.second } - lowest).coerceAtLeast(.01)
                ranked.forEachIndexed { index, (currency, score) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", color = Gmk.Muted, modifier = Modifier.width(24.dp), fontSize = 12.sp)
                        Text(currency, color = Gmk.Text, fontWeight = FontWeight.Bold, modifier = Modifier.width(44.dp), fontSize = 13.sp)
                        Box(Modifier.weight(1f).height(16.dp).background(Color(0xFF111D36), RoundedCornerShape(3.dp))) {
                            Box(Modifier.fillMaxWidth(((score - lowest) / spread).toFloat().coerceIn(.03f, 1f)).fillMaxHeight()
                                .background(if (score >= 0) Gmk.Pink else Gmk.Cyan, RoundedCornerShape(3.dp)))
                        }
                        Text("${if (score >= 0) "+" else ""}${"%.2f".format(score)}%", color = if (score >= 0) Gmk.Pink else Gmk.Cyan, textAlign = TextAlign.End,
                            modifier = Modifier.width(64.dp), fontSize = 12.sp)
                    }
                }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("相対強弱ヒートマップ", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("セル = 行の通貨の対JPY変化 − 列の通貨の対JPY変化（相対比較）", color = Gmk.Muted, fontSize = 10.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.width(32.dp))
                currencies.forEach { Text(it, Modifier.weight(1f), color = Gmk.Muted, textAlign = TextAlign.Center, fontSize = 9.sp) }
            }
            currencies.forEach { row ->
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(row, Modifier.width(32.dp), color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    currencies.forEach { col ->
                        val d = if (row == col) null else values[row]?.let { r -> values[col]?.let { r - it } }
                        val cell = when {
                            d == null -> Color(0xFF17213A)
                            d >= 0 -> Gmk.Pink.copy(alpha = (.20f + (d / 3.0).toFloat().coerceIn(0f, .65f)))
                            else -> Gmk.Cyan.copy(alpha = (.20f + (abs(d) / 3.0).toFloat().coerceIn(0f, .65f)))
                        }
                        Box(Modifier.weight(1f).height(28.dp).padding(1.dp).background(cell, RoundedCornerShape(2.dp)), contentAlignment = Alignment.Center) {
                            Text(d?.let { "%+.1f".format(it) } ?: "—", color = Color.White.copy(alpha = .92f), fontSize = 8.sp)
                        }
                    }
                }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("セッション別（JST）", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("東京 07–16 / 欧州 16–翌01 / 米国 21–翌06", color = Gmk.Muted, fontSize = 10.sp)
            listOf("東京", "欧州", "米国").forEach { name ->
                val scores = sessionScores.getValue(name)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.width(48.dp), color = Gmk.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    currencies.forEach { c ->
                        val score = scores[c]
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            val h = if (score == null) 8.dp else (12.dp.value + abs(score).toFloat().coerceIn(0f, 28f)).dp
                            val color = when { score == null -> Gmk.Muted; score >= 0 -> Gmk.Pink; else -> Gmk.Cyan }
                            Box(Modifier.width(17.dp).height(h).background(color.copy(alpha = if (score == null) .35f else .85f), RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)))
                            Text(c, color = Gmk.Muted, fontSize = 8.sp)
                            Text(score?.let { "%+.1f".format(it) } ?: "—", color = if (score == null) Gmk.Muted else color, fontSize = 8.sp)
                        }
                    }
                }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("すべて", "メジャー", "高金利", "暗号資産").forEach { ChoiceChip(it, it == filter, Gmk.Pink) { filter = it } }
            }
            Spacer(Modifier.height(8.dp))
            Text("注目ペア", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("強い側がJPYなら反対方向を表示。タップでチャートへ（参考表示・判定には使いません）", color = Gmk.Muted, fontSize = 10.sp)
            if (candidates.isEmpty()) Text("候補データなし", color = Gmk.Muted, modifier = Modifier.padding(top = 8.dp), fontSize = 12.sp)
            candidates.take(4).forEach { (pair, score) ->
                val yen = values["JPY"] ?: 0.0
                val direction = if (score >= yen) "HIGH" else "LOW"
                Row(
                    Modifier.fillMaxWidth().padding(top = 7.dp).border(1.dp, Gmk.Pink.copy(alpha = .45f), RoundedCornerShape(8.dp))
                        .background(Color(0x66161E3A), RoundedCornerShape(8.dp)).clickable { onSelectPair(pair) }.padding(11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${pairLabel(pair)}  $direction", color = if (direction == "HIGH") Gmk.High else Gmk.Low, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("対JPY ${"%+.2f".format(score - yen)}%", color = Gmk.Muted, fontSize = 10.sp)
                    }
                    Text("›", color = Gmk.Pink, fontSize = 22.sp)
                }
            }
        }

        if (top != null && top.instrument in strengthPairs) {
            val gap = values[top.instrument.removeSuffix("JPY")]?.let { base -> values["JPY"]?.let { base - it } }
            val aligned = gap?.let { (top.direction == "HIGH" && it > 0.0) || (top.direction == "LOW" && it < 0.0) }
            ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
                Text("スキャンTOP1と勢力図", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${pairLabel(top.instrument)} ${top.direction} • ${formatJstTime(state.scan?.atJst.orEmpty())}", color = Gmk.Muted, fontSize = 10.sp)
                Text(when (aligned) { true -> "方向一致（参考）"; false -> "逆行（参考）"; null -> "比較できる足が不足" },
                    color = when (aligned) { true -> Gmk.Win; false -> Gmk.Warn; null -> Gmk.Muted }, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("強弱差 ${gap?.let { "%+.2f%%".format(it) } ?: "—"} • 補助表示。判定には加点していません。", color = Gmk.Muted, fontSize = 10.sp)
                Text("チャートで開く ›", color = Gmk.Pink, modifier = Modifier.clickable { onSelectPair(top.instrument) }.padding(top = 6.dp), fontSize = 12.sp)
            }
        }
    }
}

private fun isSelectedFocusVisible(candles: List<Candle>, focus: HistoryRow?, timeframe: String): Boolean {
    if (candles.isEmpty() || focus == null) return false
    val time = parseJstMs(focus.entryTimeJst) ?: return false
    return time in candles.first().timeEpochMs..(candles.last().timeEpochMs + timeframesToMs(timeframe))
}

private fun inSession(timeMs: Long, session: String): Boolean {
    if (session == "全時間") return true
    val hour = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(timeMs), Gmk.Jst).hour
    return when (session) {
        "東京" -> hour in 7..15
        "欧州" -> hour >= 16 || hour < 1
        "米国" -> hour >= 21 || hour < 6
        else -> true
    }
}

private fun filterSessionWindow(candles: List<Candle>, session: String): List<Candle> {
    if (session == "全時間" || candles.isEmpty()) return candles
    val latest = candles.mapNotNull { sessionBucket(it.timeEpochMs, session) }.maxOrNull() ?: return emptyList()
    return candles.filter { sessionBucket(it.timeEpochMs, session) == latest }
}

/**
 * (ENTRY time, direction) of the newest scan's ENTRY on [instrument] while that time is still ahead; v0.7.79: the 1-minute judgment's
 * ENTRY too (the sooner of the two), so a 1-minute signal shows its line on the chart like the 5-minute one.
 */
private fun latestScanEntry(state: GmkUiState, instrument: String, nowMs: Long): Pair<Long, String>? =
    listOfNotNull(state.scan, state.m1Scan).mapNotNull { scan ->
        val top = scan.top1?.takeIf { it.instrument == instrument && it.decision == "ENTRY" } ?: return@mapNotNull null
        val target = parseJstMs(scan.entryTimeJst) ?: return@mapNotNull null
        if (target <= nowMs) null else target to top.direction
    }.minByOrNull { it.first }

private fun sessionBucket(timeMs: Long, session: String): java.time.LocalDate? {
    val local = java.time.Instant.ofEpochMilli(timeMs).atZone(Gmk.Jst)
    if (!inSession(timeMs, session)) return null
    return when (session) {
        "欧州" -> if (local.hour < 1) local.toLocalDate().minusDays(1) else local.toLocalDate()
        "米国" -> if (local.hour < 6) local.toLocalDate().minusDays(1) else local.toLocalDate()
        else -> local.toLocalDate()
    }
}

private fun timeframesToMs(value: String): Long = when (value) { "1m" -> 60_000L; "5m" -> 300_000L; "15m" -> 900_000L; "1h" -> 3_600_000L; "4h" -> 14_400_000L; "1d" -> 86_400_000L; else -> 60_000L }

package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/**
 * v0.7.54 signal notifications (pure rules; Android posting lives in runtime/GmkSignalNotifier).
 *  - a new 3-minute ENTRY of the evidence policy at or above the chosen grade (default S..B; "C" adds the v0.7.56 60% tier) is notified at
 *    once, so S/A/B trades are not missed while the phone is in a pocket (weekday S..B 57.6%, S/A 62.4% over the year);
 *  - [PRE_ALERT_LEAD_SEC] before each time-of-day rule minute (the only S/A source) a reminder is posted.
 * The 1-minute board is observation only and is never notified.
 */
object SignalAlerts {
    val GRADE_ORDER = listOf("S", "A", "B", "C")
    /**
     * v0.7.60: every ENTRY by default. Weekday C (5-minute model, any minute) is most of the 70% ENTRY and arrives at minutes nobody
     * can guess, so it is announced unless the user chose S/A or S..B (a saved choice is kept).
     */
    const val DEFAULT_MIN_GRADE = "C"
    const val PRE_ALERT_LEAD_SEC = 120L
    /** The reminder may be posted during this many seconds from boundary - lead (the scheduler ticks every second). */
    const val PRE_ALERT_WINDOW_SEC = 45L
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    /** v0.7.56: "A" (S/A only), "B" (S..B, the 55%-validated grades) or "C" (every ENTRY incl. the 60% tier C). */
    fun normalizeMinGrade(grade: String?): String = when (grade) { "A" -> "A"; "B" -> "B"; "C" -> "C"; else -> DEFAULT_MIN_GRADE }

    fun shouldNotify(decision: String, grade: String, policyVersion: String, minGrade: String?): Boolean =
        decision == "ENTRY" && RankStatistics.evidenceVersion(policyVersion) != null && grade in GRADE_ORDER &&
            GRADE_ORDER.indexOf(grade) <= GRADE_ORDER.indexOf(normalizeMinGrade(minGrade))

    data class NextRule(val boundary: ZonedDateTime, val rules: List<EventRules.Rule>)

    /** The next 5-minute boundary at or after [now] where a time-of-day rule applies (outside the caution windows). */
    fun nextRule(now: ZonedDateTime, horizonMinutes: Long = 7L * 24L * 60L): NextRule? {
        val z = now.withZoneSameInstant(JST)
        var t = z.truncatedTo(ChronoUnit.MINUTES)
        while (t.minute % 5 != 0) t = t.plusMinutes(1)
        if (t.isBefore(z)) t = t.plusMinutes(5)
        repeat((horizonMinutes / 5L).toInt()) {
            val rules = EventRules.rulesAt(t)
            if (rules.isNotEmpty() && MarketCalendar.caution(t) == null) return NextRule(t, rules)
            t = t.plusMinutes(5)
        }
        return null
    }

    fun ruleName(rule: EventRules.Rule): String = rule.label.substringBefore('・')

    private fun hm(t: ZonedDateTime): String = "%d:%02d".format(t.hour, t.minute)

    /** "次の時間帯ルール 21:30 米指標の発表時刻(NY8:30)（S/A候補・あと12分）" */
    fun nextRuleText(now: ZonedDateTime): String {
        val n = nextRule(now) ?: return "次の時間帯ルール: 7日以内になし"
        val mins = ChronoUnit.MINUTES.between(now.withZoneSameInstant(JST).truncatedTo(ChronoUnit.MINUTES), n.boundary)
        val day = if (n.boundary.toLocalDate() == now.withZoneSameInstant(JST).toLocalDate()) "" else "${n.boundary.monthValue}/${n.boundary.dayOfMonth} "
        val left = if (mins < 120) "・あと${mins}分" else ""
        return "次の時間帯ルール $day${hm(n.boundary)} ${ruleName(n.rules.first())}（S/A候補$left）"
    }

    /** The rule boundary whose reminder is due at [now], or null. */
    fun preAlertDue(now: ZonedDateTime): NextRule? {
        val n = nextRule(now.plusSeconds(PRE_ALERT_LEAD_SEC - PRE_ALERT_WINDOW_SEC), 30L) ?: return null
        val from = n.boundary.minusSeconds(PRE_ALERT_LEAD_SEC)
        return if (!now.isBefore(from) && now.isBefore(from.plusSeconds(PRE_ALERT_WINDOW_SEC))) n else null
    }

    fun preAlertTitle(n: NextRule): String = "まもなく ${hm(n.boundary)} 時間帯ルール（S/A候補）"
    fun preAlertText(n: NextRule): String =
        "${n.rules.joinToString(" / ") { ruleName(it) }}。${hm(n.boundary.minusSeconds(10))}:50 のスキャンで当てはまる通貨があれば S/A です。"

    /** v0.7.57: the judgement length (3 or 5 minutes) is in the title - theoption's expiry must match it. */
    fun entryTitle(grade: String, instrument: String, direction: String, minutes: Int = 3): String =
        "【${minutes}分判定】$grade ENTRY ${CryptoPairs.display(instrument)} ${if (direction == "HIGH") "HIGH（上）" else "LOW（下）"}"

    fun entryText(entryTimeJst: String, judgeTimeJst: String, label: String?): String {
        fun clock(s: String) = runCatching { ZonedDateTime.parse(s).withZoneSameInstant(JST) }.getOrNull()?.let { "%d:%02d:%02d".format(it.hour, it.minute, it.second) } ?: "—"
        return "エントリー ${clock(entryTimeJst)} / 判定 ${clock(judgeTimeJst)}（${minutesBetween(entryTimeJst, judgeTimeJst) ?: "?"}分）" + (label?.let { "\n$it" } ?: "")
    }

    /** Whole minutes from entry to judgement (3 or 5 for the evidence policy), or null when a time is missing. */
    fun minutesBetween(entryTimeJst: String, judgeTimeJst: String): Int? = runCatching {
        java.time.Duration.between(ZonedDateTime.parse(entryTimeJst), ZonedDateTime.parse(judgeTimeJst)).toMinutes().toInt()
    }.getOrNull()

    /** Stable notification id per scan / per rule boundary (positive, below the runtime notification id range). */
    fun notificationId(key: String): Int = 10_000 + Math.floorMod(key.hashCode(), 1_000_000)
}

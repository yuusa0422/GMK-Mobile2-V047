package jp.gmk.mobile.domain

/**
 * v0.7.54: provider timestamps slightly ahead of the phone clock.
 *
 * bitbank stamps every ticker in milliseconds, Yahoo in seconds. When the phone clock runs even a little behind the
 * provider's clock, a brand-new price carries a timestamp "in the future". Up to v0.7.53 such a price had no age at all:
 * bitbank stream ticks were rejected outright, REST and Yahoo prices were shown as LAST, the scan lost its live price
 * (backup model) and the cut-in could not read the current price. A timestamp at most [MAX_AHEAD_MS] ahead of the receive
 * time is now read as "just now" (age 0); anything further ahead stays invalid, as before.
 * The largest lead seen in the last [WINDOW_MS] is kept for the diagnostics: it estimates how far the phone clock is behind.
 */
object ProviderClock {
    const val MAX_AHEAD_MS = 3_000L
    const val WINDOW_MS = 10L * 60_000L
    private val samples = ArrayDeque<LongArray>()   // [receivedMs, aheadMs]
    private var accepted = 0L
    private var rejected = 0L

    /** Usable source time (never later than [receivedMs]); null when missing or implausibly far ahead. */
    fun effective(sourceMs: Long, receivedMs: Long): Long? {
        if (sourceMs <= 0L || receivedMs <= 0L) return null
        if (sourceMs > receivedMs + MAX_AHEAD_MS) return null
        return minOf(sourceMs, receivedMs)
    }

    /** Same for second-resolution timestamps (Yahoo regularMarketTime / candle times). */
    fun effectiveSeconds(sourceSec: Long, receivedMs: Long): Long? =
        effective(sourceSec * 1000L, receivedMs)?.let { it / 1000L }

    /** Records how far a millisecond provider stamp ran ahead of the phone clock (bitbank only). */
    @Synchronized
    fun observe(sourceMs: Long, receivedMs: Long) {
        if (sourceMs <= 0L || receivedMs <= 0L) return
        val ahead = sourceMs - receivedMs
        if (ahead > MAX_AHEAD_MS) rejected++ else accepted++
        if (ahead > 0L) samples.addLast(longArrayOf(receivedMs, ahead))
        while (samples.isNotEmpty() && receivedMs - samples.first()[0] > WINDOW_MS) samples.removeFirst()
        while (samples.size > 2_000) samples.removeFirst()
    }

    /** Largest provider lead in the last [WINDOW_MS] (0 = the phone clock is not behind the provider). */
    @Synchronized
    fun maxAheadMs(nowMs: Long): Long = samples.filter { nowMs - it[0] in 0L..WINDOW_MS }.maxOfOrNull { it[1] } ?: 0L

    @Synchronized
    fun counts(): Pair<Long, Long> = accepted to rejected

    @Synchronized
    fun reset() { samples.clear(); accepted = 0L; rejected = 0L }
}

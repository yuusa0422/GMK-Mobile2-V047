package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.77 連敗結界 (README_V0777.txt, research_v0777/v0777_streak.py): while the newest settled weekday trades of this policy are
 * [K] or more losses in a row (trades entered in the last [WINDOW_SECONDS], results known before the decision), the weekday 5-minute C
 * waits for a stronger trade: the share of the hour's table asked of this slot is multiplied by [PICKY]. The hour still reaches 70%
 * (the catch-up at the end of the hour is unchanged), S/A/B are unchanged. One year, scored on other periods: see [NOTE].
 */
object StreakGuard {
    const val K = 3
    const val PICKY = 0.3
    const val WINDOW_SECONDS = 1800L
    const val NOTE = "連敗結界（3連敗以上の間はCの基準を上げる）: 1年の検証で 3連敗以上の次の勝率 54.2%→54.6%、7連敗以上 60→55回・10連敗以上 8→6回・" +
        "最長 13→11連敗、全体の勝率 53.37%→53.35%。2023〜24年: 次の勝率 53.7%→54.0%、7連敗以上 132→127回・10連敗以上 16→10回（最長は 11→14連敗）、" +
        "全体 52.64%→52.61%。毎時70%以上はそのまま"
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    /**
     * Losses in a row at the newest end of this policy's ENTRY trades (rank 1) entered within [WINDOW_SECONDS] before [entry] whose
     * result is known 10 s before [entry] (judged by then and settled WIN / LOSE; running or unsettled trades are skipped, a draw is a loss).
     */
    fun streak(rows: List<HistoryRow>, entry: ZonedDateTime, policyTag: String): Int {
        val e = entry.toEpochSecond(); val known = e - 10
        val days = setOf(entry.withZoneSameInstant(JST).toLocalDate().toString(), entry.minusSeconds(WINDOW_SECONDS).withZoneSameInstant(JST).toLocalDate().toString())
        val trades = ArrayList<Pair<Long, Boolean>>()
        for (r in rows) {
            if (r.candidateRank != 1 || r.decision != "ENTRY" || !r.policyVersion.startsWith(policyTag)) continue
            if (r.resultStatus != "WIN" && r.resultStatus != "LOSE") continue
            val t = r.entryTimeJst
            if (t.length >= 10 && t.endsWith("+09:00") && t.substring(0, 10) !in days) continue
            val s = runCatching { ZonedDateTime.parse(t).toEpochSecond() }.getOrNull() ?: continue
            if (s >= e || s < e - WINDOW_SECONDS) continue
            val j = runCatching { ZonedDateTime.parse(r.judgeTimeJst).toEpochSecond() }.getOrNull() ?: continue
            if (j > known) continue
            trades.add(s to (r.resultStatus == "WIN"))
        }
        var n = 0
        for ((_, win) in trades.sortedByDescending { it.first }) { if (win) break; n++ }
        return n
    }

    fun active(streak: Int): Boolean = streak >= K

    /** v0.7.78: the guard acts only on weekday 5-minute slots inside the trading hours (for the screen's「連敗結界 発動中」). */
    fun applies(now: ZonedDateTime): Boolean = TradingSession.isWeekday(now) && TradingSession.isActive(now)
}

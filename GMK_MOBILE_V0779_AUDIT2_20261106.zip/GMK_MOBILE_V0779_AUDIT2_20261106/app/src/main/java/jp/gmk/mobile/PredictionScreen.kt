package jp.gmk.mobile

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZonedDateTime

/**
 * v0.7.74 prediction screen (予測): shrine banner, AUTO / countdown / scan button in one card, the TOP1 as a spell card, 残機 and
 * 賽銭箱, the 異変 radar (recent edge, runs, next time rule), then every pair. The long grade explanation is folded away.
 */
@Composable
internal fun ScanScreen(state: GmkUiState, onScan: () -> Unit, onAuto: (Boolean) -> Unit, onM1Auto: (Boolean) -> Unit = {}, onM1Manual: () -> Unit = {}) {
    val evidenceScan = RankStatistics.evidenceVersion(state.scan?.policyVersion.orEmpty()) != null
    val minutes = expiryMinutes(state.scan?.entryTimeJst.orEmpty(), state.scan?.judgeTimeJst.orEmpty(), 3)
    val today = rememberJstToday()
    // v0.7.79: the losing streak once for the 残機 tile and the HUD's Player (both computed it from the whole history every minute)
    val lossStreak = remember(state.history) { ShrineBoard.lossStreak(state.history) }
    val hud = remember(state.history, today, lossStreak) { ShrineHud.of(state.history, today, lossStreak) }
    Box(Modifier.fillMaxSize().background(Gmk.Night)) {
        Image(painterResource(R.drawable.scan_reimu_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = .55f)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x99030A19), Color(0xDD07142A), Color(0xF507142A)))))
        DanmakuBackdrop(Modifier.fillMaxSize())
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
            item(key = "hero") { HeroBanner(state.busy || state.m1Busy) }
            item(key = "control") { ShrineControlCard(state, onScan, onAuto) }
            if (!state.batteryOptimizationExempt || state.backgroundRestricted) item(key = "power") { PowerPolicyWarning(state) }
            item(key = "top1") { Top1Card(state.scan?.top1, minutes, state.scan?.entryTimeJst.orEmpty(), state.scan?.judgeTimeJst.orEmpty()) }
            // v0.7.77: the running trades with their countdown and 優勢 / 劣勢 by the live price
            item(key = "running") { RunningTradesPanel(state) }
            item(key = "m1") { OneMinutePanel(state, onM1Auto, onM1Manual) }
            // v0.7.77: the shooting-game HUD and the おみくじ; v0.7.78: computed once for both (it was computed twice per history change)
            item(key = "board") { ShrineBoardRow(state.history, hud.winStreak, today, lossStreak) }
            item(key = "hud") { ShrineHudPanel(hud, today) }
            item(key = "radar") { IhenRadar(state) }
            item(key = "notice") { NoticeBoard(state) }
            item(key = "list-title") { OfudaTitle("弾幕リスト", if (evidenceScan) "判定は1位だけ・2位以下は参考" else null) }
            val results = state.scan?.candidates.orEmpty()
            val live = state.cryptoRates + state.rates
            if (results.isEmpty()) {
                items(state.rates.filter { it.instrument != "BTCJPY" } + state.cryptoRates) { RateOnlyRow(it) }
            } else {
                items(results) { c -> ResultRow(c, live.firstOrNull { it.instrument == c.instrument }, evidenceScan) }
                val chosen = results.map { it.instrument }.toSet()
                val outside = (state.rates.filter { it.instrument != "BTCJPY" } + state.cryptoRates).filter { it.instrument !in chosen }
                if (outside.isNotEmpty()) {
                    item(key = "outside-title") { OfudaTitle("今回の判定対象外") }
                    items(outside) { RateOnlyRow(it) }
                }
            }
            if (state.lastScanExcluded.isNotEmpty()) item(key = "excluded") {
                Text(state.lastScanExcluded.entries.joinToString(" / ") { "${it.key}: ${it.value}" },
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), color = Color(0xFFFF9AAE), fontSize = 11.sp)
            }
            val divergence = state.quoteCandleDivergencePct.filter { (ins, pct) -> pct >= if (CryptoPairs.isCrypto(ins)) 1.50 else 0.50 }
            if (divergence.isNotEmpty()) item(key = "divergence") {
                Text("価格整合注意: " + divergence.entries.joinToString(" / ") { "${it.key} ${"%.3f".format(it.value)}%" },
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), color = Gmk.Lose, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            item(key = "recent") { RecentHistoryPreview(state.history) }
            item(key = "guide") { GradeGuide(evidenceScan, state.entryMode) }
        }
    }
}

/** The shrine artwork without the phone status bar and the button drawn into its top and bottom edges. */
@Composable
private fun HeroBanner(busy: Boolean) {
    var now by remember { mutableStateOf(ZonedDateTime.now(Gmk.Jst)) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = ZonedDateTime.now(Gmk.Jst) } }
    Box(Modifier.fillMaxWidth()) {
        Image(
            painterResource(R.drawable.scan_reimu_hero), "豪徳寺 三花システム",
            Modifier.fillMaxWidth().aspectRatio(1024f / 555f),
            contentScale = ContentScale.Crop, alignment = BiasAlignment(0f, -0.12f)
        )
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color(0xE607142A)))))
        Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            YinYangOrb(30.dp, spinning = busy)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text(ShrineBoard.stage(now), color = Gmk.Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                // v0.7.77: the hour's difficulty from its validated win rate
                Difficulty.of(now)?.let { DifficultyChip(it) } ?: Text("博麗神社・相場結界", color = Gmk.Paper, fontSize = 10.sp)
            }
        }
    }
}

/** AUTO switch, countdown to the next AUTO and the manual scan button, with the live price count. */
@Composable
private fun ShrineControlCard(state: GmkUiState, onScan: () -> Unit, onAuto: (Boolean) -> Unit) {
    var seconds by remember { mutableStateOf(nextScanSeconds()) }
    LaunchedEffect(Unit) { while (true) { seconds = nextScanSeconds(); delay(1000) } }
    val fx = state.rates.filter { it.instrument != "BTCJPY" }
    val fxLive = fx.count { it.freshnessStatus == "LIVE" }
    val cryptoLive = state.cryptoRates.count { it.freshnessStatus == "LIVE" }
    val allLive = fx.isNotEmpty() && fxLive == fx.size && state.cryptoRates.isNotEmpty() && cryptoLive == state.cryptoRates.size
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), accent = if (allLive) Gmk.Cyan.copy(alpha = .7f) else Gmk.Pink.copy(alpha = .7f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("● FX ${fxLive}/${fx.size.coerceAtLeast(5)}  仮想通貨 ${cryptoLive}/${state.cryptoRates.size.coerceAtLeast(4)} LIVE",
                color = if (allLive) Gmk.Win else Color(0xFFFF8DA8), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("5分AUTO", color = Gmk.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Switch(checked = state.autoScan, onCheckedChange = onAuto)
        }
        Text(AutoClock.scheduleText(ZonedDateTime.now(Gmk.Jst)), color = Gmk.Muted, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (state.autoScan) "次の弾幕（5分AUTO）まで" else "5分AUTO 停止中", color = Gmk.Muted, fontSize = 11.sp)
                Text(if (state.autoScan) AutoClock.countdownText(seconds) else "— : —", color = Gmk.Cyan, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onScan, enabled = !state.busy,
                modifier = Modifier.width(150.dp).heightIn(min = 64.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(12.dp)
            ) {
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 64.dp)
                        .background(Brush.horizontalGradient(listOf(Gmk.ShrineRed, Color(0xFF7B3BFF))), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFFFFB5DA), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp)) {
                        if (state.busy) { YinYangOrb(20.dp, spinning = true); Spacer(Modifier.width(6.dp)) }
                        Text(if (state.busy) "詠唱中…" else "▶ 手動スキャン", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

private fun nextScanSeconds(): Int = AutoClock.nextAutoScanSeconds(ZonedDateTime.now(Gmk.Jst))

/** The TOP1 as a spell card: what to trade on theoption, for how long, and why. */
@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun Top1Card(top: ScanCandidate?, minutes: Int, entryTimeJst: String = "", judgeTimeJst: String = "") {
    val entry = top?.decision == "ENTRY"
    val border = if (entry) Gmk.Gold else Gmk.Line
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .border(if (entry) 2.dp else 1.dp, border, RoundedCornerShape(14.dp))
            .background(Color(0xEE111A33), RoundedCornerShape(14.dp))
    ) {
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(if (entry) listOf(Gmk.ShrineRed, Color(0xFF7C2757), Color(0xFF2E4D91))
                    else listOf(Color(0xFF3B3552), Color(0xFF1E2C4A))), RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("TOP1 スペルカード", color = Gmk.Paper.copy(alpha = .85f), fontSize = 10.sp)
                Text(top?.let { ShrineBoard.spellCard(it) } ?: "符の準備中", color = Color.White,
                    fontWeight = FontWeight.Bold, fontSize = 19.sp)
            }
            if (top != null) Box(
                Modifier.size(46.dp).background(Gmk.Paper, RoundedCornerShape(8.dp)).border(2.dp, Gmk.ShrineRed, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) { Text(if (top.grade == "R") "追" else top.assessment?.subGrade?.shown ?: top.grade, color = Gmk.ShrineRedDark, fontWeight = FontWeight.Bold,
                fontSize = if (top.assessment?.subGrade?.promoted == true) 15.sp else 24.sp, maxLines = 1, softWrap = false) }
        }
        if (top == null) {
            Text("まだスキャン結果がありません。AUTOか手動スキャンを待っています", Modifier.padding(16.dp), color = Gmk.Muted, fontSize = 13.sp)
        } else Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Column {
                    Text(pairLabel(top.instrument), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Gmk.Text, maxLines = 1, softWrap = false)
                    // v0.7.77: the pair's character (display only)
                    ShrineHud.character(top.instrument)?.let { Text("担当 $it", color = Gmk.Pink, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                }
                DirectionBox(top.direction, large = true)
                JudgeBadge(minutes, large = true)
            }
            if (entry) {
                Text("ザオプションで「${minutes}分」を選んでエントリー", color = if (minutes == 5) Gmk.Five else Gmk.Three, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            } else {
                Text("今回は見送り（${top.decision}）", color = Gmk.Muted, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            if (entryTimeJst.isNotBlank()) Text("ENTRY ${formatJstTime(entryTimeJst)}  →  判定 ${formatJstTime(judgeTimeJst)}", color = Gmk.Text, fontSize = 12.sp)
            // v0.7.77: seconds to the entry, then the time left to the judgement
            if (entry && entryTimeJst.isNotBlank()) EntryCountdown(entryTimeJst, judgeTimeJst)
            Text("${if (top.grade == "R") "追加判定" else "運用等級 ${top.grade}${top.assessment?.subGrade?.let { subGradeSuffix(it) } ?: ""}"}  •  ${minutes}分判定  •  ${top.regime}", color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            // v0.7.76: the percentages - C1 / C2 / C3 with the place in the hour, or the probability and the grade's validated rate
            val sub = top.assessment?.subGrade
            if (sub != null) SubGradeStrip(sub)
            else if (top.grade != "R" && top.grade != "I") {
                val weekend = RankStatistics.isWeekend(entryTimeJst) ?: false
                // v0.7.78: a weekday B is picked by the 3-minute model and judged at 5 minutes: its probability is the 3-minute model's
                PercentLine(top.probability?.takeIf { top.grade !in setOf("S", "A") }, EvidencePolicy.gradeRate(true, weekend, top.grade), top.grade,
                    if (top.grade == "B" && !weekend) "3分モデルの確率" else "勝つ確率")
            }
            top.assessment?.correctionLabel?.let { Text(it, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Gmk.Cyan) }
            if (top.decision == "SKIP" && top.skipReasonLabel.isNotBlank()) Text("見送り: ${top.skipReasonLabel}", fontSize = 12.sp, color = Gmk.Muted)
        }
    }
}

/** 残機 (losing streak) and 賽銭箱 (today's results). */
@Composable
private fun ShrineBoardRow(history: List<HistoryRow>, winRun: Int, today: LocalDate, streak: Int) = Column(Modifier.fillMaxWidth()) {
    val tally = remember(history, today) { ShrineBoard.today(history, today) }
    val now = rememberJstNow()
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        BoardTile(Modifier.weight(1f), "残機（連敗）", if (streak >= 3) Gmk.Lose else Gmk.Pink) {
            Text(ShrineBoard.lives(streak), color = if (streak >= 3) Gmk.Lose else Gmk.Pink, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            Text(ShrineBoard.livesNote(streak), color = if (streak >= 3) Gmk.Lose else Gmk.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            // v0.7.77: how usual this streak is at the 70% ENTRY, and the 連敗結界 while it is on
            ShrineBoard.streakVerdict(streak).takeIf { it.isNotEmpty() }?.let { Text(it, color = Gmk.Muted, fontSize = 10.sp) }
            ShrineHud.lastSpell(winRun).takeIf { it.isNotEmpty() }?.let { Text(it, color = Gmk.Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            // v0.7.78: only while it can act (weekday trading hours) and re-checked as time passes (the 30-minute window)
            val guard = remember(history, now) { if (StreakGuard.applies(now)) StreakGuard.streak(history, now, EvidencePolicy.POLICY_TAG) else 0 }
            if (StreakGuard.active(guard)) Text("連敗結界 発動中（平日Cの基準を上げて強い枠を待つ）", color = Gmk.Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        BoardTile(Modifier.weight(1f), "賽銭箱（今日）", Gmk.Gold) {
            val rate = tally.rate
            Text(if (rate == null) "—" else "%.1f%%".format(100.0 * rate), color = if (rate == null) Gmk.Muted else if (rate >= 0.5263) Gmk.Win else Gmk.Lose,
                fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(ShrineBoard.tallyText(tally), color = Gmk.Text, fontSize = 11.sp)
        }
    }
    val hi = remember(history) { ShrineBoard.hiScore(history) }
    // v0.7.78: "最高の日" in stakes (the STG panel's HiScore is in points; two different HI-SCOREs were shown)
    if (hi != null) Text("最高の日 ${"%+.1f".format(hi.second)}口（${hi.first.monthValue}/${hi.first.dayOfMonth}）", Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
        color = Gmk.Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    Text("1口 = 1回の賭け金。1.9倍なので勝ちは+0.9口、負け（同値も）は-1口。損益分岐は52.6%。市場参考レートでの判定です（5分判定の分）。",
        Modifier.padding(horizontal = 14.dp, vertical = 2.dp), color = Gmk.Faint, fontSize = 10.sp)
}

@Composable
private fun BoardTile(modifier: Modifier, title: String, accent: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.border(1.dp, accent.copy(alpha = .7f), RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = .16f), Color(0xE609142B))), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 9.dp)
    ) {
        Text(title, color = Gmk.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

/** 異変レーダー: this version's own recent results, the runs indicator and the next time-of-day rule. */
@Composable
private fun IhenRadar(state: GmkUiState) {
    val today = rememberJstToday()
    val edge = remember(state.history, today) { RecentEdge.of(state.history, today, EvidencePolicy.POLICY_TAG) }
    var now by remember { mutableStateOf(ZonedDateTime.now(Gmk.Jst)) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); now = ZonedDateTime.now(Gmk.Jst) } }
    val nextRule = remember(now.hour, now.minute) { SignalAlerts.nextRuleText(now) }
    val alarm = edge.level == RecentEdge.Level.STOP || state.runRegime?.level == RunRegime.Level.STRONG_RUNS
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), accent = if (alarm) Gmk.Lose else Gmk.Line) {
        Text(if (alarm) "⚠ 異変レーダー：異変発生中" else "☯ 異変レーダー", color = if (alarm) Gmk.Lose else Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(4.dp))
        Text(RecentEdge.label(edge), color = when (edge.level) {
            RecentEdge.Level.STOP -> Gmk.Lose
            RecentEdge.Level.BELOW_BREAK_EVEN -> Gmk.Warn
            RecentEdge.Level.GOOD -> Gmk.Win
            else -> Gmk.Muted
        }, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(RunRegime.label(state.runRegime), color = when (state.runRegime?.level) {
            RunRegime.Level.STRONG_RUNS -> Gmk.Lose
            RunRegime.Level.RUNS -> Gmk.Warn
            RunRegime.Level.CALM -> Gmk.Win
            else -> Gmk.Muted
        }, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(nextRule, color = Gmk.Win, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** 神社の掲示板: what the scanner, the price feeds and the result tracking are doing now. */
@Composable
private fun NoticeBoard(state: GmkUiState) {
    val lines = listOfNotNull(
        state.scanStatus?.let { it.take(220) to Gmk.Text },
        state.rateStatus?.let { it.take(180) to Color(0xFFFFA7B8) },
        state.outcomeStatus?.let { it.take(220) to Gmk.Win },
        state.error?.let { it.take(180) to Gmk.Lose }
    )
    if (lines.isEmpty()) return
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text("📜 神社の掲示板", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        lines.forEach { (text, color) -> Text(text, color = color, fontSize = 11.sp, maxLines = 3) }
    }
}

@Composable
private fun PowerPolicyWarning(state: GmkUiState) {
    val context = LocalContext.current
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), accent = Gmk.Warn) {
        Text("結界のほころび：バックグラウンド制限", color = Gmk.Warn, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(
            if (state.backgroundRestricted) "Androidがバックグラウンド実行を制限中です。AUTOが遅れることがあります。"
            else "電池最適化の対象です。画面OFF中はAUTOが遅れることがあります。",
            color = Gmk.Text, fontSize = 12.sp
        )
        TextButton(onClick = {
            runCatching { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }) { Text("電池最適化の設定を開く", color = Gmk.Cyan) }
    }
}

@Composable
private fun ResultRow(c: ScanCandidate, rate: RateRow?, evidenceScan: Boolean) {
    val reference = evidenceScan && c.rank != 1
    val accent = if (c.direction.uppercase() == "HIGH") Gmk.High else Gmk.Low
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .border(1.dp, accent.copy(alpha = if (c.rank == 1) .95f else .40f), RoundedCornerShape(10.dp))
            .background(if (c.rank == 1) Color(0xE6311834) else Color(0xDD13213D), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).background(if (c.rank == 1) Gmk.ShrineRed else Color(0xFF182A4B), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Text("${c.rank}", fontWeight = FontWeight.Bold, color = if (c.rank == 1) Color.White else Gmk.Gold)
        }
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(pairLabel(c.instrument), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Gmk.Text, maxLines = 1, softWrap = false)
                if (evidenceScan && c.rank == 1) { Spacer(Modifier.width(6.dp)); JudgeBadge(c.assessment?.chosenAction?.judgeMinutes ?: 3) }
            }
            Text("${rate?.price?.let(::formatPrice) ?: "—"}  •  ${c.regime}", fontSize = 11.sp, color = Gmk.Muted)
            if (reference) Text("参考（判定は1位だけ）", fontSize = 10.sp, color = Gmk.Faint)
            else c.assessment?.correctionLabel?.let { Text(it, fontSize = 11.sp, color = Gmk.Cyan) }
        }
        DirectionBox(c.direction)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            val gradeText = if (reference) "—" else c.assessment?.subGrade?.shown ?: c.grade
            Text(gradeText, fontSize = if (gradeText.length > 2) 12.sp else 17.sp, fontWeight = FontWeight.Bold, color = Gmk.Gold, maxLines = 1, softWrap = false)
            if (!reference) c.probability?.takeIf { it.isFinite() && c.grade !in setOf("S", "A", "R", "I") }?.let {
                Text(String.format(java.util.Locale.US, "%.1f%%", it * 100.0), fontSize = 10.sp, color = Gmk.Text)
            }
            val shown = when { c.rank == 1 -> c.decision; reference -> "参考"; else -> c.decision }
            Text(shown, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (c.rank == 1 && c.decision == "ENTRY") Gmk.Win else Gmk.Muted, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun RateOnlyRow(r: RateRow) {
    val status = when {
        r.price == null -> "取得なし"
        else -> r.freshnessStatus
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .border(1.dp, Color(0x5535D9FF), RoundedCornerShape(10.dp))
            .background(Color(0xDD13213D), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(pairLabel(r.instrument), Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Gmk.Text, fontSize = 15.sp)
        Column(horizontalAlignment = Alignment.End) {
            Text(r.price?.let(::formatPrice) ?: "—", fontWeight = FontWeight.Bold, color = Gmk.Text, fontSize = 15.sp)
            Text("$status${r.ageSeconds?.let { " ${it.toInt()}s" } ?: ""}  ${r.source}", fontSize = 10.sp,
                color = when (status) { "LIVE" -> Gmk.Win; "LAST" -> Gmk.Gold; else -> Gmk.Lose })
        }
    }
}

/** The newest five results, readable on the night background (v0.7.73 drew them in dark ink on it). */
@Composable
private fun RecentHistoryPreview(rows: List<HistoryRow>) = Column(Modifier.fillMaxWidth()) {
    OfudaTitle("直近の弾幕結果")
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        if (rows.isEmpty()) Text("まだ結果はありません。", fontSize = 12.sp, color = Gmk.Muted, modifier = Modifier.padding(6.dp))
        rows.take(5).forEach { h ->
            val (label, color) = historyStatusShort(h)
            Row(
                Modifier.fillMaxWidth().padding(vertical = 2.dp).background(Color(0xCC101B34), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(pairLabel(h.instrument), Modifier.width(82.dp), fontWeight = FontWeight.Bold, color = Gmk.Text, fontSize = 13.sp, maxLines = 1, softWrap = false)
                Text(if (h.direction == "HIGH") "▲HIGH" else "▼LOW", Modifier.width(62.dp), color = if (h.direction == "HIGH") Gmk.High else Gmk.Low,
                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
                if (RankStatistics.evidenceVersion(h.policyVersion) != null || OneMinutePolicy.isPolicy(h)) JudgeBadge(expiryMinutes(h.entryTimeJst, h.judgeTimeJst, 3))
                Spacer(Modifier.weight(1f))
                Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

/** Short result label and colour of a history row (prediction screen preview). */
internal fun historyStatusShort(h: HistoryRow): Pair<String, Color> = when {
    h.decision == "SKIP" -> (if (h.resultStatus in setOf("WIN", "LOSE")) "見送り(${h.resultStatus})" else "見送り") to Gmk.Faint
    h.resultStatus == "WIN" -> "✿ 解決 WIN" to Gmk.Win
    h.resultStatus == "LOSE" -> "被弾 LOSE" to Gmk.Lose
    h.resultStatus == "WAIT_ENTRY" -> "ENTRY待ち" to Gmk.Purple
    h.resultStatus == "WAIT_JUDGE" -> "${expiryMinutes(h.entryTimeJst, h.judgeTimeJst, 3)}分判定待ち" to Gmk.Purple
    h.resultStatus.contains("MISSED") || h.resultStatus.contains("MISSING") -> "取得失敗" to Gmk.Warn
    h.resultStatus.startsWith("INVALID") -> "集計除外" to Gmk.Warn
    h.resultStatus == "LEGACY_NO_OUTCOME" -> "旧履歴" to Gmk.Faint
    else -> h.resultStatus to Gmk.Muted
}

private fun pct1(segment: String, label: String): String = SubGrades.band(segment, label)?.let { String.format(java.util.Locale.US, "%.1f%%", it.rate * 100.0) } ?: "—"
private fun bandsRates(segment: String): String = SubGrades.LABELS.joinToString("・") { "$it ${pct1(segment, it)}" }

/** The grade explanation, folded by default (it filled most of the screen). */
@Composable
private fun GradeGuide(evidenceScan: Boolean, entryModeKey: String) {
    var open by rememberSaveable { mutableStateOf(false) }
    val mode = EntryMode.parse(entryModeKey)
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(if (open) "▲ 運用等級の説明をとじる" else "▼ 運用等級（スペルカード）の説明", color = Gmk.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 8.dp))
        if (open) {
            val lines = listOf(
                "「夢想天生」= S、霊符「夢想封印」= A：時間帯ルール（仲値9:55・米指標8:30。ほかのサインも揃うとS）→【3分判定】",
                "神技「八方鬼縛陣」= B：強い取引×直前1分の一致 →【5分判定】",
                "夢符「封魔陣」= C：5分モデルが70%に入る側 →【5分判定】（土日は仮想通貨4つ・全部3分判定）",
                "v0.7.77 連敗結界: 平日に3連敗以上（結果の出た取引・30分以内）の間は、Cの基準を上げて強い枠を待つ（毎時70%以上はそのまま）。1年の検証で3連敗の次の勝率 54.2%→54.6%、10連敗以上 年8→6回",
                "v0.7.76 Cの中の強さ: その時間の上位何%か（霊力ゲージ）で C1 / C2 / C3。平日 C1（上位10%）${pct1(SubGrades.WEEKDAY, "C1")}・C2（10〜30%）${pct1(SubGrades.WEEKDAY, "C2")}・C3 ${pct1(SubGrades.WEEKDAY, "C3")}" +
                    "／土日 ${bandsRates(SubGrades.WEEKEND)}／1分 ${bandsRates(SubGrades.M1_WEEKDAY)}。平日と土日のC1はBと同じくらい強いので、帳簿タブの「C1をBに昇格」をONにするとBで入る（初期はOFF・1分のC1はCのまま）",
                "結界「見送りの陣」= D〜H：見送り（理由つき）、I = 判定不能",
                "1年の検証: S/A/B は55%以上（土日Bは61.2%）、C は平日53.1%・土日54.9%。平日は円の5ペア＋仮想通貨4つを5分ごとに判定し、どの1時間も70%以上ENTRY。",
                "ENTRYの量「${mode.label}」: ${mode.summary}（帳簿タブで変更）。等級は1位だけ、2位以下は参考。"
            )
            (if (evidenceScan) lines else listOf("旧バージョンのスキャン結果です。次の判定から今の運用等級で表示します。") + lines)
                .forEach { Text("・$it", color = Gmk.Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        }
    }
}

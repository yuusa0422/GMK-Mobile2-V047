package jp.gmk.mobile.domain

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.63: Japanese bank holidays (national holidays + the bank closing days Dec 31 - Jan 3) from Nov 2026.
 * There is no Tokyo 9:55 fixing on these days, so the FIX955 rules (built on the fixing flows) do not trade them.
 * Research: FIX955 on Japanese holidays won 11 of 24 (45.8%; 2025-26 and 2023-24) against 62-68% on normal days.
 * Earlier dates are left out on purpose: the rule research fixtures (Oct 2025 - Oct 2026) stay exactly as they were.
 */
object JapanHolidays {
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    val DATES: Set<LocalDate> = listOf(
        "2026-11-03", "2026-11-23", "2026-12-31",
        "2027-01-01", "2027-01-02", "2027-01-03", "2027-01-11", "2027-02-11", "2027-02-23", "2027-03-22", "2027-04-29",
        "2027-05-03", "2027-05-04", "2027-05-05", "2027-07-19", "2027-08-11", "2027-09-20", "2027-09-23", "2027-10-11",
        "2027-11-03", "2027-11-23", "2027-12-31",
        "2028-01-01", "2028-01-02", "2028-01-03"
    ).map(LocalDate::parse).toSet()

    fun isBankHoliday(t: ZonedDateTime): Boolean = t.withZoneSameInstant(JST).toLocalDate() in DATES
}

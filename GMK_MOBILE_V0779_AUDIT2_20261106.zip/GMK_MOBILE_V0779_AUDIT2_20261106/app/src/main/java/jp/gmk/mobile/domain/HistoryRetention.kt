package jp.gmk.mobile.domain

/**
 * v0.7.78: what the history keeps. The 1-minute judgment adds up to ~670 rows a day (80% of 14 x 60 minutes), the 5-minute AUTO 168, so
 * with one 20,000-row limit the 5-minute history (the ledger, the monitor, HI-SCORE, the 称号) had shrunk to about three weeks. Now the
 * 1-minute rows (the v0.7.75 judgment and the old 1-minute board) keep at most [ONE_MINUTE_KEEP] (about nine days) of their own: once
 * there are more than [ONE_MINUTE_KEEP] + [ONE_MINUTE_SLACK], the oldest 1-minute rows are dropped down to [ONE_MINUTE_KEEP] (so the
 * archive file is rewritten about once in a day and a half, not every minute). Then the newest [max] rows of all are kept.
 * Rows are newest first.
 */
object HistoryRetention {
    const val MAX_ROWS = 20_000
    const val ONE_MINUTE_KEEP = 6_000
    const val ONE_MINUTE_SLACK = 1_000

    fun trim(rows: List<HistoryRow>, max: Int = MAX_ROWS, keep: Int = ONE_MINUTE_KEEP, slack: Int = ONE_MINUTE_SLACK): List<HistoryRow> {
        val oneMinute = rows.count { RankStatistics.isOneMinute(it) }
        val out = if (oneMinute <= keep + slack) rows else {
            var seen = 0
            rows.filter { r -> !RankStatistics.isOneMinute(r) || ++seen <= keep }
        }
        return if (out.size > max) out.take(max) else out
    }
}

package jp.gmk.mobile.runtime

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import jp.gmk.mobile.MainActivity

/**
 * v0.7.54 signal notifications (rules in domain/SignalAlerts). A refused permission or an OS error never affects a scan:
 * every failure simply returns false and is counted in the diagnostics.
 */
object GmkSignalNotifier {
    private const val CHANNEL_ID = "gmk_signals_v0754"
    @Volatile var posted = 0L
        private set
    @Volatile var failed = 0L
        private set
    @Volatile var lastError: String? = null
        private set

    fun permitted(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** The channel's text as Android shows it in the app's notification settings. */
    const val CHANNEL_DESCRIPTION = "ENTRY（S/Aは3分判定・B/Cは5分判定・土日は3分判定）と、時間帯ルール（S/A候補）の2分前のお知らせ"

    private fun ensureChannel(manager: NotificationManager) {
        // v0.7.79: created on every post - Android keeps the user's importance / sound and only updates the name and description,
        // so the old text (v0.7.54 "3分のENTRY（S〜B）") is replaced on the phones that already have the channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "GMK シグナル", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = CHANNEL_DESCRIPTION
                    setShowBadge(true)
                }
            )
        }
    }

    fun post(context: Context, id: Int, title: String, text: String, timeoutMs: Long): Boolean {
        if (!permitted(context)) { failed++; lastError = "POST_NOTIFICATIONS not granted"; return false }
        return try {
            val manager = ContextCompat.getSystemService(context, NotificationManager::class.java)
                ?: run { failed++; lastError = "NotificationManager unavailable"; return false }
            ensureChannel(manager)
            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(title)
                .setContentText(text.lineSequence().firstOrNull().orEmpty())
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setTimeoutAfter(timeoutMs)
                .setContentIntent(open)
                .build()
            manager.notify(id, notification)
            posted++
            true
        } catch (e: SecurityException) {
            failed++; lastError = "SecurityException: ${e.message.orEmpty()}".take(160); false
        } catch (e: RuntimeException) {
            failed++; lastError = "${e.javaClass.simpleName}: ${e.message.orEmpty()}".take(160); false
        }
    }
}

package jp.gmk.mobile.domain

import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * v0.7.69: the history was saved as ONE SharedPreferences value with every row (about 2.2 KB each, up to 20,000 rows = 44 MB)
 * plus a second copy ("items_backup") in the same file. Android keeps every SharedPreferences value in memory for the life of
 * the process and rewrites the whole file on each commit, so with weeks of every-minute AUTO the app would hold ~176 MB of
 * strings and rewrite ~88 MB up to three times a minute (memory crash, battery, flash wear).
 *
 * Now only the newest rows ("recent", at most [RECENT_MAX]) are rewritten on each save. Older rows go to an archive file that
 * is written only when the recent part overflows (then the newest [RECENT_KEEP] stay recent) or when an archived row changes.
 * Nothing is dropped: the rows kept, their order and the 20,000-row limit are the same as before.
 */
object HistoryArchivePlan {
    const val RECENT_KEEP = 300
    const val RECENT_MAX = 800

    data class Plan(val recent: List<HistoryRow>, val archive: List<HistoryRow>, val writeArchive: Boolean)

    /**
     * [snapshot] is the whole history (newest first); [persistedArchive] the archive as it is on disk (newest first).
     * The archive is kept as it is when its rows are, unchanged, the tail of the snapshot (rows trimmed at the 20,000 limit
     * may still be in the file; [merge] callers apply the limit) and at most [max] rows are newer.
     */
    fun plan(snapshot: List<HistoryRow>, persistedArchive: List<HistoryRow>, forceArchive: Boolean = false,
             keep: Int = RECENT_KEEP, max: Int = RECENT_MAX): Plan {
        if (!forceArchive) {
            if (persistedArchive.isEmpty()) {
                if (snapshot.size <= max) return Plan(snapshot, emptyList(), false)
            } else {
                val s = archiveStart(snapshot, persistedArchive, max)
                if (s >= 0) return Plan(snapshot.subList(0, s).toList(), persistedArchive, false)
            }
        }
        val k = if (snapshot.size <= max) snapshot.size else minOf(keep, snapshot.size)
        return Plan(snapshot.subList(0, k).toList(), snapshot.subList(k, snapshot.size).toList(), true)
    }

    /** Index in [snapshot] where the unchanged archive begins, or -1 (a changed archived row, more than [max] newer rows, ...). */
    fun archiveStart(snapshot: List<HistoryRow>, archive: List<HistoryRow>, max: Int = RECENT_MAX): Int {
        if (archive.isEmpty() || snapshot.isEmpty()) return -1
        val first = archive[0]
        var s = -1
        for (i in 0..minOf(max, snapshot.size - 1)) if (snapshot[i] == first) { s = i; break }
        if (s < 0) return -1
        val n = snapshot.size - s
        if (n > archive.size) return -1
        for (j in 0 until n) if (snapshot[s + j] != archive[j]) return -1
        return s
    }

    /** The same row in both parts (a stop between the archive write and the recent write) is taken once, in its archive version. */
    fun merge(recent: List<HistoryRow>, archive: List<HistoryRow>, limit: Int): List<HistoryRow> {
        if (archive.isEmpty()) return if (recent.size > limit) recent.take(limit) else recent
        val keys = archive.mapTo(HashSet(archive.size * 2)) { key(it) }
        val out = ArrayList<HistoryRow>(minOf(limit, recent.size + archive.size))
        for (r in recent) if (key(r) !in keys) { if (out.size >= limit) return out; out.add(r) }
        for (r in archive) { if (out.size >= limit) return out; out.add(r) }
        return out
    }

    fun key(r: HistoryRow): String = "${r.id}|${r.scanId}|${r.atJst}"
}

/**
 * v0.7.69: a file of text lines replaced atomically - the new lines are streamed to "<name>.tmp" and synced, the current file
 * becomes "<name>.prev" (one earlier version is kept), then the temporary file is renamed over the name. A stop at any point
 * leaves either the old or the new complete file ([read] also completes a rename that a stop interrupted). Lines are streamed
 * both ways, so a 20,000-row history is never one giant string in memory.
 */
class AtomicLinesFile(val file: File) {
    private val tmp = File(file.path + ".tmp")
    val previous = File(file.path + ".prev")
    val corrupt = File(file.path + ".corrupt")

    @Synchronized fun <T> read(block: (Sequence<String>) -> T): T? {
        if (!file.isFile && tmp.isFile) tmp.renameTo(file)          // the new file was complete before the current one was moved away
        return if (file.isFile) file.bufferedReader(Charsets.UTF_8).useLines(block) else null
    }

    @Synchronized fun <T> readPrevious(block: (Sequence<String>) -> T): T? =
        if (previous.isFile) previous.bufferedReader(Charsets.UTF_8).useLines(block) else null

    @Synchronized fun exists(): Boolean = file.isFile || tmp.isFile

    /** Throws when the lines could not be written; the current file is then unchanged. */
    @Synchronized fun write(lines: Sequence<String>, keepPrevious: Boolean = true) {
        file.parentFile?.mkdirs()
        FileOutputStream(tmp).use { out ->
            val w = out.bufferedWriter(Charsets.UTF_8)
            for (line in lines) { w.write(line); w.write("\n") }
            w.flush(); out.fd.sync()
        }
        if (keepPrevious && file.isFile && !file.renameTo(previous)) throw IOException("cannot keep the previous ${file.name}")
        if (!tmp.renameTo(file)) throw IOException("cannot replace ${file.name}")
    }

    /** Moves an unreadable current file aside ("<name>.corrupt"), so the next write cannot push the good ".prev" out. */
    @Synchronized fun quarantine(): Boolean = file.isFile && file.renameTo(corrupt)

    fun length(): Long = if (file.isFile) file.length() else 0L
}

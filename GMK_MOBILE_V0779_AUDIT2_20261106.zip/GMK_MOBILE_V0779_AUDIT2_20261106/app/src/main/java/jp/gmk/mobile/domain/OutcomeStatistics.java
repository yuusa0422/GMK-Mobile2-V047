package jp.gmk.mobile.domain;

import java.time.Duration;
import java.util.*;

/** Shared UI and diagnostic definition: resolved ENTRY only; SKIP never loses. */
public final class OutcomeStatistics {
    private OutcomeStatistics() {}
    public static final class Row {
        public final String decision,status,entryAt,judgeAt,policy;
        public final Double entryRate,judgeRate;
        public Row(String decision,String status,String entryAt,String judgeAt,String policy,Double entryRate,Double judgeRate) {
            this.decision=decision;this.status=status;this.entryAt=entryAt;this.judgeAt=judgeAt;this.policy=policy;this.entryRate=entryRate;this.judgeRate=judgeRate;
        }
        public int minutes() {
            try {
                // v0.7.79: FastTime reads the stored form without the text parser (the same instants as ZonedDateTime.parse)
                java.time.Instant entry=FastTime.instant(entryAt),judge=FastTime.instant(judgeAt);
                if(entry==null||judge==null)return 0;
                Duration duration=Duration.between(entry,judge);
                if(duration.getNano()!=0)return 0;
                long seconds=duration.getSeconds();
                return seconds>0 && seconds%60==0 && seconds<=86400?(int)(seconds/60):0;
            } catch(RuntimeException e){return 0;}
        }
    }
    public static final class Summary {
        public int wins,losses,draws,pending,missed,entries,skips,skipShadow;
        /** v0.7.54: "if entered" results of followed SKIP rows (observation only, never in the win rate or a streak). */
        public int skipShadowWins;
        public int currentLossStreak,maxConsecutiveLosses,runsAtLeast3,runsAtLeast5;
        public int resolved(){return wins+losses;}
        public Double winRate(){return resolved()>0?100.0*wins/resolved():null;}
        public Double shadowWinRate(){return skipShadow>0?100.0*skipShadowWins/skipShadow:null;}
        public void accept(Row row) {
            if(row.decision.equals("SKIP")){skips++;if(row.status.equals("WIN")||row.status.equals("LOSE"))skipShadow++;if(row.status.equals("WIN"))skipShadowWins++;return;}
            if(!row.decision.equals("ENTRY"))return;
            entries++;
            if(row.status.equals("WIN")){wins++;currentLossStreak=0;}
            else if(row.status.equals("LOSE")){
                losses++;
                currentLossStreak++;
                maxConsecutiveLosses=Math.max(maxConsecutiveLosses,currentLossStreak);
                if(currentLossStreak==3)runsAtLeast3++;
                if(currentLossStreak==5)runsAtLeast5++;
                if(row.entryRate!=null && row.judgeRate!=null && Double.isFinite(row.entryRate) && row.entryRate.doubleValue()==row.judgeRate.doubleValue())draws++;
            } else if(row.status.equals("WAIT_ENTRY")||row.status.equals("WAIT_JUDGE"))pending++;
            else missed++;
        }
    }
    public static Map<Integer,Summary> byHorizon(Collection<Row> rows) {
        Map<Integer,Summary> result=new LinkedHashMap<>();
        for(int m:new int[]{3,5,1,10,15,0})result.put(m,new Summary());
        for(Row r:chronological(rows))result.computeIfAbsent(r.minutes(),key->new Summary()).accept(r);
        return result;
    }
    private static java.time.Instant entryInstant(Row row) {
        java.time.Instant at=FastTime.instant(row.entryAt);
        return at==null?java.time.Instant.MAX:at;
    }
    /**
     * v0.7.78: each entry time is parsed once (it was parsed inside the comparator, about 2 n log n times per call: seconds of main-thread
     * work on 20,000 rows). The sort is stable, so rows of the same time keep their order as before.
     */
    private static List<Row> chronological(Collection<Row> rows) {
        List<Map.Entry<java.time.Instant,Row>> keyed=new ArrayList<>(rows.size());
        for(Row r:rows)keyed.add(new AbstractMap.SimpleImmutableEntry<>(entryInstant(r),r));
        keyed.sort(Map.Entry.comparingByKey());
        List<Row> sorted=new ArrayList<>(keyed.size());
        for(Map.Entry<java.time.Instant,Row> e:keyed)sorted.add(e.getValue());
        return sorted;
    }
    public static Summary overall(Collection<Row> rows) {
        Summary result=new Summary();
        for(Row row:chronological(rows))if(row.minutes()>0)result.accept(row);
        return result;
    }
}

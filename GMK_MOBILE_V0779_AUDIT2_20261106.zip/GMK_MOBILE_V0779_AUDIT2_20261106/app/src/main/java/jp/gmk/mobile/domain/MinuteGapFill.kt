package jp.gmk.mobile.domain

import java.time.Instant
import java.time.ZoneId

/**
 * v0.7.65: Yahoo's 1-minute FX chart never contains the candle of the minute before its daily roll (00:00 London time):
 * 07:59 JST while Britain is on summer time, 08:59 JST in winter (from 2026-10-26). One missing candle breaks the 61 contiguous
 * candles the model needs (opens B-3720 .. B-120), so every weekday scan from 9:01 to 10:01 JST was "判定不能 I" and the
 * 9 o'clock hour had no ENTRY at all.
 *
 * A single missing minute between two candles is rebuilt from its neighbours: open = previous close, close = next open,
 * high/low = their max/min, volume 0 (the research data has the real candle there; its close is the next open to within a tick).
 * Gaps of two or more minutes are left as they are, so real data trouble still stops the model.
 */
object MinuteGapFill {
    const val STEP_MS = 60_000L
    const val MAX_MISSING = 1L

    data class Filled(val candles: List<Candle>, val filledMinutes: List<Long>)

    fun fill(candles: List<Candle>): Filled {
        val s = candles.sortedBy { it.timeEpochMs }.distinctBy { it.timeEpochMs }
        if (s.size < 2) return Filled(s, emptyList())
        val out = ArrayList<Candle>(s.size + 2); val filled = ArrayList<Long>()
        out.add(s[0])
        for (i in 1 until s.size) {
            val prev = s[i - 1]; val next = s[i]; val gap = next.timeEpochMs - prev.timeEpochMs
            if (gap % STEP_MS == 0L && gap / STEP_MS - 1 in 1..MAX_MISSING) {
                for (k in 1 until gap / STEP_MS) {
                    val o = prev.close; val c = next.open
                    out.add(Candle(prev.timeEpochMs + k * STEP_MS, o, maxOf(o, c), minOf(o, c), c, 0.0)); filled.add(prev.timeEpochMs + k * STEP_MS)
                }
            }
            out.add(next)
        }
        return Filled(out, filled)
    }
}

/** Which minutes were rebuilt (distinct, newest kept), for the diagnostics. */
object GapFillBoard {
    private const val KEEP = 200
    private val minutes = HashMap<String, java.util.TreeSet<Long>>()
    private val total = HashMap<String, Int>()

    @Synchronized fun record(instrument: String, filled: List<Long>) {
        if (filled.isEmpty()) return
        val set = minutes.getOrPut(instrument) { java.util.TreeSet() }
        for (t in filled) if (set.add(t)) total[instrument] = (total[instrument] ?: 0) + 1
        while (set.size > KEEP) set.pollFirst()
    }

    data class Entry(val distinctFilled: Int, val recentJst: List<String>)

    /** instrument -> how many distinct minutes were rebuilt and the newest five (JST, newest first). */
    @Synchronized fun snapshot(): Map<String, Entry> {
        val jst = ZoneId.of("Asia/Tokyo")
        return minutes.mapValues { (inst, set) ->
            Entry(total[inst] ?: 0, set.descendingSet().take(5).map { Instant.ofEpochMilli(it).atZone(jst).toLocalDateTime().toString() })
        }
    }
}

package jp.gmk.mobile.domain

import jp.gmk.mobile.domain.horizon.HorizonFeatureService
import java.time.Duration
import java.time.ZonedDateTime

/** Explicit projection after PC action selection; never presented as the PC variable expiry. */
object ExpiryProfiles {
    fun apply(result: ScanResult, fixed: Boolean): ScanResult {
        if (!fixed || result.source != "AUTO") return result
        if (result.policyVersion.endsWith("_3M_FIXED")) return result
        val entry = runCatching { ZonedDateTime.parse(result.entryTimeJst) }.getOrNull() ?: return result
        if (!HorizonFeatureService.scheduled(entry.toEpochSecond())) return result
        val modelMinutes = runCatching { Duration.between(entry,ZonedDateTime.parse(result.judgeTimeJst)).toMinutes() }.getOrNull()
        return result.copy(judgeTimeJst=entry.plusMinutes(3).toString(),policyVersion=result.policyVersion+"_3M_FIXED",
            candidates=result.candidates.map { c -> if(c.rank!=1)c else c.copy(reasons=
                listOf("判定: 3分", "3分固定 / モデル選択=${modelMinutes ?: "不明"}分")+c.reasons.filterNot { it.startsWith("判定:") },
                assessment=c.assessment?.let { a -> if(a.chosenAction.judgeMinutes==3)a else a.copy(
                    chosenAction=a.chosenAction.copy(judgeMinutes=3),
                    correctionLabel=listOfNotNull(a.correctionLabel,"3分固定 / モデル選択=${modelMinutes ?: "不明"}分").joinToString(" / ")) }) })
    }
    /**
     * v0.7.50: the evidence policy (GMK_V0740*, v0.7.44+) always judges 3 minutes, so its rows count whatever the
     * "3分判定に固定" switch says (before, weekend rows were dropped while the switch was ON). The 1-minute board
     * (GMK_V0735_NATIVE_1M) is counted too - before, the 1分判定 tile could never show a result.
     */
    fun includes(row: HistoryRow, fixed: Boolean, includeLegacy: Boolean): Boolean =
        includeLegacy || RankStatistics.evidenceVersion(row.policyVersion) != null || RankStatistics.isOneMinute(row) ||
            ((row.policyVersion.startsWith("GMK_V0736") || row.policyVersion.startsWith("GMK_V0740")) &&
                (row.source != "AUTO" || row.policyVersion.endsWith("_3M_FIXED") == fixed))
}

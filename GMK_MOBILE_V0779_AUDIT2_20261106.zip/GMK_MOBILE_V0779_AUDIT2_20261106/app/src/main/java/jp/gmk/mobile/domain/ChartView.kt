package jp.gmk.mobile.domain

/**
 * v0.7.74: which candles the chart draws. The chart used to squeeze every fetched candle (a whole day of 1-minute bars) into one
 * screen width; now it shows the newest [DEFAULT_SPAN] bars (or the chosen number), with the price scale fitted to those bars.
 * Indicators are still computed over all fetched candles, so a band or MACD at the left edge is the same as before.
 */
object ChartWindow {
    val SPANS = listOf(30, 60, 120, 240)
    const val DEFAULT_SPAN = 60

    /**
     * Index range of the [span] bars to draw among [times] (oldest first): the newest ones, or, when [focusMs] (a history ENTRY) is
     * inside the candles, the bars with the focus at about two thirds so the judge time after it stays visible. All bars when
     * [span] <= 0 or there are fewer bars than [span].
     */
    fun range(times: List<Long>, span: Int, focusMs: Long? = null): IntRange {
        val n = times.size
        if (n == 0) return IntRange.EMPTY
        if (span <= 0 || span >= n) return 0 until n
        var end = n
        if (focusMs != null && focusMs >= times.first()) {
            val i = times.indexOfLast { it <= focusMs }
            if (i >= 0) end = (i + 1 + span / 3).coerceIn(span, n)
        }
        return (end - span) until end
    }

    /** Lowest and highest of [prices] (finite and positive only) with 7% padding; null when there is none. */
    fun priceRange(prices: List<Double>): Pair<Double, Double>? {
        val ok = prices.filter { it.isFinite() && it > 0.0 }
        if (ok.isEmpty()) return null
        val lo = ok.minOrNull()!!; val hi = ok.maxOrNull()!!
        val pad = ((hi - lo) * .07).coerceAtLeast(hi * .00002)
        return (lo - pad) to (hi + pad)
    }

    /** [count] evenly spaced price levels from [hi] down to [lo] (the labels beside the chart). */
    fun levels(lo: Double, hi: Double, count: Int = 5): List<Double> =
        if (count < 2) listOf(hi) else (0 until count).map { hi - (hi - lo) * it / (count - 1) }
}

/**
 * v0.7.74: the pure part of the crypto chart candles (data/CryptoChartRepository.kt): request window, 4h from 1h, finished candles
 * only, X/JPY from X/USD. Display only; the decisions never read these candles.
 */
object CryptoChartMath {
    /** Source candle size (seconds) of a chart timeframe; 4h is built from 1h candles. */
    fun granularitySeconds(timeframe: String): Int = when (timeframe) {
        "1m" -> 60; "5m" -> 300; "15m" -> 900; "1h", "4h" -> 3600; "1d" -> 86400; else -> 0
    }
    fun binanceInterval(timeframe: String): String = when (timeframe) {
        "1m" -> "1m"; "5m" -> "5m"; "15m" -> "15m"; "1h", "4h" -> "1h"; "1d" -> "1d"; else -> "1m"
    }
    fun periodMs(timeframe: String): Long = when (timeframe) {
        "1m" -> 60_000L; "5m" -> 300_000L; "15m" -> 900_000L; "1h" -> 3_600_000L; "4h" -> 14_400_000L; "1d" -> 86_400_000L; else -> 60_000L
    }

    /** (start, end) in seconds: the newest 300 source candles (Coinbase's limit), or 220 before and 70 after a focused time. */
    fun window(granularitySec: Int, focusMs: Long?, nowMs: Long): Pair<Long, Long> {
        val nowSec = nowMs / 1000L
        val g = granularitySec.toLong()
        if (focusMs != null && focusMs < nowMs - g * 1000L) {
            val f = focusMs / 1000L
            return (f - g * 220L) to minOf(f + g * 70L, nowSec)
        }
        return (nowSec - g * 299L) to nowSec
    }

    /** [sourceMs] candles grouped into [periodMs] buckets (4h from 1h); unchanged when the source already has that size. */
    fun aggregate(c: List<Candle>, sourceMs: Long, periodMs: Long): List<Candle> {
        if (sourceMs >= periodMs || c.isEmpty()) return c
        val per = (periodMs / sourceMs).toInt()
        // a bucket cut by the window start (fewer source candles than it holds) is left out
        return c.groupBy { (it.timeEpochMs / periodMs) * periodMs }.toSortedMap().entries
            .filterIndexed { i, e -> i > 0 || e.value.size >= per }
            .map { (t, rows) -> Candle(t, rows.first().open, rows.maxOf { it.high }, rows.minOf { it.low }, rows.last().close, rows.sumOf { it.volume }) }
    }

    /** Only finished candles (the forming one is left out, like the FX chart). */
    fun confirmed(c: List<Candle>, periodMs: Long, nowMs: Long): List<Candle> = c.filter { it.timeEpochMs + periodMs <= nowMs }

    /** X/JPY candles: [usd] x USD/JPY candles ([usdjpy]); when those are missing, x the latest USD/JPY rate [usdjpyLive]. */
    fun inYen(usd: List<Candle>, usdjpy: List<Candle>, usdjpyLive: Double?): List<Candle> {
        val fx = usdjpy.ifEmpty {
            val r = usdjpyLive?.takeIf { it.isFinite() && it > 0.0 } ?: return emptyList()
            listOf(Candle(0L, r, r, r, r))
        }
        return CryptoPairs.toYen(usd, fx)
    }
}

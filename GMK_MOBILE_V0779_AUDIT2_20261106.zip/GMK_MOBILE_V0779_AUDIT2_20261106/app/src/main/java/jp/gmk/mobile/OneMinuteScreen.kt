package jp.gmk.mobile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZonedDateTime

/**
 * v0.7.75 1-minute judgment panel (弾幕モード): 1分AUTO switch, manual 1-minute scan, the newest 1-minute signal with the seconds to
 * its entry, this hour's ENTRY share, today's 1-minute results and the one-year check (shown as it is: below the 1.9x break-even).
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun OneMinutePanel(state: GmkUiState, onAuto: (Boolean) -> Unit, onManual: () -> Unit) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { nowMs = System.currentTimeMillis(); delay(500) } }
    val scan = state.m1Scan
    val top = scan?.top1
    val entryMs = scan?.entryTimeJst?.let(::parseJstMs)
    val now = remember(nowMs / 15_000) { ZonedDateTime.now(Gmk.Jst) }
    val entered = remember(state.history, now) { OneMinutePolicy.enteredInHour(state.history, now) }
    val today = rememberJstToday()
    val tally = remember(state.history, today) { ShrineBoard.todayOneMinute(state.history, today) }
    val streak = remember(state.history) { ShrineBoard.lossStreakOneMinute(state.history) }
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), accent = Gmk.Cyan.copy(alpha = .75f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            YinYangOrb(26.dp, spinning = state.m1Busy)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("1分判定（弾幕モード）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("仮想通貨4つ・毎分・どの1時間も80%以上ENTRY（土日も）", color = Gmk.Muted, fontSize = 10.sp)
            }
            Text("1分AUTO", color = Gmk.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp))
            Switch(checked = state.m1Auto, onCheckedChange = onAuto)
        }
        Spacer(Modifier.height(8.dp))
        if (top == null || scan == null) {
            Text(if (state.m1Auto) "次の分の10秒前に判定します" else "1分AUTOはOFF。手動1分スキャンで次の分を判定できます", color = Gmk.Muted, fontSize = 12.sp)
        } else {
            val left = entryMs?.let { ((it - nowMs) / 1000L).toInt() }
            val entry = top.decision == "ENTRY"
            Column(
                Modifier.fillMaxWidth()
                    .border(1.dp, if (entry) Gmk.Gold else Gmk.Line, RoundedCornerShape(10.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xCC2A1240), Color(0xCC0E2A4F))), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(pairLabel(top.instrument), color = Gmk.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    DirectionBox(top.direction)
                    JudgeBadge(1)
                    Text(if (entry) "${top.assessment?.subGrade?.shown ?: top.grade} ENTRY" else "見送り", color = if (entry) (if (top.grade == "B") Gmk.Gold else Gmk.Win) else Gmk.Muted,
                        fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Text(
                    when {
                        left == null -> ""
                        left > 0 -> "ENTRY ${formatJstTime(scan.entryTimeJst)} まで あと${left}秒（ザオプションで「1分」）"
                        left > -60 -> "判定中… ${formatJstTime(scan.judgeTimeJst)} に判定"
                        else -> "ENTRY ${formatJstTime(scan.entryTimeJst)} → 判定 ${formatJstTime(scan.judgeTimeJst)}"
                    },
                    color = if (left != null && left > 0) Gmk.Cyan else Gmk.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
                // v0.7.76: C1 / C2 / C3 with the percentages; B shows its probability and the validated B rate
                val sub = top.assessment?.subGrade
                if (sub != null) { Spacer(Modifier.height(4.dp)); SubGradeStrip(sub, compact = true) }
                else if (entry) PercentLine(top.probability, EvidenceModelM1Data.gradeRates(RankStatistics.isWeekend(scan.entryTimeJst) ?: false)[top.grade], top.grade)
                top.assessment?.correctionLabel?.let { Text(it, color = Gmk.Muted, fontSize = 10.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(Modifier.weight(1f)) {
                Text("この1時間", color = Gmk.Muted, fontSize = 10.sp)
                // v0.7.78: of the minutes the 1-minute AUTO decided this hour (the 80% counts those)
                val hourKey = now.toLocalDate().toString() + "T" + now.hour
                val seen = if (state.m1HourKey == hourKey) maxOf(state.m1HourSeen, entered) else maxOf(entered, now.minute + 1)
                Text("ENTRY $entered / ${seen}分", color = Gmk.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                // v0.7.79: the 80% is of the minutes the 1-minute AUTO ran this hour (48 only for a whole hour)
                Text(if (state.m1Auto) "（動いた分の80%以上・1時間通しなら48分）" else "（1分AUTO OFF・手動は必ずENTRY）", color = Gmk.Faint, fontSize = 9.sp)
            }
            Column(Modifier.weight(1f)) {
                Text("今日の1分", color = Gmk.Muted, fontSize = 10.sp)
                Text(ShrineBoard.tallyText(tally), color = Gmk.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("残機 ${ShrineBoard.lives(streak)}", color = if (streak >= 3) Gmk.Lose else Gmk.Pink, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onManual, enabled = !state.m1Auto && !state.m1Busy, modifier = Modifier.fillMaxWidth().heightIn(min = 46.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Gmk.ShrineRedDark), shape = RoundedCornerShape(10.dp)
        ) {
            Text(if (state.m1Auto) "1分AUTO中（手動はAUTO OFFで使えます）" else if (state.m1Busy) "詠唱中…" else "▶ 手動1分スキャン（次の分を判定）",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        state.m1Status?.let { Text(it, color = Gmk.Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp), maxLines = 2) }
        Text(OneMinutePolicy.NOTE, color = Gmk.Warn, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

/**
 * v0.7.75 スペルカード宣言: a new 5-minute ENTRY (TOP1) slides in at the top for six seconds - its spell card, pair, direction and the
 * theoption expiry. Only for a scan made in the last minute (not for one restored at start); tap to close.
 */
@Composable
internal fun SpellDeclaration(state: GmkUiState, onDeclared: () -> Unit = {}) {
    val scan = state.scan
    val top = scan?.top1
    // v0.7.78: kept over a screen rotation / activity restart (the banner and its sound came again within the minute)
    var shownId by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<String?>(null) }
    var visible by remember { mutableStateOf(false) }
    val fresh = scan != null && top?.decision == "ENTRY" &&
        (parseJstMs(scan.atJst)?.let { System.currentTimeMillis() - it in 0L..60_000L } ?: false)
    LaunchedEffect(scan?.scanId, fresh) {
        if (fresh && scan != null && scan.scanId != shownId) {
            shownId = scan.scanId; visible = true; onDeclared()
            delay(6_000); visible = false
        }
    }
    AnimatedVisibility(visible = visible && top != null, enter = slideInHorizontally { it } + fadeIn(), exit = slideOutHorizontally { -it } + fadeOut()) {
        if (top != null && scan != null) {
            val minutes = expiryMinutes(scan.entryTimeJst, scan.judgeTimeJst, 3)
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)
                    .border(2.dp, Gmk.Gold, RoundedCornerShape(12.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xF0B0203F), Color(0xF04A1A6B), Color(0xF01A3366))), RoundedCornerShape(12.dp))
                    .clickable { visible = false }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                YinYangOrb(34.dp, spinning = true)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("スペルカード宣言！", color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(ShrineBoard.spellCard(top), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    ShrineHud.character(top.instrument)?.let { Text("$it の出番！", color = Gmk.Pink, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    Text("${pairLabel(top.instrument)} ${if (top.direction == "HIGH") "▲HIGH" else "▼LOW"} • ${minutes}分判定 • ENTRY ${formatJstTime(scan.entryTimeJst)}",
                        color = Gmk.Paper, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

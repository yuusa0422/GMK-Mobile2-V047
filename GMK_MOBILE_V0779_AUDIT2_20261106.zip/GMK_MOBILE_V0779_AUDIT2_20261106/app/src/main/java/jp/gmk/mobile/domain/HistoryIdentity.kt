package jp.gmk.mobile.domain

import java.time.ZonedDateTime

/** Two entries can share a judge time when their horizons differ. */
object HistoryIdentity {
    fun alreadyRecorded(rows: List<HistoryRow>, result: ScanResult): Boolean = rows.any {
        (result.scanId.isNotBlank() && it.scanId==result.scanId) || sameAutoFrame(it,result)
    }
    fun sameAutoFrame(row: HistoryRow, result: ScanResult): Boolean {
        if(!result.source.startsWith("AUTO") || row.source!=result.source)return false
        if(row.entryTimeJst.isNotBlank() && result.entryTimeJst.isNotBlank()) {
            // v0.7.60: AUTO now stores rows every minute; two JST strings of different minutes are never the same instant, so most
            // of the up to 20,000 rows are rejected without parsing (any other string is still compared as an instant).
            if(row.entryTimeJst==result.entryTimeJst)return true
            if(differentJstMinute(row.entryTimeJst,result.entryTimeJst))return false
            return runCatching {
                ZonedDateTime.parse(row.entryTimeJst).toInstant()==ZonedDateTime.parse(result.entryTimeJst).toInstant()
            }.getOrDefault(row.entryTimeJst==result.entryTimeJst)
        }
        return result.scanId.isNotBlank() && row.scanId==result.scanId
    }
    private fun differentJstMinute(a: String, b: String): Boolean =
        a.length >= 16 && b.length >= 16 && a.endsWith("+09:00") && b.endsWith("+09:00") && a.regionMatches(0, b, 0, 16).not()
}

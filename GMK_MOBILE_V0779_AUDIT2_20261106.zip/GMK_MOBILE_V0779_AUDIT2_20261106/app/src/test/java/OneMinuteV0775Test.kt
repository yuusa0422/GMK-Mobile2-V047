import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/**
 * v0.7.75 1-minute judgment: the exported model gives the research's probabilities, real minutes through the app's inputs give the
 * research's choice, every hour keeps at least 80% ENTRY, and the rows are kept with the history's 1-minute results.
 * Fixtures: research_v0775/gen_m1_v0775.py.
 */
class OneMinuteV0775Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun lines(name: String) = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream(name)!!).bufferedReader().readLines().filter { it.isNotBlank() }

    @Test fun exportedModelGivesTheResearchProbabilities() {
        var n = 0
        for (l in lines("v0775_m1_parity.txt.gz")) {
            val (p, x) = l.split('|')
            val v = x.split(',').map { it.toDouble() }.toDoubleArray()
            assertEquals(CandleModelM1.FEATURE_COUNT, v.size)
            assertEquals(p.toDouble(), OneMinutePolicy.ensemble.probability(v), 1e-12); n++
        }
        assertEquals(240, n)
        assertEquals(CandleModelM1.FEATURE_COUNT, EvidenceModelM1Data.FEATURE_COUNT)
    }

    @Test fun realMinutesGiveTheResearchChoice() {
        class Slot(val b: Long, val inst: String, val dir: String, val p: Double) { val bars = HashMap<String, ArrayList<Candle>>() }
        val slots = ArrayList<Slot>(); var cur: Slot? = null
        for (l in lines("v0775_m1_slots.txt.gz")) {
            val q = l.split('|')
            when (q[0]) {
                "S" -> { cur = Slot(q[1].toLong(), q[2], q[3], q[4].toDouble()); slots.add(cur) }
                "C" -> cur!!.bars.getOrPut(q[1]) { ArrayList() }.add(Candle(q[2].toLong() * 1000L, q[3].toDouble(), q[4].toDouble(), q[5].toDouble(), q[6].toDouble(), q[7].toDouble()))
            }
        }
        assertEquals(30, slots.size)
        for (s in slots) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst)
            // the live price at entry = the close of the minute opening at entry-60 s (the forming minute of the app)
            val live = s.bars.mapValues { (_, c) -> c.first { it.timeEpochMs == s.b * 1000L - 60_000L }.close }
            val c = OneMinutePolicy.choose(OneMinutePolicy.scores(s.bars, live, entry))!!
            assertEquals("${s.b}", s.inst, c.instrument); assertEquals("${s.b}", s.dir, c.direction); assertEquals("${s.b}", s.p, c.probability, 1e-9)
            assertEquals(4, c.scores.size)
            // without the forming minute's candle the app still decides (open = previous close)
            val noForming = s.bars.mapValues { (_, cs) -> cs.filter { it.timeEpochMs != s.b * 1000L - 60_000L } }
            assertNotNull(OneMinutePolicy.choose(OneMinutePolicy.scores(noForming, live, entry)))
            // a finished minute missing: that product is left out
            val gap = s.bars.mapValues { (k, cs) -> if (k == "ETHUSD") cs.filter { it.timeEpochMs != s.b * 1000L - 600_000L } else cs }
            assertEquals(listOf("BTCJPY", "BTCUSD"), OneMinutePolicy.scores(gap, live, entry).map { it.instrument })
        }
    }

    @Test fun everyHourKeepsAtLeastEightyPercentEntry() {
        val hour = ZonedDateTime.parse("2026-11-06T10:00:00+09:00")
        for (p in listOf(0.0, 0.5, 0.52, 1.0)) {
            var entered = 0; var b = 0
            for (m in 0 until 60) {
                val (g, d) = OneMinutePolicy.decide(hour.plusMinutes(m.toLong()), p, entered)
                if (d == "ENTRY") { entered++; if (g == "B") b++; assertTrue(g in setOf("B", "C")) } else assertEquals("D", g)
            }
            assertEquals("p=$p", 48, entered)
            if (p == 1.0) assertEquals(48, b)
            if (p == 0.0) assertEquals(0, b)
        }
        // a mixed hour: 80% exactly, the low ones skipped first
        val ps = (0 until 60).map { 0.50 + 0.04 * ((it * 37) % 60) / 60.0 }
        var e = 0; val skipped = ArrayList<Double>()
        for (m in 0 until 60) { val (_, d) = OneMinutePolicy.decide(hour.plusMinutes(m.toLong()), ps[m], e); if (d == "ENTRY") e++ else skipped.add(ps[m]) }
        assertEquals(48, e); assertEquals(12, skipped.size)
        // the threshold is the hour's quantile: the top 5% line is above the top 80% line
        assertTrue(OneMinutePolicy.threshold(false, 10, 0.05) > OneMinutePolicy.threshold(false, 10, 0.8))
        assertTrue(OneMinutePolicy.threshold(true, 22, 0.05) > 0.5)
        assertEquals(48, OneMinutePolicy.NEEDED)
    }

    private fun row(id: Long, entry: String, source: String = "AUTO_1M", decision: String = "ENTRY", status: String = "WIN", policy: String = OneMinutePolicy.POLICY_TAG) =
        HistoryRow(id, "m$id", source, entry, "BTCJPY", "HIGH", "C", decision, entryTimeJst = entry,
            judgeTimeJst = ZonedDateTime.parse(entry).plusSeconds(60).toString(), entryRate = 1.0, judgeRate = 2.0, resultStatus = status, policyVersion = policy)

    @Test fun entriesOfTheHourAreRecountedFromTheHistory() {
        val rows = listOf(row(1, "2026-11-06T10:00:00+09:00"), row(2, "2026-11-06T10:59:00+09:00"), row(3, "2026-11-06T11:00:00+09:00"),
            row(4, "2026-11-06T10:05:00+09:00", source = "MANUAL_1M"), row(5, "2026-11-06T10:06:00+09:00", decision = "SKIP", status = "SKIP"),
            row(6, "2026-11-06T10:07:00+09:00", policy = "GMK_V0735_NATIVE_1M"), row(7, "2026-11-06T01:10:00Z"))   // 01:10 UTC = 10:10 JST
        assertEquals(3, OneMinutePolicy.enteredInHour(rows, ZonedDateTime.parse("2026-11-06T10:30:00+09:00")))
        assertEquals(1, OneMinutePolicy.enteredInHour(rows, ZonedDateTime.parse("2026-11-06T11:30:00+09:00")))
    }

    @Test fun rowsAreKeptWithTheOneMinuteResults() {
        val entry = ZonedDateTime.parse("2026-11-07T10:31:00+09:00")
        val sc = listOf(EvidencePolicy.PairScore("BTCJPY", 0.53, 0.47), EvidencePolicy.PairScore("ETHUSD", 0.49, 0.55), EvidencePolicy.PairScore("BTCUSD", 0.52, 0.48))
        val c = OneMinutePolicy.choose(sc)!!
        assertEquals("ETHUSD", c.instrument); assertEquals("LOW", c.direction)
        val r = OneMinutePolicy.result("AUTO_1M", entry, entry.minusSeconds(9), c, "B", "ENTRY", "x")
        assertEquals("2026-11-07T10:32+09:00", r.judgeTimeJst); assertEquals(OneMinutePolicy.POLICY_TAG, r.policyVersion)
        assertEquals(listOf("ETHUSD", "BTCJPY", "BTCUSD"), r.candidates.map { it.instrument }); assertEquals(1, r.top1!!.assessment!!.chosenAction.judgeMinutes)
        val h = row(1, "2026-11-07T10:31:00+09:00")
        assertTrue(RankStatistics.isOneMinute(h)); assertFalse(OneMinuteObservation.isObservation(h.policyVersion))
        assertTrue(ExpiryProfiles.includes(h, false, false))
        assertEquals(1, historyStatistics(listOf(h)).getValue(1).wins)
        val t = RankStatistics.tables(listOf(h, row(2, "2026-11-06T10:31:00+09:00", status = "LOSE")))
        assertEquals(listOf("1分判定 平日（v0.7.75・毎時80%）", "1分判定 土日（v0.7.75・毎時80%）"), t.map { it.title })
        assertTrue(RankStatistics.lineText(t[1], t[1].counts.single()).contains("検証"))
        // the 5-minute monitor and the shrine board never count the 1-minute rows; the 1-minute tally does
        assertNull(RankStatistics.monitor(listOf(h))); assertEquals(0, ShrineBoard.today(listOf(h), LocalDate.of(2026, 11, 7)).wins)
        assertEquals(1, ShrineBoard.todayOneMinute(listOf(h), LocalDate.of(2026, 11, 7)).wins)
        assertTrue(OneMinutePolicy.NOTE.contains("損益分岐52.6%を下回る"))
        // cut-ins: every 5-minute row, of the 1-minute rows only grade B
        assertFalse(OneMinutePolicy.showsCutIn(h)); assertTrue(OneMinutePolicy.showsCutIn(h.copy(grade = "B")))
        assertTrue(OneMinutePolicy.showsCutIn(h.copy(policyVersion = EvidencePolicy.POLICY_TAG, source = "AUTO")))
    }

    @Test fun stagesAndHiScore() {
        assertEquals("Stage 1「仲値の刻」", ShrineBoard.stage(ZonedDateTime.parse("2026-11-06T09:55:00+09:00")))
        assertEquals("Stage 6「米国指標の嵐」", ShrineBoard.stage(ZonedDateTime.parse("2026-11-06T22:59:00+09:00")))
        assertEquals("Extra Stage「仮想通貨の宴」", ShrineBoard.stage(ZonedDateTime.parse("2026-11-07T12:00:00+09:00")))
        assertTrue(ShrineBoard.stage(ZonedDateTime.parse("2026-11-06T23:00:00+09:00")).startsWith("休憩中"))
        val p = EvidencePolicy.POLICY_TAG
        fun r(i: Int, day: String, st: String) = row(i.toLong(), "2026-11-${day}T10:%02d:00+09:00".format(i), source = "AUTO", status = st, policy = p)
        val rows = listOf(r(1, "05", "WIN"), r(2, "05", "WIN"), r(3, "05", "LOSE"), r(4, "06", "WIN"), r(5, "06", "WIN"), r(6, "06", "WIN"), r(7, "06", "LOSE"))
        val hi = ShrineBoard.hiScore(rows)!!
        assertEquals(LocalDate.of(2026, 11, 6), hi.first); assertEquals(3 * 0.9 - 1, hi.second, 1e-9)
        assertNull(ShrineBoard.hiScore(emptyList()))
    }
}

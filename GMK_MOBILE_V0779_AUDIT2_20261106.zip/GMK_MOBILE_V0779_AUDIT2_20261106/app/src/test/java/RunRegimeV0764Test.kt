import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.util.zip.GZIPInputStream

/** v0.7.64: the runs indicator equals research_v0764/run_regime_app.py on real 15-minute candles. */
class RunRegimeV0764Test {
    @Test fun matchesTheResearchOnRealCandles() {
        val lines = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0764_run_regime_parity.txt.gz")!!).bufferedReader().readLines()
        val bars = HashMap<Long, HashMap<String, List<Candle>>>(); var checked = 0
        for (line in lines) {
            val f = line.split('|')
            if (f[0] == "B") {
                val q = f[1].toLong()
                val cs = if (f[3].isEmpty()) emptyList() else f[3].split(';').map { val (t, c) = it.split(':'); val v = c.toDouble(); Candle(t.toLong() * 1000L, v, v, v, v, 0.0) }
                bars.getOrPut(q) { HashMap() }[f[2]] = cs
            } else if (f[0] == "E") {
                val q = f[1].toLong(); val nowMs = q * 1000L
                val s = RunRegime.of(bars.getValue(q), nowMs)
                for (kv in f.drop(2)) {
                    val (k, v) = kv.split('='); val want = if (v == "None") null else v.toDouble()
                    val got = if (k == "YEN") s.yen else s.pairs[k]
                    if (want == null) assertNull(line.take(40), got) else assertEquals("$q $k", want, got!!, 1e-12)
                }
                checked++
            }
        }
        assertEquals(12, checked)
    }
    private fun series(n: Int, step: (Int) -> Double, t0: Long = 1_790_000_000_000L): List<Candle> {
        var p = 150.0; return (0 until n).map { i -> p *= kotlin.math.exp(step(i)); Candle(t0 + i * 900_000L, p, p, p, p, 0.0) }
    }
    @Test fun levelsAndGaps() {
        val now = 1_790_000_000_000L + 240 * 900_000L
        val alt = series(240, { i -> if (i % 2 == 0) 0.001 else -0.001 })            // every move comes back -> VR well below 1
        val calm = RunRegime.of(RunRegime.PAIRS.associateWith { alt }, now); assertEquals(RunRegime.Level.CALM, calm.level); assertTrue(calm.yen!! < 0.5)
        val trend = series(240, { i -> if ((i / 8) % 2 == 0) 0.001 else -0.001 })     // moves keep going for 2 hours -> VR > 1.1
        val hot = RunRegime.of(RunRegime.PAIRS.associateWith { trend }, now); assertEquals(RunRegime.Level.STRONG_RUNS, hot.level)
        // too few pairs or bars -> unknown; a candle that is not finished yet is not used
        assertEquals(RunRegime.Level.UNKNOWN, RunRegime.of(mapOf("USDJPY" to trend, "EURJPY" to trend), now).level)
        assertNull(RunRegime.pairVr(trend.take(90), now))
        assertEquals(RunRegime.pairVr(trend, now), RunRegime.pairVr(trend + Candle(now - 60_000L, 1.0, 1.0, 1.0, 1.0, 0.0), now))
        assertTrue(RunRegime.label(hot).startsWith("警戒")); assertTrue(RunRegime.label(null).contains("集計中"))
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZonedDateTime

/** v0.7.63: no Tokyo 9:55 fixing on Japanese bank holidays -> the FIX955 rules do not trade them. */
class HolidayV0763Test {
    @Test fun fixingRulesSkipJapaneseBankHolidays() {
        val holiday = ZonedDateTime.parse("2026-11-03T09:55:00+09:00")       // 文化の日 (Tuesday)
        val normal = ZonedDateTime.parse("2026-11-04T09:55:00+09:00")
        assertTrue(JapanHolidays.isBankHoliday(holiday)); assertFalse(JapanHolidays.isBankHoliday(normal))
        assertTrue(EventRules.rulesAt(holiday).none { it.id.startsWith("FIX955") })
        assertEquals(setOf("FIX955_POS", "FIX955_BBZ"), EventRules.rulesAt(normal).map { it.id }.filter { it.startsWith("FIX955") }.toSet())
        // the US rule still runs on a Japanese holiday (NY 8:30 = 22:30 JST in winter)
        assertTrue(EventRules.rulesAt(ZonedDateTime.parse("2026-11-23T22:30:00+09:00")).any { it.id == "US0830_F1" })
        // bank closing days at the year end; the research period (before Nov 2026) is untouched
        for (d in listOf("2026-12-31", "2027-01-01", "2027-01-11", "2027-03-22", "2027-09-20")) assertTrue(d, JapanHolidays.isBankHoliday(ZonedDateTime.parse("${d}T09:55:00+09:00")))
        assertFalse(JapanHolidays.isBankHoliday(ZonedDateTime.parse("2025-11-03T09:55:00+09:00")))
    }
    @Test fun nextRuleTextSkipsTheHoliday() {
        val text = SignalAlerts.nextRuleText(ZonedDateTime.parse("2026-11-03T08:45:00+09:00"))
        assertFalse(text, text.contains("あと70分"))                  // up to v0.7.62 it announced today's 9:55 fixing
        assertTrue(text, text.contains("仲値") || text.contains("NY8:30") || text.contains("米"))
    }
}

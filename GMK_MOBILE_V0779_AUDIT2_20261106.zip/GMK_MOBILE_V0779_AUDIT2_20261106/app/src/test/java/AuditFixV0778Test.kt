import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.78 full audit: one test per fixed defect of the domain code (the screen fixes are pinned by tools/audit_v0778.py). */
class AuditFixV0778Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun row(id: Int, at: String, status: String, grade: String = "C", policy: String = EvidencePolicy.POLICY_TAG, source: String = "AUTO",
                    decision: String = "ENTRY", minutes: Long = 5, inst: String = "USDJPY", sub: SubGrade? = null): HistoryRow {
        val trace = CandidateActionTrace(inst, "HIGH", "未記録", null, null, grade, decision, minutes.toInt())
        val a = CandidateAssessment("未記録", null, null, grade, decision, RuleSelectionStage.LEGACY_BASE, null, null, null, null, trace, trace, subGrade = sub)
        return HistoryRow(id.toLong(), "s$id", source, at, inst, "HIGH", grade, decision, entryTimeJst = at,
            judgeTimeJst = ZonedDateTime.parse(at).plusMinutes(minutes).toString(), entryRate = 150.0, judgeRate = 150.1, resultStatus = status,
            policyVersion = policy, assessment = a)
    }

    @Test fun oneMinuteLivePriceFromTheDecisionTime() {
        val e = ZonedDateTime.parse("2026-11-06T10:21:00+09:00").toInstant().toEpochMilli()
        assertTrue(OneMinutePolicy.liveFresh(e - 10_000L, e))          // the price at the decision (T-10) - rejected up to v0.7.77
        assertTrue(OneMinutePolicy.liveFresh(e - 18_000L, e))
        assertFalse(OneMinutePolicy.liveFresh(e - 18_001L, e))
        assertTrue(OneMinutePolicy.liveFresh(e + 1_000L, e)); assertFalse(OneMinutePolicy.liveFresh(e + 1_001L, e))
    }

    @Test fun oneMinuteHourCountsTheMinutesTheAppRuns() {
        val at30 = ZonedDateTime.parse("2026-11-06T10:30:00+09:00")
        assertEquals(48, OneMinutePolicy.neededInHour(at30, 0))                 // every earlier minute counted (as before)
        assertEquals(24, OneMinutePolicy.neededInHour(at30, 0, seenBefore = 0))  // started at :30: 80% of the 30 minutes it runs
        assertEquals(48, OneMinutePolicy.neededInHour(at30, 0, seenBefore = 30))
        assertEquals(28, OneMinutePolicy.neededInHour(at30, 4, seenBefore = 4))  // 80% of 34 = 27.2
        val weak = OneMinutePolicy.threshold(false, 10, 0.99)
        assertEquals("ENTRY", OneMinutePolicy.decide(at30, weak, 0).second)                     // old: 48 needed, 30 left -> forced
        assertEquals("SKIP", OneMinutePolicy.decide(at30, weak, 0, seenBefore = 0).second)      // v0.7.78: 24 needed in 30 -> picks
        val c = OneMinutePolicy.Choice("ETHUSD", "LOW", weak, listOf(EvidencePolicy.PairScore("ETHUSD", 0.4, weak)))
        assertTrue(OneMinutePolicy.reason(c, "D", "SKIP", 0, at30, 0).contains("この時間の基準に届かず見送り"))
        assertTrue(OneMinutePolicy.reason(c, "D", "SKIP", 48, at30).contains("80%を確保済みのため見送り"))
        assertTrue(OneMinutePolicy.reason(c, "D", "SKIP", 0, at30, 0).contains("ENTRY 0/1分"))
    }

    @Test fun enteredInHourReadsBothTimeFormats() {
        val entry = ZonedDateTime.parse("2026-11-06T10:40:00+09:00")
        val m1 = OneMinutePolicy.POLICY_TAG
        val rows = listOf(row(1, "2026-11-06T10:05:00+09:00", "WIN", policy = m1, source = "AUTO_1M", minutes = 1),
            row(2, ZonedDateTime.parse("2026-11-06T10:06:00+09:00").withZoneSameInstant(jst).toString(), "WIN", policy = m1, source = "AUTO_1M", minutes = 1),
            row(3, "2026-11-06T01:07:00Z", "WIN", policy = m1, source = "AUTO_1M", minutes = 1),                // 10:07 JST
            row(4, "2026-11-06T11:05:00+09:00", "WIN", policy = m1, source = "AUTO_1M", minutes = 1),           // another hour
            row(5, "2026-11-06T10:08:00+09:00", "WIN", policy = m1, source = "MANUAL_1M", minutes = 1),         // manual
            row(6, "2026-11-05T10:08:00+09:00", "WIN", policy = m1, source = "AUTO_1M", minutes = 1))           // another day
        assertEquals(3, OneMinutePolicy.enteredInHour(rows, entry))
    }

    @Test fun oneMinuteRowsNoLongerPushTheFiveMinuteHistoryOut() {
        val five = (0 until 50).map { row(it, "2026-11-06T10:00:00+09:00", "WIN") }
        val m1 = (0 until 80).map { row(1000 + it, "2026-11-06T10:00:00+09:00", "WIN", policy = OneMinutePolicy.POLICY_TAG, source = "AUTO_1M", minutes = 1) }
        val rows = (m1.take(40) + five.take(25) + m1.drop(40) + five.drop(25))     // newest first, mixed
        assertSame(rows, HistoryRetention.trim(rows, max = 1000, keep = 60, slack = 20))   // 80 <= 60 + 20: unchanged
        val t = HistoryRetention.trim(rows, max = 1000, keep = 50, slack = 20)
        assertEquals(50, t.count { RankStatistics.isOneMinute(it) }); assertEquals(50, t.count { !RankStatistics.isOneMinute(it) })
        assertEquals(m1.take(50).map { it.id }, t.filter { RankStatistics.isOneMinute(it) }.map { it.id })   // the newest 1-minute rows stay
        assertEquals(rows.filter { !RankStatistics.isOneMinute(it) }, t.filter { !RankStatistics.isOneMinute(it) })
        assertEquals(30, HistoryRetention.trim(rows, max = 30, keep = 50, slack = 20).size)
        assertEquals(20_000, HistoryRetention.MAX_ROWS); assertEquals(6_000, HistoryRetention.ONE_MINUTE_KEEP)
    }

    @Test fun streakStatisticsSortByTimeAcrossFormats() {
        // newest first as stored, three time formats: the losses at 10:10 / 10:15 are the newest
        val rows = listOf(row(1, "2026-11-06T10:15:00+09:00", "LOSE"), row(2, "2026-11-06T01:10:00Z", "LOSE"),
            row(3, ZonedDateTime.parse("2026-11-06T10:05:00+09:00").withZoneSameInstant(jst).toString(), "WIN"), row(4, "2026-11-06T10:00:00+09:00", "LOSE"))
        val s = historyCombinedStatistics(rows.shuffled(java.util.Random(7)))
        assertEquals(2, s.currentLossStreak); assertEquals(2, s.maxConsecutiveLosses)
        // a large history is sorted in well under a second (it parsed inside the comparator before)
        val many = (0 until 20_000).map { k -> row(k, ZonedDateTime.parse("2026-01-01T09:00:00+09:00").plusMinutes(k.toLong()).toOffsetDateTime().toString(),
            if (k % 3 == 0) "LOSE" else "WIN") }.asReversed()
        val t0 = System.nanoTime(); historyCombinedStatistics(many); assertTrue((System.nanoTime() - t0) / 1e9 < 3.0)
    }

    @Test fun subGradeFilterAndLinesAreFiveMinuteLiveOnly() {
        val c1 = SubGrade("C1", SubGrades.M1_WEEKDAY, 0.1, 0.52)
        val m1 = row(1, "2026-11-06T10:00:00+09:00", "WIN", policy = OneMinutePolicy.POLICY_TAG, source = "AUTO_1M", minutes = 1, sub = c1)
        val five = row(2, "2026-11-06T10:00:00+09:00", "WIN", sub = SubGrade("C1", SubGrades.WEEKDAY, 0.05, 0.56))
        assertFalse(RankFilter.matches(m1, "C1")); assertTrue(RankFilter.matches(five, "C1")); assertTrue(RankFilter.matches(m1, "1分"))
        val backup = row(3, "2026-11-06T10:05:00+09:00", "LOSE", sub = SubGrade("C1", SubGrades.WEEKDAY, 0.05, 0.53, fresh = false))
        val t = RankStatistics.tables(listOf(five, backup)).single()
        assertEquals(1, t.counts.single { it.grade == "C1" }.total)        // the backup model's C1 is not in the validated C1 line
        assertEquals(2, t.counts.single { it.grade == "C" && !it.skipped }.total)
    }

    @Test fun guardAppliesOnWeekdayTradingHoursOnly() {
        assertTrue(StreakGuard.applies(ZonedDateTime.parse("2026-11-06T10:00:00+09:00")))
        assertFalse(StreakGuard.applies(ZonedDateTime.parse("2026-11-07T10:00:00+09:00")))     // Saturday
        assertFalse(StreakGuard.applies(ZonedDateTime.parse("2026-11-06T23:10:00+09:00")))
        assertFalse(StreakGuard.applies(ZonedDateTime.parse("2026-11-06T08:59:00+09:00")))
    }

    @Test fun soundCuesFollowTheSettledResults() {
        val waiting = listOf(row(1, "2026-11-06T10:00:00+09:00", "WAIT_JUDGE"), row(2, "2026-11-06T10:00:00+09:00", "WAIT_JUDGE", decision = "SKIP"),
            row(3, "2026-11-06T10:01:00+09:00", "WAIT_JUDGE", grade = "C", policy = OneMinutePolicy.POLICY_TAG, source = "AUTO_1M", minutes = 1),
            row(4, "2026-11-06T10:02:00+09:00", "WAIT_JUDGE", grade = "B", policy = OneMinutePolicy.POLICY_TAG, source = "AUTO_1M", minutes = 1))
        val pending = SoundCues.pendingOf(waiting)
        assertEquals(setOf("s1", "s4"), pending)                 // a skip and a 1-minute C have no cut-in, so no sound
        assertNull(SoundCues.settled(pending, waiting))
        val after = waiting.map { if (it.scanId == "s1") it.copy(resultStatus = "LOSE") else it }
        assertEquals("s1", SoundCues.settled(pending, after)!!.scanId)
        assertNull(SoundCues.settled(emptySet(), after))
    }

    @Test fun reportLinesNeedAWinningPairAndALosingHour() {
        val today = java.time.LocalDate.parse("2026-11-06")
        val lose = (0 until 6).map { row(it, "2026-11-06T10:${String.format("%02d", it * 5)}:00+09:00", "LOSE", inst = if (it % 2 == 0) "USDJPY" else "EURJPY") }
        val r = Bunbunmaru.today(lose, today)
        assertFalse(r.lines.toString(), r.lines.any { it.startsWith("本日の当たりペア") })      // 0 wins is not a 当たり
        assertTrue(r.lines.toString(), r.lines.any { it.startsWith("苦戦した時間 10時台") })
        val win = (0 until 6).map { row(10 + it, "2026-11-06T11:${String.format("%02d", it * 5)}:00+09:00", "WIN") }
        val w = Bunbunmaru.today(win, today)
        assertTrue(w.lines.toString(), w.lines.any { it.startsWith("本日の当たりペア ") && it.endsWith("6勝0敗") }); assertFalse(w.lines.any { it.startsWith("苦戦した時間") })
    }

    @Test fun dayKeyFromTheTextOrTheParse() {
        assertEquals("2026-11-06", jstDayKey("2026-11-06T10:00:00+09:00"))
        assertEquals("2026-11-06", jstDayKey("2026-11-06T10:00+09:00"))
        assertEquals("2026-11-07", jstDayKey("2026-11-06T15:30:00Z"))                   // 00:30 JST the next day
        assertEquals("2026-11-06", jstDayKey("2026-11-06T10:00+09:00[Asia/Tokyo]"))
        assertNull(jstDayKey("broken"))
    }

    private class RealSlot(val kind: String, val b: Long) { val bars = LinkedHashMap<String, ArrayList<Candle>>(); val live = HashMap<String, Double>() }

    @Test fun promotedWeekendC1SaysItIsBelowTheBBar() {
        val out = ArrayList<RealSlot>(); var cur: RealSlot? = null
        for (l in GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0772_real_slots.txt.gz")!!).bufferedReader().readLines()) {
            val p = l.split('|')
            when (p[0]) {
                "S" -> { cur = RealSlot(p[1], p[2].toLong()); out.add(cur) }
                "C" -> cur!!.bars.getOrPut(p[1]) { ArrayList() }.add(Candle(p[2].toLong() * 1000L, p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble()))
                "L" -> cur!!.live[p[1]] = p[2].toDouble()
            }
        }
        var promoted = 0
        for (s in out.filter { it.kind == "we" }) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst)
            val cq = s.live.mapValues { EvidencePolicy.LiveQuote(it.value, s.b * 1000L - 10_000L) }
            val native = ScanResult("t-${s.b}", entry.minusSeconds(10).toString(), entry.toString(), entry.plusMinutes(3).toString(), source = "AUTO")
            val top = EvidencePolicy.apply(native, native, emptyMap(), emptyMap(), EntryMode.WEEKDAY_60, crypto = s.bars, cryptoQuotes = cq, promoteC1 = true).top1!!
            val label = top.assessment!!.correctionLabel!!
            if (top.assessment!!.subGrade?.promoted == true) { promoted++; assertTrue(label, label.contains("未満のC1から昇格")) }
            else if (top.grade == "B") assertTrue(label, label.contains("（上位8%の基準 ") && !label.contains("C1から昇格"))
        }
        assertTrue(promoted >= 1)
    }
}

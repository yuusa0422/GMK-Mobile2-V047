import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.util.zip.GZIPInputStream

/** v0.7.73: decision log (every pair's probabilities of a slot) and the live monitor (newest ENTRY trades vs the 1-year check). */
class MonitorV0773Test {
    private val jst = ZoneId.of("Asia/Tokyo")

    private class Slot(val kind: String, val b: Long) { val bars = LinkedHashMap<String, ArrayList<Candle>>(); val live = HashMap<String, Double>() }
    private fun slots(): List<Slot> {
        val out = ArrayList<Slot>(); var cur: Slot? = null
        for (l in GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0772_real_slots.txt.gz")!!).bufferedReader().readLines()) {
            val p = l.split('|')
            when (p[0]) {
                "S" -> { cur = Slot(p[1], p[2].toLong()); out.add(cur) }
                "C" -> cur!!.bars.getOrPut(p[1]) { ArrayList() }.add(Candle(p[2].toLong() * 1000L, p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble()))
                "L" -> cur!!.live[p[1]] = p[2].toDouble()
            }
        }
        return out
    }

    @Test fun slotScoresAreTheDecisionsNumbers() {
        // the logged probabilities are the decision's own: the best of them is exactly what choose9 / chooseWeekend decide
        var n = 0
        for (s in slots()) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst); val at = s.b * 1000L - 10_000L
            val fx = s.bars.filterKeys { it in TradingSession.FX }; val cr = s.bars.filterKeys { CryptoPairs.isCrypto(it) }
            val q = s.live.filterKeys { it in TradingSession.FX }.mapValues { EvidencePolicy.LiveQuote(it.value, at) }
            val cq = s.live.filterKeys { CryptoPairs.isCrypto(it) }.mapValues { EvidencePolicy.LiveQuote(it.value, at) }
            for (live in listOf(true, false)) {
                val (sc, ch) = if (s.kind == "wd") EvidencePolicy.scores9(fx, cr, if (live) q else emptyMap(), if (live) cq else emptyMap(), entry) to
                    EvidencePolicy.choose9(fx, cr, if (live) q else emptyMap(), if (live) cq else emptyMap(), entry)
                else EvidencePolicy.scoresWeekend(cr, if (live) cq else emptyMap(), entry) to EvidencePolicy.chooseWeekend(cr, if (live) cq else emptyMap(), entry)
                assertNotNull(sc); assertNotNull(ch)
                assertEquals(ch!!.fresh, sc!!.fresh)
                val best = sc.pairs.flatMap { listOf(Triple(it.instrument, "HIGH", it.high), Triple(it.instrument, "LOW", it.low)) }.maxByOrNull { it.third }!!
                assertEquals("${s.b}", ch.instrument, best.first); assertEquals("${s.b}", ch.direction, best.second); assertEquals(ch.probability, best.third, 0.0)
                if (s.kind == "wd") assertEquals(s.bars.size, sc.pairs.size)
                n++
            }
        }
        assertEquals(240, n)
    }

    @Test fun decisionLogLinesAreCompleteJson() {
        val sc = EvidencePolicy.SlotScores(true, listOf(EvidencePolicy.PairScore("USDJPY", 0.512345678, 0.487654321), EvidencePolicy.PairScore("BTCJPY", 0.55, Double.NaN)))
        val l = DecisionLog.line(1793880000L, true, "WEEKDAY_60", sc, "BTCJPY", "HIGH", "C", "ENTRY", "FIVE=BTCJPY HIGH p5=0.5500 \"x\"\nnext")
        assertEquals("{\"b\":1793880000,\"k\":\"wd\",\"m\":\"WEEKDAY_60\",\"f\":1,\"top\":\"BTCJPY HIGH C ENTRY\"," +
            "\"note\":\"FIVE=BTCJPY HIGH p5=0.5500 \\\"x\\\" next\",\"p\":[[\"USDJPY\",0.51235,0.48765],[\"BTCJPY\",0.55000,null]]}", l)
        assertTrue(DecisionLog.complete(l)); assertFalse(DecisionLog.complete(l.dropLast(3))); assertFalse(DecisionLog.complete(""))
        val none = DecisionLog.line(1793880300L, false, "FIFTY_FIVE", null, "ETHUSD", "LOW", "D", "SKIP", "")
        assertTrue(none.endsWith("\"p\":[]}")); assertTrue(DecisionLog.complete(none)); assertTrue(none.contains("\"k\":\"we\",") && none.contains("\"f\":0,"))
        assertTrue(DecisionLog.TRIM_AT > DecisionLog.KEEP)
    }

    private fun row(i: Int, win: Boolean?, grade: String = "C", weekend: Boolean = false, decision: String = "ENTRY", policy: String = EvidencePolicy.POLICY_TAG): HistoryRow {
        val t = Instant.ofEpochSecond((if (weekend) 1794013200L else 1793840400L) + i * 300L).atZone(jst).toOffsetDateTime().toString()
        return HistoryRow(id = i.toLong(), source = "AUTO", atJst = t, instrument = "USDJPY", direction = "HIGH", grade = grade, decision = decision,
            entryTimeJst = t, resultStatus = when (win) { true -> "WIN"; false -> "LOSE"; null -> "WAIT_JUDGE" }, policyVersion = policy)
    }

    @Test fun cutInReadsCryptoAgainstTheEntrySourcesPrice() {
        // a BTC/JPY ENTRY priced from Coinbase (15,000,000) must be compared with the Coinbase-based live price, not with bitbank's
        val at = java.time.ZonedDateTime.parse("2026-11-06T10:04:40+09:00"); val now = at.toInstant().toEpochMilli()
        fun r(id: String, inst: String, src: String) = HistoryRow(id.hashCode().toLong(), id, "AUTO", at.minusMinutes(5).toString(), inst, "HIGH", "C", "ENTRY",
            entryTimeJst = at.minusMinutes(4).minusSeconds(40).toString(), judgeTimeJst = at.plusSeconds(20).toString(), entryRate = 15_000_000.0,
            entryRateSource = src, resultStatus = "WAIT_JUDGE")
        fun q(inst: String, price: Double, src: String) = RateRow(inst, price, null, null, src, 1.0, "LIVE", sourceEpochMs = now - 1_000, receivedEpochMs = now)
        val bitbank = q("BTCJPY", 14_990_000.0, "bitbank")            // bitbank is about 0.1% under Coinbase: would say "losing"
        val coinbase = q("BTCJPY", 15_010_000.0, "Coinbase×USD/JPY")  // the entry's own source: winning
        val qa = CutInEventQueue()
        CutInPolicy.observeEvents(qa, listOf(r("a", "BTCJPY", "Coinbase 1m open")), listOf(coinbase, bitbank), now, true)
        assertEquals(CutInEventQueue.Kind.WIN_ADVANTAGE, qa.advance(now, 0).started.kind)
        // a Binance-priced entry is not read against a Coinbase live price (about 0.09% apart): no advantage shown
        val qb = CutInEventQueue()
        val sup = CutInPolicy.observeEvents(qb, listOf(r("b", "BTCJPY", "Binance 1m open")), listOf(coinbase, bitbank), now, true)
        assertEquals("NO_FRESH_LIVE_RATE", sup.single().reason); assertNull(qb.advance(now, 0).current)
        // ETH/USD exists only in the crypto rates
        val qc = CutInEventQueue()
        CutInPolicy.observeEvents(qc, listOf(r("c", "ETHUSD", "Coinbase 1m open").copy(entryRate = 3000.0)), listOf(q("ETHUSD", 2999.0, "Coinbase")), now, true)
        assertEquals(CutInEventQueue.Kind.LOSE_ADVANTAGE, qc.advance(now, 0).started.kind)
    }

    @Test fun monitorComparesTheNewestEntriesWithTheCheck() {
        assertNull(RankStatistics.monitor(emptyList()))
        assertTrue(RankStatistics.monitorText(null).contains("まだ"))
        // 300 weekday C: 160 wins (53.3%) vs 53.09% expected -> in range; then 4 losses in a row at the end
        val ok = (0 until 300).map { row(it, it % 15 >= 7) } + (300 until 304).map { row(it, false) }
        val m = RankStatistics.monitor(ok)!!
        assertEquals(300, m.n); assertEquals(0.5309, m.expected, 1e-12); assertEquals(4, m.lossStreak)
        assertTrue(RankStatistics.monitorText(m).contains("範囲内")); assertTrue(RankStatistics.monitorText(m).contains("今の連敗 4"))
        // 130 / 300 wins: clearly below
        val bad = (0 until 300).map { row(it, it % 30 < 13) }
        val mb = RankStatistics.monitor(bad)!!
        assertTrue(mb.z < -3.0); assertTrue(RankStatistics.monitorText(mb).contains("要注意"))
        // only settled AUTO ENTRY rank-1 rows of the current policy; weekend B expected from the weekend model's rate
        val mixed = (0 until 50).map { row(it, true, "B", weekend = true) } + (50 until 60).map { row(it, null) } + (60 until 70).map { row(it, false, decision = "SKIP") } +
            (70 until 80).map { row(it, false, policy = "GMK_V0735_NATIVE_1M") }
        val mm = RankStatistics.monitor(mixed)!!
        assertEquals(50, mm.n); assertEquals(0.6121, mm.expected, 1e-12); assertEquals(0, mm.lossStreak); assertTrue(RankStatistics.monitorText(mm).contains("参考"))
        // the longest losing streak inside the window
        val st = (0 until 120).map { row(it, !(it in 10..16 || it in 50..52)) }
        assertEquals(7, RankStatistics.monitor(st)!!.longestLossStreak)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.66: AUTO every 5 minutes on weekdays too (S/A 3-minute, B/C 5-minute judging); the hour rule counts the slots left. */
class CleanupV0766Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun t(d: Int, h: Int, m: Int, s: Int) = ZonedDateTime.of(2026, 11, d, h, m, s, 0, jst)

    @Test fun weekdayAutoRunsEveryFiveMinutes() {
        val now = t(4, 17, 51, 20)                                    // Wednesday 17:51:20 -> next scan 17:54:50 (entry 17:55)
        assertEquals(210, AutoClock.nextAutoScanSeconds(now))
        assertEquals("平日: 5分ごとにスキャン（S/Aは3分判定・B/Cは5分判定）", AutoClock.scheduleText(now))
        assertEquals(0, AutoClock.nextAutoScanSeconds(t(4, 17, 54, 50).plusNanos(400_000_000)))
        for (m in 0 until 60) {                                       // only the minutes before :00, :05, ... are scan minutes
            val at = t(4, 14, m, 50)
            assertEquals("$m", m % 5 == 4, AutoClock.nextAutoScanSeconds(at) == 0)
        }
        // last slot of the day 22:55 -> after it the next one is 09:00 the next weekday (T-10 = 08:59:50)
        assertEquals(10 * 3600 + 4 * 60 + 50, AutoClock.nextAutoScanSeconds(t(4, 22, 55, 0)))
        val sat = t(7, 10, 1, 0)
        assertEquals(3 * 60 + 50, AutoClock.nextAutoScanSeconds(sat))
        assertEquals("土日: 5分ごとにスキャン・3分判定", AutoClock.scheduleText(sat))
        assertEquals("土日: 5分ごとにスキャン・3分判定", AutoClock.scheduleText(t(6, 22, 58, 0)))   // Friday night -> next scan Saturday 09:00
    }

    @Test fun hourRuleCountsFiveMinuteSlots() {
        for (f in listOf(true, false)) for (h in 9..22) {
            // 9 needed at :15 -> 9 slots left (:15 .. :55) -> catch-up; one slot fewer at :20 -> catch-up too
            assertTrue(RankLadder.minuteCut(f, h, 15, 0).catchUp); assertEquals(9, RankLadder.minuteCut(f, h, 15, 0).left)
            assertFalse(RankLadder.minuteCut(f, h, 10, 0).catchUp); assertEquals(10, RankLadder.minuteCut(f, h, 10, 0).left)
            assertEquals(12, RankLadder.minuteCut(f, h, 0, 0).left); assertEquals(1, RankLadder.minuteCut(f, h, 55, 8).left)
            assertTrue(RankLadder.minuteCut(f, h, 55, 8).catchUp); assertTrue(RankLadder.minuteCut(f, h, 30, 9).full)
            // a manual scan between slots counts the slot it is in: :07 -> 11 slots (:05 .. :55)
            assertEquals(11, RankLadder.minuteCut(f, h, 7, 0).left)
            val q = if (f) EvidenceSlot9Data.FRESH_QUANTILES[h - 9] else EvidenceSlot9Data.FALLBACK_QUANTILES[h - 9]   // v0.7.71: nine-pair tables
            assertEquals(q.last(), RankLadder.quantileCut(f, h, 0.0), 0.0); assertEquals(q.first(), RankLadder.quantileCut(f, h, 1.0), 0.0)
            assertTrue(RankLadder.baseShare(f, h) in 0.4..0.8)            // 70% of the slots minus the fixed trades
        }
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/**
 * v0.7.75: the 5-minute AUTO really scans every 5 minutes. v0.7.67-v0.7.69 scanned every weekday minute (09:39:50 and 09:40:50 both
 * scanned and entered) while the countdown, the only thing the tests checked, still showed 5 minutes: the scheduler had its own copy of
 * the rule. Now both use AutoClock.isScanMinute, and this test reads the view model's source to make sure it still does.
 */
class ScheduleLockV0775Test {
    @Test fun scansOnlyAtTMinus10OfTheFiveMinuteBoundaries() {
        assertTrue(AutoClock.isScanMinute(ZonedDateTime.parse("2026-11-06T09:39:50+09:00")))      // the 09:40 entry
        assertFalse(AutoClock.isScanMinute(ZonedDateTime.parse("2026-11-06T09:40:50+09:00")))     // no 09:41 entry
        // every minute of a weekday and a weekend day: only :X4 and :X9 scan, and the countdown agrees with the scheduler
        for (day in listOf("2026-11-06", "2026-11-07")) {
            var t = ZonedDateTime.parse("${day}T09:00:00+09:00"); var scans = 0
            while (t.hour < 23) {
                val scan = AutoClock.isScanMinute(t)
                assertEquals("$t", t.minute % 5 == 4, scan)
                if (scan) scans++
                val at50 = t.withSecond(50)
                assertEquals("$at50", scan && TradingSession.isActive(at50.plusSeconds(10)), AutoClock.nextAutoScanSeconds(at50) == 0)
                t = t.plusMinutes(1)
            }
            assertEquals(14 * 12, scans)
        }
        // UTC input is read in JST
        assertTrue(AutoClock.isScanMinute(ZonedDateTime.parse("2026-11-06T00:39:50Z")))
    }

    @Test fun theViewModelUsesTheSameRule() {
        val root = File(System.getProperty("gmk.projectRoot") ?: ".")
        val vm = listOf(File(root, "app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt"), File("src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt"))
            .firstOrNull { it.isFile } ?: return            // the source is not available in this environment
        val text = vm.readText()
        assertTrue(text.contains("private fun isAutoMinute(t: ZonedDateTime): Boolean = AutoClock.isScanMinute(t)"))
        assertFalse("the scheduler must not keep its own copy of the rule", Regex("""isWeekday\(entry\) \|\|""").containsMatchIn(text))
        assertEquals(1, Regex("""fun isAutoMinute""").findAll(text).count())
    }
}

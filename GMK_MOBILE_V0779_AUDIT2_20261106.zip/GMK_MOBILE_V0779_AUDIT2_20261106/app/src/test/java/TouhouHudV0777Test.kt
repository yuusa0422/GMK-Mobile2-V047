import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZonedDateTime

/** v0.7.77 shooting-game HUD, ラストスペル, the pairs' characters and the おみくじ (display only). */
class TouhouHudV0777Test {
    private fun row(id: Int, at: String, status: String, grade: String = "C", judge: Double = 150.1) =
        HistoryRow(id.toLong(), "s$id", "AUTO", at, "USDJPY", "HIGH", grade, "ENTRY", entryTimeJst = at,
            judgeTimeJst = ZonedDateTime.parse(at).plusMinutes(5).toString(), entryRate = 150.0, judgeRate = judge, resultStatus = status,
            policyVersion = EvidencePolicy.POLICY_TAG)

    @Test fun hudOfToday() {
        val today = LocalDate.parse("2026-11-06")
        val rows = listOf(row(1, "2026-11-06T10:00:00+09:00", "WIN", "B"), row(2, "2026-11-06T10:05:00+09:00", "WIN"),
            row(3, "2026-11-06T10:10:00+09:00", "LOSE", judge = 150.0), row(4, "2026-11-06T10:15:00+09:00", "WIN", "S"),
            row(5, "2026-11-05T10:00:00+09:00", "WIN"), row(6, "2026-11-05T10:05:00+09:00", "WIN"), row(7, "2026-11-05T10:10:00+09:00", "WIN"),
            row(8, "2026-11-05T10:15:00+09:00", "WIN"))
        val h = ShrineHud.of(rows, today)
        assertEquals(10_000L + 11_000L + 10_000L, h.score)                      // win, win (streak 2), loss, win
        assertEquals(10_000L + 11_000L + 12_000L + 13_000L, h.hiScore)          // yesterday's four wins in a row
        assertEquals(2, h.bombs); assertEquals(1, h.graze); assertEquals(3, h.points); assertEquals(1, h.winStreak)
        assertEquals(4.0, h.power, 0.0)                                         // 75% is past the MAX (60%)
        assertEquals(ShrineBoard.LIVES, h.lives)
        val empty = ShrineHud.of(emptyList(), today)
        assertEquals(0L, empty.score); assertEquals(0.0, empty.power, 0.0); assertEquals(ShrineBoard.LIVES, empty.lives)
    }

    @Test fun lastSpellAndCharacters() {
        assertEquals("", ShrineHud.lastSpell(2)); assertTrue(ShrineHud.lastSpell(3).contains("3連勝中"))
        assertEquals("ラストスペル発動中！ 5連勝", ShrineHud.lastSpell(5)); assertEquals("「夢想天生」状態！ 10連勝", ShrineHud.lastSpell(10))
        for (p in TradingSession.FX.filter { it != "BTCJPY" } + CryptoPairs.ALL) assertNotNull(p, ShrineHud.character(p))
        assertEquals("霧雨魔理沙", ShrineHud.character("BTCJPY")); assertNull(ShrineHud.character("EURUSD"))
    }

    @Test fun omikujiIsOnePerDay() {
        val d = LocalDate.parse("2026-11-06")
        assertEquals(ShrineHud.omikuji(d), ShrineHud.omikuji(LocalDate.parse("2026-11-06")))
        val week = (0L until 60L).map { ShrineHud.omikuji(d.plusDays(it)).first }.toSet()
        assertEquals(ShrineHud.OMIKUJI.map { it.first }.toSet(), week)               // every fortune comes up
    }
}

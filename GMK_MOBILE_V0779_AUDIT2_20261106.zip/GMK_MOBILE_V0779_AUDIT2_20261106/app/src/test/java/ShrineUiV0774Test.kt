import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZonedDateTime

/** v0.7.74: the shrine board (spell card, 残機, 賽銭箱), the chart window and the crypto chart candles (display only). */
class ShrineUiV0774Test {
    private val policy = EvidencePolicy.POLICY_TAG + "_V0774"
    private fun row(i: Int, status: String, entry: String = "2026-11-06T10:%02d:00+09:00".format(i), decision: String = "ENTRY",
                    policyVersion: String = policy, entryRate: Double? = 150.0, judgeRate: Double? = 150.1) =
        HistoryRow(i.toLong(), "s$i", "AUTO", entry, "USDJPY", "HIGH", "C", decision, entryTimeJst = entry,
            judgeTimeJst = ZonedDateTime.parse(entry).plusMinutes(5).toString(), entryRate = entryRate, judgeRate = judgeRate,
            resultStatus = status, policyVersion = policyVersion)

    @Test fun spellCardsFollowTheGradeAndTheDecision() {
        assertEquals("「夢想天生」", ShrineBoard.spellCard("S", "ENTRY"))
        assertEquals("霊符「夢想封印」", ShrineBoard.spellCard("A", "ENTRY"))
        assertEquals("神技「八方鬼縛陣」", ShrineBoard.spellCard("B", "ENTRY"))
        assertEquals("夢符「封魔陣」", ShrineBoard.spellCard("C", "ENTRY"))
        // a skipped C (the ENTRY amount setting) is a skip, not a spell
        assertEquals("結界「見送りの陣」", ShrineBoard.spellCard("C", "SKIP"))
        assertEquals("結界「見送りの陣」", ShrineBoard.spellCard("E", "SKIP"))
        assertEquals("判定不能「霧の湖」", ShrineBoard.spellCard("I", "SKIP"))
    }

    @Test fun livesCountTheLossesInARowOfTheCurrentPolicyOnly() {
        assertEquals("★★★★★", ShrineBoard.lives(0)); assertEquals("★★★☆☆", ShrineBoard.lives(2)); assertEquals("☆☆☆☆☆", ShrineBoard.lives(7))
        assertEquals("無傷", ShrineBoard.livesNote(0)); assertTrue(ShrineBoard.livesNote(3).startsWith("被弾注意"))
        // win, loss, skip (does not reset), pending, loss, old-engine loss (not counted) -> 2
        val rows = listOf(row(0, "WIN"), row(5, "LOSE"), row(10, "WIN", decision = "SKIP"), row(15, "WAIT_JUDGE"), row(20, "LOSE"),
            row(25, "LOSE", policyVersion = "GMK_V0736_DIRECT19"))
        assertEquals(2, ShrineBoard.lossStreak(rows))
        assertEquals(0, ShrineBoard.lossStreak(rows + row(30, "WIN")))
    }

    @Test fun offeringBoxIsTodaysEntryResultsAtThePayout() {
        val today = LocalDate.of(2026, 11, 6)
        val rows = listOf(row(0, "WIN"), row(5, "WIN"), row(10, "LOSE"), row(15, "LOSE", entryRate = 150.0, judgeRate = 150.0),
            row(20, "WAIT_JUDGE"), row(25, "WIN", decision = "SKIP"), row(30, "WIN", entry = "2026-11-05T23:59:00+09:00"),
            // 2026-11-05 15:30 UTC is 2026-11-06 00:30 JST: today
            row(35, "WIN", entry = "2026-11-05T15:30:00Z"))
        val t = ShrineBoard.today(rows, today)
        assertEquals(3, t.wins); assertEquals(2, t.losses); assertEquals(1, t.draws); assertEquals(1, t.pending)
        assertEquals(0.6, t.rate!!, 1e-12)
        assertEquals(3 * 0.9 - 2, t.units, 1e-12)
        assertTrue(ShrineBoard.tallyText(t).startsWith("3勝 2敗  60.0%  +0.7口"))
        assertEquals("まだ奉納なし", ShrineBoard.tallyText(ShrineBoard.today(emptyList(), today)))
        // break-even of the 1.9x payout is 1/1.9 = 52.63%: 11 wins 9 losses (55%) gains, 10 / 10 loses
        assertTrue(ShrineBoard.Tally(11, 9, 0, 0).units > 0); assertTrue(ShrineBoard.Tally(10, 10, 0, 0).units < 0)
    }

    @Test fun chartShowsTheNewestBarsOrTheFocusedOne() {
        val times = (0 until 300).map { 1_000_000L + it * 60_000L }
        assertEquals(240 until 300, ChartWindow.range(times, 60))
        assertEquals(0 until 300, ChartWindow.range(times, 0))
        assertEquals(0 until 50, ChartWindow.range(times.take(50), 60))
        assertTrue(ChartWindow.range(emptyList(), 60).isEmpty())
        // a history ENTRY at bar 100: shown at two thirds of a 60-bar window
        val w = ChartWindow.range(times, 60, times[100] + 10_000L)
        assertEquals(60, w.count()); assertTrue(100 in w); assertEquals(120, w.last)
        // focus near the start or the end stays inside the data
        assertEquals(0 until 60, ChartWindow.range(times, 60, times[3]))
        assertEquals(240 until 300, ChartWindow.range(times, 60, times[299]))
        // before the first bar or far after the last: the newest bars
        assertEquals(240 until 300, ChartWindow.range(times, 60, 5L))
    }

    @Test fun priceScaleFitsTheVisibleBars() {
        val (lo, hi) = ChartWindow.priceRange(listOf(150.0, 151.0, Double.NaN, -1.0, 0.0))!!
        assertEquals(150.0 - 0.07, lo, 1e-9); assertEquals(151.0 + 0.07, hi, 1e-9)
        assertNull(ChartWindow.priceRange(listOf(Double.NaN)))
        val flat = ChartWindow.priceRange(listOf(100.0, 100.0))!!
        assertTrue(flat.second > flat.first)
        assertEquals(listOf(151.0, 150.75, 150.5, 150.25, 150.0), ChartWindow.levels(150.0, 151.0))
    }

    @Test fun cryptoChartCandlesWindowAggregateAndYen() {
        val now = 1_794_000_000_000L
        assertEquals(60, CryptoChartMath.granularitySeconds("1m")); assertEquals(3600, CryptoChartMath.granularitySeconds("4h"))
        assertEquals(0, CryptoChartMath.granularitySeconds("2m"))
        val (s, e) = CryptoChartMath.window(60, null, now)
        assertEquals(now / 1000, e); assertEquals(299 * 60L, e - s)          // at most 300 candles per Coinbase request
        val (fs, fe) = CryptoChartMath.window(60, now - 10_800_000L, now)
        assertEquals((now - 10_800_000L) / 1000 - 220 * 60, fs); assertEquals((now - 10_800_000L) / 1000 + 70 * 60, fe)
        assertEquals(now / 1000, CryptoChartMath.window(60, now - 600_000L, now).second)   // never past now
        // 4h from 1h: the first bucket cut by the window start is dropped, the forming one too
        val h = 3_600_000L; val base = (now / (4 * h)) * (4 * h) - 12 * h
        val hourly = (-2 until 13).map { Candle(base + it * h, 100.0 + it, 101.0 + it, 99.0 + it, 100.5 + it, 1.0) }
        val four = CryptoChartMath.confirmed(CryptoChartMath.aggregate(hourly, h, 4 * h), 4 * h, now)
        assertEquals(listOf(base, base + 4 * h, base + 8 * h), four.map { it.timeEpochMs })
        assertEquals(100.0, four[0].open, 0.0); assertEquals(104.0, four[0].high, 0.0); assertEquals(99.0, four[0].low, 0.0); assertEquals(103.5, four[0].close, 0.0)
        assertSame(hourly, CryptoChartMath.aggregate(hourly, h, h))
        // X/JPY with USD/JPY candles, and with the latest rate only
        val usd = listOf(Candle(60_000L, 100.0, 102.0, 99.0, 101.0))
        val yen = CryptoChartMath.inYen(usd, listOf(Candle(60_000L, 150.0, 150.0, 150.0, 150.0)), null)
        assertEquals(15_000.0, yen.single().open, 1e-9); assertEquals(15_150.0, yen.single().close, 1e-9)
        val live = CryptoChartMath.inYen(usd, emptyList(), 152.0)
        assertEquals(15_200.0, live.single().open, 1e-9); assertEquals(60_000L, live.single().timeEpochMs)
        assertTrue(CryptoChartMath.inYen(usd, emptyList(), null).isEmpty())
    }
}

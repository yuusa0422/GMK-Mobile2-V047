import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.nio.file.Files

/** v0.7.69: only the newest rows are rewritten on each save; older rows sit in an archive written now and then. */
class HistoryArchiveV0769Test {
    private fun row(i: Int, status: String = "WIN") = HistoryRow(1_790_000_000_000L + i, "scan$i", "AUTO", "2026-11-04T10:%02d:50+09:00".format(i % 60),
        "USDJPY", "HIGH", "C", "ENTRY", resultStatus = status, policyVersion = EvidencePolicy.POLICY_TAG)
    private fun history(n: Int) = (n downTo 1).map { row(it) }               // newest first

    @Test fun smallHistoryStaysRecentAndOverflowMovesOlderRowsOnce() {
        val small = history(800)
        assertEquals(HistoryArchivePlan.Plan(small, emptyList(), false), HistoryArchivePlan.plan(small, emptyList()))
        val big = history(801)
        val p = HistoryArchivePlan.plan(big, emptyList())
        assertTrue(p.writeArchive); assertEquals(HistoryArchivePlan.RECENT_KEEP, p.recent.size); assertEquals(501, p.archive.size)
        assertEquals(big, p.recent + p.archive)
        // new rows on top and outcome changes of recent rows leave the archive alone until the recent part passes RECENT_MAX
        var snap = big; var archive = p.archive; val rewrites = mutableListOf<Int>()
        for (k in 802..1400) {
            snap = (listOf(row(k)) + snap).toMutableList().also { it[3] = it[3].copy(resultStatus = "LOSE") }
            val q = HistoryArchivePlan.plan(snap, archive)
            if (q.writeArchive) { assertEquals(HistoryArchivePlan.RECENT_MAX + 1, snap.size - archive.size); archive = q.archive; rewrites += k }
            else { assertSame(archive, q.archive); assertEquals(snap.size - archive.size, q.recent.size) }
            assertEquals(snap, HistoryArchivePlan.merge(q.recent, q.archive, 20_000))
        }
        assertEquals(listOf(1302), rewrites)                                     // once per 501 new rows (300 -> 801 recent rows)
        assertEquals(1400 - 1302 + HistoryArchivePlan.RECENT_KEEP, 1400 - archive.size)
    }

    @Test fun changedArchivedRowOrTrimmedTailIsHandled() {
        val snap = history(1000); val p = HistoryArchivePlan.plan(snap, emptyList())
        val changed = snap.toMutableList().also { it[600] = it[600].copy(resultStatus = "LOSE") }
        val q = HistoryArchivePlan.plan(changed, p.archive)
        assertTrue("a change inside the archive rewrites it", q.writeArchive); assertEquals(changed, q.recent + q.archive)
        // the oldest rows trimmed at the 20,000 limit: the archive on disk still has them, the merge applies the limit
        val trimmed = (listOf(row(1001), row(1002)) + snap).take(1000)
        val t = HistoryArchivePlan.plan(trimmed, p.archive)
        assertFalse(t.writeArchive); assertEquals(302, t.recent.size)
        assertEquals(trimmed, HistoryArchivePlan.merge(t.recent, t.archive, 1000))
        assertTrue(HistoryArchivePlan.plan(snap, p.archive, forceArchive = true).writeArchive)
        assertEquals(-1, HistoryArchivePlan.archiveStart(snap.filter { it != p.archive[0] }, p.archive))   // the archive's newest row is gone
    }

    @Test fun rowInBothPartsIsTakenOnceInItsArchiveVersion() {
        val recent = listOf(row(5), row(4, "WAIT_JUDGE"), row(3))          // a stop after the archive write: 4 and 3 moved already
        val archive = listOf(row(4, "WIN"), row(3), row(2), row(1))
        val m = HistoryArchivePlan.merge(recent, archive, 20_000)
        assertEquals(listOf("scan5", "scan4", "scan3", "scan2", "scan1"), m.map { it.scanId }); assertEquals("WIN", m[1].resultStatus)
        assertEquals(3, HistoryArchivePlan.merge(recent, archive, 3).size)
        val legacyTwins = listOf(row(9), row(9).copy(id = 7L))                   // same scan id, different rows: both kept
        assertEquals(2, HistoryArchivePlan.merge(legacyTwins.take(1), legacyTwins.drop(1), 10).size)
    }

    @Test fun atomicFileKeepsOneEarlierVersionAndSurvivesAStopBeforeTheRename() {
        val dir = Files.createTempDirectory("gmk_archive").toFile()
        try {
            val f = AtomicLinesFile(File(dir, "a.jsonl"))
            fun cur() = f.read { it.toList() }
            assertNull(cur()); assertFalse(f.exists())
            f.write(sequenceOf("1")); f.write(sequenceOf("1", "2"))
            assertEquals(listOf("1", "2"), cur()); assertEquals(listOf("1"), f.readPrevious { it.toList() })
            assertEquals("1\n2\n", File(dir, "a.jsonl").readText())
            // stop after the current file became .prev but before the new one was renamed
            File(dir, "a.jsonl").renameTo(File(dir, "a.jsonl.prev")); File(dir, "a.jsonl.tmp").writeText("1\n2\n3\n")
            assertTrue(f.exists()); assertEquals(listOf("1", "2", "3"), cur()); assertFalse(File(dir, "a.jsonl.tmp").exists())
            // a stop while the temporary file was being written leaves the current file as it was
            File(dir, "a.jsonl.tmp").writeText("1\n2\n3\n4"); assertEquals(listOf("1", "2", "3"), cur())
            f.write((1..5000).asSequence().map { "row$it" }); assertEquals(5000, f.read { it.count() }); assertEquals(listOf("1", "2", "3"), f.readPrevious { it.toList() })
            // an unreadable file is moved aside, so the next write keeps the good earlier version as .prev
            assertTrue(f.quarantine()); assertFalse(File(dir, "a.jsonl").exists()); assertTrue(f.corrupt.isFile)
            f.write(sequenceOf("new")); assertEquals(listOf("new"), cur()); assertEquals(listOf("1", "2", "3"), f.readPrevious { it.toList() })
        } finally { dir.deleteRecursively() }
    }
}

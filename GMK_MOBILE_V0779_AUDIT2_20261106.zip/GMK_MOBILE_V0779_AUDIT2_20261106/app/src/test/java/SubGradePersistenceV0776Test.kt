import jp.gmk.mobile.data.AssessmentJsonCodec
import jp.gmk.mobile.domain.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** v0.7.76: the sub-grade of a history row survives the save; a broken sub-grade block drops only the sub-grade, never the row's assessment. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26])
class SubGradePersistenceV0776Test {
    private fun assessment(sub: SubGrade?): CandidateAssessment {
        val trace = CandidateActionTrace("EURJPY", "LOW", "未記録", null, null, "B", "ENTRY", 5)
        return CandidateAssessment("未記録", null, null, "B", "ENTRY", RuleSelectionStage.LEGACY_BASE, null, null, null, null,
            trace, trace, trace, "【5分判定】5分モデル B↑C1", subGrade = sub)
    }

    @Test fun subGradeRoundTrips() {
        val sub = SubGrade("C1", SubGrades.WEEKDAY, 0.0712, 0.5531, fresh = true, promoted = true)
        val json = AssessmentJsonCodec.encode(assessment(sub))!!
        assertEquals("DISPLAY_ONLY", json.getJSONObject("sub_grade").getString("usage"))
        val back = AssessmentJsonCodec.decode(JSONObject(json.toString()))!!
        assertEquals(sub, back.subGrade); assertEquals(0.5678, back.subGrade!!.rate!!, 0.0)
        // an old row (no sub_grade) and a row without one decode as before
        val old = JSONObject(json.toString()).apply { remove("sub_grade") }
        assertNull(AssessmentJsonCodec.decode(old)!!.subGrade)
        assertNull(AssessmentJsonCodec.decode(AssessmentJsonCodec.encode(assessment(null)))!!.subGrade)
    }

    @Test fun brokenSubGradeDropsOnlyTheSubGrade() {
        val base = AssessmentJsonCodec.encode(assessment(SubGrade("C2", SubGrades.WEEKEND, 0.2, 0.56)))!!.toString()
        for (bad in listOf(
            JSONObject(base).apply { getJSONObject("sub_grade").put("label", "C9") },
            JSONObject(base).apply { getJSONObject("sub_grade").put("segment", "xx") },
            JSONObject(base).apply { getJSONObject("sub_grade").put("top", 1.5) },
            JSONObject(base).apply { getJSONObject("sub_grade").put("probability", "0.5") },
            JSONObject(base).apply { getJSONObject("sub_grade").put("usage", "TRADE") },
            JSONObject(base).apply { put("sub_grade", "C2") })) {
            val a = AssessmentJsonCodec.decode(bad)
            assertNotNull(bad.toString(), a); assertNull(bad.toString(), a!!.subGrade); assertEquals("B", a.operationalGrade)
        }
        // "promoted" is kept only for a C1
        val c2 = JSONObject(base).apply { getJSONObject("sub_grade").put("promoted", true) }
        assertFalse(AssessmentJsonCodec.decode(c2)!!.subGrade!!.promoted)
    }
}

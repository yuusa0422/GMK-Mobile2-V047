import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.util.zip.GZIPInputStream

/** v0.7.61 deep audit: the hour quota follows the hour's slots the app runs (as the research counts the slots with data). */
class DeepAuditV0761Test {
    private val tag = EvidencePolicy.POLICY_TAG
    private fun row(id: String, entry: String, decision: String = "ENTRY", grade: String = if (decision == "ENTRY") "C" else "D",
                    source: String = "AUTO", judgeMin: Long = 5, dir: String = "HIGH") =
        HistoryRow(id.hashCode().toLong(), id, source, entry, "USDJPY", dir, grade, decision, entryTimeJst = entry,
            judgeTimeJst = java.time.ZonedDateTime.parse(entry).plusMinutes(judgeMin).toString(), entryRate = 150.0, policyVersion = tag)

    @Test fun slotsCountStoredSlotRowsAndTheSlotsAhead() {
        // the whole hour ran: every slot row before 10:31 is stored (some ENTRY, some SKIP)
        val full = (0 until 31 step 5).map { m -> row("s$m", "2026-11-02T10:%02d:00+09:00".format(m), if (m % 10 == 0) "ENTRY" else "SKIP") } +
            listOf(row("m1", "2026-11-02T10:12:00+09:00"), row("m2", "2026-11-02T10:27:00+09:00"))
        assertEquals(12, LiveEntryState.of(full, "2026-11-02T10:31:00+09:00", tag).hourSlots)
        assertEquals(12, LiveEntryState.of(full, "2026-11-02T10:35:00+09:00", tag).hourSlots)
        assertEquals(6, LiveEntryState.of(full, "2026-11-02T10:31:00+09:00", tag).hourEntries)    // 10:00 10:10 10:20 10:30 + 10:12 10:27
        // started at 10:41: no slot rows yet, slots ahead 10:45 / 10:50 / 10:55
        assertEquals(LiveEntryState.State(0, 0, 0, 3), LiveEntryState.of(emptyList(), "2026-11-02T10:41:00+09:00", tag))
        assertEquals(4, LiveEntryState.of(emptyList(), "2026-11-02T10:40:00+09:00", tag).hourSlots)     // 10:40 itself is ahead
        assertEquals(0, LiveEntryState.of(emptyList(), "2026-11-02T10:57:00+09:00", tag).hourSlots)
        // a failed slot scan (no row) and an I row (no data) are not slots; MANUAL rows never are; another hour's rows neither
        val gaps = listOf(row("a", "2026-11-02T10:00:00+09:00", "SKIP"), row("i", "2026-11-02T10:05:00+09:00", "SKIP", grade = "I"),
            row("c", "2026-11-02T10:10:00+09:00", "ENTRY"), row("man", "2026-11-02T10:15:10+09:00", source = "MANUAL"),
            row("prev", "2026-11-02T09:55:00+09:00", "SKIP"))
        val s = LiveEntryState.of(gaps, "2026-11-02T10:21:00+09:00", tag)
        assertEquals(2 + 7, s.hourSlots)            // 10:00 10:10 stored + 10:25 .. 10:55 ahead (10:15 / 10:20 missing, 10:05 had no data)
        assertEquals(2, s.hourEntries)              // 10:10 + the manual entry
    }

    @Test fun quotaUsesTheSlotsAndMatchesTheResearch() {
        assertEquals(9, RankLadder.hourQuota(12)); assertEquals(8, RankLadder.hourQuota(11)); assertEquals(3, RankLadder.hourQuota(4))
        assertEquals(1, RankLadder.hourQuota(1)); assertEquals(0, RankLadder.hourQuota(0))
        // joined at 10:41 with 3 slots: 3 entries are enough, no burst of nine at the end of the hour
        assertTrue(RankLadder.minuteCut(true, 10, 41, 3, 3).full)
        assertFalse(RankLadder.minuteCut(true, 10, 41, 0, 3).catchUp)
        assertTrue(RankLadder.minuteCut(true, 10, 57, 0, 3).catchUp)
        assertEquals(RankLadder.minuteCut(true, 10, 20, 2).cut, RankLadder.minuteCut(true, 10, 20, 2, 12).cut, 0.0)
        val lines = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0771_hour_slots_parity.txt.gz")!!).bufferedReader().readLines()   // v0.7.71: nine pairs, pace 0.8
        for (line in lines) {
            val f = line.split('|')
            val c = RankLadder.minuteCut(f[1] == "fresh", f[2].toInt(), f[3].toInt(), f[4].toInt(), f[5].toInt()).cut
            val want = f[6].replace("inf", "Infinity").toDouble()
            if (want.isInfinite()) assertEquals(line, want, c, 0.0) else assertEquals(line, want, c, 1e-12)
        }
        assertEquals(1200, lines.size)
    }

    @Test fun policyShowsAndUsesTheHourSlots() {
        var n = 0
        for (s in EvidenceFixture.slots.filter { !it.weekend }) {
            EvidencePolicy.resetState()
            val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.WEEKDAY_60, 2, 0, 0, 4)
            val top = out.top1!!
            if (top.grade == "I") continue
            val note = top.reasons[1]
            if (" FIVE=" !in note || " CAUTION" in note) continue
            assertTrue(note, " slots=4" in note)
            val minute = java.time.ZonedDateTime.parse(out.entryTimeJst).withZoneSameInstant(java.time.ZoneId.of("Asia/Tokyo")).minute
            val hour = java.time.ZonedDateTime.parse(out.entryTimeJst).withZoneSameInstant(java.time.ZoneId.of("Asia/Tokyo")).hour
            val mc = RankLadder.minuteCut(" fresh5" in note, hour, minute, 2, 4)
            assertEquals(note, mc.need, Regex(" need=(-?[0-9]+) ").find(note)!!.groupValues[1].toInt())
            assertTrue(top.assessment!!.correctionLabel!!, top.assessment!!.correctionLabel!!.contains("70%（3回/4枠）"))
            n++
        }
        assertTrue("checked $n", n >= 10)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.71: weekday 5-minute AUTO over the yen crosses + BTC/JPY, ETH/JPY, BTC/USD, ETH/USD (Coinbase, theoption's crypto source). */
class CryptoV0771Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun lines(name: String) = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream(name)!!).bufferedReader().readLines()

    @Test fun coinbaseResponsesAreReadExactly() {
        // /products/BTC-USD/candles: newest first; a broken row and a row off the minute grid are dropped
        val text = "[[1793880060,70010.5,70100,70050.25,70090,12.5],[1793880000,69990,70080.5,70000,70050.25,8],[1793880030,1,2,1,1,1],[1793879940,10,5,7,7,1]]"
        val c = CryptoPairs.parseCandles(text)
        assertEquals(listOf(1793880000000L, 1793880060000L), c.map { it.timeEpochMs })
        assertEquals(Candle(1793880060000L, 70050.25, 70100.0, 70010.5, 70090.0, 12.5), c[1])
        assertTrue(CryptoPairs.parseCandles("[]").isEmpty())
        // /products/BTC-USD/ticker
        val t = CryptoPairs.parseTicker("""{"ask":"70091.01","bid":"70090.99","volume":"8123.5","trade_id":912345678,"price":"70091.00","size":"0.0012","time":"2026-11-05T10:15:30.123456Z"}""")!!
        assertEquals(70091.0, t.first, 0.0); assertEquals(java.time.Instant.parse("2026-11-05T10:15:30.123456Z").toEpochMilli(), t.second)
        assertNull(CryptoPairs.parseTicker("""{"message":"NotFound"}""")); assertNull(CryptoPairs.parseTicker("""{"price":"0","time":"2026-11-05T10:15:30Z"}"""))
        assertEquals("BTC-USD", CryptoPairs.product("BTCJPY")); assertEquals("ETH-USD", CryptoPairs.product("ETHUSD")); assertNull(CryptoPairs.product("USDJPY"))
        assertEquals("ETH/JPY", CryptoPairs.display("ETHJPY")); assertEquals("USDJPY", CryptoPairs.display("USDJPY"))
    }

    @Test fun binanceBackupIsReadExactly() {
        // data-api.binance.vision /api/v3/klines?interval=1m: oldest first, strings; a row off the minute grid and a broken row are dropped
        val k = "[[1793880000000,\"70000.00\",\"70080.50\",\"69990.00\",\"70050.25\",\"8.0\",1793880059999,\"560000.1\",120,\"4.0\",\"280000.0\",\"0\"]," +
            "[1793880060000,\"70050.25\",\"70100.00\",\"70010.50\",\"70090.00\",\"12.5\",1793880119999,\"875000.0\",150,\"6.0\",\"420000.0\",\"0\"]," +
            "[1793880030000,\"1\",\"2\",\"1\",\"1\",\"1\",1793880089999,\"1\",1,\"1\",\"1\",\"0\"],[1793880120000,\"7\",\"5\",\"10\",\"7\",\"1\",1793880179999,\"1\",1,\"1\",\"1\",\"0\"]]"
        val c = CryptoPairs.parseBinanceKlines(k)
        assertEquals(listOf(1793880000000L, 1793880060000L), c.map { it.timeEpochMs })
        assertEquals(Candle(1793880060000L, 70050.25, 70100.0, 70010.5, 70090.0, 12.5), c[1])
        assertTrue(CryptoPairs.parseBinanceKlines("[]").isEmpty())
        // /api/v3/trades?limit=1: newest trade with its time in ms
        val t = CryptoPairs.parseBinanceTrade("""[{"id":5123456789,"price":"70091.01000000","qty":"0.00120000","quoteQty":"84.10921200","time":1793880061234,"isBuyerMaker":true,"isBestMatch":true}]""")!!
        assertEquals(70091.01, t.first, 0.0); assertEquals(1793880061234L, t.second)
        assertNull(CryptoPairs.parseBinanceTrade("""{"code":-1121,"msg":"Invalid symbol."}""")); assertNull(CryptoPairs.parseBinanceTrade("[]"))
        assertEquals("BTCUSDT", CryptoPairs.binanceSymbol("BTC-USD")); assertEquals("ETHUSDT", CryptoPairs.binanceSymbol("ETH-USD")); assertNull(CryptoPairs.binanceSymbol("USDJPY"))
        // a result's judge price comes from the entry price's source
        assertEquals("Coinbase", CryptoPairs.sourceOf("Coinbase 1m open")); assertEquals("Binance", CryptoPairs.sourceOf("Binance manual live"))
        assertNull(CryptoPairs.sourceOf("Yahoo 1m open")); assertNull(CryptoPairs.sourceOf(null)); assertNull(CryptoPairs.sourceOf(""))
    }

    @Test fun yenSeriesMatchesTheResearchSeries() {
        // research: Coinbase BTC-USD x Dukascopy USD/JPY (scripts/v0771_syn.py); a Friday FX close into the weekend and a weekday hour
        var coin = ArrayList<Candle>(); var fx = ArrayList<Candle>(); var exp = ArrayList<Candle>(); var slices = 0; var checked = 0
        for (l in lines("v0771_crypto_yen_parity.txt.gz")) {
            if (l == "#") {
                val got = CryptoPairs.toYen(coin, fx).associateBy { it.timeEpochMs }
                assertEquals(exp.size, got.size)
                for (e in exp) {
                    val g = got.getValue(e.timeEpochMs)
                    for ((a, b) in listOf(e.open to g.open, e.high to g.high, e.low to g.low, e.close to g.close)) assertEquals(a, b, 1e-7 * a)
                    checked++
                }
                coin = ArrayList(); fx = ArrayList(); exp = ArrayList(); slices++; continue
            }
            val p = l.split('|'); if (p.size < 6) continue
            val k = Candle(p[1].toLong(), p[2].toDouble(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), if (p.size > 6) p[6].toDouble() else 0.0)
            when (p[0]) { "C" -> coin.add(k); "F" -> fx.add(k); "E" -> exp.add(k) }
        }
        assertEquals(2, slices); assertTrue(checked > 400)
        // a missing USD/JPY minute takes the previous minute's close as its open; after the last FX minute the close is carried
        val t0 = 1_793_880_000_000L
        val c = (0..3).map { Candle(t0 + it * 60_000L, 100.0, 101.0, 99.0, 100.5, 1.0) }
        val f = listOf(Candle(t0, 150.0, 150.2, 149.9, 150.1, 0.0), Candle(t0 + 120_000L, 150.3, 150.4, 150.2, 150.35, 0.0))
        val y = CryptoPairs.toYen(c, f)
        assertEquals(100.0 * 150.1, y[1].open, 1e-9); assertEquals(100.5 * 150.1, y[1].close, 1e-9)          // minute 1: no FX bar
        assertEquals(100.0 * 150.3, y[2].open, 1e-9); assertEquals(100.0 * 150.35, y[3].open, 1e-9)          // minute 3: after the last FX bar
        assertEquals(4, y.size); assertTrue(CryptoPairs.toYen(c, emptyList()).isEmpty())
    }

    @Test fun liveYenUsesTheCryptoTimeUnlessUsdJpyIsStale() {
        val coin = EvidencePolicy.LiveQuote(70000.0, 1_000_000L)
        assertEquals(EvidencePolicy.LiveQuote(70000.0 * 153.2, 1_000_000L), CryptoPairs.liveYen(coin, EvidencePolicy.LiveQuote(153.2, 990_000L), true))
        assertEquals(900_000L, CryptoPairs.liveYen(coin, EvidencePolicy.LiveQuote(153.2, 900_000L), true)!!.epochMs)     // 100 s older: stale
        assertEquals(1_000_000L, CryptoPairs.liveYen(coin, EvidencePolicy.LiveQuote(153.2, 1L), false)!!.epochMs)         // weekend
        assertNull(CryptoPairs.liveYen(coin, null, true))
    }

    private fun walk(name: String, b: Long, start: Double, step: Double, n: Int = 130): List<Candle> {
        var p = start; val r = java.util.Random(name.hashCode().toLong())
        return (0 until n).map { i ->
            val o = p; p *= 1 + step * (r.nextGaussian()); val h = maxOf(o, p) * (1 + step / 3); val l = minOf(o, p) * (1 - step / 3)
            Candle((b - (n - i) * 60L) * 1000L, o, h, l, p, 1.0)
        }
    }

    @Test fun designAndPoolFollowTheResearch() {
        val b = ZonedDateTime.of(2026, 11, 5, 14, 35, 0, 0, jst).toEpochSecond()
        val px = mapOf("USDJPY" to 153.0, "EURJPY" to 176.0, "GBPJPY" to 200.0, "AUDJPY" to 100.0, "NZDJPY" to 90.0,
            "BTCJPY" to 1.07e7, "ETHJPY" to 5.4e5, "BTCUSD" to 70000.0, "ETHUSD" to 3500.0)
        val candles = px.mapValues { (k, v) -> walk(k, b, v, if (CryptoPairs.isCrypto(k)) 8e-4 else 1.5e-4) }
        val feats = candles.mapValues { (k, v) -> EvidenceFeatures.instrument(k, v, b, v.last().close * 1.0001)!! }
        val basket = CandleModel9.basket(feats)
        assertEquals((feats.getValue("USDJPY").r5 + feats.getValue("EURJPY").r5 + feats.getValue("GBPJPY").r5 + feats.getValue("AUDJPY").r5) / 4.0, basket.r5, 1e-15)
        val x = CandleModel9.design(feats.getValue("GBPJPY"), basket, 14, -1, true)
        assertEquals(CandleModel9.FEATURE_COUNT, x.size)
        assertEquals(-feats.getValue("GBPJPY").r1, x[0], 0.0); assertEquals(-basket.r5, x[10], 0.0); assertEquals(-(feats.getValue("GBPJPY").r5 - basket.r5), x[11], 0.0)
        assertEquals(-basket.f1, x[20], 0.0); assertEquals(14.0, x[24], 0.0); assertEquals(1.0, x[25 + 2], 0.0); assertEquals(-1.0, x[34], 0.0)
        val e = CandleModel9.design(feats.getValue("ETHUSD"), basket, 14, 1, true)
        assertEquals(0.0, e[10], 0.0); assertEquals(feats.getValue("ETHUSD").r5, e[11], 0.0); assertEquals(1.0, e[25 + 8], 0.0)
        val fb = CandleModel9.design(feats.getValue("ETHUSD"), basket, 14, 1, false); for (i in 14..21) assertEquals(0.0, fb[i], 0.0)
        // yen basket needs all four majors: NaN otherwise (as the research rows)
        assertTrue(CandleModel9.basket(feats - "AUDJPY").r5.isNaN())
        assertTrue(CandleModel9.design(feats.getValue("USDJPY"), CandleModel9.basket(feats - "AUDJPY"), 14, 1, true)[10].isNaN())
        // the pool: with fresh yen prices, a crypto pair without a live price is never chosen
        val entry = ZonedDateTime.of(2026, 11, 5, 14, 35, 0, 0, jst)
        val fxQ = TradingSession.FX.associateWith { EvidencePolicy.LiveQuote(candles.getValue(it).last().close, b * 1000L - 10_000L) }
        val fx = TradingSession.FX.associateWith { candles.getValue(it) }; val cr = CryptoPairs.ALL.associateWith { candles.getValue(it) }
        val none = EvidencePolicy.choose9(fx, cr, fxQ, emptyMap(), entry)!!
        assertTrue(none.fresh); assertFalse(CryptoPairs.isCrypto(none.instrument))
        val crQ = CryptoPairs.ALL.associateWith { EvidencePolicy.LiveQuote(candles.getValue(it).last().close, b * 1000L - 10_000L) }
        val all = EvidencePolicy.choose9(fx, cr, fxQ, crQ, entry)!!
        assertTrue(all.instrument in CandleModel9.INSTRUMENTS)
        val best = CandleModel9.INSTRUMENTS.flatMap { s -> listOf(1, -1).map { d ->
            EvidenceEnsemble.fresh9.probability(CandleModel9.design(EvidenceFeatures.instrument(s, candles.getValue(s), b,
                (fxQ + crQ).getValue(s).price)!!, CandleModel9.basket(candles.mapValues { (k, v) -> EvidenceFeatures.instrument(k, v, b, (fxQ + crQ).getValue(k).price)!! }),
                14, d, true)) } }.max()
        assertEquals(best, all.probability, 1e-15)
        // without yen live prices: the backup model, crypto included without live prices
        val fallback = EvidencePolicy.choose9(fx, cr, emptyMap(), emptyMap(), entry)!!
        assertFalse(fallback.fresh)
    }

    @Test fun productionModelMatchesPython() {
        // 240 design rows per model (fresh / backup) with the Python ensemble probability (scripts/v0771_production.py)
        var n = 0
        for (l in lines("v0771_model9_parity.txt.gz")) {
            val p = l.split('|'); if (p.size != 3) continue
            val x = p[2].split(',').map { if (it == "nan") Double.NaN else it.toDouble() }.toDoubleArray()   // NaN = no yen basket (as the research rows)
            val m = if (p[0] == "fresh") EvidenceEnsemble.fresh9 else EvidenceEnsemble.fallback9
            assertEquals(p[1].toDouble(), m.probability(x), 1e-12); n++
        }
        assertEquals(480, n)
        assertEquals(CandleModel9.FEATURE_COUNT, EvidenceModel9Data.FEATURE_COUNT)
        for (h in 9..22) for (f in listOf(true, false)) {
            val q = if (f) EvidenceSlot9Data.FRESH_QUANTILES[h - 9] else EvidenceSlot9Data.FALLBACK_QUANTILES[h - 9]
            assertEquals(EvidenceSlot9Data.QUANTILE_POINTS + 1, q.size); assertTrue((1 until q.size).all { q[it] >= q[it - 1] })
            assertTrue(RankLadder.baseShare(f, h) in 0.4..0.8)
        }
    }

    @Test fun hourRuleWaitsSlightlyLongerEarly() {
        // pace 0.8: 9 needed with 12 slots left asks for the top 60% (0.8 x 9 / 12), not 75%
        val m = RankLadder.minuteCut(true, 14, 0, 0)
        assertEquals(RankLadder.quantileCut(true, 14, maxOf(0.8 * 9 / 12, RankLadder.baseShare(true, 14) / 2)), m.cut, 0.0)
        assertTrue(RankLadder.minuteCut(true, 14, 15, 0).catchUp)                   // 9 needed, 9 slots left: enter regardless
        assertTrue(RankLadder.minuteCut(true, 14, 30, 9).full)
        assertEquals(5, RankLadder.judgeMinutes(false, "C")); assertEquals("【5分判定】C ENTRY ETH/USD HIGH（上）", SignalAlerts.entryTitle("C", "ETHUSD", "HIGH", 5))
    }

    @Test fun weekendModelMatchesPythonAndDecidesSaturdays() {
        var n = 0
        for (l in lines("v0771_modelW_parity.txt.gz")) {
            val p = l.split('|'); if (p.size != 3) continue
            val x = p[2].split(',').map { if (it == "nan") Double.NaN else it.toDouble() }.toDoubleArray()   // NaN = no yen basket (as the research rows)
            assertEquals(p[1].toDouble(), (if (p[0] == "fresh") EvidenceEnsemble.freshW else EvidenceEnsemble.fallbackW).probability(x), 1e-12); n++
        }
        assertEquals(480, n)
        val entry = ZonedDateTime.of(2026, 11, 7, 15, 20, 0, 0, jst); val b = entry.toEpochSecond()       // Saturday
        val px = mapOf("BTCJPY" to 1.07e7, "ETHJPY" to 5.4e5, "BTCUSD" to 70000.0, "ETHUSD" to 3500.0)
        val crypto = px.mapValues { (k, v) -> walk(k, b, v, 8e-4) }
        val x = EvidenceFeatures.instrument("ETHUSD", crypto.getValue("ETHUSD"), b, 3500.0)!!
        val d = CandleModelW.design(x, 15, -1, true)
        assertEquals(CandleModelW.FEATURE_COUNT, d.size); assertEquals(0.0, d[10], 0.0); assertEquals(-x.r5, d[11], 0.0); assertEquals(-x.f1, d[21], 0.0)
        assertEquals(15.0, d[24], 0.0); assertEquals(1.0, d[25], 0.0); assertEquals(1.0, d[26 + 3], 0.0); assertEquals(-1.0, d[30], 0.0)
        // only pairs with a live price are chosen; none -> backup model over all four
        val q = mapOf("ETHJPY" to EvidencePolicy.LiveQuote(crypto.getValue("ETHJPY").last().close, b * 1000L - 11_000L),
                      "BTCUSD" to EvidencePolicy.LiveQuote(crypto.getValue("BTCUSD").last().close, b * 1000L - 11_000L))
        val wk = EvidencePolicy.chooseWeekend(crypto, q, entry)!!
        assertTrue(wk.fresh); assertTrue(wk.instrument in q.keys)
        assertFalse(EvidencePolicy.chooseWeekend(crypto, emptyMap(), entry)!!.fresh)
        assertNull(EvidencePolicy.chooseWeekend(emptyMap(), q, entry))
        // the Saturday decision: the chosen pair, judged at 3 minutes, B at or above the hour's top-8% cut
        val native = ScanResult("s1", entry.minusSeconds(10).toString(), entry.toString(), entry.plusMinutes(3).toString(),
            listOf(ScanCandidate(1, "BTCJPY", "BTC/JPY", "HIGH", "C", null, "SKIP")), source = "AUTO", policyVersion = "TEST")
        val r = EvidencePolicy.apply(native, native, mapOf("BTCJPY" to crypto.getValue("BTCJPY")), emptyMap(), EntryMode.DEFAULT,
            crypto = crypto, cryptoQuotes = q)
        val top = r.top1!!
        assertEquals(wk.instrument, top.instrument); assertEquals(wk.direction, top.direction)
        assertEquals(entry.plusMinutes(3).toString(), r.judgeTimeJst)
        val cut = EvidenceModelWData.FRESH_B8[15 - 9]
        assertEquals(if (wk.probability >= cut) "B" else if (wk.probability >= EvidenceModelWData.FRESH_C60[15 - 9]) "C" else "D", top.grade)
        assertEquals(if (top.grade == "B") "ENTRY" else "SKIP", top.decision)
        assertEquals(if (top.instrument == "BTCJPY") 1 else 2, r.candidates.size)
        assertTrue((1..r.candidates.size).toSet() == r.candidates.map { it.rank }.toSet())
        // Coinbase down on a Saturday: the bitbank BTC/JPY rule decides as before (never ETH etc.)
        val backup = EvidencePolicy.apply(native, native, mapOf("BTCJPY" to crypto.getValue("BTCJPY")), emptyMap(), EntryMode.DEFAULT)
        assertEquals("BTCJPY", backup.top1!!.instrument)
    }
}

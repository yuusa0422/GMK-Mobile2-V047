import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.domain.ProviderClock
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** v0.7.54: a bitbank ticker stamped slightly ahead of the phone clock is a live price (it used to be rejected / LAST). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class ClockSkewV0754Test {
    @Before fun reset() = ProviderClock.reset()
    private fun ticker(ts: Long) = JSONObject().put("buy", "9999999").put("sell", "10000001").put("last", "10000000").put("timestamp", ts)

    @Test fun tickSlightlyAheadOfThePhoneClockIsLive() {
        val received = 1_761_000_000_000L
        val row = MarketRepository.decodeBitbankTicker(ticker(received + 800), received, "test")
        assertEquals("LIVE", row.freshnessStatus)
        assertEquals(received, row.sourceEpochMs)
        assertEquals(0.0, row.ageSeconds!!, 0.0)
        assertEquals(800L, ProviderClock.maxAheadMs(received))
        val past = MarketRepository.decodeBitbankTicker(ticker(received - 1_500), received, "test")
        assertEquals("LIVE", past.freshnessStatus); assertEquals(1.5, past.ageSeconds!!, 1e-9)
    }

    @Test fun tickFarAheadStaysInvalid() {
        val received = 1_761_000_000_000L
        val row = MarketRepository.decodeBitbankTicker(ticker(received + 60_000), received, "test")
        assertNotEquals("LIVE", row.freshnessStatus)
        assertNull(row.sourceEpochMs); assertNull(row.ageSeconds)
        assertEquals(10_000_000.0, row.price!!, 0.0)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.util.zip.GZIPInputStream

/**
 * v0.7.72 audit: real 5-minute slots of the current year (research minute bars) through the app's own pipeline (window of 61 bars
 * ending at the bar of B-120 with the forming bar of B-60 present, live price at B-10 s, basket, CandleModel9 / CandleModelW design,
 * ensembles, best of pairs x directions) give the research's decision: same pair, same direction, same probability.
 * Fixture: research_v0772/gen_real_slots_v0772.py.
 */
class RealSlotsV0772Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private class Slot(val kind: String, val b: Long) {
        val bars = LinkedHashMap<String, ArrayList<Candle>>(); val live = HashMap<String, Double>(); val expect = HashMap<String, Triple<String, String, Double>>()
    }
    private fun slots(): List<Slot> {
        val out = ArrayList<Slot>(); var cur: Slot? = null
        for (l in GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0772_real_slots.txt.gz")!!).bufferedReader().readLines()) {
            val p = l.split('|')
            when (p[0]) {
                "S" -> { cur = Slot(p[1], p[2].toLong()); out.add(cur) }
                "C" -> cur!!.bars.getOrPut(p[1]) { ArrayList() }.add(Candle(p[2].toLong() * 1000L, p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble()))
                "L" -> cur!!.live[p[1]] = p[2].toDouble()
                "E" -> cur!!.expect[p[1]] = Triple(p[2], p[3], p[4].toDouble())
            }
        }
        return out
    }

    @Test fun weekdaySlotsGiveTheResearchChoice() {
        var n = 0; var partial = 0
        for (s in slots().filter { it.kind == "wd" }) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst)
            val fx = s.bars.filterKeys { it in TradingSession.FX }; val cr = s.bars.filterKeys { CryptoPairs.isCrypto(it) }
            val at = s.b * 1000L - 10_000L
            val q = s.live.filterKeys { it in TradingSession.FX }.mapValues { EvidencePolicy.LiveQuote(it.value, at) }
            val cq = s.live.filterKeys { CryptoPairs.isCrypto(it) }.mapValues { EvidencePolicy.LiveQuote(it.value, at) }
            for ((kind, quotes, cquotes) in listOf(Triple("fresh", q, cq), Triple("fallback", emptyMap(), emptyMap()))) {
                val want = s.expect.getValue(kind)
                val got = EvidencePolicy.choose9(fx, cr, quotes, cquotes, entry) ?: error("no choice ${s.b}")
                assertEquals("${s.b} $kind", kind == "fresh", got.fresh)
                assertEquals("${s.b} $kind", want.first, got.instrument); assertEquals("${s.b} $kind", want.second, got.direction)
                assertEquals("${s.b} $kind", want.third, got.probability, 1e-9)
            }
            if (s.bars.size < 9) partial++
            n++
        }
        assertEquals(80, n); assertTrue("slots with a pair missing: $partial", partial >= 5)
    }

    @Test fun weekendSlotsGiveTheResearchChoice() {
        var n = 0
        for (s in slots().filter { it.kind == "we" }) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst)
            assertFalse(TradingSession.isWeekday(entry))
            val at = s.b * 1000L - 10_000L
            val cq = s.live.mapValues { EvidencePolicy.LiveQuote(it.value, at) }
            for ((kind, quotes) in listOf("fresh" to cq, "fallback" to emptyMap())) {
                val want = s.expect.getValue(kind)
                val got = EvidencePolicy.chooseWeekend(s.bars, quotes, entry) ?: error("no choice ${s.b}")
                assertEquals("${s.b} $kind", kind == "fresh", got.fresh)
                assertEquals("${s.b} $kind", want.first, got.instrument); assertEquals("${s.b} $kind", want.second, got.direction)
                assertEquals("${s.b} $kind", want.third, got.probability, 1e-9)
            }
            n++
        }
        assertEquals(40, n)
    }
}

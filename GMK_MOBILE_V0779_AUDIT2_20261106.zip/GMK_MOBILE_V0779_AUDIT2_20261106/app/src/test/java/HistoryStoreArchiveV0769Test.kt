import android.content.Context
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.domain.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File
import java.time.ZonedDateTime

/** v0.7.69: the history file keeps only the newest rows; older rows are in an archive file; the backup is in its own file. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26])
class HistoryStoreArchiveV0769Test {
    private val app get() = RuntimeEnvironment.getApplication()
    private val stores = mutableListOf<HistoryStore>()
    private val t0 = ZonedDateTime.parse("2026-11-02T09:00:00+09:00")
    private val archiveFile get() = File(app.filesDir, HistoryStore.ARCHIVE_FILE_NAME)
    private fun prefs(name: String) = app.getSharedPreferences(name, Context.MODE_PRIVATE)

    @Before fun clear() {
        listOf("gmk_mobile_history", "gmk_mobile_history_journal", "gmk_mobile_history_backup").forEach { prefs(it).edit().clear().commit() }
        listOf("", ".prev", ".tmp", ".corrupt").forEach { File(archiveFile.path + it).delete() }
    }
    @After fun flush() = stores.forEach(::drain)
    private fun store() = HistoryStore(app).also { stores += it }
    private fun drain(s: HistoryStore) {
        val deadline = System.nanoTime() + 10_000_000_000L
        while ((s.diagnosticStats().getBoolean("write_pending") || s.diagnosticStats().getBoolean("writer_active")) && System.nanoTime() < deadline) Thread.sleep(5)
        assertFalse(s.diagnosticStats().getBoolean("writer_active")); assertFalse(s.diagnosticStats().getBoolean("write_pending"))
    }

    private fun json(i: Int): JSONObject {
        val e = t0.plusMinutes(i.toLong())
        return JSONObject().put("id", 1_790_000_000_000L + i).put("scan_id", "auto-$i").put("source", "AUTO")
            .put("at_jst", e.minusSeconds(10).toString()).put("policy_version", "GMK_TEST_POLICY")
            .put("instrument", "USDJPY").put("direction", "HIGH").put("grade", "D").put("decision", "SKIP")
            .put("candidate_rank", 1).put("regime", "UNKNOWN").put("entry_time_jst", e.toString())
            .put("judge_time_jst", e.plusMinutes(5).toString()).put("entry_rate", JSONObject.NULL).put("judge_rate", JSONObject.NULL)
            .put("result_status", "SKIP")
    }
    private fun array(range: IntProgression) = JSONArray().also { a -> range.forEach { a.put(json(it)) } }
    private fun scan(i: Int): ScanResult {
        val e = t0.plusMinutes(i.toLong())
        return ScanResult("auto-$i", e.minusSeconds(10).toString(), e.toString(), e.plusMinutes(5).toString(),
            listOf(ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "D", null, "SKIP")), source = "AUTO", policyVersion = "GMK_TEST_POLICY")
    }
    private fun savedRecent() = JSONArray(prefs("gmk_mobile_history").getString("items", "[]")).length()

    @Test fun oldSingleFileHistoryIsSplitOnceAndReloadsUnchanged() {
        val legacy = array(1000 downTo 1).toString()
        prefs("gmk_mobile_history").edit().putString("items", legacy).putString("items_backup", legacy).putLong("items_backup_at_ms", 1L).commit()
        val s = store()
        assertEquals(1000, s.load().size)
        s.add(scan(1001)); drain(s)
        val d = s.diagnosticStats()
        assertEquals(1L, d.getLong("archive_writes")); assertEquals(701, d.getInt("archive_rows")); assertEquals(300, savedRecent())
        assertTrue(archiveFile.isFile)
        assertFalse("the second full copy left the history file", prefs("gmk_mobile_history").contains("items_backup"))
        assertEquals(legacy, prefs("gmk_mobile_history_backup").getString("items", null))
        val reloaded = HistoryStore(app).load()
        assertEquals(1001, reloaded.size); assertEquals(s.load(), reloaded)
        assertEquals((1001 downTo 1).map { "auto-$it" }, reloaded.map { it.scanId })
        // new rows and outcome changes only rewrite the small recent part
        for (i in 1002..1010) s.add(scan(i))
        drain(s)
        assertEquals(1L, s.diagnosticStats().getLong("archive_writes")); assertEquals(309, savedRecent())
        assertEquals(s.load(), HistoryStore(app).load())
    }

    @Test fun aStopBetweenTheArchiveAndTheRecentWriteLosesAndDoublesNothing() {
        prefs("gmk_mobile_history").edit().putString("items", array(1000 downTo 1).toString()).commit()
        val s = store(); s.load(); s.add(scan(1001)); drain(s)
        // as if the app stopped right after the archive (rows 701..1) was written: the history file still has all 1000 old rows
        prefs("gmk_mobile_history").edit().putString("items", array(1001 downTo 1).toString()).commit()
        val reloaded = HistoryStore(app).load()
        assertEquals((1001 downTo 1).map { "auto-$it" }, reloaded.map { it.scanId })
    }

    @Test fun anUnreadableArchiveFallsBackToTheVersionBeforeItAndIsRewritten() {
        prefs("gmk_mobile_history").edit().putString("items", array(1000 downTo 701).toString()).commit()
        archiveFile.writeText("GMK_HISTORY_ARCHIVE_V1 700\n" + (700 downTo 1).joinToString("\n") { json(it).toString() } + "\n")   // cut short: no end line
        File(archiveFile.path + ".prev").writeText("GMK_HISTORY_ARCHIVE_V1 600\n" + (600 downTo 1).joinToString("\n") { json(it).toString() } +
            "\nGMK_HISTORY_ARCHIVE_END 600\n")
        val s = store()
        val rows = s.load()
        assertEquals((1000 downTo 701).map { "auto-$it" } + (600 downTo 1).map { "auto-$it" }, rows.map { it.scanId })
        assertFalse(s.diagnosticStats().isNull("archive_error"))
        assertTrue("the cut-short file is kept aside", File(archiveFile.path + ".corrupt").isFile)
        s.add(scan(1001)); drain(s)
        assertEquals(1L, s.diagnosticStats().getLong("archive_writes")); assertTrue(s.diagnosticStats().isNull("archive_error"))
        assertEquals(s.load(), HistoryStore(app).load())
        assertTrue("the good earlier version is still there", File(archiveFile.path + ".prev").readText().startsWith("GMK_HISTORY_ARCHIVE_V1 600"))
    }
}

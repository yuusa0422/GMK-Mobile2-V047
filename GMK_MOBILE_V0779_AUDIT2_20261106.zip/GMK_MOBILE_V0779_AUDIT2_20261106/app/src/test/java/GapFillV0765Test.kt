import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.65: the minute Yahoo leaves out before its daily roll is rebuilt, so the 61-candle window works in the 9 o'clock hour. */
class GapFillV0765Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun sec(y: Int, mo: Int, d: Int, h: Int, mi: Int) = ZonedDateTime.of(y, mo, d, h, mi, 0, 0, jst).toEpochSecond()

    @Test fun realYahooRollIsRebuilt() {
        // real Yahoo 1-minute candles of 2026-10-07 06:30-08:44 JST (British summer time: 07:59 is missing)
        val lines = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0765_yahoo_rollover.txt.gz")!!).bufferedReader().readLines().filter { it.isNotBlank() }
        val bars = lines.map { it.split('|') }.groupBy({ it[0] }, { Candle(it[1].toLong(), it[2].toDouble(), it[3].toDouble(), it[4].toDouble(), it[5].toDouble(), 0.0) })
        val gapMs = sec(2026, 10, 7, 7, 59) * 1000L
        for ((inst, raw) in bars) {
            assertTrue(inst, raw.none { it.timeEpochMs == gapMs })
            for (m in 1..61) {                                   // every scan from 8:01 to 9:01 JST needed the missing candle
                val b = sec(2026, 10, 7, 8, 0) + m * 60L
                if (b - 120L > sec(2026, 10, 7, 8, 44)) continue
                assertNull("$inst $m", EvidenceFeatures.window(raw, b))
            }
            val f = MinuteGapFill.fill(raw)
            assertEquals(listOf(gapMs), f.filledMinutes)
            val prev = raw.first { it.timeEpochMs == gapMs - 60_000L }; val next = raw.first { it.timeEpochMs == gapMs + 60_000L }
            val x = f.candles.first { it.timeEpochMs == gapMs }
            assertEquals(prev.close, x.open, 0.0); assertEquals(next.open, x.close, 0.0)
            assertEquals(maxOf(prev.close, next.open), x.high, 0.0); assertEquals(minOf(prev.close, next.open), x.low, 0.0); assertEquals(0.0, x.volume, 0.0)
            val b = sec(2026, 10, 7, 8, 35)
            assertEquals(61, EvidenceFeatures.window(f.candles, b)!!.size)
            assertNotNull(EvidenceFeatures.instrument(inst, f.candles, b, f.candles.last().close))
            assertEquals(raw.size + 1, f.candles.size)            // nothing else is touched
            assertEquals(raw.sortedBy { it.timeEpochMs }, f.candles.filter { it.timeEpochMs != gapMs })
        }
    }

    private fun minutes(fromMs: Long, n: Int): List<Candle> {
        var p = 158.0
        return (0 until n).map { i -> val o = p; p += if (i % 3 == 0) 0.011 else -0.004; Candle(fromMs + i * 60_000L, o, maxOf(o, p) + 0.002, minOf(o, p) - 0.002, p, 1.0) }
    }

    @Test fun winterRollOpensTheNineOClockHour() {
        val gap = sec(2026, 11, 4, 8, 59) * 1000L
        val all = minutes(sec(2026, 11, 4, 7, 30) * 1000L, 160)        // 07:30 .. 10:09 JST
        val raw = all.filter { it.timeEpochMs != gap }
        val filled = MinuteGapFill.fill(raw).candles
        for (m in 0..62) {
            val b = sec(2026, 11, 4, 9, 0) + m * 60L                   // 9:00 .. 10:02
            val needsGap = b - 3720L <= gap / 1000L && gap / 1000L <= b - 120L
            assertEquals("raw $m", !needsGap, EvidenceFeatures.window(raw, b) != null)
            assertNotNull("filled $m", EvidenceFeatures.window(filled, b))
        }
        assertEquals((1..61).toList(), (0..62).filter { m -> val b = sec(2026, 11, 4, 9, 0) + m * 60L; b - 3720L <= gap / 1000L && gap / 1000L <= b - 120L })
    }

    @Test fun longerGapsStayAndCompleteDataIsUnchanged() {
        val t0 = sec(2026, 11, 4, 7, 30) * 1000L
        val all = minutes(t0, 160)
        val two = all.filter { it.timeEpochMs != t0 + 88 * 60_000L && it.timeEpochMs != t0 + 89 * 60_000L }   // 08:58 and 08:59 missing
        val f2 = MinuteGapFill.fill(two)
        assertTrue(f2.filledMinutes.isEmpty()); assertEquals(two, f2.candles)
        assertNull(EvidenceFeatures.window(f2.candles, sec(2026, 11, 4, 9, 35)))
        val same = MinuteGapFill.fill(all.reversed() + all.take(3))          // unsorted with duplicates -> sorted, deduplicated, nothing added
        assertTrue(same.filledMinutes.isEmpty()); assertEquals(all, same.candles)
        assertTrue(MinuteGapFill.fill(emptyList()).candles.isEmpty())
        val odd = listOf(all[0], all[1].copy(timeEpochMs = all[0].timeEpochMs + 90_000L))       // not on the minute grid -> left alone
        assertTrue(MinuteGapFill.fill(odd).filledMinutes.isEmpty())
    }

    @Test fun boardCountsEachMinuteOnce() {
        val m = sec(2026, 11, 4, 8, 59) * 1000L
        GapFillBoard.record("TESTJPY", listOf(m)); GapFillBoard.record("TESTJPY", listOf(m)); GapFillBoard.record("TESTJPY", listOf(m + 86_400_000L))
        val e = GapFillBoard.snapshot().getValue("TESTJPY")
        assertEquals(2, e.distinctFilled); assertEquals("2026-11-05T08:59", e.recentJst.first())
    }
}

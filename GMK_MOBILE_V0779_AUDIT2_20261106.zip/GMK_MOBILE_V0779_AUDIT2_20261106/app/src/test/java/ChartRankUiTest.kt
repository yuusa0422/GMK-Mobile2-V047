import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import jp.gmk.mobile.RankFilterChips
import jp.gmk.mobile.Top1Card
import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/**
 * v0.7.74: the TOP1 card is a spell card (grade -> Reimu spell name), says which theoption expiry to pick, and stays readable with
 * large text; the grade filter of the history list. (Until v0.7.73 this class tested the v0.7.42 similarity-rank labels and filter,
 * which belonged to an engine retired in v0.7.50 and are no longer drawn.)
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w360dp-h640dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class ChartRankUiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    private fun candidate(instrument: String, grade: String, decision: String) =
        ScanCandidate(1, instrument, CryptoPairs.display(instrument), "HIGH", grade, .55, decision, regime = "TREND")

    private fun render(top: ScanCandidate?, minutes: Int, fontScale: Float = 1f) {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, fontScale)) {
                MaterialTheme { Box(Modifier.size(360.dp, 600.dp)) {
                    Top1Card(top, minutes, "2026-11-06T10:05:00+09:00", "2026-11-06T10:10:00+09:00")
                } }
            }
        }
    }

    @Test fun entryShowsItsSpellCardAndTheExpiryToPick() {
        render(candidate("USDJPY", "C", "ENTRY"), 5)
        compose.onNodeWithText("夢符「封魔陣」").assertIsDisplayed()
        compose.onNodeWithText("ザオプションで「5分」を選んでエントリー").assertIsDisplayed()
        compose.onNodeWithText("運用等級 C", substring = true).assertIsDisplayed()
        compose.onNodeWithText("ENTRY 10:05:00", substring = true).assertIsDisplayed()
        saveScreenshot("top1_entry_c.png")
    }

    @Test fun cryptoPairStaysOneReadableLabelWithLargeText() {
        render(candidate("ETHUSD", "A", "ENTRY"), 3, 1.8f)
        compose.onNodeWithText("霊符「夢想封印」").assertIsDisplayed()
        val layouts = mutableListOf<androidx.compose.ui.text.TextLayoutResult>()
        compose.onNodeWithText("ETH/USD", useUnmergedTree = true)
            .performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.GetTextLayoutResult) { it(layouts) }
        val label = layouts.single()
        assertEquals("The pair must remain one readable label", 1, label.lineCount)
        assertTrue("The pair glyphs must fit", label.getLineRight(0) <= label.size.width && label.getLineLeft(0) >= 0f)
        saveScreenshot("top1_crypto_large_text.png")
    }

    @Test fun skipShowsTheBarrierCardAndItsReason() {
        render(ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "E", null, "SKIP"), 5)
        compose.onNodeWithText("結界「見送りの陣」").assertIsDisplayed()
        compose.onNodeWithText("今回は見送り（SKIP）").assertIsDisplayed()
        compose.onNodeWithText("見送り: 旧データ・理由未記録").assertIsDisplayed()
        compose.onNodeWithText("ザオプションで", substring = true).assertDoesNotExist()
    }

    @Test fun noScanYetSaysSo() {
        render(null, 3)
        compose.onNodeWithText("まだスキャン結果がありません", substring = true).assertIsDisplayed()
    }

    @Test fun gradeFilterSelectsAndHidesTheRetiredOneMinuteChip() {
        var selected = ""
        compose.setContent { MaterialTheme { RankFilterChips(emptyList(), "すべて") { selected = it } } }
        compose.onNodeWithTag("rank-filter-C").assertIsDisplayed().performClick()
        compose.runOnIdle { assertEquals("C", selected) }
        compose.onNodeWithTag("rank-filter-1分").assertDoesNotExist()
        saveScreenshot("rank_filter_chips.png")
    }

    private fun saveScreenshot(name: String) {
        val root = java.io.File(System.getProperty("gmk.projectRoot"), "release_evidence/v0774/screenshots")
        root.mkdirs()
        lateinit var bitmap: android.graphics.Bitmap
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            bitmap = android.graphics.Bitmap.createBitmap(view.width, view.height, android.graphics.Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(bitmap))
        }
        java.io.File(root, name).outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.68: missed results are retried while the app runs; AUTO slot log; the share display does not count I rows as slots. */
class RepairV0768Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private val tag = EvidencePolicy.POLICY_TAG
    private val now = ZonedDateTime.of(2026, 11, 4, 16, 0, 0, 0, jst)
    private fun row(id: String, judgeAgo: Long, status: String, decision: String = "ENTRY", grade: String = "C", source: String = "AUTO") =
        HistoryRow(id.hashCode().toLong(), id, source, now.minusMinutes(judgeAgo + 5).toString(), "USDJPY", "HIGH", grade, decision,
            entryTimeJst = now.minusMinutes(judgeAgo + 5).toString(), judgeTimeJst = now.minusMinutes(judgeAgo).toString(),
            entryRate = 150.0, resultStatus = status, policyVersion = tag)

    @Test fun dueRowsAreRecentMinuteAlignedMisses() {
        val skip = row("skip", 60, "JUDGE_RATE_MISSED", "SKIP", "D")
        assertTrue("a followed D skip", ObservationPolicy.tracks(skip))
        val rows = listOf(
            row("old_entry", 120, "JUDGE_RATE_MISSED"), skip, row("entry", 30, "ENTRY_RATE_MISSED"),
            row("manual", 30, "JUDGE_RATE_MISSED", source = "MANUAL"),            // arbitrary second: cannot be read back
            row("too_new", 1, "JUDGE_RATE_MISSED"),                               // the normal tracking may still be on it
            row("too_old", 25 * 60, "JUDGE_RATE_MISSED"),                         // beyond the provider's 1-minute history we rely on
            row("tried", 30, "JUDGE_RATE_MISSED"),                                // already retried 3 times
            row("won", 30, "WIN"), row("waiting", 30, "WAIT_JUDGE"))
        val due = OutcomeRepair.due(rows, now, mapOf("tried" to OutcomeRepair.MAX_ATTEMPTS))
        assertEquals(listOf("old_entry", "entry", "skip"), due.map { it.scanId })    // ENTRY first, oldest judge first
        assertEquals(OutcomeRepair.BATCH, OutcomeRepair.due((1..20).map { row("e$it", 10L + it, "JUDGE_RATE_MISSED") }, now, emptyMap()).size)
        assertTrue(OutcomeRepair.due(rows, now, mapOf("old_entry" to 3, "entry" to 3, "skip" to 3, "tried" to 3)).isEmpty())
    }

    @Test fun autoSlotLogKeepsOutcomesAndCounts() {
        AutoSlotLog.clear()
        AutoSlotLog.record("2026-11-03T21:15", "MISSED_SLEEP"); AutoSlotLog.record("2026-11-03T21:20", "FAILED", "Yahoo all endpoints failed")
        AutoSlotLog.record("2026-11-03T21:25", "OK", "C ENTRY")
        assertEquals(mapOf("MISSED_SLEEP" to 1, "FAILED" to 1, "OK" to 1), AutoSlotLog.counts())
        assertEquals("2026-11-03T21:20 FAILED Yahoo all endpoints failed", AutoSlotLog.recent()[1])
        repeat(500) { AutoSlotLog.record("k$it", "OK") }
        assertEquals(400, AutoSlotLog.recent().size); assertEquals("k499 OK", AutoSlotLog.recent().last())
        AutoSlotLog.clear()
    }

    @Test fun shareDisplayDoesNotCountUnjudgeableSlots() {
        fun r(id: String, t: String, decision: String, grade: String) = HistoryRow(id.hashCode().toLong(), id, "AUTO", t, "USDJPY", "HIGH", grade, decision,
            entryTimeJst = t, judgeTimeJst = ZonedDateTime.parse(t).plusMinutes(5).toString(), entryRate = 150.0, policyVersion = tag)
        val rows = listOf(r("a", "2026-11-04T09:00:00+09:00", "SKIP", "D"), r("b", "2026-11-04T09:35:00+09:00", "SKIP", "I"),
            r("c", "2026-11-04T09:40:00+09:00", "SKIP", "I"), r("d", "2026-11-04T09:45:00+09:00", "ENTRY", "C"))
        assertEquals(2 to 1, RankStatistics.entryShareByHour(rows).getValue("平日").getValue(9))    // was 4 slots (the I rows counted)
    }
}

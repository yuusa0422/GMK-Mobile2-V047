import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit

/** v0.7.62: the countdown follows the AUTO scans that really run; the recent-results warning. */
class ClockGuardV0762Test {
    private fun isAutoMinute(t: ZonedDateTime): Boolean {
        return t.minute % 5 == 4                     // v0.7.66: weekday and weekend every 5 minutes
    }
    @Test fun countdownMatchesTheAutoScheduleDayAndNight() {
        var t = ZonedDateTime.parse("2026-10-30T20:00:00+09:00"); val end = t.plusDays(4); var n = 0
        while (t.isBefore(end)) {
            var s = t.truncatedTo(ChronoUnit.MINUTES).withSecond(50)
            if (s.isBefore(t) && ChronoUnit.MILLIS.between(s, t) >= 1000L) s = s.plusMinutes(1)
            while (!(isAutoMinute(s) && TradingSession.isActive(s.plusSeconds(10)))) s = s.plusMinutes(1)
            assertEquals(t.toString(), ChronoUnit.SECONDS.between(t, s).toInt().coerceAtLeast(0), AutoClock.nextAutoScanSeconds(t)); t = t.plusSeconds(37); n++
        }
        assertTrue(n > 9000)
        assertEquals(890, AutoClock.nextAutoScanSeconds(ZonedDateTime.parse("2026-11-03T08:45:00+09:00")))     // not "every minute" at night
        assertEquals(90, AutoClock.nextAutoScanSeconds(ZonedDateTime.parse("2026-11-02T10:23:20+09:00")))      // next scan 10:24:50 (not every minute)
        assertEquals(30, AutoClock.nextAutoScanSeconds(ZonedDateTime.parse("2026-11-02T10:24:20+09:00")))
        assertEquals(0, AutoClock.nextAutoScanSeconds(ZonedDateTime.parse("2026-11-02T10:24:50.500+09:00")))
        assertEquals("9:59:55", AutoClock.countdownText(AutoClock.nextAutoScanSeconds(ZonedDateTime.parse("2026-10-30T22:59:55+09:00"))))
        assertEquals("00:30", AutoClock.countdownText(30))
    }
    private val tag = EvidencePolicy.POLICY_TAG
    private fun row(i: Int, day: String, win: Boolean, decision: String = "ENTRY") = HistoryRow(i.toLong(), "s$i", "AUTO", "${day}T10:00:00+09:00",
        "USDJPY", "HIGH", "C", decision, entryTimeJst = "${day}T10:%02d:00+09:00".format(i % 60), resultStatus = if (win) "WIN" else "LOSE", policyVersion = tag)
    private fun day(day: String, wins: Int, n: Int, start: Int) = (0 until n).map { row(start + it, day, it < wins) }
    @Test fun recentEdgeUsesFinishedWeekdaysOnly() {
        val today = LocalDate.parse("2026-11-03")
        assertEquals(RecentEdge.Level.COLLECTING, RecentEdge.of(day("2026-11-02", 43, 82, 0), today, tag).level)
        val good = day("2026-10-28", 60, 100, 0) + day("2026-10-29", 55, 100, 200) + day("2026-10-30", 54, 100, 400) +
            day("2026-10-31", 0, 100, 600) /* Saturday: not counted */ + day("2026-11-03", 0, 100, 800) /* today: not counted */
        val s = RecentEdge.of(good, today, tag); assertEquals(RecentEdge.Level.GOOD, s.level); assertEquals(3, s.days); assertEquals(169, s.wins); assertEquals(300, s.total)
        val bad = day("2026-10-28", 48, 100, 0) + day("2026-10-29", 49, 100, 200) + day("2026-10-30", 47, 100, 400)
        assertEquals(RecentEdge.Level.STOP, RecentEdge.of(bad, today, tag).level)
        val mid = day("2026-10-28", 51, 100, 0) + day("2026-10-29", 52, 100, 200) + day("2026-10-30", 51, 100, 400)
        assertEquals(RecentEdge.Level.BELOW_BREAK_EVEN, RecentEdge.of(mid, today, tag).level)
        // SKIP rows, other versions and days with < 20 results are ignored; at most 10 days
        val skips = bad.map { it.copy(decision = "SKIP") } + day("2026-10-27", 5, 10, 900)
        assertEquals(RecentEdge.Level.COLLECTING, RecentEdge.of(skips, today, tag).level)
        val many = (1..15).flatMap { d -> val dt = LocalDate.parse("2026-10-01").plusDays(d.toLong()); if (dt.dayOfWeek.value > 5) emptyList() else day(dt.toString(), 60, 100, d * 1000) }
        assertEquals(10, RecentEdge.of(many, today, tag).days)
        assertTrue(RecentEdge.label(RecentEdge.of(bad, today, tag)).startsWith("停止推奨"))
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.50 audit fixes: BTC UTC day files, history filters, D..H observation, rank table, I rows. */
class AuditFixV0750Test {
    @Before fun reset() = EvidencePolicy.resetState()
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun ms(h: Int, m: Int, day: Int = 23) = ZonedDateTime.of(2026, 10, day, h, m, 0, 0, jst).toInstant().toEpochMilli()

    @Test fun bitbankDayFilesAreUtcDaysAndTheMorningWindowSpansTwoFiles() {
        // 09:35 JST = 00:35 UTC: the 61-bar window reaches back into the previous UTC day.
        assertEquals(listOf("20261023", "20261022"), BitbankDays.keys(ms(9, 35), 130L))
        assertEquals(listOf("20261023", "20261022"), BitbankDays.keys(ms(10, 0), 130L))
        // From 11:10 JST the last 130 minutes are inside one UTC day.
        assertEquals(listOf("20261023"), BitbankDays.keys(ms(11, 15), 130L))
        assertEquals(listOf("20261023"), BitbankDays.keys(ms(22, 55), 130L))
        // 08:30 JST is still the previous UTC day.
        assertEquals("20261022", BitbankDays.key(ms(8, 30)))
        assertEquals("20261021", BitbankDays.keyDaysBefore(ms(9, 5), 2))
    }

    private fun row(policy: String, grade: String, decision: String, status: String, entry: String = "2026-10-23T14:00:00+09:00",
                    source: String = "AUTO", minutes: Long = 3) = HistoryRow(1, "id-$policy-$grade-$status-$entry", source, entry, "USDJPY", "HIGH", grade, decision,
        entryTimeJst = entry, judgeTimeJst = ZonedDateTime.parse(entry).plusMinutes(minutes).toString(),
        entryRate = 150.0, judgeRate = if (status == "WIN") 151.0 else 149.0, resultStatus = status, policyVersion = policy)

    @Test fun historyCountsOneMinuteBoardAndEvidenceRowsWhateverTheThreeMinuteSwitch() {
        val oneMinute = row(RankStatistics.ONE_MINUTE_POLICY, "A", "ENTRY", "WIN", minutes = 1)
        assertTrue(ExpiryProfiles.includes(oneMinute, false, false))
        assertTrue(ExpiryProfiles.includes(oneMinute, true, false))
        assertEquals(1, historyStatistics(listOf(oneMinute).filter { ExpiryProfiles.includes(it, true, false) }).getValue(1).wins)
        val weekend = row(EvidencePolicy.POLICY_TAG, "S", "ENTRY", "WIN", "2026-10-24T14:00:00+09:00")
        val fixedWeekday = row(EvidencePolicy.POLICY_TAG + "_3M_FIXED", "A", "ENTRY", "LOSE")
        for (fixed in listOf(true, false)) {
            assertTrue(ExpiryProfiles.includes(weekend, fixed, false))
            assertTrue(ExpiryProfiles.includes(fixedWeekday, fixed, false))
            assertTrue(ExpiryProfiles.includes(row("GMK_V0740_V0749_EVIDENCE", "B", "ENTRY", "WIN"), fixed, false))
        }
        // Older policies keep their switch-dependent view.
        val old = row("GMK_V0736_PC_R13_3M_FIXED", "C", "ENTRY", "WIN")
        assertTrue(ExpiryProfiles.includes(old, true, false)); assertFalse(ExpiryProfiles.includes(old, false, false))
        assertFalse(ExpiryProfiles.includes(row("GMK_V0740_TECH_WEEKDAY_HOUR_K100_C_M10_3M_FIXED", "C", "ENTRY", "WIN"), false, false))
        assertFalse(ExpiryProfiles.includes(row("OTHER", "C", "ENTRY", "WIN"), false, false))
    }

    @Test fun onlyEvidenceSkipsDtoHAreObservedAndTheyNeverEnterWinRateOrStreak() {
        assertTrue(ObservationPolicy.tracks("SKIP", "D", EvidencePolicy.POLICY_TAG))
        assertTrue(ObservationPolicy.tracks("SKIP", "H", "GMK_V0740_V0749_EVIDENCE_3M_FIXED"))
        assertFalse(ObservationPolicy.tracks("SKIP", "I", EvidencePolicy.POLICY_TAG))
        assertFalse(ObservationPolicy.tracks("ENTRY", "C", EvidencePolicy.POLICY_TAG))
        assertFalse(ObservationPolicy.tracks("SKIP", "E", RankStatistics.ONE_MINUTE_POLICY))
        assertFalse(ObservationPolicy.tracks("SKIP", "E", "GMK_V0740_TECH_WEEKDAY_HOUR_K100_C_M10"))
        val rows = listOf(
            row(EvidencePolicy.POLICY_TAG, "A", "ENTRY", "WIN", "2026-10-23T14:00:00+09:00"),
            row(EvidencePolicy.POLICY_TAG, "E", "SKIP", "LOSE", "2026-10-23T14:05:00+09:00"),
            row(EvidencePolicy.POLICY_TAG, "E", "SKIP", "LOSE", "2026-10-23T14:10:00+09:00"),
            row(EvidencePolicy.POLICY_TAG, "B", "ENTRY", "WIN", "2026-10-23T14:15:00+09:00"))
        val s = historyStatistics(rows).getValue(3)
        assertEquals(2, s.wins); assertEquals(0, s.losses); assertEquals(100.0, s.winRate()!!, 0.0)
        assertEquals(2, s.skips); assertEquals(2, s.skipShadow); assertEquals(0, s.maxConsecutiveLosses)
    }

    @Test fun rankTableSeparatesVersionsSegmentsAndTheOneMinuteBoard() {
        val rows = listOf(
            row("GMK_V0740_V0749_EVIDENCE", "A", "ENTRY", "WIN"),
            row("GMK_V0740_V0749_EVIDENCE", "A", "ENTRY", "LOSE"),
            row("GMK_V0740_V0749_EVIDENCE", "A", "ENTRY", "WAIT_JUDGE"),
            row("GMK_V0740_V0749_EVIDENCE", "D", "SKIP", "SKIP"),
            row("GMK_V0740_V0749_EVIDENCE", "S", "ENTRY", "WIN", "2026-10-24T14:00:00+09:00"),
            row(EvidencePolicy.POLICY_TAG + "_3M_FIXED", "E", "SKIP", "WIN"),
            row(EvidencePolicy.POLICY_TAG, "I", "SKIP", "SKIP"),
            row("GMK_V0740_V0748_EVIDENCE", "C", "ENTRY", "WIN"),
            row(RankStatistics.ONE_MINUTE_POLICY, "A", "ENTRY", "LOSE", minutes = 1),
            row("GMK_V0742_OCTOBER_CHART200_EH", "H", "SKIP", "SKIP"))
        val t = RankStatistics.tables(rows)
        assertEquals(listOf("${RankStatistics.evidenceVersion(EvidencePolicy.POLICY_TAG)}|平日", "0.7.49|平日", "0.7.49|土日", "0.7.48|平日", "1m|平日"), t.map { it.key })
        val v49 = t[1]
        assertEquals(listOf("A", "D"), v49.counts.map { it.grade })
        val a = v49.counts.first()
        assertEquals(1, a.wins); assertEquals(1, a.losses); assertEquals(1, a.pending); assertEquals(0.5, a.rate!!, 0.0)
        // v0.7.49 used other rank rules: no validated reference for its rows (only the current version shows one)
        assertEquals("A  1勝1敗 50.0%（判定待ち1）", RankStatistics.lineText(v49, a))
        assertEquals("D  見送り 1件", RankStatistics.lineText(v49, v49.counts[1]))
        val v50 = t[0]
        // v0.7.57: weekday E is no longer a current grade (no validated reference shown)
        assertEquals("E  見送り 1件・入っていたら 1勝0敗 100.0%" + (EvidencePolicy.gradeRate(true, false, "E")?.let { " ｜検証 " +
            String.format(java.util.Locale.US, "%.1f%%", it * 100.0) } ?: ""), RankStatistics.lineText(v50, v50.counts[0]))
        assertTrue(RankStatistics.lineText(v50, v50.counts[1]).startsWith("I  判定不能 1件"))
        assertTrue(t[3].validated.isEmpty())           // v0.7.48 rows: different rank definition, no pattern-rank reference
        assertTrue(t[4].oneMinute && t[4].validated.isEmpty())
        assertEquals("A  0勝1敗 0.0%", RankStatistics.lineText(t[4], t[4].counts[0]))
    }

    @Test fun rankFilterUsesOperationalGradesAndKeepsTheOneMinuteBoardApart() {
        val a3 = row(EvidencePolicy.POLICY_TAG, "A", "ENTRY", "WIN")
        val a1 = row(RankStatistics.ONE_MINUTE_POLICY, "A", "ENTRY", "WIN", minutes = 1)
        val g = row(EvidencePolicy.POLICY_TAG, "G", "SKIP", "SKIP")
        assertTrue(RankFilter.matches(a3, "A")); assertFalse(RankFilter.matches(a1, "A")); assertTrue(RankFilter.matches(a1, "1分"))
        assertTrue(RankFilter.matches(g, "D〜H")); assertFalse(RankFilter.matches(g, "A"))
        assertTrue(listOf(a3, a1, g).all { RankFilter.matches(it, "すべて") })
    }

    @Test fun undecidableSlotIsAnIRowOfThisPolicyWithAThreeMinuteJudge() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val native = s.native()
        val out = EvidencePolicy.apply(native, native.copy(policyVersion = "GMK_V0736_PC_R13", judgeTimeJst = s.entry.plusMinutes(5).toString()), emptyMap(), s.quotes())
        assertEquals("I", out.top1!!.grade); assertEquals("SKIP", out.top1!!.decision)
        assertEquals(EvidencePolicy.POLICY_TAG, out.policyVersion)
        assertEquals(s.entry.plusMinutes(3).toInstant(), ZonedDateTime.parse(out.judgeTimeJst).toInstant())
        assertNotNull(RankStatistics.evidenceVersion(out.policyVersion))
        assertFalse(ObservationPolicy.tracks(out.top1!!.decision, out.top1!!.grade, out.policyVersion))
        out.top1!!.assessment?.let { a ->
            assertTrue(a.correctionLabel!!.startsWith("判定不能 I（1分足61本の連続データ不足"))
            assertEquals(3, a.chosenAction.judgeMinutes)
        }
    }
}

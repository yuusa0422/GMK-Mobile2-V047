import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.54: losing contexts skipped, 1-minute board observation only, provider clock tolerance, signal alerts. */
class LossPatternsV0754Test {
    @Before fun reset() { EvidencePolicy.resetState(); ProviderClock.reset() }
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun at(mo: Int, d: Int, h: Int, m: Int, s: Int = 0) = ZonedDateTime.of(2026, mo, d, h, m, s, 0, jst)

    // v0.7.55 replaced the v0.7.54 ladder (C skipped everywhere); these tests keep checking that the v0.7.54 losing contexts stay skipped.
    @Test fun modelGradeSkipsTheLosingContexts() {
        // weekday 09h: every non-confirmed model trade -> F; confirmed strong trades stay B even at 9
        assertEquals("F", RankLadder.modelGrade("A", false, false, 9)); assertEquals("F", RankLadder.modelGrade("C", false, false, 9))
        assertEquals("B", RankLadder.modelGrade("S", false, true, 9)); assertEquals("D", RankLadder.modelGrade("B", false, false, 10))
        assertEquals("D", RankLadder.modelGrade("S", false, false, 22)); assertEquals("E", RankLadder.modelGrade("D", false, false, 9))
        // weekend: S -> B only against the hour, A/B/C -> D, D/E -> E, F..H unchanged
        assertEquals("B", RankLadder.modelGrade("S", true, againstHour = true)); assertEquals("D", RankLadder.modelGrade("S", true))
        for (g in listOf("A", "B", "C")) assertEquals("D", RankLadder.modelGrade(g, true, againstHour = true))
        assertEquals("D", RankLadder.modelGrade("D", true)); assertEquals("E", RankLadder.modelGrade("E", true))   // v0.7.56: v0.7.48 D below the C cut -> D
        for (g in listOf("F", "G", "H")) assertEquals(g, RankLadder.modelGrade(g, true))
        // demotion reasons only for trades the strength would have entered
        assertTrue(RankLadder.demotion("C", false, false, 9)!!.contains("9時台")); assertTrue(RankLadder.demotion("A", true, false, 15)!!.contains("土日"))
        assertNull(RankLadder.demotion("S", true, false, 15, againstHour = true)); assertTrue(RankLadder.demotion("S", true, false, 15)!!.contains("追いかける"))
        assertTrue(RankLadder.demotion("C", false, false, 10)!!.contains("50.8%")); assertNull(RankLadder.demotion("D", true, false, 9))   // v0.7.56: below the C cut
        assertNull(RankLadder.demotion("S", false, true, 14))
    }

    @Test fun ladderRatesStayOrdered() {
        val wd = listOf("S", "A", "B", "C", "D").map { EvidencePolicy.gradeRate(true, false, it)!! }   // v0.7.57: weekday S..D (E/F unused)
        assertTrue(wd.zipWithNext().all { (a, b) -> a > b })
        for (f in listOf(true, false)) for (w in listOf(true, false)) assertTrue(EvidencePolicy.gradeRate(f, w, "C")!! < 0.55)
        val we = listOf("B", "C", "D", "E", "F", "G", "H").map { EvidencePolicy.gradeRate(true, true, it)!! }
        assertTrue(we.zipWithNext().all { (a, b) -> a > b })
        val fb = listOf("B", "C", "D", "E", "F", "G", "H").map { EvidencePolicy.gradeRate(false, true, it)!! }
        assertTrue(fb.zipWithNext().all { (a, b) -> a > b })
        assertEquals(RankStatistics.CURRENT_RANK_VERSIONS, setOf(RankStatistics.evidenceVersion(EvidencePolicy.POLICY_TAG)))
    }

    @Test fun realSlotsSkipWeekendCAndPreFixC() {
        var demoted = 0; var weekendEntries = 0
        for (s in EvidenceFixture.slots) {
            EvidencePolicy.resetState()
            val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes())
            val top = out.top1!!; val note = top.reasons[1]; val label = top.assessment!!.correctionLabel!!.removePrefix("【3分判定】").removePrefix("【5分判定】")
            val entry = ZonedDateTime.parse(s.native().entryTimeJst).withZoneSameInstant(jst)
            val v48 = Regex(" v0748=([A-Z])").find(note)!!.groupValues[1]
            if (s.weekend) {
                assertTrue("weekend ${s.boundary} ${top.grade}", top.grade !in setOf("S", "A"))   // v0.7.56: weekend C exists (SKIP in 55%優先)
                if (top.decision == "ENTRY") { weekendEntries++; assertEquals("B", top.grade); assertEquals("S", v48); assertTrue(" AGAINST_HOUR" in note) }
            } else if (entry.hour == 9 && " RULE=" !in note) assertTrue(top.grade in setOf("B", "C", "D"))   // v0.7.57: 09h uses the hour's own 5-minute cut
            if (" DEMOTED" in note) {
                demoted++
                assertEquals("SKIP", top.decision); assertTrue(top.grade in setOf("C", "D", "E", "F"))
                assertTrue(label, label.startsWith("見送り ") && "理由: " in label)
                assertTrue(v48 in setOf("S", "A", "B", "C") || top.grade == "C")   // v0.7.56: a weekend C may come from v0.7.48 D (v0.7.57: weekday C = 5-minute model)
            }
            assertEquals(top.grade in RankLadder.ENTRY_GRADES, top.decision == "ENTRY")
            assertEquals(top.grade, top.assessment!!.chosenAction.operationalGrade)
        }
        assertTrue("demoted=$demoted weekendEntries=$weekendEntries", demoted >= 1)
    }

    @Test fun oneMinuteBoardIsObservationOnly() {
        assertTrue(OneMinuteObservation.isObservation(OneMinuteObservation.POLICY))
        assertTrue(OneMinuteObservation.POLICY.startsWith(RankStatistics.ONE_MINUTE_POLICY))
        assertTrue(ObservationPolicy.tracks("SKIP", OneMinuteObservation.GRADE, OneMinuteObservation.POLICY))
        assertFalse(ObservationPolicy.tracks("SKIP", "E", RankStatistics.ONE_MINUTE_POLICY))      // pre-v0.7.54 1-minute rows
        fun row(id: String, status: String) = HistoryRow(id.hashCode().toLong(), id, "AUTO_1M", "2026-10-26T10:00:50+09:00", "USDJPY", "HIGH",
            OneMinuteObservation.GRADE, "SKIP", entryTimeJst = "2026-10-26T10:01:00+09:00", judgeTimeJst = "2026-10-26T10:02:00+09:00",
            entryRate = 150.0, judgeRate = if (status == "WIN") 150.1 else 149.9, resultStatus = status, policyVersion = OneMinuteObservation.POLICY)
        val rows = listOf(row("a", "WIN"), row("b", "LOSE"), row("c", "LOSE"))
        val t = RankStatistics.tables(rows).single()
        assertTrue(t.oneMinute && t.observationOnly); assertEquals("1mobs|平日", t.key)
        val line = RankStatistics.lineText(t, t.counts.single())
        assertTrue(line, line.startsWith("E  見送り 3件・入っていたら 1勝2敗"))
        val s = historyStatistics(rows).getValue(1)
        assertNull(s.winRate()); assertEquals(0, s.entries); assertEquals(3, s.skipShadow); assertEquals(1, s.skipShadowWins)
        assertEquals(0, s.maxConsecutiveLosses)
    }

    @Test fun providerClockToleratesASmallLeadOnly() {
        val now = 1_761_000_000_000L
        assertEquals(now, ProviderClock.effective(now + 800, now)); assertEquals(now, ProviderClock.effective(now + 3_000, now))
        assertNull(ProviderClock.effective(now + 3_001, now)); assertEquals(now - 500, ProviderClock.effective(now - 500, now))
        assertNull(ProviderClock.effective(0, now))
        assertEquals(now / 1000, ProviderClock.effectiveSeconds(now / 1000 + 2, now)); assertNull(ProviderClock.effectiveSeconds(now / 1000 + 3600, now))
        ProviderClock.observe(now + 800, now); ProviderClock.observe(now - 300, now + 1_000); ProviderClock.observe(now + 90_000, now + 2_000)
        assertEquals(88_000L, ProviderClock.maxAheadMs(now + 2_000)); assertEquals(2L to 1L, ProviderClock.counts())
        assertEquals(0L, ProviderClock.maxAheadMs(now + ProviderClock.WINDOW_MS + 5_000))
    }

    @Test fun signalAlertsFollowTheRulesAndTheCalendar() {
        val tag = EvidencePolicy.POLICY_TAG
        assertTrue(SignalAlerts.shouldNotify("ENTRY", "S", tag, "B")); assertTrue(SignalAlerts.shouldNotify("ENTRY", "B", tag, "B"))
        assertFalse(SignalAlerts.shouldNotify("ENTRY", "C", tag, "B")); assertTrue(SignalAlerts.shouldNotify("ENTRY", "C", tag, "C"))   // v0.7.56: "C" = every ENTRY again
        assertFalse(SignalAlerts.shouldNotify("ENTRY", "B", tag, "A")); assertFalse(SignalAlerts.shouldNotify("SKIP", "D", tag, "C"))
        assertFalse(SignalAlerts.shouldNotify("SKIP", "E", OneMinuteObservation.POLICY, "C"))
        assertFalse(SignalAlerts.shouldNotify("ENTRY", "A", RankStatistics.ONE_MINUTE_POLICY, "C"))
        assertEquals("C", SignalAlerts.normalizeMinGrade("X")); assertEquals("A", SignalAlerts.normalizeMinGrade("A"))   // v0.7.60: default = every ENTRY
        // next rule: Monday 26 Oct (London winter time, New York still summer time until 1 Nov)
        fun next(t: ZonedDateTime) = SignalAlerts.nextRule(t)!!.let { it.boundary to it.rules.map { r -> r.id } }
        assertEquals(at(10, 26, 9, 55) to listOf("FIX955_POS", "FIX955_BBZ"), next(at(10, 26, 9, 0)))
        assertEquals(at(10, 26, 9, 55), next(at(10, 26, 9, 55)).first)
        // v0.7.58: only 9:55 (2 rules) and New York 8:30 (F1) are kept
        assertEquals(at(10, 26, 21, 30) to listOf("US0830_F1"), next(at(10, 26, 9, 55, 1)))
        // 29 Oct 22:50 is inside the ECB caution window -> next is 30 Oct 9:55; 30 Oct 12:20 / 16:25 are inside the BOJ windows
        assertEquals(at(10, 30, 9, 55), next(at(10, 29, 21, 31)).first)
        assertEquals(at(10, 30, 21, 30), next(at(10, 30, 9, 56)).first)
        // after the US clock change New York 8:30 is 22:30 JST; Saturday/Sunday have no rules
        assertEquals(at(11, 2, 9, 55), next(at(10, 30, 22, 51)).first)
        assertEquals(at(11, 2, 22, 30), next(at(11, 2, 18, 31)).first)
        // the reminder is due during [boundary-120 s, boundary-75 s)
        assertNull(SignalAlerts.preAlertDue(at(10, 26, 9, 52, 59)))
        assertEquals(at(10, 26, 9, 55), SignalAlerts.preAlertDue(at(10, 26, 9, 53, 0))!!.boundary)
        assertEquals(at(10, 26, 9, 55), SignalAlerts.preAlertDue(at(10, 26, 9, 53, 44))!!.boundary)
        assertNull(SignalAlerts.preAlertDue(at(10, 26, 9, 53, 45)))
        assertNull(SignalAlerts.preAlertDue(at(10, 26, 10, 3, 0)))
        val text = SignalAlerts.nextRuleText(at(10, 26, 21, 0))
        assertTrue(text, text.startsWith("次の時間帯ルール 21:30 米指標の発表時刻(NY8:30)（S/A候補・あと30分）"))
        assertTrue(SignalAlerts.preAlertText(SignalAlerts.preAlertDue(at(10, 26, 9, 53, 10))!!).contains("9:54:50"))
        assertTrue(SignalAlerts.entryTitle("S", "USDJPY", "LOW").startsWith("【3分判定】S ENTRY USDJPY LOW"))   // v0.7.57
        assertTrue(SignalAlerts.notificationId("x") >= 10_000)
    }
}

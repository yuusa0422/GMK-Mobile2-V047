import jp.gmk.mobile.data.ShrineSound
import org.junit.Assert.*
import org.junit.Test

/** v0.7.77 効果音: the synthesised sounds are short, not clipped, and only the final WIN / LOSE cut-ins sound. */
class ShrineSoundV0777Test {
    @Test fun soundsAreShortAndNotClipped() {
        for (k in ShrineSound.Kind.values()) {
            val s = ShrineSound.samples(k)
            val seconds = s.size.toDouble() / ShrineSound.RATE
            assertTrue("$k $seconds", seconds in 0.15..0.5)
            val peak = s.maxOf { kotlin.math.abs(it.toInt()) }
            assertTrue("$k peak $peak", peak in 3000..Short.MAX_VALUE - 1000)
            assertTrue("$k starts quiet", kotlin.math.abs(s[0].toInt()) < 2000)
        }
        // ピチューン falls: more zero crossings at the start than at the end
        val lose = ShrineSound.samples(ShrineSound.Kind.LOSE)
        fun crossings(a: ShortArray) = (1 until a.size).count { (a[it - 1] < 0) != (a[it] < 0) }
        val q = lose.size / 4
        assertTrue(crossings(lose.copyOfRange(0, q)) > 2 * crossings(lose.copyOfRange(lose.size - q, lose.size)))
    }

    @Test fun onlyFinalCutInsSound() {
        assertEquals(ShrineSound.Kind.WIN, ShrineSound.forCutIn("WIN_FINAL"))
        assertEquals(ShrineSound.Kind.LOSE, ShrineSound.forCutIn("LOSE_FINAL"))
        assertNull(ShrineSound.forCutIn("WIN_ADVANTAGE")); assertNull(ShrineSound.forCutIn("LOSE_ADVANTAGE"))
    }
}

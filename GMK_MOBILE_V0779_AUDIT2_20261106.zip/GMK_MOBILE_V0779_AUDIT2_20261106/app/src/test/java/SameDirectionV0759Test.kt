import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** v0.7.59: the 5-minute model's pick is scored p - 0.03 x open trades in the same direction (all five pairs are yen crosses). */
class SameDirectionV0759Test {
    @Before fun reset() = EvidencePolicy.resetState()
    private val weekday get() = EvidenceFixture.slots.filter { !it.weekend }

    @Test fun constantsAndRates() {
        assertEquals("V0771_CRYPTO9", EvidencePolicy.VERSION);   // v0.7.71 (the policy tag is unchanged)
        assertEquals("GMK_V0740_V0759_EVIDENCE", EvidencePolicy.POLICY_TAG)
        assertEquals(setOf("0.7.59"), RankStatistics.CURRENT_RANK_VERSIONS)
        assertEquals(0.03, RankLadder.SAME_DIRECTION_PENALTY, 0.0)
        assertEquals(0.5309, RankLadder.rate(true, false, "C")!!.year, 0.0); assertEquals(0.5089, RankLadder.rate(true, false, "D")!!.year, 0.0)   // v0.7.71
        assertEquals(0.5196, RankLadder.rate(false, false, "C")!!.year, 0.0); assertEquals(0.5112, RankLadder.rate(false, false, "D")!!.year, 0.0)
        assertTrue(EntryMode.WEEKDAY_60.summary.contains("53.4%"))
    }

    @Test fun noOpenTradesKeepTheV0758Choice() {
        var n = 0
        for (s in weekday) {
            val plain = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry, fiveMinute = true) ?: continue
            val zero = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry, fiveMinute = true, openByDirection = mapOf("HIGH" to 0, "LOW" to 0))!!
            assertEquals(plain.instrument, zero.instrument); assertEquals(plain.direction, zero.direction); assertEquals(plain.probability, zero.probability, 0.0)
            // the 3-minute model is never penalized
            val three = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry)
            val threeOpen = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry, openByDirection = mapOf("HIGH" to 9, "LOW" to 9))
            assertEquals(three?.instrument, threeOpen?.instrument); assertEquals(three?.direction, threeOpen?.direction)
            n++
        }
        assertTrue("checked $n", n >= 12)
    }

    @Test fun openTradesInOneDirectionMoveThePickOnlyAcrossDirections() {
        var flipped = 0; var n = 0
        for (s in weekday) {
            val base = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry, fiveMinute = true) ?: continue
            val other = if (base.direction == "HIGH") "LOW" else "HIGH"
            var switched = false
            for (k in 0..12) {
                val c = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry, fiveMinute = true, openByDirection = mapOf(base.direction to k))!!
                if (c.direction == base.direction) {
                    assertFalse("once switched it stays switched", switched)
                    // the same penalty applies to every pair of that direction, so the best of that direction is unchanged
                    assertEquals(base.instrument, c.instrument); assertEquals(base.probability, c.probability, 0.0)
                } else {
                    assertEquals(other, c.direction); assertTrue(c.probability <= base.probability); switched = true
                    // exact rule: the switch happens at the first k where the best other-direction p exceeds p - 0.03 k
                    assertTrue(c.probability > base.probability - RankLadder.SAME_DIRECTION_PENALTY * k - 1e-12)
                }
            }
            if (switched) flipped++; n++
        }
        assertTrue("checked $n flipped $flipped", n >= 12 && flipped >= n / 2)
    }

    @Test fun policyRecordsOpenTradesAndStillFollowsTheHourRule() {
        var checked = 0
        for (s in weekday) {
            EvidencePolicy.resetState()
            val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.WEEKDAY_60, 2, 7, 0)
            val top = out.top1!!
            if (top.grade == "I") continue
            val note = top.reasons[1]
            assertTrue(note, " OPEN=H7/L0" in note)
            if (" FIVE=" !in note || " CAUTION" in note) continue
            val m = Regex(" FIVE=([A-Z]+) (HIGH|LOW) p5=([0-9.]+) cut=(\\S+) ").find(note)!!
            assertEquals(note, m.groupValues[1], top.instrument); assertEquals(note, m.groupValues[2], top.direction)
            assertEquals(note, if (m.groupValues[3].toDouble() >= m.groupValues[4].toDouble() - 1e-4) "C" else "D", top.grade)
            assertTrue(top.assessment!!.correctionLabel!!.contains("保有中 HIGH 7 / LOW 0"))
            checked++
        }
        assertTrue("checked $checked", checked >= 12)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.79 second full audit: the domain fixes (the screen, service and text fixes are pinned by tools/audit_v0779.py). */
class AuditFixV0779Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun ref(s: String): Instant? = try { ZonedDateTime.parse(s).toInstant() } catch (e: RuntimeException) { null }
    private fun row(id: Int, at: String, status: String, judge: String = ZonedDateTime.parse(at).plusMinutes(5).toString(), grade: String = "C") =
        HistoryRow(id.toLong(), "s$id", "AUTO", at, "USDJPY", "HIGH", grade, "ENTRY", entryTimeJst = at, judgeTimeJst = judge,
            entryRate = 150.0, judgeRate = 150.1, resultStatus = status, policyVersion = EvidencePolicy.POLICY_TAG)

    @Test fun fastTimeReadsTheStoredTimesLikeZonedDateTimeParse() {
        val cases = listOf("2026-11-06T10:05:00+09:00", "2026-11-06T10:10+09:00", "2026-11-06T10:05:12.345+09:00", "2026-11-06T01:05Z",
            "2026-11-06T10:05:12.345678901+09:00", "2026-11-06T10:05:12.3456789012+09:00", "2026-02-29T10:00+09:00", "2024-02-29T10:00+09:00",
            "2026-11-06T10:05:00+09:00[Asia/Tokyo]", "2026-11-06t10:05+09:00", "2026-11-06T24:00+09:00", "2026-11-06T10:60+09:00",
            "2026-11-06T10:05:60+09:00", "2026-11-06T10:05+18:00", "2026-11-06T10:05+18:01", "2026-11-06T10:05-00:00", "2026-11-06T10:05+0900",
            "2026-11-06T10:05:00.+09:00", "2026-11-06T10:05.5+09:00", "", "x", "2026-13-01T00:00Z", "2026-04-31T00:00Z", "1899-12-31T23:59Z",
            "2999-12-31T23:59:59.999999999-18:00", "2026-11-06T10:05:00+09:00 ", "2026-11-06T10:05:00z", "+12026-11-06T10:05Z")
        for (s in cases) {
            assertEquals(s, ref(s), FastTime.instant(s))
            assertEquals(s, ref(s)?.toEpochMilli(), FastTime.epochMs(s))
            assertEquals(s, ref(s)?.atZone(jst), FastTime.jst(s))
        }
        assertNotNull(FastTime.fast("2026-11-06T10:05:00+09:00")); assertNull(FastTime.fast("2026-11-06T10:05:00+09:00[Asia/Tokyo]"))
        val r = java.util.Random(79)
        repeat(50_000) {
            var s = String.format("%04d-%02d-%02dT%02d:%02d", 1890 + r.nextInt(1200), r.nextInt(14), r.nextInt(33), r.nextInt(26), r.nextInt(62))
            when (r.nextInt(3)) { 1 -> s += String.format(":%02d", r.nextInt(62)); 2 -> s += String.format(":%02d.%0${1 + r.nextInt(10)}d", r.nextInt(62), r.nextInt(1000)) }
            s += when (r.nextInt(4)) { 0 -> "Z"; 1 -> "+09:00"; 2 -> String.format("%s%02d:%02d", if (r.nextBoolean()) "+" else "-", r.nextInt(20), r.nextInt(61)); else -> "+09:00[Asia/Tokyo]" }
            assertEquals(s, ref(s), FastTime.instant(s))
        }
    }

    @Test fun statisticsOrderAndMinutesAcrossTimeFormats() {
        val rows = listOf(
            row(4, "2026-11-06T10:15:00+09:00", "LOSE"),
            row(3, "2026-11-06T10:10+09:00", "WIN", judge = "2026-11-06T10:15:00+09:00[Asia/Tokyo]"),   // the region form goes to the parser
            row(2, "2026-11-06T01:05:00Z", "LOSE"),                                                       // 10:05 JST written in UTC
            row(1, "2026-11-06T10:00:00.000+09:00", "LOSE"),
            row(5, "not a time", "LOSE", judge = "x"))                                                                 // unreadable: not counted
        val all = historyCombinedStatistics(rows)
        assertEquals(1, all.wins); assertEquals(3, all.losses)
        assertEquals(1, all.currentLossStreak); assertEquals(2, all.maxConsecutiveLosses)                 // L L W L by time
        val byMinutes = historyStatistics(rows)
        assertEquals(4, byMinutes.getValue(5).resolved()); assertEquals(1, byMinutes.getValue(0).resolved())
        assertEquals(true, RankStatistics.isWeekend("2026-11-06T16:00:00Z"))                              // Saturday 01:00 JST
        assertEquals(false, RankStatistics.isWeekend("2026-11-06T10:00+09:00")); assertNull(RankStatistics.isWeekend("x"))
        assertEquals(1, ShrineBoard.lossStreak(rows))
    }

    @Test fun hudLivesFromTheBoardsStreak() {
        val today = LocalDate.parse("2026-11-06")
        val rows = listOf(row(2, "2026-11-06T10:05:00+09:00", "LOSE"), row(1, "2026-11-06T10:00:00+09:00", "LOSE"))
        assertEquals(ShrineBoard.LIVES - 2, ShrineHud.of(rows, today).lives)
        assertEquals(ShrineHud.of(rows, today), ShrineHud.of(rows, today, ShrineBoard.lossStreak(rows)))   // the screen passes the board's streak
        assertEquals(ShrineBoard.LIVES - 4, ShrineHud.of(rows, today, 4).lives)
    }

    @Test fun historyListKeysAreUniqueAndStay() {
        val a = row(1, "2026-11-06T10:00:00+09:00", "WAIT_JUDGE"); val b = row(2, "2026-11-06T10:05:00+09:00", "WAIT_ENTRY")
        val keys = HistoryListKeys.of(listOf(b, a, a, a)).map { it.first }
        assertEquals(4, keys.toSet().size)
        assertEquals(HistoryArchivePlan.key(a), keys[1]); assertTrue(keys[2].startsWith(HistoryArchivePlan.key(a)))
        // a result filled in keeps the key; a new row at the top leaves the others' keys as they were
        val settled = a.copy(resultStatus = "WIN", judgeRate = 150.2)
        val c = row(3, "2026-11-06T10:10:00+09:00", "WAIT_ENTRY")
        assertEquals(HistoryListKeys.of(listOf(b, a)).map { it.first }, HistoryListKeys.of(listOf(c, b, settled)).drop(1).map { it.first })
    }

    @Test fun cutInTimesReadAsBefore() {
        // the cut-in policy reads the settled time of each recent row four times a second; the stored forms give the same instants
        for (s in listOf("2026-11-06T10:05:03.512+09:00", "2026-11-06T10:05:03.512+09:00[Asia/Tokyo]", "2026-11-06T01:05:03Z", ""))
            assertEquals(s, ref(s)?.toEpochMilli(), FastTime.epochMs(s))
    }
}

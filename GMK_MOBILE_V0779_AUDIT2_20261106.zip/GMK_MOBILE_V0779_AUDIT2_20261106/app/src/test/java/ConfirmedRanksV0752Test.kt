import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** v0.7.52: weekday B = strong model trade confirmed by the last-minute move. */
class ConfirmedRanksV0752Test {
    @Before fun reset() = EvidencePolicy.resetState()

    @Test fun confirmationRulesFollowTheResearchFlags() {
        // FX: the trade fades a spike of at least 2.5 sigma
        assertTrue(RankLadder.confirms("USDJPY", -1, 2.5)); assertTrue(RankLadder.confirms("EURJPY", 1, -3.1))
        assertFalse(RankLadder.confirms("USDJPY", 1, 2.5)); assertFalse(RankLadder.confirms("GBPJPY", -1, 2.49))
        // BTC: the trade follows a 1..3 sigma move
        assertTrue(RankLadder.confirms("BTCJPY", 1, 1.0)); assertTrue(RankLadder.confirms("BTCJPY", -1, -2.99))
        assertFalse(RankLadder.confirms("BTCJPY", 1, 3.0)); assertFalse(RankLadder.confirms("BTCJPY", 1, 0.99)); assertFalse(RankLadder.confirms("BTCJPY", -1, 1.5))
    }

    @Test fun realSlotsMarkConfirmedTradesExactly() {
        var confirmed = 0; var checked = 0
        for (s in EvidenceFixture.slots) {
            EvidencePolicy.resetState()
            val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes())
            val top = out.top1!!; val note = top.reasons[1]
            if (" RULE=" in note || " CAUTION" in note) continue
            // v0.7.57: CONFIRMED describes the 3-minute model's choice (the top trade may be the 5-minute model's FX trade)
            val ch = s.best.getValue("fresh")
            val x = EvidenceFeatures.instrument(ch.instrument, s.candles().getValue(ch.instrument), s.boundary, s.cands.first { it.instrument == ch.instrument }.live)!!
            val dir = if (ch.direction == "HIGH") 1 else -1
            val want = !s.weekend && RankLadder.confirms(ch.instrument, dir, x.f1)
            assertEquals("slot ${s.boundary} ${ch.instrument} f1=${x.f1}", want, " CONFIRMED" in note)
            if (want) confirmed++
            if (top.grade == "B" && !s.weekend) { assertTrue(" CONFIRMED" in note); assertTrue(top.assessment!!.correctionLabel!!.contains("で一致")); assertEquals(ch.instrument, top.instrument) }
            checked++
        }
        assertTrue(checked >= 20)
        // the fixture year contains confirmed trades; synthetic check that a confirmed strong trade becomes B
        assertEquals("B", RankLadder.modelGrade("S", false, true))
        assertTrue("confirmed=$confirmed of $checked", confirmed in 1 until checked)
    }

    @Test fun ladderRatesAreOrderedAndBackupModelHasNoConfirmedTier() {
        val wd = listOf("S", "A", "B", "C", "D").map { EvidencePolicy.gradeRate(true, false, it)!! }   // v0.7.57: B/C/D judged at 5 minutes
        assertTrue(wd.zipWithNext().all { (a, b) -> a > b })
        assertEquals(0.5756, EvidencePolicy.gradeRate(true, false, "B")!!, 1e-12)
        assertNull(EvidencePolicy.gradeRate(false, false, "B"))
        assertNotNull(EvidencePolicy.gradeRate(false, false, "D"))
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.53: more time-of-day rules (US data 8:30 New York, UK data 9:30 London, 9:55 Bollinger) and S by fade confluence. */
class MoreRulesV0753Test {
    @Before fun reset() = EvidencePolicy.resetState()
    private val jst = ZoneId.of("Asia/Tokyo")

    private class Slot(val boundary: Long) {
        val bars = linkedMapOf<String, MutableList<Candle>>()
        val live = linkedMapOf<String, Double>()
        val expected = linkedMapOf<String, DoubleArray>()
        var match: List<String>? = null
    }
    private val slots: List<Slot> by lazy {
        val out = mutableListOf<Slot>(); var cur: Slot? = null
        GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0753_event_parity.txt.gz")!!).bufferedReader().useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val p = line.split('|')
                when (p[0]) {
                    "SLOT" -> cur = Slot(p[1].toLong())
                    "BAR" -> cur!!.bars.getOrPut(p[1]) { mutableListOf() } += Candle(p[2].toLong(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble(), p[7].toDouble())
                    "LIVE" -> cur!!.live[p[1]] = p[2].toDouble()
                    "EXPV" -> cur!!.expected[p[1]] = p.drop(2).map { it.toDouble() }.toDoubleArray()
                    "EXPM" -> cur!!.match = p.drop(1)
                    "END" -> { out += cur!!; cur = null }
                    else -> error("fixture line ${p[0]}")
                }
            }
        }
        out
    }
    private fun entry(b: Long) = ZonedDateTime.ofInstant(Instant.ofEpochSecond(b), jst)

    @Test fun ruleTradesGradesAndConfluenceMatchPythonOnRealSlots() {
        var matched = 0; var none = 0; var s = 0
        val ids = mutableSetOf<String>()
        assertTrue(slots.size >= 60)
        for (sl in slots) {
            val e = entry(sl.boundary)
            for ((inst, want) in sl.expected) {
                val w = EvidenceFeatures.window(sl.bars.getValue(inst), sl.boundary)!!
                val px = sl.live.getValue(inst)
                val x = EvidenceFeatures.instrument(inst, sl.bars.getValue(inst), sl.boundary, px)!!
                val f = EventRules.Feature.values()
                val got = listOf(EventRules.value(f[0], x, w, px), EventRules.value(f[2], x, w, px), EventRules.value(f[3], x, w, px),
                    EventRules.value(f[1], x, w, px), EventRules.value(f[4], x, w, px))   // fixture order: pos60L r5 r15 bbzL f1
                for (k in 0 until 5) assertEquals("value $k $inst ${sl.boundary}", want[k], got[k], 1e-9)
            }
            val got = EventRules.match(e, sl.bars, sl.live.mapValues { it.value as Double? }, EventRules.ALL_IDS)
            val m = sl.match!!
            if (m[0] == "NONE") { none++; assertNull("slot ${sl.boundary} $e", got) }
            else {
                matched++; ids += m[0]
                assertNotNull("slot ${sl.boundary} $e", got)
                assertEquals(m[0], got!!.rule.id); assertEquals(m[1], got.instrument); assertEquals(m[2], got.direction)
                assertEquals(m[3].toDouble(), got.value, 1e-9)
                assertEquals("confluence ${sl.boundary}", m[4].toInt(), got.confluence)
                assertEquals(m[5], got.grade)
                if (got.grade == "S") s++
            }
        }
        assertEquals(EventRules.RULES.map { it.id }.toSet(), ids)
        assertTrue("matched=$matched none=$none S=$s", matched >= 50 && none >= 10 && s >= 15 && s < matched)
    }

    @Test fun newRulesFollowTheNewYorkAndLondonClocks() {
        fun at(mo: Int, d: Int, h: Int, m: Int) = ZonedDateTime.of(2026, mo, d, h, m, 0, 0, jst)
        // New York 8:30: 21:30 JST until US summer time ends on 1 Nov, 22:30 JST after
        assertEquals(listOf("US0830_BBZ", "US0830_F1"), EventRules.rulesAt(at(10, 29, 21, 30), EventRules.ALL_IDS).map { it.id })
        assertTrue(EventRules.rulesAt(at(10, 29, 22, 30), EventRules.ALL_IDS).isEmpty())
        assertEquals(listOf("US0830_BBZ", "US0830_F1"), EventRules.rulesAt(at(11, 2, 22, 30), EventRules.ALL_IDS).map { it.id })
        assertTrue(EventRules.rulesAt(at(11, 2, 21, 30), EventRules.ALL_IDS).isEmpty())
        // London 9:30: 17:30 JST until 25 Oct, 18:30 JST after
        assertEquals(listOf("UK0930_F1"), EventRules.rulesAt(at(10, 23, 17, 30), EventRules.ALL_IDS).map { it.id })
        assertTrue(EventRules.rulesAt(at(10, 26, 17, 30), EventRules.ALL_IDS).isEmpty())
        assertEquals(listOf("UK0930_F1"), EventRules.rulesAt(at(10, 26, 18, 30), EventRules.ALL_IDS).map { it.id })
        // 9:55 has two rules in priority order; weekends have none
        assertEquals(listOf("FIX955_POS", "FIX955_BBZ"), EventRules.rulesAt(at(10, 27, 9, 55), EventRules.ALL_IDS).map { it.id })
        assertTrue(EventRules.rulesAt(at(10, 31, 21, 30), EventRules.ALL_IDS).isEmpty())
        assertEquals(8, EventRules.RULES.size)
        assertEquals(listOf(0.8, 1.5, 1.0, 1.0, 1.0), EventRules.Feature.values().map { it.threshold })
    }

    /** 61 one-minute candles ending at [b]; flat (tiny zig-zag) until [riseFrom], then rising [step] per minute. */
    private fun window(b: Long, base: Double, riseFrom: Int, step: Double): List<Candle> = (0 until 61).map { i ->
        val t = (b - 3720L + i * 60L) * 1000L
        val c = base + (if (i % 2 == 0) 0.01 else -0.01) + (if (i >= riseFrom) (i - riseFrom + 1) * step else 0.0)
        val o = if (i == 0) c else base + (if (i % 2 == 1) 0.01 else -0.01) + (if (i - 1 >= riseFrom) (i - riseFrom) * step else 0.0)
        Candle(t, o, maxOf(o, c) + 0.002, minOf(o, c) - 0.002, c, 0.0)
    }

    @Test fun confluenceDecidesBetweenSAndA() {
        val b = ZonedDateTime.of(2026, 10, 29, 21, 30, 0, 0, jst).toEpochSecond()       // New York 8:30 (summer time)
        val names = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY")
        // a steady 15-minute rise into the release: every fade signal points up -> 4 of 4 -> S, trade LOW
        val trend = names.associateWith { window(b, 150.0, 45, 0.04) }
        val tLive = trend.mapValues { (_, w) -> (w.last().close + 0.03) as Double? }
        val s = EventRules.match(entry(b), trend, tLive, EventRules.ALL_IDS)!!
        assertEquals("US0830_BBZ", s.rule.id); assertEquals("LOW", s.direction)
        val w = EvidenceFeatures.window(trend.getValue(s.instrument), b)!!
        val x = EvidenceFeatures.instrument(s.instrument, trend.getValue(s.instrument), b, tLive.getValue(s.instrument)!!)!!
        val others = EventRules.Feature.values().filter { it != EventRules.Feature.BBZL }.map { EventRules.value(it, x, w, tLive.getValue(s.instrument)!!) }
        assertTrue("others=$others", others.zip(EventRules.Feature.values().filter { it != EventRules.Feature.BBZL }).all { (v, f) -> v >= f.threshold })
        assertEquals(4, s.confluence); assertEquals("S", s.grade)
        // a flat market with one jump in the last minute: only bbzL / f1 / pos60L -> the BBZ rule has 2 others -> A
        val flat = names.associateWith { window(b, 150.0, 99, 0.0) }
        val fLive = flat.mapValues { (_, w) -> (w.last().close + 0.08) as Double? }
        val a = EventRules.match(entry(b), flat, fLive, EventRules.ALL_IDS)!!
        assertEquals("US0830_BBZ", a.rule.id); assertEquals(2, a.confluence); assertEquals("A", a.grade)
        // a falling market is the mirror image: HIGH, S
        val down = names.associateWith { window(b, 150.0, 45, -0.04) }
        val dLive = down.mapValues { (_, w) -> (w.last().close - 0.03) as Double? }
        val d = EventRules.match(entry(b), down, dLive, EventRules.ALL_IDS)!!
        assertEquals("HIGH", d.direction); assertEquals("S", d.grade)
        // signals on the other side never count: a rise that the live price has already given back past the 20-minute mean
        val back = trend.mapValues { (_, w) -> (w.last().close - 1.5) as Double? }
        val r = EventRules.match(entry(b), trend, back, EventRules.ALL_IDS)
        assertTrue(r == null || r.confluence < 4)
    }

    private fun policyOn(sl: Slot): ScanCandidate {
        val b = sl.boundary; val e = entry(b)
        val btc = EvidenceFixture.slots.first { !it.weekend }
        val shift = (b - btc.boundary) * 1000L
        val bars = LinkedHashMap<String, List<Candle>>(sl.bars)
        bars["BTCJPY"] = btc.bars.getValue("BTCJPY").map { it.copy(timeEpochMs = it.timeEpochMs + shift) }
        val quotes = sl.live.mapValues { EvidencePolicy.LiveQuote(it.value, b * 1000L - 10_000L) } +
            ("BTCJPY" to EvidencePolicy.LiveQuote(btc.cands.first { it.instrument == "BTCJPY" }.live, b * 1000L - 10_000L))
        val order = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
        val native = ScanResult(scanId = "rule-$b", atJst = e.minusSeconds(10).toOffsetDateTime().toString(), entryTimeJst = e.toOffsetDateTime().toString(),
            judgeTimeJst = e.plusMinutes(3).toOffsetDateTime().toString(),
            candidates = order.mapIndexed { i, inst -> ScanCandidate(i + 1, inst, inst, "HIGH", "C", 0.5, "ENTRY", 0.0, "RANGE", 0.5, emptyList()) }, source = "AUTO")
        EvidencePolicy.resetState()
        return EvidencePolicy.apply(native, native, bars, quotes).top1!!
    }

    @Test fun policyGradesRuleTradesSOrAWithLabelsAndRates() {
        // v0.7.58: only the 3 rules that held on 2023-24 are traded; the retired ones (US 8:30 BBZ, UK 9:30 ...) are model minutes
        val active = slots.filter { it.match!![0] in EventRules.ACTIVE_IDS }
        assertTrue(active.isNotEmpty())
        for (sl in slots.filter { it.match!![0] != "NONE" && it.match!![0] !in EventRules.ACTIVE_IDS }) {
            val n = policyOn(sl).reasons[1]; val id = Regex(" RULE=([A-Z0-9_]+) ").find(n)?.groupValues?.get(1)
            assertTrue(n, id == null || id in EventRules.ACTIVE_IDS)
        }
        for (sl in active) {
            val m = sl.match!!
            val top = policyOn(sl)
            val note = top.reasons[1]; val label = top.assessment!!.correctionLabel!!.removePrefix("【3分判定】").removePrefix("【5分判定】")
            assertEquals(m[5], top.grade); assertEquals("ENTRY", top.decision); assertEquals(m[1], top.instrument); assertEquals(m[2], top.direction)
            assertTrue(note, " RULE=${m[0]} ${m[1]} " in note && " c=${m[4]} " in note && EvidencePolicy.VERSION in note)
            assertTrue(label, label.startsWith("時間帯ルール ${m[5]}（") && "ほかのサイン ${m[4]}/4 も同じ向き" in label && "このルール" in label)
            assertEquals(RankLadder.rate(true, false, m[5])!!.year, top.probability!!, 1e-12)
            assertEquals(top.grade, top.assessment!!.chosenAction.operationalGrade)
        }
    }

    @Test fun ladderRatesForV0753() {
        val wd = listOf("S", "A", "B", "C", "D").map { EvidencePolicy.gradeRate(true, false, it)!! }   // v0.7.57: FX only, B/C/D at 5 minutes
        assertTrue(wd.zipWithNext().all { (a, b) -> a > b })
        assertEquals(listOf(0.8000, 0.5894, 0.5756), wd.take(3))   // v0.7.58: the 3 kept rules
        assertEquals(0.8000, EvidencePolicy.gradeRate(false, false, "S")!!, 0.0); assertEquals(0.5894, EvidencePolicy.gradeRate(false, false, "A")!!, 0.0)
        assertEquals(1.0, RankLadder.rate(true, false, "S")!!.october!!, 0.0)
        // version constants are checked by the current version's test (LossPatternsV0754Test)
        assertEquals(RankStatistics.CURRENT_RANK_VERSIONS, setOf(RankStatistics.evidenceVersion(EvidencePolicy.POLICY_TAG)))
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.67 cleanup, updated in v0.7.70: the countdown says what the AUTO does - every 5 minutes on weekdays and weekends. */
class CleanupV0767Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun t(d: Int, h: Int, m: Int, s: Int) = ZonedDateTime.of(2026, 11, d, h, m, s, 0, jst)

    @Test fun weekdayCountsDownToTheNextFiveMinuteSlot() {
        val now = t(4, 17, 51, 20)                                    // Wednesday 17:51:20 -> next scan 17:54:50 (entry 17:55)
        assertEquals(210, AutoClock.nextAutoScanSeconds(now))
        assertEquals("平日: 5分ごとにスキャン（S/Aは3分判定・B/Cは5分判定）", AutoClock.scheduleText(now))
        assertEquals(0, AutoClock.nextAutoScanSeconds(t(4, 17, 54, 50).plusNanos(400_000_000)))
        assertEquals(10 * 3600 + 4 * 60 + 50, AutoClock.nextAutoScanSeconds(t(4, 22, 55, 0)))   // next: 09:00 the next weekday
        // the 3-minute rule minutes are still 5-minute AUTO slots: 9:55 (fixing) and NY 8:30 = 22:30 JST in winter
        assertEquals(EventRules.ACTIVE_IDS.filter { it.startsWith("FIX955") }.toSet(), EventRules.rulesAt(t(4, 9, 55, 0)).map { it.id }.toSet())
        assertEquals(listOf("US0830_F1"), EventRules.rulesAt(t(4, 22, 30, 0)).map { it.id })
        assertTrue(EventRules.rulesAt(t(3, 9, 55, 0)).isEmpty())                               // 11/3 bank holiday: no fixing
    }

    @Test fun weekendCountsDownFiveMinutes() {
        val sat = t(7, 10, 1, 0)                                      // Saturday: 5-minute slots, 3-minute judging
        assertEquals(3 * 60 + 50, AutoClock.nextAutoScanSeconds(sat))
        assertEquals("土日: 5分ごとにスキャン・3分判定", AutoClock.scheduleText(sat))
        assertEquals("土日: 5分ごとにスキャン・3分判定", AutoClock.scheduleText(t(6, 22, 58, 0)))   // Friday night -> Saturday 09:00
    }
}

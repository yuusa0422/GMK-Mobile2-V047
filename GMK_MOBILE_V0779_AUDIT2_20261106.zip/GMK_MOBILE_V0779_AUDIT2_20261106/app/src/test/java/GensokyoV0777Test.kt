import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZonedDateTime

/**
 * v0.7.77 幻想郷 extras (display only): the hour difficulty, the running trades with 優勢 / 劣勢 (a draw loses), the 称号 from the history,
 * today's 文々。新聞 and the losing-streak odds.
 */
class GensokyoV0777Test {
    private fun row(id: Int, at: String, status: String, grade: String = "C", inst: String = "USDJPY", dir: String = "HIGH", entry: Double? = 150.0,
                    judge: Double? = 150.1, minutes: Long = 5, sub: SubGrade? = null, policy: String = EvidencePolicy.POLICY_TAG, decision: String = "ENTRY"): HistoryRow {
        val trace = CandidateActionTrace(inst, dir, "未記録", null, null, grade, decision, minutes.toInt())
        val a = CandidateAssessment("未記録", null, null, grade, decision, RuleSelectionStage.LEGACY_BASE, null, null, null, null, trace, trace, subGrade = sub)
        return HistoryRow(id.toLong(), "s$id", "AUTO", at, inst, dir, grade, decision, entryTimeJst = at,
            judgeTimeJst = ZonedDateTime.parse(at).plusMinutes(minutes).toString(), entryRate = entry, judgeRate = judge, resultStatus = status,
            policyVersion = policy, assessment = a)
    }
    private fun at(day: Int, h: Int, m: Int) = String.format("2026-11-%02dT%02d:%02d:00+09:00", day, h, m)

    @Test fun hourDifficulty() {
        assertEquals("Lunatic", Difficulty.of(ZonedDateTime.parse("2026-11-06T13:10:00+09:00"))!!.name)       // weekday 13h 51.5%
        assertEquals("Hard", Difficulty.of(ZonedDateTime.parse("2026-11-06T09:10:00+09:00"))!!.name)
        assertEquals("Normal", Difficulty.of(ZonedDateTime.parse("2026-11-06T11:10:00+09:00"))!!.name)
        assertEquals("Easy", Difficulty.of(ZonedDateTime.parse("2026-11-06T19:10:00+09:00"))!!.name)
        assertEquals("Easy", Difficulty.of(ZonedDateTime.parse("2026-11-07T19:10:00+09:00"))!!.name)       // Saturday
        assertTrue(Difficulty.of(ZonedDateTime.parse("2026-11-07T19:10:00+09:00"))!!.weekend)
        assertNull(Difficulty.of(ZonedDateTime.parse("2026-11-06T23:10:00+09:00")))
        assertEquals(14, Difficulty.WEEKDAY.size); assertEquals(14, Difficulty.WEEKEND.size)
        assertEquals("難易度 Lunatic（13時台の検証 51.5%）", Difficulty.text(Difficulty.of(ZonedDateTime.parse("2026-11-06T13:10:00+09:00"))!!))
    }

    @Test fun runningTradesLeadByTheLivePrice() {
        val now = ZonedDateTime.parse("2026-11-06T10:02:00+09:00").toInstant().toEpochMilli()
        val rows = listOf(
            row(1, at(6, 10, 0), "WAIT_JUDGE", inst = "USDJPY", dir = "HIGH"),                      // 3:00 left, price up -> 優勢
            row(2, at(6, 10, 1), "WAIT_JUDGE", inst = "EURJPY", dir = "LOW", entry = 160.0),        // 4:00 left, price up -> 劣勢
            row(3, at(6, 10, 0), "WAIT_JUDGE", inst = "GBPJPY", entry = 190.0),                    // equal -> 劣勢 (a draw loses)
            row(4, at(6, 9, 30), "WAIT_JUDGE", inst = "AUDJPY"),                                    // judged long ago: being fetched
            row(5, at(6, 10, 0), "WIN", inst = "NZDJPY"),                                           // settled
            row(6, at(6, 10, 0), "WAIT_JUDGE", inst = "BTCUSD", decision = "SKIP"))                 // a skip is not a trade
        val t = RunningTrades.of(rows, mapOf("USDJPY" to 150.2, "EURJPY" to 160.1, "GBPJPY" to 190.0), now)
        assertEquals(listOf("USDJPY", "GBPJPY", "EURJPY"), t.map { it.row.instrument })
        assertEquals(listOf(true, false, false), t.map { it.leading })
        assertEquals(180L, t[0].secondsLeft); assertEquals(0.4f, t[0].progress, 1e-6f); assertEquals(0.2, t[0].diff!!, 1e-9)
        assertEquals("3:00", RunningTrades.clock(180)); assertEquals("0:07", RunningTrades.clock(7))
        assertNull(RunningTrades.of(rows.take(1), emptyMap(), now).single().leading)            // no live price yet
    }

    @Test fun achievementsFromTheHistory() {
        val rows = ArrayList<HistoryRow>(); var id = 0
        // 3 losses at 10h (one a draw) then 10 C1 wins, all in the 11h hour
        for (k in 0 until 3) rows += row(++id, at(2, 10, k * 5), "LOSE", judge = if (k == 0) 150.0 else 149.9)
        for (k in 0 until 10) rows += row(++id, at(2, 11, k * 5), "WIN", sub = SubGrade("C1", SubGrades.WEEKDAY, 0.05, 0.56))
        val got = Achievements.of(rows).associateBy { it.def.id }
        for (id_ in listOf("first", "win5", "win10", "comeback", "c1", "nomiss")) assertTrue(id_, got.getValue(id_).unlocked)
        for (id_ in listOf("saisen", "spell", "graze", "extra", "danmaku", "win100")) assertFalse(id_, got.getValue(id_).unlocked)
        assertEquals(at(2, 11, 0), got.getValue("first").atJst); assertEquals(at(2, 11, 10), got.getValue("comeback").atJst)
        assertEquals(Achievements.ALL.size, Achievements.of(emptyList()).size); assertTrue(Achievements.of(emptyList()).none { it.unlocked })
        // +10 stakes in a day: 12 wins = +10.8
        val day = (0 until 12).map { row(100 + it, at(3, 11 + it / 12, it * 5 % 60), "WIN") }
        assertTrue(Achievements.of(day).single { it.def.id == "saisen" }.unlocked)
        // 1-minute rows count only for the 1-minute title
        val m1 = (0 until 100).map { row(300 + it, at(4, 12 + it / 60, it % 60), "WIN", policy = OneMinutePolicy.POLICY_TAG, minutes = 1) }
        val g1 = Achievements.of(m1).associateBy { it.def.id }
        assertTrue(g1.getValue("danmaku").unlocked); assertFalse(g1.getValue("first").unlocked)
    }

    @Test fun bunbunmaruReportsToday() {
        val today = LocalDate.parse("2026-11-06")
        assertEquals("本日はまだ取材中です", Bunbunmaru.today(emptyList(), today).headline)
        val rows = (0 until 6).map { row(it, at(6, 10, it * 5), if (it < 4) "WIN" else "LOSE", inst = if (it % 2 == 0) "USDJPY" else "EURJPY") } +
            row(50, at(5, 10, 0), "WIN")                                                          // yesterday
        val r = Bunbunmaru.today(rows, today)
        assertEquals("霊夢さん本日 4勝2敗（66.7%・+1.6口）", r.headline)
        assertTrue(r.lines.toString(), r.lines.any { it == "最長の連勝 4・最長の連敗 2" })
        assertTrue(r.lines.toString(), r.lines.any { it.startsWith("本日の当たりペア ") })
        // v0.7.78: 4勝2敗 (66.7%) is not a 苦戦 (only an hour below the 52.6% break-even is)
        assertFalse(r.lines.toString(), r.lines.any { it.startsWith("苦戦した時間") })
        assertTrue(r.comment.isNotBlank())
    }

    @Test fun losingStreakOdds() {
        assertEquals(listOf(3, 5, 7, 10), ShrineBoard.STREAK_ODDS.map { it.first })
        assertTrue(ShrineBoard.streakVerdict(0).isEmpty())
        assertTrue(ShrineBoard.streakVerdict(4).contains("1日に何度も"))
        assertTrue(ShrineBoard.streakVerdict(6).contains("1日に1回ほど"))
        assertTrue(ShrineBoard.streakVerdict(8).contains("数日に1回"))
        assertTrue(ShrineBoard.streakVerdict(10).contains("月に1回"))
    }
}

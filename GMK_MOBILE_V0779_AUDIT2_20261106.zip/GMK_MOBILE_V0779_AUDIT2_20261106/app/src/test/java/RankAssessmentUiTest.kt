import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import jp.gmk.mobile.HistoryScreen
import jp.gmk.mobile.domain.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.time.ZonedDateTime

/**
 * v0.7.74: the history screen (リプレイ帳) - the 3分 / 5分 result tiles of the current versions with 残機, older versions' grade tables
 * folded, and old-engine rows labelled as such (until v0.7.73 this class tested the retired engines' rule-grade labels on the TOP1).
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w360dp-h640dp")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class RankAssessmentUiTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    private fun row(id: Long, minutes: Long, status: String, policy: String, grade: String = "C"): HistoryRow {
        val entry = ZonedDateTime.parse("2026-11-05T10:00:00+09:00").plusMinutes(id * 5)
        return HistoryRow(id, "ui-$id", "AUTO", entry.minusSeconds(10).toString(), "USDJPY", "HIGH", grade, "ENTRY",
            entryTimeJst = entry.toString(), judgeTimeJst = entry.plusMinutes(minutes).toString(), entryRate = 150.0,
            judgeRate = if (status == "WIN") 150.1 else 149.9, resultStatus = status, policyVersion = policy)
    }

    private fun render(rows: List<HistoryRow>, fontScale: Float = 1f) {
        compose.setContent {
            val density = LocalDensity.current.density
            CompositionLocalProvider(LocalDensity provides Density(density, fontScale)) {
                MaterialTheme { Box(Modifier.size(360.dp, 640.dp)) { HistoryScreen(rows) {} } }
            }
        }
    }

    @Test fun threeAndFiveMinuteTilesAndLivesAreShown() {
        val p = "GMK_V0740_V0773_EVIDENCE"
        render(listOf(row(1, 3, "WIN", p, "A"), row(2, 5, "LOSE", p), row(3, 5, "LOSE", p)))
        compose.onNodeWithText("S・A・土日").assertIsDisplayed()       // the 3分判定 tile
        compose.onNodeWithText("B・C（平日）").assertIsDisplayed()     // the 5分判定 tile
        compose.onNodeWithText("1勝 0敗", substring = true).assertIsDisplayed()
        compose.onNodeWithText("0勝 2敗", substring = true).assertIsDisplayed()
        compose.onNodeWithText("残機 ★★★☆☆", substring = true).assertExists()
        saveScreenshot("history_tiles.png")
    }

    @Test fun olderVersionTablesAreFolded() {
        render(listOf(row(1, 5, "WIN", "GMK_V0740_V0773_EVIDENCE"), row(2, 5, "LOSE", "GMK_V0740_V0772_EVIDENCE")))
        compose.onNodeWithText("v0.7.73 平日", substring = true).assertExists()
        compose.onNodeWithText("v0.7.72 平日", substring = true).assertDoesNotExist()
        compose.onNodeWithText("前のバージョン", substring = true).assertExists().performClick()
        compose.onNodeWithText("v0.7.72 平日", substring = true).assertExists()
    }

    @Test fun oldEngineRowsAreLabelledAsOldVersions() {
        render(listOf(row(1, 3, "WIN", "GMK_V0736_DIRECT19")), 1.8f)
        compose.onNode(hasScrollToIndexAction()).performScrollToNode(hasText("旧バージョンの記録", substring = true))
        compose.onNodeWithText("旧バージョンの記録", substring = true).assertIsDisplayed()
        saveScreenshot("history_old_engine_large_text.png")
    }

    private fun saveScreenshot(name: String) {
        val root = java.io.File(System.getProperty("gmk.projectRoot"), "release_evidence/v0774/screenshots")
        root.mkdirs()
        lateinit var bitmap: android.graphics.Bitmap
        compose.runOnUiThread {
            val view = compose.activity.window.decorView
            bitmap = android.graphics.Bitmap.createBitmap(view.width, view.height, android.graphics.Bitmap.Config.ARGB_8888)
            view.draw(android.graphics.Canvas(bitmap))
        }
        java.io.File(root, name).outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
    }
}

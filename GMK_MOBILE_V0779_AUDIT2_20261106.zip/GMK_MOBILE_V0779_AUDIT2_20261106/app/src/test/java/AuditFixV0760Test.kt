import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.util.zip.GZIPInputStream

/** v0.7.60 audit fixes: the history pass for the hour rule / open trades, the hour rule against the Python research, notification default. */
class AuditFixV0760Test {
    private val tag = EvidencePolicy.POLICY_TAG
    private fun row(id: String, entry: String, judgeMin: Long, dir: String = "HIGH", decision: String = "ENTRY", policy: String = tag,
                    source: String = "AUTO", rank: Int = 1) =
        HistoryRow(id.hashCode().toLong(), id, source, entry, "USDJPY", dir, if (decision == "ENTRY") "C" else "D", decision,
            candidateRank = rank, entryTimeJst = entry, judgeTimeJst = java.time.ZonedDateTime.parse(entry).plusMinutes(judgeMin).toString(),
            entryRate = 150.0, policyVersion = policy)

    @Test fun liveStateCountsThisHourAndRunningTrades() {
        val now = "2026-11-02T10:31:00+09:00"
        val rows = listOf(
            row("a", "2026-11-02T10:30:00+09:00", 5),                     // this hour, running (judged 10:35)
            row("b", "2026-11-02T10:27:00+09:00", 5, "LOW"),              // this hour, running until 10:32
            row("c", "2026-11-02T10:26:00+09:00", 5),                     // this hour, judged 10:31 = not running any more
            row("d", "2026-11-02T10:29:00+09:00", 3, "LOW"),              // S/A 3 minutes, judged 10:32 -> running
            row("e", "2026-11-02T10:05:00+09:00", 5, source = "MANUAL"),  // manual entries count for the hour
            row("f", "2026-11-02T09:58:00+09:00", 5),                     // previous hour: not counted, not running
            row("g", "2026-11-02T10:20:00+09:00", 5, decision = "SKIP"),  // skip rows never count
            row("h", "2026-11-02T10:21:00+09:00", 5, policy = "GMK_V0740_V0758_EVIDENCE"), // an older policy
            row("i", "2026-11-02T10:22:00+09:00", 5, rank = 2),           // not the chosen trade
            row("j", "2026-11-02T10:31:00+09:00", 5),                     // the entry minute itself (a retry) is not before it
            row("k", "2026-11-01T10:30:00+09:00", 5),                     // another day
            row("l", "2026-11-02T01:30:00Z", 5))                         // 10:30 JST written in UTC: parsed, counted, running
        val s = LiveEntryState.of(rows, now, tag)
        assertEquals(6, s.hourEntries)          // a b c d e l
        assertEquals(2, s.openHigh)             // a l
        assertEquals(2, s.openLow)              // b d
        // across the hour: 11:02 sees 10:58 still running but not in this hour
        val t = LiveEntryState.of(listOf(row("x", "2026-11-02T10:58:00+09:00", 5), row("y", "2026-11-02T11:00:00+09:00", 5, "LOW")),
            "2026-11-02T11:02:00+09:00", tag)
        assertEquals(Triple(1, 1, 1), Triple(t.hourEntries, t.openHigh, t.openLow))   // v0.7.61: State also carries hourSlots
        assertEquals(LiveEntryState.State(0, 0, 0), LiveEntryState.of(rows, "bad", tag))
        LiveEntryState.of(emptyList(), now, tag).let { assertEquals(Triple(0, 0, 0), Triple(it.hourEntries, it.openHigh, it.openLow)) }
    }

    @Test fun liveStateMatchesTheFullScanOnALongHistory() {
        val rows = ArrayList<HistoryRow>()
        var t = java.time.ZonedDateTime.parse("2026-09-01T09:00:00+09:00")
        val rnd = java.util.Random(3)
        while (rows.size < 6000) {
            if (t.hour in 9..22) rows.add(row("r${rows.size}", t.toOffsetDateTime().toString(), if (rnd.nextInt(10) == 0) 3 else 5,
                if (rnd.nextBoolean()) "HIGH" else "LOW", if (rnd.nextInt(3) == 0) "SKIP" else "ENTRY"))
            t = t.plusMinutes(1L + rnd.nextInt(3))
        }
        rows.reverse()                                                    // newest first, as HistoryStore keeps it
        for (k in 0 until 40) {
            val e = java.time.ZonedDateTime.parse(rows[rnd.nextInt(rows.size)].entryTimeJst).plusMinutes(rnd.nextInt(4).toLong())
            val start = e.truncatedTo(java.time.temporal.ChronoUnit.HOURS)
            val sel = rows.filter { it.decision == "ENTRY" }.map { it to java.time.ZonedDateTime.parse(it.entryTimeJst) }
            val hour = sel.count { (_, x) -> !x.isBefore(start) && x.isBefore(e) }
            val open = sel.filter { (r, x) -> x.isBefore(e) && java.time.ZonedDateTime.parse(r.judgeTimeJst).isAfter(e) }
            val s = LiveEntryState.of(rows, e.toOffsetDateTime().toString(), tag)
            assertEquals(Triple(hour, open.count { it.first.direction == "HIGH" }, open.count { it.first.direction == "LOW" }), Triple(s.hourEntries, s.openHigh, s.openLow))
        }
    }

    @Test fun hourRuleMatchesTheResearchExactly() {
        // v0.7.66: the 5-minute AUTO rule (slots left) on the 5-minute tables (research_v0766/gen_slot5_v0766.py)
        val lines = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0771_hour_rule_parity.txt.gz")!!).bufferedReader().readLines()
        var cuts = 0; var hours = 0
        for (line in lines) {
            val f = line.split('|')
            if (f[0] == "cut") {
                val c = RankLadder.minuteCut(f[1] == "fresh", f[2].toInt(), f[3].toInt(), f[4].toInt()).cut; val want = f[5].replace("inf", "Infinity").toDouble()
                if (want.isInfinite()) assertEquals(line, want, c, 0.0) else assertEquals(line, want, c, 1e-12)
                cuts++
            } else {
                val fresh = f[1] == "fresh"; val h = f[2].toInt(); val p = f[4].split(',').map { it.toDouble() }
                val fixed = f[5].split(',').filter { it.isNotBlank() }.map { it.toInt() }.toSet()
                val want = f[6].split(',').filter { it.isNotBlank() }.map { it.toInt() }
                var cnt = 0; val got = ArrayList<Int>()
                for (m in 0 until 60 step 5) {
                    if (m in fixed) { cnt++; got.add(m); continue }
                    if (p[m / 5] >= RankLadder.minuteCut(fresh, h, m, cnt).cut) { cnt++; got.add(m) }
                }
                assertEquals(line.take(40), want, got)
                assertTrue(got.size >= RankLadder.hourQuota())
                hours++
            }
        }
        assertEquals(1960, cuts); assertEquals(168, hours)
    }

    @Test fun historyIdentityKeepsItsMeaning() {
        fun old(row: HistoryRow, result: ScanResult): Boolean {             // v0.7.59 sameAutoFrame
            if (!result.source.startsWith("AUTO") || row.source != result.source) return false
            if (row.entryTimeJst.isNotBlank() && result.entryTimeJst.isNotBlank()) return runCatching {
                java.time.ZonedDateTime.parse(row.entryTimeJst).toInstant() == java.time.ZonedDateTime.parse(result.entryTimeJst).toInstant()
            }.getOrDefault(row.entryTimeJst == result.entryTimeJst)
            return result.scanId.isNotBlank() && row.scanId == result.scanId
        }
        val times = listOf("2026-11-02T10:05+09:00", "2026-11-02T10:05:00+09:00", "2026-11-02T10:05:30+09:00", "2026-11-02T10:06+09:00",
            "2026-11-02T01:05Z", "2026-11-02T01:05:00Z", "2026-11-02T10:05:00.000+09:00", "2026-11-03T10:05+09:00", "bad", "bad+09:00", "", "2026-11-02T10:05+0900")
        var n = 0
        for (a in times) for (b in times) for (src in listOf("AUTO", "MANUAL", "AUTO_1M")) for (ids in listOf("x" to "x", "x" to "y", "" to "")) {
            val row = HistoryRow(1, ids.first, "AUTO", a, "USDJPY", "HIGH", "C", "ENTRY", entryTimeJst = a)
            val res = ScanResult(scanId = ids.second, atJst = "2026-11-02T10:04:50+09:00", entryTimeJst = b, judgeTimeJst = b, candidates = emptyList(), source = src)
            assertEquals("$a | $b | $src", old(row, res), HistoryIdentity.sameAutoFrame(row, res)); n++
        }
        assertEquals(12 * 12 * 3 * 3, n)
    }

    @Test fun notificationsAnnounceEveryEntryByDefaultButKeepAChoice() {
        assertEquals("C", SignalAlerts.DEFAULT_MIN_GRADE)
        assertEquals("C", SignalAlerts.normalizeMinGrade(null)); assertEquals("B", SignalAlerts.normalizeMinGrade("B"))
        assertEquals("A", SignalAlerts.normalizeMinGrade("A")); assertEquals("C", SignalAlerts.normalizeMinGrade("?"))
        assertTrue(SignalAlerts.shouldNotify("ENTRY", "C", tag, null)); assertFalse(SignalAlerts.shouldNotify("ENTRY", "C", tag, "B"))
        assertFalse(SignalAlerts.shouldNotify("SKIP", "D", tag, null))
    }
}

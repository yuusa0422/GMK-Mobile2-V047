"""App form of the runs indicator (port target for domain/RunRegime.kt): the last 240 completed 15-minute candles of each yen cross
(what the app's 15m chart fetch keeps), r15 = ln(close_i / close_{i-1}) only for bars 15 minutes apart, r60 = sum of four consecutive r15,
VR = var(r60) / (4 var(r15)) (sample variances), needs >= 100 r15 and >= 40 r60; yen value = mean of the pairs that have one (>= 3 of 5)."""
import numpy as np, pandas as pd, gzip, json, sys
PAIRS = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
SRC = {'USDJPY': 'hist/USDJPY_merged.csv.gz', **{s: f'hist/combined/{s}_1m.csv.gz' for s in PAIRS[1:]}}
def bars15(s):
    d = pd.read_csv(SRC[s], usecols=['epoch_ms', 'close']); d['t'] = d.epoch_ms // 1000; d = d.drop_duplicates('t').sort_values('t')
    d['q'] = d.t - d.t % 900; g = d.groupby('q').close.last()                       # close of the 15-minute bar opening at q
    return g.index.values.astype(np.int64), g.values.astype(float)
def vr_of(times, closes):
    if len(times) < 5: return None
    lc = np.log(closes); ok = np.diff(times) == 900; r = np.where(ok, np.diff(lc), np.nan)
    r15 = r[~np.isnan(r)]
    if len(r15) < 100: return None
    r4 = np.array([r[i - 3:i + 1].sum() if not np.isnan(r[i - 3:i + 1]).any() else np.nan for i in range(3, len(r))])
    r60 = r4[~np.isnan(r4)]
    if len(r60) < 40: return None
    v15 = r15.var(ddof=1); return float(r60.var(ddof=1) / (4 * v15)) if v15 > 0 else None
def at(bars, now):
    out = {}
    for s, (t, c) in bars.items():
        k = np.searchsorted(t + 900, now, side='right'); lo = max(0, k - 240)
        out[s] = vr_of(t[lo:k], c[lo:k])
    vals = [v for v in out.values() if v is not None]
    return out, (float(np.mean(vals)) if len(vals) >= 3 else None)
if __name__ == '__main__':
    bars = {s: bars15(s) for s in PAIRS}
    E = pd.read_pickle('work/v0762_entries.pkl'); E['q'] = ((E.b - 60) // 900) * 900
    qs = np.unique(E.q.values); vals = {}
    for i, q in enumerate(qs): vals[q] = at(bars, q)[1]
    E['vr'] = E.q.map(vals); E['per'] = np.where(E.b < 1769871600, 'P1', np.where(E.b < 1780239600, 'P2', np.where(E.b < 1788188400, 'P3a', 'SepOct')))
    E['lv'] = pd.cut(E.vr, [-np.inf, 1.0, 1.1, np.inf], labels=['<=1.0', '1.0-1.1', '>1.1'])
    t = E.groupby(['lv', 'per'], observed=True).w.mean().unstack('per').mul(100).round(1); t['all'] = E.groupby('lv', observed=True).w.mean().mul(100).round(1)
    t['share'] = (E.groupby('lv', observed=True).size() / E.vr.notna().sum() * 100).round(1); print(t.to_string()); print('coverage', round(E.vr.notna().mean() * 100, 1))
    # fixture for the Kotlin parity test: 12 moments, the 240 bars of each pair and the expected values
    rng = np.random.default_rng(7); pick = list(rng.choice(qs, 10, replace=False)) + [int(qs[qs >= 1788188400][5]), int(qs[qs >= 1789000000][3])]
    lines = []
    for q in pick:
        per, yen = at(bars, int(q))
        for s, (tt, cc) in bars.items():
            k = np.searchsorted(tt + 900, q, side='right'); lo = max(0, k - 240)
            lines.append(f'B|{q}|{s}|' + ';'.join(f'{a}:{b!r}' for a, b in zip(tt[lo:k].tolist(), cc[lo:k].tolist())))
        lines.append(f'E|{q}|' + '|'.join(f'{s}={per[s]!r}' for s in PAIRS) + f'|YEN={yen!r}')
    with gzip.open('research_v0764/v0764_run_regime_parity.txt.gz', 'wt') as f: f.write('\n'.join(lines) + '\n')
    print('fixture moments', len(pick))

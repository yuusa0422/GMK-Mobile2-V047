"""v0.7.72 research: retrain the weekday nine-pair 5-minute model with variants and score them with the exact app replay (rotation
P1/P2/P3, pace 0.8). Variants: crypto basket in the basket slots of crypto rows (cb), yen leg of X/JPY (leg), cross signals (cross),
2023-24 added to training (y), model size (big). Usage: v0772_exp.py name [name ...]  (3 seeds, fresh design)."""
import sys, json, pickle, time, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('v0770_models.py').read().split("if __name__ == '__main__':")[0])
INST9 = YEN + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']; CR = ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
S0, F0, U0 = FEATS['base']
def add(D):
    D = D.copy()
    piv = D[D.inst.isin(['BTCUSD', 'ETHUSD'])].pivot_table(index='b', columns='inst', values=['r5', 'r15', 'f1', 'r60'])
    for c in ('r5', 'r15', 'f1', 'r60'):
        D['cb_' + c] = D.b.map(piv[c].mean(axis=1, skipna=False))
    uj = D[D.inst == 'USDJPY'].set_index('b')
    for c in ('r5', 'r15', 'f1'): D['uj_' + c] = D.b.map(uj[c])
    cr = D.inst.isin(CR)
    D['cbask_r5'] = np.where(cr, D.cb_r5, D.bask_r5); D['cidio_r5'] = np.where(cr, D.r5 - D.cb_r5, D.idio_r5)
    D['cbask_r15'] = np.where(cr, D.cb_r15, D.bask_r15); D['cidio_r15'] = np.where(cr, D.r15 - D.cb_r15, D.idio_r15)
    D['cbask_f1'] = np.where(cr, D.cb_f1, D.bask_f1); D['cidio_f1'] = np.where(cr, D.f1 - D.cb_f1, D.idio_f1)
    jy = D.inst.isin(['BTCJPY', 'ETHJPY'])
    for c in ('r5', 'r15', 'f1'): D['leg_' + c] = np.where(jy, D['uj_' + c], 0.0)
    # app convention: crypto rows have basket 0 and idio = own move in the base slots
    for c in ('r5', 'r15', 'f1'):
        D.loc[cr, 'bask_' + c] = 0.0; D.loc[cr, 'idio_' + c] = D.loc[cr, c]
    return D
CB_S = ['r1', 'r3', 'r5', 'r10', 'r15', 'r30', 'r60', 'pos15', 'pos60', 'bbz', 'cbask_r5', 'cidio_r5', 'cbask_r15', 'cidio_r15']
CB_F = ['f1', 'f2', 'f5', 'f15', 'pos15L', 'bbzL', 'cbask_f1', 'cidio_f1']
V = {'base': (S0, F0, U0, {}, False), 'cb': (CB_S, CB_F, U0, {}, False), 'cbleg': (CB_S + ['leg_r5', 'leg_r15'], CB_F + ['leg_f1'], U0, {}, False),
     'cross': (S0 + ['cb_r5', 'cb_r15', 'uj_r5'], F0 + ['cb_f1', 'uj_f1'], U0, {}, False), 'y': (S0, F0, U0, {}, True),
     'big': (S0, F0, U0, dict(max_iter=300, max_leaf_nodes=11, min_samples_leaf=1500), False),
     'cby': (CB_S, CB_F, U0, {}, True), 'long': (S0 + ['r240', 'r1440'], F0, U0, {}, False),
     'l240': (S0 + ['r240'], F0, U0, {}, False), 'l1440': (S0 + ['r1440'], F0, U0, {}, False),
     'longcross': (S0 + ['r240', 'r1440', 'cb_r5', 'cb_r15', 'uj_r5'], F0 + ['cb_f1', 'uj_f1'], U0, {}, False),
     'longy': (S0 + ['r240', 'r1440'], F0, U0, {}, True), 'longbig': (S0 + ['r240', 'r1440'], F0, U0, dict(max_iter=300, max_leaf_nodes=11, min_samples_leaf=1500), False)}
def des(D, d, S, Fr, U):
    cols = [D[c].values * d for c in S] + [D[c].values * d for c in Fr] + [D[c].values.astype(float) for c in U]
    cols += [(D.inst.values == s).astype(float) for s in INST9] + [np.full(len(D), float(d))]
    return np.column_stack(cols)
if __name__ == '__main__':
    Dc = add(load('cur', True)); Dc = Dc[Dc.inst.isin(INST9)].reset_index(drop=True)
    need_y = any(V[n.split('@')[0]][4] for n in sys.argv[1:])
    Dy = add(load('y', True)) if need_y else None
    if Dy is not None: Dy = Dy[Dy.inst.isin(INST9) & Dy.move5.notna()].reset_index(drop=True)
    for arg in sys.argv[1:]:
        name, ns = (arg.split('@') + ['3'])[:2]; ns = int(ns); tag = arg.replace('@', '_s')
        S, Fr, U, cfg, use_y = V[name]; c = dict(CFG); c.update(cfg); parts = []; t0 = time.time()
        for te in ('P1', 'P2', 'P3'):
            tr = Dc[(Dc.period != te) & Dc.move5.notna()]
            if use_y: tr = pd.concat([tr, Dy], ignore_index=True)
            X = np.vstack([des(tr, 1, S, Fr, U), des(tr, -1, S, Fr, U)]); y = np.r_[tr.move5.values == 1, tr.move5.values == -1].astype(int)
            ms = [HistGradientBoostingClassifier(random_state=s, **c).fit(X, y) for s in range(ns)]
            T = Dc[Dc.period == te]; pu = np.mean([m.predict_proba(des(T, 1, S, Fr, U))[:, 1] for m in ms], 0); pdn = np.mean([m.predict_proba(des(T, -1, S, Fr, U))[:, 1] for m in ms], 0)
            parts.append(T[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=pu, pd=pdn)); del X, y
        pd.concat(parts, ignore_index=True).to_pickle(f'../work/v0772_rot_{tag}.pkl'); print('TRAINED', tag, round(time.time() - t0), 's', flush=True)

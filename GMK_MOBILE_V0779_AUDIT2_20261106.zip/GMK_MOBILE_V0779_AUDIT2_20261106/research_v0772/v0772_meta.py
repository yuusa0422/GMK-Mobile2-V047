"""v0.7.72 research (the user's idea, 2026-11-05: learn which skips would win and which entries lose): a second-stage model on the
out-of-sample scores of the nine-pair model plus slot context (the other pairs' scores, the gap to the slot's best, the yen / crypto
consensus, the minute) and the trade's own inputs. Rotation-honest: the meta model for period P is fit on the other periods' rows
(whose scores are themselves out of sample). Then the exact app replay with the meta score in place of p (selection and cut)."""
import time
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
exec(open('v0772_exp.py').read().split("\nif __name__ == '__main__':")[0])
PACE['a'] = 0.8
src = sys.argv[1] if len(sys.argv) > 1 else '../work/v0771_sc_fresh_rot.pkl'
R = pd.read_pickle(src)
Dc = load('cur', True); Dc = Dc[Dc.inst.isin(INST9)]
FE = ['r1', 'r5', 'r15', 'r60', 'pos15', 'pos60', 'bbz', 'f1', 'f5', 'pos15L', 'bbzL', 'rv60', 'rv30_60', 'minute', 'bask_r5', 'bask_f1']
R = R.merge(Dc[['b', 'inst'] + FE], on=['b', 'inst'], how='left')
# slot context
R['m'] = R.pu - R.pd; R['best'] = np.maximum(R.pu, R.pd)
g = R.groupby('b')
R['slot_top'] = g.best.transform('max'); R['slot_n'] = g.best.transform('size')
fx = R.inst.isin(JPY)
R['yen_cons'] = R.b.map(R[fx].groupby('b').m.mean()); R['cr_cons'] = R.b.map(R[~fx].groupby('b').m.mean())
R['rank'] = g.best.rank(ascending=False)
def rows(R, d):
    s = 1.0 if d == 1 else -1.0; p = R.pu if d == 1 else R.pd; q = R.pd if d == 1 else R.pu
    X = pd.DataFrame({'p': p, 'q': q, 'gap': R.slot_top - p, 'rank': R['rank'], 'n': R.slot_n, 'yen': R.yen_cons * s, 'cr': R.cr_cons * s,
                      'own_m': R.m * s, 'hour': R.hour, 'dir': s, 'crypto': (~R.inst.isin(JPY)).astype(float)})
    for c in FE: X[c] = R[c] * (s if c not in ('rv60', 'rv30_60', 'minute') else 1.0)
    for i in INST9: X['is_' + i] = (R.inst == i).astype(float)
    return X
CFGM = dict(max_iter=120, learning_rate=0.05, max_leaf_nodes=7, min_samples_leaf=3000, l2_regularization=1.0, early_stopping=False)
out = []
for te in ('P1', 'P2', 'P3'):
    t0 = time.time(); tr = R[R.period != te]; T = R[R.period == te].copy()
    X = pd.concat([rows(tr, 1), rows(tr, -1)]); y = np.r_[tr.move5.values == 1, tr.move5.values == -1].astype(int)
    ms = [HistGradientBoostingClassifier(random_state=s, **CFGM).fit(X.values, y) for s in range(3)]
    T['pu'] = np.mean([m.predict_proba(rows(T, 1).values)[:, 1] for m in ms], 0); T['pd'] = np.mean([m.predict_proba(rows(T, -1).values)[:, 1] for m in ms], 0)
    out.append(T[['b', 'inst', 'hour', 'period', 'move3', 'move5', 'pu', 'pd']]); print(te, round(time.time() - t0), 's', flush=True)
M = pd.concat(out, ignore_index=True); M.to_pickle('../work/v0772_rot_meta.pkl')
for name, S in (('base', R[['b', 'inst', 'hour', 'period', 'move3', 'move5', 'pu', 'pd']]), ('meta', M)):
    E = rotation(S, insts=INST9); r = summ(E); C = E[E.g == 'C']
    print(name, json.dumps(dict(win=r['win'], P=r['P'], sep_oct=r['sep_oct'], C=r['C'], per_day=r['per_day'])), flush=True)
# blend: the meta score half-weighted
B = R[['b', 'inst', 'hour', 'period', 'move3', 'move5']].merge(M[['b', 'inst', 'pu', 'pd']], on=['b', 'inst']).rename(columns={'pu': 'mu', 'pd': 'md'})
B = B.merge(R[['b', 'inst', 'pu', 'pd']], on=['b', 'inst']); B['pu'] = (B.pu + B.mu) / 2; B['pd'] = (B.pd + B.md) / 2
E = rotation(B, insts=INST9); r = summ(E); print('blend', json.dumps(dict(win=r['win'], P=r['P'], sep_oct=r['sep_oct'], C=r['C'])), flush=True)

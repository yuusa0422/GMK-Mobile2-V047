"""Pattern test: trades that follow the last-minute move (f1 x direction > 0) or the 60-minute trend (r60 x direction > 1) win less.
Penalise them in the score (selection and cut) by k and replay; checked per period and on 2023-24 (production fit, in-sample tables)."""
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
exec(open('v0772_exp.py').read().split("\nif __name__ == '__main__':")[0])
PACE['a'] = 0.8
rot = pd.read_pickle('../work/v0771_sc_fresh_rot.pkl'); ins = pd.read_pickle('../work/v0771_sc_fresh_ins.pkl'); ys = pd.read_pickle('../work/v0771_sc_fresh_y.pkl')
fc = load('cur', True)[['b', 'inst', 'f1', 'r60']]; fy = load('y', True)[['b', 'inst', 'f1', 'r60']]
def pen(S, f, k, what):
    S = S.merge(f, on=['b', 'inst'], how='left')
    if what == 'f1': up, dn = (S.f1 > 0), (S.f1 < 0)
    else: up, dn = (S.r60 > 1), (S.r60 < -1)
    return S.assign(pu=S.pu - k * up, pd=S.pd - k * dn).drop(columns=['f1', 'r60'])
for what in ('f1', 'r60'):
    for k in (0.0, 0.003, 0.006, 0.01):
        R = pen(rot, fc, k, what); E = rotation(R, insts=INST9); r = summ(E)
        y, _ = years(pen(ins, fc, k, what), pen(ys, fy, k, what), INST9)
        print(what, k, json.dumps(dict(win=r['win'], P=r['P'], sep_oct=r['sep_oct'], y2324=y['win'])), flush=True)

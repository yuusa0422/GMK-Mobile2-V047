exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
rot = pd.read_pickle('../work/v0771_sc_fresh_rot.pkl'); E = rotation(rot, insts=INST9)
E['hour'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.hour
C = E[E.g == 'C']
print('by hour', C.groupby('hour').w.agg(['mean', 'size']).assign(mean=lambda x: (x['mean'] * 100).round(1)).T.to_string())
print('forced vs not', C.groupby('forced').w.agg(['mean', 'size']).to_string())
C = C.assign(q=pd.qcut(C.p, 5, labels=False))
print('by p quintile', C.groupby('q').w.agg(['mean', 'size']).to_string())
print('by minute', C.groupby('minute').w.agg(['mean', 'size']).assign(mean=lambda x: (x['mean'] * 100).round(1)).T.to_string())
print('all grades', E.groupby('g').w.agg(['mean', 'size']).to_string())

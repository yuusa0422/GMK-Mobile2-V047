"""What-if numbers for spec questions (not applied): lower hourly quota, skipping the weakest hours' C trades."""
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
rot = pd.read_pickle('../work/v0771_sc_fresh_rot.pkl')
for sh in (0.7, 0.6, 0.5):
    SHARE = sh; E = rotation(rot, insts=INST9); r = summ(E); print('quota', sh, json.dumps({k: r[k] for k in ('win', 'P', 'sep_oct', 'per_day')}), flush=True)
SHARE = 0.7; E = rotation(rot, insts=INST9); E['hour'] = pd.to_datetime(E.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.hour
for hs in ([9], [9, 13], [9, 13, 15]):
    X = E[~((E.g == 'C') & E.hour.isin(hs))]; print('skip C in hours', hs, round(X.w.mean() * 100, 2), 'per_day', round(len(X) / NDAYS, 1), flush=True)

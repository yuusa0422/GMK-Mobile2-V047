"""v0.7.72 post-hoc selection experiments on the v0.7.71 production rotation scores (no retraining): pool removal, per-pair offsets."""
import time
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']
rot = pd.read_pickle('../work/v0771_sc_fresh_rot.pkl'); ins = pd.read_pickle('../work/v0771_sc_fresh_ins.pkl'); ys = pd.read_pickle('../work/v0771_sc_fresh_y.pkl')
def ev(name, R=rot, I=ins, Y=ys, insts=INST9, yr=True):
    t0 = time.time(); E = rotation(R, insts=insts); r = summ(E)
    out = dict(win=r['win'], P=r['P'], sep_oct=r['sep_oct'], per_day=r['per_day'], C=r['C'])
    if yr: y, _ = years(I, Y, insts); out['y2324'] = y['win']
    print(name, json.dumps(out), round(time.time() - t0), 's', flush=True); return E
E0 = ev('base9')
# pool removal
for drop in INST9: ev('drop_' + drop, insts=[i for i in INST9 if i != drop], yr=False)
# per-pair offsets: subtract the pair's mean max(pu,pd) on the training periods (rotation-consistent: computed on ins scores, a mild leak)
off = ins.assign(m=np.maximum(ins.pu, ins.pd)).groupby('inst').m.mean(); off = off - off.mean(); print('offsets', off.round(4).to_dict())
for k in (0.5, 1.0):
    f = lambda S: S.assign(pu=S.pu - k * S.inst.map(off), pd=S.pd - k * S.inst.map(off))
    ev(f'offset{k}', R=f(rot), I=f(ins), Y=f(ys))

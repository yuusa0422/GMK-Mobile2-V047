"""Score v0772_rot_<name>.pkl files with the exact app replay (rotation, pace 0.8, nine pairs)."""
import os
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
PACE['a'] = 0.8
INST9 = JPY + ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']; CR = INST9[5:]
for name in sys.argv[1:]:
    f = f'../work/v0772_rot_{name}.pkl'
    if not os.path.exists(f): print(name, 'missing'); continue
    R = pd.read_pickle(f); E = rotation(R, insts=INST9); r = summ(E); C = E[E.g == 'C']
    print(name, json.dumps(dict(win=r['win'], P=r['P'], sep_oct=r['sep_oct'], C=r['C'], per_day=r['per_day'],
          crypto=round(C.inst.isin(CR).mean() * 100, 1), cw=round(C[C.inst.isin(CR)].w.mean() * 100, 2), fw=round(C[~C.inst.isin(CR)].w.mean() * 100, 2))), flush=True)

"""v0.7.72 audit fixture: real 5-minute slots of the current year (research minute bars: Yahoo/Dukascopy FX, Coinbase x USD/JPY crypto)
with the research's own decision, so the Kotlin pipeline (EvidenceFeatures window + live price, CandleModel9/CandleModelW design,
basket, ensembles, best of pairs x directions) is checked end to end on real data, not only on design rows.
Lines: 'S|kind|b' starts a slot (kind wd / we); 'C|inst|t|o|h|l|c' minute bars B-130 min .. B-60 (the forming bar at B-60 included,
the app must ignore it); 'L|inst|price' live price (= close of the bar at B-60, the research proxy) taken at B-10 s;
'E|fresh|inst|dir|p' and 'E|fallback|inst|dir|p' the research choice (no open trades)."""
import gzip, pickle, sys, numpy as np, pandas as pd
exec(open('model_export_lib.py').read())
H = '..'
SRC = {'USDJPY': f'{H}/hist_v0765/USDJPY_merged.csv.gz', 'EURJPY': f'{H}/hist_v0765/EURJPY_1m.csv.gz', 'GBPJPY': f'{H}/hist_v0765/GBPJPY_1m.csv.gz',
       'AUDJPY': f'{H}/hist_v0765/AUDJPY_1m.csv.gz', 'NZDJPY': f'{H}/hist_v0765/NZDJPY_1m.csv.gz',
       'BTCJPY': f'{H}/crypto_in/syn/BTCJPY_cur.csv.gz', 'ETHJPY': f'{H}/crypto_in/syn/ETHJPY_cur.csv.gz', 'BTCUSD': f'{H}/crypto_in/syn/BTCUSD_cur.csv.gz', 'ETHUSD': f'{H}/crypto_in/syn/ETHUSD_cur.csv.gz'}
INST9 = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']; CR = INST9[5:]
def load(path):
    d = pd.read_csv(path, usecols=['epoch_ms', 'open', 'high', 'low', 'close']); d['t'] = d.epoch_ms // 1000
    return d.drop_duplicates('t').set_index('t').sort_index()[['open', 'high', 'low', 'close']]
bars = {s: load(p) for s, p in SRC.items()}
rng = np.random.default_rng(72); L = []
def dump(b, insts, live=True):
    for s in insts:
        w = bars[s].loc[b - 130 * 60:b - 60]
        for t, r in w.iterrows(): L.append(f'C|{s}|{t}|{float(r.open)!r}|{float(r.high)!r}|{float(r.low)!r}|{float(r.close)!r}')
        if live and (b - 60) in bars[s].index: L.append(f'L|{s}|{float(bars[s].loc[b - 60, "close"])!r}')
def pick_best(S):
    i = int(np.argmax(np.r_[S.pu.values, S.pd.values])); n = len(S)
    r = S.iloc[i % n]; return r.inst, ('HIGH' if i < n else 'LOW'), float(r.pu if i < n else r.pd)
# weekday: production in-sample scores (5 seeds, the exported models)
fr = pd.read_pickle('../work/v0771_sc_fresh_ins.pkl'); fb = pd.read_pickle('../work/v0771_sc_fallback_ins.pkl')
cnt = fr.groupby('b').inst.nunique(); full = cnt[cnt == 9].index.values; part = cnt[(cnt >= 6) & (cnt < 9)].index.values
pick = list(rng.choice(full, 70, replace=False)) + list(rng.choice(part, min(10, len(part)), replace=False))
for b in sorted(pick):
    a = fr[fr.b == b]; c = fb[fb.b == b]
    L.append(f'S|wd|{b}'); dump(b, list(a.inst))
    for k, S in (('fresh', a), ('fallback', c)):
        i, d, p = pick_best(S); L.append(f'E|{k}|{i}|{d}|{p!r}')
# weekend: the exported weekend ensembles on the research weekend rows
exec(open('v0771_weekend_prod.py').read().split('Cc = prep(')[0])
W = pickle.load(open('../work/v0771_weekend_production.pkl', 'rb'))
Dw = pd.read_pickle('../work/v0770_F_cur_wkend.pkl'); Dw = Dw[Dw.inst.isin(CR)]
cw = Dw.groupby('b').inst.nunique(); wb = list(rng.choice(cw[cw == 4].index.values, 40, replace=False))
for b in sorted(wb):
    S = Dw[Dw.b == b].reset_index(drop=True).assign(wkend=1.0)
    L.append(f'S|we|{b}'); dump(b, list(S.inst))
    for k, fresh in (('fresh', True), ('fallback', False)):
        tx = W[k]['texts']; pu = np.mean([eval_text(t, des(S, 1, fresh)) for t in tx], 0); pdn = np.mean([eval_text(t, des(S, -1, fresh)) for t in tx], 0)
        i, d, p = pick_best(S.assign(pu=pu, pd=pdn)); L.append(f'E|{k}|{i}|{d}|{p!r}')
with gzip.GzipFile(sys.argv[1], 'wb', mtime=0) as f: f.write(('\n'.join(L) + '\n').encode())
print('slots', len(pick), len(wb), 'lines', len(L))

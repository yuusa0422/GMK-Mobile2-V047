"""v0.7.72 weekend research: the four-crypto weekend model (3-minute WIN, top 8% = B) with variants, scored like v0771_weekend_prod
(rotation P1/P2/P3: cuts from the training periods' weekend slots, B win on the left-out period). Variants: base, long (r240, r1440),
y (2023-24 rows added to training), longy, cross (crypto basket + USD/JPY), big (model size)."""
import sys, json, time, numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('v0770_models.py').read().split("if __name__ == '__main__':")[0])
CR = ['BTCJPY', 'ETHJPY', 'BTCUSD', 'ETHUSD']; S0, F0, U0 = FEATS['base']
def prep(which):
    a = pd.read_pickle(f'../work/v0770_F_{which}_crypto.pkl'); a = a[a.inst.isin(CR)].assign(wkend=0.0)
    w = pd.read_pickle(f'../work/v0770_F_{which}_wkend.pkl'); w = w[w.inst.isin(CR)].assign(wkend=1.0)
    D = pd.concat([a, w], ignore_index=True)
    piv = D[D.inst.isin(['BTCUSD', 'ETHUSD'])].pivot_table(index='b', columns='inst', values=['r5', 'r15', 'f1'])
    for c in ('r5', 'r15', 'f1'): D['cb_' + c] = D.b.map(piv[c].mean(axis=1, skipna=False))
    return D
V = {'base': (S0, F0, {}, False), 'long': (S0 + ['r240', 'r1440'], F0, {}, False), 'l240': (S0 + ['r240'], F0, {}, False),
     'y': (S0, F0, {}, True), 'longy': (S0 + ['r240', 'r1440'], F0, {}, True), 'cross': (S0 + ['cb_r5', 'cb_r15'], F0 + ['cb_f1'], {}, False),
     'big': (S0, F0, dict(max_iter=300, max_leaf_nodes=11, min_samples_leaf=1500), False)}
def des(D, d, S, Fr):
    cols = [D[c].values * d for c in S] + [D[c].values * d for c in Fr] + [D[c].values.astype(float) for c in U0 + ['wkend']]
    cols += [(D.inst.values == s).astype(float) for s in CR] + [np.full(len(D), float(d))]
    return np.column_stack(cols)
def best(D, pu, pdn):
    A = pd.concat([D[['b', 'inst', 'hour', 'move3']].assign(p=pu, dir=1), D[['b', 'inst', 'hour', 'move3']].assign(p=pdn, dir=-1)])
    A['w'] = (A.move3 == A.dir).astype(float); return A.sort_values('p', ascending=False).groupby('b').head(1)
Cc = prep('cur'); Cy = None
for arg in sys.argv[1:]:
    name, ns = (arg.split('@') + ['3'])[:2]; ns = int(ns); S, Fr, cfg, use_y = V[name]; c = dict(CFG); c.update(cfg); t0 = time.time(); parts = []
    if use_y and Cy is None: Cy = prep('y'); Cy = Cy[Cy.move3.notna()]
    for te in ('P1', 'P2', 'P3'):
        tr = Cc[(Cc.period != te) & Cc.move3.notna()]
        trn = pd.concat([tr, Cy], ignore_index=True) if use_y else tr
        X = np.vstack([des(trn, 1, S, Fr), des(trn, -1, S, Fr)]); y = np.r_[trn.move3.values == 1, trn.move3.values == -1].astype(int)
        ms = [HistGradientBoostingClassifier(random_state=s, **c).fit(X, y) for s in range(ns)]; del X, y
        pr = lambda D: (np.mean([m.predict_proba(des(D, 1, S, Fr))[:, 1] for m in ms], 0), np.mean([m.predict_proba(des(D, -1, S, Fr))[:, 1] for m in ms], 0))
        tw = tr[tr.wkend == 1]; Bt = best(tw, *pr(tw)); b8 = {h: float(g.p.quantile(0.92)) for h, g in Bt.groupby('hour')}
        te_ = Cc[(Cc.period == te) & (Cc.wkend == 1) & Cc.move3.notna()]; Be = best(te_, *pr(te_)); parts.append(Be[Be.p >= Be.hour.map(b8)].assign(per=te))
    R = pd.concat(parts); nd = Cc[Cc.wkend == 1].date.nunique()
    print(arg, json.dumps(dict(win=round(R.w.mean() * 100, 2), per_day=round(len(R) / nd, 1), P=[round(R[R.per == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')],
          pairs={i: round(v * 100, 1) for i, v in R.groupby('inst').w.mean().items()})), round(time.time() - t0), 's', flush=True)

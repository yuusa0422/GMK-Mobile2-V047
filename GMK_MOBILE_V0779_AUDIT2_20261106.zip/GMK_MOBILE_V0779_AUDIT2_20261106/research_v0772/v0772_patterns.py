"""Descriptive: entered C vs skipped D (the slot's best trade) win rates by simple patterns (one year, out-of-sample scores)."""
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
exec(open('v0772_exp.py').read().split("\nif __name__ == '__main__':")[0])
PACE['a'] = 0.8
rot = pd.read_pickle('../work/v0771_sc_fresh_rot.pkl'); E = rotation(rot, insts=INST9)
Cr, _ = build(rot[rot.inst.isin(INST9)]); ent = set(E.b)
D = pd.DataFrame([dict(b=b, inst=Cr[b].iloc[0].inst, dir=int(Cr[b].iloc[0].dir), p=float(Cr[b].iloc[0].p), w=float(Cr[b].iloc[0].w5)) for b in slots_cur if b in Cr and b not in ent and b not in F])
C = E[E.g == 'C'][['b', 'inst', 'dir', 'p', 'w']].copy()
Dc = load('cur', True)[['b', 'inst', 'f1', 'pos60', 'r60', 'rv60', 'minute', 'hour']]
def ann(X):
    X = X.merge(Dc, on=['b', 'inst'], how='left'); X['crypto'] = ~X.inst.isin(JPY)
    X['f1s'] = np.sign(X.f1 * X.dir); X['pos60s'] = pd.cut(X.pos60 * X.dir, [-9, -0.5, 0.5, 9], labels=['逆側', '中', '同側'])
    X['trend'] = pd.cut(X.r60 * X.dir, [-99, -1, 1, 99], labels=['逆張り', '中立', '順張り']); X['vol'] = pd.qcut(X.rv60.rank(method='first'), 3, labels=['低', '中', '高'])
    return X
C = ann(C); D = ann(D)
print('ENTRY C', round(C.w.mean() * 100, 2), len(C), '| SKIP D', round(D.w.mean() * 100, 2), len(D))
for col in ('crypto', 'f1s', 'pos60s', 'trend', 'vol', 'hour'):
    t = pd.DataFrame({'C': C.groupby(col).w.mean() * 100, 'nC': C.groupby(col).size(), 'D': D.groupby(col).w.mean() * 100, 'nD': D.groupby(col).size()}).round(1)
    print('---', col); print(t.to_string())

"""v0.7.72 research: does recent data matter? Walk-forward (train only on the past, as the app is used): test months 2026-05..2026-10,
each scored by models trained on the data before it - all of it (expanding), the last 4 months only, or all with recency weights
(half-life 90 days). Hour tables from the model's in-sample scores on its training data (as production), exact app replay (pace 0.8)."""
import time
exec(open('v0770_eval.py').read().split("if __name__ == '__main__':")[0])
exec(open('v0772_exp.py').read().split("\nif __name__ == '__main__':")[0])
PACE['a'] = 0.8
Dc = add(load('cur', True)); Dc = Dc[Dc.inst.isin(INST9) & Dc.move5.notna()].reset_index(drop=True)
Dc['mo'] = Dc.b.map(lambda b: MON(b)) if False else pd.to_datetime(Dc.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
S, Fr, U = S0, F0, U0
def fitw(tr, w, ns=3):
    X = np.vstack([des(tr, 1, S, Fr, U), des(tr, -1, S, Fr, U)]); y = np.r_[tr.move5.values == 1, tr.move5.values == -1].astype(int)
    sw = None if w is None else np.r_[w, w]
    return [HistGradientBoostingClassifier(random_state=s, **CFG).fit(X, y, sample_weight=sw) for s in range(ns)]
def score(ms, T):
    return T[['b', 'inst', 'hour', 'period', 'move3', 'move5']].assign(pu=np.mean([m.predict_proba(des(T, 1, S, Fr, U))[:, 1] for m in ms], 0),
                                                                    pd=np.mean([m.predict_proba(des(T, -1, S, Fr, U))[:, 1] for m in ms], 0))
res = {v: [] for v in ('all', 'last4', 'decay90')}
for M_ in ('2026-07', '2026-08', '2026-09', '2026-10'):
    t0 = time.time(); past = Dc[Dc.mo < M_]; test = Dc[Dc.mo == M_]
    last4 = sorted(past.mo.unique())[-4:]
    tend = test.b.min(); age = (tend - past.b.values) / 86400.0
    for v, tr, w in (('all', past, None), ('last4', past[past.mo.isin(last4)], None), ('decay90', past, 0.5 ** (age / 90.0))):
        ms = fitw(tr, w); recent = tr[tr.mo.isin(sorted(tr.mo.unique())[-3:])]; ins = score(ms, recent); te = score(ms, test)
        C, Mi = build(ins); tr_slots = set(b for b in slots_cur if b in set(recent.b)); Q, base = tables(Mi[Mi.b.isin(tr_slots)], {b: x for b, x in fx.items() if b in tr_slots}, hour_of(tr_slots))
        Ct, _ = build(te); te_slots = set(b for b in slots_cur if b in set(test.b))
        E = sim(Ct, {b: x for b, x in F.items() if b in te_slots}, te_slots, Q, base); res[v].append(E.assign(mo=M_))
        print(M_, v, round(E.w.mean() * 100, 2), len(E), flush=True)
    print(M_, 'done', round(time.time() - t0), 's', flush=True)
for v, Es in res.items():
    E = pd.concat(Es); print('WF', v, json.dumps(dict(win=round(E.w.mean() * 100, 2), n=len(E), months={m: round(x.w.mean() * 100, 2) for m, x in E.groupby('mo')},
          C=round(E[E.g == 'C'].w.mean() * 100, 2))), flush=True)

"""Improvement test from the rankings: pick only from (or favour) the winning family 'last-minute shock against our direction'
(signed f1 in the bottom quintile), keep the exact 70% hour rule and the same-direction penalty. Rotation, out of sample."""
import json, sys
src = open('v0758_streakfix2.py').read(); exec(src.split("V = {'v0758'")[0])
LAM = 0.03
FIVE = len(sys.argv) > 3 and sys.argv[3] == 'five'
Sc = pd.read_pickle(sys.argv[1])
F1 = pd.concat([pd.read_pickle(f'../work/minute/policy_{k}.pkl')[['b', 'inst', 'f1']] for k in (1, 2)]).drop_duplicates(['b', 'inst'])
d12 = Sc.period != 'P3'; v = Sc.loc[d12, 'f1'].dropna().values; CUT0 = float(np.quantile(np.r_[v, -v], 0.2)); CUT1 = float(np.quantile(np.r_[v, -v], 0.4))
print('signed f1 cuts', round(CUT0, 3), round(CUT1, 3), flush=True)
def cands(Sc, mode):
    A = pd.concat([Sc[['b', 'inst', 'hour', 'period', 'date', 'move5', 'f1']].assign(p=Sc.pu, dir=1), Sc[['b', 'inst', 'hour', 'period', 'date', 'move5', 'f1']].assign(p=Sc.pd, dir=-1)])
    A['w'] = (A.move5 == A.dir).astype(float); s = A.f1 * A.dir; A['fam'] = (s <= CUT0).astype(float)
    if mode == 'only0': A = A[s <= CUT0]
    elif mode == 'only1': A = A[s <= CUT1]
    elif mode == 'nochase': A = A[s < -CUT0]          # drop the losing family (shock in our direction)
    A = A.sort_values(['b', 'p'], ascending=[True, False]); C = {}
    for b, g in A.groupby('b', sort=True): C[b] = (g.p.values, g.inst.values, g.dir.values, g.w.values, g.fam.values)
    M = A.groupby('b').head(1)[['b', 'hour', 'period', 'p']]
    return C, M
def simulate(C, F, slots, Q, base, bonus=0.0):
    out = []; S_ = pd.DataFrame({'b': sorted(slots)}); ts = pd.to_datetime(S_.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); S_['date'] = ts.dt.date; S_['hour'] = ts.dt.hour
    cb = np.array(sorted(C)); opens = []; hours = []
    for (d, h), g in S_.groupby(['date', 'hour']):
        n = len(g); N = math.ceil(SHARE * n - 1e-9); cnt = 0; sb = set(g.b)
        lo = bisect.bisect_left(cb, g.b.min()); hi = bisect.bisect_left(cb, g.b.min() + 3600)
        for b in sorted(set(cb[lo:hi].tolist()) | {x for x in sb if x in F}):
            minute = (b // 60) % 60; opens = [o for o in opens if o[0] > b]
            if b in F and b in sb:
                gr, w, inst, dd, L_ = F[b]; out.append((b, gr, w, dd, 0)); cnt += 1; opens.append((b + L_, dd)); continue
            if b not in C: continue
            ps, insts, dirs, ws, fams = C[b]; nopen = {1: sum(1 for o in opens if o[1] == 1), -1: sum(1 for o in opens if o[1] == -1)}
            best = None
            for p, i, dd, w, fm in zip(ps, insts, dirs, ws, fams):
                sc = p - LAM * nopen[dd] + bonus * fm
                if best is None or sc > best[0]: best = (sc, p, dd, w)
            _, p, dd, w = best; left = (60 - minute + 4) // 5 if FIVE else 60 - minute; need = N - cnt   # FIVE: slots left in the hour
            if need >= left: forced = 1
            elif need > 0 and p >= qcut(Q[h], max(need / left, base[h] / 2)): forced = 0
            else: continue
            out.append((b, 'C', w, dd, forced)); cnt += 1; opens.append((b + 300, dd))
        hours.append(cnt / n)
    E = pd.DataFrame(out, columns=['b', 'g', 'w', 'dir', 'forced']); E.attrs['hours_below'] = float(np.mean(np.array(hours) < SHARE - 1e-9)); return E
F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); res = {}
JPY = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
for name, insts in (('5 JPY pairs', JPY),):
    C, M = cands(Sc[Sc.inst.isin(insts)], 'all'); Es = []
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
        Ct = {b: v for b, v in C.items() if per_cur.get(b - b % 300) == te}
        Es.append(simulate(Ct, {b: v for b, v in F.items() if b in tes}, tes, Q, base, 0.0))
    hb = float(np.mean([e.attrs['hours_below'] for e in Es])); E = pd.concat(Es).sort_values('b'); s10, mx = streak_stats(E.w.values)
    pr = E.b.map(lambda b: per_cur.get(b - b % 300))
    r = dict(win=round(E.w.mean() * 100, 2), per_day=round(len(E) / len(set(PM.date)), 1), streaks_ge10=s10, max_streak=mx, hours_below_70=round(hb * 100, 2),
             periods={p: round(E[pr == p].w.mean() * 100, 2) for p in ('P1', 'P2', 'P3')}, sep_oct=round(E[E.b >= 1788188400].w.mean() * 100, 2), sep_oct_n=int((E.b >= 1788188400).sum()))
    res[name] = r; print(name, json.dumps(r), flush=True); json.dump(res, open('../work/v0765_5m_' + sys.argv[2] + '.json', 'w'), indent=1)

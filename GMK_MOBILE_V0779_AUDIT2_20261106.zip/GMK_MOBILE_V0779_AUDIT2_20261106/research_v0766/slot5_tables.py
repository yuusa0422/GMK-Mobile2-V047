"""v0.7.66 '5-minute AUTO' tables and rates for the app (the model is unchanged).
1) Rotation (validation): the current model's scores at :00/:05/... only, exact app rules with slots left in the hour -> rates of C
   and of the skipped D (year and October), fresh and fallback (no live price).
2) Production: the production models (fit on the whole year, = the app's model, checked against the exported parity rows) scored
   in-sample at the 5-minute boundaries -> the per-hour quantile tables Q (201 points) and BASE that the app compares with."""
import sys, json, pickle
sys.argv = ['x', '../work/v0765_5m_cur.pkl', 'tables', 'five']
exec(open('v0765_sim_5min.py').read().split("F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix); res = {}")[0])
F = fixed_lookup(RTc, Bfix); fx = fixed_map(RTc, Bfix)
JPY = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
mo = lambda b: pd.to_datetime(b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')


def rotation(Sc):
    C, M = cands(Sc[Sc.inst.isin(JPY)], 'all'); Es = []
    for te in ('P1', 'P2', 'P3'):
        tr = M[M.period != te]; trs = set(b for b in slots_cur if per_cur.get(b) != te and per_cur.get(b) is not None)
        Q, base = tables(tr, {b: v for b, v in fx.items() if b in trs}, hour_of(trs)); tes = set(b for b in slots_cur if per_cur.get(b) == te)
        Ct = {b: v for b, v in C.items() if per_cur.get(b - b % 300) == te}
        Es.append(simulate(Ct, {b: v for b, v in F.items() if b in tes}, tes, Q, base, 0.0))
    E = pd.concat(Es).sort_values('b'); ent = set(E.b)
    top = pd.concat([Sc[['b', 'move5']].assign(p=Sc.pu, dir=1), Sc[['b', 'move5']].assign(p=Sc.pd, dir=-1)]).sort_values('p', ascending=False).groupby('b').head(1)
    D = top[~top.b.isin(ent) & top.b.isin(set(slots_cur)) & ~top.b.isin(set(F))]; D = D.assign(w=(D.move5 == D.dir).astype(float))
    out = {}
    for g in ('B', 'C'):
        x = E[E.g == g]; o = mo(x.b) == '2026-10'
        out[g] = (round(float(x.w.mean()), 4), round(float(x[o].w.mean()), 4), int(o.sum()), len(x))
    out['SA'] = (round(float(E[E.g == 'SA'].w.mean()), 4), int((E.g == 'SA').sum()))
    o = mo(D.b) == '2026-10'; out['D'] = (round(float(D.w.mean()), 4), round(float(D[o].w.mean()), 4), int(o.sum()), len(D))
    s10, mx = streak_stats(E.w.values)
    out['all'] = dict(win=round(E.w.mean() * 100, 2), per_day=round(len(E) / len(set(PM.date)), 1), streaks_ge10=s10, max_streak=mx,
                      hours_below=round(float(np.mean([e.attrs['hours_below'] for e in Es])) * 100, 2))
    return out


res = {}
res['fresh_rotation'] = rotation(Sc); print('fresh rotation', json.dumps(res['fresh_rotation']), flush=True)
FB = pd.read_pickle('../work/v0758_val_minute_all_fallback.pkl')[['b', 'inst', 'pu', 'pd', 'move5']].merge(PM[['b', 'inst', 'hour', 'period', 'date', 'f1']], on=['b', 'inst'])
FB = FB[FB.b % 300 == 0]
res['fallback_rotation'] = rotation(FB); print('fallback rotation', json.dumps(res['fallback_rotation']), flush=True)
src = open('v0758_production.py').read(); exec(src[src.index('def tables('):src.index('def qcut(')])
prod = pickle.load(open('../work/production_model5_v0758.pkl', 'rb')); EX = [('isk0', False)]
P0 = PM[PM.k == 0].reset_index(drop=True); out_tabs = {}
for fresh in (True, False):
    k = 'fresh' if fresh else 'fallback'
    ms = fit(PM, fresh, extra=EX)
    X = np.array([[float(v) for v in r[2].split(',')] for r in prod[k]['parity']]); want = np.array([r[1] for r in prod[k]['parity']])
    got = np.mean([m.predict_proba(X)[:, 1] for m in ms], 0); print(k, 'production parity max diff', float(np.abs(got - want).max()), flush=True)
    pu, pdn = pred(ms, P0, fresh, extra=EX); del ms
    Sp = P0[['b', 'inst', 'hour', 'period', 'date', 'move5', 'f1']].assign(pu=pu, pd=pdn)
    C, M = cands(Sp, 'all'); Q, base = tables(M, fx, hour_of(slots_cur))
    out_tabs[k] = dict(Q={int(h): [float(v) for v in Q[h]] for h in Q}, base={int(h): float(base[h]) for h in base})
    E = simulate(C, F, set(slots_cur), Q, base, 0.0); print(k, 'production in-sample 5-minute', round(E.w.mean() * 100, 2), len(E), flush=True)
    res[k + '_insample'] = round(E.w.mean() * 100, 2)
    del Sp, C, M
pickle.dump(out_tabs, open('../work/v0766_slot5_tables.pkl', 'wb')); json.dump(res, open('../work/v0766_slot5_rates.json', 'w'), indent=1)
print('TABLES_DONE', flush=True)

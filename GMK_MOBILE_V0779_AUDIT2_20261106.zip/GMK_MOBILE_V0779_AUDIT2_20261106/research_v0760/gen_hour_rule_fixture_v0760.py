"""Parity fixture for the every-hour-70% rule: Python (research_v0758 simulate/qcut on the production tables) vs Kotlin RankLadder.
Lines: 'cut|fresh|hour|minute|entries|expected cut' and 'hour|fresh|hour|seed|p0,p1,...,p59|fixed minutes|entered minutes'."""
import pickle, math, gzip, sys, numpy as np
M = pickle.load(open('../work/production_model5_v0758.pkl', 'rb')); out = sys.argv[1]
QN = 200; SHARE = 0.7; N = math.ceil(SHARE * 12 - 1e-9)
def qcut(Q, frac):
    frac = min(max(frac, 0.0), 1.0); return float(np.interp(1 - frac, np.linspace(0, 1, QN + 1), Q))
def cut(k, h, minute, entries):
    need = N - entries; left = 60 - minute
    if need >= left: return -math.inf
    if need <= 0: return math.inf
    return qcut(np.array(M[k]['Q'][h]), max(need / left, M[k]['base'][h] / 2))
rng = np.random.default_rng(7); L = []
for k in ('fresh', 'fallback'):
    for h in range(9, 23):
        for minute in (0, 1, 7, 15, 30, 44, 50, 51, 55, 59):
            for e in (0, 1, 3, 5, 8, 9, 11):
                L.append(f'cut|{k}|{h}|{minute}|{e}|{cut(k, h, minute, e)!r}')
        for seed in range(6):
            Q = np.array(M[k]['Q'][h]); p = np.interp(rng.random(60), np.linspace(0, 1, QN + 1), Q)      # minutes drawn from the hour's distribution
            fixed = sorted(rng.choice(np.arange(0, 60, 5), size=int(rng.integers(0, 3)), replace=False).tolist())
            if seed == 0: p = p - 0.05                                                               # a weak hour -> catch-up at the end
            cnt = 0; entered = []
            for minute in range(60):
                if minute in fixed: cnt += 1; entered.append(minute); continue
                c = cut(k, h, minute, cnt)
                if p[minute] >= c: cnt += 1; entered.append(minute)
            L.append(f'hour|{k}|{h}|{seed}|' + ','.join(repr(float(x)) for x in p) + '|' + ','.join(map(str, fixed)) + '|' + ','.join(map(str, entered)))
with gzip.open(out, 'wt') as f: f.write('\n'.join(L) + '\n')
print('fixture lines', len(L))

"""Prepare, build, and verify GMK v0.7.42 with no generated production key.

All dependencies of source preparation are in the Python standard library.
An extracted project or the distributed v0.7.42 source ZIP is accepted.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

VERSION_CODE = 112
VERSION_NAME = "0.7.42-chart-rank"
APPLICATION_ID = "jp.gmk.mobile.rule"
SOURCE_ZIP = "GMK_MOBILE_V0742_CHART_RANK_PRODUCTION_20261009.zip"
FIXTURE_ZIP = "GMK_V0735_TEST_DATA.zip"
KEY_NAMES = ("KEYSTORE_B64", "STORE_PASSWORD", "KEY_ALIAS", "KEY_PASSWORD")
REQUIRED_SUITES = {
    "Direct19IntegrationTest": 6, "ProductionRegressionTest": 5,
    "PcSyncRegressionTest": 3, "MobileDeepAuditRegressionTest": 28,
    "MobileFullAuditStateTest": 10, "MobileFullAuditUiTest": 3,
    "RuleAiFunctionalTest": 4, "RuleAiRuntimeIntegrationTest": 14,
    "MobileRealtimeAuditTest": 26, "HistoryPipelineAuditTest": 6,
    "OutcomeStreakStatisticsTest": 6, "HorizonPreparationClockTest": 3,
    "CutInQueueRegressionTest": 6, "HistoryPublicationLatencyTest": 2,
    "HistoryCutInTimingUiTest": 2, "OctoberSimilarityIntegrationTest": 7,
    "HorizonRuntimeOctoberIntegrationTest": 14, "MarketTransportV0740Test": 16,
    "NativeRankMetadataParityTest": 1, "RankAssessmentRegressionTest": 6,
    "HistoryAssessmentPersistenceTest": 5, "RankAssessmentUiTest": 3,
    "ChartRankAssessmentPersistenceTest": 9, "ChartRankUiTest": 5,
    "ChartConditionalRankRuntimeTest": 11,
}


def fail(message):
    raise ValueError(message)



def upload_name_matches(name, canonical):
    # Browser duplicate downloads may append numeric copies: (1), (2)(1).
    return re.fullmatch(re.escape(Path(canonical).stem) + r"(?: ?\([0-9]+\))*\.zip", name) is not None


def upload_matches(root, canonical):
    return sorted(p for p in Path(root).rglob("*.zip")
                  if ".git" not in p.parts and upload_name_matches(p.name, canonical))


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def checked_path(value):
    value = str(Path(value).resolve())
    if any(x in value for x in "\r\n"):
        fail("project path contains a newline")
    return Path(value)


def run(command, cwd=None):
    # Never print arguments containing passwords; signing uses env: passwords.
    subprocess.run([str(x) for x in command], cwd=cwd, check=True)


def signing_mode(env=None):
    env = os.environ if env is None else env
    present = [bool(env.get(name)) for name in KEY_NAMES]
    if any(present) and not all(present):
        missing = [name for name, exists in zip(KEY_NAMES, present) if not exists]
        fail("partial signing secrets: missing " + ", ".join(missing))
    fingerprint = env.get("EXPECTED_CERT_SHA256", "").replace(":", "").lower()
    if fingerprint and (not all(present) or not re.fullmatch("[0-9a-f]{64}", fingerprint)):
        fail("expected certificate must be a SHA-256 fingerprint with all signing secrets")
    if all(present):
        if not fingerprint:
            fail("production signing requires EXPECTED_CERT_SHA256 from the existing installed certificate")
        try:
            data = base64.b64decode("".join(env["KEYSTORE_B64"].split()), validate=True)
        except (ValueError, base64.binascii.Error):
            fail("signing keystore is not valid base64")
        if not data:
            fail("signing keystore is empty")
        return "supplied-production-key"
    return "test-only-debug-production-unsigned"


def safe_extract(archive, destination, strip_root=False, allowed_files=None, allow_identical=False):
    """Reject traversal, links, duplicate targets, and unbounded ZIP expansion."""
    destination = checked_path(destination)
    with zipfile.ZipFile(archive) as source:
        members = source.infolist()
        if len(members) > 20000 or sum(x.file_size for x in members) > 512 * 1024 * 1024:
            fail("ZIP exceeds the 512 MiB / 20,000 member extraction limit")
        seen = set()
        planned = []
        for info in members:
            name = info.filename.replace("\\", "/")
            relative = PurePosixPath(name)
            if not relative.parts or relative.is_absolute() or ".." in relative.parts or ":" in name:
                fail("unsafe ZIP path")
            mode = (info.external_attr >> 16) & 0o170000
            if mode not in (0, stat.S_IFREG, stat.S_IFDIR):
                fail("links and special ZIP entries are forbidden")
            if strip_root:
                if len(relative.parts) == 1:
                    if info.is_dir():
                        continue
                    fail("fixture archive has no project directory")
                relative = PurePosixPath(*relative.parts[1:])
                if relative.parts[0] != "tools":
                    fail("fixture archive contains files outside tools")
            if allowed_files is not None and not info.is_dir() and str(relative) not in allowed_files:
                fail("data ZIP contains an undeclared file")
            if str(relative) in seen:
                fail("duplicate ZIP target")
            seen.add(str(relative))
            target = destination.joinpath(*relative.parts)
            if destination not in target.resolve().parents:
                fail("unsafe ZIP target")
            # Existing source files cannot silently be replaced by a fixture ZIP.
            if target.exists() and not info.is_dir():
                if not allow_identical or target.is_symlink() or sha256(target) != hashlib.sha256(source.read(info)).hexdigest():
                    fail("ZIP would overwrite an existing source file")
                continue  # A verified identical fixture is already materialized.
            planned.append((info, target))
        for info, target in planned:
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with source.open(info) as stream, target.open("wb") as out:
                    shutil.copyfileobj(stream, out)



def restore_data_parts(project, workspace):
    manifest = project / "DATA_PARTS_MANIFEST.json"
    if not manifest.is_file():
        return
    data = json.loads(manifest.read_text())
    if data.get("format_version") != 1:
        fail("unsupported data part manifest")
    files = {}
    for item in data["files"]:
        path = PurePosixPath(item["path"])
        name = str(path)
        if path.is_absolute() or ".." in path.parts or ":" in name or not path.parts or name in files:
            fail("unsafe or duplicate data part file")
        if path.parts[0] not in ("app", "tools"):
            fail("data part path must belong to app or tools")
        files[name] = item
    if sum(item["bytes"] for item in files.values()) > 512 * 1024 * 1024:
        fail("data parts exceed 512 MiB")
    # Complete extracted projects do not need the original upload ZIPs again.
    if files and all((project / name).is_file() and (project / name).stat().st_size == item["bytes"]
                     and sha256(project / name) == item["sha256"] for name, item in files.items()):
        return
    part_names = set()
    extracted_names = set()
    for item in data["parts"]:
        name = item["filename"]
        if not (re.fullmatch(r"GMK_MOBILE_V0740_DATA_PART[0-9]{2}\.zip", name) or re.fullmatch(r"GMK_MOBILE_V0742_CHART_DATA_PART[0-9]{2}_20261009\.zip", name)) or name in part_names:
            fail("unsafe or duplicate data part filename")
        part_names.add(name)
        matches = upload_matches(workspace, name)
        if len(matches) != 1:
            fail("upload exactly one required data ZIP: " + name)
        part = matches[0]
        if part.stat().st_size != item["bytes"] or sha256(part) != item["sha256"]:
            fail("missing or corrupted data ZIP: " + name)
        with zipfile.ZipFile(part) as archive:
            current = {str(PurePosixPath(i.filename.replace("\\", "/")))
                       for i in archive.infolist() if not i.is_dir()}
            if archive.testzip() is not None:
                fail("corrupted data ZIP CRC: " + name)
            for member in archive.infolist():
                if member.is_dir():
                    continue
                relative = str(PurePosixPath(member.filename.replace("\\", "/")))
                if relative not in files or member.file_size != files[relative]["bytes"]:
                    fail("data ZIP file differs from declared manifest")
                if hashlib.sha256(archive.read(member)).hexdigest() != files[relative]["sha256"]:
                    fail("data ZIP file SHA-256 differs from declared manifest")
        if not current or extracted_names & current:
            fail("empty data ZIP or duplicate file across data ZIPs")
        extracted_names.update(current)
        safe_extract(part, project, allowed_files=set(files), allow_identical=True)
    if extracted_names != set(files):
        fail("data ZIP file set differs from declared file manifest")
    extras = [p for p in workspace.rglob("GMK_MOBILE_V*_DATA*.zip")
              if ".git" not in p.parts and not any(upload_name_matches(p.name, name) for name in part_names)]
    if extras:
        fail("unexpected data ZIPs found; keep only parts for this source release")
    for name, item in files.items():
        target = project / name
        if not target.is_file() or target.stat().st_size != item["bytes"] or sha256(target) != item["sha256"]:
            fail("missing or corrupted restored data file: " + name)


def projects_in(root):
    return sorted({checked_path(p.parent) for p in Path(root).rglob("settings.gradle.kts")
                   if ".git" not in p.parts and (p.parent / "app/build.gradle.kts").is_file()})


def verify_package_manifest(project):
    manifest = project / "PACKAGE_MANIFEST_SHA256.txt"
    if not manifest.is_file():
        fail("source package SHA-256 manifest is missing")
    seen = set()
    for line in manifest.read_text().splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-f]{64}) [ *](.+)", line)
        if not match:
            fail("invalid package manifest line")
        digest, name = match.groups()
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or ":" in name or name in seen:
            fail("unsafe or duplicate package manifest path")
        seen.add(name)
        target = project.joinpath(*relative.parts)
        if not target.is_file() or target.is_symlink() or sha256(target) != digest:
            fail("source package integrity failure: " + name)
    if not seen:
        fail("empty source package manifest")
    return len(seen)


def verify_version(project):
    content = (project / "app/build.gradle.kts").read_text()
    expected = {"applicationId": '"' + APPLICATION_ID + '"',
                "versionCode": str(VERSION_CODE), "versionName": '"' + VERSION_NAME + '"'}
    if any(not re.search(r"^\s*" + key + r"\s*=\s*" + re.escape(value) + r"\s*$", content, re.M)
           for key, value in expected.items()):
        fail("wrong applicationId or production version; use the v0.7.42 source package")
    for key in ("compileSdk", "targetSdk"):
        if not re.search(r"^\s*" + key + r"\s*=\s*35\s*$", content, re.M):
            fail("source requires Android SDK 35")


def verify_fixture(project):
    meta = json.loads((project / "DIRECT19_BUNDLED_FIXTURE_MANIFEST.json").read_text())
    fixture = project / "tools/direct19_feature_fixture.bin"
    if not fixture.is_file() or sha256(fixture) != meta["bundled_sha256"]:
        fail("missing or corrupted observed-price fixture")


def prepare(workspace, temporary):
    signing_mode()  # Fail partial secrets before source extraction / expensive build.
    workspace = checked_path(workspace)
    archives = upload_matches(workspace, SOURCE_ZIP)
    if len(archives) > 1:
        fail("multiple v0.7.42 source ZIPs; keep one source ZIP or one extracted project")
    extracted = projects_in(workspace)
    if archives and extracted:
        fail("both source ZIP and extracted Android project found; keep only one")
    if archives:
        temporary.mkdir(parents=True, exist_ok=True)
        selected_root = Path(tempfile.mkdtemp(prefix="gmk-v0742-", dir=temporary))
        safe_extract(archives[0], selected_root)
        projects = projects_in(selected_root)
    else:
        projects = extracted
    if len(projects) != 1:
        fail("expected one extracted Android project or " + SOURCE_ZIP)
    project = projects[0]
    verify_version(project)
    restore_data_parts(project, workspace)
    verify_package_manifest(project)
    restore = project / "tools/restore_bundled_assets.py"
    if (project / "BUNDLED_ASSETS.json").is_file():
        if not restore.is_file():
            fail("bundled asset restore helper is missing")
        run([sys.executable, restore], project)
    if not all((project / "tools" / name).is_dir() for name in ("fixtures", "pc_r13_fixtures")):
        fixtures = upload_matches(workspace, FIXTURE_ZIP)
        if len(fixtures) != 1:
            fail("test fixture folders are missing; upload exactly one " + FIXTURE_ZIP)
        safe_extract(fixtures[0], project, strip_root=True, allow_identical=True)
    verify_fixture(project)
    if not (project / "tools/audit_v0742.py").is_file():
        fail("v0.7.42 complete source audit helper is missing")
    run([sys.executable, "tools/audit_v0742.py"], project)
    env_file = os.environ.get("GITHUB_ENV")
    if env_file:
        with open(env_file, "a") as out:
            out.write("GMK_PROJECT=" + str(project) + "\n")
    print("Prepared GMK v0.7.42: source, fixtures, assets and signing configuration checked")
    return project


def verify_tests(project):
    rows = {}
    reports = project / "app/build/test-results/testDebugUnitTest"
    for report in sorted(reports.glob("TEST*.xml")):
        suite = ET.parse(report).getroot()
        if any(int(suite.get(name, "0")) != 0 for name in ("failures", "errors", "skipped")):
            fail("failed or skipped Android-host tests: " + report.name)
        name = suite.get("name", "")
        if not name or name in rows:
            fail("missing or duplicate test suite")
        cases = suite.findall("testcase")
        count = int(suite.get("tests", "0"))
        if count != len(cases) or count <= 0:
            fail("test case count mismatch: " + name)
        if any(case.find(tag) is not None for case in cases for tag in ("failure", "error", "skipped")):
            fail("test case failure is present: " + name)
        rows[name] = count
    for name, minimum in REQUIRED_SUITES.items():
        if rows.get(name, 0) < minimum:
            fail("required regression suite missing or incomplete: " + name)
    # Every current test class must be represented, including newly added tests.
    for source in (project / "app/src/test").rglob("*"):
        if source.suffix not in (".kt", ".java"):
            continue
        text = source.read_text()
        if "@Test" not in text and "@org.junit.Test" not in text:
            continue
        classes = re.findall(r"\bclass\s+(\w+Test)\b", text)
        for name in classes:
            if not any(key == name or key.endswith("." + name) for key in rows):
                fail("current test source not executed: " + name)
    return {"status": "PASS", "tests": sum(rows.values()), "failed": 0, "skipped": 0, "suites": rows}


def verify_apk_assets(apk, project):
    source = project / "app/src/main/assets"
    expected = {"assets/" + str(p.relative_to(source)).replace(os.sep, "/"): p
                for p in source.rglob("*") if p.is_file()}
    if not expected or not any(name.startswith("assets/october_similarity/") for name in expected):
        fail("October similarity assets are missing from the current source")
    if not {"assets/october_chart_rank/index.bin.gz.part01", "assets/october_chart_rank/index.bin.gz.part02", "assets/october_chart_rank/chart_rank_manifest.json"} <= set(expected):
        fail("October chart rank assets are missing from the current source")
    records = []
    with zipfile.ZipFile(apk) as packaged:
        names = packaged.namelist()
        if len(names) != len(set(names)):
            fail("duplicate APK ZIP members")
        actual = {name for name in names if name.startswith("assets/") and not name.endswith("/")}
        generated = actual - set(expected)
        if generated - {"assets/dexopt/baseline.prof", "assets/dexopt/baseline.profm"}:
            fail("APK contains unexpected asset files")
        if actual - generated != set(expected):
            fail("APK asset set differs from source")
        for name, path in sorted(expected.items()):
            digest = hashlib.sha256(packaged.read(name)).hexdigest()
            if digest != sha256(path):
                fail("packaged asset differs from audited source: " + name)
            records.append({"asset": name, "bytes": path.stat().st_size, "sha256": digest})
    return {"status": "PASS", "scope": "ALL_PACKAGED_SOURCE_ASSET_BYTES", "assets_verified": len(records),
            "android_generated_profile_assets": sorted(generated), "results": records}


def build(project, workspace):
    signing_mode()
    verify_version(project)
    verify_package_manifest(project)
    sdk = Path(os.environ.get("ANDROID_HOME", os.environ.get("ANDROID_SDK_ROOT", "")))
    if not (sdk / "platforms/android-35/android.jar").is_file():
        fail("Android SDK 35 platform is missing")
    for tool in ("apksigner", "aapt", "zipalign"):
        if not (sdk / "build-tools/35.0.0" / tool).is_file():
            fail("Android build-tools 35.0.0 are missing: " + tool)
    run([sys.executable, "tools/audit_v0742.py"], project)
    with (workspace / "build-environment.log").open("w") as environment:
        for command in (["java", "-version"], ["javac", "-version"], ["gradle", "--version"]):
            checked = subprocess.run(command, check=True, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True)
            environment.write(checked.stdout)
            print(checked.stdout, end="")
        environment.write("Android SDK 35 / build-tools 35.0.0 verified\n")
    with (workspace / "gradle-build.log").open("w") as log:
        process = subprocess.Popen(["gradle", ":app:testDebugUnitTest", ":app:lintRelease",
                                    ":app:assembleRelease", ":app:assembleDebug", "--no-daemon",
                                    "--stacktrace", "--console=plain"], cwd=project,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            print(line, end="", flush=True)
            log.write(line)
        if process.wait() != 0:
            fail("Gradle build or tests failed; inspect gradle-build.log")
    result = verify_tests(project)
    (workspace / "test-verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


def sign_production(apksigner, key, release, verified):
    # Signing diagnostics may repeat secret aliases or environment password values.
    # Keep subprocess output private and report a useful generic error instead.
    signed = subprocess.run([str(apksigner), "sign", "--ks", str(key),
        "--ks-key-alias", os.environ["KEY_ALIAS"], "--ks-pass", "env:STORE_PASSWORD",
        "--key-pass", "env:KEY_PASSWORD", "--out", str(verified), str(release)],
        capture_output=True, text=True)
    if signed.returncode:
        verified.unlink(missing_ok=True)
        fail("production signing failed (exit code " + str(signed.returncode) +
             "); verify the supplied keystore, alias and passwords")


def package(project, workspace, temporary):
    mode = signing_mode()
    verify_version(project)
    tests = verify_tests(project)
    sdk = Path(os.environ.get("ANDROID_HOME", os.environ.get("ANDROID_SDK_ROOT", "")))
    tools = sdk / "build-tools/35.0.0"
    out = workspace / "artifacts"
    out.mkdir(parents=True, exist_ok=True)
    debug = project / "app/build/outputs/apk/debug/app-debug.apk"
    release = project / "app/build/outputs/apk/release/app-release-unsigned.apk"
    if not debug.is_file() or not release.is_file():
        fail("both fresh debug and unsigned release APKs are required")
    verify_apk_assets(debug, project)
    verify_apk_assets(release, project)
    release_metadata = subprocess.run([str(tools / "aapt"), "dump", "badging", str(release)],
                                      check=True, capture_output=True, text=True).stdout
    release_required = [f"package: name='{APPLICATION_ID}' versionCode='{VERSION_CODE}' versionName='{VERSION_NAME}'",
                        "sdkVersion:'26'", "targetSdkVersion:'35'"]
    if not all(value in release_metadata for value in release_required):
        fail("unsigned release APK package id/version/SDK metadata differs from audited source")
    (out / "unsigned-release-package.txt").write_text(release_metadata)
    if mode == "supplied-production-key":
        temporary.mkdir(parents=True, exist_ok=True)
        key = temporary / "gmk-v0742.keystore"
        key.write_bytes(base64.b64decode("".join(os.environ["KEYSTORE_B64"].split()), validate=True))
        key.chmod(0o600)
        verified = out / "GMK_MOBILE_V0742_PRODUCTION.apk"
        try:
            sign_production(tools / "apksigner", key, release, verified)
        finally:
            key.unlink(missing_ok=True)
    else:
        verified = out / "GMK_MOBILE_V0742_TEST_ONLY.apk"
        shutil.copyfile(debug, verified)
        shutil.copyfile(release, out / "GMK_MOBILE_V0742_RELEASE_UNSIGNED.apk")
    signature = subprocess.run([str(tools / "apksigner"), "verify", "--verbose", "--print-certs", str(verified)],
                               check=True, capture_output=True, text=True).stdout
    (out / "signature.txt").write_text(signature)
    expected = os.environ.get("EXPECTED_CERT_SHA256", "").replace(":", "").lower()
    certs = re.findall(r"certificate SHA-256 digest:\s*([0-9a-fA-F]+)", signature)
    if expected and (len(certs) != 1 or certs[0].lower() != expected):
        verified.unlink(missing_ok=True)
        fail("signing certificate differs from the installed production certificate")
    metadata = subprocess.run([str(tools / "aapt"), "dump", "badging", str(verified)],
                              check=True, capture_output=True, text=True).stdout
    (out / "package.txt").write_text(metadata)
    expected_id = APPLICATION_ID if mode == "supplied-production-key" else APPLICATION_ID + ".test"
    expected_name = VERSION_NAME if mode == "supplied-production-key" else VERSION_NAME + "-test"
    required = [f"package: name='{expected_id}' versionCode='{VERSION_CODE}' versionName='{expected_name}'",
                "sdkVersion:'26'", "targetSdkVersion:'35'"]
    if not all(value in metadata for value in required):
        verified.unlink(missing_ok=True)
        fail("APK package id/version/SDK metadata differs from audited source")
    assets = verify_apk_assets(verified, project)
    (out / "model-verification.json").write_text(json.dumps(assets, indent=2) + "\n")
    (out / "test-verification.json").write_text(json.dumps(tests, indent=2) + "\n")
    (out / "signing-mode.txt").write_text(mode + "\n")
    (out / "release-verification.json").write_text(json.dumps({"status": "PASS", "version": VERSION_NAME,
        "signing_mode": mode, "existing_certificate_matched": bool(expected), "generated_production_key": False,
        "production_application_id": APPLICATION_ID, "verified_application_id": expected_id,
        "unsigned_release_package_metadata_verified": True,
        "test_apk_installs_separately": mode != "supplied-production-key",
        "installable_update_requires_same_existing_signing_certificate": True}, indent=2) + "\n")
    for name in ("gradle-build.log", "build-environment.log"):
        if (workspace / name).is_file():
            shutil.copyfile(workspace / name, out / name)
    for report in (project / "app/build/test-results/testDebugUnitTest").glob("TEST*.xml"):
        shutil.copyfile(report, out / report.name)
    (out / "SHA256.txt").write_text("".join(sha256(p) + "  " + p.name + "\n" for p in sorted(out.glob("*.apk"))))
    print("Verified " + verified.name + "; signing mode=" + mode)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "build", "package", "verify-tests"))
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    parser.add_argument("--temporary", type=Path, default=Path(os.environ.get("RUNNER_TEMP", tempfile.gettempdir())))
    parser.add_argument("--project", type=Path, default=None)
    args = parser.parse_args()
    try:
        project = args.project or Path(os.environ.get("GMK_PROJECT", Path(__file__).resolve().parents[1]))
        project = checked_path(project)
        workspace = checked_path(args.workspace)
        if args.command == "prepare":
            prepare(workspace, args.temporary)
        elif args.command == "build":
            build(project, workspace)
        elif args.command == "package":
            package(project, workspace, args.temporary)
        else:
            print(json.dumps(verify_tests(project)))
    except (OSError, ValueError, KeyError, zipfile.BadZipFile, subprocess.CalledProcessError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()

package jp.gmk.mobile.domain

import java.util.Locale

/** Which existing classifier branch ran. These tags are explanatory, not a new policy. */
enum class RuleSelectionStage {
    LEGACY_BASE, BASE_UNMATCHED, TIME_WINDOW, REMAPPED,
    RESCUE_STAGE1, RESCUE_STAGE2, REMAP_RESCUE_REJECTED, UNMATCHED_RESCUE_FAILED
}

enum class CandidateSkipReason(val label: String) {
    TIME_WINDOW("時間外"),
    RULE_UNMATCHED("旧ルール未一致"),
    UNMATCHED_RESCUE_FAILED("ルール未一致・救済不成立"),
    REMAP_RESCUE_REJECTED("旧ルール再マップ拒否・救済不成立"),
    AI_GATE_REJECTED("AIゲート見送り"),
    QUOTE_UNSAFE("レート安全性不足"),
    UNKNOWN("理由未記録")
}

/** Immutable native/chosen action trace. A rule grade is not a calibrated strength. */
data class CandidateActionTrace(
    val instrument: String,
    val direction: String,
    val legacyRuleGrade: String,
    val legacyRuleId: Int?,
    val operationalRuleId: Int?,
    val operationalGrade: String,
    val decision: String,
    val judgeMinutes: Int
)

/** Frozen chart-neighbour estimate. This metadata never supplies an ENTRY or direction. */
data class ChartRankAssessment(
    val grade: String,
    val rawProbability: Double?,
    val calibratedProbability: Double?,
    val supportN: Int,
    val referenceDates: Int,
    val effectiveSampleSize: Double?,
    val statusReason: String,
    val snapshotId: String,
    val modelVersion: String,
    /** Query entry boundary, in Unix UTC seconds. */
    val queryBoundaryUtc: Long,
    val direction: String,
    val shrunkProbability: Double? = null,
    val validationStatus: String = "UNVALIDATED"
) {
    val gradeLabel: String get() = if (grade == "UNRANKED") "保留" else grade
    val statusReasonLabel: String get() = when {
        statusReason == "OUTSIDE_VALIDATED_RESEARCH_SCOPE" || statusReason == "OUTSIDE_RESEARCH_SCOPE" -> "対象通貨・時間帯・判定時間の範囲外"
        statusReason == "OUT_OF_CALIBRATION_RANGE" -> "過去の校正範囲外"
        statusReason == "INSUFFICIENT_REAL_CHART_SUPPORT" -> "類似履歴の件数・日数が不足"
        statusReason == "INSUFFICIENT_REAL_CALIBRATION_CASES" -> "実測で校正できる件数が不足"
        statusReason == "MISSING_CONTIGUOUS_61_M1_BARS" -> "直前チャートの連続した足が不足"
        statusReason == "CHART_INPUT_REVISED" -> "準備後に直前チャートが更新されたため"
        statusReason.endsWith("DEADLINE") -> "判定時刻までに参照が完了しなかったため"
        statusReason.contains("FRAME") || statusReason == "WARMING" -> "類似履歴の参照準備が未完了"
        statusReason.startsWith("INVALID_CHART_INPUT") -> "直前チャートを安全に比較できないため"
        else -> "推定条件を満たしていないため"
    }
    val displayLabel: String get() {
        val estimate = calibratedProbability?.takeIf { it.isFinite() && it in 0.0..1.0 }
            ?.let { String.format(Locale.JAPAN, "推定 %.1f%% / ", it * 100.0) }.orEmpty()
        return "類似ランク $gradeLabel / ${estimate}参照${supportN}件（強弱未検証）"
    }
    val evidenceLabel: String get() {
        val raw = rawProbability?.takeIf { it.isFinite() && it in 0.0..1.0 }
            ?.let { String.format(Locale.JAPAN, "類似履歴 %.1f%% / ", it * 100.0) }.orEmpty()
        val effective = effectiveSampleSize?.takeIf { it.isFinite() && it >= 0.0 }
            ?.let { String.format(Locale.JAPAN, " / 有効件数 %.1f", it) }.orEmpty()
        return "${raw}${referenceDates}日参照$effective"
    }
}

object ChartRankDisplay {
    /** Keep unsupported grades visible even when no current row belongs to them. */
    val grades = listOf("E", "F", "G", "H", "UNRANKED")
    val filters = listOf("すべて", "E", "F", "G", "H", "保留", "未記録")
    fun matches(assessment: CandidateAssessment?, filter: String): Boolean = when (filter) {
        "すべて" -> true
        "保留" -> assessment?.chartRank?.grade == "UNRANKED"
        "未記録" -> assessment?.chartRank == null
        else -> assessment?.chartRank?.grade == filter
    }
}

/** Separates native/operational action from an optional, unvalidated chart estimate. */
data class CandidateAssessment(
    val legacyRuleGrade: String,
    val legacyRuleId: Int?,
    val operationalRuleId: Int?,
    val operationalGrade: String,
    val decision: String,
    val selectionStage: RuleSelectionStage,
    val skipReason: CandidateSkipReason?,
    val gateScore: Double?,
    val historicalExpectedRate: Double?,
    val historicalSampleSize: Int?,
    val originalAction: CandidateActionTrace,
    val chosenAction: CandidateActionTrace,
    val correctionSourceAction: CandidateActionTrace? = null,
    val correctionLabel: String? = null,
    val chartRank: ChartRankAssessment? = null
) {
    val strengthStatus: String get() = "UNVALIDATED"
    val strengthLabel: String get() = chartRank?.displayLabel ?: "検証待ち"
    val historicalRateLabel: String get() {
        val rate = historicalExpectedRate
        val count = historicalSampleSize
        return if (rate != null && rate.isFinite() && rate in 0.0..1.0 && count != null && count > 0) {
            val prefix = if (correctionLabel == null) "過去ルール統計" else "補正前の過去ルール統計"
            String.format(Locale.JAPAN, "%s: %.1f%% (n=%d)", prefix, rate * 100.0, count)
        } else "過去ルール統計: 未記録"
    }
}

object CandidateAssessmentFactory {
    fun native(
        instrument: String,
        direction: String,
        base: FinalRankPolicy.Match,
        policy: FinalRankPolicy.Match,
        operationalGrade: String,
        decision: String,
        gateScore: Double?,
        gateRejected: Boolean,
        judgeMinutes: Int = 3
    ): CandidateAssessment {
        val reason = if (decision != "SKIP") null else when {
            gateRejected -> CandidateSkipReason.AI_GATE_REJECTED
            policy.selectionStage == RuleSelectionStage.TIME_WINDOW -> CandidateSkipReason.TIME_WINDOW
            policy.selectionStage == RuleSelectionStage.REMAP_RESCUE_REJECTED -> CandidateSkipReason.REMAP_RESCUE_REJECTED
            policy.selectionStage == RuleSelectionStage.UNMATCHED_RESCUE_FAILED -> CandidateSkipReason.UNMATCHED_RESCUE_FAILED
            policy.selectionStage == RuleSelectionStage.BASE_UNMATCHED -> CandidateSkipReason.RULE_UNMATCHED
            else -> CandidateSkipReason.UNKNOWN
        }
        val baseId = base.ruleId.takeIf { it >= 0 }
        val policyId = policy.ruleId.takeIf { it >= 0 }
        val sampled = policy.sampleSize > 0 && policy.expectedWinRate.isFinite() && policy.expectedWinRate in 0.0..1.0
        val trace = CandidateActionTrace(instrument, direction, base.rank, baseId, policyId, operationalGrade, decision, judgeMinutes)
        return CandidateAssessment(
            base.rank, baseId, policyId, operationalGrade, decision, policy.selectionStage,
            reason, gateScore?.takeIf { it.isFinite() },
            policy.expectedWinRate.takeIf { sampled }, policy.sampleSize.takeIf { sampled }, trace, trace
        )
    }

    /** Preserve both the selected target's native origin and the C TOP1 that triggered routing. */
    fun similarityCorrection(
        target: ScanCandidate,
        sourceTop1: ScanCandidate,
        direction: String,
        judgeMinutes: Int
    ): CandidateAssessment {
        return correction(target, sourceTop1, direction, "C", "ENTRY", judgeMinutes,
            "同通貨・曜日・時間帯の類似100件でC補正")
    }

    fun correction(
        target: ScanCandidate,
        sourceTop1: ScanCandidate,
        direction: String,
        grade: String,
        decision: String,
        judgeMinutes: Int,
        label: String,
        skipReason: CandidateSkipReason? = null
    ): CandidateAssessment {
        val existing = target.assessment
        val original = existing?.originalAction ?: target.actionTrace(3)
        val source = sourceTop1.assessment?.chosenAction ?: sourceTop1.actionTrace(3)
        val chosen = original.copy(direction = direction, operationalGrade = grade, decision = decision, judgeMinutes = judgeMinutes)
        return CandidateAssessment(
            existing?.legacyRuleGrade ?: "未記録",
            existing?.legacyRuleId,
            existing?.operationalRuleId,
            grade, decision, existing?.selectionStage ?: RuleSelectionStage.LEGACY_BASE,
            if (decision == "SKIP") skipReason ?: CandidateSkipReason.UNKNOWN else null, existing?.gateScore,
            // A rerouted action is not the action on which the rule average was measured.
            // Keep its rule statistic in the original trace/metadata; strength remains unvalidated.
            existing?.historicalExpectedRate, existing?.historicalSampleSize,
            original, chosen, source, label,
            // A stored chart estimate is about one direction and expiry. Never carry it
            // onto a newly reversed action; the runtime may attach a fresh estimate later.
            existing?.chartRank?.takeIf {
                existing.chosenAction.direction == direction &&
                    existing.chosenAction.instrument == chosen.instrument &&
                    existing.chosenAction.judgeMinutes == judgeMinutes
            }
        )
    }

    private fun ScanCandidate.actionTrace(minutes: Int) = CandidateActionTrace(
        instrument, direction, "未記録", null, null, grade, decision, minutes
    )
}

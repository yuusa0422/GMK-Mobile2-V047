package jp.gmk.mobile.data

import android.content.Context
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import jp.gmk.mobile.domain.r13.*
import jp.gmk.mobile.domain.direct19.*
import jp.gmk.mobile.domain.october.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicReference

/** Prepares slow inputs outside the scan. No model network request is made by apply(). */
class HorizonRuntime(context: Context, private val repository: MarketRepository,
    assetBytes: ((String)->ByteArray)? = null,
    private val epochMillis: ()->Long = System::currentTimeMillis) {
    private val app=context.applicationContext
    private val hasInjectedAssetBytes=assetBytes!=null
    private val assetBytes: (String)->ByteArray=assetBytes ?: { path -> app.assets.open(path).use { it.readBytes() } }
    private val prefs=app.getSharedPreferences("gmk_horizon_policy",Context.MODE_PRIVATE)
    private val cache=HorizonMarketCache(File(app.filesDir,"horizon_history_v1"))
    private val prepared=AtomicReference<PreparedHorizonFrame?>(null)
    private val preparedDirect=AtomicReference<Direct19Frame?>(null)
    private val preparedOctober=AtomicReference<OctoberSimilarityFrame?>(null)
    private val preparedChartRank=AtomicReference<ChartConditionalRankFrame?>(null)
    @Volatile private var chartRank=ChartConditionalRankAdapter(null,epochMillis)
    @Volatile private var chartRankLoadStatus="STARTING"
    @Volatile private var october: OctoberSimilarityScanAdapter?=null
    @Volatile private var octoberLoadStatus="STARTING"
    @Volatile private var octoberReadySymbols=0
    @Volatile private var direct19: Direct19ScanAdapter?=null
    @Volatile private var direct19LoadStatus="STARTING"
    @Volatile private var adapter: HorizonScanAdapter?=null
    @Volatile private var r13: R13ScanAdapter?=null
    @Volatile private var r13LoadStatus="STARTING"
    private var pendingState: HorizonAdapterState?=null
    private var pendingScanId=""
    private var lastLegacyNative: ScanResult?=null
    private var pendingLegacyNative: ScanResult?=null
    private val coverageVersion="MOBILE_V0734_PC_R9"
    @Volatile private var backgroundStatus="STARTING"
    @Volatile private var legacyModelLoadStatus="STARTING"
    @Volatile private var applicationStatus="NOT_EVALUATED"
    @Volatile private var direct19ReadySymbols=0
    @Volatile private var prepareMs=0.0
    @Volatile private var quoteStatus="NOT_CAPTURED"
    private var job: Job?=null
    private var chartRankPreparation: Job?=null
    fun observe(rows: List<RateRow>)=cache.observe(rows)
    fun start(scope: CoroutineScope, enabled: ()->Boolean, scanIdle: ()->Boolean) {
        if(job?.isActive==true)return
        job=scope.launch(Dispatchers.Default) {
            try {
                val index=if(hasInjectedAssetBytes)OctoberSimilarityCatalog.loadIndex(assetBytes)
                    else OctoberSimilarityCatalog.loadIndex(app.assets)
                october=OctoberSimilarityScanAdapter(index,File(app.filesDir,"october_observed_m1.bin"),epochMillis)
                octoberLoadStatus="LOADED"
            } catch(e: Exception) {
                if(e is CancellationException)throw e
                octoberLoadStatus="MODEL_UNAVAILABLE:${e.javaClass.simpleName}"
            } catch(e: OutOfMemoryError) {
                // This optional catalogue must not stop the existing native pipeline.
                october=null
                preparedOctober.set(null)
                octoberLoadStatus="MODEL_RESOURCE_LIMIT:${e.javaClass.simpleName}"
            }
            try {
                fun model(name: String)=Direct19Model.load(assetBytes("direct19/$name"),Direct19Catalog.hashes.getValue(name))
                direct19=Direct19ScanAdapter(model("hgb_3m.bin"),model("hgb_5m.bin"));direct19LoadStatus="LOADED"
            } catch(e: Exception) {
                if(e is CancellationException)throw e
                direct19LoadStatus="MODEL_UNAVAILABLE:${e.javaClass.simpleName}"
            }
            try {
                val index=if(hasInjectedAssetBytes)ChartConditionalRankCatalog.loadIndex(assetBytes)
                    else ChartConditionalRankCatalog.loadIndex(app.assets)
                chartRank=ChartConditionalRankAdapter(index,epochMillis)
                chartRankLoadStatus="LOADED"
            } catch(e: Exception) {
                if(e is CancellationException)throw e
                chartRankLoadStatus="MODEL_UNAVAILABLE:${e.javaClass.simpleName}"
            } catch(e: OutOfMemoryError) {
                preparedChartRank.set(null)
                chartRankLoadStatus="MODEL_RESOURCE_LIMIT:${e.javaClass.simpleName}"
            }
            try {
                fun load(name: String)=PortableTreeModel.load(assetBytes("horizon_policy/$name"),HorizonModelCatalog.hashes.getValue(name))
                val saved=if(prefs.getString("version","")==coverageVersion)prefs.getString("scores","").orEmpty().split(',').mapNotNull { it.toDoubleOrNull() } else emptyList()
                val baseModels=listOf(load("base_3m.bin"),load("base_10m.bin"),load("base_15m.bin"))
                adapter=HorizonScanAdapter(baseModels,load("r15_path_protect15.bin"),saved,epochMillis)
                try {
                    fun bytes(name: String)=assetBytes("pc_r13/$name.bin")
                    val neural=listOf("TCN","M1_TCN","M1_LSTM","M1_LINEAR").associateWith {
                        R13Models.Neural(bytes(it),R13Catalog.hashes.getValue(it))
                    }
                    val frameStore=R13FrameStore(File(app.filesDir,"pc_r13_frames_v1.bin"))
                    withContext(Dispatchers.IO) { runCatching { frameStore.load() }.onFailure { r13LoadStatus="HISTORY_RESET:${it.javaClass.simpleName}" } }
                    r13=R13ScanAdapter(neural,R13Models.Xgb(bytes("XGB"),R13Catalog.hashes.getValue("XGB")),baseModels,frameStore)
                    if(r13LoadStatus=="STARTING")r13LoadStatus="LOADED"
                } catch(e: Exception) {
                    if(e is CancellationException)throw e
                    r13LoadStatus="MODELS_UNAVAILABLE:${e.javaClass.simpleName}"
                }
                legacyModelLoadStatus="LOADED"
            } catch(e: Exception) {
                if(e is CancellationException)throw e
                legacyModelLoadStatus="MODELS_UNAVAILABLE:${e.javaClass.simpleName}"
                if(r13==null)r13LoadStatus="BASE_MODELS_UNAVAILABLE:${e.javaClass.simpleName}"
            }
            // Price history belongs to both inference paths. A legacy model failure
            // must not prevent a healthy Direct19 model from restoring its inputs.
            withContext(Dispatchers.IO) { HorizonFeatureService.SYMBOLS.forEach { cache.load(it,epochMillis()) } }
            backgroundStatus="WARMING"
            var cursor=0;var bitcoinDay=0;var attemptedBoundary=0L;var quoteBoundary=0L
            val lastFetch=HashMap<String,Long>()
            while(isActive) {
                var now=epochMillis()
                val boundary=(now/300_000+1)*300L
                if(!enabled() || !HorizonFeatureService.scheduled(boundary)) {
                    prepared.set(null);preparedDirect.set(null);preparedOctober.set(null);preparedChartRank.set(null);backgroundStatus="INACTIVE";delay(1000);continue
                }
                var remaining=boundary-now/1000
                if(remaining in 15..25 && boundary!=attemptedBoundary && HorizonFeatureService.scheduled(boundary)) {
                    attemptedBoundary=boundary
                    val began=System.nanoTime()
                    try {
                        preparedChartRank.set(null)
                        if(OctoberSimilarityScanAdapter.supports(boundary)) {
                            try {
                                preparedOctober.set(null)
                                val frame=october?.prepare(cache.snapshot(),boundary)?.copy(preparedMs=epochMillis())
                                if(epochMillis()<(boundary-10)*1000)preparedOctober.set(frame)
                                octoberReadySymbols=frame?.eligible?.count { it } ?: 0
                                backgroundStatus=if(octoberReadySymbols==0)"OCTOBER_WARMING" else "OCTOBER_FRAME_READY"
                            } catch(e: OutOfMemoryError) {
                                october=null;preparedOctober.set(null);octoberReadySymbols=0
                                octoberLoadStatus="MODEL_RESOURCE_LIMIT:${e.javaClass.simpleName}"
                                backgroundStatus="OCTOBER_RESOURCE_LIMIT_NATIVE_CONTINUES"
                            }
                        } else if(Direct19ScanAdapter.supports(boundary)) {
                            val frame=direct19?.prepare(cache.snapshot(),boundary)?.copy(preparedMs=epochMillis())
                            if(epochMillis()<(boundary-10)*1000)preparedDirect.set(frame)
                            direct19ReadySymbols=frame?.input?.eligible?.count { it } ?: 0
                            backgroundStatus=if(direct19ReadySymbols==0)"DIRECT19_WARMING" else "DIRECT19_FRAME_READY"
                        } else {
                            val frame=adapter?.prepare(cache.snapshot(),boundary)
                            if(epochMillis()<(boundary-10)*1000)prepared.set(frame)
                            backgroundStatus=if(frame==null)"WARMING_DATA" else if(frame.service.ready)"FRAME_READY" else "FRAME_CONTEXT_WARMING"
                        }
                        // Original action preparation and quote refresh retain priority.
                        // Optional rank retrieval runs in a child job, outside publication.
                        if(chartRankLoadStatus=="LOADED" && ChartConditionalRankAdapter.supports(boundary)) {
                            val prices=cache.snapshot()
                            chartRankPreparation?.cancel()
                            chartRankPreparation=launch(Dispatchers.Default) {
                                try {
                                    val frame=chartRank.prepare(prices,boundary)
                                    if(isActive && enabled() && epochMillis()<(boundary-10)*1000)preparedChartRank.set(frame)
                                } catch(e: OutOfMemoryError) {
                                    preparedChartRank.set(null)
                                    chartRank=ChartConditionalRankAdapter(null,epochMillis)
                                    chartRankLoadStatus="MODEL_RESOURCE_LIMIT:${e.javaClass.simpleName}"
                                } catch(e: Exception) {
                                    if(e is CancellationException)throw e
                                    preparedChartRank.set(null)
                                }
                            }
                        }
                    } catch(e: Exception) {
                        if(e is CancellationException)throw e
                        backgroundStatus="PREPARE_UNAVAILABLE:${e.javaClass.simpleName}"
                    }
                    prepareMs=(System.nanoTime()-began)/1e6
                }
                now=epochMillis()
                val quoteBudget=HorizonTimingPolicy.quoteBudgetMs(now,boundary)
                if(quoteBudget>0 && quoteBoundary!=boundary && enabled() && scanIdle()) {
                    quoteBoundary=boundary
                    try {
                        val rows=withTimeout(quoteBudget) { repository.fetchRates() }
                        cache.observe(rows)
                        quoteStatus="CAPTURED:${rows.count { it.freshnessStatus=="LIVE" }}"
                    } catch(e: TimeoutCancellationException) { quoteStatus="TIMEOUT_NATIVE_CONTINUES" }
                    catch(e: CancellationException) { throw e }
                    catch(e: Exception) { quoteStatus="UNAVAILABLE:${e.javaClass.simpleName}" }
                }
                // History ends before :40. The bounded :41..:45 quote request ends before :50.
                now=epochMillis();remaining=boundary-now/1000
                val second=now/1000%60
                if(second in 6..35 && enabled() && scanIdle()) {
                    // The October policy needs the common four first. Other schedules
                    // retain the full historical symbol rotation for the original models.
                    val historySymbols=if(OctoberSimilarityScanAdapter.supports(boundary))OctoberSimilarityIndex.TRADED.toList()+HorizonFeatureService.SYMBOLS else HorizonFeatureService.SYMBOLS
                    val symbol=historySymbols[cursor++%historySymbols.size]
                    val warm=cache.size(symbol)<4000
                    if((warm || remaining<=60) && now-(lastFetch[symbol] ?: 0L)>25_000) {
                        try {
                            val day=if(symbol=="BTCJPY" && warm)bitcoinDay++%5 else 0
                            val rows=withTimeout(3500) { repository.fetchHorizonHistory(symbol,warm,day) }
                            cache.merge(symbol,rows,epochMillis())
                            withContext(Dispatchers.IO) { cache.persist(symbol) }
                            lastFetch[symbol]=now
                        } catch(e: TimeoutCancellationException) { backgroundStatus="FETCH_TIMEOUT_NATIVE_CONTINUES" }
                        catch(e: CancellationException) { throw e }
                        catch(e: Exception) { backgroundStatus="FETCH_UNAVAILABLE:${e.javaClass.simpleName}";lastFetch[symbol]=now }
                    }
                }
                delay(250)
            }
        }
    }
    @Synchronized
    fun apply(native: ScanResult,candles: Map<String,List<Candle>>, fixedThreeMinute: Boolean=false): ScanResult {
        val selected=applyOperational(native,candles,fixedThreeMinute)
        // The immutable, boundary/input-bound frame also serves accepted retries.
        return chartRank.apply(native,selected,candles,preparedChartRank.get(),
            if(chartRankLoadStatus=="LOADED")"FRAME_NOT_READY" else chartRankLoadStatus)
    }
    private fun applyOperational(native: ScanResult,candles: Map<String,List<Candle>>, fixedThreeMinute: Boolean): ScanResult {
        if(native.source!="AUTO")return native
        val boundary=runCatching { java.time.ZonedDateTime.parse(native.entryTimeJst).toEpochSecond() }.getOrNull() ?: return native
        if(OctoberSimilarityScanAdapter.supports(boundary)) {
            pendingState=null;pendingScanId=native.scanId
            val frame=preparedOctober.getAndSet(null)
            val corrected=try {
                val quotes=cache.quoteSnapshot((boundary-10)*1000)
                october?.apply(native,candles,frame,quotes,fixedThreeMinute,epochMillis())
            } catch(e: OutOfMemoryError) {
                october=null;preparedOctober.set(null);octoberReadySymbols=0
                octoberLoadStatus="MODEL_RESOURCE_LIMIT:${e.javaClass.simpleName}"
                backgroundStatus="OCTOBER_RESOURCE_LIMIT_NATIVE_CONTINUES"
                null
            }
            val result=corrected ?: native.copy(policyVersion=OctoberSimilarityScanAdapter.FALLBACK+if(fixedThreeMinute)"_3M_FIXED" else "")
            applicationStatus=october?.status ?: octoberLoadStatus
            return result
        }
        if(Direct19ScanAdapter.supports(boundary)) {
            pendingState=null;pendingScanId=native.scanId
            val frame=preparedDirect.getAndSet(null)
            val quotes=cache.quoteSnapshot((boundary-10)*1000)
            val result=direct19?.apply(native,candles,frame,quotes,fixedThreeMinute,epochMillis())
                ?: native.copy(policyVersion=Direct19ScanAdapter.FALLBACK+if(fixedThreeMinute)"_3M_FIXED" else "")
            applicationStatus=direct19?.status ?: direct19LoadStatus
            return result
        }
        val policy=adapter ?: return ExpiryProfiles.apply(native.copy(policyVersion="GMK_V0736_R9_FALLBACK"),fixedThreeMinute).also { applicationStatus=legacyModelLoadStatus }
        val checkpoint=policy.checkpointState()
        // The legacy adapter caches by boundary. A retried/revised native scan
        // cannot inherit another proposal's identity or ENTRY decision.
        if(checkpoint.boundary==boundary && lastLegacyNative!=native) {
            applicationStatus="NATIVE_REVISION_LEGACY_FALLBACK"
            return ExpiryProfiles.apply(native.copy(policyVersion="GMK_V0736_R9_FALLBACK"),fixedThreeMinute)
        }
        val frame=prepared.getAndSet(null)
        val quotes=cache.quoteSnapshot((boundary-10)*1000)
        pendingState=checkpoint;pendingLegacyNative=lastLegacyNative;pendingScanId=native.scanId
        val base=policy.apply(native,candles,frame,quotes,epochMillis())
        lastLegacyNative=native
        val result=r13?.apply(base,native,frame,quotes,candles) ?: base.copy(policyVersion=R13ScanAdapter.FALLBACK)
        check(result.scanId==native.scanId && result.entryTimeJst==native.entryTimeJst && result.source==native.source)
        applicationStatus=r13?.status ?: policy.status
        return ExpiryProfiles.apply(result.copy(policyVersion=result.policyVersion.replace("GMK_V0735","GMK_V0736").replace("GMK_V0734","GMK_V0736")),fixedThreeMinute)
    }
    /** Persist policy state only after the accepted scan has been journalled. */
    @Synchronized
    fun commit(scanId: String) {
        if(scanId!=pendingScanId)return
        adapter?.let { policy -> prefs.edit().putString("version",coverageVersion).putString("scores",policy.snapshot().joinToString(",")).apply() }
        r13?.commit(scanId)
        direct19?.commit(scanId)
        october?.commit(scanId)
        pendingState=null;pendingLegacyNative=null;pendingScanId=""
    }
    @Synchronized
    fun discardPending() {
        pendingState?.let { adapter?.restoreState(it);lastLegacyNative=pendingLegacyNative }
        pendingState=null;pendingLegacyNative=null;pendingScanId="";r13?.discardPending();direct19?.discardPending();october?.discardPending()
    }
    fun diagnosticStats(): JSONObject=JSONObject().put("version",HorizonModelCatalog.VERSION)
        .put("chart_conditional_rank",JSONObject().put("version",ChartConditionalRankIndex.VERSION)
            .put("load_status",chartRankLoadStatus).put("status",chartRank.status)
            .put("last_grade",chartRank.lastGrade).put("supported_grades",org.json.JSONArray(listOf("E","F","G","H","UNRANKED")))
            .put("prepare_ms",chartRank.prepareMs).put("inference_ms",chartRank.inferenceMs)
            .put("snapshot_epoch",ChartConditionalRankIndex.SNAPSHOT_UTC)
            .put("historical_rows",270501).put("references_per_query",200)
            .put("scope","2026_OCTOBER_WEEKDAYS_JST_09_15_FOUR_FX_NATIVE_TOP1_E_3M")
            .put("uses_month_weekday_hour_for_similarity",false).put("strength_status","UNVALIDATED"))
        .put("october_similarity",JSONObject().put("version",OctoberSimilarityIndex.VERSION)
            .put("policy","TECH_WEEKDAY_HOUR_K100__C_M10").put("load_status",octoberLoadStatus)
            .put("status",october?.status ?: "UNAVAILABLE").put("changed",october?.changed ?: false)
            .put("ready_symbols",octoberReadySymbols).put("prepare_ms",october?.prepareMs ?: JSONObject.NULL)
            .put("inference_ms",october?.inferenceMs ?: JSONObject.NULL)
            .put("snapshot_epoch",october?.snapshotEpoch ?: JSONObject.NULL)
            .put("latest_training_label_epoch",october?.latestTrainingLabelEpoch ?: JSONObject.NULL)
            .put("bundled_last_boundary",october?.bundledLastBoundary ?: JSONObject.NULL)
            .put("live_observed_rows",october?.liveObservationCount ?: 0)
            .put("live_journal_status",october?.journalStatus ?: "UNAVAILABLE")
            .put("scope","OCTOBER_JST_WEEKDAYS_09_17_COMMON_FOUR_C")
            .put("available_from_epoch",OctoberSimilarityCatalog.AVAILABLE_FROM)
            .put("preserves_native_entry_mask",true).put("preserves_native_SAB",true)
            .put("horizon_minutes",org.json.JSONArray(listOf(3,5))))
        .put("direct19",JSONObject().put("version",Direct19Policy.VERSION).put("policy",Direct19Policy.POLICY)
            .put("load_status",direct19LoadStatus).put("status",direct19?.status ?: "UNAVAILABLE")
            .put("changed",direct19?.status=="APPLIED").put("ready_symbols",direct19ReadySymbols).put("prepare_ms",direct19?.prepareMs ?: JSONObject.NULL)
            .put("inference_ms",direct19?.inferenceMs ?: JSONObject.NULL).put("trained_for_day","2026-10-06")
            .put("on_device_daily_fitting",false).put("scope","JST_WEEKDAYS_09_17_COMMON_FOUR_C")
            .put("preserves_native_entry_mask",true).put("horizon_minutes",org.json.JSONArray(listOf(3,5))))
        .put("status",adapter?.status ?: "MODELS_UNAVAILABLE").put("background",backgroundStatus)
        .put("legacy_model_load_status",legacyModelLoadStatus).put("application_status",applicationStatus)
        .put("price_history_symbols",cache.snapshot().size)
        .put("feature_prepare_ms",prepareMs).put("inference_ms",adapter?.lastInferenceMs ?: 0.0)
        .put("pre_scan_quote",quoteStatus)
        .put("coverage_samples",adapter?.snapshot()?.size ?: 0)
        .put("coverage_version",coverageVersion)
        .put("pc_r13",JSONObject().put("version",R13Policy.VERSION).put("policy",R13Policy.POLICY)
            .put("preserves_base_entry_mask",true)
            .put("minimum_research_entry_percent",EntryMaskGuard.MINIMUM_RESEARCH_ENTRY_PERCENT)
            .put("model_fold","2026-08").put("available_from_epoch",R13Catalog.AVAILABLE_FROM)
            .put("load_status",r13LoadStatus).put("status",r13?.status ?: "UNAVAILABLE")
            .put("changed",r13?.changed ?: false).put("inference_ms",r13?.inferenceMs ?: JSONObject.NULL)
            .put("persistence",r13?.persistenceStatus ?: "NOT_LOADED"))
        .put("partial_ohlc_available",false).put("fixed_model_available_from","2026-08-01T00:00:00+09:00")
    fun stop() { job?.cancel();chartRankPreparation?.cancel();prepared.set(null);preparedDirect.set(null);preparedOctober.set(null);preparedChartRank.set(null);repository.cancelInFlightRequests() }
}

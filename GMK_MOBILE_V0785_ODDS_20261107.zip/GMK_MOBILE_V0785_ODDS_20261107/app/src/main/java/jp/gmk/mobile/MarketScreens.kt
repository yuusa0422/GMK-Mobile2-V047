package jp.gmk.mobile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay
import java.time.ZonedDateTime
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Every pair the decisions use: the five yen crosses and (v0.7.74) the four crypto pairs. */
internal val chartInstruments = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY") + CryptoPairs.ALL
private val timeframes = listOf("1m", "5m", "15m", "1h", "4h", "1d")
private val strengthPairs = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
private val CHART_HEIGHT = 320.dp

/**
 * v0.7.74 chart (幻想チャート): the newest 60 bars by default (30 / 60 / 120 / 240 to choose) with the price scale fitted to them and
 * price labels beside the chart; before, a whole day of 1-minute bars was squeezed into the screen width. Indicators are computed
 * over every fetched bar and only drawn for the visible ones.
 */
@Composable
fun ChartScreen(
    state: GmkUiState,
    instrument: String,
    timeframe: String,
    focusHistory: HistoryRow?,
    autoFollowScan: Boolean,
    onToggleAutoFollow: () -> Unit,
    onInstrument: (String) -> Unit,
    onTimeframe: (String) -> Unit,
    onRefresh: (String, String, Long?) -> Unit
) {
    val focusMs = remember(focusHistory?.id) { focusHistory?.entryTimeJst?.let(::parseJstMs) }
    LaunchedEffect(instrument, timeframe, focusHistory?.id) {
        onRefresh(instrument, timeframe, focusMs)
        if (focusHistory == null) {
            while (true) {
                // v0.7.83: 3 s after each minute (the newest finished bar is out then); every 60 s from the opening of the screen left the
                // chart up to a minute behind the finished bars
                val now = System.currentTimeMillis()
                delay(60_000L - now % 60_000L + 3_000L)
                onRefresh(instrument, timeframe, null)
            }
        }
    }
    var span by rememberSaveable { mutableStateOf(ChartWindow.DEFAULT_SPAN) }
    val candles = state.chartCandles.takeIf { state.chartInstrument == instrument && state.chartTimeframe == timeframe }.orEmpty()
    val rate = (state.cryptoRates + state.rates).firstOrNull { it.instrument == instrument }
    val bollinger = remember(candles) { bollingerBands(candles) }
    val macdRows = remember(candles) { macd(candles) }
    val window = remember(candles, span, focusMs) { ChartWindow.range(candles.map { it.timeEpochMs }, span, focusMs) }
    val visible = if (window.isEmpty()) emptyList() else candles.subList(window.first, window.last + 1)
    val visibleBands = if (window.isEmpty()) emptyList() else window.map { bollinger.getOrNull(it) }
    val visibleMacd = if (window.isEmpty()) emptyList() else window.map { macdRows.getOrNull(it) }
    val last = visible.lastOrNull()
    val latestBand = visibleBands.lastOrNull()
    val latestMacd = visibleMacd.lastOrNull()
    val scanTop = state.scan?.top1?.takeIf { it.instrument == instrument }
    var chartNowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val plannedEntry = latestScanEntry(state, instrument, chartNowMs)
    LaunchedEffect(plannedEntry?.first) {
        val target = plannedEntry?.first ?: return@LaunchedEffect
        val delayMs = target - System.currentTimeMillis()
        if (delayMs > 0L) delay(delayMs)
        chartNowMs = System.currentTimeMillis()
    }
    val strengthForPair = remember(state.strengthCandles) { currencyRelativeStrength(state.strengthCandles) }
    // v0.7.78: the 1-minute rows (48 an hour) only on the 1-minute chart; they filled the 60 markers of the BTC / ETH charts
    val historyRows = remember(state.history, instrument, timeframe) {
        // v0.7.84: the newest 30 trades of each kind (the 1-minute rows, one a minute, took all 60 places and hid the 5-minute trades)
        val mine = state.history.asSequence().filter { it.instrument == instrument && it.decision == "ENTRY" }
        (mine.filter { !RankStatistics.isOneMinute(it) }.take(30) + (if (timeframe == "1m") mine.filter { RankStatistics.isOneMinute(it) }.take(30) else emptySequence()))
            .sortedByDescending { parseJstMs(it.entryTimeJst) ?: 0L }.toList()
    }
    val period = timeframesToMs(timeframe)
    val start = visible.firstOrNull()?.timeEpochMs ?: 0L
    val end = (visible.lastOrNull()?.timeEpochMs ?: 0L) + period
    val drawEnd = max(end, plannedEntry?.first?.plus(period) ?: 0L)
    // v0.7.83: the chosen history row first (the chart draws the newest 12 trades in view)
    val markers = remember(historyRows, focusHistory) { (listOfNotNull(focusHistory?.takeIf { it.decision == "ENTRY" }) + historyRows).distinctBy { it.id } }
    val range = remember(visible, visibleBands, markers, start, drawEnd) {
        ChartWindow.priceRange(buildList {
            visible.forEach { add(it.high); add(it.low) }
            visibleBands.filterNotNull().forEach { add(it.upper); add(it.lower) }
            markers.forEach { h ->
                if (parseJstMs(h.entryTimeJst)?.let { it in start until drawEnd } == true) h.entryRate?.let(::add)
                if (parseJstMs(h.judgeTimeJst)?.let { it in start until drawEnd } == true) h.judgeRate?.let(::add)
            }
        })
    }

    Column(Modifier.fillMaxSize().background(Gmk.Night).verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2A1240), Gmk.Night))).padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                YinYangOrb(24.dp, spinning = state.chartLoading)
                Spacer(Modifier.width(8.dp))
                Text("幻想チャート", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.weight(1f))
                ChoiceChip("SCAN追従 ${if (autoFollowScan) "ON" else "OFF"}", autoFollowScan, Gmk.Cyan, onToggleAutoFollow)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                chartInstruments.forEach { pair -> ChoiceChip(pairLabel(pair), pair == instrument, if (CryptoPairs.isCrypto(pair)) Gmk.Gold else Gmk.Pink) { onInstrument(pair) } }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                timeframes.forEach { tf -> ChoiceChip(tf, tf == timeframe, Gmk.Purple) { onTimeframe(tf) } }
                Spacer(Modifier.width(6.dp))
                Text("表示", color = Gmk.Muted, fontSize = 11.sp)
                ChartWindow.SPANS.forEach { n -> ChoiceChip("${n}本", n == span, Gmk.Cyan) { span = n } }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(pairLabel(instrument), color = Gmk.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${state.chartSource.ifBlank { if (CryptoPairs.isCrypto(instrument)) "Coinbase" else "Yahoo Finance" }} • $timeframe • ${visible.size}/${candles.size}本",
                        color = Gmk.Muted, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(rate?.price?.let(::formatPrice) ?: "—", color = if (rate?.freshnessStatus == "LIVE") Gmk.Pink else Gmk.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("${rate?.freshnessStatus ?: "取得待ち"}  更新 ${state.chartUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "—"}", color = Gmk.Muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OhlcCell("始", last?.open); OhlcCell("高", last?.high); OhlcCell("安", last?.low); OhlcCell("終", last?.close)
            }
            Spacer(Modifier.height(8.dp))
            // v0.7.83: price and time scales drawn in the chart (they sat outside it, not level with the grid lines), the live price as a
            // tagged line, the trades as entry triangles with a line to their judge price (no full-height lines), at most the newest 12
            val livePrice = rate?.price?.takeIf { rate.freshnessStatus == "LIVE" && it.isFinite() && it > 0.0 }
            PriceChart(Modifier.fillMaxWidth(), visible, visibleBands, markers, period, start, drawEnd, range, plannedEntry?.first, plannedEntry?.second, livePrice)
            Text(if (state.chartLoading && candles.isEmpty()) "足を取得中…" else if (candles.isEmpty()) "足なし" else
                "緑=上がった足・赤=下がった足 • 帯=ボリンジャー(20, 2) ${latestBand?.let { "上 ${formatPrice(it.upper)} / 中 ${formatPrice(it.middle)} / 下 ${formatPrice(it.lower)}" } ?: ""}",
                color = Gmk.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            state.chartError?.let { Text(it, color = Gmk.Warn, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp)) }
        }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("MACD (12, 26, 9)", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(latestMacd?.let { "${formatSmall(it.macd)} / ${formatSmall(it.signal)} / ${formatSmall(it.histogram)}" } ?: "—", color = Gmk.Cyan, fontSize = 11.sp)
            }
            Spacer(Modifier.height(4.dp))
            MacdChart(Modifier.fillMaxWidth(), visibleMacd, visible.map { it.timeEpochMs }, period, start, drawEnd)
        }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), accent = Gmk.Pink.copy(alpha = .5f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📰 文々。速報", color = Gmk.Pink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Text(if (rate?.freshnessStatus == "LIVE") "LIVE" else "取得確認", color = if (rate?.freshnessStatus == "LIVE") Gmk.Win else Gmk.Gold, fontSize = 11.sp)
            }
            Spacer(Modifier.height(4.dp))
            val comments = buildList {
                if (rate == null || rate.price == null) add("リアルタイム価格を取得できていません")
                else if (rate.freshnessStatus != "LIVE") add("取得遅延注意: provider age ${rate.ageSeconds?.let { "%.1f秒".format(it) } ?: "不明"}")
                if (scanTop != null) add("スキャンTOP1: ${scanTop.direction} / 運用等級 ${scanTop.grade} / ${scanTop.assessment?.correctionLabel ?: "理由未記録"}")
                if (plannedEntry != null) add("ENTRY予定: ${plannedEntry.second} • ${formatClock(plannedEntry.first)}")
                val strengthGap = strengthForPair[instrument.removeSuffix("JPY")]?.let { base -> strengthForPair["JPY"]?.let { base - it } }
                if (strengthGap != null && instrument.endsWith("JPY")) {
                    val aligned = scanTop?.let { (it.direction == "HIGH" && strengthGap > 0.0) || (it.direction == "LOW" && strengthGap < 0.0) }
                    add("通貨強弱（参考）: ${"%+.2f".format(strengthGap)}% • ${when (aligned) { true -> "方向一致"; false -> "逆行に注意"; null -> "方向比較" }}")
                }
                // v0.7.79: the 1-minute rows only on the 1-minute chart, like the markers (a 5-minute chart showed the last 1-minute result)
                val settled = state.history.firstOrNull { it.instrument == instrument && it.decision == "ENTRY" && it.resultStatus in setOf("WIN", "LOSE") &&
                    (timeframe == "1m" || !RankStatistics.isOneMinute(it)) }
                if (settled != null) add("直近の結果: ${settled.resultStatus} • ${settled.direction} • ${formatJstTime(settled.entryTimeJst)}")
                if (state.history.any { it.instrument == instrument && it.decision == "ENTRY" && it.resultStatus == "WAIT_JUDGE" &&
                        (timeframe == "1m" || !RankStatistics.isOneMinute(it)) }) add("判定待ち: ENTRY後の結果取得中")
                if (last != null && latestBand != null) {
                    val pos = (last.close - latestBand.lower) / (latestBand.upper - latestBand.lower).coerceAtLeast(1e-12)
                    if (pos >= 0.90) add("ボリンジャー上限付近。反転を含めて次の足を確認")
                    else if (pos <= 0.10) add("ボリンジャー下限付近。反発の有無を確認")
                }
                if (latestMacd != null && visibleMacd.size >= 2) {
                    val before = visibleMacd[visibleMacd.lastIndex - 1]
                    if (before != null && before.macd >= before.signal && latestMacd.macd < latestMacd.signal) add("MACDデッドクロス")
                    else if (before != null && before.macd <= before.signal && latestMacd.macd > latestMacd.signal) add("MACDゴールデンクロス")
                }
                if (focusHistory != null) add(if (isSelectedFocusVisible(visible, focusHistory, timeframe)) "選んだ履歴のENTRY・判定位置をチャートに表示中" else "選んだ履歴は表示中の足の範囲外です（下に価格・時刻）")
                if (isEmpty()) add("スキャンと市場データを待っています")
            }
            comments.take(5).forEach { Text("• $it", color = Gmk.Text, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        }

        focusHistory?.let { HistoryFocusCard(it) }

        ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text("チャートの印", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text("▲ = HIGHのENTRY・▼ = LOWのENTRY（ENTRYの値段）。そこから判定の値段まで線（緑 WIN・赤 LOSE・紫 判定待ち）。紫の縦の点線 = 次のENTRY予定、" +
                "金の線と右の金の札 = いまの価格（LIVEでない時は最後の足の終値を灰色で）。履歴をタップするとその時刻の足を開きます。",
                color = Gmk.Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PriceChart(
    modifier: Modifier, candles: List<Candle>, bands: List<BollingerPoint?>, events: List<HistoryRow>, period: Long, start: Long, end: Long,
    range: Pair<Double, Double>?, plannedEntryMs: Long?, plannedDirection: String?, livePrice: Double?
) {
    val measurer = rememberTextMeasurer()
    Canvas(modifier.height(CHART_HEIGHT).background(Color(0xFF0A1530), RoundedCornerShape(6.dp))) {
        val (lo0, hi0) = range ?: run {
            drawLine(Gmk.Muted.copy(alpha = .5f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.dp.toPx())
            return@Canvas
        }
        if (candles.isEmpty()) return@Canvas
        // the live price is inside the scale too (it can be outside the finished bars)
        val lo = if (livePrice != null) min(lo0, livePrice) else lo0
        val hi = if (livePrice != null) max(hi0, livePrice) else hi0
        val axisW = 72.dp.toPx(); val plotW = (size.width - axisW).coerceAtLeast(10f)      // v0.7.84: 72 dp for the larger labels
        val top = 10.dp.toPx(); val bottom = size.height - 20.dp.toPx(); val height = (bottom - top).coerceAtLeast(1f)
        fun y(price: Double): Float = bottom - ((price - lo) / (hi - lo).coerceAtLeast(1e-12)).toFloat() * height
        fun x(time: Long): Float = (((time - start).toDouble() / (end - start).coerceAtLeast(1L)) * plotW).toFloat().coerceIn(0f, plotW)
        val slot = (period.toDouble() / (end - start).coerceAtLeast(period).toDouble() * plotW).toFloat()
        val bodyW = (slot * .7f).coerceIn(1.5f, 14.dp.toPx())
        val small = TextStyle(color = Gmk.Muted, fontSize = 10.sp)
        // grid and price scale (labels level with their lines)
        ChartWindow.levels(lo, hi).forEach { p ->
            val gy = y(p)
            drawLine(Color(0x2E8FA8D8), Offset(0f, gy), Offset(plotW, gy), 1.dp.toPx())
            val t = measurer.measure(formatPrice(p), small)
            drawText(t, topLeft = Offset(plotW + 4.dp.toPx(), (gy - t.size.height / 2f).coerceIn(0f, size.height - t.size.height)))
        }
        drawLine(Color(0x558FA8D8), Offset(plotW, top), Offset(plotW, bottom), 1.dp.toPx())
        // time scale: four times under their bars
        val step = (candles.size / 4).coerceAtLeast(1)
        for (i in candles.indices step step) {
            val c = candles[i]; val cx = x(c.timeEpochMs + period / 2L)
            val t = measurer.measure(formatClock(c.timeEpochMs).take(5), small)
            if (cx - t.size.width / 2f >= 0f && cx + t.size.width / 2f <= plotW) {
                drawLine(Color(0x1E8FA8D8), Offset(cx, top), Offset(cx, bottom), 1.dp.toPx())
                drawText(t, topLeft = Offset(cx - t.size.width / 2f, bottom + 4.dp.toPx()))
            }
        }
        // Bollinger band as a soft band with its middle line (the band lines no longer share the candle colours)
        val band = Path(); val upper = Path(); val lower = Path(); val mid = Path()
        val pts = bands.mapIndexedNotNull { i, p -> p?.let { x(candles[i].timeEpochMs + period / 2L) to it } }
        if (pts.size >= 2) {
            pts.forEachIndexed { k, (px, p) -> if (k == 0) { band.moveTo(px, y(p.upper)); upper.moveTo(px, y(p.upper)); mid.moveTo(px, y(p.middle)) } else { band.lineTo(px, y(p.upper)); upper.lineTo(px, y(p.upper)); mid.lineTo(px, y(p.middle)) } }
            pts.asReversed().forEach { (px, p) -> band.lineTo(px, y(p.lower)) }
            band.close()
            pts.forEachIndexed { k, (px, p) -> if (k == 0) lower.moveTo(px, y(p.lower)) else lower.lineTo(px, y(p.lower)) }
            drawPath(band, Color(0x1A7FB2FF))
            drawPath(upper, Color(0x667FB2FF), style = Stroke(1.dp.toPx()))
            drawPath(lower, Color(0x667FB2FF), style = Stroke(1.dp.toPx()))
            drawPath(mid, Color(0x99A9C4FF), style = Stroke(1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx()))))
        }
        // candles: green up, red down
        val up = Color(0xFF2EE59D); val down = Color(0xFFFF5370)
        candles.forEach { c ->
            val cx = x(c.timeEpochMs + period / 2L)
            val color = if (c.close >= c.open) up else down
            drawLine(color, Offset(cx, y(c.high)), Offset(cx, y(c.low)), 1.dp.toPx())
            val yOpen = y(c.open); val yClose = y(c.close)
            drawRect(color, Offset(cx - bodyW / 2f, min(yOpen, yClose)), Size(bodyW, max(1.dp.toPx(), abs(yOpen - yClose))))
        }
        // trades: entry triangle at the entry price, a line to the judge price, coloured by the result (newest 12 in view)
        // v0.7.84: the chosen row, then up to 8 of the 5-minute / 3-minute trades and 8 of the 1-minute trades in view
        val inView = events.mapNotNull { h -> parseJstMs(h.entryTimeJst)?.takeIf { it in start until end }?.let { it to h } }
        val drawn = (inView.take(1) + inView.drop(1).filter { !RankStatistics.isOneMinute(it.second) }.take(8) +
            inView.drop(1).filter { RankStatistics.isOneMinute(it.second) }.take(8)).distinctBy { it.second.id }
        drawn.forEach { (t, h) ->
            val color = when (h.resultStatus) { "WIN" -> up; "LOSE" -> down; else -> Gmk.Purple }
            val entry = h.entryRate?.takeIf { it.isFinite() && it > 0.0 } ?: return@forEach
            val ex = x(t); val ey = y(entry)
            val judgeX = parseJstMs(h.judgeTimeJst)?.let { x(it.coerceAtMost(end)) }
            val judge = h.judgeRate?.takeIf { it.isFinite() && it > 0.0 }
            if (judgeX != null) {
                drawLine(color.copy(alpha = .9f), Offset(ex, ey), Offset(judgeX, judge?.let(::y) ?: ey), 2.dp.toPx(),
                    pathEffect = if (judge == null) PathEffect.dashPathEffect(floatArrayOf(3.dp.toPx(), 3.dp.toPx())) else null)
                if (judge != null) drawCircle(color, radius = 3.5.dp.toPx(), center = Offset(judgeX, y(judge)))
            }
            val r = 6.dp.toPx(); val tri = Path()
            if (h.direction == "HIGH") { tri.moveTo(ex, ey - r); tri.lineTo(ex - r * .9f, ey + r * .6f); tri.lineTo(ex + r * .9f, ey + r * .6f) }
            else { tri.moveTo(ex, ey + r); tri.lineTo(ex - r * .9f, ey - r * .6f); tri.lineTo(ex + r * .9f, ey - r * .6f) }
            tri.close()
            drawPath(tri, Color.White)
            drawPath(tri, color, style = Stroke(1.5.dp.toPx()))
        }
        // the next planned ENTRY
        if (plannedEntryMs != null && plannedEntryMs in start until end) {
            val px = x(plannedEntryMs)
            drawLine(Gmk.Purple, Offset(px, top), Offset(px, bottom), 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 3.dp.toPx())))
            val t = measurer.measure("次 ${if (plannedDirection == "HIGH") "▲HIGH" else "▼LOW"}", TextStyle(color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold))
            val lx = (px - t.size.width - 4.dp.toPx()).coerceAtLeast(0f)
            drawRect(Gmk.Purple.copy(alpha = .85f), Offset(lx - 2.dp.toPx(), top), Size(t.size.width + 4.dp.toPx(), t.size.height.toFloat()))
            drawText(t, topLeft = Offset(lx, top))
        }
        // the price now: gold line and tag on the scale (grey: the last finished bar's close when there is no live price)
        val nowPrice = livePrice ?: candles.last().close
        val tagColor = if (livePrice != null) Gmk.Gold else Gmk.Faint
        val ly = y(nowPrice)
        drawLine(tagColor.copy(alpha = .9f), Offset(0f, ly), Offset(plotW, ly), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4.dp.toPx(), 3.dp.toPx())))
        val tag = measurer.measure(formatPrice(nowPrice), TextStyle(color = Color(0xFF0A1530), fontSize = 11.sp, fontWeight = FontWeight.Bold))
        val tagTop = (ly - tag.size.height / 2f).coerceIn(0f, size.height - tag.size.height)
        drawRect(tagColor, Offset(plotW + 1.dp.toPx(), tagTop), Size(axisW - 1.dp.toPx(), tag.size.height.toFloat()))
        drawText(tag, topLeft = Offset(plotW + 4.dp.toPx(), tagTop))
    }
}

/** v0.7.83: on the price chart's time scale (the bars were spread over the whole width, so they did not line up with the candles). */
@Composable
private fun MacdChart(modifier: Modifier, rows: List<MacdPoint?>, times: List<Long>, period: Long, start: Long, end: Long) {
    Canvas(modifier.height(110.dp).background(Color(0xFF0A1530), RoundedCornerShape(6.dp))) {
        val valid = rows.filterNotNull()
        if (valid.isEmpty() || times.size != rows.size) return@Canvas
        val extent = valid.flatMap { listOf(it.macd, it.signal, it.histogram) }.maxOf { abs(it) }.coerceAtLeast(1e-12)
        val plotW = (size.width - 72.dp.toPx()).coerceAtLeast(10f)
        val mid = size.height / 2f
        fun x(time: Long): Float = (((time - start).toDouble() / (end - start).coerceAtLeast(1L)) * plotW).toFloat().coerceIn(0f, plotW)
        val slot = (period.toDouble() / (end - start).coerceAtLeast(period).toDouble() * plotW).toFloat()
        drawLine(Color(0x556D82AB), Offset(0f, mid), Offset(plotW, mid), 1.dp.toPx())
        val macdPath = Path(); val signalPath = Path()
        var started = false
        rows.forEachIndexed { i, p ->
            if (p == null) return@forEachIndexed
            val cx = x(times[i] + period / 2L)
            fun py(v: Double) = mid - (v / extent).toFloat() * (size.height * .43f)
            val bar = p.histogram.toFloat() / extent.toFloat() * (size.height * .36f)
            val w = (slot * .7f).coerceAtLeast(1.5f)
            drawRect(if (bar >= 0) Color(0xB32EE59D) else Color(0xB3FF5370), Offset(cx - w / 2f, mid - bar.coerceAtLeast(0f)), Size(w, max(1.dp.toPx(), abs(bar))))
            if (!started) { macdPath.moveTo(cx, py(p.macd)); signalPath.moveTo(cx, py(p.signal)); started = true }
            else { macdPath.lineTo(cx, py(p.macd)); signalPath.lineTo(cx, py(p.signal)) }
        }
        drawPath(macdPath, Gmk.Cyan, style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round))
        drawPath(signalPath, Color(0xFFFFA33B), style = Stroke(1.5.dp.toPx(), cap = StrokeCap.Round))
    }
}

/** MACD values (small numbers): 5 significant decimals for FX, 2 for crypto-sized values. */
private fun formatSmall(v: Double): String = if (abs(v) >= 10) "%.2f".format(v) else "%.5f".format(v)

@Composable
private fun OhlcCell(label: String, value: Double?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Gmk.Muted, fontSize = 11.sp)
        Text(value?.let(::formatPrice) ?: "—", color = Gmk.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun HistoryFocusCard(row: HistoryRow) {
    ShrinePanel(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), accent = Gmk.Pink.copy(alpha = .6f)) {
        Text("選んだ履歴 • ${pairLabel(row.instrument)} ${row.direction}", color = Gmk.Pink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text("ENTRY ${formatJstTime(row.entryTimeJst)} @ ${row.entryRate?.let(::formatPrice) ?: "取得なし"}", color = Gmk.Text, fontSize = 12.sp)
        Text("判定 ${formatJstTime(row.judgeTimeJst)} @ ${row.judgeRate?.let(::formatPrice) ?: "取得なし"} • ${row.resultStatus}", color = Gmk.Text, fontSize = 12.sp)
        Text("${row.source} / 運用等級 ${row.grade} / ${row.regime}", color = Gmk.Muted, fontSize = 11.sp)
        row.assessment?.correctionLabel?.let { Text(it, color = Gmk.Cyan, fontSize = 11.sp) }
        if (row.decision == "SKIP" && row.skipReasonLabel.isNotBlank()) Text("見送り: ${row.skipReasonLabel}", color = Gmk.Muted, fontSize = 11.sp)
    }
}

@Composable
fun CurrencyStrengthScreen(state: GmkUiState, onRefresh: (String) -> Unit, onSelectPair: (String) -> Unit) {
    var timeframe by remember { mutableStateOf(state.strengthTimeframe.ifBlank { "1h" }) }
    var session by remember { mutableStateOf("全時間") }
    var filter by remember { mutableStateOf("すべて") }
    LaunchedEffect(timeframe) {
        onRefresh(timeframe)
        while (true) { delay(120_000L); onRefresh(timeframe) }
    }
    val sessions = listOf("全時間", "東京", "欧州", "米国")
    val filteredCandles = remember(state.strengthCandles, session) { state.strengthCandles.mapValues { (_, c) -> filterSessionWindow(c, session) } }
    val values = remember(filteredCandles) { currencyRelativeStrength(filteredCandles) }
    val allowedPairs = when (filter) {
        "メジャー" -> setOf("USDJPY", "EURJPY", "GBPJPY")
        "高金利" -> setOf("AUDJPY", "NZDJPY")
        "暗号資産" -> setOf("BTCJPY")
        else -> strengthPairs.toSet()
    }
    val candidates = strengthPairs.filter { it in allowedPairs }
        .mapNotNull { pair -> values[pair.removeSuffix("JPY")]?.let { pair to it } }
        .sortedByDescending { abs(it.second - (values["JPY"] ?: 0.0)) }
    val currencies = listOf("JPY", "USD", "EUR", "GBP", "AUD", "NZD", "BTC")
    val top = state.scan?.top1
    // v0.7.79: the three sessions once per candle update (they were computed again at every redraw of the screen)
    val sessionScores = remember(state.strengthCandles) {
        listOf("東京", "欧州", "米国").associateWith { name -> currencyRelativeStrength(state.strengthCandles.mapValues { (_, list) -> filterSessionWindow(list, name) }) }
    }

    Column(Modifier.fillMaxSize().background(Gmk.Night).verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF2A1240), Gmk.Night))).padding(14.dp)) {
            Text("勢力図（通貨強弱）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text("幻想郷の勢力図 — 円の5ペアとBTC/JPY（bitbank）の確定足から算出・対JPY変化率", color = Gmk.Muted, fontSize = 11.sp)
            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                sessions.forEach { ChoiceChip(it, it == session, Gmk.Pink) { session = it } }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                timeframes.forEach { ChoiceChip(it, it == timeframe, Gmk.Purple) { timeframe = it } }
            }
        }
        if (state.strengthLoading) Text("通貨足を取得中…", color = Gmk.Cyan, modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp), fontSize = 12.sp)
        if (state.strengthErrors.isNotEmpty()) Text("一部データなし: ${state.strengthErrors.keys.joinToString()}", color = Gmk.Warn, modifier = Modifier.padding(horizontal = 14.dp), fontSize = 11.sp)

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("勢力ランキング", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text("更新 ${state.strengthUpdatedAtMs.takeIf { it > 0 }?.let(::formatClock) ?: "—"}", color = Gmk.Muted, fontSize = 11.sp)
            }
            val ranked = currencies.mapNotNull { c -> values[c]?.let { c to it } }.filter { (c, _) -> filter != "暗号資産" || c == "BTC" }.sortedByDescending { it.second }
            if (ranked.isEmpty()) {
                Text("必要な確定足がまだありません", color = Gmk.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            } else {
                val lowest = ranked.minOf { it.second }
                val spread = (ranked.maxOf { it.second } - lowest).coerceAtLeast(.01)
                ranked.forEachIndexed { index, (currency, score) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 1}", color = Gmk.Muted, modifier = Modifier.width(24.dp), fontSize = 12.sp)
                        Text(currency, color = Gmk.Text, fontWeight = FontWeight.Bold, modifier = Modifier.width(44.dp), fontSize = 13.sp)
                        Box(Modifier.weight(1f).height(16.dp).background(Color(0xFF111D36), RoundedCornerShape(3.dp))) {
                            Box(Modifier.fillMaxWidth(((score - lowest) / spread).toFloat().coerceIn(.03f, 1f)).fillMaxHeight()
                                .background(if (score >= 0) Gmk.Pink else Gmk.Cyan, RoundedCornerShape(3.dp)))
                        }
                        Text("${if (score >= 0) "+" else ""}${"%.2f".format(score)}%", color = if (score >= 0) Gmk.Pink else Gmk.Cyan, textAlign = TextAlign.End,
                            modifier = Modifier.width(64.dp), fontSize = 12.sp)
                    }
                }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("相対強弱ヒートマップ", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("セル = 行の通貨の対JPY変化 − 列の通貨の対JPY変化（相対比較）", color = Gmk.Muted, fontSize = 11.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.width(32.dp))
                currencies.forEach { Text(it, Modifier.weight(1f), color = Gmk.Muted, textAlign = TextAlign.Center, fontSize = 10.sp) }
            }
            currencies.forEach { row ->
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(row, Modifier.width(32.dp), color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    currencies.forEach { col ->
                        val d = if (row == col) null else values[row]?.let { r -> values[col]?.let { r - it } }
                        val cell = when {
                            d == null -> Color(0xFF17213A)
                            d >= 0 -> Gmk.Pink.copy(alpha = (.20f + (d / 3.0).toFloat().coerceIn(0f, .65f)))
                            else -> Gmk.Cyan.copy(alpha = (.20f + (abs(d) / 3.0).toFloat().coerceIn(0f, .65f)))
                        }
                        Box(Modifier.weight(1f).height(28.dp).padding(1.dp).background(cell, RoundedCornerShape(2.dp)), contentAlignment = Alignment.Center) {
                            Text(d?.let { "%+.1f".format(it) } ?: "—", color = Color.White.copy(alpha = .92f), fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Text("セッション別（JST）", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("東京 07–16 / 欧州 16–翌01 / 米国 21–翌06", color = Gmk.Muted, fontSize = 11.sp)
            listOf("東京", "欧州", "米国").forEach { name ->
                val scores = sessionScores.getValue(name)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.width(48.dp), color = Gmk.Text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    currencies.forEach { c ->
                        val score = scores[c]
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            val h = if (score == null) 8.dp else (12.dp.value + abs(score).toFloat().coerceIn(0f, 28f)).dp
                            val color = when { score == null -> Gmk.Muted; score >= 0 -> Gmk.Pink; else -> Gmk.Cyan }
                            Box(Modifier.width(17.dp).height(h).background(color.copy(alpha = if (score == null) .35f else .85f), RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)))
                            Text(c, color = Gmk.Muted, fontSize = 10.sp)
                            Text(score?.let { "%+.1f".format(it) } ?: "—", color = if (score == null) Gmk.Muted else color, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("すべて", "メジャー", "高金利", "暗号資産").forEach { ChoiceChip(it, it == filter, Gmk.Pink) { filter = it } }
            }
            Spacer(Modifier.height(8.dp))
            Text("注目ペア", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("強い側がJPYなら反対方向を表示。タップでチャートへ（参考表示・判定には使いません）", color = Gmk.Muted, fontSize = 11.sp)
            if (candidates.isEmpty()) Text("候補データなし", color = Gmk.Muted, modifier = Modifier.padding(top = 8.dp), fontSize = 12.sp)
            candidates.take(4).forEach { (pair, score) ->
                val yen = values["JPY"] ?: 0.0
                val direction = if (score >= yen) "HIGH" else "LOW"
                Row(
                    Modifier.fillMaxWidth().padding(top = 7.dp).border(1.dp, Gmk.Pink.copy(alpha = .45f), RoundedCornerShape(8.dp))
                        .background(Color(0x66161E3A), RoundedCornerShape(8.dp)).clickable { onSelectPair(pair) }.padding(11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("${pairLabel(pair)}  $direction", color = if (direction == "HIGH") Gmk.High else Gmk.Low, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("対JPY ${"%+.2f".format(score - yen)}%", color = Gmk.Muted, fontSize = 11.sp)
                    }
                    Text("›", color = Gmk.Pink, fontSize = 22.sp)
                }
            }
        }

        if (top != null && top.instrument in strengthPairs) {
            val gap = values[top.instrument.removeSuffix("JPY")]?.let { base -> values["JPY"]?.let { base - it } }
            val aligned = gap?.let { (top.direction == "HIGH" && it > 0.0) || (top.direction == "LOW" && it < 0.0) }
            ShrinePanel(Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) {
                Text("スキャンTOP1と勢力図", color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${pairLabel(top.instrument)} ${top.direction} • ${formatJstTime(state.scan?.atJst.orEmpty())}", color = Gmk.Muted, fontSize = 11.sp)
                Text(when (aligned) { true -> "方向一致（参考）"; false -> "逆行（参考）"; null -> "比較できる足が不足" },
                    color = when (aligned) { true -> Gmk.Win; false -> Gmk.Warn; null -> Gmk.Muted }, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("強弱差 ${gap?.let { "%+.2f%%".format(it) } ?: "—"} • 補助表示。判定には加点していません。", color = Gmk.Muted, fontSize = 11.sp)
                Text("チャートで開く ›", color = Gmk.Pink, modifier = Modifier.clickable { onSelectPair(top.instrument) }.padding(top = 6.dp), fontSize = 12.sp)
            }
        }
    }
}

private fun isSelectedFocusVisible(candles: List<Candle>, focus: HistoryRow?, timeframe: String): Boolean {
    if (candles.isEmpty() || focus == null) return false
    val time = parseJstMs(focus.entryTimeJst) ?: return false
    return time in candles.first().timeEpochMs..(candles.last().timeEpochMs + timeframesToMs(timeframe))
}

private fun inSession(timeMs: Long, session: String): Boolean {
    if (session == "全時間") return true
    val hour = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(timeMs), Gmk.Jst).hour
    return when (session) {
        "東京" -> hour in 7..15
        "欧州" -> hour >= 16 || hour < 1
        "米国" -> hour >= 21 || hour < 6
        else -> true
    }
}

private fun filterSessionWindow(candles: List<Candle>, session: String): List<Candle> {
    if (session == "全時間" || candles.isEmpty()) return candles
    val latest = candles.mapNotNull { sessionBucket(it.timeEpochMs, session) }.maxOrNull() ?: return emptyList()
    return candles.filter { sessionBucket(it.timeEpochMs, session) == latest }
}

/**
 * (ENTRY time, direction) of the newest scan's ENTRY on [instrument] while that time is still ahead; v0.7.79: the 1-minute judgment's
 * ENTRY too (the sooner of the two), so a 1-minute signal shows its line on the chart like the 5-minute one.
 */
private fun latestScanEntry(state: GmkUiState, instrument: String, nowMs: Long): Pair<Long, String>? =
    listOfNotNull(state.scan, state.m1Scan).mapNotNull { scan ->
        val top = scan.top1?.takeIf { it.instrument == instrument && it.decision == "ENTRY" } ?: return@mapNotNull null
        val target = parseJstMs(scan.entryTimeJst) ?: return@mapNotNull null
        if (target <= nowMs) null else target to top.direction
    }.minByOrNull { it.first }

private fun sessionBucket(timeMs: Long, session: String): java.time.LocalDate? {
    val local = java.time.Instant.ofEpochMilli(timeMs).atZone(Gmk.Jst)
    if (!inSession(timeMs, session)) return null
    return when (session) {
        "欧州" -> if (local.hour < 1) local.toLocalDate().minusDays(1) else local.toLocalDate()
        "米国" -> if (local.hour < 6) local.toLocalDate().minusDays(1) else local.toLocalDate()
        else -> local.toLocalDate()
    }
}

private fun timeframesToMs(value: String): Long = when (value) { "1m" -> 60_000L; "5m" -> 300_000L; "15m" -> 900_000L; "1h" -> 3_600_000L; "4h" -> 14_400_000L; "1d" -> 86_400_000L; else -> 60_000L }

package jp.gmk.mobile.data

import jp.gmk.mobile.domain.Candle
import jp.gmk.mobile.domain.CryptoPairs
import jp.gmk.mobile.domain.EvidencePolicy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * v0.7.71: a public crypto market-data source for BTC-USD and ETH-USD (no key). Its own HTTP client, so it never waits for Yahoo or
 * bitbank requests. Every successful ticker is kept in [latest] (the 2-second loop in the view model keeps it fresh), so a scan has a
 * live price even if its own request fails. [CoinbaseRepository] is the main source (closest to theoption's crypto, see
 * [CryptoPairs]); [BinanceRepository] is the backup when Coinbase cannot be reached.
 */
abstract class CryptoMarketRepository(val label: String, timeoutSeconds: Long) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS).readTimeout(timeoutSeconds, TimeUnit.SECONDS).callTimeout(timeoutSeconds, TimeUnit.SECONDS)
        .build()
    private val requests = AtomicLong(); private val success = AtomicLong(); private val failure = AtomicLong(); private val http429 = AtomicLong()
    private val lastError = AtomicReference<String?>(null)
    protected val lastCandleOkMs = AtomicLong(); protected val lastTickerOkMs = AtomicLong()
    /** product (BTC-USD / ETH-USD) -> newest ticker (USD price, provider time). */
    val latest = ConcurrentHashMap<String, EvidencePolicy.LiveQuote>()

    fun diagnosticStats(): JSONObject {
        val now = System.currentTimeMillis()
        val q = JSONObject(); for ((k, v) in latest) q.put(k, JSONObject().put("price", v.price).put("age_ms", now - v.epochMs))
        return JSONObject().put("requests", requests.get()).put("success", success.get()).put("failure", failure.get()).put("http_429", http429.get())
            .put("last_error", lastError.get() ?: JSONObject.NULL).put("last_ticker_ok_ms", lastTickerOkMs.get()).put("last_candles_ok_ms", lastCandleOkMs.get())
            .put("tickers", q)
    }

    /** Age in ms of the newest ticker of [product] (Long.MAX_VALUE when none). */
    fun tickerAgeMs(product: String, nowMs: Long = System.currentTimeMillis()): Long = latest[product]?.let { now -> (nowMs - now.epochMs).coerceAtLeast(0L) } ?: Long.MAX_VALUE

    private class HttpStatus(val code: Int, message: String) : IOException(message)

    protected suspend fun get(url: String): String = suspendCancellableCoroutine { cont ->
        requests.incrementAndGet()
        val call = client.newCall(Request.Builder().url(url).header("User-Agent", "GMK-Mobile/0.7.85").header("Accept", "application/json").build())
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                failure.incrementAndGet(); lastError.set((e.message ?: e::class.java.simpleName).take(160))
                if (cont.isActive) cont.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                response.use { r ->
                    val text = try { r.body?.string().orEmpty() } catch (e: IOException) {
                        failure.incrementAndGet(); if (cont.isActive) cont.resumeWithException(e); return
                    }
                    if (!r.isSuccessful) {
                        failure.incrementAndGet(); if (r.code == 429) http429.incrementAndGet()
                        val err = HttpStatus(r.code, "$label HTTP ${r.code}: ${text.take(120)}"); lastError.set(err.message)
                        if (cont.isActive) cont.resumeWithException(err); return
                    }
                    success.incrementAndGet()
                    if (cont.isActive) cont.resume(text)
                }
            }
        })
    }

    protected suspend fun <T> retry(attempts: Int, block: suspend () -> T): T {
        var last: Exception? = null
        repeat(attempts) { k ->
            try { return block() } catch (ce: CancellationException) { throw ce } catch (e: Exception) {
                last = e
                if (e is HttpStatus && e.code in 400..499 && e.code != 429) throw e
                if (k + 1 < attempts) delay(300L * (k + 1))
            }
        }
        throw last ?: IOException("$label request failed")
    }

    protected fun keep(product: String, q: EvidencePolicy.LiveQuote): EvidencePolicy.LiveQuote {
        latest.merge(product, q) { old, new -> if (new.epochMs >= old.epochMs) new else old }
        lastTickerOkMs.set(System.currentTimeMillis()); return q
    }

    /** Newest trade price of [product] (BTC-USD / ETH-USD) in USD with the provider's time. */
    abstract suspend fun ticker(product: String, attempts: Int = 2): EvidencePolicy.LiveQuote

    /** One-minute candles of [product] from [startSec] to [endSec] (at most 300 minutes), oldest first. */
    abstract suspend fun candles(product: String, startSec: Long, endSec: Long, attempts: Int = 2): List<Candle>

    /** The one-minute candle of [product] that opens at [targetMs] (the exact minute OPEN for results), or null. */
    suspend fun minuteAt(product: String, targetMs: Long): Candle? {
        val t = targetMs / 1000L
        return candles(product, t - 120L, t + 120L).firstOrNull { it.timeEpochMs == targetMs }
    }
}

/** Coinbase Exchange public REST: /products/{id}/ticker and /products/{id}/candles?granularity=60 (the main crypto source). */
class CoinbaseRepository(timeoutSeconds: Long = 4) : CryptoMarketRepository("Coinbase", timeoutSeconds) {
    private val base = "https://api.exchange.coinbase.com"

    override suspend fun ticker(product: String, attempts: Int): EvidencePolicy.LiveQuote = retry(attempts) {
        val text = get("$base/products/$product/ticker")
        val (price, at) = CryptoPairs.parseTicker(text) ?: throw IOException("Coinbase ticker unreadable: ${text.take(120)}")
        keep(product, EvidencePolicy.LiveQuote(price, at))
    }

    override suspend fun candles(product: String, startSec: Long, endSec: Long, attempts: Int): List<Candle> = retry(attempts) {
        val url = "$base/products/$product/candles".toHttpUrl().newBuilder()
            .addQueryParameter("granularity", "60")
            .addQueryParameter("start", Instant.ofEpochSecond(startSec).toString())
            .addQueryParameter("end", Instant.ofEpochSecond(endSec).toString())
            .build().toString()
        val c = CryptoPairs.parseCandles(get(url))
        if (c.isEmpty()) throw IOException("Coinbase candles empty ($product)")
        lastCandleOkMs.set(System.currentTimeMillis()); c
    }
}

/**
 * Binance public market data (data-api.binance.vision: market data only, no key): /api/v3/trades?limit=1 (newest trade with its time)
 * and /api/v3/klines?interval=1m. BTCUSDT / ETHUSDT for BTC-USD / ETH-USD. Used only when Coinbase cannot be reached.
 */
class BinanceRepository(timeoutSeconds: Long = 4) : CryptoMarketRepository("Binance", timeoutSeconds) {
    private val base = "https://data-api.binance.vision"

    override suspend fun ticker(product: String, attempts: Int): EvidencePolicy.LiveQuote = retry(attempts) {
        val symbol = CryptoPairs.binanceSymbol(product) ?: throw IOException("no Binance symbol for $product")
        val text = get("$base/api/v3/trades?symbol=$symbol&limit=1")
        val (price, at) = CryptoPairs.parseBinanceTrade(text) ?: throw IOException("Binance trade unreadable: ${text.take(120)}")
        keep(product, EvidencePolicy.LiveQuote(price, at))
    }

    override suspend fun candles(product: String, startSec: Long, endSec: Long, attempts: Int): List<Candle> = retry(attempts) {
        val symbol = CryptoPairs.binanceSymbol(product) ?: throw IOException("no Binance symbol for $product")
        val url = "$base/api/v3/klines".toHttpUrl().newBuilder()
            .addQueryParameter("symbol", symbol).addQueryParameter("interval", "1m")
            .addQueryParameter("startTime", (startSec * 1000L).toString()).addQueryParameter("endTime", (endSec * 1000L).toString())
            .addQueryParameter("limit", "1000")
            .build().toString()
        val c = CryptoPairs.parseBinanceKlines(get(url))
        if (c.isEmpty()) throw IOException("Binance candles empty ($product)")
        lastCandleOkMs.set(System.currentTimeMillis()); c
    }
}

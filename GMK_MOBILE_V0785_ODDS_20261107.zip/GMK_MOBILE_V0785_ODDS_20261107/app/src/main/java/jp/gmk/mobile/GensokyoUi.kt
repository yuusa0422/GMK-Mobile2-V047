package jp.gmk.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.util.Locale

/*
 * v0.7.77 幻想郷 extras on screen (display only): 結界維持中 (the running trades with their countdown and whether the live price leads),
 * the TOP1 countdown, the hour's difficulty, 文々。新聞 号外 (today's report) and 幻想郷縁起 (称号).
 */

internal fun difficultyColor(name: String): Color = when (name) {
    "Easy" -> Gmk.Win
    "Normal" -> Gmk.Cyan
    "Hard" -> Gmk.Warn
    else -> Gmk.Lose
}

/** "Lunatic" chip with the hour's validated rate. */
@Composable
internal fun DifficultyChip(level: Difficulty.Level) {
    val c = difficultyColor(level.name)
    Text("${level.name}  ${level.hour}時台 ${String.format(Locale.US, "%.1f%%", level.rate * 100.0)}", color = c, fontWeight = FontWeight.Bold, fontSize = 11.sp,
        modifier = Modifier.background(c.copy(alpha = .14f), RoundedCornerShape(6.dp)).border(1.dp, c.copy(alpha = .8f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp), maxLines = 1)
}

/** v0.7.78: today's JST date, re-read every minute (a remember keyed on the history alone kept yesterday's date after midnight). */
@Composable
internal fun rememberJstToday(): LocalDate {
    var today by remember { mutableStateOf(LocalDate.now(Gmk.Jst)) }
    LaunchedEffect(Unit) { while (true) { delay(60_000); today = LocalDate.now(Gmk.Jst) } }
    return today
}

/** v0.7.78: the JST time, re-read every [periodMs]. */
@Composable
internal fun rememberJstNow(periodMs: Long = 30_000L): java.time.ZonedDateTime {
    var now by remember { mutableStateOf(java.time.ZonedDateTime.now(Gmk.Jst)) }
    LaunchedEffect(periodMs) { while (true) { delay(periodMs); now = java.time.ZonedDateTime.now(Gmk.Jst) } }
    return now
}

/** A once-a-second clock for countdowns while [active]. */
@Composable
internal fun rememberTicker(active: Boolean): Long {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { nowMs = System.currentTimeMillis(); delay(1000) } }
    return nowMs
}

/** TOP1: "ENTRYまで あと8秒" -> "判定まで 4:12" with a bar, or "判定時刻を過ぎました". */
@Composable
internal fun EntryCountdown(entryTimeJst: String, judgeTimeJst: String) {
    val entry = parseJstMs(entryTimeJst) ?: return
    val judge = parseJstMs(judgeTimeJst) ?: return
    val now = rememberTicker(System.currentTimeMillis() < judge + 2_000L)
    val (text, color, progress) = when {
        now < entry -> Triple("ENTRYまで あと${(entry - now + 999) / 1000}秒", Gmk.Gold, 0f)
        now < judge -> Triple("判定まで ${RunningTrades.clock((judge - now + 999) / 1000)}", Gmk.Cyan, ((now - entry).toFloat() / (judge - entry).coerceAtLeast(1)).coerceIn(0f, 1f))
        else -> Triple("判定時刻を過ぎました（結果はリプレイ帳）", Gmk.Muted, 1f)
    }
    Column(Modifier.fillMaxWidth()) {
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = if (now < judge) 20.sp else 12.sp)
        if (now < judge) Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0x553A4A6E), RoundedCornerShape(3.dp))) {
            Box(Modifier.fillMaxWidth(progress.coerceAtLeast(0.02f)).height(5.dp).background(Brush.horizontalGradient(listOf(Gmk.ShrineRed, color)), RoundedCornerShape(3.dp)))
        }
    }
}

/** 結界維持中: the running trades, each with its countdown and 優勢 / 劣勢 by the live price (a draw loses). */
@Composable
internal fun RunningTradesPanel(state: GmkUiState) {
    val waiting = remember(state.history) { state.history.asSequence().take(RunningTrades.SCAN_ROWS).any { it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") } }
    if (!waiting) return
    val now = rememberTicker(true)
    val prices = remember(state.rates, state.cryptoRates) { (state.rates + state.cryptoRates).mapNotNull { r -> r.price?.let { r.instrument to it } }.toMap() }
    val trades = remember(state.history, prices, now / 1000) { RunningTrades.of(state.history, prices, now) }
    if (trades.isEmpty()) return
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), accent = Gmk.Purple.copy(alpha = .75f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            YinYangOrb(20.dp, spinning = true)
            Spacer(Modifier.width(6.dp))
            Text("結界維持中（進行中の取引 ${trades.size}）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            val lead = trades.count { it.leading == true }
            Text("優勢 $lead / ${trades.size}", color = if (lead * 2 >= trades.size) Gmk.Win else Gmk.Lose, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(4.dp))
        trades.forEach { t -> RunningTradeRow(t, state.sigmaPerMin[t.row.instrument]) }
        Text("いまの値段で比べた目安（判定は判定時刻の値段・同値は負け）", color = Gmk.Faint, fontSize = 10.sp)
    }
}

@Composable
private fun RunningTradeRow(t: RunningTrades.Trade, sigma: Double? = null) {
    val (label, color) = when (t.leading) {
        true -> "優勢" to Gmk.Win
        false -> "劣勢" to Gmk.Lose
        null -> "—" to Gmk.Muted
    }
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Color(0xCC101B34), RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(pairLabel(t.row.instrument), Modifier.width(80.dp), color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, softWrap = false)
            Text(if (t.direction > 0) "▲HIGH" else "▼LOW", Modifier.width(56.dp), color = if (t.direction > 0) Gmk.High else Gmk.Low, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(t.row.assessment?.subGrade?.shown ?: t.row.grade, Modifier.width(40.dp), color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            Text(RunningTrades.clock(t.secondsLeft), color = Gmk.Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            t.diff?.let { d -> Spacer(Modifier.width(6.dp)); Text(formatDiff(d, t.row.instrument), color = color, fontSize = 11.sp) }
        }
        // v0.7.85: the chance the side changes by the judge (from the distance to the entry price and the last hour's moves)
        val rev = t.diff?.let { d -> sigma?.let { s -> TradeOdds.reverse(d, s, t.secondsLeft / 60.0) } }
        if (rev != null && t.secondsLeft > 0) Text(if (t.leading == true) "このまま勝つ ${TradeOdds.pc(1 - rev)}・反転して負ける ${TradeOdds.pc(rev)}"
            else "このまま負け ${TradeOdds.pc(1 - rev)}・逆転して勝つ ${TradeOdds.pc(rev)}", color = if (t.leading == true) OddsWin else OddsReverse, fontSize = 12.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.height(3.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).background(Color(0x553A4A6E), RoundedCornerShape(2.dp))) {
            Box(Modifier.fillMaxWidth(t.progress.coerceAtLeast(0.02f)).height(4.dp).background(color.copy(alpha = .85f), RoundedCornerShape(2.dp)))
        }
    }
}

private fun formatDiff(d: Double, instrument: String): String =
    if (CryptoPairs.isCrypto(instrument)) String.format(Locale.US, "%+.1f", d) else String.format(Locale.US, "%+.3f", d)

/** 文々。新聞 号外: today's report. */
@Composable
internal fun BunbunmaruCard(rows: List<HistoryRow>) {
    val today = rememberJstToday()
    val report = remember(rows, today) { Bunbunmaru.today(rows, today) }
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            .background(Color(0xF2F3E7CF), RoundedCornerShape(10.dp)).border(2.dp, Color(0xFF6B4A2A), RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("文々。新聞", color = Color(0xFF7A1028), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Text("号外", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp,
                modifier = Modifier.background(Color(0xFFB0203F), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 1.dp))
            Spacer(Modifier.weight(1f))
            Text(today.toString(), color = Color(0xFF5A4630), fontSize = 11.sp)
        }
        Text(report.headline, color = Color(0xFF1E1A14), fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(vertical = 4.dp))
        report.lines.forEach { Text("・$it", color = Color(0xFF2E2618), fontSize = 12.sp) }
        Spacer(Modifier.height(4.dp))
        Text("記者 射命丸「${report.comment}」", color = Color(0xFF5A2E10), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

/** 幻想郷縁起: the 称号, unlocked first, then the locked ones with how to get them. */
@Composable
internal fun AchievementsPanel(rows: List<HistoryRow>) {
    val got = remember(rows) { Achievements.of(rows) }
    var open by rememberSaveable { mutableStateOf(false) }
    val n = got.count { it.unlocked }
    ShrinePanel(accent = Gmk.Gold.copy(alpha = .55f)) {
        Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
            Text("幻想郷縁起（称号）", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("$n / ${got.size}  ${if (open) "▲" else "▼"}", color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp).height(5.dp).background(Color(0x553A4A6E), RoundedCornerShape(3.dp))) {
            Box(Modifier.fillMaxWidth((n.toFloat() / got.size).coerceAtLeast(0.02f)).height(5.dp).background(Gmk.Gold, RoundedCornerShape(3.dp)))
        }
        // v0.7.78: folded = the three newest 称号 by the time they were won (was: the last three of the list order)
        val shown = if (open) got.sortedBy { if (it.unlocked) 0 else 1 } else got.filter { it.unlocked }.sortedBy { it.atJst?.let(::parseJstMs) ?: 0L }.takeLast(3).asReversed()
        if (shown.isEmpty()) Text("まだ称号はありません。はじめてのWINで「初陣」", color = Gmk.Muted, fontSize = 11.sp)
        shown.forEach { g ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (g.unlocked) "★" else "☆", color = if (g.unlocked) Gmk.Gold else Gmk.Faint, fontSize = 14.sp)
                Spacer(Modifier.width(6.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (g.unlocked) g.def.title else "？？？", color = if (g.unlocked) Gmk.Text else Gmk.Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(g.def.how + (g.atJst?.let { "（${formatJstTime(it)}）" } ?: ""), color = Gmk.Faint, fontSize = 11.sp)
                }
            }
        }
        if (!open && got.size > n) Text("▼ タップで全部の称号と取り方", color = Gmk.Cyan, fontSize = 11.sp)
    }
}

/** The shooting-game HUD (HiScore / Score / Player / Bomb / Power / Graze / Point) of today, and the shrine's おみくじ. */
@Composable
internal fun ShrineHudPanel(hud: ShrineHud.Hud, today: LocalDate) {
    val (fortune, line) = remember(today) { ShrineHud.omikuji(today) }
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .background(Brush.verticalGradient(listOf(Color(0xEE1A0B2E), Color(0xEE0B1630))), RoundedCornerShape(10.dp))
            .border(1.dp, Gmk.Purple.copy(alpha = .7f), RoundedCornerShape(10.dp)).padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        HudLine("HiScore", String.format(Locale.US, "%010d", hud.hiScore), Gmk.Gold)
        HudLine("Score", String.format(Locale.US, "%010d", hud.score), Color.White)
        HudLine("Player", "★".repeat(hud.lives) + "☆".repeat(ShrineBoard.LIVES - hud.lives), Gmk.Pink)
        HudLine("Bomb", if (hud.bombs == 0) "—" else "✦".repeat(hud.bombs.coerceAtMost(8)) + (if (hud.bombs > 8) "+${hud.bombs - 8}" else ""), Gmk.Win)
        HudLine("Power", String.format(Locale.US, "%.2f / 4.00", hud.power) + if (hud.power >= 4.0) "  MAX" else "", Gmk.ShrineRed)
        HudLine("Graze", "${hud.graze}", Gmk.Cyan)
        HudLine("Point", "${hud.points}", Gmk.Low)
        ShrineHud.lastSpell(hud.winStreak).takeIf { it.isNotEmpty() }?.let {
            Text(it, color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text("博麗神社のおみくじ【$fortune】$line", color = Gmk.Paper, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        FoldNote("Score = 勝ちごとに9,000点＋連勝×1,000点・Bomb = 今日のS/A/BのENTRY・Power = 今日の勝率（52.6%で約2.0）・Graze = 同値。おみくじは遊び（判定とは無関係）",
            "HUDの見方")
    }
}

@Composable
private fun HudLine(name: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(name, Modifier.width(76.dp), color = Gmk.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

package jp.gmk.mobile.domain

import java.time.LocalDate

/**
 * v0.7.80 1分の連敗の目安 (display only). v0.7.81: the 1-minute share is 70% (the user's instruction); the counts below are at 70%
 * (research_v0780/m1_share70_v0781.json: 5+ 7.4-8.0 a day, 7+ 1.6-1.8, 10+ 0.15-0.21, the longest of a day 7.9 on average).
 * research_v0780/m1_streak_v0780.py replayed the app's hourly 80% rule on the out-of-sample best candidate of every minute
 * (rotation 2025-10..2026-11 and 2023-24): about 670 entries a day at 51-52% (the 1.9x break-even is 52.6%), so a day has
 * 5+ losses in a row about 9 times, 7+ about twice and 10+ once in about five days - the same counts as the results shuffled
 * within the day (chance). Asking a stronger trade on a streak (as the 5-minute 連敗結界) changed nothing while the 80% is kept
 * (catch-up), so the panel shows how usual the streak is instead of hiding it, and today's longest streak and B results.
 */
object OneMinuteStreak {
    /** Runs of at least k losses per day at the 70% rule with the v0.7.82 models (rotation weekday / weekend; research_v0782); before: 34 / 7.5 / 1.7 / 0.19. */
    val ODDS_PER_DAY: List<Pair<Int, Double>> = listOf(3 to 33.0, 5 to 7.1, 7 to 1.4, 10 to 0.16)
    const val TYPICAL_DAY_MAX = 8                         // the longest losing streak of a day, on average
    const val BREAK_EVEN = 52.6                           // % at the 1.9x payout (a draw loses)

    fun verdict(k: Int): String = when {
        k < 3 -> ""
        k < 5 -> "3連敗以上は1日に約33回起きる長さ（1分はほぼ五分の勝負）"
        k < 7 -> "5連敗以上は1日に約7回起きる長さ（偶然の範囲）"
        k < 10 -> "7連敗以上も1日に約1.4回起きる（1日の最長は平均${TYPICAL_DAY_MAX}連敗）"
        else -> "10連敗以上は5日に1回ほど（偶然の範囲）"
    }

    data class Day(val wins: Int, val losses: Int, val longest: Int, val runs5: Int, val bWins: Int, val bLosses: Int) {
        val resolved get() = wins + losses
        val rate: Double? get() = if (resolved == 0) null else 100.0 * wins / resolved
        val bRate: Double? get() = if (bWins + bLosses == 0) null else 100.0 * bWins / (bWins + bLosses)
    }

    /** Today's settled 1-minute ENTRY trades (JST day), in time order: the longest losing streak, runs of 5+ and the B trades apart. */
    fun today(rows: List<HistoryRow>, today: LocalDate): Day {
        val key = today.toString()
        val day = rows.asSequence()
            .filter { OneMinutePolicy.isPolicy(it) && it.decision == "ENTRY" && (it.resultStatus == "WIN" || it.resultStatus == "LOSE") && jstDayKey(it.entryTimeJst) == key }
            .mapNotNull { r -> FastTime.instant(r.entryTimeJst)?.let { it to r } }
            .sortedBy { it.first }.map { it.second }.toList()
        var w = 0; var l = 0; var run = 0; var longest = 0; var runs5 = 0; var bw = 0; var bl = 0
        for (r in day) {
            val win = r.resultStatus == "WIN"
            if (win) { w++; run = 0 } else { l++; run++; if (run == 5) runs5++; longest = maxOf(longest, run) }
            if (r.grade == "B") { if (win) bw++ else bl++ }
        }
        return Day(w, l, longest, runs5, bw, bl)
    }

    fun dayText(d: Day): String {
        if (d.resolved == 0) return ""
        val b = d.bRate?.let { "・Bだけ ${d.bWins}勝${d.bLosses}敗 ${"%.1f".format(it)}%" } ?: ""
        return "今日の最長 ${d.longest}連敗・5連敗以上 ${d.runs5}回$b（損益分岐 ${BREAK_EVEN}%）"
    }
}

package jp.gmk.mobile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import kotlinx.coroutines.delay

/** WIN / LOSE cut-ins (moved out of MainActivity.kt in v0.7.74; unchanged). */
private typealias CutInKind = CutInEventQueue.Kind

private data class CutInDisplay(
    val key: String,
    val scanId: String,
    val instrument: String,
    val kind: CutInKind,
    val slot: Int,
    val oneMinuteAdvantage: Boolean = false
)

private fun cutInDrawable(kind: CutInKind, slot: Int, oneMinuteAdvantage: Boolean = false): Int {
    val i = slot.coerceIn(1, 10) - 1
    val winAdv = intArrayOf(
        R.drawable.cutin_win_adv_01, R.drawable.cutin_win_adv_02, R.drawable.cutin_win_adv_03,
        R.drawable.cutin_win_adv_04, R.drawable.cutin_win_adv_05, R.drawable.cutin_win_adv_06,
        R.drawable.cutin_win_adv_07, R.drawable.cutin_win_adv_08, R.drawable.cutin_win_adv_09,
        R.drawable.cutin_win_adv_10
    )
    val winFinal = intArrayOf(
        R.drawable.cutin_win_final_01, R.drawable.cutin_win_final_02, R.drawable.cutin_win_final_03,
        R.drawable.cutin_win_final_04, R.drawable.cutin_win_final_05, R.drawable.cutin_win_final_06,
        R.drawable.cutin_win_final_07, R.drawable.cutin_win_final_08, R.drawable.cutin_win_final_09,
        R.drawable.cutin_win_final_10
    )
    val loseAdv = intArrayOf(
        R.drawable.cutin_lose_adv_01, R.drawable.cutin_lose_adv_02, R.drawable.cutin_lose_adv_03,
        R.drawable.cutin_lose_adv_04, R.drawable.cutin_lose_adv_05, R.drawable.cutin_lose_adv_06,
        R.drawable.cutin_lose_adv_07, R.drawable.cutin_lose_adv_08, R.drawable.cutin_lose_adv_09,
        R.drawable.cutin_lose_adv_10
    )
    val loseFinal = intArrayOf(
        R.drawable.cutin_lose_final_01, R.drawable.cutin_lose_final_02, R.drawable.cutin_lose_final_03,
        R.drawable.cutin_lose_final_04, R.drawable.cutin_lose_final_05, R.drawable.cutin_lose_final_06,
        R.drawable.cutin_lose_final_07, R.drawable.cutin_lose_final_08, R.drawable.cutin_lose_final_09,
        R.drawable.cutin_lose_final_10
    )
    val winAdv1m = intArrayOf(
        R.drawable.cutin_win_adv_1m_01, R.drawable.cutin_win_adv_1m_02, R.drawable.cutin_win_adv_1m_03,
        R.drawable.cutin_win_adv_1m_04, R.drawable.cutin_win_adv_1m_05, R.drawable.cutin_win_adv_1m_06,
        R.drawable.cutin_win_adv_1m_07, R.drawable.cutin_win_adv_1m_08, R.drawable.cutin_win_adv_1m_09,
        R.drawable.cutin_win_adv_1m_10
    )
    val loseAdv1m = intArrayOf(
        R.drawable.cutin_lose_adv_1m_01, R.drawable.cutin_lose_adv_1m_02, R.drawable.cutin_lose_adv_1m_03,
        R.drawable.cutin_lose_adv_1m_04, R.drawable.cutin_lose_adv_1m_05, R.drawable.cutin_lose_adv_1m_06,
        R.drawable.cutin_lose_adv_1m_07, R.drawable.cutin_lose_adv_1m_08, R.drawable.cutin_lose_adv_1m_09,
        R.drawable.cutin_lose_adv_1m_10
    )
    return when (kind) {
        CutInKind.WIN_ADVANTAGE -> if (oneMinuteAdvantage) winAdv1m[i] else winAdv[i]
        CutInKind.LOSE_ADVANTAGE -> if (oneMinuteAdvantage) loseAdv1m[i] else loseAdv[i]
        CutInKind.WIN_FINAL -> winFinal[i]
        CutInKind.LOSE_FINAL -> loseFinal[i]
    }
}

private fun stableCutInSlot(scanId: String, instrument: String): Int {
    val hash = (scanId.ifBlank { instrument }).hashCode()
    return Math.floorMod(hash, 10) + 1
}

@Composable
internal fun CutInOverlay(
    state: GmkUiState,
    controller: CutInEventQueue,
    onShown: (String, String, String) -> Unit,
    onSuppressed: (String, String, String) -> Unit
) {
    if (!state.cutInEnabled) return
    val lifecycle = (LocalContext.current as? androidx.lifecycle.LifecycleOwner)?.lifecycle
    var foreground by remember(lifecycle) {
        mutableStateOf(lifecycle == null || lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED))
    }
    DisposableEffect(lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, _ ->
            foreground = lifecycle == null || lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }
    var current by remember { mutableStateOf<CutInDisplay?>(null) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(250)
        }
    }
    // v0.7.79: the newest 256 rows that can cut in, once per history change (the policy reads only those); up to v0.7.78 the whole
    // history (20,000 rows) was filtered into a new list four times a second
    val cutInRows = remember(state.history) { state.history.asSequence().filter(OneMinutePolicy::showsCutIn).take(256).toList() }
    LaunchedEffect(nowMs, cutInRows, state.rates, state.cryptoRates, state.cutInEnabled, foreground) {
        val at = System.currentTimeMillis()
        val suppressed = CutInPolicy.observeEvents(controller, cutInRows, state.cryptoRates + state.rates, at, state.cutInEnabled)
        // Coroutines can keep running while an Activity is stopped. Queue results, but
        // never consume/mark them as shown until a visible screen can display them.
        if (!foreground) {
            current = null
            return@LaunchedEffect
        }
        val tick = controller.advance(at, android.os.SystemClock.elapsedRealtime())
        current = tick.current?.let { event -> CutInDisplay(event.key, event.scanId, event.instrument,
            event.kind, stableCutInSlot(event.scanId, event.instrument), event.oneMinuteAdvantage) }
        tick.started?.let { onShown(it.kind.name, it.scanId, it.instrument) }
        suppressed.firstOrNull()?.let { onSuppressed(it.reason, it.scanId, it.instrument) }
    }

    AnimatedVisibility(
        visible = current != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 3 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it / 3 })
    ) {
        current?.let { cut ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.18f))
                    .clickable { controller.dismiss(); current = null },
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(0.96f),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF070A12))
                ) {
                    Column {
                        // Every asset is rebuilt to exactly 16:5. Fit + explicit aspect ratio means
                        // character faces, labels, and countdowns can never be cropped by the container.
                        Image(
                            painter = painterResource(cutInDrawable(cut.kind, cut.slot, cut.oneMinuteAdvantage)),
                            contentDescription = "GMK ${cut.kind.name} cut-in",
                            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 5f),
                            contentScale = ContentScale.Fit
                        )
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Color(0xF211131C))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (cut.kind) {
                                    CutInKind.WIN_ADVANTAGE -> "勝ち優勢"
                                    CutInKind.LOSE_ADVANTAGE -> "負け優勢"
                                    CutInKind.WIN_FINAL -> "WIN"
                                    CutInKind.LOSE_FINAL -> "LOSE"
                                },
                                color = when (cut.kind) {
                                    CutInKind.WIN_ADVANTAGE, CutInKind.WIN_FINAL -> Color(0xFF71E3A6)
                                    else -> Color(0xFFFF7A8C)
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(pairLabel(cut.instrument), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            Text("博麗神社 GMK", color = Color.LightGray, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

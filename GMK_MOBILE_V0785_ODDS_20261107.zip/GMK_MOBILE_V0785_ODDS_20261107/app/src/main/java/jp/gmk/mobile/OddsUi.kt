package jp.gmk.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.gmk.mobile.domain.SkipGrades
import jp.gmk.mobile.domain.TradeOdds

internal val OddsWin = Color(0xFF2EE59D)
internal val OddsReverse = Color(0xFFFF5370)
internal val OddsDraw = Color(0xFFB8C2D8)

/**
 * v0.7.85: 勝ち・反転・引き分け as one bar (green / red / grey, adding up to 100%) with the three numbers under it, and a warning line
 * when a draw (同値 = 負け) is 3% or more likely.
 */
@Composable
internal fun OddsBar(o: TradeOdds.Odds, compact: Boolean = false) {
    Column(Modifier.fillMaxWidth().padding(top = 4.dp)) {
        val total = (o.win + o.reverse + o.draw).coerceAtLeast(1e-9)
        Row(Modifier.fillMaxWidth().height(if (compact) 6.dp else 10.dp).background(Color(0x553A4A6E), RoundedCornerShape(5.dp))) {
            if (o.win > 0) Box(Modifier.weight((o.win / total).toFloat().coerceAtLeast(0.001f)).fillMaxHeight().background(OddsWin, RoundedCornerShape(5.dp)))
            if (o.reverse > 0) Box(Modifier.weight((o.reverse / total).toFloat().coerceAtLeast(0.001f)).fillMaxHeight().background(OddsReverse))
            if (o.draw > 0) Box(Modifier.weight((o.draw / total).toFloat().coerceAtLeast(0.001f)).fillMaxHeight().background(OddsDraw, RoundedCornerShape(5.dp)))
        }
        Row(Modifier.fillMaxWidth().padding(top = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("勝ち ${TradeOdds.pc(o.win)}", color = OddsWin, fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("反転 ${TradeOdds.pc(o.reverse)}", color = OddsReverse, fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("引き分け ${TradeOdds.pc(o.draw)}", color = OddsDraw, fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.Bold)
        }
        if (o.drawWarning) Text("⚠ 引き分けの可能性あり（同値は負け・${TradeOdds.pc(o.draw)}）", color = Gmk.Warn, fontSize = if (compact) 11.sp else 12.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
        if (!compact) Text("反転 = 予想と逆に動いて負ける確率。引き分け = 判定の値段がENTRYと同じ（負け）になる確率", color = Gmk.Faint, fontSize = 11.sp)
    }
}

/** v0.7.85: the skip grade (D..H) in words with its win rate if it had been entered, for a skipped trade. */
@Composable
internal fun SkipGradeLine(segment: String, grade: String) {
    if (grade !in SkipGrades.GRADES) return
    Text(SkipGrades.text(segment, grade), color = Gmk.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
}

/**
 * v0.7.85: 次にやること - one card at the top of the prediction screen with what to do now on theoption: each ENTRY that is coming or
 * running (5-minute / 3-minute and 1-minute), its pair, direction, expiry and the seconds left, with 勝ち・反転・引き分け;
 * with none, when the next judgment comes.
 */
@Composable
internal fun NextActionCard(state: jp.gmk.mobile.ui.GmkUiState) {
    val now = rememberTicker(true)
    class Act(val c: jp.gmk.mobile.domain.ScanCandidate, val entryMs: Long, val judgeMs: Long, val minutes: Int, val oneMinute: Boolean)
    val acts = listOfNotNull(state.scan to false, state.m1Scan to true).mapNotNull { (s, one) ->
        val top = s?.top1 ?: return@mapNotNull null
        if (top.decision != "ENTRY") return@mapNotNull null
        val e = parseJstMs(s.entryTimeJst) ?: return@mapNotNull null; val j = parseJstMs(s.judgeTimeJst) ?: return@mapNotNull null
        if (now >= j) null else Act(top, e, j, expiryMinutes(s.entryTimeJst, s.judgeTimeJst, if (one) 1 else 3), one)
    }.sortedBy { it.entryMs }
    ShrinePanel(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), accent = if (acts.isEmpty()) Gmk.Line else Gmk.Gold) {
        Text("次にやること", color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        if (acts.isEmpty()) {
            val sec = jp.gmk.mobile.domain.AutoClock.nextAutoScanSeconds(java.time.ZonedDateTime.now(Gmk.Jst))
            Text("いまはエントリーなし（待つ）", color = Gmk.Muted, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(if (state.autoScan) "次の5分判定まで ${jp.gmk.mobile.domain.AutoClock.countdownText(sec)}" + (if (state.m1Auto) "・1分判定は毎分" else "")
                else if (state.m1Auto) "1分判定は毎分の10秒前" else "AUTOがOFFです（上のスイッチでON）", color = Gmk.Muted, fontSize = 13.sp)
        }
        acts.forEach { a ->
            val toEntry = ((a.entryMs - now) / 1000L).toInt(); val toJudge = ((a.judgeMs - now) / 1000L).toInt()
            Column(Modifier.fillMaxWidth().padding(top = 6.dp).background(Color(0xCC1A2442), RoundedCornerShape(10.dp)).padding(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(pairLabel(a.c.instrument), color = Gmk.Text, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1, softWrap = false)
                    Spacer(Modifier.width(8.dp))
                    Text(if (a.c.direction == "HIGH") "▲ HIGH" else "▼ LOW", color = if (a.c.direction == "HIGH") Gmk.High else Gmk.Low, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.weight(1f))
                    Text("${a.minutes}分", color = Gmk.Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                Text(if (toEntry > 0) "あと${toEntry}秒でエントリー（ザオプションで「${a.minutes}分」・${formatClock(a.entryMs)}）"
                    else "進行中 — 判定まで ${toJudge / 60}:${String.format(java.util.Locale.US, "%02d", toJudge % 60)}",
                    color = if (toEntry > 0) Gmk.Cyan else Gmk.Purple, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("運用等級 ${a.c.assessment?.subGrade?.shown ?: a.c.grade}" + if (a.oneMinute) "・1分判定" else "", color = Gmk.Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                a.c.odds?.let { OddsBar(it, compact = true) }
            }
        }
    }
}

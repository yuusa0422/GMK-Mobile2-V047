package jp.gmk.mobile.domain

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * v0.7.85 勝ち・反転・引き分けの確率 (display only; no decision reads it).
 *
 * Before the entry: every judgment's model is fit with a draw counted as a loss in both directions, so for one pair
 * P(HIGH wins) + P(LOW wins) = 1 - P(draw): the draw probability is 1 - p(HIGH) - p(LOW), calibrated on one year out of sample
 * (research_v0784: the 1-minute models' raw value 0.02-0.04 gave 2.9% draws on weekdays, the 5-minute model's 0.01-0.02 gave 1.4%).
 * 勝ち = the chosen direction's probability, 引き分け = the calibrated draw probability, 反転 = the rest (the price goes the other way).
 *
 * While a trade runs: 反転の確率 = the chance the side changes by the judge time, from how far the price is from the entry price
 * against the last hour's 1-minute moves: Phi(-|diff| / (sigma * sqrt(minutes left))), checked on one year of 3- and 5-minute trades
 * (research_v0784/reverse_v0784.py: predicted 22.5% -> 22.1% happened for the yen crosses, 20.2% for crypto; at least 3%).
 */
object TradeOdds {
    data class Odds(val win: Double, val reverse: Double, val draw: Double) {
        /** A draw (the judge price equal to the entry price) is likely enough to say so: 3% or more. */
        val drawWarning: Boolean get() = draw >= DRAW_WARNING
    }
    const val DRAW_WARNING = 0.03
    const val M1_WEEKDAY = "m1w"; const val M1_WEEKEND = "m1e"; const val M5_WEEKDAY = "w5"; const val M3_WEEKEND = "e3"

    /** Calibration: raw 1 - p(HIGH) - p(LOW) below the bound -> the draw rate that happened. */
    private val CAL: Map<String, List<Pair<Double, Double>>> = mapOf(
        M1_WEEKDAY to listOf(0.0 to 0.0018, 0.005 to 0.0026, 0.01 to 0.0038, 0.02 to 0.0088, 0.04 to 0.0293, 0.08 to 0.0495, 0.15 to 0.096, 9.0 to 0.12),
        M1_WEEKEND to listOf(0.0 to 0.0035, 0.005 to 0.0056, 0.01 to 0.0068, 0.02 to 0.010, 0.04 to 0.0216, 0.08 to 0.0523, 0.15 to 0.108, 9.0 to 0.175),
        M5_WEEKDAY to listOf(0.01 to 0.0045, 0.02 to 0.0142, 0.04 to 0.0178, 9.0 to 0.020))

    fun draw(segment: String, pHigh: Double, pLow: Double): Double {
        val raw = 1.0 - pHigh - pLow
        val table = CAL[segment] ?: return raw.coerceIn(0.002, 0.25)
        return table.first { raw < it.first }.second
    }

    /** The odds of the trade in [direction] ("HIGH" / "LOW") of a pair whose model gives [pHigh] / [pLow]. */
    fun of(segment: String, direction: String, pHigh: Double, pLow: Double): Odds? {
        if (!pHigh.isFinite() || !pLow.isFinite()) return null
        val win = (if (direction == "HIGH") pHigh else pLow).coerceIn(0.0, 1.0)
        val d = draw(segment, pHigh, pLow).coerceIn(0.0, 1.0 - win)
        return Odds(win, (1.0 - win - d).coerceAtLeast(0.0), d)
    }

    /** Standard deviation of the last [n] 1-minute close-to-close changes (price units), or null with fewer than 20. */
    fun sigmaPerMinute(candles: List<Candle>, n: Int = 60): Double? {
        val c = candles.sortedBy { it.timeEpochMs }.takeLast(n + 1).map { it.close }.filter { it.isFinite() && it > 0.0 }
        if (c.size < 21) return null
        val d = c.zipWithNext { a, b -> b - a }
        val m = d.average(); val v = d.sumOf { (it - m) * (it - m) } / (d.size - 1)
        return sqrt(v).takeIf { it.isFinite() && it > 0.0 }
    }

    /** The chance that a running trade's side (winning / losing now) changes by the judge: [diff] = (price - entry) x direction. */
    fun reverse(diff: Double, sigmaPerMinute: Double, minutesLeft: Double): Double? {
        if (!diff.isFinite() || !(sigmaPerMinute > 0.0) || !(minutesLeft > 0.0)) return null
        if (diff == 0.0) return 0.5
        val z = abs(diff) / (sigmaPerMinute * sqrt(minutesLeft))
        return phi(-z).coerceIn(0.03, 0.5)
    }

    /** Standard normal distribution function (Abramowitz-Stegun 26.2.17, error below 1e-7). */
    fun phi(x: Double): Double {
        val t = 1.0 / (1.0 + 0.2316419 * abs(x))
        val pdf = exp(-x * x / 2.0) / sqrt(2.0 * Math.PI)
        val tail = pdf * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))))
        return if (x >= 0) 1.0 - tail else tail
    }

    /** "勝ち 53.1%・反転 45.2%・引き分け 1.7%" */
    fun text(o: Odds): String = "勝ち ${pc(o.win)}・反転 ${pc(o.reverse)}・引き分け ${pc(o.draw)}"
    fun pc(x: Double) = String.format(java.util.Locale.US, "%.1f%%", x * 100.0)
}

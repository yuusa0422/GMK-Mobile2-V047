package jp.gmk.mobile.domain

import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * v0.7.50: bitbank 1-minute candlestick files are partitioned by UTC day (yyyyMMdd = 00:00-23:59 UTC = 09:00-08:59 JST).
 * Up to v0.7.49 the app asked for the JST day and added the previous day only below 30 bars, so scans for
 * 09:35-10:00 JST had 35-60 BTC bars (61 needed): weekday BTC dropped out of the choice, weekend slots became I.
 */
object BitbankDays {
    private val FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd")
    fun key(epochMs: Long): String = Instant.ofEpochMilli(epochMs).atZone(ZoneOffset.UTC).format(FMT)
    /** Newest first: the UTC day of [nowMs], then the UTC day [lookbackMinutes] earlier when it differs. */
    fun keys(nowMs: Long, lookbackMinutes: Long): List<String> =
        listOf(key(nowMs), key(nowMs - lookbackMinutes * 60_000L)).distinct()
    /** UTC day key [dayOffset] days before [nowMs] (horizon background history). */
    fun keyDaysBefore(nowMs: Long, dayOffset: Int): String =
        Instant.ofEpochMilli(nowMs).atZone(ZoneOffset.UTC).minusDays(dayOffset.toLong()).format(FMT)
}

/**
 * v0.7.50: a D..H skip of the 3-minute evidence policy is followed exactly like an ENTRY
 * ("if it had been entered"). The result is stored on the SKIP row; OutcomeStatistics already
 * counts such rows only as skips, so they never enter a win rate or a losing streak.
 */
object ObservationPolicy {
    val GRADES = setOf("D", "E", "F", "G", "H")
    /** v0.7.56: a C that the ENTRY amount setting skips is followed too (no earlier version skipped a C). */
    const val C_SKIP_SINCE = "0.7.56"
    /** v0.7.54: every 1-minute board row is observation only and is followed too. */
    fun tracks(decision: String, grade: String, policyVersion: String): Boolean =
        decision == "SKIP" && ((grade in GRADES && RankStatistics.evidenceVersion(policyVersion) != null) ||
            (grade == "C" && RankStatistics.atLeast(RankStatistics.evidenceVersion(policyVersion), C_SKIP_SINCE)) ||
            OneMinuteObservation.isObservation(policyVersion))
    fun tracks(row: HistoryRow): Boolean = tracks(row.decision, row.grade, row.policyVersion)
}

/** [skipped]: v0.7.56 C rows skipped by the ENTRY amount setting are counted apart from the C rows that were entered. */
class RankCount(val grade: String, val skipped: Boolean = false) {
    var wins = 0
    var losses = 0
    var pending = 0
    var unresolved = 0
    var total = 0
    val resolved: Int get() = wins + losses
    val rate: Double? get() = if (resolved > 0) wins.toDouble() / resolved else null
}

class RankTable(
    val key: String,
    val title: String,
    val oneMinute: Boolean,
    val counts: List<RankCount>,
    val validated: Map<String, Double>,
    /** v0.7.54: the 1-minute board is observation only - every grade is a skip ("if entered"). */
    val observationOnly: Boolean = false
)

/**
 * v0.7.54: the 1-minute board (OneMinuteLocalEngine, a momentum-following heuristic) replayed on one year of real 1-minute
 * candles (scripts/onemin_sim_v0754.py): weekday 45.0% (draws 10.4%), weekend 30.6% (draws 42.1%); every confidence grade
 * 43-47% on weekdays, every period below 46%. Reversed it is 44.7% (a draw loses both ways). The best simple 1-minute trade
 * found (fade an FX spike of 3 sigma or more: 53.6% over the year) fell to 49.5% in September and 41.6% in October 2026.
 * No 1-minute trade is validated, so the board is shown for reference and its rows are SKIP observations.
 */
object OneMinuteObservation {
    const val POLICY = "GMK_V0735_NATIVE_1M_V0754_OBSERVE"
    const val GRADE = "E"
    const val REASON = "1分ボードは参考表示（1年の再現で平日45.0%・土日30.6%、反対向きも44.7%）。1分で勝てる形は見つかっていないため見送り"
    fun isObservation(policyVersion: String): Boolean = policyVersion.startsWith(POLICY)
}

/** History by operational grade: 3-minute evidence rows per app version and weekday/weekend; the 1-minute board apart. */
object RankStatistics {
    const val ONE_MINUTE_POLICY = "GMK_V0735_NATIVE_1M"
    val ORDER = listOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I")
    val ONE_MINUTE_ORDER = listOf("S", "A", "B", "C", "E")
    /** v0.7.85: the 1-minute judgment's grades (its skips D..H counted apart; up to v0.7.84 its D skips were not in the table). */
    val M1_ORDER = listOf("S", "A", "B", "C", "D", "E", "F", "G", "H")
    /** Versions whose ranks are the current v0.7.57 ranks (validated column shown). Earlier versions used other rank rules. */
    val CURRENT_RANK_VERSIONS = setOf("0.7.59")
    const val NOTE = "勝率は ENTRY だけ。「見送り・入っていたら」は見送った枠をそのまま入った場合の参考で、勝率・連敗には入りません。" +
        "検証%は1年分を、作ったのとは別の期間で採点した勝率（S/Aの時間帯ルールは偶然の可能性も残るため実際は少し低めを見込む）。" +
        "v0.7.66: 平日も5分ごとに判定し（v0.7.58〜v0.7.65は毎分）、どの1時間も70%以上ENTRY。S/A（時間帯ルール3つ）は3分判定、B/C/D は5分判定。" +
        "S/A/B は55%以上、C は70%に入る分（平日53.1%・円の5ペア＋仮想通貨4つ）。土日は仮想通貨4つの土日モデルで B 61.2%・C 54.9%（v0.7.71）。" +
        "設定で見送ったCは「C 見送り」に入ります。v0.7.56以前の表はランクの決め方が違います。" +
        "件数が少ないうちは上下に大きくぶれます。"
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    private val VERSION = Regex("^GMK_V0740_V(\\d)(\\d)(\\d)(\\d)")
    private val VERSION_CACHE = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun isOneMinute(row: HistoryRow): Boolean = row.policyVersion.startsWith(ONE_MINUTE_POLICY)
    private fun m1Order(row: HistoryRow): Boolean = OneMinutePolicy.isPolicy(row) && !OneMinuteObservation.isObservation(row.policyVersion)

    /** "0.7.49" for GMK_V0740_V0749_EVIDENCE..., null for any other policy. */
    fun evidenceVersion(policyVersion: String): String? {
        // v0.7.79: remembered per policy text (a history has a few dozen; the screens asked the regular expression for every row each minute)
        VERSION_CACHE[policyVersion]?.let { return it.ifEmpty { null } }
        val v = VERSION.find(policyVersion)?.groupValues?.let { "${it[1]}.${it[2]}.${it[3]}${it[4]}" }
        if (VERSION_CACHE.size < 512) VERSION_CACHE[policyVersion] = v ?: ""
        return v
    }

    fun versionKey(v: String?): Int = v?.split('.')?.mapNotNull { it.toIntOrNull() }?.fold(0) { a, b -> a * 100 + b } ?: -1
    /** True when evidence version [v] (e.g. "0.7.56") is [min] or later; false for null. */
    fun atLeast(v: String?, min: String): Boolean = v != null && versionKey(v) >= versionKey(min)

    fun isWeekend(entryTimeJst: String): Boolean? =
        FastTime.jst(entryTimeJst)?.let { it.dayOfWeek.value >= 6 }     // v0.7.79: without the text parser (every row of the tables)

    fun tables(rows: List<HistoryRow>): List<RankTable> {
        class Group(val title: String, val oneMinute: Boolean, val version: String?, val weekend: Boolean, val counts: LinkedHashMap<String, RankCount>,
                    val observe: Boolean = false)
        val groups = LinkedHashMap<String, Group>()
        for (r in rows) {
            val weekend = isWeekend(r.entryTimeJst) ?: continue
            val seg = if (weekend) "土日" else "平日"
            val oneMinute = isOneMinute(r)
            val version = if (oneMinute) null else evidenceVersion(r.policyVersion) ?: continue
            val order = if (m1Order(r)) M1_ORDER else if (oneMinute) ONE_MINUTE_ORDER else ORDER
            if (r.grade !in order) continue
            val observe = oneMinute && OneMinuteObservation.isObservation(r.policyVersion)
            val m1 = OneMinutePolicy.isPolicy(r)        // v0.7.75 1-minute judgment (model, 80% per hour)
            // v0.7.83: the current 1-minute models apart from the v0.7.75-v0.7.82 rows (other models; 80% up to v0.7.80)
            val m1Now = m1 && OneMinutePolicy.isCurrent(r)
            val key = if (observe) "1mobs|$seg" else if (m1Now) "1m83|$seg" else if (m1) "1m75|$seg" else if (oneMinute) "1m|$seg" else "$version|$seg"
            val g = groups.getOrPut(key) {
                val title = if (observe) "1分ボード $seg（参考・見送り）" else if (m1Now) "1分判定 $seg（v0.7.83・毎時${OneMinutePolicy.PERCENT}%）"
                    else if (m1) "1分判定 $seg（v0.7.75〜v0.7.82の旧モデル）"
                    else if (oneMinute) "1分ボード $seg（簡易ルール・検証なし）" else "v$version $seg（${if (weekend) "3分判定" else "S/Aは3分・B/C/Dは5分判定"}）"
                Group(title, oneMinute, version, weekend, LinkedHashMap<String, RankCount>().also { m ->
                    order.forEach {
                        m[it] = RankCount(it)
                        // v0.7.76: C1 / C2 / C3 lines under C (a row with a sub-grade counts in C - or B when promoted - and in its line)
                        if (it == "C" && (!oneMinute || m1)) SubGrades.LABELS.forEach { s -> m[s] = RankCount(s) }
                        if (it == "C" && !oneMinute) { m[C_SKIP_KEY] = RankCount("C", skipped = true); SubGrades.LABELS.forEach { s -> m["$s|SKIP"] = RankCount(s, skipped = true) } }
                    }
                }, observe)
            }
            val skippedC = !oneMinute && r.grade == "C" && r.decision == "SKIP"
            fun count(c: RankCount) {
                c.total++
                when (r.resultStatus) {
                    "WIN" -> c.wins++
                    "LOSE" -> c.losses++
                    "WAIT_ENTRY", "WAIT_JUDGE" -> c.pending++
                    else -> c.unresolved++
                }
            }
            // v0.7.85: a D skip of v0.7.84 or earlier (every skip was D) is 旧D in the current tables, never mixed with the new D band
            val legacyD = (m1Now || (!oneMinute && version in CURRENT_RANK_VERSIONS)) && SkipGrades.legacyD(r)
            count(if (legacyD) g.counts.getOrPut(SkipGrades.LEGACY_D) { RankCount(SkipGrades.LEGACY_D) } else g.counts.getValue(if (skippedC) C_SKIP_KEY else r.grade))
            val sub = r.assessment?.subGrade
            // v0.7.78: only live-price sub-grades (the backup model's C has no validated C1 / C2 / C3 rate)
            if (sub != null && sub.fresh && !observe && (r.grade == "C" || (r.grade == "B" && sub.promoted)))
                g.counts[if (skippedC) "${sub.label}|SKIP" else sub.label]?.let(::count)
        }
        return groups.entries
            .sortedWith(compareBy<Map.Entry<String, Group>> { if (it.value.oneMinute) 1 else 0 }
                .thenBy { if (it.value.observe) 0 else 1 }
                .thenBy { if (it.key.startsWith("1m83|")) 0 else 1 }
                .thenByDescending { versionKey(it.value.version) }
                .thenBy { if (it.value.weekend) 1 else 0 })
            .map { (key, g) ->
                val validated = if (!g.oneMinute && g.version in CURRENT_RANK_VERSIONS)
                    g.counts.values.map { it.grade }.distinct().mapNotNull { grade -> EvidencePolicy.gradeRate(true, g.weekend, grade)?.let { grade to it } }.toMap() +
                        subRates(if (g.weekend) SubGrades.WEEKEND else SubGrades.WEEKDAY) +
                        // v0.7.85: D..H = the bands of SkipGrades (their win rate if entered)
                        SkipGrades.GRADES.mapNotNull { gr -> SkipGrades.rate(if (g.weekend) SkipGrades.E3 else SkipGrades.W5, gr)?.let { gr to it.first / 100.0 } }.toMap()
                else if (key.startsWith("1m83|")) EvidenceModelM2Data.gradeRates(g.weekend) + subRates(if (g.weekend) SubGrades.M1_WEEKEND else SubGrades.M1_WEEKDAY) +
                    SkipGrades.GRADES.mapNotNull { gr -> SkipGrades.rate(if (g.weekend) SkipGrades.M1E else SkipGrades.M1W, gr)?.let { gr to it.first / 100.0 } }.toMap()
                else emptyMap()
                RankTable(key, g.title, g.oneMinute, g.counts.values.filter { it.total > 0 }, validated, g.observe)
            }
    }

    private fun pct(x: Double): String = String.format(Locale.US, "%.1f%%", x * 100.0)
    private fun subRates(segment: String): Map<String, Double> = SubGrades.BANDS[segment].orEmpty().filter { it.rate > 0.0 }.associate { it.label to it.rate }

    private const val C_SKIP_KEY = "C|SKIP"

    /**
     * v0.7.73 live monitor: the newest [MONITOR_LAST] settled AUTO ENTRY trades of the current policy against what the 1-year check
     * expects for their grades ([EvidencePolicy.gradeRate]; a draw is a loss). z below -2 = clearly lower than expected (the market may
     * have changed; time to rebuild the model with new data). Also the current losing streak (1-year check: after a loss the next ENTRY
     * won 54.3%, after a win 52.7%; losing streaks were as long as chance would give, not longer).
     */
    const val MONITOR_LAST = 300
    data class Monitor(val n: Int, val wins: Int, val expected: Double, val z: Double, val lossStreak: Int, val longestLossStreak: Int)

    fun monitor(rows: List<HistoryRow>, last: Int = MONITOR_LAST): Monitor? {
        val current = evidenceVersion(EvidencePolicy.POLICY_TAG)
        val done = rows.asSequence()
            .filter { it.source == "AUTO" && it.candidateRank == 1 && it.decision == "ENTRY" && !isOneMinute(it) &&
                evidenceVersion(it.policyVersion) == current && it.resultStatus in setOf("WIN", "LOSE") }
            .mapNotNull { r -> FastTime.instant(r.entryTimeJst)?.let { it to r } }
            .sortedBy { it.first }.map { it.second }.toList()
        if (done.isEmpty()) return null
        val tail = done.takeLast(last); val n = tail.size; val wins = tail.count { it.resultStatus == "WIN" }
        // v0.7.76: a row with a validated sub-grade (C1 / C2 / C3, a promoted C1 too) expects that sub-grade's rate
        val e = tail.map { r -> r.assessment?.subGrade?.rate ?: EvidencePolicy.gradeRate(true, isWeekend(r.entryTimeJst) ?: false, r.grade) ?: 0.5 }.average()
        val z = (wins.toDouble() / n - e) / Math.sqrt(maxOf(e * (1.0 - e) / n, 1e-12))
        var streak = 0; for (r in done.asReversed()) { if (r.resultStatus == "LOSE") streak++ else break }
        var longest = 0; var run = 0; for (r in tail) { if (r.resultStatus == "LOSE") { run++; longest = maxOf(longest, run) } else run = 0 }
        return Monitor(n, wins, e, z, streak, longest)
    }

    fun monitorText(m: Monitor?): String {
        if (m == null) return "実績モニター: まだ判定済みのENTRYがありません"
        val actual = m.wins.toDouble() / m.n
        val verdict = when {
            m.n < 100 -> "件数が少ないので参考"
            m.z <= -2.0 -> "要注意: 検証より明らかに低い（相場が変わった可能性。新しいデータでモデルの作り直しを検討）"
            m.z >= 2.0 -> "検証より明らかに高い"
            else -> "検証の見込みの範囲内"
        }
        return "実績モニター（直近${m.n}回のENTRY）: 実績 ${pct(actual)}・検証の見込み ${pct(m.expected)}（${verdict}）。" +
            "今の連敗 ${m.lossStreak}・この中の最長連敗 ${m.longestLossStreak}（1年の検証: 負けの次は54.3%・勝ちの次は52.7%、連敗の長さは偶然と同じ程度）"
    }

    /**
     * v0.7.56: share of 3-minute AUTO slots entered, per segment ("平日"/"土日") and JST hour: hour -> (slots, ENTRY).
     * Only rows of the current policy version are counted (other versions entered other amounts).
     */
    fun entryShareByHour(rows: List<HistoryRow>): Map<String, Map<Int, Pair<Int, Int>>> {
        val out = LinkedHashMap<String, java.util.TreeMap<Int, Pair<Int, Int>>>()
        val current = evidenceVersion(EvidencePolicy.POLICY_TAG)
        for (r in rows) {
            if (r.source != "AUTO" || r.candidateRank != 1 || isOneMinute(r) || evidenceVersion(r.policyVersion) != current) continue
            val t = FastTime.jst(r.entryTimeJst) ?: continue
            val seg = if (t.dayOfWeek.value >= 6) "土日" else "平日"
            val m = out.getOrPut(seg) { java.util.TreeMap() }
            val old = m[t.hour] ?: (0 to 0)
            // v0.7.58: the slots are the 5-minute boundaries; ENTRY rows of the minutes between them count as entries of that hour.
            // v0.7.68: an I row (no data, judged impossible) is not a slot - the hour rule (LiveEntryState) does not count it either
            val slot = t.second == 0 && t.minute % 5 == 0 && r.grade != "I"
            m[t.hour] = (old.first + (if (slot) 1 else 0)) to (old.second + if (r.decision == "ENTRY") 1 else 0)
        }
        return out
    }

    /** One line per segment: "平日 ENTRY 61%（120/197枠）" for the history panel; empty when nothing is recorded yet. */
    fun entryShareText(rows: List<HistoryRow>): String = entryShareByHour(rows).entries.joinToString("　") { (seg, hours) ->
        val slots = hours.values.sumOf { it.first }; val entries = hours.values.sumOf { it.second }
        "$seg ENTRY ${if (slots > 0) Math.round(entries * 100.0 / slots) else 0}%（$entries/${slots}枠）"
    }

    fun isSkipGrade(table: RankTable, grade: String): Boolean =
        grade == "I" || grade in ObservationPolicy.GRADES || grade == SkipGrades.LEGACY_D || (table.oneMinute && grade == "E") || table.observationOnly
    fun isSkipCount(table: RankTable, c: RankCount): Boolean = c.skipped || isSkipGrade(table, c.grade)

    fun lineText(table: RankTable, c: RankCount): String {
        val wait = if (c.pending > 0) "（判定待ち${c.pending}）" else ""
        val v = table.validated[c.grade]?.let { " ｜検証 ${pct(it)}" } ?: ""
        val name = if (c.grade in SubGrades.LABELS) "└${c.grade}" else if (c.grade == SkipGrades.LEGACY_D) SkipGrades.LEGACY_D_TEXT else c.grade
        return when {
            c.grade == "I" -> "I  判定不能 ${c.total}件（データ不足など・観察のみ）"
            isSkipCount(table, c) -> "$name  見送り ${c.total}件" +
                (c.rate?.let { "・入っていたら ${c.wins}勝${c.losses}敗 ${pct(it)}" } ?: "") + wait + v
            else -> "$name  ${c.wins}勝${c.losses}敗 ${c.rate?.let(::pct) ?: "—"}" + wait + v
        }
    }
}

/** History list filter by operational grade (replaces the retired chart-similarity E..H filter). */
object RankFilter {
    val filters = listOf("すべて", "S", "A", "B", "C", "C1", "C2", "C3", "D", "E", "F", "G", "H", "I", "1分")      // v0.7.85: D..H apart (was "D〜H")
    fun matches(row: HistoryRow, filter: String): Boolean {
        val oneMinute = RankStatistics.isOneMinute(row)
        return when (filter) {
            "すべて" -> true
            "1分" -> oneMinute
            // v0.7.76: the sub-grade of a C (or promoted C1) row; v0.7.78: 5-minute rows only, like "C" (the 1-minute rows are under "1分")
            in SubGrades.LABELS -> !oneMinute && row.assessment?.subGrade?.label == filter
            // v0.7.85: "D" = the new D band only (the old all-skip D rows are 旧D)
            "D" -> !oneMinute && row.grade == "D" && !SkipGrades.legacyD(row)
            else -> !oneMinute && row.grade == filter
        }
    }
}

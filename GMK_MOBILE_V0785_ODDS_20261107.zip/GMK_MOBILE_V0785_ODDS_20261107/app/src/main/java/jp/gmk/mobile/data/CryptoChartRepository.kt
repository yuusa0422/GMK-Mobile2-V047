package jp.gmk.mobile.data

import jp.gmk.mobile.domain.Candle
import jp.gmk.mobile.domain.CryptoChartMath
import jp.gmk.mobile.domain.CryptoPairs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.time.Instant
import java.util.concurrent.TimeUnit

/**
 * v0.7.74: chart candles of the crypto pairs (BTC/JPY, ETH/JPY, BTC/USD, ETH/USD) for the chart screen only. Up to v0.7.73 the chart
 * offered the five yen crosses and bitbank BTC/JPY, so a TOP1 of ETH/JPY, BTC/USD or ETH/USD left the followed chart empty. Same
 * sources as the decisions (Coinbase, Binance as the backup; X/JPY = X/USD x USD/JPY), but its own HTTP client and never read by a
 * decision, a rank or a result.
 */
class CryptoChartRepository(timeoutSeconds: Long = 8) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS).readTimeout(timeoutSeconds, TimeUnit.SECONDS).callTimeout(timeoutSeconds, TimeUnit.SECONDS)
        .build()

    private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        client.newCall(Request.Builder().url(url).header("User-Agent", "GMK-Mobile/0.7.85").header("Accept", "application/json").build())
            .execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}: ${text.take(80)}")
                text
            }
    }

    /** USD candles of [product] (BTC-USD / ETH-USD) for a chart [timeframe], Coinbase first, Binance when Coinbase fails. */
    suspend fun usdCandles(product: String, timeframe: String, focusMs: Long?, nowMs: Long = System.currentTimeMillis()): Pair<List<Candle>, String> {
        val g = CryptoChartMath.granularitySeconds(timeframe)
        require(g > 0) { "unsupported chart timeframe: $timeframe" }
        val (start, end) = CryptoChartMath.window(g, focusMs, nowMs)
        val periodMs = CryptoChartMath.periodMs(timeframe)
        var coinbaseError: String? = null
        try {
            val url = "https://api.exchange.coinbase.com/products/$product/candles".toHttpUrl().newBuilder()
                .addQueryParameter("granularity", g.toString())
                .addQueryParameter("start", Instant.ofEpochSecond(start).toString())
                .addQueryParameter("end", Instant.ofEpochSecond(end).toString())
                .build().toString()
            val c = CryptoChartMath.confirmed(CryptoChartMath.aggregate(CryptoPairs.parseCandles(get(url)), g * 1000L, periodMs), periodMs, nowMs)
            if (c.isNotEmpty()) return c to "Coinbase"
            coinbaseError = "Coinbase: 足なし"
        } catch (ce: CancellationException) { throw ce } catch (e: Exception) { coinbaseError = "Coinbase: ${e.message ?: e::class.java.simpleName}" }
        val symbol = CryptoPairs.binanceSymbol(product) ?: throw IOException(coinbaseError)
        val url = "https://data-api.binance.vision/api/v3/klines".toHttpUrl().newBuilder()
            .addQueryParameter("symbol", symbol).addQueryParameter("interval", CryptoChartMath.binanceInterval(timeframe))
            .addQueryParameter("startTime", (start * 1000L).toString()).addQueryParameter("endTime", (end * 1000L).toString())
            .addQueryParameter("limit", "1000")
            .build().toString()
        val c = CryptoChartMath.confirmed(CryptoChartMath.aggregate(CryptoPairs.parseBinanceKlines(get(url)), g * 1000L, periodMs), periodMs, nowMs)
        if (c.isEmpty()) throw IOException("$coinbaseError / Binance: 足なし")
        return c to "Binance（予備）"
    }
}

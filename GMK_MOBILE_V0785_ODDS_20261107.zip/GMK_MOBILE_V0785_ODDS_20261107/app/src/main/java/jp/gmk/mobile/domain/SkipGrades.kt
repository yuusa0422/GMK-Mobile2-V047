package jp.gmk.mobile.domain

import java.util.Locale

/**
 * v0.7.85 見送りの強さ D / E / F / G / H (display and record only; ENTRY / SKIP never change). A skipped trade is graded by its place in
 * its hour ("その時間の上位何%か", the same hour tables the judgment uses):
 *   D = top 70% (weekend 3-minute: 60-70%) - skipped although strong (the hour already had its 70%, or below the hour's bar of the moment)
 *   E = 70-80%, F = 80-90%, G = 90-95%, H = below the top 95% (the weakest).
 * Win rate if it had been entered and draw rate per band, one year scored out of sample (research_v0784/bands_v0784.py; 1-minute and
 * weekend: the mean with 2023-24). A draw loses.
 */
object SkipGrades {
    val GRADES = listOf("D", "E", "F", "G", "H")
    const val W5 = "w5"; const val E3 = "e3"; const val M1W = "m1w"; const val M1E = "m1e"

    /** The skip grade of a candidate whose top share in its hour is [top] (0 = the strongest, 1 = the weakest). */
    fun of(top: Double): String = when {
        !top.isFinite() -> "D"
        top < 0.70 -> "D"
        top < 0.80 -> "E"
        top < 0.90 -> "F"
        top < 0.95 -> "G"
        else -> "H"
    }

    /** (win %, draw %) if entered. */
    val RATES: Map<String, Map<String, Pair<Double, Double>>> = mapOf(
        W5 to mapOf("D" to (52.8 to 0.7), "E" to (51.0 to 0.6), "F" to (50.4 to 0.8), "G" to (50.0 to 0.5), "H" to (51.7 to 0.5)),
        E3 to mapOf("D" to (51.8 to 0.7), "E" to (52.3 to 0.5), "F" to (51.2 to 0.7), "G" to (49.5 to 0.5), "H" to (50.2 to 1.1)),
        M1W to mapOf("D" to (51.9 to 0.3), "E" to (51.4 to 0.4), "F" to (51.1 to 0.4), "G" to (50.9 to 0.4), "H" to (50.3 to 0.8)),
        M1E to mapOf("D" to (52.7 to 1.3), "E" to (50.5 to 2.0), "F" to (50.0 to 2.2), "G" to (49.1 to 3.5), "H" to (47.5 to 8.1)))

    fun rate(segment: String, grade: String): Pair<Double, Double>? = RATES[segment]?.get(grade)

    /** "上位70〜80%" - the band of [grade] in [segment]. */
    fun band(segment: String, grade: String): String = when (grade) {
        "D" -> if (segment == E3) "上位60〜70%" else "上位70%以内"
        "E" -> "上位70〜80%"
        "F" -> "上位80〜90%"
        "G" -> "上位90〜95%"
        "H" -> "上位95%より下"
        else -> ""
    }

    /** One word for the band (the screens show it next to the grade). */
    fun word(grade: String): String = when (grade) {
        "D" -> "惜しい"; "E" -> "やや弱い"; "F" -> "弱い"; "G" -> "とても弱い"; "H" -> "最弱"; else -> ""
    }

    /** "見送り E（やや弱い・上位70〜80%）入っていたら 51.0%・引き分け 0.6%" */
    fun text(segment: String, grade: String): String {
        val r = rate(segment, grade)
        val tail = r?.let { "入っていたら ${f(it.first)}%・引き分け ${f(it.second)}%" } ?: ""
        return "見送り $grade（${word(grade)}・${band(segment, grade)}）$tail"
    }

    /** The segment of a history row's skip grade (null when it has none). */
    fun segmentOf(oneMinute: Boolean, weekend: Boolean): String = if (oneMinute) (if (weekend) M1E else M1W) else (if (weekend) E3 else W5)

    /**
     * A D skip recorded before v0.7.85, when every skip was D (its strength is not known). The v0.7.85 rows carry the band word
     * ("惜しい") in their label; these old rows are counted and shown apart as 旧D so they never mix with the new D.
     */
    fun legacyD(row: HistoryRow): Boolean = row.decision == "SKIP" && row.grade == "D" && row.assessment?.correctionLabel.let { it == null || (word("D") !in it && "注意の時間帯" !in it) }
    const val LEGACY_D = "旧D"
    const val LEGACY_D_TEXT = "旧D（v0.7.84までの見送り。当時は見送りが全部Dで、強さの区別なし）"

    private fun f(x: Double) = String.format(Locale.US, "%.1f", x)
}

package jp.gmk.mobile.domain

import java.time.Instant
import java.time.ZoneId
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.7.82 1-minute judgment inputs (research_v0782/m1_lab_v0782.py `prod_feats` + `des`, ext inputs). Per product (BTC-USD, ETH-USD and,
 * on weekdays, the five yen crosses): the 241 minutes opening at entry-241 min .. entry-1 min, the last one being the forming minute
 * closed at the live price. X/JPY crypto pairs use their X/USD inputs; the yen crosses have no volume (Yahoo), so their volume inputs are
 * missing (the research left them missing too). The cross inputs: the other coin for BTC / ETH, the mean of the other four crosses for a
 * yen cross; the crypto basket (mean r1 / r5 of BTC and ETH) for every pair.
 */
object CandleModelM2 {
    val CRYPTO = listOf("BTCJPY", "ETHJPY", "BTCUSD", "ETHUSD")
    val FX = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY")
    /** The pairs of the weekday model (its pair inputs in this order) and of the weekend model. */
    val PAIRS_WEEKDAY = CRYPTO + FX
    val PAIRS_WEEKEND = CRYPTO
    fun pairs(weekend: Boolean) = if (weekend) PAIRS_WEEKEND else PAIRS_WEEKDAY
    fun productOf(pair: String): String? = when (pair) { "BTCJPY", "BTCUSD" -> "BTCUSD"; "ETHJPY", "ETHUSD" -> "ETHUSD"; in FX -> pair; else -> null }
    val SIGNED = listOf("r1", "r2", "r3", "r5", "r10", "r15", "r30", "r60", "pos15", "pos60", "bbz", "body", "gap", "body2", "up5", "up15", "cr_r1", "cr_r5",
        "r120", "r240", "pos240", "o_r1", "o_r2", "o_r5", "sp_r1", "sp_r5", "vs5", "vs15", "cl", "cl2", "run", "ma_dev60")
    val UNSIGNED = listOf("rv60", "rv15_60", "rng", "rng2", "vol2", "rv60_240", "vol5", "rngz15", "dow")
    fun features(weekend: Boolean): List<String> =
        SIGNED + listOf("wk_with", "wk_against") + UNSIGNED + listOf("hour", "minute", "wkend") + pairs(weekend).map { "is_$it" } + "dir"
    fun featureCount(weekend: Boolean) = features(weekend).size
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    const val WINDOW = 241

    /**
     * One product's own inputs for the entry minute [entryMs] (exact minute), or null when a finished minute of the window is missing.
     * The forming minute (opening at entry-1 min) takes its open / high / low from its candle when present (else the previous close) and
     * the live price [live] as its close. [hasVolume] false: every volume is missing (yen crosses).
     */
    fun product(candles: List<Candle>, live: Double, entryMs: Long, hasVolume: Boolean): Map<String, Double>? {
        if (!live.isFinite() || live <= 0.0) return null
        val byT = HashMap<Long, Candle>(candles.size * 2); for (c in candles) byT[c.timeEpochMs] = c
        val n = WINDOW
        val o = DoubleArray(n); val h = DoubleArray(n); val l = DoubleArray(n); val c = DoubleArray(n); val v = DoubleArray(n)
        for (k in 0 until n) {
            val t = entryMs - (n - k) * 60_000L
            val bar = byT[t]
            if (k < n - 1) {
                if (bar == null || !(bar.close > 0.0) || !(bar.open > 0.0) || !(bar.high > 0.0) || !(bar.low > 0.0)) return null
                o[k] = bar.open; h[k] = bar.high; l[k] = bar.low; c[k] = bar.close; v[k] = if (hasVolume) bar.volume else Double.NaN
            } else {
                val op = bar?.open?.takeIf { it > 0.0 } ?: c[k - 1]
                o[k] = op; h[k] = max(bar?.high ?: op, max(op, live)); l[k] = min(bar?.low ?: op, min(op, live)); c[k] = live
                v[k] = if (hasVolume) (bar?.volume ?: Double.NaN) else Double.NaN
            }
        }
        val i = n - 1
        val lg = DoubleArray(n) { ln(c[it]) }
        val ret = DoubleArray(n) { if (it == 0) Double.NaN else lg[it] - lg[it - 1] }
        fun z(x: Double) = if (x.isNaN()) 0.0 else x                       // numpy nan_to_num
        fun sumSq(from: Int): Double { var s = 0.0; for (k in from..i) s += z(ret[k] * ret[k]); return s }
        val norm = max(sqrt(max(sumSq(i - 59), 0.0) / 60.0), 1e-8)
        val n15 = sqrt(max(sumSq(i - 14), 0.0) / 15.0)
        val n240 = sqrt(max(sumSq(i - 239), 0.0) / 240.0)
        val x = LinkedHashMap<String, Double>()
        for (kk in intArrayOf(1, 2, 3, 5, 10, 15, 30, 60, 120, 240)) x["r$kk"] = (lg[i] - lg[i - kk]) / (norm * sqrt(kk.toDouble()))
        fun range(from: Int): Pair<Double, Double> {
            var hi = Double.NEGATIVE_INFINITY; var lo = Double.POSITIVE_INFINITY
            for (k in from..i) { hi = max(hi, h[k]); lo = min(lo, l[k]) }
            return hi to lo
        }
        val (h15, l15) = range(i - 14); val (h60, l60) = range(i - 59); val (h240, l240) = range(i - 239)
        x["pos15"] = (c[i] - l15) / max(h15 - l15, 1e-12) * 2 - 1
        x["pos60"] = (c[i] - l60) / max(h60 - l60, 1e-12) * 2 - 1
        x["pos240"] = (c[i] - l240) / max(h240 - l240, 1e-12) * 2 - 1
        var m20 = 0.0; for (k in i - 19..i) m20 += c[k]; m20 /= 20.0
        var v20 = 0.0; for (k in i - 19..i) v20 += (c[k] - m20) * (c[k] - m20); v20 /= 20.0
        x["bbz"] = (c[i] - m20) / sqrt(max(v20, 1e-16))
        var m60 = 0.0; for (k in i - 59..i) m60 += c[k]; m60 /= 60.0
        x["ma_dev60"] = (lg[i] - ln(m60)) / (norm * sqrt(60.0))
        val lo = ln(o[i])
        x["body"] = (lg[i] - lo) / norm; x["gap"] = (lo - lg[i - 1]) / norm; x["body2"] = (lg[i - 1] - ln(o[i - 1])) / norm
        fun updown(from: Int): Double { var u = 0; var d = 0; for (k in from..i) { if (ret[k] > 0) u++ else if (ret[k] < 0) d++ }; return (u - d).toDouble() }
        x["up5"] = updown(i - 4); x["up15"] = updown(i - 14)
        x["uw"] = (ln(h[i]) - max(lo, lg[i])) / norm; x["lw"] = (min(lo, lg[i]) - ln(l[i])) / norm
        x["rv60"] = norm * 1e4; x["rv15_60"] = n15 / norm; x["rv60_240"] = norm / max(n240, 1e-8)
        x["rng"] = (ln(h[i]) - ln(l[i])) / norm; x["rng2"] = (ln(h[i - 1]) - ln(l[i - 1])) / norm
        // volumes of the finished minutes (numpy: cumulative sums of nan_to_num(v); a ratio of missing volumes is NaN, 0 / 0 too)
        fun vsum(from: Int, to: Int): Double { var s = 0.0; for (k in from until to) s += z(v[k]); return s }
        fun svsum(from: Int, to: Int): Double { var s = 0.0; for (k in from until to) s += z(v[k] * Math.signum(z(ret[k]))); return s }
        val mv60 = vsum(i - 60, i) / 60.0
        x["vol2"] = v[i - 1] / mv60
        x["vol5"] = (vsum(i - 5, i) / 5.0) / mv60
        x["vs5"] = svsum(i - 5, i) / max(vsum(i - 5, i), 1e-12)
        x["vs15"] = svsum(i - 15, i) / max(vsum(i - 15, i), 1e-12)
        x["cl"] = (c[i] - l[i]) / max(h[i] - l[i], 1e-12) * 2 - 1
        x["cl2"] = (c[i - 1] - l[i - 1]) / max(h[i - 1] - l[i - 1], 1e-12) * 2 - 1
        var rs = 0.0; for (k in i - 15 until i) rs += z(ln(h[k]) - ln(l[k]))
        x["rngz15"] = (ln(h[i]) - ln(l[i])) / max(rs / 15.0, 1e-12)
        // the run of same-sign minutes ending at the forming minute (+k up, -k down; a flat minute ends it), clipped to 8
        var run = 0.0
        for (k in 1..i) {
            val sg = Math.signum(z(ret[k]))
            run = if (sg != 0.0 && (Math.signum(run) == 0.0 || Math.signum(run) == sg)) run + sg else sg
        }
        x["run"] = run.coerceIn(-8.0, 8.0)
        return x
    }

    /** The cross inputs (o_r1, o_r2, o_r5) of [pair] from the other products' inputs, or null when one is missing. */
    fun cross(pair: String, inputs: Map<String, Map<String, Double>>): Triple<Double, Double, Double>? {
        val others: List<String> = when (productOf(pair)) {
            "BTCUSD" -> listOf("ETHUSD"); "ETHUSD" -> listOf("BTCUSD")
            else -> FX.filter { it != pair }
        }
        val xs = others.map { inputs[it] ?: return null }
        fun mean(k: String) = xs.sumOf { it.getValue(k) } / xs.size
        return Triple(mean("r1"), mean("r2"), mean("r5"))
    }

    /** The design row of [pair] in direction [dir] (+1 HIGH / -1 LOW) for the weekday ([weekend] false) or weekend model. */
    fun design(pair: String, x: Map<String, Double>, cross: Triple<Double, Double, Double>, basket: Pair<Double, Double>, entryMs: Long, dir: Int, weekend: Boolean): DoubleArray {
        val d = dir.toDouble()
        val t = Instant.ofEpochMilli(entryMs).atZone(JST)
        val pairs = pairs(weekend)
        val out = DoubleArray(featureCount(weekend)); var j = 0
        for (f in SIGNED) out[j++] = d * when (f) {
            "cr_r1" -> basket.first; "cr_r5" -> basket.second
            "o_r1" -> cross.first; "o_r2" -> cross.second; "o_r5" -> cross.third
            "sp_r1" -> x.getValue("r1") - cross.first; "sp_r5" -> x.getValue("r5") - cross.third
            else -> x.getValue(f)
        }
        out[j++] = if (dir == 1) x.getValue("uw") else x.getValue("lw")
        out[j++] = if (dir == 1) x.getValue("lw") else x.getValue("uw")
        for (f in UNSIGNED) out[j++] = if (f == "dow") (t.dayOfWeek.value - 1).toDouble() else x.getValue(f)
        out[j++] = t.hour.toDouble(); out[j++] = t.minute.toDouble(); out[j++] = if (t.dayOfWeek.value >= 6) 1.0 else 0.0
        for (p in pairs) out[j++] = if (p == pair) 1.0 else 0.0
        out[j++] = d
        check(j == out.size)
        return out
    }
}

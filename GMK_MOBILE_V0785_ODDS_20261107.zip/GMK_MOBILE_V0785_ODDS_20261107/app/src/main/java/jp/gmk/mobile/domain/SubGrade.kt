package jp.gmk.mobile.domain

import java.util.Locale

/**
 * v0.7.76 strength inside grade C (C1 / C2 / C3) of one trade. [top] = the share of its hour's slots whose best probability is at or
 * above this trade's ([SubGrades.topShare] on the hour table the decision already uses; 0.07 = the top 7% of that hour), [probability] =
 * the model's probability of winning. [promoted] = a C1 that the user's setting turned into B ([SubGrades.PROMOTABLE]).
 * Explanation and statistics only: the ENTRY / SKIP of a slot and the hour's 70% / 80% never read it.
 */
data class SubGrade(
    val label: String,
    val segment: String,
    val top: Double,
    val probability: Double,
    val fresh: Boolean = true,
    val promoted: Boolean = false
) {
    /** The validated win rate of this sub-grade (null for the backup model or an unknown segment). */
    val rate: Double? get() = SubGrades.band(segment, label)?.takeIf { fresh }?.rate
    /** "C1" or "B↑C1" (a promoted C1). */
    val shown: String get() = if (promoted) "B↑$label" else label
}

/**
 * v0.7.76 (README_V0776.txt): grade C split by the trade's place in its hour's distribution (the same hour tables the ENTRY rule uses).
 * Research: scripts/v0776_csub_weekday.py, v0776_csub_weekend.py, research_v0775/v0776_csub_m1.py - each period scored by a model fit on
 * the other periods with the hour tables of the other periods (as the app's rule), and 2023-24 with the production model and tables.
 * Weekday 5-minute C (70% fill, 53.1%): top 10% of the hour 56.8%, 10-30% 53.2%, below 52.2%; 2023-24 55.9 / 53.6 / 51.7.
 * Weekend C (top 8-60%, 54.9%): 8-15% 59.2%, 15-30% 55.8%, below 53.4%; 2023-24 56.8 / 56.2 / 52.4.
 * 1-minute C: top 5-15% weekday 52.1% / weekend 54.5%, 15-40% 51.5 / 52.5, below 51.2 / 50.9 (2023-24 54.4 / 54.7 for C1).
 * The weekday and weekend C1 are about as strong as their B, so the setting「C1をBに昇格」(default OFF) can make them B: they then
 * enter in every ENTRY mode, notify and cut in as B, and count in the C1 line of the history as well.
 */
object SubGrades {
    const val WEEKDAY = "5w"
    const val WEEKEND = "we"
    const val M1_WEEKDAY = "1w"
    const val M1_WEEKEND = "1e"

    /** One sub-grade: trades with top < [maxTop] (and >= the band before) of [segment]; validated [rate] (rotation), [y2324], per day. */
    data class Band(val label: String, val maxTop: Double, val rate: Double, val y2324: Double?, val perDay: Double, val periods: List<Double>)

    val BANDS: Map<String, List<Band>> = mapOf(
        // weekday 5-minute C (the 70% fill): rotation 53.09%, 97.3/day
        WEEKDAY to listOf(
            Band("C1", 0.10, 0.5678, 0.5585, 13.2, listOf(0.556, 0.578, 0.574)),
            Band("C2", 0.30, 0.5323, 0.5362, 25.9, listOf(0.517, 0.543, 0.536)),
            Band("C3", 1.01, 0.5220, 0.5169, 58.3, listOf(0.512, 0.525, 0.530))),
        // weekend model C (top 8%..60%, 3 minutes): rotation 54.89%, 88.5/day
        WEEKEND to listOf(
            Band("C1", 0.15, 0.5924, 0.5679, 12.0, listOf(0.584, 0.613, 0.579)),
            Band("C2", 0.30, 0.5583, 0.5617, 25.1, listOf(0.529, 0.587, 0.558)),
            Band("C3", 1.01, 0.5342, 0.5241, 51.4, listOf(0.530, 0.542, 0.531))),
        // 1-minute C (70% fill minus the top 5% = B) of the v0.7.82 models (research_v0782/m1_prod_v0782_results.json): weekday rotation
        // 51.78% (yen crosses + crypto; no 2023-24 yen data, so no 2023-24 rate), weekend 52.44% (2023-24 51.54%)
        M1_WEEKDAY to listOf(
            Band("C1", 0.15, 0.5281, null, 82.6, listOf(0.527, 0.555, 0.520)),
            Band("C2", 0.40, 0.5155, null, 194.3, listOf(0.518, 0.534, 0.505)),
            Band("C3", 1.01, 0.5163, null, 265.1, listOf(0.511, 0.524, 0.504))),
        M1_WEEKEND to listOf(
            Band("C1", 0.15, 0.5460, 0.5464, 78.8, listOf(0.541, 0.568, 0.539)),
            Band("C2", 0.40, 0.5304, 0.5206, 194.2, listOf(0.529, 0.543, 0.521)),
            Band("C3", 1.01, 0.5137, 0.5054, 267.7, listOf(0.515, 0.522, 0.502)))
    )

    /**
     * Segments whose C1 may be promoted to B: weekday 5-minute C1 56.8% (B 57.6%), weekend C1 59.2% (B 61.2%). The 1-minute C1
     * (weekday 52.1%, weekend 54.5%) stays C: well below its B and every 1-minute C is entered anyway.
     */
    val PROMOTABLE: Set<String> = setOf(WEEKDAY, WEEKEND)

    val LABELS = listOf("C1", "C2", "C3")

    fun band(segment: String, label: String): Band? = BANDS[segment]?.firstOrNull { it.label == label }

    /** The band of a trade at [top] of its hour (the last band for anything below). */
    fun bandOf(segment: String, top: Double): Band? {
        val bands = BANDS[segment] ?: return null
        return bands.firstOrNull { top < it.maxTop } ?: bands.last()
    }

    /**
     * Share of the hour's slots at or above [p] on the ascending quantile grid [q] (q[k] = quantile k / (q.size - 1), linear between the
     * points - the inverse of the cut the ENTRY rule takes from the same grid): 1.0 at or below the lowest point, 0.0 at or above the top.
     */
    fun topShare(q: DoubleArray, p: Double): Double {
        if (q.isEmpty() || !p.isFinite()) return 1.0
        val n = q.size - 1
        if (p <= q[0]) return 1.0
        if (p >= q[n]) return 0.0
        var lo = 0; var hi = n
        while (hi - lo > 1) { val mid = (lo + hi) ushr 1; if (q[mid] <= p) lo = mid else hi = mid }
        val span = q[hi] - q[lo]
        val x = lo + if (span > 0.0) (p - q[lo]) / span else 0.0
        return (1.0 - x / n).coerceIn(0.0, 1.0)
    }

    /** The sub-grade of a C trade of [segment] at [top] with probability [p]; null when [grade] is not C. */
    fun of(segment: String, grade: String, top: Double, p: Double, fresh: Boolean): SubGrade? {
        if (grade != "C" || !top.isFinite() || !p.isFinite()) return null
        val b = bandOf(segment, top) ?: return null
        return SubGrade(b.label, segment, top, p, fresh)
    }

    /** [sub] promoted to B when [enabled], its segment is promotable, it is C1 of the live-price model. */
    fun promote(sub: SubGrade?, enabled: Boolean): SubGrade? =
        if (sub != null && enabled && sub.fresh && sub.label == "C1" && sub.segment in PROMOTABLE) sub.copy(promoted = true) else sub

    fun weekday(fresh: Boolean, hourJst: Int, p: Double): Double =
        topShare((if (fresh) EvidenceSlot9Data.FRESH_QUANTILES else EvidenceSlot9Data.FALLBACK_QUANTILES)[(hourJst - 9).coerceIn(0, 13)], p)

    fun weekend(fresh: Boolean, hourJst: Int, p: Double): Double =
        topShare((if (fresh) EvidenceSlotWData.FRESH_QUANTILES else EvidenceSlotWData.FALLBACK_QUANTILES)[(hourJst - 9).coerceIn(0, 13)], p)

    fun oneMinute(weekend: Boolean, hourJst: Int, p: Double): Double =
        EvidenceModelM2Data.table(weekend, hourJst)?.let { topShare(it, p) } ?: 1.0      // v0.7.82 tables

    private fun pc(x: Double) = String.format(Locale.US, "%.1f%%", x * 100.0)
    private fun topText(top: Double): String {
        val t = top * 100.0
        return if (t < 1.0) "上位1%以内" else "上位${String.format(Locale.US, "%.0f", kotlin.math.ceil(t - 1e-6))}%"
    }

    /** "C1・その時間の上位7%・勝つ確率54.2%・検証56.8%" */
    fun text(sub: SubGrade): String =
        "${if (sub.promoted) "B（C1から昇格）" else sub.label}・その時間の${topText(sub.top)}・勝つ確率${pc(sub.probability)}・" +
            (sub.rate?.let { "検証${pc(it)}" } ?: "予備モデル（検証なし）")

    /** The short chip of a history row: "C1 54.2%". */
    fun chip(sub: SubGrade): String = "${sub.shown} ${pc(sub.probability)}"

    /** Reimu's spell card of a sub-grade (display only). */
    fun spellCard(sub: SubGrade): String = if (sub.promoted) "夢境「二重大結界」（C1昇格）" else when (sub.label) {
        "C1" -> "夢境「二重大結界」"
        "C2" -> "夢符「封魔陣」"
        else -> "宝符「陰陽宝玉」"
    }
}

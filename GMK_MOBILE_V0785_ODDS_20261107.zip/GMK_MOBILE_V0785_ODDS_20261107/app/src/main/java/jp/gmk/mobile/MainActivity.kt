package jp.gmk.mobile

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import jp.gmk.mobile.data.ShrineSound
import jp.gmk.mobile.domain.HistoryRow
import jp.gmk.mobile.runtime.GmkRuntimeHolder

/*
 * v0.7.74: the screens live in their own files - PredictionScreen.kt (予測), MarketScreens.kt (チャート・通貨強弱), HistoryScreen.kt
 * (履歴), StatusScreen.kt (状態), CutInOverlay.kt, and the shared colours / pieces / formatters in GmkTheme.kt. This file keeps the
 * activity, the tab frame and the bottom bar.
 */
class MainActivity : ComponentActivity() {
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Foreground runtime still functions; UI power/runtime diagnostics remain visible if denied. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        enableEdgeToEdge()
        setContent {
            // v0.7.84: line height 1.4x of each text's own size (the default 24sp spread the 10-12sp texts far apart)
            val type = Typography().let { t -> t.copy(bodyLarge = t.bodyLarge.copy(lineHeight = 1.4.em), bodyMedium = t.bodyMedium.copy(lineHeight = 1.4.em)) }
            MaterialTheme(colorScheme = darkColorScheme(primary = Gmk.ShrineRed, secondary = Gmk.Cyan, background = Gmk.Night, surface = Gmk.Night), typography = type) {
                // v0.7.77: the keep-screen-on setting holds the screen on while the app is in front
                GmkApp(onKeepScreenOn = { on ->
                    if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        GmkRuntimeHolder.get(application).refreshDevicePowerState()
    }
}

enum class Tab { Prediction, Chart, Strength, History, Status }

@Composable
fun GmkApp(onKeepScreenOn: (Boolean) -> Unit = {}) {
    val app = LocalContext.current.applicationContext as android.app.Application
    val vm = remember(app) { GmkRuntimeHolder.get(app) }
    val state by vm.state.collectAsState()
    LaunchedEffect(state.keepScreenOn) { onKeepScreenOn(state.keepScreenOn) }
    var tabName by rememberSaveable { mutableStateOf(Tab.Prediction.name) }
    val tab = runCatching { Tab.valueOf(tabName) }.getOrDefault(Tab.Prediction)
    var selectedInstrument by rememberSaveable { mutableStateOf("EURJPY") }
    var chartTimeframe by rememberSaveable { mutableStateOf("1m") }
    var autoFollowScan by rememberSaveable { mutableStateOf(true) }
    var focusHistory by remember { mutableStateOf<HistoryRow?>(null) }
    // the chart follows each new scan's TOP1 while SCAN追従 is ON
    val newestTop = state.scan?.let { scan -> scan.top1?.let { scan.atJst to it.instrument } }
    LaunchedEffect(newestTop?.first, autoFollowScan) {
        if (autoFollowScan) newestTop?.second?.takeIf { it in chartInstruments }?.let {
            selectedInstrument = it
            focusHistory = null
        }
    }
    val context = LocalContext.current
    val diagnosticLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        // v0.7.79: built and written in the background (on the main thread it froze the screen for seconds)
        if (uri != null) vm.saveDiagnostic(uri) { ok ->
            Toast.makeText(context, if (ok) "診断ログを保存しました" else "診断ログの保存に失敗しました", Toast.LENGTH_SHORT).show()
        }
    }
    Scaffold(
        containerColor = Gmk.Night,
        bottomBar = {
            BottomBar(tab) {
                tabName = it.name
                if (it == Tab.History) vm.loadHistory()
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.Prediction -> ScanScreen(state, vm::manualScan, vm::setAuto, vm::setOneMinuteAuto, vm::manualOneMinuteScan)
                Tab.Chart -> ChartScreen(
                    state = state,
                    instrument = selectedInstrument,
                    timeframe = chartTimeframe,
                    focusHistory = focusHistory,
                    autoFollowScan = autoFollowScan,
                    onToggleAutoFollow = { autoFollowScan = !autoFollowScan },
                    onInstrument = { selectedInstrument = it; focusHistory = null; autoFollowScan = false },
                    onTimeframe = { chartTimeframe = it },
                    onRefresh = vm::loadChart
                )
                Tab.Strength -> CurrencyStrengthScreen(
                    state = state,
                    onRefresh = vm::loadStrength,
                    onSelectPair = { selectedInstrument = it; focusHistory = null; autoFollowScan = false; tabName = Tab.Chart.name }
                )
                Tab.History -> HistoryScreen(state.history) { row ->
                    selectedInstrument = row.instrument.takeIf { it in chartInstruments } ?: selectedInstrument
                    focusHistory = row
                    chartTimeframe = "1m"
                    autoFollowScan = false
                    tabName = Tab.Chart.name
                }
                Tab.Status -> StatusScreen(
                    state = state,
                    setCutInEnabled = vm::setCutInEnabled,
                    exportDiagnostic = { diagnosticLauncher.launch("GMK_DIAGNOSTICS_${System.currentTimeMillis()}.json") },
                    setSignalNotify = vm::setSignalNotify,
                    setNotifyMinGrade = vm::setNotifyMinGrade,
                    setEntryMode = vm::setEntryMode,
                    setPromoteC1 = vm::setPromoteC1,
                    setSoundOn = vm::setSoundOn,
                    setKeepScreenOn = vm::setKeepScreenOn
                )
            }
            Box(Modifier.align(Alignment.TopCenter)) { SpellDeclaration(state) { if (state.soundOn && ShrineSound.audible(context)) ShrineSound.play(ShrineSound.Kind.ENTRY) } }
            // v0.7.78: WIN / LOSE sounds from the history itself (they came only with a cut-in, so never with カットイン OFF)
            ShrineSoundEffects(state)
            CutInOverlay(
                state = state,
                controller = vm.cutInEvents,
                onShown = vm::recordCutInShown,
                onSuppressed = vm::recordCutInSuppressed
            )
        }
    }
}

/**
 * v0.7.78: the WIN chime / ピチューン when a waiting ENTRY (every 5-minute trade, 1-minute B only - the ones with a cut-in) gets its
 * result, with 効果音 ON and the phone not in マナーモード; independent of the cut-in setting.
 */
@Composable
private fun ShrineSoundEffects(state: jp.gmk.mobile.ui.GmkUiState) {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<Set<String>?>(null) }
    LaunchedEffect(state.history) {
        val before = pending
        if (before != null && state.soundOn && ShrineSound.audible(context)) {
            jp.gmk.mobile.domain.SoundCues.settled(before, state.history)?.let { r ->
                ShrineSound.play(if (r.resultStatus == "WIN") ShrineSound.Kind.WIN else ShrineSound.Kind.LOSE)
            }
        }
        pending = jp.gmk.mobile.domain.SoundCues.pendingOf(state.history)
    }
}

/** Shrine-style tab bar: the active tab gets the shrine maiden's red with a talisman-white underline. */
@Composable
private fun BottomBar(tab: Tab, select: (Tab) -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A1022), Color(0xFF2A0E22), Color(0xFF0A1022))))
            .windowInsetsPadding(WindowInsets.navigationBars).height(64.dp)
            .border(1.dp, Gmk.ShrineRed.copy(alpha = .45f))
    ) {
        BottomItem("☯", "神託", tab == Tab.Prediction) { select(Tab.Prediction) }
        BottomItem("⌁", "チャート", tab == Tab.Chart) { select(Tab.Chart) }
        BottomItem("◉", "勢力図", tab == Tab.Strength) { select(Tab.Strength) }
        BottomItem("▤", "リプレイ", tab == Tab.History) { select(Tab.History) }
        BottomItem("⛩", "帳簿", tab == Tab.Status) { select(Tab.Status) }
    }
}

@Composable
private fun RowScope.BottomItem(icon: String, text: String, active: Boolean, click: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable(onClick = click)
            .background(if (active) Brush.verticalGradient(listOf(Color(0x664F173E), Color(0xCCB0203F))) else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = if (active) Gmk.Paper else Gmk.Muted, fontSize = 21.sp)
        Text(text, color = if (active) Gmk.Paper else Gmk.Muted, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, fontSize = 11.sp, maxLines = 1)
        if (active) Box(Modifier.padding(top = 3.dp).height(3.dp).width(34.dp).background(Gmk.Paper, RoundedCornerShape(2.dp)))
    }
}

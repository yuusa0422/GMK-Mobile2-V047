package jp.gmk.mobile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.74: one place for the colours, shared pieces and formatters of every screen (before: each screen file had its own copies).
 * Theme: Hakurei shrine at night - the shrine maiden's red and white (紅白), talisman (お札) titles, night-sky panels.
 */
internal object Gmk {
    val Night = Color(0xFF07142A)
    val NightDeep = Color(0xFF040B19)
    val Panel = Color(0xE6122140)
    val PanelWarm = Color(0xE6221330)
    val Line = Color(0x667B68D7)
    /** 紅白: the shrine maiden's red and the talisman paper. */
    val ShrineRed = Color(0xFFE0284A)
    val ShrineRedDark = Color(0xFF7A1028)
    val Paper = Color(0xFFFFF4E4)
    val Gold = Color(0xFFFFC76A)
    val Pink = Color(0xFFFF4F91)
    val Cyan = Color(0xFF35D9FF)
    val Purple = Color(0xFF9E6CFF)
    val Text = Color(0xFFF6F2FF)
    /** Secondary text: brighter than before (0xFF9FB4D9) so small lines stay readable on the night panels. */
    val Muted = Color(0xFFC6D2EA)        // v0.7.84: brighter (was B4C3E0) for the small explanation texts on the night panels
    val Faint = Color(0xFFA2B2D0)        // v0.7.84: brighter (was 8396B8; too dark to read on the panels)
    val Win = Color(0xFF53E6A4)
    val Lose = Color(0xFFFF5A73)
    val Warn = Color(0xFFFFB84F)
    val High = Color(0xFFFF4F91)
    val Low = Color(0xFF3D9BFF)
    /** theoption expiry colours: 3分 orange, 5分 teal (the text always says it too). */
    val Three = Color(0xFFFF8A3D)
    val Five = Color(0xFF14B8A6)
    val Jst: ZoneId = ZoneId.of("Asia/Tokyo")
}

/** A night panel with a thin border; [accent] colours the border. */
@Composable
internal fun ShrinePanel(modifier: Modifier = Modifier, accent: Color = Gmk.Line, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth()
            .border(1.dp, accent, RoundedCornerShape(12.dp))
            .background(Gmk.Panel, RoundedCornerShape(12.dp))
            .padding(12.dp),
        content = content
    )
}

/** Section title as a talisman (お札): red tab on the left, paper-white text. */
@Composable
internal fun OfudaTitle(text: String, sub: String? = null, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF3A1230), Color(0xFF142F57))), RoundedCornerShape(8.dp)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(6.dp).height(34.dp).background(Gmk.ShrineRed, RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)))
        Spacer(Modifier.width(10.dp))
        Text("⛩", fontSize = 13.sp, color = Gmk.Paper)
        Spacer(Modifier.width(6.dp))
        Text(text, color = Gmk.Paper, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (sub != null) Text(sub, color = Gmk.Muted, fontSize = 11.sp, modifier = Modifier.padding(end = 10.dp))
    }
}

/** A tappable choice (pair, timeframe, filter); at least 36 dp tall so it is easy to hit. */
@Composable
internal fun ChoiceChip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Text(
        text,
        Modifier.heightIn(min = 36.dp)
            .border(1.dp, if (selected) accent else Color(0x556B7CA5), RoundedCornerShape(18.dp))
            .background(if (selected) accent.copy(alpha = .22f) else Color(0x66101C36), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 9.dp),
        color = if (selected) Gmk.Text else Gmk.Muted,
        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        fontSize = 12.sp
    )
}

/** v0.7.57: judgement length badge - theoption's expiry must match it (3分 orange, 5分 teal; the text says it too). */
@Composable
internal fun JudgeBadge(minutes: Int, large: Boolean = false) {
    val color = when (minutes) { 5 -> Gmk.Five; 3 -> Gmk.Three; else -> Color(0xFF8E8E9E) }
    Surface(color = color, shape = RoundedCornerShape(8.dp)) {
        Text("${minutes}分判定", Modifier.padding(horizontal = if (large) 12.dp else 7.dp, vertical = if (large) 7.dp else 3.dp),
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (large) 17.sp else 11.sp, maxLines = 1, softWrap = false)
    }
}

/** ▲ HIGH (pink) / ▼ LOW (blue). */
@Composable
internal fun DirectionBox(direction: String, large: Boolean = false) {
    val (label, color) = when (direction.uppercase()) {
        "HIGH" -> "▲ HIGH" to Gmk.High
        "LOW" -> "▼ LOW" to Gmk.Low
        else -> "—" to Color.Gray
    }
    Surface(color = color.copy(alpha = .92f), shape = RoundedCornerShape(8.dp)) {
        Text(label, Modifier.padding(horizontal = if (large) 14.dp else 10.dp, vertical = if (large) 8.dp else 6.dp), color = Color.White,
            fontWeight = FontWeight.Bold, fontSize = if (large) 19.sp else 14.sp, maxLines = 1, softWrap = false)
    }
}

/** A label / value line of the status screen. */
@Composable
internal fun StatusLine(label: String, value: String, valueColor: Color = Gmk.Text) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(118.dp), color = Gmk.Muted, fontSize = 11.sp)
        Text(value, Modifier.weight(1f), color = valueColor, fontSize = 11.sp)
    }
}

internal fun parseJstMs(value: String): Long? = jp.gmk.mobile.domain.FastTime.epochMs(value)

/** "HH:mm:ss" in JST of an ISO time, "—" when blank or unreadable. */
internal fun formatJstTime(iso: String): String {
    if (iso.isBlank()) return "—"
    return runCatching {
        ZonedDateTime.parse(iso).withZoneSameInstant(Gmk.Jst).format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
    }.getOrElse { "—" }
}

/** "HH:mm:ss" in JST of epoch milliseconds. */
internal fun formatClock(value: Long): String =
    runCatching { ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(value), Gmk.Jst).toLocalTime().toString().take(8) }.getOrDefault("—")

/**
 * v0.7.84: a long explanation folded under one tappable line ("▼ title"), so the screens show the numbers first; tap to read it.
 */
@Composable
internal fun FoldNote(text: String, title: String = "説明", color: Color = Gmk.Muted) {
    var open by rememberSaveable(text) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(top = 2.dp)) {
        Text((if (open) "▲ " else "▼ ") + title, color = Gmk.Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 5.dp))
        if (open) Text(text, color = color, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

/** Prices: crypto in yen without decimals, other prices of 100 or more with 3 decimals, below 100 with 5 (BTC/USD 2). */
internal fun formatPrice(x: Double): String = when {
    x >= 100_000 -> "%,.0f".format(x)
    x >= 1_000 -> "%,.2f".format(x)
    x >= 10 -> "%.3f".format(x)          // v0.7.83: AUD/JPY and NZD/JPY (below 100) had 5 decimals; Yahoo quotes the yen crosses to 3
    else -> "%.5f".format(x)
}

/** Expiry minutes of a row (1/3/5/10/15), else [fallback]. */
internal fun expiryMinutes(entry: String, judge: String, fallback: Int): Int = runCatching {
    java.time.Duration.between(jp.gmk.mobile.domain.FastTime.instant(entry)!!, jp.gmk.mobile.domain.FastTime.instant(judge)!!).toMinutes().toInt().takeIf { it in setOf(1, 3, 5, 10, 15) } ?: fallback
}.getOrDefault(fallback)

/** "ETH/USD" for the crypto pairs, the instrument itself for the yen crosses. */
internal fun pairLabel(instrument: String): String = jp.gmk.mobile.domain.CryptoPairs.display(instrument)

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.util.zip.GZIPInputStream

/**
 * v0.7.82 1-minute models (research_v0782/m1_prod_v0782.py): the weekday model over the five yen crosses and the four crypto pairs, the
 * weekend model over the crypto pairs, both with the ext inputs of CandleModelM2. The exported texts give the research probabilities and
 * real minutes (raw 1-minute bars) give the research choice through the app's own input computation.
 */
class OneMinuteFxV0782Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun num(s: String) = if (s == "nan") Double.NaN else s.toDouble()       // Python writes NaN as "nan"
    private fun lines(name: String) = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream(name)!!).bufferedReader().readLines().filter { it.isNotBlank() }

    @Test fun exportedModelsGiveTheResearchProbabilities() {
        assertEquals(EvidenceModelM2Data.FEATURES_WEEKDAY, CandleModelM2.featureCount(false))
        assertEquals(EvidenceModelM2Data.FEATURES_WEEKEND, CandleModelM2.featureCount(true))
        val n = HashMap<String, Int>()
        for (l in lines("v0782_m2_parity.txt.gz")) {
            val (m, p, x) = l.split('|')
            val v = x.split(',').map(::num).toDoubleArray()
            val weekend = m == "E"
            assertEquals(CandleModelM2.featureCount(weekend), v.size)
            assertEquals(p.toDouble(), OneMinutePolicy.ensemble(weekend).probability(v), 1e-12); n[m] = (n[m] ?: 0) + 1
        }
        assertEquals(mapOf("W" to 300, "E" to 300), n)
    }

    private class Slot(val model: String, val b: Long, val inst: String, val dir: String, val p: Double) { val bars = HashMap<String, ArrayList<Candle>>() }
    private fun slots(): List<Slot> {
        val out = ArrayList<Slot>(); var cur: Slot? = null
        for (l in lines("v0782_m2_slots.txt.gz")) {
            val q = l.split('|')
            when (q[0]) {
                "S" -> { cur = Slot(q[1], q[2].toLong(), q[3], q[4], q[5].toDouble()); out.add(cur) }
                "C" -> cur!!.bars.getOrPut(q[1]) { ArrayList() }.add(Candle(q[2].toLong() * 1000L, num(q[3]), num(q[4]), num(q[5]), num(q[6]), num(q[7])))
            }
        }
        return out
    }

    @Test fun realMinutesGiveTheResearchChoice() {
        val all = slots()
        assertEquals(12, all.count { it.model == "W" }); assertEquals(8, all.count { it.model == "E" })
        var fxChosen = 0
        for (s in all) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst)
            assertEquals(s.model == "E", entry.dayOfWeek.value >= 6)
            // the live price at entry = the close of the minute opening at entry-60 s (the forming minute of the app)
            val live = s.bars.mapValues { (_, c) -> c.first { it.timeEpochMs == s.b * 1000L - 60_000L }.close }
            val usd = s.bars.filterKeys { it == "BTCUSD" || it == "ETHUSD" }; val fx = s.bars.filterKeys { it in CandleModelM2.FX }
            val sc = OneMinutePolicy.scores(usd, live.filterKeys { it in usd }, entry, fx, live.filterKeys { it in fx })
            val c = OneMinutePolicy.choose(sc)!!
            assertEquals("${s.b}", s.inst, c.instrument); assertEquals("${s.b}", s.dir, c.direction); assertEquals("${s.b}", s.p, c.probability, 1e-9)
            assertEquals(if (s.model == "W") 9 else 4, sc.size)
            if (c.instrument in CandleModelM2.FX) fxChosen++
            if (s.model == "W") {
                // a yen cross missing a finished minute: every yen pair is left out (each one's cross input needs the other four), crypto stays
                val gap = fx.mapValues { (k, cs) -> if (k == "EURJPY") cs.filter { it.timeEpochMs != s.b * 1000L - 600_000L } else cs }
                assertEquals(CandleModelM2.CRYPTO, OneMinutePolicy.scores(usd, live.filterKeys { it in usd }, entry, gap, live.filterKeys { it in fx }).map { it.instrument })
            } else {
                // weekends: the yen crosses are never scored
                assertEquals(CandleModelM2.CRYPTO, OneMinutePolicy.scores(usd, live, entry, fx, live).map { it.instrument })
            }
        }
        assertTrue("yen crosses chosen in some weekday slots: $fxChosen", fxChosen >= 0)
    }

    @Test fun pairsAndLabels() {
        assertEquals(listOf("BTCJPY", "ETHJPY", "BTCUSD", "ETHUSD", "USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY"), CandleModelM2.pairs(false))
        assertEquals(CandleModelM2.CRYPTO, CandleModelM2.pairs(true))
        assertEquals("USD/JPY", OneMinutePolicy.display("USDJPY")); assertEquals("BTC/JPY", OneMinutePolicy.display("BTCJPY"))
        assertTrue(EvidenceModelM2Data.NOTE.startsWith("1年の検証（毎時70%）"))
    }
}

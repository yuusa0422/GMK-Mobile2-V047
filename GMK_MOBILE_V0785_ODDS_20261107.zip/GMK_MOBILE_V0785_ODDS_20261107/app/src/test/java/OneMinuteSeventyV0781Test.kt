import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZonedDateTime

/** v0.7.81: the 1-minute judgment keeps every hour at least 70% ENTRY (the user's instruction; 80% up to v0.7.80). */
class OneMinuteSeventyV0781Test {
    @Test fun seventyPercentOfTheMinutesTheAppRuns() {
        assertEquals(0.7, OneMinutePolicy.SHARE, 0.0); assertEquals(42, OneMinutePolicy.NEEDED); assertEquals(70, OneMinutePolicy.PERCENT)
        val h = ZonedDateTime.parse("2026-11-06T10:00:00+09:00")
        assertEquals(42, OneMinutePolicy.neededInHour(h, 0))
        assertEquals(14, OneMinutePolicy.neededInHour(h.plusMinutes(40), 0, seenBefore = 0))           // started at :40: 70% of 20
        // the weakest hour still enters 42 of 60, the forced ones at the end
        var e = 0; var forcedFrom = -1
        for (m in 0 until 60) {
            val (_, d) = OneMinutePolicy.decide(h.plusMinutes(m.toLong()), 0.0, e)
            if (d == "ENTRY") { if (forcedFrom < 0) forcedFrom = m; e++ }
        }
        assertEquals(42, e); assertEquals(18, forcedFrom)
        val c = OneMinutePolicy.Choice("BTCUSD", "HIGH", 0.6, listOf(EvidencePolicy.PairScore("BTCUSD", 0.6, 0.4)))
        assertTrue(OneMinutePolicy.reason(c, "B", "ENTRY", 3, h.plusMinutes(5)).contains("（70%以上に保つ）"))
        // v0.7.82: the rates of the v0.7.82 models at 70%
        assertTrue(EvidenceModelM2Data.NOTE.startsWith("1年の検証（毎時70%）"))
        assertEquals(0.5178, EvidenceModelM2Data.gradeRates(false).getValue("C"), 0.0)
        assertEquals(0.5281, SubGrades.band(SubGrades.M1_WEEKDAY, "C1")!!.rate, 0.0)
    }
}

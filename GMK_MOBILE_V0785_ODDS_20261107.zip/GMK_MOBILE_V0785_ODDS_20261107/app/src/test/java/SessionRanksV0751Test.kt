import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.51 session ranks: time-of-day rules (parity with scripts/ranks_v0751.py), London clock, October calendar, state.
 * v0.7.53: four more rules come after these at the same minutes, so a v0.7.51 no-trade slot may now trade a v0.7.53 rule. */
class SessionRanksV0751Test {
    @Before fun reset() = EvidencePolicy.resetState()
    private val jst = ZoneId.of("Asia/Tokyo")

    private class Slot(val boundary: Long) {
        val bars = linkedMapOf<String, MutableList<Candle>>()
        val live = linkedMapOf<String, Double>()
        val expected = linkedMapOf<String, DoubleArray>()
        var match: List<String>? = null
    }
    private val slots: List<Slot> by lazy {
        val out = mutableListOf<Slot>(); var cur: Slot? = null
        GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0751_event_parity.txt.gz")!!).bufferedReader().useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val p = line.split('|')
                when (p[0]) {
                    "SLOT" -> cur = Slot(p[1].toLong())
                    "BAR" -> cur!!.bars.getOrPut(p[1]) { mutableListOf() } += Candle(p[2].toLong(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble(), p[7].toDouble())
                    "LIVE" -> cur!!.live[p[1]] = p[2].toDouble()
                    "EXPV" -> cur!!.expected[p[1]] = doubleArrayOf(p[2].toDouble(), p[3].toDouble(), p[4].toDouble())
                    "EXPM" -> cur!!.match = p.drop(1)
                    "END" -> { out += cur!!; cur = null }
                    else -> error("fixture line ${p[0]}")
                }
            }
        }
        out
    }
    private val V0751_IDS = setOf("FIX955_POS", "JST1220_POS", "JST2250_R15", "LON0725_R5")
    private fun entry(b: Long) = ZonedDateTime.ofInstant(Instant.ofEpochSecond(b), jst)

    @Test fun ruleTradesMatchPythonOnRealSlots() {
        var matched = 0; var none = 0
        assertTrue(slots.size >= 30)
        for (s in slots) {
            val e = entry(s.boundary)
            for ((inst, want) in s.expected) {
                val w = EvidenceFeatures.window(s.bars.getValue(inst), s.boundary)!!
                val x = EvidenceFeatures.instrument(inst, s.bars.getValue(inst), s.boundary, s.live.getValue(inst))!!
                assertEquals("pos60L $inst ${s.boundary}", want[0], EventRules.pos60L(w, s.live.getValue(inst)), 1e-9)
                assertEquals("r5 $inst", want[1], x.r5, 1e-9)
                assertEquals("r15 $inst", want[2], x.r15, 1e-9)
            }
            val got = EventRules.match(e, s.bars, s.live.mapValues { it.value as Double? }, EventRules.ALL_IDS)
            val m = s.match!!
            if (m[0] == "NONE") { none++; assertTrue("slot ${s.boundary} $e", got == null || got.rule.id !in V0751_IDS) }
            else {
                matched++
                assertNotNull("slot ${s.boundary} $e", got)
                assertEquals(m[0], got!!.rule.id); assertEquals(m[1], got.instrument); assertEquals(m[2], got.direction)
                assertEquals(m[3].toDouble(), got.value, 1e-9)
            }
        }
        assertTrue("matched=$matched none=$none", matched >= 25 && none >= 8)
    }

    @Test fun londonRuleFollowsTheOctoberClockChange() {
        fun at(d: Int, h: Int, m: Int, s: Int = 0) = ZonedDateTime.of(2026, 10, d, h, m, s, 0, jst)
        assertEquals(listOf("LON0725_R5"), EventRules.rulesAt(at(23, 15, 25), EventRules.ALL_IDS).map { it.id })      // Fri, BST: 07:25 London = 15:25 JST
        assertTrue(EventRules.rulesAt(at(23, 16, 25), EventRules.ALL_IDS).isEmpty())
        assertTrue(EventRules.rulesAt(at(26, 15, 25), EventRules.ALL_IDS).isEmpty())                                // Mon after 25 Oct: GMT
        assertEquals(listOf("LON0725_R5"), EventRules.rulesAt(at(26, 16, 25), EventRules.ALL_IDS).map { it.id })
        assertEquals(listOf("FIX955_POS", "FIX955_BBZ"), EventRules.rulesAt(at(26, 9, 55), EventRules.ALL_IDS).map { it.id })
        assertEquals(listOf("JST1220_POS"), EventRules.rulesAt(at(27, 12, 20), EventRules.ALL_IDS).map { it.id })
        assertEquals(listOf("JST2250_R15"), EventRules.rulesAt(at(28, 22, 50), EventRules.ALL_IDS).map { it.id })
        assertTrue(EventRules.rulesAt(at(24, 9, 55), EventRules.ALL_IDS).isEmpty())                                 // Saturday: BTC only
        assertTrue(EventRules.rulesAt(at(26, 9, 55, 7), EventRules.ALL_IDS).isEmpty())                              // manual +10 s entry
        assertTrue(EventRules.rulesAt(at(26, 9, 50), EventRules.ALL_IDS).isEmpty())
    }

    private fun flatWindow(b: Long, base: Double, last: Double): List<Candle> = (0 until 61).map { i ->
        val t = (b - 3720L + i * 60L) * 1000L
        val c = if (i == 60) last else base + (if (i % 2 == 0) 0.01 else -0.01)
        Candle(t, c, maxOf(c, base) + 0.005, minOf(c, base) - 0.005, c, 0.0)
    }

    @Test fun fixRuleTakesUsdjpyFirstOtherRulesTakeTheLargestMove() {
        val b = ZonedDateTime.of(2026, 10, 26, 9, 55, 0, 0, jst).toEpochSecond()
        val bars = mapOf("USDJPY" to flatWindow(b, 150.0, 150.0), "EURJPY" to flatWindow(b, 170.0, 170.0), "GBPJPY" to flatWindow(b, 200.0, 200.0),
            "AUDJPY" to flatWindow(b, 100.0, 100.0), "NZDJPY" to flatWindow(b, 90.0, 90.0))
        // live above every 61-minute high: pos60L = +1 for all -> fade = LOW; USDJPY wins the tie at 9:55
        val up = mapOf("USDJPY" to 150.5, "EURJPY" to 170.5, "GBPJPY" to 200.5, "AUDJPY" to 100.5, "NZDJPY" to 90.5).mapValues { it.value as Double? }
        val fix = EventRules.match(entry(b), bars, up, EventRules.ALL_IDS)!!
        assertEquals("FIX955_POS", fix.rule.id); assertEquals("USDJPY", fix.instrument); assertEquals("LOW", fix.direction); assertEquals(1.0, fix.value, 0.0)
        // v0.7.53: the far live price also puts bbzL and f1 past their thresholds (2 of 4 other signals) -> A, not S
        assertEquals(2, fix.confluence); assertEquals("A", fix.grade)
        // without a USDJPY quote the tie goes to the fixed order (EURJPY)
        assertEquals("EURJPY", EventRules.match(entry(b), bars, up + ("USDJPY" to null), EventRules.ALL_IDS)!!.instrument)
        // inside the range: no trade
        val mid = up.mapValues { (k, _) -> bars.getValue(k)[30].close }
        assertNull(EventRules.match(entry(b), bars, mid, EventRules.ALL_IDS))
        // 12:20: same tie -> fixed order, no USDJPY preference needed (USDJPY is also first in the order)
        val b2 = ZonedDateTime.of(2026, 10, 26, 12, 20, 0, 0, jst).toEpochSecond()
        val bars2 = bars.mapValues { (k, v) -> flatWindow(b2, v[0].open, v[0].open) }
        val low = mapOf("USDJPY" to 149.9, "EURJPY" to 169.0, "GBPJPY" to 199.99, "AUDJPY" to 99.99, "NZDJPY" to 89.99).mapValues { it.value as Double? }
        val lunch = EventRules.match(entry(b2), bars2, low, EventRules.ALL_IDS)!!
        assertEquals("JST1220_POS", lunch.rule.id); assertEquals("HIGH", lunch.direction); assertEquals(-1.0, lunch.value, 0.0)
        assertEquals(2, lunch.confluence); assertEquals("A", lunch.grade)
    }

    @Test fun octoberCalendarWindows() {
        fun at(d: Int, h: Int, m: Int) = ZonedDateTime.of(2026, 10, d, h, m, 0, 0, jst)
        assertNull(MarketCalendar.caution(at(29, 22, 5)))
        assertNotNull(MarketCalendar.caution(at(29, 22, 10))); assertNotNull(MarketCalendar.caution(at(29, 22, 55)))
        assertNull(MarketCalendar.caution(at(30, 11, 25))); assertNotNull(MarketCalendar.caution(at(30, 12, 20)))
        assertNull(MarketCalendar.caution(at(30, 13, 30))); assertNotNull(MarketCalendar.caution(at(30, 15, 30)))
        assertNull(MarketCalendar.caution(at(28, 12, 20)))
        // as an entry at 13:00 JST on 30 Oct in UTC form is the same instant
        assertNotNull(MarketCalendar.caution(at(30, 13, 0).withZoneSameInstant(ZoneId.of("UTC"))))
    }

    @Test fun rankTableOrderAndModelGradeMapping() {
        val wd = listOf("S", "A", "B", "C", "D").map { EvidencePolicy.gradeRate(true, false, it)!! }   // v0.7.56: the former C is C (top part) / D
        assertTrue(wd.zipWithNext().all { (a, b) -> a > b })
        // v0.7.54: weekend C is skipped (D); the weekend ENTRY tier is B only
        val we = listOf("B", "C", "D", "E", "F", "G", "H").map { EvidencePolicy.gradeRate(true, true, it)!! }   // v0.7.56: weekend C = top 60% tier
        assertTrue(we.zipWithNext().all { (a, b) -> a > b })
        assertNull(EvidencePolicy.gradeRate(true, true, "S")); assertNull(EvidencePolicy.gradeRate(true, true, "A")); assertEquals(0.5489, EvidencePolicy.gradeRate(true, true, "C")!!, 0.0)   // v0.7.71 weekend model
        // v0.7.52: weekday S/A are B only when the last-minute move confirms the trade
        // v0.7.55: unconfirmed weekday trades are skipped (D), the weekend S tier enters only against the hour
        assertEquals("D", RankLadder.modelGrade("S", false)); assertEquals("D", RankLadder.modelGrade("A", false))
        assertEquals("B", RankLadder.modelGrade("S", false, true)); assertEquals("B", RankLadder.modelGrade("A", false, true))
        assertEquals("D", RankLadder.modelGrade("B", false, true)); assertEquals("D", RankLadder.modelGrade("A", true, true))
        assertEquals("D", RankLadder.modelGrade("B", false)); assertEquals("D", RankLadder.modelGrade("C", false))
        assertEquals("B", RankLadder.modelGrade("S", true, againstHour = true)); assertEquals("D", RankLadder.modelGrade("A", true)); assertEquals("D", RankLadder.modelGrade("B", true))
        assertEquals("E", RankLadder.modelGrade("D", false)); assertEquals("F", RankLadder.modelGrade("E", false))
        for (g in listOf("F", "G", "H")) { assertEquals(g, RankLadder.modelGrade(g, false)); assertEquals(g, RankLadder.modelGrade(g, true)) }
        // v0.7.53: rule trades are S (confluence) or A; every rule's own rate lies between the A and S rates' neighbourhood
        for (r in EventRules.RULES) assertTrue(r.id, r.rate > RankLadder.rate(true, false, "B")!!.year && r.rate < RankLadder.rate(true, false, "S")!!.year)
    }

    @Test fun rollingStateSurvivesARestart() {
        // 150 consecutive weekday AUTO slots (past the 96-slot seed) plus a few backup-model slots
        val rnd = kotlin.random.Random(4)
        val t0 = ZonedDateTime.of(2026, 10, 19, 9, 0, 0, 0, jst).toEpochSecond()
        for (i in 0 until 150) {
            val adj = rnd.nextDouble(-0.05, 0.05)
            EvidencePolicy.decide(EvidencePolicy.Choice("EURJPY", "LOW", 0.5 + adj, adj, i % 10 != 0), false, t0 + i * 300L, record = true)
        }
        val n = EvidencePolicy.bufferSize(true, false) + EvidencePolicy.bufferSize(false, false)
        assertEquals(150, n)
        val text = EvidencePolicy.exportState()
        val last = object { val boundary = t0 + 150 * 300L }
        val before = EvidencePolicy.decide(EvidencePolicy.Choice("USDJPY", "HIGH", 0.52, 0.01, true), false, last.boundary, record = false)
        EvidencePolicy.resetState(); assertEquals(0, EvidencePolicy.bufferSize(true, false))
        val now = last.boundary
        assertEquals(n, EvidencePolicy.importState(text, now))
        assertEquals(135, EvidencePolicy.bufferSize(true, false))
        val after = EvidencePolicy.decide(EvidencePolicy.Choice("USDJPY", "HIGH", 0.52, 0.01, true), false, last.boundary, record = false)
        assertFalse(after.fromSeed)
        assertEquals(before.pct, after.pct, 0.0); assertEquals(before.strength, after.strength, 0.0); assertEquals(before.grade, after.grade)
        assertEquals(text, EvidencePolicy.exportState())
        // a second import never overwrites live state; malformed or very old text is ignored
        assertEquals(0, EvidencePolicy.importState(text, now))
        EvidencePolicy.resetState()
        assertEquals(0, EvidencePolicy.importState(text.replace(",", ";;"), now)); assertEquals(0, EvidencePolicy.bufferSize(true, false))
        assertEquals(0, EvidencePolicy.importState("GMK_EVIDENCE_STATE_V1\nbogus\t1,2,3", now))
        assertEquals(0, EvidencePolicy.importState(text, now + EvidencePolicy.MAX_STATE_AGE_SEC + 3600 * 24))
        assertEquals(0, EvidencePolicy.importState(null, now))
    }

    @Test fun rollingStateFromRealSlotsKeepsRecentEntries() {
        val slots = EvidenceFixture.slots.filter { !it.weekend }
        for (s in slots.take(10)) EvidencePolicy.apply(s.native("AUTO"), s.native("AUTO"), s.candles(), s.quotes())
        val n = EvidencePolicy.bufferSize(true, false)
        assertTrue(n >= 10)
        val text = EvidencePolicy.exportState()
        EvidencePolicy.resetState()
        val now = slots.take(10).maxOf { it.boundary } + 300
        val recent = slots.take(10).count { now - it.boundary <= EvidencePolicy.MAX_STATE_AGE_SEC }
        assertEquals(recent, EvidencePolicy.importState(text, now))
        assertEquals(recent, EvidencePolicy.bufferSize(true, false))
    }

    @Test fun finalRanksOnRealSlotsFollowTheNewLadder() {
        for (s in EvidenceFixture.slots) {
            EvidencePolicy.resetState()
            val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes())
            val top = out.top1!!
            val note = top.reasons[1]
            val label = top.assessment!!.correctionLabel!!.removePrefix("【3分判定】").removePrefix("【5分判定】")
            assertEquals(EvidencePolicy.POLICY_TAG, out.policyVersion)
            val v48 = Regex(" v0748=([A-Z])").find(note)!!.groupValues[1]
            val hour = ZonedDateTime.parse(s.native().entryTimeJst).withZoneSameInstant(jst).hour
            val e = Regex(" e=([0-9.]+)").find(note)!!.groupValues[1].toDouble(); val r = Regex(" r=([0-9.]+)").find(note)!!.groupValues[1].toDouble()
            // v0.7.56: the note rounds e/r to 4 digits; the grade must match on one side of that rounding
            val wants = listOf(-5e-5, 5e-5).map { d -> RankLadder.modelGrade(v48, s.weekend, " CONFIRMED" in note, hour, " AGAINST_HOUR" in note, r + d, e + d, " fresh" in note) }.toSet()
            val want = if (top.grade in wants) top.grade else wants.first()
            when {
                " RULE=" in note -> { assertTrue(top.grade in setOf("S", "A")); assertEquals("ENTRY", top.decision); assertTrue(label.startsWith("時間帯ルール ")) }
                // v0.7.57 weekday: B keeps the ladder; every other weekday trade is the 5-minute model's C (ENTRY in 60%) or D
                !s.weekend && top.grade != "B" && " CAUTION" !in note -> { assertTrue(top.grade == "C" || top.grade in SkipGrades.GRADES); assertTrue(label, label.startsWith("5分モデル ") || label.startsWith("見送り ")) }
                top.decision == "ENTRY" -> { assertEquals(want, top.grade); assertTrue(top.grade in setOf("B", "C")); assertTrue(label.startsWith("検証モデル ")) }
                else -> { assertEquals(want, top.grade); assertTrue(top.grade in setOf("C", "D", "E", "F", "G", "H")); assertTrue(label.startsWith("見送り ")) }
            }
            assertFalse("no pattern grades any more", " WIN#" in note || " REV#" in note)
            assertEquals(top.grade, top.assessment!!.chosenAction.operationalGrade)
        }
    }

    @Test fun eventRuleReplacesTheModelTradeOnARealFixSlot() {
        // take a real rule slot from the event fixture, wrap it as the app's native scan (six instruments) and run the policy
        val s = slots.first { it.match!![0] == "FIX955_POS" }
        val b = s.boundary; val e = entry(b)
        val btc = EvidenceFixture.slots.first { !it.weekend }
        val shift = (b - btc.boundary) * 1000L
        val bars = LinkedHashMap<String, List<Candle>>(s.bars)
        bars["BTCJPY"] = btc.bars.getValue("BTCJPY").map { it.copy(timeEpochMs = it.timeEpochMs + shift) }
        val quotes = s.live.mapValues { EvidencePolicy.LiveQuote(it.value, b * 1000L - 10_000L) } +
            ("BTCJPY" to EvidencePolicy.LiveQuote(btc.cands.first { it.instrument == "BTCJPY" }.live, b * 1000L - 10_000L))
        val order = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
        val native = ScanResult(scanId = "fix-$b", atJst = e.minusSeconds(10).toOffsetDateTime().toString(), entryTimeJst = e.toOffsetDateTime().toString(),
            judgeTimeJst = e.plusMinutes(3).toOffsetDateTime().toString(),
            candidates = order.mapIndexed { i, inst -> ScanCandidate(i + 1, inst, inst, "HIGH", "C", 0.5, "ENTRY", 0.0, "RANGE", 0.5, emptyList()) }, source = "AUTO")
        val want = EventRules.match(e, s.bars, s.live.mapValues { it.value as Double? }, EventRules.ALL_IDS)!!
        val out = EvidencePolicy.apply(native, native, bars, quotes)
        val top = out.top1!!
        assertEquals(want.grade, top.grade); assertEquals("ENTRY", top.decision)
        assertEquals(s.match!![1], top.instrument); assertEquals(s.match!![2], top.direction)
        assertTrue(top.assessment!!.correctionLabel!!.startsWith("【3分判定】時間帯ルール ${want.grade}（仲値(9:55)"))
        assertEquals(1, EvidencePolicy.bufferSize(true, false))          // the model decision was still recorded
    }
}

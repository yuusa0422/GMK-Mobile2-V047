import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.83 bug fixes of the 1-minute judgment (the screen, fetch and chart fixes are pinned by tools/audit_v0783.py). */
class AuditFixV0783Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun num(s: String) = if (s == "nan") Double.NaN else s.toDouble()

    /** The weekend slots of the v0.7.82 fixture (crypto, 245 raw minutes each). */
    private fun weekendSlots(): List<Pair<Long, Map<String, List<Candle>>>> {
        val out = ArrayList<Pair<Long, HashMap<String, ArrayList<Candle>>>>(); var keep = false
        val lines = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0782_m2_slots.txt.gz")!!).bufferedReader().readLines()
        for (l in lines) {
            val q = l.split('|')
            if (q[0] == "S") { keep = q[1] == "E"; if (keep) out.add(q[2].toLong() to HashMap()) }
            else if (q[0] == "C" && keep) out.last().second.getOrPut(q[1]) { ArrayList() }.add(Candle(q[2].toLong() * 1000L, num(q[3]), num(q[4]), num(q[5]), num(q[6]), num(q[7])))
        }
        return out
    }

    @Test fun theOneMinuteModelNeedsMoreThanTheFiveMinuteWindow() {
        // v0.7.82 asked the crypto sources for 130 minutes (the 5-minute models' window): the 1-minute models need 241, so no crypto pair
        // was ever scored (weekends: no 1-minute judgment at all). v0.7.83 asks WINDOW + 9 minutes, within Coinbase's 300 per request.
        assertTrue(CandleModelM2.WINDOW + 9 <= 300)
        for ((b, bars) in weekendSlots()) {
            val entry = Instant.ofEpochSecond(b).atZone(jst)
            val live = bars.mapValues { (_, c) -> c.first { it.timeEpochMs == b * 1000L - 60_000L }.close }
            val window = { minutes: Long -> bars.mapValues { (_, c) -> c.filter { it.timeEpochMs >= b * 1000L - minutes * 60_000L } } }
            assertTrue(OneMinutePolicy.scores(window(130L), live, entry).isEmpty())
            assertEquals(CandleModelM2.CRYPTO, OneMinutePolicy.scores(window(CandleModelM2.WINDOW + 9L), live, entry).map { it.instrument })
        }
    }

    private fun row(id: Long, policy: String, status: String = "WIN") = HistoryRow(id, "m$id", "AUTO_1M", "2026-11-09T10:05:00+09:00", "BTCJPY", "HIGH", "C", "ENTRY",
        entryTimeJst = "2026-11-09T10:05:00+09:00", judgeTimeJst = "2026-11-09T10:06:00+09:00", entryRate = 1.0, judgeRate = 2.0, resultStatus = status,
        policyVersion = policy)

    @Test fun currentAndOlderOneMinuteModelsAreCountedApart() {
        val now = row(1, OneMinutePolicy.POLICY_TAG); val old = row(2, OneMinutePolicy.POLICY_TAG_V0775, "LOSE")
        assertNotEquals(OneMinutePolicy.POLICY_TAG, OneMinutePolicy.POLICY_TAG_V0775)
        assertTrue(OneMinutePolicy.isPolicy(now) && OneMinutePolicy.isPolicy(old))
        assertTrue(OneMinutePolicy.isCurrent(now)); assertFalse(OneMinutePolicy.isCurrent(old))
        assertTrue(RankStatistics.isOneMinute(now) && RankStatistics.isOneMinute(old))
        val tables = RankStatistics.tables(listOf(now, old))
        val cur = tables.single { it.key == "1m83|平日" }; val prev = tables.single { it.key == "1m75|平日" }
        assertEquals(1, cur.counts.single { it.grade == "C" }.wins); assertEquals(1, prev.counts.single { it.grade == "C" }.losses)
        assertTrue(cur.validated.isNotEmpty()); assertTrue(prev.validated.isEmpty())
        assertEquals(listOf("1m83|平日", "1m75|平日"), tables.map { it.key })
        // both count in the hour's ENTRY and the day's results (the hour rule must not restart at the update)
        assertEquals(2, OneMinutePolicy.enteredInHour(listOf(now, old), ZonedDateTime.parse("2026-11-09T10:30:00+09:00")))
        assertEquals(1, ShrineBoard.todayOneMinute(listOf(now, old), java.time.LocalDate.parse("2026-11-09")).wins)
    }
}

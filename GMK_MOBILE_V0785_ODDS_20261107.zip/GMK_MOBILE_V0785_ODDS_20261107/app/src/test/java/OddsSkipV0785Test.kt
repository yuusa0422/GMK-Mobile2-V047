import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZonedDateTime

/** v0.7.85: D..H of the skipped trades and the 勝ち・反転・引き分け probabilities. */
class OddsSkipV0785Test {
    @Test fun skipGradesAreBandsOfThePlaceInTheHour() {
        assertEquals(listOf("D", "D", "E", "F", "G", "H", "H"), listOf(0.1, 0.699, 0.70, 0.85, 0.93, 0.95, 1.0).map(SkipGrades::of))
        for (seg in listOf(SkipGrades.W5, SkipGrades.E3, SkipGrades.M1W, SkipGrades.M1E)) for (g in SkipGrades.GRADES) assertNotNull("$seg $g", SkipGrades.rate(seg, g))
        // the 1-minute weekend bands: weaker band, lower win rate and more draws
        val e = SkipGrades.GRADES.map { SkipGrades.rate(SkipGrades.M1E, it)!! }
        assertTrue(e.zipWithNext().all { (a, b) -> a.first >= b.first && a.second <= b.second })
        assertTrue(SkipGrades.text(SkipGrades.W5, "E").startsWith("見送り E（やや弱い・上位70〜80%）入っていたら 51.0%"))
    }

    @Test fun oddsAddUpAndFollowTheCalibration() {
        val o = TradeOdds.of(TradeOdds.M1_WEEKDAY, "HIGH", 0.53, 0.44)!!          // raw draw 0.03 -> 2.93% happened
        assertEquals(1.0, o.win + o.reverse + o.draw, 1e-12); assertEquals(0.53, o.win, 1e-12); assertEquals(0.0293, o.draw, 1e-12); assertFalse(o.drawWarning)
        val q = TradeOdds.of(TradeOdds.M1_WEEKEND, "LOW", 0.40, 0.48)!!          // raw 0.12 -> 10.8%: a draw is likely
        assertEquals(0.48, q.win, 1e-12); assertEquals(0.108, q.draw, 1e-12); assertTrue(q.drawWarning)
        assertEquals(0.0018, TradeOdds.of(TradeOdds.M1_WEEKDAY, "HIGH", 0.52, 0.50)!!.draw, 1e-12)   // raw below 0
        assertNull(TradeOdds.of(TradeOdds.M5_WEEKDAY, "HIGH", Double.NaN, 0.4))
    }

    @Test fun runningTradeReversal() {
        assertEquals(0.5, TradeOdds.phi(0.0), 1e-7); assertEquals(0.158655, TradeOdds.phi(-1.0), 1e-6); assertEquals(0.977250, TradeOdds.phi(2.0), 1e-6)
        // one sigma ahead with one minute left: 15.9%; four minutes left: Phi(-0.5) = 30.9%; far ahead: at least 3%
        assertEquals(0.158655, TradeOdds.reverse(0.01, 0.01, 1.0)!!, 1e-6)
        assertEquals(0.308538, TradeOdds.reverse(-0.01, 0.01, 4.0)!!, 1e-6)
        assertEquals(0.03, TradeOdds.reverse(1.0, 0.01, 1.0)!!, 1e-12)
        assertNull(TradeOdds.reverse(0.01, 0.0, 1.0))
        val c = (0 until 61).map { Candle(it * 60_000L, 100.0, 100.0, 100.0, 100.0 + (if (it % 2 == 0) 0.01 else -0.01)) }
        assertEquals(0.02, TradeOdds.sigmaPerMinute(c)!!, 1e-3)
    }

    @Test fun oneMinuteSkipsAreGraded() {
        val t = ZonedDateTime.parse("2026-11-09T10:20:00+09:00")
        // the hour already has its 70%: the skip is graded by its place in the hour, not a plain D
        val (g, d) = OneMinutePolicy.decide(t, 0.30, 60, 20)
        assertEquals("SKIP", d); assertEquals("H", g)
        val strong = OneMinutePolicy.decide(t, 0.99, 60, 20)
        assertEquals("SKIP" to "D", strong.second to strong.first)
    }
}

/** v0.7.85 on the real slots: every weekday skip of the 5-minute model is the band of its place in the hour; old D rows are 旧D. */
class SkipBandsOnSlotsV0785Test {
    private val jst = java.time.ZoneId.of("Asia/Tokyo")

    @Test fun weekdaySkipsTakeTheBandOfTheirPlace() {
        var checked = 0
        for (s in EvidenceFixture.slots.filter { !it.weekend }) for (shift in 0L..1L) {
            EvidencePolicy.resetState()
            val e = s.entry.plusMinutes(shift)
            val n = s.native().copy(entryTimeJst = e.toOffsetDateTime().toString(), judgeTimeJst = e.plusMinutes(5).toOffsetDateTime().toString())
            val bars = s.candles().mapValues { (_, v) -> v.map { it.copy(timeEpochMs = it.timeEpochMs + shift * 60_000L) } }
            val quotes = s.quotes().mapValues { (_, q) -> q.copy(epochMs = q.epochMs + shift * 60_000L) }
            val top = EvidencePolicy.apply(n, n, bars, quotes, EntryMode.WEEKDAY_60, 3).top1!!
            val note = top.reasons[1]
            if (top.grade !in SkipGrades.GRADES || " CAUTION" in note || " FIVE=" !in note) continue
            val p5 = Regex(" p5=([0-9.]+)").find(note)!!.groupValues[1].toDouble()
            val hour = e.withZoneSameInstant(jst).hour
            val want = listOf(-5e-5, 5e-5).map { SkipGrades.of(SubGrades.weekday(" fresh5" in note, hour, p5 + it)) }.toSet()
            assertTrue("$note -> ${top.grade} want $want", top.grade in want)
            val label = top.assessment!!.correctionLabel!!
            assertTrue(label, SkipGrades.word(top.grade) in label && "入っていたら" in label)
            assertFalse(SkipGrades.legacyD(HistoryRow(1, "x", "AUTO", n.entryTimeJst, top.instrument, top.direction, top.grade, "SKIP", assessment = top.assessment)))
            checked++
        }
        assertTrue("checked $checked", checked >= 10)
    }

    @Test fun oldDRowsAreCountedApart() {
        fun row(id: Long, label: String?) = HistoryRow(id, "m$id", "AUTO", "2026-11-09T10:05:00+09:00", "USDJPY", "HIGH", "D", "SKIP",
            entryTimeJst = "2026-11-09T10:05:00+09:00", judgeTimeJst = "2026-11-09T10:10:00+09:00", entryRate = 1.0, judgeRate = 2.0, resultStatus = "WIN",
            policyVersion = EvidencePolicy.POLICY_TAG, assessment = label?.let { CandidateAssessment("未記録", null, null, "D", "SKIP", RuleSelectionStage.LEGACY_BASE,
                CandidateSkipReason.UNKNOWN, null, null, null, CandidateActionTrace("USDJPY", "HIGH", "未記録", null, null, "D", "SKIP", 1),
                CandidateActionTrace("USDJPY", "HIGH", "未記録", null, null, "D", "SKIP", 1), null, it) })
        val old = row(1, "【5分判定】見送り D（検証 50.9%）"); val new = row(2, "【5分判定】見送り D（惜しい・上位70%以内・入っていたら 52.8%）")
        assertTrue(SkipGrades.legacyD(old)); assertTrue(SkipGrades.legacyD(row(3, null))); assertFalse(SkipGrades.legacyD(new))
        assertFalse(RankFilter.matches(old, "D")); assertTrue(RankFilter.matches(new, "D"))
        val t = RankStatistics.tables(listOf(old, new)).single()
        val d = t.counts.single { it.grade == "D" }; val l = t.counts.single { it.grade == SkipGrades.LEGACY_D }
        assertEquals(1, d.total); assertEquals(1, l.total)
        assertTrue(RankStatistics.lineText(t, l).startsWith(SkipGrades.LEGACY_D_TEXT + "  見送り 1件"))
        assertTrue(RankStatistics.lineText(t, d).endsWith("｜検証 52.8%"))
    }
}

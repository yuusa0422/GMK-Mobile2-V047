import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZonedDateTime

/** v0.7.80 1分の連敗の目安: today's longest streak, runs of 5+, B apart (display only; the 1-minute decision is unchanged). */
class OneMinuteStreakV0780Test {
    private fun row(i: Int, at: String, status: String, grade: String = "C", policy: String = OneMinutePolicy.POLICY_TAG) =
        HistoryRow(i.toLong(), "m$i", "AUTO_1M", at, "BTCJPY", "HIGH", grade, "ENTRY", entryTimeJst = at,
            judgeTimeJst = ZonedDateTime.parse(at).plusMinutes(1).toString(), entryRate = 1.0, judgeRate = 1.1, resultStatus = status, policyVersion = policy)

    @Test fun todayInTimeOrder() {
        val day = LocalDate.parse("2026-11-06")
        val seq = "LLLLLLWLLWWLLLLLB"          // 6 losses, win, 2 losses, 2 wins, 5 losses, then a B win
        val rows = seq.mapIndexed { i, c ->
            val at = ZonedDateTime.parse("2026-11-06T10:00:00+09:00").plusMinutes(i.toLong()).toOffsetDateTime().toString()
            row(i, at, if (c == 'L') "LOSE" else "WIN", grade = if (c == 'B') "B" else "C")
        }.shuffled(java.util.Random(3)) +
            row(90, "2026-11-05T10:00:00+09:00", "LOSE") +                                   // yesterday
            row(91, "2026-11-06T11:00:00+09:00", "WAIT_JUDGE") +                             // not settled
            row(92, "2026-11-06T11:01:00+09:00", "LOSE", policy = EvidencePolicy.POLICY_TAG)  // a 5-minute trade
        val d = OneMinuteStreak.today(rows, day)
        assertEquals(4, d.wins); assertEquals(13, d.losses); assertEquals(6, d.longest); assertEquals(2, d.runs5)
        assertEquals(1, d.bWins); assertEquals(0, d.bLosses)
        assertTrue(OneMinuteStreak.dayText(d).startsWith("今日の最長 6連敗・5連敗以上 2回・Bだけ 1勝0敗 100.0%"))
        assertEquals("", OneMinuteStreak.dayText(OneMinuteStreak.today(emptyList(), day)))
    }

    @Test fun verdictBands() {
        assertEquals("", OneMinuteStreak.verdict(2))
        // v0.7.82: the counts at the 70% rule with the v0.7.82 models
        assertTrue(OneMinuteStreak.verdict(3).contains("約33回")); assertTrue(OneMinuteStreak.verdict(5).contains("約7回"))
        assertTrue(OneMinuteStreak.verdict(7).contains("約1.4回")); assertTrue(OneMinuteStreak.verdict(12).contains("5日に1回"))
        // the bands follow the research table
        assertEquals(listOf(3, 5, 7, 10), OneMinuteStreak.ODDS_PER_DAY.map { it.first })
    }
}

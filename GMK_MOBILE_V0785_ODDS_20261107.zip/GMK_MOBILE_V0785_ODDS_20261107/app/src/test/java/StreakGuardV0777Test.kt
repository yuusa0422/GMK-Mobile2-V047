import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZonedDateTime

/**
 * v0.7.77 連敗結界: the settled losing streak before an entry (known results only, last 30 minutes, this policy's rank-1 ENTRY trades),
 * and the weekday C cut asking a stronger trade on a streak while the hour's catch-up (70%) is unchanged.
 */
class StreakGuardV0777Test {
    private val tag = EvidencePolicy.POLICY_TAG
    private fun row(id: Int, at: String, status: String, minutes: Long = 5, rank: Int = 1, decision: String = "ENTRY", policy: String = tag) =
        HistoryRow(id.toLong(), "s$id", "AUTO", at, "USDJPY", "HIGH", "C", decision, candidateRank = rank, entryTimeJst = at,
            judgeTimeJst = ZonedDateTime.parse(at).plusMinutes(minutes).toString(), entryRate = 150.0, judgeRate = 150.1, resultStatus = status, policyVersion = policy)

    @Test fun streakCountsOnlyKnownResults() {
        val entry = ZonedDateTime.parse("2026-11-06T10:30:00+09:00")
        val rows = listOf(
            row(1, "2026-11-06T09:55:00+09:00", "LOSE"),            // older than 30 minutes: not counted
            row(2, "2026-11-06T10:05:00+09:00", "WIN"),
            row(3, "2026-11-06T10:10:00+09:00", "LOSE"),
            row(4, "2026-11-06T10:15:00+09:00", "LOSE"),
            row(5, "2026-11-06T10:20:00+09:00", "LOSE"),
            row(6, "2026-11-06T10:25:00+09:00", "WAIT_JUDGE"),      // running (judged at 10:30): skipped
            row(7, "2026-11-06T10:22:00+09:00", "WIN", rank = 2),    // not the chosen trade
            row(8, "2026-11-06T10:23:00+09:00", "WIN", decision = "SKIP"),
            row(9, "2026-11-06T10:24:00+09:00", "WIN", policy = OneMinutePolicy.POLICY_TAG, minutes = 1))
        assertEquals(3, StreakGuard.streak(rows, entry, tag)); assertTrue(StreakGuard.active(3)); assertFalse(StreakGuard.active(2))
        // a trade judged after the decision time (entry - 10 s) is not known yet even when stored as settled
        assertEquals(3, StreakGuard.streak(rows + row(10, "2026-11-06T10:25:00+09:00", "WIN"), entry, tag))
        assertEquals(0, StreakGuard.streak(rows + row(11, "2026-11-06T10:21:00+09:00", "WIN", minutes = 3), entry, tag))
        assertEquals(0, StreakGuard.streak(emptyList(), entry, tag))
        // the 30-minute window starts at entry - 1800 s
        assertEquals(1, StreakGuard.streak(listOf(row(12, "2026-11-06T10:00:00+09:00", "LOSE")), entry, tag))
        assertEquals(0, StreakGuard.streak(listOf(row(13, "2026-11-06T09:59:00+09:00", "LOSE")), entry, tag))
    }

    @Test fun onAStreakTheCutAsksAStrongerTradeButTheHourStillReachesSeventyPercent() {
        for (fresh in listOf(true, false)) for (h in 10..22) {
            val calm = RankLadder.minuteCut(fresh, h, 20, 3, 12, lossStreak = StreakGuard.K - 1)
            val hot = RankLadder.minuteCut(fresh, h, 20, 3, 12, lossStreak = StreakGuard.K)
            assertEquals(RankLadder.minuteCut(fresh, h, 20, 3, 12).cut, calm.cut, 0.0)
            val frac0 = maxOf(RankLadder.PACE * calm.need / calm.left, RankLadder.baseShare(fresh, h) / 2.0)
            assertEquals(RankLadder.quantileCut(fresh, h, frac0 * StreakGuard.PICKY), hot.cut, 1e-12)
            assertTrue(hot.cut >= calm.cut)
            // catch-up and a full hour are unchanged
            val catchUp = RankLadder.minuteCut(fresh, h, 40, 2, 12, lossStreak = 9)
            assertTrue(catchUp.catchUp); assertEquals(Double.NEGATIVE_INFINITY, catchUp.cut, 0.0)
            assertTrue(RankLadder.minuteCut(fresh, h, 40, 9, 12, lossStreak = 9).full)
        }
    }

    @Test fun thePolicyTakesTheStreak() {
        var checked = 0; var same = 0
        for (s in EvidenceFixture.slots.filter { !it.weekend }) {
            // entries so far this hour so that the slot is one short of a catch-up (one more slot left than entries still needed)
            val minute = ZonedDateTime.parse(s.native().entryTimeJst).minute
            val left = ((60 - minute + 4) / 5).coerceIn(1, 12); val entries = (10 - left).coerceIn(0, 8)
            EvidencePolicy.resetState()
            val calm = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.WEEKDAY_60, hourEntries = entries).top1!!
            EvidencePolicy.resetState()
            val hot = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.WEEKDAY_60, hourEntries = entries, lossStreak = 4).top1!!
            val n = hot.reasons[1]
            if (" FIVE=" !in n || " CATCHUP" in n || " FULL" in n) { assertEquals(calm.grade, hot.grade); assertEquals(calm.decision, hot.decision); same++; continue }
            assertTrue(n, " STREAK=4" in n)
            assertTrue(hot.assessment!!.correctionLabel!!, hot.assessment!!.correctionLabel!!.contains("4連敗中の連敗結界で基準を上げる"))
            val p5 = { x: String -> Regex(" p5=([0-9.]+)").find(x)!!.groupValues[1].toDouble() }
            val cut = { x: String -> Regex(" cut=([0-9.]+)").find(x)!!.groupValues[1].toDouble() }
            assertTrue(n, cut(n) > cut(calm.reasons[1]))                                     // the streak asks a stronger trade
            // each run's grade follows its own cut (the note rounds to 4 digits)
            for (top in listOf(calm, hot)) {
                val x = top.reasons[1]
                if (Math.abs(p5(x) - cut(x)) > 1e-4) { if (p5(x) >= cut(x)) assertEquals(x, "C", top.grade) else assertTrue(x, top.grade in SkipGrades.GRADES) }   // v0.7.85: D..H
            }
            if (hot.grade == "C") assertEquals("C", calm.grade)          // pickier never turns a D into a C
            checked++
        }
        assertTrue("checked $checked same $same", checked >= 10)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZonedDateTime

/** v0.7.84 fixes in the domain (the screen fixes are pinned by tools/audit_v0784.py). */
class AuditFixV0784Test {
    private fun row(id: Long, status: String, entry: String) = HistoryRow(id, "r$id", "AUTO_1M", entry, "BTCJPY", "HIGH", "C", "ENTRY",
        entryTimeJst = entry, judgeTimeJst = ZonedDateTime.parse(entry).plusMinutes(1).toString(), entryRate = 100.0, resultStatus = status,
        policyVersion = OneMinutePolicy.POLICY_TAG)

    @Test fun runningTradesReadOnlyTheNewestRows() {
        // the running trades panel reads the newest SCAN_ROWS rows every second (it read the whole history, up to 20,000 rows)
        val now = ZonedDateTime.parse("2026-11-09T10:30:30+09:00")
        val running = row(1, "WAIT_JUDGE", "2026-11-09T10:30:00+09:00")
        val settled = (2L..2000L).map { row(it, "WIN", "2026-11-09T09:00:00+09:00") }
        val t = RunningTrades.of(listOf(running) + settled, mapOf("BTCJPY" to 101.0), now.toInstant().toEpochMilli())
        assertEquals(listOf(1L), t.map { it.row.id }); assertEquals(true, t.single().leading)
        assertTrue(RunningTrades.SCAN_ROWS in 200..1000)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.55: ENTRY only where one year (scored on other periods) is 55% or more; live-price age recorded on every row. */
class FiftyFiveV0755Test {
    @Before fun reset() = EvidencePolicy.resetState()
    private val jst = ZoneId.of("Asia/Tokyo")

    @Test fun ladderRatesAndConstants() {
        // v0.7.56 keeps the v0.7.55 ladder as the 55%優先 setting (version constants: EntrySixtyV0756Test)
        assertEquals(setOf("S", "A", "B"), RankLadder.ENTRY_GRADES); assertEquals(RankLadder.ENTRY_GRADES, EntryMode.FIFTY_FIVE.entryGrades(false))
        // every ENTRY grade is validated at 55% or more, every skip grade below
        for (w in listOf(false, true)) for (g in listOf("S", "A", "B", "D", "E", "F", "G", "H")) {
            val r = EvidencePolicy.gradeRate(true, w, g) ?: continue
            assertEquals("$g weekend=$w $r", g in RankLadder.ENTRY_GRADES, r >= 0.55)
        }
        assertEquals(0.6121, EvidencePolicy.gradeRate(true, true, "B")!!, 0.0); assertEquals(0.5089, EvidencePolicy.gradeRate(true, false, "D")!!, 0.0)   // v0.7.71
        assertEquals(0.5309, EvidencePolicy.gradeRate(true, false, "C")!!, 0.0); assertNull(EvidencePolicy.gradeRate(false, false, "B"))
        assertEquals(0.5657, EvidencePolicy.gradeRate(false, true, "B")!!, 0.0)   // v0.7.71 weekend backup model
        assertTrue(RankLadder.againstHour(-0.3, 1)); assertTrue(RankLadder.againstHour(0.0, 1)); assertTrue(RankLadder.againstHour(0.7, -1))
        assertFalse(RankLadder.againstHour(0.2, 1)); assertFalse(RankLadder.againstHour(-0.2, -1)); assertFalse(RankLadder.againstHour(null, 1))
        assertFalse(RankLadder.againstHour(Double.NaN, 1))
        assertEquals("A", SignalAlerts.normalizeMinGrade("A")); assertEquals("C", SignalAlerts.normalizeMinGrade("C"))   // v0.7.56
    }

    @Test fun modelGradeMapping() {
        val weekday = mapOf("S" to "D", "A" to "D", "B" to "D", "C" to "D", "D" to "E", "E" to "F")
        for ((g, want) in weekday) {
            assertEquals(g, want, RankLadder.modelGrade(g, false, false, 14))
            assertEquals(g, if (g in setOf("S", "A")) "B" else want, RankLadder.modelGrade(g, false, true, 14))
            assertEquals(g, if (g in setOf("S", "A", "B", "C")) "F" else want, RankLadder.modelGrade(g, false, false, 9))
        }
        val weekend = mapOf("S" to "D", "A" to "D", "B" to "D", "C" to "D", "D" to "D", "E" to "E", "F" to "F", "G" to "G", "H" to "H")   // v0.7.56: D below the C cut
        for ((g, want) in weekend) {
            assertEquals(g, want, RankLadder.modelGrade(g, true, false, 14, false))
            assertEquals(g, if (g == "S") "B" else want, RankLadder.modelGrade(g, true, false, 14, true))
        }
        assertTrue(RankLadder.demotion("S", true, false, 14, false)!!.contains("追いかける"))
        assertTrue(RankLadder.demotion("A", false, false, 14)!!.contains("50.8%"))   // v0.7.56: below the C cut
    }

    @Test fun weekendStrongTradeEntersOnlyAgainstTheHourOnRealSlots() {
        var against = 0; var chasing = 0
        for (s in EvidenceFixture.slots.filter { it.weekend }) {
            EvidencePolicy.resetState()
            val top = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes()).top1!!
            val note = top.reasons[1]; val v48 = Regex(" v0748=([A-Z])").find(note)!!.groupValues[1]
            val dir = if (top.direction == "HIGH") 1 else -1
            val pyPos60 = s.features.getValue(top.instrument)[EvidenceFixture.FEATURE_KEYS.indexOf("pos60")]      // Python research value
            val want = pyPos60 * dir <= 0.0
            assertEquals("slot ${s.boundary} pos60=$pyPos60 dir=$dir", want, " AGAINST_HOUR" in note)
            if (v48 == "S") {
                if (want) { against++; assertEquals("B", top.grade); assertEquals("ENTRY", top.decision); assertTrue(top.assessment!!.correctionLabel!!.contains("追いかけない")) }
                else { chasing++; assertEquals("D", top.grade); assertEquals("SKIP", top.decision); assertTrue(top.assessment!!.correctionLabel!!.contains("追いかける")) }
            } else assertNotEquals("ENTRY", top.decision)
        }
        assertTrue("against=$against chasing=$chasing", against + chasing >= 1)
    }

    @Test fun weekdayEntersOnlySAndB() {
        var d = 0
        for (s in EvidenceFixture.slots.filter { !it.weekend }) {
            EvidencePolicy.resetState()
            val top = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes()).top1!!
            val note = top.reasons[1]; val label = top.assessment!!.correctionLabel!!.removePrefix("【3分判定】").removePrefix("【5分判定】")
            if (top.decision == "ENTRY") assertTrue(top.grade in setOf("S", "A", "B"))
            if (" RULE=" !in note && " CAUTION" !in note && top.grade != "B") {
                // v0.7.57 (55%優先): every other weekday trade is the 5-minute model's C ("55%未満", skipped here) or D (below the hour's cut)
                assertTrue(top.grade, top.grade == "C" || top.grade in SkipGrades.GRADES); assertEquals("SKIP", top.decision)   // v0.7.85: D..H
                assertTrue(label, label.startsWith("見送り ") && (if (top.grade == "C") "55%未満" in label else "基準" in label)); d++
            }
        }
        assertTrue("former C rows $d", d >= 5)
    }

    @Test fun liveAgeIsRecordedInLabelAndNote() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val top = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(ageMs = 12_300L)).top1!!
        assertTrue(top.reasons[1], " qage=12300ms" in top.reasons[1])
        assertTrue(top.assessment!!.correctionLabel!!, "直前価格 12.3秒前" in top.assessment!!.correctionLabel!!)
        EvidencePolicy.resetState()
        val stale = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(ageMs = 45_000L)).top1!!
        assertTrue(stale.assessment!!.correctionLabel!!.contains("予備モデル"))
        assertTrue(Regex("直前価格 ([0-9]+(?:\\.[0-9]+)?)秒前").find("… / 直前価格 7.5秒前")!!.groupValues[1] == "7.5")
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/**
 * v0.7.76 C1 / C2 / C3: the place in the hour is the inverse of the cut the ENTRY rule takes from the same hour table, the bands are the
 * research's, real slots through the app's policy carry the sub-grade of their C (weekday 5-minute, weekend model, 1-minute), the setting
 * promotes only a C1 of the weekday / weekend model (to an entered B, nothing else changes), and the history counts the sub-grades.
 */
class SubGradeV0776Test {
    private val jst = ZoneId.of("Asia/Tokyo")

    @Test fun placeInTheHourInvertsTheHourCut() {
        for (fresh in listOf(true, false)) for (h in 9..22) for (frac in listOf(0.03, 0.05, 0.10, 0.25, 0.30, 0.5, 0.8)) {
            val cut = RankLadder.quantileCut(fresh, h, frac)
            assertEquals("$fresh $h $frac", frac, SubGrades.weekday(fresh, h, cut), 0.006)
        }
        for (weekend in listOf(false, true)) for (h in 9..22) for (frac in listOf(0.05, 0.10, 0.15, 0.4, 0.8)) {
            assertEquals("$weekend $h $frac", frac, SubGrades.oneMinute(weekend, h, OneMinutePolicy.threshold(weekend, h, frac)), 0.006)
        }
        // the weekend tables give the v0.7.71 cuts: B8 = the top 8%, C60 = the top 60%
        for (h in 0..13) {
            assertEquals(0.08, SubGrades.weekend(true, h + 9, EvidenceModelWData.FRESH_B8[h]), 0.006)
            assertEquals(0.60, SubGrades.weekend(true, h + 9, EvidenceModelWData.FRESH_C60[h]), 0.006)
            assertEquals(0.08, SubGrades.weekend(false, h + 9, EvidenceModelWData.FALLBACK_B8[h]), 0.006)
            assertEquals(0.60, SubGrades.weekend(false, h + 9, EvidenceModelWData.FALLBACK_C60[h]), 0.006)
        }
        assertEquals(14, EvidenceSlotWData.FRESH_QUANTILES.size); assertTrue(EvidenceSlotWData.FRESH_QUANTILES.all { it.size == 201 })
        val q = doubleArrayOf(0.1, 0.2, 0.3)
        assertEquals(1.0, SubGrades.topShare(q, 0.05), 0.0); assertEquals(0.0, SubGrades.topShare(q, 0.4), 0.0)
        assertEquals(0.5, SubGrades.topShare(q, 0.2), 1e-12); assertEquals(0.25, SubGrades.topShare(q, 0.25), 1e-12)
        assertEquals(1.0, SubGrades.topShare(q, Double.NaN), 0.0)
    }

    @Test fun bandsAreTheResearchBands() {
        val wd = SubGrades.BANDS.getValue(SubGrades.WEEKDAY)
        assertEquals(listOf("C1", "C2", "C3"), wd.map { it.label }); assertEquals(listOf(0.10, 0.30), wd.take(2).map { it.maxTop })
        assertEquals(listOf(0.5678, 0.5323, 0.5220), wd.map { it.rate })
        assertEquals(listOf(0.5924, 0.5583, 0.5342), SubGrades.BANDS.getValue(SubGrades.WEEKEND).map { it.rate })
        assertEquals(listOf(0.15, 0.30), SubGrades.BANDS.getValue(SubGrades.WEEKEND).take(2).map { it.maxTop })
        for (seg in SubGrades.BANDS.keys) {
            val b = SubGrades.BANDS.getValue(seg)
            // v0.7.82: the weekday 1-minute model's C2 and C3 are equal (51.55% / 51.63%): only its C1 stands out
            if (seg == SubGrades.M1_WEEKDAY) assertTrue(seg, b.drop(1).all { it.rate < b[0].rate } && b.zipWithNext().all { (x, y) -> x.maxTop < y.maxTop })
            else assertTrue(seg, b.zipWithNext().all { (x, y) -> x.rate > y.rate && x.maxTop < y.maxTop })
            assertTrue(b.last().maxTop > 1.0)
        }
        assertEquals("C1", SubGrades.of(SubGrades.WEEKDAY, "C", 0.0999, 0.55, true)!!.label)
        assertEquals("C2", SubGrades.of(SubGrades.WEEKDAY, "C", 0.10, 0.55, true)!!.label)
        assertEquals("C3", SubGrades.of(SubGrades.WEEKDAY, "C", 0.30, 0.55, true)!!.label)
        assertEquals("C3", SubGrades.of(SubGrades.WEEKDAY, "C", 1.0, 0.55, true)!!.label)
        assertNull(SubGrades.of(SubGrades.WEEKDAY, "B", 0.05, 0.55, true)); assertNull(SubGrades.of(SubGrades.WEEKDAY, "D", 0.05, 0.55, true))
        val c1 = SubGrades.of(SubGrades.WEEKDAY, "C", 0.07, 0.551, true)!!
        assertEquals(0.5678, c1.rate!!, 0.0); assertNull(c1.copy(fresh = false).rate)
        // promotion: only with the setting, only a live-price C1 of the weekday / weekend model
        assertFalse(SubGrades.promote(c1, false)!!.promoted); assertTrue(SubGrades.promote(c1, true)!!.promoted)
        assertEquals("B↑C1", SubGrades.promote(c1, true)!!.shown)
        assertFalse(SubGrades.promote(c1.copy(fresh = false), true)!!.promoted)
        assertFalse(SubGrades.promote(c1.copy(label = "C2"), true)!!.promoted)
        assertTrue(SubGrades.promote(c1.copy(segment = SubGrades.WEEKEND), true)!!.promoted)
        assertFalse(SubGrades.promote(c1.copy(segment = SubGrades.M1_WEEKDAY), true)!!.promoted)
        assertFalse(SubGrades.promote(c1.copy(segment = SubGrades.M1_WEEKEND), true)!!.promoted)
        assertTrue(SubGrades.text(c1), SubGrades.text(c1).startsWith("C1・その時間の上位7%・勝つ確率55.1%・検証56.8%"))
    }

    private fun note(top: ScanCandidate) = top.reasons[1]

    @Test fun weekdaySlotsCarryTheSubGradeOfTheirC() {
        var c = 0; var c1 = 0; var other = 0
        for (s in EvidenceFixture.slots.filter { !it.weekend }) {
            EvidencePolicy.resetState()
            val off = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.WEEKDAY_60).top1!!
            EvidencePolicy.resetState()
            val on = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.WEEKDAY_60, promoteC1 = true).top1!!
            EvidencePolicy.resetState()
            val fifty = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), EntryMode.FIFTY_FIVE, promoteC1 = true).top1!!
            val sub = off.assessment!!.subGrade
            if (off.grade != "C") { assertNull(note(off), sub); assertEquals(off.grade, on.grade); assertEquals(off.decision, on.decision); other++; continue }
            c++
            assertNotNull(note(off), sub)
            val n = note(off)
            val p5 = Regex(" p5=([0-9.]+)").find(n)!!.groupValues[1].toDouble()
            val hour = ZonedDateTime.parse(s.native().entryTimeJst).withZoneSameInstant(jst).hour
            assertEquals(n, SubGrades.weekday(" fresh5" in n, hour, p5), sub!!.top, 2e-3)
            assertEquals(n, SubGrades.bandOf(SubGrades.WEEKDAY, sub.top)!!.label, sub.label)
            assertTrue(n, " SUB=${sub.label} " in n); assertFalse(sub.promoted)
            val label = off.assessment!!.correctionLabel!!
            assertTrue(label, label.contains("Cの中の強さ ${sub.label}・その時間の"))
            assertEquals(SubGrades.chip(sub), "${sub.label} ${"%.1f%%".format(sub.probability * 100.0)}")
            if (sub.label == "C1" && sub.fresh) {
                c1++
                assertEquals("B", on.grade); assertEquals("ENTRY", on.decision); assertTrue(on.assessment!!.subGrade!!.promoted)
                assertEquals("B", on.assessment!!.chosenAction.operationalGrade); assertEquals(5, on.assessment!!.chosenAction.judgeMinutes)
                assertTrue(note(on), " PROMOTED" in note(on) && note(on).endsWith(" -> B/ENTRY ${on.instrument} ${on.direction}"))
                assertTrue(on.assessment!!.correctionLabel!!, on.assessment!!.correctionLabel!!.startsWith("【5分判定】5分モデル B↑C1"))
                assertEquals("B", fifty.grade); assertEquals("ENTRY", fifty.decision)     // 55%優先 enters the promoted C1
            } else {
                assertEquals(off.grade, on.grade); assertEquals(off.decision, on.decision); assertFalse(on.assessment!!.subGrade!!.promoted)
            }
            assertEquals(off.instrument, on.instrument); assertEquals(off.direction, on.direction)
        }
        assertTrue("C $c C1 $c1 other $other", c >= 5 && c1 >= 1 && other >= 5)
    }

    private class RealSlot(val kind: String, val b: Long) { val bars = LinkedHashMap<String, ArrayList<Candle>>(); val live = HashMap<String, Double>() }
    private fun realSlots(): List<RealSlot> {
        val out = ArrayList<RealSlot>(); var cur: RealSlot? = null
        for (l in GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0772_real_slots.txt.gz")!!).bufferedReader().readLines()) {
            val p = l.split('|')
            when (p[0]) {
                "S" -> { cur = RealSlot(p[1], p[2].toLong()); out.add(cur) }
                "C" -> cur!!.bars.getOrPut(p[1]) { ArrayList() }.add(Candle(p[2].toLong() * 1000L, p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble()))
                "L" -> cur!!.live[p[1]] = p[2].toDouble()
            }
        }
        return out
    }

    @Test fun weekendSlotsCarryTheSubGradeOfTheirC() {
        val grades = HashMap<String, Int>()
        for (s in realSlots().filter { it.kind == "we" }) {
            val entry = Instant.ofEpochSecond(s.b).atZone(jst)
            val cq = s.live.mapValues { EvidencePolicy.LiveQuote(it.value, s.b * 1000L - 10_000L) }
            val native = ScanResult("t-${s.b}", entry.minusSeconds(10).toString(), entry.toString(), entry.plusMinutes(3).toString(), source = "AUTO")
            for (promote in listOf(false, true)) {
                val top = EvidencePolicy.apply(native, native, emptyMap(), emptyMap(), EntryMode.WEEKDAY_60, crypto = s.bars, cryptoQuotes = cq, promoteC1 = promote).top1!!
                val n = note(top); val sub = top.assessment!!.subGrade
                val p = Regex(" p=([0-9.]+)").find(n)!!.groupValues[1].toDouble()
                val c60 = Regex(" c60=([0-9.]+)").find(n)!!.groupValues[1].toDouble(); val b8 = Regex(" b8=([0-9.]+)").find(n)!!.groupValues[1].toDouble()
                if (Math.abs(p - c60) < 2e-4 || Math.abs(p - b8) < 2e-4) continue      // the note rounds to 4 digits
                val c = p >= c60 && p < b8
                assertEquals(n, c, sub != null)
                if (sub == null) continue
                assertEquals(n, SubGrades.WEEKEND, sub.segment)
                assertEquals(n, SubGrades.weekend(true, entry.hour, sub.probability), sub.top, 1e-12)
                assertTrue(n, sub.top >= 0.08 - 0.006 && sub.top <= 0.60 + 0.006)
                val promoted = promote && sub.label == "C1"
                assertEquals(n, promoted, sub.promoted)
                // 平日70% does not enter a weekend C; a promoted C1 is an entered B
                assertEquals(n, if (promoted) "B" else "C", top.grade); assertEquals(n, if (promoted) "ENTRY" else "SKIP", top.decision)
                assertEquals(3, top.assessment!!.chosenAction.judgeMinutes)
                if (!promote) grades.merge(sub.label, 1, Int::plus)
            }
        }
        assertTrue(grades.toString(), grades.values.sum() >= 5 && (grades["C1"] ?: 0) >= 1)
    }

    @Test fun oneMinuteCMinutesCarryTheirSubGrade() {
        val entry = ZonedDateTime.parse("2026-11-06T10:20:00+09:00")
        val strong = OneMinutePolicy.threshold(false, 10, 0.10); val mid = OneMinutePolicy.threshold(false, 10, 0.30); val weak = OneMinutePolicy.threshold(false, 10, 0.70)
        assertEquals("C1", OneMinutePolicy.subGrade(entry, strong, "C")!!.label)
        assertEquals("C2", OneMinutePolicy.subGrade(entry, mid, "C")!!.label)
        assertEquals("C3", OneMinutePolicy.subGrade(entry, weak, "C")!!.label)
        assertNull(OneMinutePolicy.subGrade(entry, strong, "B")); assertNull(OneMinutePolicy.subGrade(entry, strong, "D"))
        assertEquals(SubGrades.M1_WEEKEND, OneMinutePolicy.subGrade(ZonedDateTime.parse("2026-11-07T10:20:00+09:00"), strong, "C")!!.segment)
        val c = OneMinutePolicy.Choice("ETHUSD", "LOW", strong, listOf(EvidencePolicy.PairScore("ETHUSD", 0.4, strong)))
        val r = OneMinutePolicy.result("AUTO_1M", entry, entry.minusSeconds(9), c, "C", "ENTRY", OneMinutePolicy.reason(c, "C", "ENTRY", 3, entry)).top1!!
        assertEquals("C1", r.assessment!!.subGrade!!.label); assertEquals(SubGrades.M1_WEEKDAY, r.assessment!!.subGrade!!.segment)
        assertTrue(r.assessment!!.correctionLabel!!, r.assessment!!.correctionLabel!!.contains("Cの中の強さ C1"))
        assertNull(OneMinutePolicy.result("AUTO_1M", entry, entry.minusSeconds(9), c, "B", "ENTRY", "x").top1!!.assessment!!.subGrade)
    }

    private fun row(id: Int, grade: String, decision: String, status: String, sub: SubGrade?, policy: String = EvidencePolicy.POLICY_TAG,
                    at: String = "2026-11-02T10:05:00+09:00"): HistoryRow {
        val trace = CandidateActionTrace("USDJPY", "HIGH", "未記録", null, null, grade, decision, 5)
        val a = CandidateAssessment("未記録", null, null, grade, decision, RuleSelectionStage.LEGACY_BASE, null, null, null, null, trace, trace, subGrade = sub)
        return HistoryRow(id.toLong(), "s$id", "AUTO", at, "USDJPY", "HIGH", grade, decision, entryTimeJst = at,
            judgeTimeJst = ZonedDateTime.parse(at).plusMinutes(5).toString(), entryRate = 150.0, judgeRate = 150.1, resultStatus = status, policyVersion = policy, assessment = a)
    }

    @Test fun historyCountsTheSubGrades() {
        val c1 = SubGrade("C1", SubGrades.WEEKDAY, 0.05, 0.56); val c3 = SubGrade("C3", SubGrades.WEEKDAY, 0.6, 0.52)
        val rows = listOf(row(1, "C", "ENTRY", "WIN", c1), row(2, "C", "ENTRY", "LOSE", c3), row(3, "B", "ENTRY", "WIN", c1.copy(promoted = true)),
            row(4, "C", "SKIP", "WIN", c1), row(5, "C", "ENTRY", "WIN", null), row(6, "B", "ENTRY", "LOSE", null))
        val t = RankStatistics.tables(rows).single()
        val lines = t.counts.map { RankStatistics.lineText(t, it) }
        assertTrue(lines.toString(), lines.contains("B  1勝1敗 50.0% ｜検証 57.6%"))
        assertTrue(lines.toString(), lines.contains("C  2勝1敗 66.7% ｜検証 53.1%"))
        assertTrue(lines.toString(), lines.contains("└C1  2勝0敗 100.0% ｜検証 56.8%"))      // the C1 and the promoted C1
        assertTrue(lines.toString(), lines.contains("└C3  0勝1敗 0.0% ｜検証 52.2%"))
        assertTrue(lines.toString(), lines.any { it.startsWith("└C1  見送り 1件・入っていたら 1勝0敗") })
        assertFalse(lines.toString(), lines.any { it.startsWith("└C2") })                  // no row, no line
        assertEquals(listOf("B", "C", "C1", "C3", "C", "C1"), t.counts.map { it.grade })
        assertTrue(RankFilter.matches(rows[2], "C1")); assertFalse(RankFilter.matches(rows[1], "C1")); assertTrue(RankFilter.matches(rows[1], "C3"))
        // the monitor expects a row's sub-grade rate when it has one
        val m = RankStatistics.monitor(rows)!!
        assertEquals((0.5678 + 0.5220 + 0.5678 + EvidencePolicy.gradeRate(true, false, "C")!! + EvidencePolicy.gradeRate(true, false, "B")!!) / 5, m.expected, 1e-9)
        // 1-minute rows: C1 / C2 / C3 lines under C with the 1-minute rates
        val m1 = listOf(row(7, "C", "ENTRY", "WIN", SubGrade("C2", SubGrades.M1_WEEKDAY, 0.2, 0.52), OneMinutePolicy.POLICY_TAG, "2026-11-02T10:06:00+09:00"))
        val t1 = RankStatistics.tables(m1).single()
        assertEquals(listOf("C", "C2"), t1.counts.map { it.grade })
        assertTrue(RankStatistics.lineText(t1, t1.counts[1]), RankStatistics.lineText(t1, t1.counts[1]).startsWith("└C2  1勝0敗 100.0% ｜検証 51.6%"))      // v0.7.82 model
    }

    @Test fun spellCardsOfTheSubGrades() {
        val c = ScanCandidate(1, "USDJPY", "USD/JPY", "HIGH", "C", 0.55, "ENTRY")
        assertEquals("夢符「封魔陣」", ShrineBoard.spellCard(c))
        val trace = CandidateActionTrace("USDJPY", "HIGH", "未記録", null, null, "C", "ENTRY", 5)
        fun withSub(s: SubGrade, grade: String = "C") = c.copy(grade = grade, assessment = CandidateAssessment("未記録", null, null, grade, "ENTRY",
            RuleSelectionStage.LEGACY_BASE, null, null, null, null, trace, trace, subGrade = s))
        assertEquals("夢境「二重大結界」", ShrineBoard.spellCard(withSub(SubGrade("C1", SubGrades.WEEKDAY, 0.05, 0.56))))
        assertEquals("宝符「陰陽宝玉」", ShrineBoard.spellCard(withSub(SubGrade("C3", SubGrades.WEEKDAY, 0.5, 0.52))))
        assertEquals("夢境「二重大結界」（C1昇格）", ShrineBoard.spellCard(withSub(SubGrade("C1", SubGrades.WEEKDAY, 0.05, 0.56, promoted = true), "B")))
    }
}

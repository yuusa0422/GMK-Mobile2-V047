import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.Duration
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.58: weekday FX every minute, every clock hour >= 70% ENTRY (moving cut), 3 kept time-of-day rules, 47-input 5-minute model. */
class EveryMinuteV0758Test {
    @Before fun reset() = EvidencePolicy.resetState()
    private val jst = ZoneId.of("Asia/Tokyo")

    @Test fun everyMinuteEnsembleMatchesPythonExactly() {
        assertEquals(47, EvidenceModel5Data.FEATURE_COUNT)
        assertEquals(EvidenceModelData.FEATURES.size + 1, EvidenceEnsemble.fresh5.members.first().featureCount)
        assertEquals(5, EvidenceEnsemble.fresh5.members.size); assertEquals(5, EvidenceEnsemble.fallback5.members.size)
        val rows = GZIPInputStream(javaClass.classLoader!!.getResourceAsStream("v0758_model5_parity.txt.gz")!!).bufferedReader().readLines()
        assertEquals(600, rows.size)
        var worst = 0.0; var k0 = 0
        for (line in rows) {
            val (kind, p, csv) = line.split('|')
            val x = csv.split(',').map { it.toDouble() }.toDoubleArray()
            if (x.last() == 1.0) k0++
            val model = if (kind == "fresh") EvidenceEnsemble.fresh5 else EvidenceEnsemble.fallback5
            worst = maxOf(worst, Math.abs(model.probability(x) - p.toDouble()))
        }
        assertTrue("max diff $worst", worst < 1e-12)
        assertTrue("boundary and in-between minutes both in the parity rows: $k0", k0 in 20..580)
    }

    @Test fun hourRuleCutsAndRates() {
        // version constants are checked by the current version's test (SameDirectionV0759Test)
        assertEquals(RankStatistics.CURRENT_RANK_VERSIONS, setOf(RankStatistics.evidenceVersion(EvidencePolicy.POLICY_TAG)))
        assertEquals(9, RankLadder.hourQuota()); assertEquals(0.7, RankLadder.HOUR_SHARE, 0.0)
        for (f in listOf(true, false)) for (h in 9..22) {
            val q = if (f) EvidenceSlot9Data.FRESH_QUANTILES[h - 9] else EvidenceSlot9Data.FALLBACK_QUANTILES[h - 9]   // v0.7.71: nine-pair 5-minute slot tables
            assertEquals(EvidenceSlot9Data.QUANTILE_POINTS + 1, q.size)
            for (i in 1 until q.size) assertTrue(q[i] >= q[i - 1])
            assertEquals(q.last(), RankLadder.quantileCut(f, h, 0.0), 0.0); assertEquals(q.first(), RankLadder.quantileCut(f, h, 1.0), 0.0)
            assertTrue(RankLadder.baseShare(f, h) in 0.4..0.8)   // v0.7.66: share of the 5-minute slots (was of the minutes)
            // catch-up: 9 needed and 2 five-minute slots left (v0.7.66)
            val c = RankLadder.minuteCut(f, h, 51, 0); assertTrue(c.catchUp); assertEquals(Double.NEGATIVE_INFINITY, c.cut, 0.0)
            val full = RankLadder.minuteCut(f, h, 10, 9); assertTrue(full.full); assertEquals(Double.POSITIVE_INFINITY, full.cut, 0.0)
            // more entries still needed -> a lower cut; the same need later in the hour -> a lower cut
            val a = RankLadder.minuteCut(f, h, 10, 1); val b = RankLadder.minuteCut(f, h, 10, 6); val late = RankLadder.minuteCut(f, h, 40, 1)
            assertTrue(!a.catchUp && !a.full && b.cut >= a.cut && late.cut <= a.cut)   // fewer still needed -> stricter
            assertTrue(a.cut in 0.45..0.62)
        }
        assertEquals(setOf("FIX955_POS", "FIX955_BBZ", "US0830_F1"), EventRules.ACTIVE_IDS)
        val noon = ZonedDateTime.of(2026, 11, 4, 12, 20, 0, 0, jst); assertTrue(EventRules.rulesAt(noon).isEmpty())
        val fix = ZonedDateTime.of(2026, 11, 4, 9, 55, 0, 0, jst); assertEquals(setOf("FIX955_POS", "FIX955_BBZ"), EventRules.rulesAt(fix).map { it.id }.toSet())
        assertTrue(EventRules.rulesAt(fix.plusMinutes(1)).isEmpty())
        for (g in listOf("S", "A", "B")) assertTrue(g, EvidencePolicy.gradeRate(true, false, g)!! >= 0.55)
        assertEquals(0.5309, EvidencePolicy.gradeRate(true, false, "C")!!, 0.0); assertEquals(0.5089, EvidencePolicy.gradeRate(true, false, "D")!!, 0.0)   // v0.7.71 (nine pairs)
        assertEquals(3, RankLadder.judgeMinutes(false, "S")); assertEquals(5, RankLadder.judgeMinutes(false, "C")); assertEquals(3, RankLadder.judgeMinutes(true, "C"))
        assertTrue(EvidencePolicy.isBoundary(fix)); assertFalse(EvidencePolicy.isBoundary(fix.plusMinutes(1))); assertFalse(EvidencePolicy.isBoundary(fix.plusSeconds(10)))
        assertEquals("平日70%", EntryMode.WEEKDAY_60.label); assertEquals(EntryMode.WEEKDAY_60, EntryMode.DEFAULT)
    }

    private fun parse(note: String): Triple<Double, Double, String>? {
        val m = Regex(" FIVE=[A-Z]+ (?:HIGH|LOW) p5=([0-9.]+) cut=(\\S+) (fresh5|fallback5)").find(note) ?: return null
        return Triple(m.groupValues[1].toDouble(), m.groupValues[2].replace("∞", "Infinity").toDouble(), m.groupValues[3])
    }

    @Test fun boundarySlotsFollowTheHourRule() {
        val seen = HashMap<String, Int>()
        for (s in EvidenceFixture.slots) for (h in listOf(0, 4, 9)) {
            EvidencePolicy.resetState()
            val mode = EntryMode.WEEKDAY_60
            val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), mode, h)
            val top = out.top1!!; val note = top.reasons[1]; val label = top.assessment!!.correctionLabel!!
            val minutes = Duration.between(ZonedDateTime.parse(out.entryTimeJst), ZonedDateTime.parse(out.judgeTimeJst)).toMinutes().toInt()
            assertTrue(label, label.startsWith("【${minutes}分判定】"))
            assertFalse(note, " MINUTE" in note)
            if (s.weekend) { assertEquals(3, minutes); continue }
            assertNotEquals("weekday trades are FX only: $note", "BTCJPY", top.instrument)
            val rule = Regex(" RULE=([A-Z0-9_]+) ").find(note)?.groupValues?.get(1)
            if (rule != null) { assertTrue(note, rule in EventRules.ACTIVE_IDS); assertEquals(3, minutes); assertEquals("ENTRY", top.decision); continue }
            if (top.grade == "B") { assertTrue(note, " CONFIRMED" in note); assertEquals(5, minutes); assertEquals("ENTRY", top.decision); continue }
            if (" CAUTION" in note) { assertEquals("SKIP", top.decision); continue }
            assertEquals(5, minutes)
            val (p5, cut, _) = parse(note) ?: error(note)
            assertTrue(note, " H=$h " in note)
            val minute = ZonedDateTime.parse(out.entryTimeJst).withZoneSameInstant(jst).minute
            val expect = RankLadder.minuteCut(" fresh5" in note, top.let { ZonedDateTime.parse(out.entryTimeJst).withZoneSameInstant(jst).hour }, minute, h)
            assertEquals(note, expect.cut, cut, 1e-4)
            // v0.7.85: a skip is D..H by its place in the hour (OddsSkipV0785Test pins the band); it was always D
            if (h >= 9) { assertTrue(note, " FULL" in note); assertTrue(note, top.grade in SkipGrades.GRADES) }
            if (p5 >= cut - 1e-4) assertEquals(note, "C", top.grade) else assertTrue(note, top.grade in SkipGrades.GRADES)
            assertEquals(note, top.grade == "C", top.decision == "ENTRY")
            seen.merge("${if (top.grade in SkipGrades.GRADES) "D" else top.grade}|${top.decision}|$h", 1, Int::plus)
        }
        assertTrue(seen.toString(), (seen["C|ENTRY|0"] ?: 0) > 0 && (seen["D|SKIP|0"] ?: 0) > 0 && (seen["D|SKIP|9"] ?: 0) > 0)
    }

    @Test fun minutesBetweenBoundariesUseOnlyTheFiveMinuteModel() {
        var checked = 0
        for (s in EvidenceFixture.slots.filter { !it.weekend }) {
            EvidencePolicy.resetState()
            // the same market one minute later: every bar and quote shifted by +60 s, entry at minute 1 of the slot (not a boundary)
            val e = s.entry.plusMinutes(1)
            val n = s.native().copy(entryTimeJst = e.toOffsetDateTime().toString(), judgeTimeJst = e.plusMinutes(3).toOffsetDateTime().toString())
            val bars = s.candles().mapValues { (_, v) -> v.map { it.copy(timeEpochMs = it.timeEpochMs + 60_000L) } }
            val quotes = s.quotes().mapValues { (_, q) -> q.copy(epochMs = q.epochMs + 60_000L) }
            val out = EvidencePolicy.apply(n, n, bars, quotes, EntryMode.WEEKDAY_60, 3)
            val top = out.top1!!
            if (top.grade == "I") continue
            val note = top.reasons[1]
            assertTrue(note, " MINUTE" in note); assertFalse(note, " RULE=" in note); assertNotEquals(note, "B", top.grade)
            assertEquals(5L, Duration.between(ZonedDateTime.parse(out.entryTimeJst), ZonedDateTime.parse(out.judgeTimeJst)).toMinutes())
            if (" CAUTION" in note) continue
            val (p5, cut, _) = parse(note) ?: error(note)
            if (p5 >= cut - 1e-4) assertEquals(note, "C", top.grade) else assertTrue(note, top.grade in SkipGrades.GRADES)   // v0.7.85: D..H
            assertEquals(0, EvidencePolicy.bufferSize(true, false) + EvidencePolicy.bufferSize(false, false))   // not recorded between boundaries
            checked++
        }
        assertTrue("checked $checked", checked >= 12)
    }

    @Test fun hourShareCountsBoundarySlotsAndAllEntries() {
        val tag = EvidencePolicy.POLICY_TAG
        fun row(id: String, t: String, decision: String) = HistoryRow(id.hashCode().toLong(), id, "AUTO", t, "USDJPY", "HIGH", if (decision == "ENTRY") "C" else "D",
            decision, entryTimeJst = t, judgeTimeJst = ZonedDateTime.parse(t).plusMinutes(5).toString(), entryRate = 150.0, policyVersion = tag)
        val rows = listOf(row("a", "2026-11-02T10:00:00+09:00", "ENTRY"), row("b", "2026-11-02T10:01:00+09:00", "ENTRY"),
            row("c", "2026-11-02T10:05:00+09:00", "SKIP"), row("d", "2026-11-02T10:07:00+09:00", "ENTRY"))
        val m = RankStatistics.entryShareByHour(rows).getValue("平日").getValue(10)
        assertEquals(2, m.first); assertEquals(3, m.second)
    }
}

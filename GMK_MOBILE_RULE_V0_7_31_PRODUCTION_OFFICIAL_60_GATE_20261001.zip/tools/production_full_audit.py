from pathlib import Path
import csv, hashlib, re, sys, xml.etree.ElementTree as ET
import yaml

root = Path(__file__).resolve().parents[1]
app = root / 'app/src/main'
fail=[]
def check(name, cond, detail=''):
    if not cond: fail.append(f'{name}: {detail}')

# Metadata / production separation
gradle=(root/'app/build.gradle.kts').read_text(encoding='utf-8')
check('version', 'versionCode = 101' in gradle and 'versionName = "0.7.31-production-official-win-gate"' in gradle)
check('production_name', 'research' not in re.search(r'versionName\s*=\s*"([^"]+)"', gradle).group(1).lower())
check('research_kotlin_absent', not any(p.name == 'ResearchRuleIdPolicy.kt' for p in root.rglob('*.kt')))

# Android security / manifest parse
manifest=app/'AndroidManifest.xml'; ET.parse(manifest)
mt=manifest.read_text(encoding='utf-8')
check('backup_disabled', 'android:allowBackup="false"' in mt)
check('cleartext_disabled_manifest', 'android:usesCleartextTraffic="false"' in mt)
ns=app/'res/xml/network_security_config.xml'; ET.parse(ns)
check('cleartext_disabled_config', 'cleartextTrafficPermitted="false"' in ns.read_text(encoding='utf-8'))

# Gate isolation / fail closed / only demotion
gate=(app/'java/jp/gmk/mobile/domain/OfficialWinGate.kt').read_text(encoding='utf-8')
engine=(app/'java/jp/gmk/mobile/domain/LocalRuleEngine.kt').read_text(encoding='utf-8')
one=(app/'java/jp/gmk/mobile/domain/OneMinuteLocalEngine.kt').read_text(encoding='utf-8')
check('gate_version', 'V0731_PRODUCTION_OFFICIAL_DRAW_AS_LOSS_GATE_JAN_JUN' in gate)
check('gate_threshold', 'THRESHOLD = 0.530' in gate)
check('gate_fail_closed', 'if (!isSupported(f)) return Result(0.0, false)' in gate)
check('gate_no_network_ai', not re.search(r'^\s*import\s+.*(okhttp|retrofit|socket|ollama)', gate, re.I|re.M) and 'toHttpUrl' not in gate and 'Request.Builder' not in gate)
check('gate_top1_only', 'idx == 0 && isEntryGrade(p.rank)' in engine)
check('gate_only_demotes', 'val finalGrade = if (officialGate != null && !officialGate.allowEntry) "E" else p.rank' in engine)
check('gate_no_1m', 'OfficialWinGate' not in one)
check('ohlc_3m_defense', all(x in engine for x in ['c.open.isFinite()', 'c.timeEpochMs > 0L', 'c.high >= max(c.open, c.close)', 'distinctBy { it.timeEpochMs }']))
check('ohlc_1m_defense', all(x in one for x in ['c.open.isFinite()', 'c.timeEpochMs > 0L', 'c.high >= max(c.open, c.close)', 'distinctBy { it.timeEpochMs }']))

# OOS contract. Entry rate denominator is all eligible frames; official WR denominator is graded ENTRY.
summary=list(csv.DictReader((root/'OFFICIAL_WIN_GATE_V0730_SUMMARY.csv').open(encoding='utf-8')))
oos=next(r for r in summary if r['segment']=='V0730_OOS_JUL_AUG18')
check('oos_entry_rate', float(oos['entry_rate']) >= 0.70, oos['entry_rate'])
check('oos_official_wr', float(oos['official_win_rate']) >= 0.60, oos['official_win_rate'])
check('oos_counts', (int(oos['eligible_frames']),int(oos['entries']),int(oos['graded_entries']),int(oos['wins']))==(5880,4144,4136,2491), str(oos))
rows=list(csv.DictReader((root/'OFFICIAL_WIN_GATE_OOS_202607_0818.csv').open(encoding='utf-8')))
entries=[r for r in rows if r['gate_entry'].lower()=='true']
wins=sum(r['outcls']=='WIN' for r in entries)
check('oos_scored_rows', len(rows)==5871, len(rows))
check('oos_scored_entry_count', len(entries)==4136, len(entries))
check('oos_scored_wins', wins==2491, wins)
check('oos_scored_wr', wins/len(entries) >= 0.60, wins/len(entries))
check('draw_present_and_counted_loss', any(r['outcls']=='DRAW' for r in entries))

# Existing live safety contracts
vm=(app/'java/jp/gmk/mobile/ui/GmkViewModel.kt').read_text(encoding='utf-8')
hist=(app/'java/jp/gmk/mobile/data/HistoryStore.kt').read_text(encoding='utf-8')
repo=(app/'java/jp/gmk/mobile/data/MarketRepository.kt').read_text(encoding='utf-8')
check('six_of_six_gate', 'スキャン見送り: 6/6必須' in vm)
check('draw_is_loss', 'DRAW is directional LOSE by specification' in hist and 'resultStatus = if (win) "WIN" else "LOSE"' in hist)
check('freshness_gate', 'freshnessStatus == "LIVE"' in vm and 'latestLagMs > 5_000L' in vm and 'fetchAgeSeconds' in vm)
check('network_timeouts', all(x in repo for x in ['connectTimeout(3', 'readTimeout(4', 'callTimeout(4']))
check('network_cancellable', 'suspendCancellableCoroutine' in repo and 'invokeOnCancellation { call.cancel() }' in repo)
check('fatal_errors_not_swallowed', not any('catch (t: Throwable)' in p.read_text(encoding='utf-8') or 'catch (_: Throwable)' in p.read_text(encoding='utf-8') for p in (app/'java').rglob('*.kt')))
drawable_refs=set()
for source in (app/'java').rglob('*.kt'):
    drawable_refs.update(re.findall(r'(?<!android\.)R\.drawable\.([A-Za-z0-9_]+)', source.read_text(encoding='utf-8')))
drawable_files={p.stem for p in (app/'res/drawable-nodpi').glob('*')}
check('drawable_references_exist', drawable_refs <= drawable_files, ','.join(sorted(drawable_refs-drawable_files)))

# Workflow safety and production default
workflow=(root/'.github/workflows/build.yml').read_text(encoding='utf-8')
yaml.safe_load(workflow)
check('workflow_default_prod', 'default: production' in workflow)
check('workflow_research_reject', 'research versionName cannot be packaged as production' in workflow)
check('workflow_safe_extract', all(x in workflow for x in ['Unsafe ZIP path', 'Duplicate ZIP target', 'Symlink entry is not allowed']))
check('workflow_compile_assemble', ':app:compileDebugKotlin' in workflow and ':app:assembleDebug' in workflow)
check('workflow_contract', 'functional_contract_test.py' in workflow)

# Secrets: reject obvious committed credentials (not variable names/placeholders).
secret_hits=[]
patterns=[re.compile(r'AIza[0-9A-Za-z_-]{30,}'),re.compile(r'ghp_[A-Za-z0-9]{20,}'),re.compile(r'(?i)(api[_-]?key|token|secret|password)\s*[=:]\s*["\'][^"\']{8,}["\']')]
for p in root.rglob('*'):
    if not p.is_file() or p.suffix.lower() in {'.webp','.png','.jpg','.jpeg','.zip','.jar','.apk'}: continue
    try: text=p.read_text(encoding='utf-8')
    except Exception: continue
    for pat in patterns:
        if pat.search(text): secret_hits.append(str(p)); break
check('no_committed_secrets', not secret_hits, ','.join(secret_hits[:5]))

if fail:
    print('FAIL', len(fail))
    for x in fail: print(' -',x)
    sys.exit(1)
print('PASS production full audit checks=38')

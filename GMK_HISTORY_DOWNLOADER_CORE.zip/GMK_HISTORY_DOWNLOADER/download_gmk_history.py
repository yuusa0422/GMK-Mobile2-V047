from __future__ import annotations

import json
import sys
import time
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd
import requests

ROOT = Path(__file__).resolve().parent
CFG_PATH = ROOT / "config.json"
OUT = ROOT / "output"

FX_ENDPOINT = "https://forex-api.coin.z.com/public/v1/klines"
CRYPTO_ENDPOINT = "https://api.coin.z.com/public/v1/klines"


def load_config() -> dict:
    with CFG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def daterange(start: str, end: str):
    d = date.fromisoformat(start)
    e = date.fromisoformat(end)
    while d <= e:
        yield d
        d += timedelta(days=1)


def request_json(url: str, params: dict, retries: int, timeout: int) -> dict:
    last_err = None
    for n in range(retries):
        try:
            r = requests.get(url, params=params, timeout=timeout)
            r.raise_for_status()
            payload = r.json()
            if str(payload.get("status")) != "0":
                msgs = payload.get("messages") or []
                raise RuntimeError(f"API status={payload.get('status')} messages={msgs}")
            return payload
        except Exception as exc:
            last_err = exc
            if n + 1 < retries:
                time.sleep(2 * (n + 1))
    raise RuntimeError(f"request failed: {last_err}")


def rows_to_df(rows: list[dict], tz_name: str, include_volume: bool) -> pd.DataFrame:
    columns = ["open", "high", "low", "close"] + (["volume"] if include_volume else [])
    if not rows:
        return pd.DataFrame(columns=columns, index=pd.DatetimeIndex([], name="datetime_jst", tz=tz_name))

    df = pd.DataFrame(rows)
    if "openTime" not in df.columns:
        raise RuntimeError("API response has no openTime")

    # pd.to_datetime(Series, ...) returns a Series on recent pandas versions.
    # Convert explicitly to DatetimeIndex before timezone conversion.
    raw_ts = pd.to_numeric(df["openTime"], errors="coerce")
    valid = raw_ts.notna()
    if not valid.all():
        df = df.loc[valid].copy()
        raw_ts = raw_ts.loc[valid]
    if df.empty:
        return pd.DataFrame(columns=columns, index=pd.DatetimeIndex([], name="datetime_jst", tz=tz_name))

    idx = pd.DatetimeIndex(pd.to_datetime(raw_ts.to_numpy(), unit="ms", utc=True))
    df.index = idx.tz_convert(tz_name)
    df.index.name = "datetime_jst"

    for c in ["open", "high", "low", "close", "volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    keep = [c for c in columns if c in df.columns]
    df = df[keep].sort_index()
    df = df[~df.index.duplicated(keep="last")]
    return df


def fetch_fx_day(api_symbol: str, d: date, cfg: dict) -> pd.DataFrame:
    params = {
        "symbol": api_symbol,
        "priceType": cfg.get("fx_price_type", "BID"),
        "interval": "1min",
        "date": d.strftime("%Y%m%d"),
    }
    payload = request_json(
        FX_ENDPOINT,
        params,
        retries=int(cfg.get("request_retries", 4)),
        timeout=int(cfg.get("request_timeout_seconds", 30)),
    )
    return rows_to_df(payload.get("data") or [], cfg["timezone"], include_volume=False)


def fetch_crypto_day(api_symbol: str, d: date, cfg: dict) -> pd.DataFrame:
    params = {
        "symbol": api_symbol,
        "interval": "1min",
        "date": d.strftime("%Y%m%d"),
    }
    payload = request_json(
        CRYPTO_ENDPOINT,
        params,
        retries=int(cfg.get("request_retries", 4)),
        timeout=int(cfg.get("request_timeout_seconds", 30)),
    )
    return rows_to_df(payload.get("data") or [], cfg["timezone"], include_volume=bool(cfg.get("include_volume", True)))


def filter_exact_date_and_session(df: pd.DataFrame, d: date, start_hour: str, end_hour: str) -> pd.DataFrame:
    if df.empty:
        return df
    df = df[df.index.date == d]
    sh, sm = map(int, start_hour.split(":"))
    eh, em = map(int, end_hour.split(":"))
    minute = df.index.hour * 60 + df.index.minute
    lo = sh * 60 + sm
    hi = eh * 60 + em
    return df[(minute >= lo) & (minute <= hi)]


def add_symbol(df: pd.DataFrame, symbol: str) -> pd.DataFrame:
    out = df.copy()
    out.insert(0, "symbol", symbol)
    return out


def resample_ohlc(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    if interval == "1m":
        return df.copy()
    if interval not in {"3m", "5m"}:
        raise ValueError(f"unsupported interval: {interval}")

    agg = {"open": "first", "high": "max", "low": "min", "close": "last"}
    if "volume" in df.columns:
        agg["volume"] = "sum"

    symbol = str(df["symbol"].iloc[0]) if (not df.empty and "symbol" in df.columns) else ""
    base = df.drop(columns=["symbol"], errors="ignore")

    # Resample per JST calendar day. This prevents a 3m/5m candle from crossing a date boundary.
    pieces = []
    for _, day_df in base.groupby(base.index.date):
        r = day_df.resample(interval, origin="start_day", label="left", closed="left").agg(agg)
        r = r.dropna(subset=["open", "high", "low", "close"])
        pieces.append(r)
    out = pd.concat(pieces).sort_index() if pieces else base.iloc[0:0].copy()
    if symbol:
        out.insert(0, "symbol", symbol)
    return out


def save_csv(df: pd.DataFrame, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = df.reset_index()
    tmp["datetime_jst"] = tmp["datetime_jst"].dt.strftime("%Y-%m-%d %H:%M:%S%z")
    tmp.to_csv(path, index=False, encoding="utf-8-sig")


def basic_validate(df: pd.DataFrame, symbol: str, interval: str, cfg: dict, weekend_only: bool) -> list[str]:
    errs = []
    if df.empty:
        return [f"{symbol}/{interval}: no rows"]
    if df.index.has_duplicates:
        errs.append(f"{symbol}/{interval}: duplicate timestamps")
    if df[["open", "high", "low", "close"]].isna().any().any():
        errs.append(f"{symbol}/{interval}: OHLC NaN")
    bad_ohlc = (df["high"] < df[["open", "close", "low"]].max(axis=1)) | (df["low"] > df[["open", "close", "high"]].min(axis=1))
    if bad_ohlc.any():
        errs.append(f"{symbol}/{interval}: OHLC inconsistency rows={int(bad_ohlc.sum())}")
    dow = df.index.dayofweek
    if weekend_only and (dow < 5).any():
        errs.append(f"{symbol}/{interval}: weekday rows found in weekend-only data")
    if not weekend_only and (dow >= 5).any():
        errs.append(f"{symbol}/{interval}: weekend rows found in FX data")
    sh, sm = map(int, cfg["start_hour"].split(":"))
    eh, em = map(int, cfg["end_hour"].split(":"))
    m = df.index.hour * 60 + df.index.minute
    if ((m < sh * 60 + sm) | (m > eh * 60 + em)).any():
        errs.append(f"{symbol}/{interval}: out-of-session rows found")
    return errs


def main():
    cfg = load_config()
    if OUT.exists():
        import shutil
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True, exist_ok=True)

    frames_by_tf: dict[str, dict[str, pd.DataFrame]] = {tf: {} for tf in cfg["output_intervals"]}
    failures: list[str] = []
    validations: list[str] = []

    print(f"GMK history: {cfg['start_date']} -> {cfg['end_date']} / {cfg['start_hour']}-{cfg['end_hour']} JST")
    print("Source: GMO Coin public APIs / 1-minute candles; outputs: 1m, 3m, 5m")

    # FX: weekdays only
    for symbol, api_symbol in cfg["weekday_symbols"].items():
        print(f"[FX] {symbol} ({api_symbol})")
        days = []
        for d in daterange(cfg["start_date"], cfg["end_date"]):
            if d.weekday() >= 5:
                continue
            try:
                day = fetch_fx_day(api_symbol, d, cfg)
                day = filter_exact_date_and_session(day, d, cfg["start_hour"], cfg["end_hour"])
                if not day.empty:
                    days.append(day)
                else:
                    print(f"  WARN no rows {d}")
            except Exception as exc:
                failures.append(f"{symbol} {d}: {exc}")
                print(f"  ERROR {d}: {exc}", file=sys.stderr)
            time.sleep(0.05)

        if not days:
            failures.append(f"{symbol}: no data for entire requested range")
            continue

        m1 = add_symbol(pd.concat(days).sort_index(), symbol)
        m1 = m1[~m1.index.duplicated(keep="last")]
        for tf in cfg["output_intervals"]:
            out = resample_ohlc(m1, tf)
            frames_by_tf[tf][symbol] = out
            save_csv(out, OUT / tf.upper() / f"{symbol}_{tf}_JST.csv")
            validations.extend(basic_validate(out, symbol, tf, cfg, weekend_only=False))
            print(f"  {tf}: rows={len(out)}")

    # BTCJPY: weekends only, price is JPY because GMO Coin BTC market is JPY-denominated.
    for symbol, api_symbol in cfg.get("weekend_symbol", {}).items():
        print(f"[WEEKEND] {symbol} ({api_symbol})")
        days = []
        for d in daterange(cfg["start_date"], cfg["end_date"]):
            if d.weekday() < 5:
                continue
            try:
                day = fetch_crypto_day(api_symbol, d, cfg)
                day = filter_exact_date_and_session(day, d, cfg["start_hour"], cfg["end_hour"])
                if not day.empty:
                    days.append(day)
                else:
                    print(f"  WARN no rows {d}")
            except Exception as exc:
                failures.append(f"{symbol} {d}: {exc}")
                print(f"  ERROR {d}: {exc}", file=sys.stderr)
            time.sleep(0.05)

        if not days:
            failures.append(f"{symbol}: no data for entire requested range")
            continue

        m1 = add_symbol(pd.concat(days).sort_index(), symbol)
        m1 = m1[~m1.index.duplicated(keep="last")]
        for tf in cfg["output_intervals"]:
            out = resample_ohlc(m1, tf)
            frames_by_tf[tf][symbol] = out
            save_csv(out, OUT / tf.upper() / f"{symbol}_{tf}_JST_WEEKEND.csv")
            validations.extend(basic_validate(out, symbol, tf, cfg, weekend_only=True))
            print(f"  {tf}: rows={len(out)}")

    # Combined CSV and manifest for each timeframe
    manifest_rows = []
    for tf, symbol_map in frames_by_tf.items():
        nonempty = [df for df in symbol_map.values() if not df.empty]
        if nonempty:
            combined = pd.concat(nonempty).sort_index()
            save_csv(combined, OUT / f"GMK_ALL_{tf}_20260901_20261006_JST.csv")
        for symbol, df in symbol_map.items():
            manifest_rows.append({
                "timeframe": tf,
                "symbol": symbol,
                "rows": len(df),
                "first_jst": "" if df.empty else df.index.min().isoformat(),
                "last_jst": "" if df.empty else df.index.max().isoformat(),
                "days": 0 if df.empty else df.index.normalize().nunique(),
            })

    pd.DataFrame(manifest_rows).to_csv(OUT / "manifest.csv", index=False, encoding="utf-8-sig")
    with (OUT / "run_config.json").open("w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    with (OUT / "SOURCE.txt").open("w", encoding="utf-8") as f:
        f.write("FX: GMO Coin Forex public API /public/v1/klines, BID, 1min\n")
        f.write("BTCJPY: GMO Coin Crypto public API /public/v1/klines, BTC, 1min (JPY-denominated market)\n")
        f.write("3m and 5m are resampled from the downloaded 1m data in JST.\n")

    if validations:
        with (OUT / "validation_errors.txt").open("w", encoding="utf-8") as f:
            f.write("\n".join(validations) + "\n")
    else:
        with (OUT / "validation_OK.txt").open("w", encoding="utf-8") as f:
            f.write("Basic validation passed: no duplicate timestamps, no OHLC NaN/inconsistency, session/day-of-week constraints passed.\n")

    if failures:
        with (OUT / "failures.txt").open("w", encoding="utf-8") as f:
            f.write("\n".join(failures) + "\n")

    zip_path = ROOT / "GMK_HISTORY_20260901_20261006.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in OUT.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(ROOT))

    print(f"DONE: {zip_path}")
    if failures or validations:
        print(f"FAILED CHECKS: download_failures={len(failures)} validation_errors={len(validations)}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()

from __future__ import annotations

import json
import sys
import time
import zipfile
from pathlib import Path
from datetime import timedelta

import pandas as pd
import yfinance as yf

ROOT = Path(__file__).resolve().parent
CFG_PATH = ROOT / "config.json"
OUT = ROOT / "output"
RAW = OUT / "csv"


def load_config():
    with CFG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
    rename = {c: c.lower() for c in df.columns}
    df = df.rename(columns=rename)
    wanted = [c for c in ["open", "high", "low", "close", "volume"] if c in df.columns]
    return df[wanted]


def download_symbol(ticker: str, start: str, end: str, interval: str, tries: int = 4) -> pd.DataFrame:
    # yfinance end is exclusive; add one day so end_date is included.
    end_exclusive = (pd.Timestamp(end) + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
    last_err = None
    for n in range(tries):
        try:
            df = yf.download(
                ticker,
                start=start,
                end=end_exclusive,
                interval=interval,
                auto_adjust=False,
                repair=True,
                progress=False,
                prepost=False,
                threads=False,
            )
            if df is not None and not df.empty:
                return normalize_columns(df)
        except Exception as e:
            last_err = e
        time.sleep(2 * (n + 1))
    if last_err:
        raise RuntimeError(f"download failed for {ticker}: {last_err}")
    raise RuntimeError(f"download returned no rows for {ticker}")


def to_jst(df: pd.DataFrame, tz_name: str) -> pd.DataFrame:
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is None:
        # Yahoo intraday data normally has TZ. UTC is safest fallback for missing metadata.
        idx = idx.tz_localize("UTC")
    idx = idx.tz_convert(tz_name)
    df = df.copy()
    df.index = idx
    df.index.name = "datetime_jst"
    return df


def filter_session(df: pd.DataFrame, start_hour: str, end_hour: str, weekday_only: bool) -> pd.DataFrame:
    if weekday_only:
        df = df[df.index.dayofweek < 5]
    else:
        df = df[df.index.dayofweek >= 5]

    sh, sm = map(int, start_hour.split(":"))
    eh, em = map(int, end_hour.split(":"))
    minute_of_day = df.index.hour * 60 + df.index.minute
    lo = sh * 60 + sm
    hi = eh * 60 + em
    return df[(minute_of_day >= lo) & (minute_of_day <= hi)]


def add_symbol_col(df: pd.DataFrame, symbol: str) -> pd.DataFrame:
    out = df.copy()
    out.insert(0, "symbol", symbol)
    return out


def save_csv(df: pd.DataFrame, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = df.reset_index()
    tmp["datetime_jst"] = tmp["datetime_jst"].dt.strftime("%Y-%m-%d %H:%M:%S%z")
    tmp.to_csv(path, index=False, encoding="utf-8-sig")


def make_manifest(all_frames: dict[str, pd.DataFrame], cfg: dict):
    rows = []
    for symbol, df in all_frames.items():
        rows.append({
            "symbol": symbol,
            "rows": len(df),
            "first_jst": "" if df.empty else df.index.min().isoformat(),
            "last_jst": "" if df.empty else df.index.max().isoformat(),
            "days": 0 if df.empty else df.index.normalize().nunique(),
        })
    m = pd.DataFrame(rows)
    m.to_csv(OUT / "manifest.csv", index=False, encoding="utf-8-sig")

    with (OUT / "run_config.json").open("w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def main():
    cfg = load_config()
    OUT.mkdir(exist_ok=True)
    RAW.mkdir(exist_ok=True)

    all_frames: dict[str, pd.DataFrame] = {}
    failures = []

    print(f"GMK history: {cfg['start_date']} -> {cfg['end_date']} / {cfg['start_hour']}-{cfg['end_hour']} JST")

    # Weekdays: six FX pairs
    for symbol, ticker in cfg["weekday_symbols"].items():
        print(f"[FX] {symbol} ({ticker})")
        try:
            df = download_symbol(ticker, cfg["start_date"], cfg["end_date"], cfg["download_interval"])
            df = to_jst(df, cfg["timezone"])
            df = filter_session(df, cfg["start_hour"], cfg["end_hour"], weekday_only=True)
            if not cfg.get("include_volume", True) and "volume" in df.columns:
                df = df.drop(columns=["volume"])
            df = add_symbol_col(df, symbol)
            all_frames[symbol] = df
            save_csv(df, RAW / f"{symbol}_{cfg['download_interval']}_JST.csv")
            print(f"  rows={len(df)}")
        except Exception as e:
            failures.append((symbol, str(e)))
            print(f"  ERROR: {e}", file=sys.stderr)

    # Weekends: crypto only
    for symbol, ticker in cfg.get("weekend_symbol", {}).items():
        print(f"[WEEKEND] {symbol} ({ticker})")
        try:
            df = download_symbol(ticker, cfg["start_date"], cfg["end_date"], cfg["download_interval"])
            df = to_jst(df, cfg["timezone"])
            df = filter_session(df, cfg["start_hour"], cfg["end_hour"], weekday_only=False)
            if not cfg.get("include_volume", True) and "volume" in df.columns:
                df = df.drop(columns=["volume"])
            df = add_symbol_col(df, symbol)
            all_frames[symbol] = df
            save_csv(df, RAW / f"{symbol}_{cfg['download_interval']}_JST_WEEKEND.csv")
            print(f"  rows={len(df)}")
        except Exception as e:
            failures.append((symbol, str(e)))
            print(f"  ERROR: {e}", file=sys.stderr)

    make_manifest(all_frames, cfg)

    # Combined CSV sorted by JST datetime.
    nonempty = [df for df in all_frames.values() if not df.empty]
    if nonempty:
        combined = pd.concat(nonempty).sort_index()
        save_csv(combined, OUT / "GMK_ALL_20260901_20261006_JST.csv")

    if failures:
        with (OUT / "failures.txt").open("w", encoding="utf-8") as f:
            for symbol, err in failures:
                f.write(f"{symbol}: {err}\n")

    zip_path = ROOT / "GMK_HISTORY_20260901_20261006.zip"
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in OUT.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(ROOT))

    print(f"DONE: {zip_path}")
    if failures:
        print("Some symbols failed. See output/failures.txt", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()

from __future__ import annotations

import json
import sys
import io
import time
import zipfile
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pandas as pd
import requests

ROOT = Path(__file__).resolve().parent
CFG_PATH = ROOT / "config.json"
OUT = ROOT / "output"

FX_ENDPOINT = "https://forex-api.coin.z.com/public/v1/klines"
GMO_CRYPTO_ENDPOINT = "https://api.coin.z.com/public/v1/klines"
GMO_HIST_TRADES_URL = "https://api.coin.z.com/data/trades/{symbol}/{year}/{month}/{yyyymmdd}_{symbol}.csv.gz"


def load_config() -> dict:
    with CFG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def daterange(start: str, end: str):
    d = date.fromisoformat(start)
    e = date.fromisoformat(end)
    while d <= e:
        yield d
        d += timedelta(days=1)


def request_json(url: str, params: dict, retries: int, timeout: int) -> dict:
    last_err = None
    headers = {"User-Agent": "GMK-History-Downloader/4.0"}
    for n in range(retries):
        try:
            r = requests.get(url, params=params, headers=headers, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            last_err = exc
            if n + 1 < retries:
                time.sleep(2 * (n + 1))
    raise RuntimeError(f"request failed: {last_err}")


def gmo_request_json(url: str, params: dict, retries: int, timeout: int) -> dict:
    payload = request_json(url, params, retries, timeout)
    if str(payload.get("status")) != "0":
        msgs = payload.get("messages") or []
        raise RuntimeError(f"GMO API status={payload.get('status')} messages={msgs}")
    return payload


def rows_to_df(rows: list[dict], tz_name: str, include_volume: bool) -> pd.DataFrame:
    columns = ["open", "high", "low", "close"] + (["volume"] if include_volume else [])
    if not rows:
        return pd.DataFrame(columns=columns, index=pd.DatetimeIndex([], name="datetime_jst", tz=tz_name))

    df = pd.DataFrame(rows)
    if "openTime" not in df.columns:
        raise RuntimeError("API response has no openTime")

    raw_ts = pd.to_numeric(df["openTime"], errors="coerce")
    valid = raw_ts.notna()
    df = df.loc[valid].copy()
    raw_ts = raw_ts.loc[valid]
    if df.empty:
        return pd.DataFrame(columns=columns, index=pd.DatetimeIndex([], name="datetime_jst", tz=tz_name))

    idx = pd.DatetimeIndex(pd.to_datetime(raw_ts.to_numpy(), unit="ms", utc=True))
    df.index = idx.tz_convert(tz_name)
    df.index.name = "datetime_jst"

    for c in ["open", "high", "low", "close", "volume"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    keep = [c for c in columns if c in df.columns]
    df = df[keep].sort_index()
    return df[~df.index.duplicated(keep="last")]


def _find_col(df: pd.DataFrame, names: list[str]) -> str:
    by_lower = {str(c).strip().lower(): c for c in df.columns}
    for n in names:
        if n.lower() in by_lower:
            return by_lower[n.lower()]
    raise RuntimeError(f"CSV missing required column; wanted one of {names}, got {list(df.columns)}")


def fetch_gmo_historical_trades_day(api_symbol: str, d: date, cfg: dict) -> pd.DataFrame:
    """Download GMO Coin official daily historical trade CSV and aggregate to 1-minute OHLCV.

    Uses only real executions. No synthetic candles are created here.
    """
    ymd = d.strftime("%Y%m%d")
    url = GMO_HIST_TRADES_URL.format(
        symbol=api_symbol, year=d.strftime("%Y"), month=d.strftime("%m"), yyyymmdd=ymd
    )
    last = None
    headers = {"User-Agent": "GMK-History-Downloader/5.0"}
    for n in range(int(cfg.get("request_retries", 4))):
        try:
            r = requests.get(url, headers=headers, timeout=int(cfg.get("request_timeout_seconds", 30)))
            r.raise_for_status()
            raw = pd.read_csv(io.BytesIO(r.content), compression="gzip")
            if raw.empty:
                return pd.DataFrame(columns=["open","high","low","close","volume"], index=pd.DatetimeIndex([], name="datetime_jst", tz=cfg["timezone"]))

            ts_col = _find_col(raw, ["timestamp", "time", "datetime", "executed_at", "execution_time"])
            px_col = _find_col(raw, ["price", "execution_price"])
            try:
                sz_col = _find_col(raw, ["size", "volume", "amount", "quantity"])
            except Exception:
                sz_col = None

            idx = pd.to_datetime(raw[ts_col], utc=True, errors="coerce")
            valid = idx.notna()
            raw = raw.loc[valid].copy()
            idx = pd.DatetimeIndex(idx[valid]).tz_convert(cfg["timezone"])
            raw.index = idx
            raw.index.name = "datetime_jst"
            raw["_price"] = pd.to_numeric(raw[px_col], errors="coerce")
            raw["_size"] = pd.to_numeric(raw[sz_col], errors="coerce") if sz_col else 0.0
            raw = raw.dropna(subset=["_price"]).sort_index()
            if raw.empty:
                return pd.DataFrame(columns=["open","high","low","close","volume"], index=pd.DatetimeIndex([], name="datetime_jst", tz=cfg["timezone"]))

            g = raw.groupby(raw.index.floor("1min"))
            out = pd.DataFrame({
                "open": g["_price"].first(),
                "high": g["_price"].max(),
                "low": g["_price"].min(),
                "close": g["_price"].last(),
                "volume": g["_size"].sum(),
            }).sort_index()
            out.index.name = "datetime_jst"
            return out
        except Exception as exc:
            last = exc
            if n + 1 < int(cfg.get("request_retries", 4)):
                time.sleep(2 * (n + 1))
    raise RuntimeError(f"historical trade CSV failed: {last} url={url}")


def fetch_fx_day(api_symbol: str, d: date, cfg: dict) -> pd.DataFrame:
    params = {
        "symbol": api_symbol,
        "priceType": cfg.get("fx_price_type", "BID"),
        "interval": "1min",
        "date": d.strftime("%Y%m%d"),
    }
    payload = gmo_request_json(
        FX_ENDPOINT, params,
        retries=int(cfg.get("request_retries", 4)),
        timeout=int(cfg.get("request_timeout_seconds", 30)),
    )
    return rows_to_df(payload.get("data") or [], cfg["timezone"], include_volume=False)


def fetch_gmo_crypto_day(api_symbol: str, d: date, cfg: dict) -> pd.DataFrame:
    params = {"symbol": api_symbol, "interval": "1min", "date": d.strftime("%Y%m%d")}
    payload = gmo_request_json(
        GMO_CRYPTO_ENDPOINT, params,
        retries=int(cfg.get("request_retries", 4)),
        timeout=int(cfg.get("request_timeout_seconds", 30)),
    )
    return rows_to_df(payload.get("data") or [], cfg["timezone"], include_volume=True)


def session_bounds_jst(d: date, cfg: dict):
    sh, sm = map(int, cfg["start_hour"].split(":"))
    eh, em = map(int, cfg["end_hour"].split(":"))
    tz = cfg["timezone"]
    start = pd.Timestamp(datetime(d.year, d.month, d.day, sh, sm), tz=tz)
    # Include the candle starting exactly at end_hour, so query through the next minute.
    end_exclusive = pd.Timestamp(datetime(d.year, d.month, d.day, eh, em), tz=tz) + pd.Timedelta(minutes=1)
    return start, end_exclusive


def filter_exact_date_and_session(df: pd.DataFrame, d: date, start_hour: str, end_hour: str) -> pd.DataFrame:
    if df.empty:
        return df
    df = df[df.index.date == d]
    sh, sm = map(int, start_hour.split(":"))
    eh, em = map(int, end_hour.split(":"))
    minute = df.index.hour * 60 + df.index.minute
    lo = sh * 60 + sm
    hi = eh * 60 + em
    return df[(minute >= lo) & (minute <= hi)]


def expected_minute_index(d: date, cfg: dict) -> pd.DatetimeIndex:
    start, end_exclusive = session_bounds_jst(d, cfg)
    return pd.date_range(start, end_exclusive - pd.Timedelta(minutes=1), freq="1min", name="datetime_jst")


def missing_minutes(df: pd.DataFrame, d: date, cfg: dict) -> pd.DatetimeIndex:
    expected = expected_minute_index(d, cfg)
    actual = pd.DatetimeIndex(df.index)
    return expected.difference(actual)


def fetch_complete_btc_day(api_symbol: str, d: date, cfg: dict):
    """Get BTCJPY from GMO official historical executions, then fill only real KLine minutes.

    Primary: GMO Coin official daily historical trade CSV aggregated to 1-minute OHLCV.
    Secondary: GMO Coin public KLine 1-minute candles, used only for timestamps absent from trade aggregation.
    No forward fill/interpolation/synthetic candles.
    """
    sources = []
    hist = pd.DataFrame()
    try:
        hist = fetch_gmo_historical_trades_day(api_symbol, d, cfg)
        hist = filter_exact_date_and_session(hist, d, cfg["start_hour"], cfg["end_hour"])
        if not hist.empty:
            sources.append("GMO-HIST-TRADES")
    except Exception as exc:
        print(f"  WARN GMO historical {d}: {exc}", file=sys.stderr)

    kline = pd.DataFrame()
    try:
        kline = fetch_gmo_crypto_day(api_symbol, d, cfg)
        kline = filter_exact_date_and_session(kline, d, cfg["start_hour"], cfg["end_hour"])
        if not kline.empty:
            sources.append("GMO-KLINE")
    except Exception as exc:
        print(f"  WARN GMO KLine {d}: {exc}", file=sys.stderr)

    if hist.empty and kline.empty:
        return pd.DataFrame(), [], []
    if hist.empty:
        merged = kline.copy()
    elif kline.empty:
        merged = hist.copy()
    else:
        merged = pd.concat([hist, kline[~kline.index.isin(hist.index)]]).sort_index()
        merged = merged[~merged.index.duplicated(keep="first")]

    miss = list(missing_minutes(merged, d, cfg))
    return merged, sources, miss


def add_symbol(df: pd.DataFrame, symbol: str) -> pd.DataFrame:
    out = df.copy()
    out.insert(0, "symbol", symbol)
    return out


def resample_ohlc(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    if interval == "1m":
        return df.copy()
    if interval not in {"3m", "5m"}:
        raise ValueError(f"unsupported interval: {interval}")
    pandas_freq = {"3m": "3min", "5m": "5min"}[interval]
    agg = {"open": "first", "high": "max", "low": "min", "close": "last"}
    if "volume" in df.columns:
        agg["volume"] = "sum"
    symbol = str(df["symbol"].iloc[0]) if (not df.empty and "symbol" in df.columns) else ""
    base = df.drop(columns=["symbol"], errors="ignore")
    pieces = []
    for _, day_df in base.groupby(base.index.date):
        r = day_df.resample(pandas_freq, origin="start_day", label="left", closed="left").agg(agg)
        r = r.dropna(subset=["open", "high", "low", "close"])
        pieces.append(r)
    out = pd.concat(pieces).sort_index() if pieces else base.iloc[0:0].copy()
    if symbol:
        out.insert(0, "symbol", symbol)
    return out


def save_csv(df: pd.DataFrame, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = df.reset_index()
    tmp["datetime_jst"] = tmp["datetime_jst"].dt.strftime("%Y-%m-%d %H:%M:%S%z")
    tmp.to_csv(path, index=False, encoding="utf-8-sig")


def basic_validate(df: pd.DataFrame, symbol: str, interval: str, cfg: dict, weekend_only: bool) -> list[str]:
    errs = []
    if df.empty:
        return [f"{symbol}/{interval}: no rows"]
    if df.index.has_duplicates:
        errs.append(f"{symbol}/{interval}: duplicate timestamps")
    if df[["open", "high", "low", "close"]].isna().any().any():
        errs.append(f"{symbol}/{interval}: OHLC NaN")
    bad_ohlc = (df["high"] < df[["open", "close", "low"]].max(axis=1)) | (df["low"] > df[["open", "close", "high"]].min(axis=1))
    if bad_ohlc.any():
        errs.append(f"{symbol}/{interval}: OHLC inconsistency rows={int(bad_ohlc.sum())}")
    dow = df.index.dayofweek
    if weekend_only and (dow < 5).any():
        errs.append(f"{symbol}/{interval}: weekday rows found in weekend-only data")
    if not weekend_only and (dow >= 5).any():
        errs.append(f"{symbol}/{interval}: weekend rows found in FX data")
    sh, sm = map(int, cfg["start_hour"].split(":"))
    eh, em = map(int, cfg["end_hour"].split(":"))
    m = df.index.hour * 60 + df.index.minute
    if ((m < sh * 60 + sm) | (m > eh * 60 + em)).any():
        errs.append(f"{symbol}/{interval}: out-of-session rows found")
    return errs


def exact_1m_validate(df: pd.DataFrame, symbol: str, cfg: dict, weekend_only: bool) -> tuple[list[str], list[dict]]:
    errs, missing_rows = [], []
    for d in daterange(cfg["start_date"], cfg["end_date"]):
        should_include = (d.weekday() >= 5) if weekend_only else (d.weekday() < 5)
        if not should_include:
            continue
        day_df = df[df.index.date == d]
        miss = missing_minutes(day_df, d, cfg)
        if len(miss):
            errs.append(f"{symbol}/1m {d}: missing_minutes={len(miss)}")
            for ts in miss:
                missing_rows.append({"symbol": symbol, "date": d.isoformat(), "missing_jst": ts.isoformat()})
    return errs, missing_rows


def selftest() -> None:
    idx = pd.date_range("2026-09-01 09:00", periods=841, freq="1min", tz="Asia/Tokyo", name="datetime_jst")
    sample = pd.DataFrame({
        "symbol": ["TEST"] * len(idx), "open": range(len(idx)), "high": range(len(idx)),
        "low": range(len(idx)), "close": range(len(idx)), "volume": [1] * len(idx),
    }, index=idx)
    assert len(resample_ohlc(sample, "3m")) == 281
    assert len(resample_ohlc(sample, "5m")) == 169
    assert len(expected_minute_index(date(2026, 9, 1), {
        "start_hour": "09:00", "end_hour": "23:00", "timezone": "Asia/Tokyo"
    })) == 841


def main():
    selftest()
    cfg = load_config()
    if OUT.exists():
        import shutil
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True, exist_ok=True)

    frames_by_tf: dict[str, dict[str, pd.DataFrame]] = {tf: {} for tf in cfg["output_intervals"]}
    failures: list[str] = []
    validations: list[str] = []
    missing_rows: list[dict] = []
    source_rows: list[dict] = []

    print(f"GMK history V5: {cfg['start_date']} -> {cfg['end_date']} / {cfg['start_hour']}-{cfg['end_hour']} JST")
    print("FX: GMO Coin Forex 1m. BTCJPY: GMO official historical trades primary + GMO KLine gap fallback. No synthetic fill.")

    for symbol, api_symbol in cfg["weekday_symbols"].items():
        print(f"[FX] {symbol} ({api_symbol})")
        days = []
        for d in daterange(cfg["start_date"], cfg["end_date"]):
            if d.weekday() >= 5:
                continue
            try:
                day = fetch_fx_day(api_symbol, d, cfg)
                day = filter_exact_date_and_session(day, d, cfg["start_hour"], cfg["end_hour"])
                miss = missing_minutes(day, d, cfg)
                if len(miss):
                    failures.append(f"{symbol} {d}: incomplete 1m data, missing={len(miss)}")
                    for ts in miss:
                        missing_rows.append({"symbol": symbol, "date": d.isoformat(), "missing_jst": ts.isoformat()})
                if not day.empty:
                    days.append(day)
                else:
                    failures.append(f"{symbol} {d}: no rows")
            except Exception as exc:
                failures.append(f"{symbol} {d}: {exc}")
                print(f"  ERROR {d}: {exc}", file=sys.stderr)
            time.sleep(0.05)
        if not days:
            failures.append(f"{symbol}: no data for entire requested range")
            continue
        m1 = add_symbol(pd.concat(days).sort_index(), symbol)
        m1 = m1[~m1.index.duplicated(keep="last")]
        exact_errs, exact_missing = exact_1m_validate(m1, symbol, cfg, weekend_only=False)
        validations.extend(exact_errs)
        missing_rows.extend(exact_missing)
        for tf in cfg["output_intervals"]:
            out = resample_ohlc(m1, tf)
            frames_by_tf[tf][symbol] = out
            save_csv(out, OUT / tf.upper() / f"{symbol}_{tf}_JST.csv")
            validations.extend(basic_validate(out, symbol, tf, cfg, weekend_only=False))
            print(f"  {tf}: rows={len(out)}")
        source_rows.append({"symbol": symbol, "source": "GMO Coin Forex BID", "role": "primary"})

    for symbol, api_symbol in cfg.get("weekend_symbol", {}).items():
        print(f"[WEEKEND] {symbol} ({api_symbol})")
        days = []
        for d in daterange(cfg["start_date"], cfg["end_date"]):
            if d.weekday() < 5:
                continue
            try:
                day, sources, miss = fetch_complete_btc_day(api_symbol, d, cfg)
                if len(miss):
                    failures.append(f"{symbol} {d}: incomplete after GMO historical+KLine merge, missing={len(miss)}")
                    for ts in miss:
                        missing_rows.append({"symbol": symbol, "date": d.isoformat(), "missing_jst": ts.isoformat()})
                if not day.empty:
                    days.append(day)
                    print(f"  {d}: rows={len(day)} sources={'+'.join(sources) or 'NONE'} missing={len(miss)}")
                else:
                    failures.append(f"{symbol} {d}: no rows")
            except Exception as exc:
                failures.append(f"{symbol} {d}: {exc}")
                print(f"  ERROR {d}: {exc}", file=sys.stderr)
            time.sleep(0.05)
        if not days:
            failures.append(f"{symbol}: no data for entire requested range")
            continue
        m1 = add_symbol(pd.concat(days).sort_index(), symbol)
        m1 = m1[~m1.index.duplicated(keep="last")]
        exact_errs, exact_missing = exact_1m_validate(m1, symbol, cfg, weekend_only=True)
        validations.extend(exact_errs)
        missing_rows.extend(exact_missing)
        for tf in cfg["output_intervals"]:
            out = resample_ohlc(m1, tf)
            frames_by_tf[tf][symbol] = out
            save_csv(out, OUT / tf.upper() / f"{symbol}_{tf}_JST_WEEKEND.csv")
            validations.extend(basic_validate(out, symbol, tf, cfg, weekend_only=True))
            print(f"  {tf}: rows={len(out)}")
        source_rows += [
            {"symbol": symbol, "source": "GMO Coin official historical trade CSV", "role": "primary"},
            {"symbol": symbol, "source": "GMO Coin BTC/JPY KLine", "role": "gap fallback only"},
        ]

    manifest_rows = []
    for tf, symbol_map in frames_by_tf.items():
        nonempty = [df for df in symbol_map.values() if not df.empty]
        if nonempty:
            combined = pd.concat(nonempty).sort_index()
            save_csv(combined, OUT / f"GMK_ALL_{tf}_20260901_20261006_JST.csv")
        for symbol, df in symbol_map.items():
            manifest_rows.append({
                "timeframe": tf, "symbol": symbol, "rows": len(df),
                "first_jst": "" if df.empty else df.index.min().isoformat(),
                "last_jst": "" if df.empty else df.index.max().isoformat(),
                "days": 0 if df.empty else df.index.normalize().nunique(),
            })

    pd.DataFrame(manifest_rows).to_csv(OUT / "manifest.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(source_rows).drop_duplicates().to_csv(OUT / "sources.csv", index=False, encoding="utf-8-sig")
    if missing_rows:
        pd.DataFrame(missing_rows).drop_duplicates().sort_values(["symbol", "missing_jst"]).to_csv(OUT / "missing_minutes.csv", index=False, encoding="utf-8-sig")
    with (OUT / "run_config.json").open("w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    with (OUT / "SOURCE.txt").open("w", encoding="utf-8") as f:
        f.write("FX: GMO Coin Forex public API, BID, 1-minute candles.\n")
        f.write("BTCJPY: Coinbase public BTC-JPY 1-minute candles PRIMARY; GMO Coin BTC/JPY fills only missing Coinbase timestamps.\n")
        f.write("No forward-fill/interpolation/synthetic candles are generated.\n")
        f.write("3m and 5m are resampled from the final validated 1m series in JST.\n")

    all_errors = list(dict.fromkeys(failures + validations))
    if all_errors:
        with (OUT / "validation_errors.txt").open("w", encoding="utf-8") as f:
            f.write("\n".join(all_errors) + "\n")
    else:
        with (OUT / "validation_OK.txt").open("w", encoding="utf-8") as f:
            f.write("FULL VALIDATION PASSED. Every required 1-minute timestamp exists for every requested day; no duplicates, OHLC NaN/inconsistency, or session/day-of-week violations.\n")

    # Create a standalone ZIP for Windows/manual use. GitHub Actions V4 uploads output/ directly
    # so the downloaded Artifact does not contain a redundant nested result ZIP.
    zip_path = ROOT / "GMK_HISTORY_20260901_20261006.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for p in OUT.rglob("*"):
            if p.is_file():
                zf.write(p, p.relative_to(ROOT))

    print(f"DONE: {zip_path}")
    if all_errors:
        print(f"FAILED CHECKS: errors={len(all_errors)}; see output/validation_errors.txt and output/missing_minutes.csv", file=sys.stderr)
        sys.exit(2)
    print("FULL_VALIDATION_OK")


if __name__ == "__main__":
    main()

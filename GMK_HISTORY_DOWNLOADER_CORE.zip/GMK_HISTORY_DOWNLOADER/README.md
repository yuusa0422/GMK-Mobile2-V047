# GMK Historical Data Downloader

2026-09-01〜2026-10-06 のGMK検証用ヒストリカルデータを取得するための一式です。

## 初期設定
- JST 09:00〜23:00
- 平日: USDJPY / EURJPY / GBPJPY / AUDJPY / EURUSD / GBPUSD
- 土日: BTCJPY のみ
- 取得足: 5分足
- 出力: 個別CSV、全銘柄統合CSV、manifest.csv、ZIP

> 6通貨が現在のGMK構成と異なる場合は `config.json` の `weekday_symbols` だけ変更してください。

## Windows
`RUN_WINDOWS.cmd` をダブルクリック。

## GitHub Actions
1. このフォルダ一式をGitHubリポジトリへ置く
2. Actions > Build GMK historical data
3. Run workflow
4. Artifacts から `GMK_HISTORY_20260901_20261006` を取得

## 出力
- `output/csv/*.csv`: 銘柄別
- `output/GMK_ALL_20260901_20261006_JST.csv`: 統合
- `output/manifest.csv`: 件数・先頭/末尾時刻・日数
- `GMK_HISTORY_20260901_20261006.zip`: 全出力ZIP

## データ取得元
この版は `yfinance` を使用します。Yahoo Financeのintraday 5mデータは取得可能期間に制約があるため、今回の2026-09-01〜2026-10-06のような直近期間向けです。

## 注意
Yahoo側の一時的なレート制限や銘柄データ欠損がある場合は `output/failures.txt` が生成され、終了コード2になります。

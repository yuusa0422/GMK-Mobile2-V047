# GMK Historical Data Downloader (1m / 3m / 5m)

対象: 2026-09-01 ～ 2026-10-06 / JST 09:00～23:00

- 平日: USDJPY, EURJPY, GBPJPY, AUDJPY, EURUSD, GBPUSD
- 土日: BTCJPY のみ
- 元データ: 1分足
- 出力: 1分足・3分足・5分足
- 3分足/5分足は同じ1分足からJST基準で生成
- FX source: GMO Coin Forex public KLine API (BID)
- BTCJPY source: GMO Coin Crypto public KLine API (BTC / JPY market)

生成物:
- output/1M/*.csv
- output/3M/*.csv
- output/5M/*.csv
- output/GMK_ALL_1m_20260901_20261006_JST.csv
- output/GMK_ALL_3m_20260901_20261006_JST.csv
- output/GMK_ALL_5m_20260901_20261006_JST.csv
- output/manifest.csv
- output/validation_OK.txt または validation_errors.txt
- GMK_HISTORY_20260901_20261006.zip

GitHubではこのZIP本体をリポジトリ直下に `GMK_HISTORY_DOWNLOADER_CORE.zip` という名前で置き、既存の修正版workflowを実行してください。

# GMK Historical Data Downloader V4

取得条件: 2026-09-01〜2026-10-06 / JST 09:00〜23:00。
平日はFX 6通貨、土日はBTCJPYのみ。1分足を取得し、同じ1分足から3分足・5分足を生成します。

## V4の変更点
- BTCJPYは Coinbase public BTC-JPY 1分足を主データ源に変更。
- GMO Coin BTC/JPYはCoinbaseの欠損時だけ補完に使用。
- 補間・前値埋め・架空ローソク足は作りません。
- 1分単位の完全性を日別に検査し、1本でも欠ければ終了コード2で失敗させます。
- 欠損がある場合 `output/missing_minutes.csv` に時刻を全件出力します。
- 3分足・5分足は完全性検査済み1分足から生成します。
- GitHub Actions用V4では `output/` のみArtifact化し、成果物ZIPの二重格納を避けます。


V5: BTCJPY uses GMO Coin official daily historical trade CSV as primary and GMO KLine only for missing real minutes. Coinbase removed. No synthetic fill.

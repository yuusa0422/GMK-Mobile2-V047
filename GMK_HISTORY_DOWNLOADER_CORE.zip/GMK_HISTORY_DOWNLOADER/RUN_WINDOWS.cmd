@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install -r requirements.txt
  py download_gmk_history.py
) else (
  python -m pip install -r requirements.txt
  python download_gmk_history.py
)
echo.
echo Finished. Check output folder and GMK_HISTORY_20260901_20261006.zip
pause

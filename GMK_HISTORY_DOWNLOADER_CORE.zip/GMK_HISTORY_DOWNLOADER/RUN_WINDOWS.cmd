@echo off
setlocal
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 goto :fail
py download_gmk_history.py
if errorlevel 1 goto :fail
echo.
echo COMPLETE: GMK_HISTORY_20260901_20261006.zip
pause
exit /b 0
:fail
echo.
echo ERROR: Check the messages above and output\failures.txt if present.
pause
exit /b 1

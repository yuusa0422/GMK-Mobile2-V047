package jp.gmk.mobile.data

import android.content.Context

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("gmk_mobile_local", Context.MODE_PRIVATE)

    var oandaToken: String
        get() = prefs.getString("oanda_token", "") ?: ""
        set(value) = prefs.edit().putString("oanda_token", value.trim()).apply()

    var oandaAccountId: String
        get() = prefs.getString("oanda_account_id", "") ?: ""
        set(value) = prefs.edit().putString("oanda_account_id", value.trim()).apply()

    var oandaEnvironment: String
        get() = prefs.getString("oanda_environment", "practice") ?: "practice"
        set(value) = prefs.edit().putString("oanda_environment", if (value == "live") "live" else "practice").apply()

    var yahooFallback: Boolean
        get() = prefs.getBoolean("yahoo_fallback", true)
        set(value) = prefs.edit().putBoolean("yahoo_fallback", value).apply()

    var autoScan: Boolean
        get() = prefs.getBoolean("auto_scan", true)
        set(value) = prefs.edit().putBoolean("auto_scan", value).apply()

    var lastAutoBoundaryKey: String
        get() = prefs.getString("last_auto_boundary_key", "") ?: ""
        set(value) {
            prefs.edit().putString("last_auto_boundary_key", value).commit()
        }

}

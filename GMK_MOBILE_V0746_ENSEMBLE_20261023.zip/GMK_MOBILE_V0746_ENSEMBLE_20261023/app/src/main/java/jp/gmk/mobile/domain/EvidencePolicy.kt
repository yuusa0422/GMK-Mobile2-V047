package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.floor

/**
 * v0.7.46 final 3-minute ENTRY decision. Runs after the native scan and every optional overlay.
 * v0.7.46 change: the model is the average of five seeds (EvidenceEnsemble). Same inputs and rule; less variance.
 *   Out of sample, same number of entries: weekday 52.5% (both halves 52.4 / 52.5), October 2025 51.8%,
 *   October 2026 52.0%, days with 8+ losses 12.7% (single model 17.5%).
 * v0.7.45 change: weekend BTC uses a 576-slot window (about two weekend days) and a 47% quota, so quiet,
 * draw-heavy weekend days receive fewer entries and active days more (weekend entry count unchanged on average).
 * Loss/streak study: weekday losses are independent (autocorrelation ~0, runs test, daily dispersion 1.0);
 * weekend losses cluster by day (quiet days: 35% draws, 43.6% wins vs 53.2% on active days).
 *
 * Research (README_V0744.txt, one year of real 1-minute candles 2025-10-01..2026-10-21, the app's
 * exact six-instrument scan, true JST clock, DRAW = LOSE, model trained on one half and tested on the other):
 *  - current app: weekday 50.5% at 73.9% of slots, weekend BTC 47.6% at 46.1% (15% draws), max 18 losses.
 *  - this policy, same number of entries: weekday 51.9% (A 53.1 / B 51.7 / C 50.8), weekend 49.3%
 *    (A 50.8 / B 47.6; BTC 57.8% when draws are excluded). Backup model without a live price: 50.7% / 47.8%.
 *  - the gain comes mainly from the last minute before entry (fade sharp FX moves, follow BTC moves on
 *    bitbank) and from avoiding draw-prone BTC moments; see README_V0744.txt for the full table.
 *
 * Decision (every 5-minute slot, 09:00-22:55 JST, weekday six instruments, weekend BTCJPY):
 *  1) score every candidate instrument x {HIGH, LOW} with the gradient-boosted evidence model
 *     (fresh model when every candidate has a live quote taken within 40 s before entry, else backup model)
 *  2) take the best (instrument, direction); hour-adjust its probability
 *  3) ENTER when it is not in the weakest 26% (weekday) / 53% (weekend) of recent slots
 *     (rolling 288 weekday / 576 weekend AUTO slots; seeded from the one-year distribution until 96 slots are seen)
 *  4) grade A = top 25% of slots, B = next 25%, C = the rest of the entries, E = skipped (observe only)
 */
object EvidencePolicy {
    const val VERSION = "V0746_EVIDENCE_ENSEMBLE"
    const val POLICY_TAG = "GMK_V0740_V0746_EVIDENCE"
    const val WEEKDAY_ENTRY_RATE = 0.74
    const val WEEKEND_ENTRY_RATE = 0.47
    const val WEEKDAY_BUFFER_SIZE = 288
    const val WEEKEND_BUFFER_SIZE = 576
    const val BUFFER_MIN = 96
    fun bufferLimit(weekend: Boolean): Int = if (weekend) WEEKEND_BUFFER_SIZE else WEEKDAY_BUFFER_SIZE
    const val LIVE_MAX_AGE_MS = 40_000L
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    data class LiveQuote(val price: Double, val epochMs: Long)
    data class Choice(val instrument: String, val direction: String, val probability: Double, val adjusted: Double, val fresh: Boolean)
    data class Decision(val choice: Choice, val threshold: Double, val q50: Double, val q75: Double, val enter: Boolean, val grade: String, val fromSeed: Boolean)

    /** One-year validated win rates by grade (model trained on the other half, same decision rule). */
    private fun validatedRate(fresh: Boolean, weekend: Boolean, grade: String): Double = when {
        fresh && !weekend -> when (grade) { "A" -> 0.531; "B" -> 0.515; else -> 0.528 }
        fresh && weekend -> when (grade) { "A" -> 0.510; else -> 0.476 }
        !weekend -> when (grade) { "A" -> 0.520; "B" -> 0.500; else -> 0.508 }
        else -> when (grade) { "A" -> 0.497; else -> 0.452 }
    }

    // ---------------- live quotes ----------------

    fun quotesFromRates(rows: List<RateRow>): Map<String, LiveQuote> = rows.mapNotNull { r ->
        val p = r.price; val t = r.sourceEpochMs
        if (p != null && p.isFinite() && p > 0.0 && t != null && t > 0L && r.freshnessStatus == "LIVE") r.instrument to LiveQuote(p, t) else null
    }.toMap()

    fun newestQuotes(vararg sources: Map<String, LiveQuote>): Map<String, LiveQuote> {
        val out = HashMap<String, LiveQuote>()
        for (s in sources) for ((k, q) in s) { val old = out[k]; if (old == null || q.epochMs > old.epochMs) out[k] = q }
        return out
    }

    /** Live price for [instrument] taken in [B-40 s, B+1 s]; null when missing or stale. */
    fun freshPrice(quotes: Map<String, LiveQuote>, instrument: String, boundaryEpochSec: Long): Double? {
        val q = quotes[instrument] ?: return null
        val b = boundaryEpochSec * 1000L
        return if (q.price.isFinite() && q.price > 0.0 && q.epochMs >= b - LIVE_MAX_AGE_MS && q.epochMs <= b + 1_000L) q.price else null
    }

    // ---------------- adaptive threshold state ----------------

    private class Buffer { val boundaries = ArrayDeque<Long>(); val values = ArrayDeque<Double>() }
    private val buffers = ConcurrentHashMap<String, Buffer>()
    private fun key(fresh: Boolean, weekend: Boolean) = (if (fresh) "fresh" else "fallback") + "|" + (if (weekend) "weekend" else "weekday")

    @Synchronized fun resetState() = buffers.clear()
    @Synchronized fun bufferSize(fresh: Boolean, weekend: Boolean): Int = buffers[key(fresh, weekend)]?.values?.size ?: 0

    /** numpy.quantile(..., method="linear") */
    fun quantile(values: List<Double>, q: Double): Double {
        require(values.isNotEmpty())
        val a = values.sorted(); val pos = q * (a.size - 1)
        val lo = floor(pos).toInt(); val hi = ceil(pos).toInt()
        return a[lo] + (a[hi] - a[lo]) * (pos - lo)
    }

    private fun seeds(fresh: Boolean, weekend: Boolean): Triple<Double, Double, Double> = when {
        fresh && !weekend -> Triple(EvidenceModelData.FRESH_WEEKDAY_SEED_THRESHOLD, EvidenceModelData.FRESH_WEEKDAY_SEED_Q50, EvidenceModelData.FRESH_WEEKDAY_SEED_Q75)
        fresh -> Triple(EvidenceModelData.FRESH_WEEKEND_SEED_THRESHOLD, EvidenceModelData.FRESH_WEEKEND_SEED_Q50, EvidenceModelData.FRESH_WEEKEND_SEED_Q75)
        !weekend -> Triple(EvidenceModelData.FALLBACK_WEEKDAY_SEED_THRESHOLD, EvidenceModelData.FALLBACK_WEEKDAY_SEED_Q50, EvidenceModelData.FALLBACK_WEEKDAY_SEED_Q75)
        else -> Triple(EvidenceModelData.FALLBACK_WEEKEND_SEED_THRESHOLD, EvidenceModelData.FALLBACK_WEEKEND_SEED_Q50, EvidenceModelData.FALLBACK_WEEKEND_SEED_Q75)
    }

    fun hourOffset(fresh: Boolean, weekend: Boolean, hourJst: Int): Double {
        val arr = when {
            fresh && !weekend -> EvidenceModelData.FRESH_WEEKDAY_HOUR_OFFSET
            fresh -> EvidenceModelData.FRESH_WEEKEND_HOUR_OFFSET
            !weekend -> EvidenceModelData.FALLBACK_WEEKDAY_HOUR_OFFSET
            else -> EvidenceModelData.FALLBACK_WEEKEND_HOUR_OFFSET
        }
        return arr[(hourJst - 9).coerceIn(0, arr.size - 1)]
    }

    /** Threshold decision; [record] appends this slot to the rolling distribution (AUTO slots only). */
    @Synchronized
    fun decide(choice: Choice, weekend: Boolean, boundaryEpochSec: Long, record: Boolean): Decision {
        val buf = buffers.getOrPut(key(choice.fresh, weekend)) { Buffer() }
        val rate = if (weekend) WEEKEND_ENTRY_RATE else WEEKDAY_ENTRY_RATE
        val fromSeed = buf.values.size < BUFFER_MIN
        val (thr, q50, q75) = if (fromSeed) seeds(choice.fresh, weekend) else {
            val v = buf.values.toList(); Triple(quantile(v, 1.0 - rate), quantile(v, 0.50), quantile(v, 0.75))
        }
        val enter = choice.adjusted >= thr
        val grade = if (!enter) "E" else if (choice.adjusted >= q75) "A" else if (choice.adjusted >= q50) "B" else "C"
        if (record && buf.boundaries.lastOrNull() != boundaryEpochSec) {
            buf.boundaries.addLast(boundaryEpochSec); buf.values.addLast(choice.adjusted)
            while (buf.values.size > bufferLimit(weekend)) { buf.values.removeFirst(); buf.boundaries.removeFirst() }
        }
        return Decision(choice, thr, q50, q75, enter, grade, fromSeed)
    }

    // ---------------- model choice ----------------

    /** Best (instrument, direction) for this slot, or null when no candidate has a 61-minute window. */
    fun choose(native: ScanResult, candles: Map<String, List<Candle>>, quotes: Map<String, LiveQuote>, entry: ZonedDateTime): Choice? {
        val j = entry.withZoneSameInstant(JST)
        val weekend = !TradingSession.isWeekday(j)
        val b = entry.toEpochSecond()
        val pool = native.candidates.filter { !weekend || it.instrument == "BTCJPY" }
            .sortedBy { EvidenceFeatures.INSTRUMENTS.indexOf(it.instrument).let { i -> if (i < 0) 99 else i } }
        if (pool.isEmpty()) return null
        val live = pool.associate { it.instrument to freshPrice(quotes, it.instrument, b) }
        val fresh = live.values.all { it != null }
        val feats = LinkedHashMap<String, EvidenceFeatures.Instrument>()
        for (c in pool) EvidenceFeatures.instrument(c.instrument, candles[c.instrument].orEmpty(), b, if (fresh) live[c.instrument] else null)?.let { feats[c.instrument] = it }
        if (feats.isEmpty()) return null
        val yen = EvidenceFeatures.yenFactor(feats)
        val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback
        var best: Choice? = null
        for (c in pool) {
            val x = feats[c.instrument] ?: continue
            for (d in intArrayOf(1, -1)) {
                val p = model.probability(EvidenceFeatures.design(x, yen, c, j.hour, weekend, d, fresh))
                if (best == null || p > best.probability) {
                    best = Choice(c.instrument, if (d == 1) "HIGH" else "LOW", p, p - hourOffset(fresh, weekend, j.hour), fresh)
                }
            }
        }
        return best
    }

    // ---------------- final decision ----------------

    fun apply(native: ScanResult, result: ScanResult, candles: Map<String, List<Candle>>, quotes: Map<String, LiveQuote> = emptyMap()): ScanResult {
        val entry = runCatching { ZonedDateTime.parse(native.entryTimeJst) }.getOrNull() ?: return skipTop(result, "エントリー時刻不明")
        if (!TradingSession.isActive(entry)) return skipTop(result, "${TradingSession.LABEL} 外")
        val weekend = !TradingSession.isWeekday(entry.withZoneSameInstant(JST))
        val choice = runCatching { choose(native, candles, quotes, entry) }.getOrNull() ?: return skipTop(result, "1分足61本の連続データ不足")
        val target = native.candidates.firstOrNull { it.instrument == choice.instrument } ?: return skipTop(result, "候補なし")
        val nativeTop = native.top1 ?: target
        val decision = decide(choice, weekend, entry.toEpochSecond(), record = native.source == "AUTO")
        val rate = validatedRate(choice.fresh, weekend, decision.grade)
        val pct = "%.1f".format(choice.probability * 100.0)
        val modelLabel = if (choice.fresh) "直前価格あり" else "直前価格なし・予備モデル"
        val label = if (decision.enter)
            "検証モデル ${decision.grade}（${if (weekend) "土日BTC" else "平日"}・1年検証 ${"%.1f".format(rate * 100.0)}%）${choice.direction} 予測勝率 $pct% / $modelLabel"
        else "検証モデル: 期待値が低い枠 ${choice.direction} 予測勝率 $pct% / $modelLabel"
        val note = "$VERSION p=$pct% adj=${"%+.4f".format(choice.adjusted)} thr=${"%+.4f".format(decision.threshold)}" +
            " ${if (decision.fromSeed) "seed" else "rolling"} ${if (choice.fresh) "fresh" else "fallback"} -> ${decision.grade}/${if (decision.enter) "ENTRY" else "SKIP"}"
        val grade = decision.grade
        val action = if (decision.enter) "ENTRY" else "SKIP"
        val chosen = target.copy(
            rank = 1, direction = choice.direction, grade = grade, decision = action, probability = choice.probability,
            reasons = listOf("判定: 3分", note) + target.reasons.filterNot { it.startsWith("判定:") },
            assessment = CandidateAssessmentFactory.correction(target, nativeTop, choice.direction, grade, action, 3, label,
                if (decision.enter) null else CandidateSkipReason.LOW_EXPECTANCY)
        )
        val others = native.candidates.filter { it.instrument != target.instrument }.mapIndexed { i, c -> c.copy(rank = i + 2) }
        val suffix = if (result.policyVersion.endsWith("_3M_FIXED")) "_3M_FIXED" else ""
        val warnings = result.warnings + listOfNotNull(if (choice.fresh) null else "$VERSION: 直前価格が40秒以内に取れない通貨あり → 予備モデル")
        return native.copy(judgeTimeJst = entry.plusMinutes(3).toString(), candidates = listOf(chosen) + others,
            warnings = warnings.distinct(), policyVersion = POLICY_TAG + suffix)
    }

    /** Fail-safe: keep the overlay result but never ENTER. */
    private fun skipTop(result: ScanResult, why: String): ScanResult {
        val top = result.top1 ?: return result
        if (top.decision != "ENTRY") return result
        val note = "$VERSION: ${CandidateSkipReason.OBSERVE_ONLY.label} ($why) -> E/SKIP"
        val assessment = top.assessment?.let { a ->
            a.copy(operationalGrade = "E", decision = "SKIP", skipReason = CandidateSkipReason.OBSERVE_ONLY,
                chosenAction = a.chosenAction.copy(operationalGrade = "E", decision = "SKIP"))
        }
        val updated = top.copy(grade = "E", decision = "SKIP", reasons = top.reasons + note, assessment = assessment)
        return result.copy(candidates = result.candidates.map { if (it.rank == top.rank) updated else it })
    }
}

/** Newest Yahoo meta quote seen while fetching scan candles (written by MarketRepository). */
object LiveQuoteBoard {
    private val quotes = ConcurrentHashMap<String, EvidencePolicy.LiveQuote>()
    fun record(instrument: String, price: Double, epochMs: Long) {
        if (!(price.isFinite() && price > 0.0) || epochMs <= 0L) return
        quotes.merge(instrument, EvidencePolicy.LiveQuote(price, epochMs)) { old, new -> if (new.epochMs >= old.epochMs) new else old }
    }
    fun snapshot(): Map<String, EvidencePolicy.LiveQuote> = HashMap(quotes)
    fun clear() = quotes.clear()
}

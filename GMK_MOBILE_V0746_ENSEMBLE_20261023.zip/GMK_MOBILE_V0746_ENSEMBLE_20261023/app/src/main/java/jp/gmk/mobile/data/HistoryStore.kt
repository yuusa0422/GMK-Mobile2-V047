package jp.gmk.mobile.data

import android.content.Context
import jp.gmk.mobile.domain.HistoryRow
import jp.gmk.mobile.domain.ScanResult
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE)
    // Keep the crash journal in a separate, tiny preferences file. SharedPreferences commits
    // rewrite their whole XML map; storing the journal beside 20k history rows would make every
    // synchronous journal commit rewrite the giant history file on the caller/main thread.
    private val journalPrefs = context.getSharedPreferences("gmk_mobile_history_journal", Context.MODE_PRIVATE)
    // Serialize crash-journal writes with post-snapshot cleanup. Without a shared lock,
    // a new critical row could be committed after cleanup reads the journal but before
    // it removes the key, losing the only durable copy if the process then stops.
    private val journalLock = JOURNAL_LOCK
    private val ioExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "gmk-history-io").apply { isDaemon = true }
    }
    @Volatile private var cache: List<HistoryRow>? = null
    private val _rows = MutableStateFlow<List<HistoryRow>>(emptyList())
    /** Immutable published snapshot; readers never wait on journal disk I/O. */
    val rows: StateFlow<List<HistoryRow>> = _rows
    private val lastPublishedAtMs = AtomicLong(0L)
    private val lastJournalCommitDurationMs = AtomicLong(0L)
    private val pendingWrite = AtomicReference<List<HistoryRow>?>(null)
    private val writerScheduled = AtomicBoolean(false)
    private val persistAttemptCount = AtomicLong(0)
    private val persistSuccessCount = AtomicLong(0)
    private val persistFailureCount = AtomicLong(0)
    private val lastPersistSuccessMs = AtomicLong(0)
    private val lastPersistError = AtomicReference<String?>(null)
    private val journalFailureCount = AtomicLong(0)

    @Synchronized
    fun add(result: ScanResult) {
        val top = result.top1 ?: return
        val current = load().toMutableList()

        // Replayed AUTO frames and retried scan IDs must not erase a captured/settled result.
        if (jp.gmk.mobile.domain.HistoryIdentity.alreadyRecorded(current, result)) return

        val added = normalizeDecodedRow(HistoryRow(
            id = System.currentTimeMillis(),
            scanId = result.scanId,
            source = result.source,
            atJst = result.atJst,
            instrument = top.instrument,
            direction = top.direction,
            grade = top.grade,
            decision = top.decision,
            candidateRank = top.rank,
            regime = top.regime,
            entryTimeJst = result.entryTimeJst,
            judgeTimeJst = result.judgeTimeJst,
            policyVersion = result.policyVersion,
            resultStatus = if (top.decision == "ENTRY") "WAIT_ENTRY" else "SKIP",
            assessment = top.assessment
        ))
        current.add(0, added)
        save(current.take(MAX_HISTORY_ROWS), added)
    }

    @Synchronized
    fun load(): List<HistoryRow> {
        cache?.let { return it }

        // Capture the primary, backup and crash journal as one snapshot across stores.
        // Decode large JSON outside this lock so UI timing is not held by parsing.
        val stored = synchronized(journalLock) {
            Triple(prefs.getString("items", "[]") ?: "[]",
                prefs.getString("items_backup", "[]") ?: "[]",
                journalPrefs.getString(CRITICAL_ROW_KEY, null))
        }
        val capturedCriticalRows = decodeCriticalRows(stored.third)

        fun decode(text: String): List<HistoryRow>? {
            val array = try {
                JSONArray(text)
            } catch (_: Exception) {
                return null
            }

            return buildList {
                for (i in 0 until array.length()) {
                    val x = array.optJSONObject(i) ?: continue
                    val instrument = x.optString("instrument")
                    val direction = x.optString("direction")
                    if (instrument.isBlank() || direction !in setOf("HIGH", "LOW")) continue

                    val grade = x.optString("grade", x.optString("rank", "D")).uppercase()
                    if (!isKnownGrade(grade)) continue

                    val decision = x.optString("decision").uppercase().ifBlank {
                        if (grade in setOf("D", "E", "F", "G", "H", "I")) "SKIP" else "ENTRY"
                    }
                    if (decision !in setOf("ENTRY", "SKIP")) continue

                    add(normalizeDecodedRow(HistoryRow(
                        id = x.optLong("id").takeIf { it > 0L } ?: System.currentTimeMillis(),
                        scanId = x.optString("scan_id", ""),
                        source = x.optString("source"),
                        policyVersion = x.optString("policy_version", "LEGACY_UNVERSIONED"),
                        atJst = x.optString("at_jst"),
                        instrument = instrument,
                        direction = direction,
                        grade = grade,
                        decision = decision,
                        candidateRank = x.optInt("candidate_rank", 1).coerceAtLeast(1),
                        regime = x.optString("regime", "UNKNOWN"),
                        entryTimeJst = x.optString("entry_time_jst", ""),
                        judgeTimeJst = x.optString("judge_time_jst", ""),
                        entryRate = x.optDouble("entry_rate").takeIf { x.has("entry_rate") && !x.isNull("entry_rate") },
                        judgeRate = x.optDouble("judge_rate").takeIf { x.has("judge_rate") && !x.isNull("judge_rate") },
                        entryRateSource = x.optString("entry_rate_source", ""),
                        judgeRateSource = x.optString("judge_rate_source", ""),
                        entryCapturedAtJst = x.optString("entry_captured_at_jst", ""),
                        settledAtJst = x.optString("settled_at_jst", ""),
                        entryCaptureDelayMs = x.optLong("entry_capture_delay_ms").takeIf {
                            x.has("entry_capture_delay_ms") && !x.isNull("entry_capture_delay_ms")
                        },
                        judgeCaptureDelayMs = x.optLong("judge_capture_delay_ms").takeIf {
                            x.has("judge_capture_delay_ms") && !x.isNull("judge_capture_delay_ms")
                        },
                        entryProviderAgeSeconds = x.optDouble("entry_provider_age_seconds").takeIf {
                            x.has("entry_provider_age_seconds") && !x.isNull("entry_provider_age_seconds")
                        },
                        judgeProviderAgeSeconds = x.optDouble("judge_provider_age_seconds").takeIf {
                            x.has("judge_provider_age_seconds") && !x.isNull("judge_provider_age_seconds")
                        },
                        assessment = AssessmentJsonCodec.decode(x.optJSONObject("assessment")),
                        resultStatus = if (x.has("result_status")) {
                            x.optString("result_status", "LEGACY_NO_OUTCOME")
                        } else if (decision == "SKIP") {
                            "SKIP"
                        } else {
                            val legacyScanId = x.optString("scan_id", "")
                            val legacyEntry = x.optString("entry_time_jst", "")
                            val legacyJudge = x.optString("judge_time_jst", "")
                            if (legacyScanId.isBlank() || legacyEntry.isBlank() || legacyJudge.isBlank()) {
                                "LEGACY_NO_OUTCOME"
                            } else {
                                "WAIT_ENTRY"
                            }
                        }
                    )))
                }
            }
        }

        val primary = stored.first
        decode(primary)?.let { decoded ->
            val merged = mergeCriticalRow(decoded, capturedCriticalRows)
            cache = merged
            _rows.value = merged
            return merged
        }

        // Preserve the broken primary and try the last known-good snapshot.
        prefs.edit().putString("items_corrupt_last", primary.take(200_000)).commit()

        val backup = stored.second
        val recovered = decode(backup)
        if (recovered != null) {
            prefs.edit()
                .putString("items", backup)
                .putBoolean("history_recovered_from_backup", true)
                .commit()
            val merged = mergeCriticalRow(recovered, capturedCriticalRows)
            cache = merged
            _rows.value = merged
            return merged
        }

        val merged = mergeCriticalRow(emptyList(), capturedCriticalRows)
        cache = merged
        _rows.value = merged
        return merged
    }

    private fun isKnownGrade(grade: String): Boolean {
        if (grade in setOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I", "R")) return true
        if (!grade.startsWith("C")) return false
        val n = grade.removePrefix("C").toIntOrNull() ?: return false
        return n in 1..10
    }

    @Synchronized
    fun updateEntryRate(
        scanId: String,
        rate: Double,
        source: String,
        capturedAtJst: String,
        captureDelayMs: Long,
        providerAgeSeconds: Double
    ) {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return
        val h = rows[idx]
        if (h.resultStatus != "WAIT_ENTRY") return
        if (!rate.isFinite() || rate <= 0.0) return
        if (!providerAgeSeconds.isFinite() || providerAgeSeconds < 0.0) return
        rows[idx] = h.copy(
            entryRate = rate,
            entryRateSource = source,
            entryCapturedAtJst = capturedAtJst,
            entryCaptureDelayMs = captureDelayMs,
            entryProviderAgeSeconds = providerAgeSeconds,
            resultStatus = "WAIT_JUDGE"
        )
        save(rows, rows[idx])
    }

    @Synchronized
    fun markEntryMissed(scanId: String, reason: String = "ENTRY_RATE_MISSED") {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return
        if (rows[idx].resultStatus != "WAIT_ENTRY") return
        rows[idx] = rows[idx].copy(resultStatus = reason)
        save(rows, rows[idx])
    }

    @Synchronized
    fun settle(
        scanId: String,
        judgeRate: Double,
        source: String,
        settledAtJst: String,
        captureDelayMs: Long,
        providerAgeSeconds: Double
    ) {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return

        val h = rows[idx]
        if (h.resultStatus != "WAIT_JUDGE") return
        if (!judgeRate.isFinite() || judgeRate <= 0.0) return
        if (!providerAgeSeconds.isFinite() || providerAgeSeconds < 0.0) return
        val entry = h.entryRate
        if (entry == null) {
            rows[idx] = h.copy(
                judgeRate = judgeRate,
                judgeRateSource = source,
                settledAtJst = settledAtJst,
                resultStatus = "ENTRY_RATE_MISSING"
            )
            save(rows, rows[idx])
            return
        }

        // DRAW is directional LOSE by specification.
        val win = when (h.direction) {
            "HIGH" -> judgeRate > entry
            "LOW" -> judgeRate < entry
            else -> false
        }

        rows[idx] = h.copy(
            judgeRate = judgeRate,
            judgeRateSource = source,
            settledAtJst = settledAtJst,
            judgeCaptureDelayMs = captureDelayMs,
            judgeProviderAgeSeconds = providerAgeSeconds,
            resultStatus = if (win) "WIN" else "LOSE"
        )
        save(rows, rows[idx])
    }

    @Synchronized
    fun markJudgeMissed(scanId: String, reason: String = "JUDGE_RATE_MISSED") {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return
        if (rows[idx].resultStatus != "WAIT_JUDGE") return
        rows[idx] = rows[idx].copy(resultStatus = reason)
        save(rows, rows[idx])
    }

    @Synchronized
    fun reopenMinuteAlignedMissForRecovery(scanId: String): Boolean {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return false
        val h = rows[idx]
        // Only minute-aligned modes are recoverable from historical M1 OPEN. Manual 3m uses
        // an arbitrary +10-second quote and cannot be reconstructed faithfully after the fact.
        if (h.source == "MANUAL") return false
        val nextStatus = when (h.resultStatus) {
            "ENTRY_RATE_MISSED" -> if (h.entryRate == null) "WAIT_ENTRY" else "WAIT_JUDGE"
            "JUDGE_RATE_MISSED" -> if (h.entryRate != null) "WAIT_JUDGE" else "WAIT_ENTRY"
            else -> return false
        }
        rows[idx] = h.copy(resultStatus = nextStatus)
        save(rows, rows[idx])
        return true
    }

    @Synchronized
    fun pending(): List<HistoryRow> =
        load().filter { it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") }

    fun diagnosticStats(): JSONObject = JSONObject()
        .put("persist_attempts", persistAttemptCount.get())
        .put("persist_success", persistSuccessCount.get())
        .put("persist_failure", persistFailureCount.get())
        .put("last_persist_success_ms", lastPersistSuccessMs.get())
        .put("last_persist_error", lastPersistError.get() ?: JSONObject.NULL)
        .put("journal_failure", journalFailureCount.get())
        .put("last_published_at_ms", lastPublishedAtMs.get())
        .put("last_journal_commit_duration_ms", lastJournalCommitDurationMs.get())
        .put("publish_before_journal_commit", true)
        .put("critical_journal_present", !journalPrefs.getString(CRITICAL_ROW_KEY, null).isNullOrBlank())
        .put("critical_journal_rows", decodeCriticalRows().size)
        .put("write_pending", pendingWrite.get() != null)
        .put("writer_active", writerScheduled.get())
        .put("cached_rows", cache?.size ?: 0)
        .put("invalid_rate_rows", cache?.count { it.resultStatus == "INVALID_RATE_DATA" } ?: 0)
        .put("invalid_timing_rows", cache?.count { it.resultStatus == "INVALID_TIMING_DATA" } ?: 0)

    private fun rowToJson(h: HistoryRow): JSONObject = JSONObject()
        .put("policy_version", h.policyVersion)
        .put("id", h.id)
        .put("scan_id", h.scanId)
        .put("source", h.source)
        .put("at_jst", h.atJst)
        .put("instrument", h.instrument)
        .put("direction", h.direction)
        .put("grade", h.grade)
        .put("decision", h.decision)
        .put("candidate_rank", h.candidateRank)
        .put("regime", h.regime)
        .put("entry_time_jst", h.entryTimeJst)
        .put("judge_time_jst", h.judgeTimeJst)
        .put("entry_rate", h.entryRate ?: JSONObject.NULL)
        .put("judge_rate", h.judgeRate ?: JSONObject.NULL)
        .put("entry_rate_source", h.entryRateSource)
        .put("judge_rate_source", h.judgeRateSource)
        .put("entry_captured_at_jst", h.entryCapturedAtJst)
        .put("settled_at_jst", h.settledAtJst)
        .put("entry_capture_delay_ms", h.entryCaptureDelayMs ?: JSONObject.NULL)
        .put("judge_capture_delay_ms", h.judgeCaptureDelayMs ?: JSONObject.NULL)
        .put("entry_provider_age_seconds", h.entryProviderAgeSeconds ?: JSONObject.NULL)
        .put("judge_provider_age_seconds", h.judgeProviderAgeSeconds ?: JSONObject.NULL)
        .put("result_status", h.resultStatus)
        .put("assessment", AssessmentJsonCodec.encode(h.assessment) ?: JSONObject.NULL)

    private fun persistCriticalRow(row: HistoryRow) {
        if (row.scanId.isBlank()) return
        synchronized(journalLock) {
            val rows = decodeCriticalRows().toMutableList()
            rows.removeAll { it.scanId == row.scanId }
            rows.add(0, row)
            val a = JSONArray()
            rows.take(MAX_CRITICAL_ROWS).forEach { a.put(rowToJson(it)) }
            val startedNanos = System.nanoTime()
            val ok = journalPrefs.edit().putString(CRITICAL_ROW_KEY, a.toString()).commit()
            lastJournalCommitDurationMs.set((System.nanoTime() - startedNanos) / 1_000_000L)
            if (!ok) journalFailureCount.incrementAndGet()
        }
    }

    private fun decodeCriticalRows(text: String? = journalPrefs.getString(CRITICAL_ROW_KEY, null)): List<HistoryRow> {
        if (text == null) return emptyList()
        val objects = mutableListOf<JSONObject>()
        try {
            if (text.trimStart().startsWith("[")) {
                val a = JSONArray(text)
                for (i in 0 until a.length()) a.optJSONObject(i)?.let(objects::add)
            } else {
                // Backward-compatible with the single-row v0.7.24 pre-release journal.
                objects += JSONObject(text)
            }
        } catch (_: Exception) {
            return emptyList()
        }
        return objects.mapNotNull { x -> decodeHistoryRowObject(x) }.take(MAX_CRITICAL_ROWS)
    }

    private fun decodeHistoryRowObject(x: JSONObject): HistoryRow? {
        val instrument = x.optString("instrument")
        val direction = x.optString("direction")
        val grade = x.optString("grade", "E").uppercase()
        val decision = x.optString("decision", "SKIP").uppercase()
        if (instrument.isBlank() || direction !in setOf("HIGH", "LOW") || !isKnownGrade(grade) || decision !in setOf("ENTRY", "SKIP")) return null
        return normalizeDecodedRow(HistoryRow(
            id = x.optLong("id").takeIf { it > 0L } ?: System.currentTimeMillis(),
            scanId = x.optString("scan_id", ""), source = x.optString("source"), atJst = x.optString("at_jst"),
            policyVersion = x.optString("policy_version", "LEGACY_UNVERSIONED"),
            instrument = instrument, direction = direction, grade = grade, decision = decision,
            candidateRank = x.optInt("candidate_rank", 1).coerceAtLeast(1), regime = x.optString("regime", "UNKNOWN"),
            entryTimeJst = x.optString("entry_time_jst", ""), judgeTimeJst = x.optString("judge_time_jst", ""),
            entryRate = x.optDouble("entry_rate").takeIf { x.has("entry_rate") && !x.isNull("entry_rate") },
            judgeRate = x.optDouble("judge_rate").takeIf { x.has("judge_rate") && !x.isNull("judge_rate") },
            entryRateSource = x.optString("entry_rate_source", ""), judgeRateSource = x.optString("judge_rate_source", ""),
            entryCapturedAtJst = x.optString("entry_captured_at_jst", ""), settledAtJst = x.optString("settled_at_jst", ""),
            entryCaptureDelayMs = x.optLong("entry_capture_delay_ms").takeIf { x.has("entry_capture_delay_ms") && !x.isNull("entry_capture_delay_ms") },
            judgeCaptureDelayMs = x.optLong("judge_capture_delay_ms").takeIf { x.has("judge_capture_delay_ms") && !x.isNull("judge_capture_delay_ms") },
            entryProviderAgeSeconds = x.optDouble("entry_provider_age_seconds").takeIf { x.has("entry_provider_age_seconds") && !x.isNull("entry_provider_age_seconds") },
            judgeProviderAgeSeconds = x.optDouble("judge_provider_age_seconds").takeIf { x.has("judge_provider_age_seconds") && !x.isNull("judge_provider_age_seconds") },
            resultStatus = x.optString("result_status", if (decision == "ENTRY") "WAIT_ENTRY" else "SKIP"),
            assessment = AssessmentJsonCodec.decode(x.optJSONObject("assessment"))
        ))
    }

    private fun normalizeDecodedRow(row: HistoryRow): HistoryRow {
        fun validPrice(value: Double?) = value?.takeIf { it.isFinite() && it > 0.0 }
        fun validAge(value: Double?) = value?.takeIf { it.isFinite() && it >= 0.0 }
        val entry = validPrice(row.entryRate)
        val judge = validPrice(row.judgeRate)
        val invalidPrice = (row.entryRate != null && entry == null) || (row.judgeRate != null && judge == null)
        val missingRequired = when (row.resultStatus) {
            "WIN", "LOSE" -> entry == null || judge == null
            "WAIT_JUDGE" -> entry == null
            else -> false
        }
        val pendingTimingInvalid = row.decision == "ENTRY" && row.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") && runCatching {
            val entryAt = java.time.ZonedDateTime.parse(row.entryTimeJst)
            val judgeAt = java.time.ZonedDateTime.parse(row.judgeTimeJst)
            val duration = java.time.Duration.between(entryAt, judgeAt)
            row.scanId.isBlank() || row.instrument !in setOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY") ||
                duration.nano != 0 || duration.seconds !in setOf(60L, 180L, 300L, 600L, 900L)
        }.getOrDefault(true)
        return row.copy(
            // An explanatory snapshot must describe the saved action, never replace it.
            // Keep a valid historical row even if optional assessment metadata is broken.
            assessment = row.assessment?.takeIf { a ->
                val selected = a.chosenAction
                selected.instrument == row.instrument && selected.direction == row.direction &&
                    selected.operationalGrade == row.grade && selected.decision == row.decision &&
                    a.operationalGrade == row.grade && a.decision == row.decision &&
                    runCatching {
                        val duration = java.time.Duration.between(
                            java.time.ZonedDateTime.parse(row.entryTimeJst),
                            java.time.ZonedDateTime.parse(row.judgeTimeJst))
                        duration.nano == 0 && duration.seconds == selected.judgeMinutes * 60L
                    }.getOrDefault(false)
            }?.let { a ->
                val chart = a.chartRank
                val boundary = runCatching { java.time.ZonedDateTime.parse(row.entryTimeJst).toEpochSecond() }.getOrNull()
                // A corrupt optional chart snapshot cannot relabel another saved entry.
                if (chart != null && (chart.queryBoundaryUtc != boundary || chart.direction != row.direction))
                    a.copy(chartRank = null) else a
            },
            entryRate = entry,
            judgeRate = judge,
            entryProviderAgeSeconds = validAge(row.entryProviderAgeSeconds),
            judgeProviderAgeSeconds = validAge(row.judgeProviderAgeSeconds),
            entryCaptureDelayMs = row.entryCaptureDelayMs?.takeIf { it >= 0L },
            judgeCaptureDelayMs = row.judgeCaptureDelayMs?.takeIf { it >= 0L },
            resultStatus = when {
                row.decision == "ENTRY" && (invalidPrice || missingRequired) -> "INVALID_RATE_DATA"
                pendingTimingInvalid -> "INVALID_TIMING_DATA"
                else -> row.resultStatus
            }
        )
    }

    private fun mergeCriticalRow(rows: List<HistoryRow>, criticalRows: List<HistoryRow>): List<HistoryRow> {
        if (criticalRows.isEmpty()) return rows
        val out = rows.toMutableList()
        // Journal order is newest first. Replace existing rows or prepend missing rows.
        for (critical in criticalRows.asReversed()) {
            if (critical.scanId.isBlank()) continue
            val idx = out.indexOfFirst { it.scanId == critical.scanId }
            if (idx >= 0) out[idx] = critical else out.add(0, critical)
        }
        return out.take(MAX_HISTORY_ROWS)
    }

    private fun save(rows: List<HistoryRow>, criticalRow: HistoryRow) {
        // Update in-memory history immediately, then coalesce disk writes to the newest
        // snapshot. This prevents a backlog of 20k-row JSON serializations during busy
        // periods while keeping main-thread AUTO timing free from disk I/O.
        val snapshot = rows.toList()
        cache = snapshot
        lastPublishedAtMs.set(System.currentTimeMillis())
        _rows.value = snapshot
        // Mutations run on IO. Publish before waiting for the tiny durable crash journal,
        // then enqueue the large disk snapshot only after the journal is durable.
        try {
            persistCriticalRow(criticalRow)
        } catch (error: Exception) {
            journalFailureCount.incrementAndGet()
            lastPersistError.set("Critical journal: ${(error.message ?: error::class.java.simpleName).take(140)}")
        }
        pendingWrite.set(snapshot)
        scheduleWriterIfNeeded()
    }

    private fun scheduleWriterIfNeeded() {
        if (!writerScheduled.compareAndSet(false, true)) return
        ioExecutor.execute {
            var terminalFailure = false
            try {
                while (true) {
                    val snapshot = pendingWrite.getAndSet(null) ?: break
                    var persisted = false
                    var attempt = 0
                    while (!persisted && attempt < 3) {
                        attempt++
                        persisted = persistSnapshot(snapshot)
                        if (!persisted && attempt < 3) {
                            try {
                                Thread.sleep(250L * attempt)
                            } catch (_: InterruptedException) {
                                Thread.currentThread().interrupt()
                                break
                            }
                        }
                    }
                    if (!persisted) {
                        // Keep the newest failed snapshot available for the next mutation/retry.
                        pendingWrite.compareAndSet(null, snapshot)
                        terminalFailure = true
                        break
                    }
                }
            } finally {
                writerScheduled.set(false)
                // Only self-reschedule after a successful drain. Persistent storage failures
                // must not create a hot retry loop; the next mutation will retry naturally.
                if (!terminalFailure && pendingWrite.get() != null) scheduleWriterIfNeeded()
            }
        }
    }

    private fun persistSnapshot(snapshot: List<HistoryRow>): Boolean {
        persistAttemptCount.incrementAndGet()
        return try {
            val a = JSONArray()
            snapshot.forEach { h -> a.put(rowToJson(h)) }
            val payload = a.toString()
            val previous = prefs.getString("items", null)
            val editor = prefs.edit()
            val nowMs = System.currentTimeMillis()
            val lastBackupAt = prefs.getLong("items_backup_at_ms", 0L)
            val backupDue = lastBackupAt <= 0L || nowMs - lastBackupAt >= BACKUP_INTERVAL_MS
            if (backupDue && !previous.isNullOrBlank()) {
                try {
                    JSONArray(previous)
                    editor.putString("items_backup", previous)
                    editor.putLong("items_backup_at_ms", nowMs)
                } catch (_: Exception) {
                    // Never promote a corrupt primary into backup.
                }
            }
            editor.putString("items", payload)
            editor.putBoolean("history_recovered_from_backup", false)
            val ok = editor.commit()
            if (!ok) throw IllegalStateException("SharedPreferences commit returned false")
            persistSuccessCount.incrementAndGet()
            lastPersistSuccessMs.set(System.currentTimeMillis())
            lastPersistError.set(null)
            // Clear the crash journal only when the persisted snapshot contains the same
            // latest state. A newer concurrent journal entry must never be discarded.
            synchronized(journalLock) {
                val remainingCritical = decodeCriticalRows().filterNot { critical ->
                    val matched = snapshot.firstOrNull { it.scanId == critical.scanId }
                    matched != null && matched.resultStatus == critical.resultStatus &&
                        matched.entryRate == critical.entryRate && matched.judgeRate == critical.judgeRate
                }
                if (remainingCritical.isEmpty()) {
                    journalPrefs.edit().remove(CRITICAL_ROW_KEY).apply()
                } else {
                    val ca = JSONArray()
                    remainingCritical.take(MAX_CRITICAL_ROWS).forEach { ca.put(rowToJson(it)) }
                    journalPrefs.edit().putString(CRITICAL_ROW_KEY, ca.toString()).apply()
                }
            }
            true
        } catch (t: Exception) {
            persistFailureCount.incrementAndGet()
            lastPersistError.set((t.message ?: t::class.java.simpleName).take(180))
            false
        }
    }

    companion object {
        private val JOURNAL_LOCK = Any()
        private const val MAX_HISTORY_ROWS = 20_000
        private const val MAX_CRITICAL_ROWS = 16
        private const val BACKUP_INTERVAL_MS = 5L * 60L * 1000L
        private const val CRITICAL_ROW_KEY = "critical_row_journal"
    }
}

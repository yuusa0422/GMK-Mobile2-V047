package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * v0.7.43 3-minute operating session (JST): 09:00-22:59 every day (last ENTRY boundary 22:55).
 * Monday..Friday use all six instruments; Saturday/Sunday use BTCJPY only (FX market closed).
 * Whether a scanned signal may actually ENTER is decided separately by [EvidencePolicy].
 */
object TradingSession {
    const val LABEL = "09:00-23:00"
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    val FX = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY")
    val ALL = FX + "BTCJPY"
    val CRYPTO_ONLY = listOf("BTCJPY")

    private fun jst(t: ZonedDateTime): ZonedDateTime = t.withZoneSameInstant(JST)

    fun isActive(t: ZonedDateTime): Boolean = jst(t).hour in 9..22

    fun isWeekday(t: ZonedDateTime): Boolean = jst(t).dayOfWeek.value <= 5

    fun fxOpen(t: ZonedDateTime): Boolean = isActive(t) && isWeekday(t)

    fun requiredInstruments(t: ZonedDateTime): List<String> = if (fxOpen(t)) ALL else CRYPTO_ONLY
}

package jp.gmk.mobile.domain

import kotlin.math.ln
import kotlin.math.ln1p
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * v0.7.44 model inputs. Exact port of scripts/policy_data.py + evidence_model.py:design().
 *
 * Window: the 61 contiguous one-minute candles whose opens are B-3720s .. B-120s (the same rows as
 * OctoberSimilarityScanAdapter.featureRows). Live price: the newest quote taken about 10 s before B
 * (backtest proxy: close of the candle opening at B-60s). Every value is a double; sums run in index order.
 */
object EvidenceFeatures {
    val FX4 = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY")
    val INSTRUMENTS = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
    val REGIMES = listOf("RANGE", "TREND_UP", "TREND_DOWN", "CHOPPY")
    const val FEATURE_COUNT = 46

    /** Per-instrument values that do not depend on the trade direction or on other instruments. */
    data class Instrument(
        val instrument: String,
        val r1: Double, val r3: Double, val r5: Double, val r10: Double, val r15: Double, val r30: Double, val r60: Double,
        val rv60: Double, val rv30over60: Double, val pos15: Double, val pos60: Double, val bbz: Double,
        val hasLive: Boolean, val f1: Double, val f2: Double, val f5: Double, val f15: Double, val pos15Live: Double, val bbzLive: Double,
        val tie58: Double, val zero30: Double, val vol10: Double, val rvJpy: Double
    )

    /** Cross-sectional yen factor of the four major crosses (all zero unless all four are present). */
    data class YenFactor(val yen5: Double, val yen15: Double, val yenF1: Double)

    fun window(candles: List<Candle>, boundaryEpochSec: Long): List<Candle>? {
        val lastMs = (boundaryEpochSec - 120L) * 1000L
        val sorted = candles.filter { it.timeEpochMs <= lastMs }.sortedBy { it.timeEpochMs }.distinctBy { it.timeEpochMs }
        if (sorted.size < 61) return null
        val w = sorted.takeLast(61)
        for (i in w.indices) if (w[i].timeEpochMs != (boundaryEpochSec - 3720L + i * 60L) * 1000L) return null
        if (w.any { !(it.open > 0.0 && it.high > 0.0 && it.low > 0.0 && it.close > 0.0) || !it.close.isFinite() }) return null
        return w
    }

    fun instrument(name: String, candles: List<Candle>, boundaryEpochSec: Long, live: Double?): Instrument? {
        val w = window(candles, boundaryEpochSec) ?: return null
        val o = DoubleArray(61) { w[it].open }; val h = DoubleArray(61) { w[it].high }; val l = DoubleArray(61) { w[it].low }
        val c = DoubleArray(61) { w[it].close }; val v = DoubleArray(61) { w[it].volume }
        val lg = DoubleArray(61) { ln(c[it]) }
        val ret = DoubleArray(60) { lg[it + 1] - lg[it] }
        var s60 = 0.0; for (x in ret) s60 += x * x
        val norm = max(sqrt(s60 / 60.0), 1e-8)
        var s30 = 0.0; for (k in 30 until 60) s30 += ret[k] * ret[k]
        val rv30 = sqrt(s30 / 30.0)
        fun r(k: Int) = (lg[60] - lg[60 - k]) / (norm * sqrt(k.toDouble()))
        var hi15 = h[46]; var lo15 = l[46]
        for (k in 47..60) { hi15 = max(hi15, h[k]); lo15 = min(lo15, l[k]) }
        val rg15 = max(hi15 - lo15, 1e-12)
        var hi60 = h[0]; var lo60 = l[0]
        for (k in 1..60) { hi60 = max(hi60, h[k]); lo60 = min(lo60, l[k]) }
        var m = 0.0; for (k in 41..60) m += c[k]
        val m20 = m / 20.0
        var q = 0.0; for (k in 41..60) q += (c[k] - m20) * (c[k] - m20)
        val sd20 = sqrt(max(q / 20.0, 1e-16))
        val btc = name == "BTCJPY"
        var ties = 0; var zeros = 0; var vs = 0.0
        if (btc) {
            for (k in 3..60) if (o[k] == o[k - 3]) ties++
            for (k in 31..60) if (c[k] == c[k - 1]) zeros++
            for (k in 51..60) vs += v[k]
        }
        val liveOk = live != null && live.isFinite() && live > 0.0
        val ll = if (liveOk) ln(live!!) else 0.0
        val hiL = if (liveOk) max(hi15, live!!) else 0.0; val loL = if (liveOk) min(lo15, live!!) else 0.0
        return Instrument(
            instrument = name,
            r1 = r(1), r3 = r(3), r5 = r(5), r10 = r(10), r15 = r(15), r30 = r(30), r60 = r(60),
            rv60 = norm * 1e4, rv30over60 = rv30 / norm,
            pos15 = (c[60] - lo15) / rg15 * 2 - 1,
            pos60 = (c[60] - lo60) / max(hi60 - lo60, 1e-12) * 2 - 1,
            bbz = (c[60] - m20) / sd20,
            hasLive = liveOk,
            f1 = if (liveOk) (ll - lg[60]) / norm else 0.0,
            f2 = if (liveOk) (ll - lg[59]) / (norm * sqrt(2.0)) else 0.0,
            f5 = if (liveOk) (ll - lg[56]) / (norm * sqrt(5.0)) else 0.0,
            f15 = if (liveOk) (ll - lg[46]) / (norm * sqrt(15.0)) else 0.0,
            pos15Live = if (liveOk) (live!! - loL) / max(hiL - loL, 1e-12) * 2 - 1 else 0.0,
            bbzLive = if (liveOk) (live!! - m20) / sd20 else 0.0,
            tie58 = if (btc) ties / 58.0 else 0.0,
            zero30 = if (btc) zeros / 30.0 else 0.0,
            vol10 = if (btc) ln1p(vs / 10.0) else 0.0,
            rvJpy = if (btc) norm * c[60] else 0.0
        )
    }

    fun yenFactor(byInstrument: Map<String, Instrument>): YenFactor {
        val fx = FX4.mapNotNull { byInstrument[it] }
        if (fx.size != 4) return YenFactor(0.0, 0.0, 0.0)
        var a = 0.0; var b = 0.0; var c = 0.0
        for (x in fx) { a += x.r5; b += x.r15; c += x.f1 }
        return YenFactor(a / 4.0, b / 4.0, c / 4.0)
    }

    fun gradeValue(grade: String): Double = when (grade.uppercase()) { "S" -> 4.0; "A" -> 3.0; "B" -> 2.0; "C" -> 1.0; else -> 0.0 }

    /**
     * Direction-relative design row (feature order = EvidenceModelData.FEATURES).
     * [direction] +1 = HIGH, -1 = LOW. [fresh] false zeroes the live-price block (backup model).
     */
    fun design(x: Instrument, yen: YenFactor, native: ScanCandidate, hourJst: Int, weekend: Boolean, direction: Int, fresh: Boolean): DoubleArray {
        val d = direction.toDouble()
        val btc = x.instrument == "BTCJPY"
        val yen5 = if (btc) 0.0 else yen.yen5; val yen15 = if (btc) 0.0 else yen.yen15; val yenF1 = if (btc) 0.0 else yen.yenF1
        val idio5 = if (btc) 0.0 else x.r5 - yen5
        val idio15 = if (btc) 0.0 else x.r15 - yen15
        val idioF1 = if (btc) 0.0 else x.f1 - yenF1
        val appDir = if (native.direction == "HIGH") 1.0 else -1.0
        val out = DoubleArray(FEATURE_COUNT)
        var i = 0
        fun put(v: Double) { out[i++] = v }
        // signed
        put(x.r1 * d); put(x.r3 * d); put(x.r5 * d); put(x.r10 * d); put(x.r15 * d); put(x.r30 * d); put(x.r60 * d)
        put(x.pos15 * d); put(x.pos60 * d); put(x.bbz * d)
        put(yen5 * d); put(idio5 * d); put(yen15 * d); put(idio15 * d); put(appDir * d); put(native.score * d)
        // signed, live price block
        if (fresh) {
            put(x.f1 * d); put(x.f2 * d); put(x.f5 * d); put(x.f15 * d); put(x.pos15Live * d); put(x.bbzLive * d); put(yenF1 * d); put(idioF1 * d)
        } else repeat(8) { put(0.0) }
        // unsigned
        put(x.rv60); put(x.rv30over60); put(x.tie58); put(x.zero30); put(x.vol10); put(x.rvJpy)
        put(gradeValue(native.grade)); put(native.probability ?: Double.NaN); put(native.regimeConfidence)
        put(hourJst.toDouble()); put(if (weekend) 1.0 else 0.0)
        for (s in INSTRUMENTS) put(if (x.instrument == s) 1.0 else 0.0)
        for (rg in REGIMES) put(if (native.regime == rg) 1.0 else 0.0)
        put(d)
        check(i == FEATURE_COUNT)
        return out
    }
}

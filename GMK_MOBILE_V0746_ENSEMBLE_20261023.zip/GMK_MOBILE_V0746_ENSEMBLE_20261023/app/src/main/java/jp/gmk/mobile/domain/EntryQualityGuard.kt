package jp.gmk.mobile.domain

/**
 * v0.7.43 final entry-quality guard. It runs after every optional overlay and can only
 * DEMOTE the published TOP1 ENTRY to E/SKIP. It never promotes, reorders, changes a
 * direction, an instrument or a judge time.
 *
 * 1) C_NON_REVERSE: the native TOP1 was grade C and its rule did not reverse the raw
 *    momentum score. Out-of-sample checks (Oct 1-8 2026 real candles 4FX 09-15:
 *    64/137 = 46.7% when entered, Jul-Aug 2026 replay also below the other trades)
 *    showed this group is the weakest part of the native policy.
 * 2) TREND_SWITCH_COUNTER: the engine already documents "TREND_SWITCH_GUARD ... D/SKIP"
 *    for a counter-trend candidate immediately after a confirmed EMA switch, but the
 *    rank tables could still rescue it to an ENTRY grade. The documented SKIP is enforced.
 *
 * Both signals are read from the native TOP1 reasons that LocalRuleEngine writes
 * deterministically, so the native engine itself stays byte-for-byte identical.
 */
object EntryQualityGuard {
    const val VERSION = "V0743_ENTRY_QUALITY_GUARD"
    const val REVERSE_TAG = "V076_DIRECTION_REVERSE"
    const val SWITCH_TAG = "TREND_SWITCH_GUARD:"

    fun reason(nativeTop: ScanCandidate?): CandidateSkipReason? {
        if (nativeTop == null || nativeTop.decision != "ENTRY") return null
        if (nativeTop.reasons.any { it.startsWith(SWITCH_TAG) }) return CandidateSkipReason.TREND_SWITCH_COUNTER
        if (nativeTop.grade.uppercase() == "C" && nativeTop.reasons.none { it.startsWith(REVERSE_TAG) })
            return CandidateSkipReason.C_NON_REVERSE
        return null
    }

    fun apply(native: ScanResult, result: ScanResult): ScanResult {
        val skip = reason(native.top1) ?: return result
        val top = result.top1 ?: return result
        if (top.decision != "ENTRY") return result
        val note = "$VERSION: ${skip.label} -> E/SKIP"
        val assessment = top.assessment?.let { a ->
            a.copy(
                operationalGrade = "E",
                decision = "SKIP",
                skipReason = skip,
                chosenAction = a.chosenAction.copy(operationalGrade = "E", decision = "SKIP")
            )
        }
        val updated = top.copy(grade = "E", decision = "SKIP", reasons = top.reasons + note, assessment = assessment)
        return result.copy(candidates = result.candidates.map { if (it.rank == top.rank) updated else it })
    }
}

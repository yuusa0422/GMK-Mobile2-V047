import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.october.OctoberSimilarityScanAdapter
import org.junit.Assert.*
import org.junit.Test
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** v0.7.43 demote-only guard: unit contract plus the real October 432-frame replay. */
class EntryQualityGuardTest {
    private fun candidate(rank: Int, instrument: String, grade: String, decision: String, reasons: List<String>) =
        ScanCandidate(rank, instrument, instrument, "HIGH", grade, 0.6, decision, 0.2, "RANGE", 0.6, reasons)

    private fun result(vararg c: ScanCandidate) =
        ScanResult(scanId = "s", atJst = "2026-10-01T09:59:50+09:00", entryTimeJst = "2026-10-01T10:00+09:00",
            judgeTimeJst = "2026-10-01T10:03+09:00", candidates = c.toList(), source = "AUTO")

    @Test fun cNonReverseIsDemotedAndEverythingElseIsKept() {
        val cPlain = result(candidate(1, "USDJPY", "C", "ENTRY", listOf("V076_FIXED_RULE id=1")), candidate(2, "EURJPY", "B", "ENTRY", emptyList()))
        val guarded = EntryQualityGuard.apply(cPlain, cPlain)
        assertEquals("E", guarded.top1!!.grade)
        assertEquals("SKIP", guarded.top1!!.decision)
        assertEquals("USDJPY", guarded.top1!!.instrument)
        assertEquals("HIGH", guarded.top1!!.direction)
        assertTrue(guarded.top1!!.reasons.last().startsWith(EntryQualityGuard.VERSION))
        assertEquals(cPlain.candidates[1], guarded.candidates[1])
        assertEquals(cPlain.judgeTimeJst, guarded.judgeTimeJst)

        val cReverse = result(candidate(1, "USDJPY", "C", "ENTRY", listOf("${EntryQualityGuard.REVERSE_TAG} historical losing-pattern inversion")))
        assertSame(cReverse, EntryQualityGuard.apply(cReverse, cReverse))
        val b = result(candidate(1, "USDJPY", "B", "ENTRY", emptyList()))
        assertSame(b, EntryQualityGuard.apply(b, b))
        val skip = result(candidate(1, "USDJPY", "E", "SKIP", emptyList()))
        assertSame(skip, EntryQualityGuard.apply(skip, skip))
    }

    @Test fun counterTrendSwitchIsSkippedAsDocumented() {
        val r = result(candidate(1, "GBPJPY", "B", "ENTRY", listOf("${EntryQualityGuard.SWITCH_TAG} 新トレンド逆方向のためD/SKIP",
            "${EntryQualityGuard.REVERSE_TAG} historical losing-pattern inversion")))
        assertEquals(CandidateSkipReason.TREND_SWITCH_COUNTER, EntryQualityGuard.reason(r.top1))
        assertEquals("SKIP", EntryQualityGuard.apply(r, r).top1!!.decision)
    }

    @Test fun correctedActionFromNativeCNonReverseIsAlsoSkipped() {
        val native = result(candidate(1, "AUDJPY", "C", "ENTRY", emptyList()), candidate(2, "GBPJPY", "C", "ENTRY", emptyList()))
        val corrected = result(candidate(1, "GBPJPY", "C", "ENTRY", listOf("C判定のAI補正")), candidate(2, "AUDJPY", "C", "ENTRY", emptyList()))
        val guarded = EntryQualityGuard.apply(native, corrected)
        assertEquals("GBPJPY", guarded.top1!!.instrument)
        assertEquals("SKIP", guarded.top1!!.decision)
        assertEquals(corrected.candidates[1], guarded.candidates[1])
    }

    @Test fun octoberSimilarityDoesNotReactivateInLaterYears() {
        assertFalse(OctoberSimilarityScanAdapter.supports(ZonedDateTime.parse("2027-10-05T10:00:00+09:00").toEpochSecond()))
    }

    @Test fun realOctoberReplayKeepsNativeAndDemotesOnlyGuardedTop1() {
        val stream = javaClass.classLoader!!.getResourceAsStream("rank_assessment_native_october.bin.gz")
        assertNotNull("Missing recorded native replay fixture", stream)
        val engine = LocalRuleEngine()
        val grades = mutableMapOf<String, Int>()
        val guardReasons = mutableMapOf<CandidateSkipReason, Int>()
        var entries = 0
        DataInputStream(BufferedInputStream(GZIPInputStream(stream!!))).use { input ->
            assertEquals(0x474D4B41, input.readInt())
            val frames = input.readInt()
            assertEquals(432, frames)
            repeat(frames) {
                val boundary = input.readLong()
                val candles = mutableMapOf<String, List<Candle>>()
                repeat(input.readInt()) {
                    val instrument = input.readUTF()
                    candles[instrument] = List(input.readInt()) {
                        Candle(input.readLong(), input.readDouble(), input.readDouble(), input.readDouble(), input.readDouble(), input.readDouble())
                    }
                }
                val entry = Instant.ofEpochSecond(boundary).atZone(ZoneId.of("Asia/Tokyo"))
                val native = engine.scan(candles, "AUTO", entry.minusSeconds(10), entry)
                val guarded = EntryQualityGuard.apply(native, native)
                assertEquals(native.candidates.size, guarded.candidates.size)
                native.candidates.zip(guarded.candidates).forEach { (a, g) ->
                    if (a.rank != 1) assertEquals(a, g)
                }
                val top = guarded.top1 ?: return@repeat
                val nativeTop = native.top1!!
                val reason = EntryQualityGuard.reason(nativeTop)
                if (reason == null) assertEquals(nativeTop, top) else {
                    guardReasons[reason] = guardReasons.getOrDefault(reason, 0) + 1
                    assertEquals(nativeTop.instrument, top.instrument)
                    assertEquals(nativeTop.direction, top.direction)
                    assertEquals("E", top.grade)
                    assertEquals("SKIP", top.decision)
                    assertEquals(reason, top.assessment!!.skipReason)
                    assertEquals("SKIP", top.assessment!!.chosenAction.decision)
                }
                if (top.decision == "ENTRY") {
                    entries++
                    if (top.grade == "C") assertTrue(top.reasons.any { it.startsWith(EntryQualityGuard.REVERSE_TAG) })
                }
                grades[top.grade] = grades.getOrDefault(top.grade, 0) + 1
            }
            assertEquals(-1, input.read())
        }
        // Native before guard: A6 B94 C207 E47 (307 ENTRY). 140 C non-reverse TOP1 are demoted.
        assertEquals(167, entries)
        assertEquals(mapOf("A" to 6, "B" to 94, "C" to 67, "E" to 187), grades)
        assertEquals(mapOf(CandidateSkipReason.C_NON_REVERSE to 140), guardReasons)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.abs
import kotlin.math.max

/** v0.7.46: the Kotlin features, the five-model averages and the slot choice reproduce the Python research pipeline on real slots. */
class EvidenceModelParityTest {
    private fun close(a: Double, b: Double, tol: Double = 1e-9) = abs(a - b) <= tol * max(1.0, abs(b))

    @Test fun bothModelsLoadWithPinnedHashAndShape() {
        assertEquals(46, EvidenceModelData.FEATURES.size)
        assertEquals(EvidenceFeatures.FEATURE_COUNT, EvidenceModelData.FEATURES.size)
        assertEquals(5, EvidenceEnsemble.fresh.members.size)
        assertEquals(5 * 150, EvidenceEnsemble.fresh.treeCount)
        assertEquals(5 * 150, EvidenceEnsemble.fallback.treeCount)
        assertEquals(EvidenceModelData.FRESH_SHA256, EvidenceModelData.freshTexts().map { EvidenceTreeModel.sha256(it) })
        assertEquals(EvidenceModelData.FALLBACK_SHA256, EvidenceModelData.fallbackTexts().map { EvidenceTreeModel.sha256(it) })
        assertEquals(5, EvidenceModelData.FRESH_SHA256.toSet().size)
        try { EvidenceTreeModel.parse(EvidenceModelData.freshTexts()[2] + "L|0.0\n", EvidenceModelData.FRESH_SHA256[2], 46); fail("tampered model accepted") }
        catch (e: IllegalStateException) { assertEquals("EVIDENCE_MODEL_SHA", e.message) }
    }

    @Test fun instrumentFeaturesMatchPython() {
        var n = 0
        for (s in EvidenceFixture.slots) for (c in s.cands) {
            val x = EvidenceFeatures.instrument(c.instrument, s.bars.getValue(c.instrument), s.boundary, c.live)
            assertNotNull("${s.boundary} ${c.instrument} window", x)
            val got = EvidenceFixture.values(x!!); val want = s.features.getValue(c.instrument)
            for (k in want.indices) assertTrue("${s.boundary} ${c.instrument} ${EvidenceFixture.FEATURE_KEYS[k]} ${got[k]} vs ${want[k]}", close(got[k], want[k]))
            n++
        }
        assertTrue(n >= 100)
    }

    @Test fun designRowsAndProbabilitiesMatchPython() {
        for (s in EvidenceFixture.slots) for (fresh in listOf(true, false)) {
            val tag = if (fresh) "fresh" else "fallback"
            val feats = s.cands.associate { c ->
                c.instrument to EvidenceFeatures.instrument(c.instrument, s.bars.getValue(c.instrument), s.boundary, if (fresh) c.live else null)!!
            }
            val yen = EvidenceFeatures.yenFactor(feats)
            val native = s.native()
            for (c in native.candidates) {
                val hi = EvidenceFeatures.design(feats.getValue(c.instrument), yen, c, s.hour, s.weekend, 1, fresh)
                val lo = EvidenceFeatures.design(feats.getValue(c.instrument), yen, c, s.hour, s.weekend, -1, fresh)
                val want = s.designHigh.getValue("$tag|${c.instrument}")
                for (k in want.indices) assertTrue("${s.boundary} $tag ${c.instrument} ${EvidenceModelData.FEATURES[k]} ${hi[k]} vs ${want[k]}", close(hi[k], want[k]))
                val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback
                val (pHi, pLo) = s.probs.getValue("$tag|${c.instrument}")
                assertTrue("$tag p HIGH ${c.instrument}", close(model.probability(hi), pHi, 1e-10))
                assertTrue("$tag p LOW ${c.instrument}", close(model.probability(lo), pLo, 1e-10))
            }
        }
    }

    @Test fun slotChoiceMatchesPythonWithAndWithoutLivePrice() {
        for (s in EvidenceFixture.slots) {
            val fresh = EvidencePolicy.choose(s.native(), s.candles(), s.quotes(), s.entry)!!
            val wf = s.best.getValue("fresh")
            assertTrue(fresh.fresh)
            assertEquals("${s.boundary}", wf.instrument, fresh.instrument); assertEquals(wf.direction, fresh.direction)
            assertTrue(close(fresh.probability, wf.p, 1e-10)); assertTrue(close(fresh.adjusted, wf.adjusted, 1e-10))
            val backup = EvidencePolicy.choose(s.native(), s.candles(), emptyMap(), s.entry)!!
            val wb = s.best.getValue("fallback")
            assertFalse(backup.fresh)
            assertEquals("${s.boundary}", wb.instrument, backup.instrument); assertEquals(wb.direction, backup.direction)
            assertTrue(close(backup.probability, wb.p, 1e-10)); assertTrue(close(backup.adjusted, wb.adjusted, 1e-10))
            if (s.weekend) assertEquals("BTCJPY", fresh.instrument)
        }
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.random.Random

/** v0.7.44 final ENTRY decision: evidence model + rolling entry quota, weekday six instruments, weekend BTC. */
class EvidencePolicyTest {
    @Before fun reset() = EvidencePolicy.resetState()

    private fun contractHolds(r: ScanResult) {
        assertEquals((1..r.candidates.size).toSet(), r.candidates.map { it.rank }.toSet())
        assertTrue(r.candidates.all { it.direction in setOf("HIGH", "LOW") })
        assertTrue(r.candidates.all { (it.grade == "E" && it.decision == "SKIP") || (it.grade in setOf("S", "A", "B", "C") && it.decision == "ENTRY") })
    }

    @Test fun weekdaySlotPicksTheModelChoiceAsTop1AndKeepsAllSix() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val native = s.native()
        val out = EvidencePolicy.apply(native, native, s.candles(), s.quotes())
        contractHolds(out)
        assertEquals(6, out.candidates.size)
        val top = out.top1!!
        val want = s.best.getValue("fresh")
        assertEquals(want.instrument, top.instrument); assertEquals(want.direction, top.direction)
        assertEquals("判定: 3分", top.reasons.first())
        assertTrue(top.reasons[1].startsWith(EvidencePolicy.VERSION))
        assertEquals(s.entry.plusMinutes(3).toOffsetDateTime().toString(), out.judgeTimeJst)
        assertTrue(out.policyVersion.startsWith("GMK_V0740"))
        assertNotNull(top.assessment)
        assertEquals(top.grade, top.assessment!!.chosenAction.operationalGrade)
    }

    @Test fun weekendUsesBitcoinOnly() {
        val s = EvidenceFixture.slots.first { it.weekend }
        val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes())
        contractHolds(out)
        assertEquals(listOf("BTCJPY"), out.candidates.map { it.instrument })
    }

    @Test fun staleOrMissingLivePriceFallsBackToTheBackupModel() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val stale = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(ageMs = 45_000L))
        assertTrue(stale.warnings.any { it.contains("予備モデル") })
        assertTrue(stale.top1!!.reasons[1].contains("fallback"))
        assertEquals(s.best.getValue("fallback").instrument, stale.top1!!.instrument)
        val fresh = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(ageMs = 9_000L))
        assertTrue(fresh.top1!!.reasons[1].contains("fresh"))
        assertNull(EvidencePolicy.freshPrice(mapOf("USDJPY" to EvidencePolicy.LiveQuote(150.0, s.boundary * 1000L + 5_000L)), "USDJPY", s.boundary))
    }

    @Test fun rollingQuotaKeepsWeekdayAndWeekendEntryRates() {
        val rnd = Random(3)
        for ((weekend, rate) in listOf(false to EvidencePolicy.WEEKDAY_ENTRY_RATE, true to EvidencePolicy.WEEKEND_ENTRY_RATE)) {
            var entered = 0; var counted = 0; val grades = mutableMapOf<String, Int>()
            for (i in 0 until 3000) {
                val adj = rnd.nextDouble(-0.05, 0.05) + if (i > 1500) 0.02 else 0.0      // level shift: quota must adapt
                val d = EvidencePolicy.decide(EvidencePolicy.Choice("USDJPY", "HIGH", 0.5 + adj, adj, true), weekend, 1_800_000_000L + i * 300L, record = true)
                if (i >= 400) { counted++; if (d.enter) entered++; grades.merge(d.grade, 1, Int::plus) }
            }
            val share = entered.toDouble() / counted
            assertEquals("weekend=$weekend", rate, share, 0.03)
            assertEquals(0.25, grades.getValue("A").toDouble() / counted, 0.03)
            assertEquals(EvidencePolicy.bufferLimit(weekend), EvidencePolicy.bufferSize(true, weekend))
        }
        assertEquals(288, EvidencePolicy.WEEKDAY_BUFFER_SIZE)
        assertEquals(576, EvidencePolicy.WEEKEND_BUFFER_SIZE)
    }

    /** v0.7.45: the two-day weekend window moves entries from a quiet (draw-heavy) day to an active day. */
    @Test fun weekendWindowShiftsEntriesFromQuietToActiveDays() {
        val rnd = Random(9)
        var t = 1_900_000_000L
        fun feed(n: Int, lo: Double, hi: Double): Double {
            var e = 0
            repeat(n) {
                val adj = rnd.nextDouble(lo, hi)
                if (EvidencePolicy.decide(EvidencePolicy.Choice("BTCJPY", "HIGH", 0.5 + adj, adj, true), true, t, record = true).enter) e++
                t += 300L
            }
            return e.toDouble() / n
        }
        feed(576, -0.05, 0.05)                      // a normal weekend fills the window
        val quiet = feed(168, -0.05, 0.0)           // quiet day: weak slots
        val active = feed(168, 0.0, 0.05)           // active day: strong slots
        assertTrue("quiet=$quiet", quiet < 0.30)
        assertTrue("active=$active", active > 0.65)
        assertEquals(EvidencePolicy.WEEKEND_ENTRY_RATE, (quiet + active) / 2, 0.12)
    }

    @Test fun manualScansDoNotMoveTheRollingDistribution() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        EvidencePolicy.apply(s.native("MANUAL"), s.native("MANUAL"), s.candles(), s.quotes())
        assertEquals(0, EvidencePolicy.bufferSize(true, false))
        EvidencePolicy.apply(s.native("AUTO"), s.native("AUTO"), s.candles(), s.quotes())
        EvidencePolicy.apply(s.native("AUTO"), s.native("AUTO"), s.candles(), s.quotes())   // same boundary twice
        assertEquals(1, EvidencePolicy.bufferSize(true, false))
    }

    @Test fun outsideSessionAndBrokenInputsNeverEnter() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val night = s.native().let { n ->
            val t = ZonedDateTime.of(2026, 10, 20, 23, 30, 0, 0, ZoneId.of("Asia/Tokyo"))
            n.copy(entryTimeJst = t.toOffsetDateTime().toString())
        }
        val out = EvidencePolicy.apply(night, night, s.candles(), s.quotes())
        assertTrue(out.candidates.none { it.rank == 1 && it.decision == "ENTRY" })
        val empty = EvidencePolicy.apply(s.native(), s.native(), emptyMap(), s.quotes())
        assertEquals("SKIP", empty.top1!!.decision)
        contractHolds(empty)
    }

    @Test fun quantileMatchesNumpyLinear() {
        val v = listOf(5.0, 1.0, 3.0, 2.0, 4.0)
        assertEquals(1.0, EvidencePolicy.quantile(v, 0.0), 0.0)
        assertEquals(3.0, EvidencePolicy.quantile(v, 0.5), 0.0)
        assertEquals(2.04, EvidencePolicy.quantile(v, 0.26), 1e-12)
        assertEquals(5.0, EvidencePolicy.quantile(v, 1.0), 0.0)
    }
}

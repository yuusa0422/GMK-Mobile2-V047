import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.43 operating window: 09:00-23:00 every day; weekend universe is BTCJPY only. */
class TradingSessionTest {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun at(d: Int, h: Int, m: Int = 0) = ZonedDateTime.of(2026, 10, d, h, m, 0, 0, jst)

    @Test fun windowIsNineToTwentyThree() {
        assertFalse(TradingSession.isActive(at(21, 8, 55)))
        assertTrue(TradingSession.isActive(at(21, 9, 0)))
        assertTrue(TradingSession.isActive(at(21, 22, 55)))
        assertFalse(TradingSession.isActive(at(21, 23, 0)))
        assertFalse(TradingSession.isActive(at(22, 2, 0)))
    }

    @Test fun weekendRunsSameHours() {
        assertTrue(TradingSession.isActive(at(24, 9, 0)))     // Saturday
        assertTrue(TradingSession.isActive(at(25, 22, 55)))   // Sunday
        assertFalse(TradingSession.isActive(at(25, 23, 0)))
    }

    @Test fun weekdayNeedsAllSixWeekendBtcOnly() {
        assertEquals(TradingSession.ALL, TradingSession.requiredInstruments(at(23, 10, 0)))   // Friday
        assertEquals(listOf("BTCJPY"), TradingSession.requiredInstruments(at(24, 10, 0)))      // Saturday
        assertEquals(listOf("BTCJPY"), TradingSession.requiredInstruments(at(25, 15, 0)))      // Sunday
        assertEquals(TradingSession.ALL, TradingSession.requiredInstruments(at(26, 9, 0)))    // Monday
    }

    private fun series(base: Double, slope: Double, start: Long): List<Candle> = (0 until 80).map { i ->
        val o = base + slope * i + if (i % 3 == 0) slope else -slope * 0.5
        val c = o + slope * 0.4
        Candle(start + i * 60_000L, o, maxOf(o, c) + base * 0.0001, minOf(o, c) - base * 0.0001, c, 1.0)
    }

    @Test fun outsideSessionTheNativeEngineSkips() {
        val entry = at(21, 23, 30)
        val start = entry.toInstant().toEpochMilli() - 82 * 60_000L
        val map = TradingSession.ALL.withIndex().associate { (i, n) -> n to series(if (n == "BTCJPY") 1.7e7 else 100.0 + i * 10, if (i % 2 == 0) 0.01 else -0.008, start) }
        val r = LocalRuleEngine().scan(map, "AUTO", entry.minusSeconds(10), entry)
        assertEquals(6, r.candidates.size)
        assertTrue(r.candidates.all { it.decision == "SKIP" })
        assertEquals(CandidateSkipReason.TIME_WINDOW, r.top1!!.assessment!!.skipReason)
    }

    @Test fun weekendBtcOnlyUniverseProducesOneCandidate() {
        val entry = at(24, 12, 0)
        val start = entry.toInstant().toEpochMilli() - 82 * 60_000L
        val r = LocalRuleEngine().scan(mapOf("BTCJPY" to series(1.7e7, 900.0, start)), "AUTO", entry.minusSeconds(10), entry)
        assertEquals(1, r.candidates.size)
        assertEquals("BTCJPY", r.top1!!.instrument)
        assertEquals(1, r.top1!!.rank)
    }
}

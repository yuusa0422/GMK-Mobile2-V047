import jp.gmk.mobile.domain.*
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.zip.GZIPInputStream

/** Real one-year slots exported by scripts/gen_fixture.py (Python research pipeline = expected values). */
object EvidenceFixture {
    data class Cand(val instrument: String, val rank: Int, val direction: String, val grade: String, val probability: Double,
                    val score: Double, val regime: String, val regimeConfidence: Double, val decision: String, val live: Double)
    data class Best(val instrument: String, val direction: String, val p: Double, val adjusted: Double)
    class Slot(val boundary: Long, val weekend: Boolean, val hour: Int) {
        val cands = mutableListOf<Cand>()
        val bars = linkedMapOf<String, MutableList<Candle>>()
        val features = linkedMapOf<String, DoubleArray>()
        val probs = linkedMapOf<String, Pair<Double, Double>>()      // "fresh|USDJPY" -> (p HIGH, p LOW)
        val designHigh = linkedMapOf<String, DoubleArray>()          // "fresh|USDJPY" -> design row for HIGH
        val best = linkedMapOf<String, Best>()                       // "fresh" / "fallback"
        val entry: ZonedDateTime get() = ZonedDateTime.ofInstant(Instant.ofEpochSecond(boundary), ZoneId.of("Asia/Tokyo"))
        fun native(source: String = "AUTO"): ScanResult = ScanResult(
            scanId = "fx-$boundary", atJst = entry.minusSeconds(10).toOffsetDateTime().toString(),
            entryTimeJst = entry.toOffsetDateTime().toString(), judgeTimeJst = entry.plusMinutes(3).toOffsetDateTime().toString(),
            candidates = cands.sortedBy { it.rank }.map {
                ScanCandidate(it.rank, it.instrument, it.instrument, it.direction, it.grade, it.probability, it.decision,
                    it.score, it.regime, it.regimeConfidence, emptyList())
            }, source = source)
        fun candles(): Map<String, List<Candle>> = bars
        fun quotes(ageMs: Long = 10_000L): Map<String, EvidencePolicy.LiveQuote> =
            cands.associate { it.instrument to EvidencePolicy.LiveQuote(it.live, boundary * 1000L - ageMs) }
    }
    val FEATURE_KEYS = listOf("r1", "r3", "r5", "r10", "r15", "r30", "r60", "rv60", "rv30_60", "pos15", "pos60", "bbz", "f1", "f2", "f5", "f15",
        "pos15L", "bbzL", "tie58", "zero30", "vol10", "rvjpy")

    val slots: List<Slot> by lazy {
        val stream = javaClass.classLoader!!.getResourceAsStream("v0744_evidence_parity.txt.gz")!!
        val out = mutableListOf<Slot>(); var cur: Slot? = null
        GZIPInputStream(stream).bufferedReader().useLines { lines ->
            for (line in lines) {
                if (line.isBlank()) continue
                val p = line.split('|')
                when (p[0]) {
                    "SLOT" -> cur = Slot(p[1].toLong(), p[2] == "1", p[3].toInt())
                    "CAND" -> cur!!.cands += Cand(p[1], p[2].toInt(), p[3], p[4], p[5].toDouble(), p[6].toDouble(), p[7], p[8].toDouble(), p[9], p[10].toDouble())
                    "BAR" -> cur!!.bars.getOrPut(p[1]) { mutableListOf() } += Candle(p[2].toLong(), p[3].toDouble(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble(), p[7].toDouble())
                    "EXPF" -> cur!!.features[p[1]] = DoubleArray(p.size - 2) { p[it + 2].toDouble() }
                    "EXPP" -> cur!!.probs[p[1] + "|" + p[2]] = p[3].toDouble() to p[4].toDouble()
                    "EXPX" -> cur!!.designHigh[p[1] + "|" + p[2]] = DoubleArray(p.size - 4) { p[it + 4].toDouble() }
                    "BEST" -> cur!!.best[p[1]] = Best(p[2], p[3], p[4].toDouble(), p[5].toDouble())
                    "END" -> { out += cur!!; cur = null }
                    else -> error("fixture line ${p[0]}")
                }
            }
        }
        out
    }

    fun values(x: EvidenceFeatures.Instrument): DoubleArray = doubleArrayOf(
        x.r1, x.r3, x.r5, x.r10, x.r15, x.r30, x.r60, x.rv60, x.rv30over60, x.pos15, x.pos60, x.bbz,
        x.f1, x.f2, x.f5, x.f15, x.pos15Live, x.bbzLive, x.tie58, x.zero30, x.vol10, x.rvJpy)
}

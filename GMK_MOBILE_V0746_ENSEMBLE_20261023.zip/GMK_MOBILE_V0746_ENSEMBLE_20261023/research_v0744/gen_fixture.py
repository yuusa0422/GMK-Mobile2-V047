"""Parity fixture for the Kotlin port: raw candles + native fields -> features, probabilities, chosen action."""
import pickle, gzip, sys, math, random, numpy as np, pandas as pd
src = open('policy_data.py').read().split("d = pd.DataFrame(pickle.load(open('../work/frames_year.pkl'")[0]
exec(src)                                        # bars, index, window(), feats()
exec(open('evidence_model.py').read().split('def model():')[0])   # P, design()
M = pickle.load(open('../work/production_models.pkl', 'rb'))
out_path = sys.argv[1]
rng = random.Random(7)
R = lambda x: repr(float(x))
wk_b = sorted(P[P.weekday].b.unique()); we_b = sorted(P[~P.weekday].b.unique())
picks = rng.sample(wk_b, 18) + rng.sample(we_b, 6)
FKEYS = ['r1', 'r3', 'r5', 'r10', 'r15', 'r30', 'r60', 'rv60', 'rv30_60', 'pos15', 'pos60', 'bbz', 'f1', 'f2', 'f5', 'f15', 'pos15L', 'bbzL', 'tie58', 'zero30', 'vol10', 'rvjpy']
lines = []
for B in sorted(picks):
    g = P[P.b == B].sort_values('order')
    wkend = int(not g.weekday.iloc[0]); hour = int(g.hour.iloc[0])
    lines.append(f'SLOT|{B}|{wkend}|{hour}')
    for r in g.itertuples(index=False):
        lb = index[r.inst].get((B - 60) * 1000); live = lb[4]
        dec = 'ENTRY' if r.app_grade in ('S', 'A', 'B', 'C') else 'SKIP'
        lines.append(f'CAND|{r.inst}|{r.order}|{"HIGH" if r.app_dir == 1 else "LOW"}|{r.app_grade}|{R(r.app_prob)}|{R(r.app_score)}|{r.regime}|{R(r.regconf)}|{dec}|{R(live)}')
        for bar in window(r.inst, B): lines.append('BAR|' + r.inst + '|' + '|'.join([str(int(bar[0]))] + [R(x) for x in bar[1:]]))
        f = feats(window(r.inst, B), live, r.inst == 'BTCJPY')
        lines.append('EXPF|' + r.inst + '|' + '|'.join(repr(float(f[k])) for k in FKEYS))
    for fresh, tag in ((True, 'fresh'), (False, 'fallback')):
        Xu, _ = design(g, 1, fresh); Xd, _ = design(g, -1, fresh)
        pu = M['models'][fresh].predict_proba(Xu)[:, 1]; pdn = M['models'][fresh].predict_proba(Xd)[:, 1]
        st = M['stats'][tag]['weekend' if wkend else 'weekday']
        best = None
        for k, r in enumerate(g.itertuples(index=False)):
            lines.append(f'EXPP|{tag}|{r.inst}|{R(pu[k])}|{R(pdn[k])}')
            lines.append(f'EXPX|{tag}|{r.inst}|1|' + '|'.join(repr(float(v)) for v in Xu[k]))
            for d, p in ((1, pu[k]), (-1, pdn[k])):
                if best is None or p > best[2]: best = (r.inst, 'HIGH' if d == 1 else 'LOW', p)
        adj = best[2] - st['offset'][hour - 9]
        lines.append(f'BEST|{tag}|{best[0]}|{best[1]}|{R(best[2])}|{R(adj)}')
    lines.append('END')
with gzip.open(out_path, 'wt') as f: f.write('\n'.join(lines) + '\n')
print('fixture slots', len(picks), 'lines', len(lines))

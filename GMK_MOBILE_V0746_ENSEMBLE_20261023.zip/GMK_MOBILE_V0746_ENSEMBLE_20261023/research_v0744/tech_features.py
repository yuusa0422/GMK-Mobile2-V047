"""Port of OctoberTechnicalFeatures (first 30 chart features) from 61 consecutive M1 bars ending at OPEN(B-120)."""
import math, bisect
def r_features(rows):
    o = [r[1] for r in rows]; h = [r[2] for r in rows]; l = [r[3] for r in rows]; c = [r[4] for r in rows]
    lg = [math.log(x) for x in c]; ret = [lg[i] - lg[i - 1] for i in range(1, 61)]
    rv = []
    for k in (5, 15, 30, 60): rv.append(math.sqrt(sum(x * x for x in ret[60 - k:60]) / k))
    norm = max(rv[3], 1e-8)
    out = {}
    for k in (1, 3, 5, 10, 15, 30, 60): out[f'r{k}'] = (lg[60] - lg[60 - k]) / (norm * math.sqrt(k))
    out['rv60'] = rv[3] * 1e4; out['rv30_60'] = rv[2] / rv[3] if rv[3] > 1e-15 else 1
    return out
def frame_rows(times, bars, B):
    i = bisect.bisect_right(times, (B - 120) * 1000)
    rows = bars[max(0, i - 61):i]
    if len(rows) != 61 or rows[-1][0] != (B - 120) * 1000 or rows[0][0] != (B - 3720) * 1000: return None
    return rows

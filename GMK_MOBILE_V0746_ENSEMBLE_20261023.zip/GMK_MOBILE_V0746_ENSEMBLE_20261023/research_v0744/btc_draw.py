"""BTC (bitbank) tie risk: can we predict open(B+180)==open(B) from data available at B-10s?"""
import gzip, csv, numpy as np, pandas as pd, datetime as dt, pickle
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
JST = dt.timezone(dt.timedelta(hours=9))
T0 = int(dt.datetime(2025, 10, 1, tzinfo=JST).timestamp()) // 60
N = int(dt.datetime(2026, 10, 22, tzinfo=JST).timestamp()) // 60 - T0
o = np.full(N, np.nan); c = o.copy(); v = o.copy(); h = o.copy(); l = o.copy()
with gzip.open('../hist/combined/BTCJPY_1m.csv.gz', 'rt') as f:
    for r in csv.DictReader(f):
        m = int(r['epoch_ms']) // 60000 - T0
        if 0 <= m < N: o[m] = float(r['open']); c[m] = float(r['close']); v[m] = float(r['volume']); h[m] = float(r['high']); l[m] = float(r['low'])
H = pd.read_pickle('../work/hyp_fresh.pkl'); B = H[H.inst == 'BTCJPY'].copy()
bm = (B.b.values // 60 - T0).astype(int); t = bm - 2          # last completed bar at B-10s opens at B-120
dc = np.diff(c, prepend=np.nan)
def win_stat(arr, k, fn):
    return np.array([fn(arr[i - k + 1:i + 1]) for i in t])
B['zero10'] = win_stat(dc == 0, 10, np.mean); B['zero30'] = win_stat(dc == 0, 30, np.mean)
B['openeq10'] = win_stat(np.r_[False, o[1:] == o[:-1]], 10, np.mean)
B['vol10'] = np.log1p(win_stat(np.nan_to_num(v), 10, np.mean)); B['vol60'] = np.log1p(win_stat(np.nan_to_num(v), 60, np.mean))
B['rng10'] = win_stat((h - l) / c * 1e4, 10, np.nanmean)
# how often were 3-minute open-to-open changes zero in the last hour (the app can compute this from its 120 bars)
oo3 = np.r_[np.full(3, np.nan), o[3:] - o[:-3]]
B['tie60'] = win_stat(oo3 == 0, 60, np.mean)
B['rvjpy'] = B.rv60 * B.price            # 1-minute stdev in yen
B['wkend'] = (B.dow >= 5).astype(float); B['hs'] = np.sin(2 * np.pi * B.hour / 24); B['hc'] = np.cos(2 * np.pi * B.hour / 24)
B['half'] = np.where(pd.to_datetime(B.date) < pd.Timestamp('2026-04-01'), 'H1', 'H2')
B['draw'] = (B.move3 == 0).astype(int)
F = ['zero10', 'zero30', 'openeq10', 'vol10', 'vol60', 'rng10', 'tie60', 'rvjpy', 'wkend', 'hs', 'hc']
B[F] = B[F].replace([np.inf, -np.inf], np.nan).fillna(B[F].median())
for f in ['tie60', 'zero30', 'vol10', 'rvjpy']:
    q = pd.qcut(B[f].rank(method='first'), 5, labels=False)
    print(f, '5分位ごとの引分率:', ' '.join(f'{x*100:4.1f}' for x in B.groupby(q).draw.mean()))
B['p_draw'] = np.nan
for tr, te in [('H1', 'H2'), ('H2', 'H1')]:
    a = B.half == tr; b_ = B.half == te
    sc = StandardScaler().fit(B.loc[a, F]); m = LogisticRegression(max_iter=500).fit(sc.transform(B.loc[a, F]), B.loc[a, 'draw'])
    B.loc[b_, 'p_draw'] = m.predict_proba(sc.transform(B.loc[b_, F]))[:, 1]
for seg, sm in [('平日', B.dow < 5), ('土日', B.dow >= 5)]:
    x = B[sm]; q = pd.qcut(x.p_draw.rank(method='first'), 10, labels=False)
    print(f'{seg}: 予測引分確率10段階の実際の引分率:', ' '.join(f'{y*100:4.1f}' for y in x.groupby(q).draw.mean()))
B[['b', 'inst', 'zero10', 'zero30', 'openeq10', 'vol10', 'vol60', 'rng10', 'tie60', 'rvjpy', 'p_draw']].to_pickle('../work/btc_draw.pkl')

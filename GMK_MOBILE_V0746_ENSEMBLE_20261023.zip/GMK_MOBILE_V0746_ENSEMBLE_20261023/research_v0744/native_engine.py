"""Python port of LocalRuleEngine.kt (scan + scoreInstrument + classifyRegime)."""
import math, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gmk_policy as P

ORDER = ["USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY"]

def ema(values, period):
    s = values[-max(period * 4, period):]
    a = 2.0 / (period + 1.0); out = s[0]
    for v in s[1:]: out = a * v + (1 - a) * out
    return out

def rsi(values, period):
    s = values[-(period + 1):]; g = l = 0.0
    for i in range(1, len(s)):
        d = s[i] - s[i - 1]
        if d >= 0: g += d
        else: l -= d
    if l == 0: return 100.0 if g > 0 else 50.0
    rs = (g / period) / (l / period)
    return 100 - 100 / (1 + rs)

def bollZ(values, period):
    s = values[-period:]; m = sum(s) / len(s)
    var = sum((x - m) ** 2 for x in s) / len(s); sd = math.sqrt(max(var, 1e-16))
    return (s[-1] - m) / sd

def bbWidth(values, period):
    s = values[-period:]
    if not s: return 0.0
    m = sum(s) / len(s)
    if m == 0: return 0.0
    var = sum((x - m) ** 2 for x in s) / len(s); sd = math.sqrt(max(var, 1e-16))
    return 4 * sd / abs(m)

def atrAbs(c, period):
    s = c[-(period + 1):]; tr = []
    for i in range(1, len(s)):
        h, l, pc = s[i][2], s[i][3], s[i - 1][4]
        tr.append(max(h - l, abs(h - pc), abs(l - pc)))
    return sum(tr) / len(tr) if tr else 0.0

def atrPct(c, period):
    return atrAbs(c, period) / max(c[-1][4], 1e-12)

def gap_ok(a, b): return 1 <= b[0] - a[0] <= 90000

def tail_cont(c, n):
    if n <= 1: return len(c) > 0
    t = c[-n:]
    if len(t) < n: return False
    return all(gap_ok(t[i], t[i + 1]) for i in range(len(t) - 1))

def cont_tail(c):
    if not c: return []
    st = len(c) - 1
    while st > 0 and gap_ok(c[st - 1], c[st]): st -= 1
    return c[st:]

def timed_ret(c, k):
    if k <= 0 or len(c) <= k: return 0.0
    t = c[-(k + 1):]
    if not all(gap_ok(t[i], t[i + 1]) for i in range(len(t) - 1)): return 0.0
    return 0.0 if t[0][4] == 0 else t[-1][4] / t[0][4] - 1

def unit(x): return min(1.0, max(0.0, x))
def clamp(x, a, b): return min(b, max(a, x))

def classify_regime(c):
    closes = [x[4] for x in c]; last = closes[-1]
    atr = max(atrAbs(c, 14), max(last * 1e-8, 1e-12))
    e8, e21 = ema(closes, 8), ema(closes, 21)
    prev3 = closes[:-3]
    e8p = ema(prev3, 8) if len(prev3) >= 8 else e8
    gap = abs(e8 - e21) / atr; slope = abs(e8 - e8p) / atr
    recent = [x[4] for x in cont_tail(c)][-13:]
    diffs = [recent[i + 1] - recent[i] for i in range(len(recent) - 1)]
    travel = sum(abs(d) for d in diffs)
    net = abs(recent[-1] - recent[0]) if len(recent) >= 2 else 0.0
    eff = 0.0 if travel <= 1e-12 else clamp(net / travel, 0, 1)
    signs = [1 if d > 0 else -1 for d in diffs if d != 0]
    flips = sum(1 for i in range(len(signs) - 1) if signs[i] != signs[i + 1])
    alt = 0.0 if len(signs) <= 1 else flips / (len(signs) - 1)
    nd = 1 if recent[-1] > recent[0] else -1 if recent[-1] < recent[0] else 0
    pers = 0.0 if (not signs or nd == 0) else sum(1 for s in signs if s == nd) / len(signs)
    cw = bbWidth(closes, 20); older = closes[:-10]
    pw = bbWidth(older, 20) if len(older) >= 20 else cw
    exp_ = 1.0 if pw <= 1e-12 else clamp(cw / pw, 0.25, 4.0)
    es = []
    for end in range(max(22, len(closes) - 12), len(closes) + 1):
        pre = closes[:end]
        if len(pre) < 21: continue
        g = ema(pre, 8) - ema(pre, 21)
        es.append(1 if g > atr * 0.05 else -1 if g < -atr * 0.05 else 0)
    st = [s for s in es if s != 0]
    ef = sum(1 for i in range(len(st) - 1) if st[i] != st[i + 1])
    efr = 0.0 if len(st) <= 1 else ef / (len(st) - 1)
    trend = clamp(0.28 * unit(gap / 0.9) + 0.24 * unit(slope / 0.8) + 0.24 * eff + 0.16 * pers + 0.08 * unit((exp_ - 0.9) / 0.5), 0, 1)
    chop = clamp(0.38 * alt + 0.27 * (1 - eff) + 0.20 * efr + 0.15 * unit(1 - gap / 0.65), 0, 1)
    contr = unit((1.15 - exp_) / 0.45)
    rng = clamp(0.30 * unit(1 - gap / 0.75) + 0.22 * unit(1 - slope / 0.65) + 0.24 * (1 - eff) + 0.14 * contr + 0.10 * unit(1 - efr), 0, 1)
    dirn = 1 if (e8 > e21 and e8 - e8p > 0) else -1 if (e8 < e21 and e8 - e8p < 0) else 0
    if chop >= 0.62 and chop >= trend + 0.08: name = 'CHOPPY'
    elif trend >= 0.60 and dirn > 0 and pers >= 0.55: name = 'TREND_UP'
    elif trend >= 0.60 and dirn < 0 and pers >= 0.55: name = 'TREND_DOWN'
    elif rng >= 0.52: name = 'RANGE'
    elif alt >= 0.55 and eff <= 0.40: name = 'CHOPPY'
    elif dirn > 0 and trend >= 0.52: name = 'TREND_UP'
    elif dirn < 0 and trend >= 0.52: name = 'TREND_DOWN'
    else: name = 'RANGE'
    chosen = trend if name.startswith('TREND') else chop if name == 'CHOPPY' else rng
    second = sorted([trend, rng, chop], reverse=True)[1]
    conf = clamp(0.55 * chosen + 0.45 * unit(0.5 + (chosen - second)), 0.5, 0.95)
    return dict(name=name, conf=conf, eff=eff, alt=alt, gap=gap, slope=slope)

def score_instrument(inst, c):
    closes = [x[4] for x in c]; last = closes[-1]
    ret1, mom3, mom5 = timed_ret(c, 1), timed_ret(c, 3), timed_ret(c, 5)
    e8, e21 = ema(closes, 8), ema(closes, 21)
    spread = 0.0 if last == 0 else (e8 - e21) / last
    r14 = rsi(closes, 14); bb = bollZ(closes, 20); ap = atrPct(c, 14)
    body = 0.0 if last == 0 else (c[-1][4] - c[-1][1]) / last
    base = clamp(0.26 * math.tanh(mom3 / 0.0018) + 0.18 * math.tanh(mom5 / 0.0027) + 0.24 * math.tanh(spread / 0.0014)
                 + 0.12 * clamp((r14 - 50) / 25, -1, 1) + 0.10 * math.tanh(bb / 1.2)
                 + 0.10 * math.tanh((0.55 * ret1 + 0.45 * body) / 0.0012), -1, 1)
    reg = classify_regime(c)
    prev = closes[:-3]
    pe8 = ema(prev, 8) if len(prev) >= 21 else e8
    pe21 = ema(prev, 21) if len(prev) >= 21 else e21
    pspread = (pe8 - pe21) / prev[-1] if (prev and prev[-1] != 0) else spread
    def sgn(x, eps=0.00005): return 1 if x > eps else -1 if x < -eps else 0
    cur, prv = sgn(spread), sgn(pspread)
    switched = tail_cont(c, 4) and cur != 0 and prv != 0 and cur != prv
    sd = sgn(base, 0.0)
    votes = sum(1 for v in (mom3, mom5, ret1, body) if sgn(v, 0.0) == cur)
    counter = switched and sd != 0 and sd != cur
    unconf = switched and votes < 3
    regCounter = (reg['name'] == 'TREND_UP' and sd < 0) or (reg['name'] == 'TREND_DOWN' and sd > 0)
    choppy = reg['name'] == 'CHOPPY'
    rchase = reg['name'] == 'RANGE' and ((bb >= 1.35 and sd > 0) or (bb <= -1.35 and sd < 0))
    vpen = clamp((ap - 0.0012) / 0.0040, 0.0, 0.16)
    agree = sum(1 for v in (mom3, mom5, spread, r14 - 50, bb, body) if (v > 0 if base >= 0 else v < 0)) / 6.0
    conf = clamp(0.50 + abs(base) * 0.31 + agree * 0.08 - vpen, 0.50, 0.88)
    if counter: conf = min(conf, 0.54)
    if unconf and not counter: conf = clamp(conf - 0.04, 0.50, 0.88)
    def caution(v, pen, upper=0.88):
        red = clamp(v - pen, 0.50, upper)
        return max(0.55, red) if v >= 0.55 else red
    if regCounter and not switched: conf = caution(conf, 0.03 + 0.04 * clamp(reg['conf'], 0, 1))
    if choppy: conf = caution(conf, 0.05, 0.64)
    if rchase: conf = caution(conf, 0.03)
    return dict(counterSwitch=counter, instrument=inst, score=base, confidence=conf, regime=reg['name'], regimeConfidence=reg['conf'], rsi14=r14,
                atrPct=ap, agreement=agree, efficiency=reg['eff'], emaGapAtr=reg['gap'],
                x_ret1=ret1, x_mom3=mom3, x_mom5=mom5, x_spread=spread, x_bb=bb, x_body=body, x_alt=reg['alt'], x_slope=reg['slope'],
                x_switched=switched, x_regcounter=regCounter)

def valid(x):
    t, o, h, l, c = x[:5]
    return t > 0 and all(math.isfinite(v) and v > 0 for v in (o, h, l, c)) and h >= max(o, c) and l <= min(o, c) and h >= l

def scan(candles_by_inst, hour, rule_hour_fn=None, gate_threshold=None):
    """Returns ranked list of dicts. rule_hour_fn(inst, hour) -> hour used for rules/gate (default identity)."""
    rule_hour_fn = rule_hour_fn or (lambda inst, h: h)
    th = P.THRESHOLD if gate_threshold is None else gate_threshold
    raw = []
    for inst in ORDER:
        c = candles_by_inst.get(inst)
        if not c: continue
        seen = {};
        for x in c:
            if valid(x): seen[x[0]] = x
        c = [seen[k] for k in sorted(seen)][-120:]
        if len(c) < 21: continue
        raw.append(score_instrument(inst, c))
    cl = []
    for x in raw:
        f = dict(x, direction='HIGH' if x['score'] >= 0 else 'LOW')
        hh = rule_hour_fn(x['instrument'], hour)
        p = P.classify_base(f, hh)
        cl.append((x, f, p, hh, -x['score'] if p['reverse'] else x['score']))
    cl.sort(key=lambda t: (-P.rank_priority(t[2]['rank']), -t[2]['minPeriodWinRate'], -t[2]['expectedWinRate'],
                           -t[0]['confidence'], -abs(t[4]), t[0]['instrument']))
    out = []
    for i, (x, f, pb, hh, _) in enumerate(cl):
        p = P.classify(f, hh) if i == 0 else pb
        eff = -x['score'] if p['reverse'] else x['score']
        d = 'HIGH' if eff >= 0 else 'LOW'
        gs = None
        if i == 0 and p['rank'] in ('S', 'A', 'B', 'C'):
            gs = P.gate_score(dict(instrument=x['instrument'], regime=x['regime'], direction=d, grade=p['rank'], ruleId=p['ruleId'],
                                   reverse=p['reverse'], probability=p['expectedWinRate'], effectiveScore=eff,
                                   regimeConfidence=x['regimeConfidence'], hour=hh, rawConfidence=x['confidence'], rsi14=x['rsi14'],
                                   atrPct=x['atrPct'], agreement=x['agreement'], efficiency=x['efficiency'], emaGapAtr=x['emaGapAtr']))
        grade = 'E' if (gs is not None and gs < th) else p['rank']
        out.append(dict(rank=i + 1, instrument=x['instrument'], direction=d, grade=grade, pregate=p['rank'], gate=gs,
                        ruleId=p['ruleId'], reverse=p['reverse'], stage=p['stage'], prob=p['expectedWinRate'], feat=x))
    return out


def scan_v(candles_by_inst, hour, skip_c_nonrev=False, top1_final=False, switch_guard=False):
    raw = []
    for inst in ORDER:
        c = candles_by_inst.get(inst)
        if not c: continue
        seen = {}
        for x in c:
            if valid(x): seen[x[0]] = x
        c = [seen[k] for k in sorted(seen)][-120:]
        if len(c) < 21: continue
        raw.append(score_instrument(inst, c))
    def final_grade(p, x):
        g = p['rank']
        if g == 'E': return 'E'
        if switch_guard and x['counterSwitch']: return 'E'
        if skip_c_nonrev and g == 'C' and not p['reverse']: return 'E'
        return g
    cl = []
    for x in raw:
        f = dict(x, direction='HIGH' if x['score'] >= 0 else 'LOW')
        p = P.classify(f, hour) if top1_final else P.classify_base(f, hour)
        key_rank = final_grade(p, x) if top1_final else p['rank']
        cl.append((x, f, p, key_rank, -x['score'] if p['reverse'] else x['score']))
    cl.sort(key=lambda t: (-P.rank_priority(t[3]), -t[2]['minPeriodWinRate'], -t[2]['expectedWinRate'], -t[0]['confidence'], -abs(t[4]), t[0]['instrument']))
    x, f, pb, _, _ = cl[0]
    p = P.classify(f, hour)
    eff = -x['score'] if p['reverse'] else x['score']
    d = 'HIGH' if eff >= 0 else 'LOW'
    g = p['rank']; gs = None; reason = ''
    if g != 'E':
        gs = P.gate_score(dict(instrument=x['instrument'], regime=x['regime'], direction=d, grade=g, ruleId=p['ruleId'], reverse=p['reverse'],
            probability=p['expectedWinRate'], effectiveScore=eff, regimeConfidence=x['regimeConfidence'], hour=hour, rawConfidence=x['confidence'],
            rsi14=x['rsi14'], atrPct=x['atrPct'], agreement=x['agreement'], efficiency=x['efficiency'], emaGapAtr=x['emaGapAtr']))
        if gs < P.THRESHOLD: reason = 'gate'
        elif switch_guard and x['counterSwitch']: reason = 'switch'
        elif skip_c_nonrev and g == 'C' and not p['reverse']: reason = 'c_nonrev'
    else: reason = 'rule'
    return dict(instrument=x['instrument'], direction=d, pregate=g, grade='E' if reason else g, reason=reason, reverse=p['reverse'], gate=gs)

v0.7.44 研究コード（参考・再現用）。アプリのビルドには使いません。

データ: 1分足 2025-10-01〜2026-10-21（為替 Dukascopy BID、BTC bitbank）。GMK_FETCH_HISTORY_WORKFLOW で取得したもの。
  ../hist/USDJPY_merged.csv.gz, ../hist/combined/<SYMBOL>_1m.csv.gz を想定したパスになっています。

順番:
 1. frames_build.py      元アプリ（LocalRuleEngine/FinalRankPolicy/OfficialWinGate）のPython移植で全5分枠を再現
                          （native_engine.py, gmk_policy.py, tech_features.py。10月の元結果と完全一致を確認済み）
 2. policy_data.py       枠×通貨ごとの入力（アプリと同じ61本の窓＋直前価格）を作成
 3. evidence_model.py    方向つき勝ち確率モデルの設計（入力46項目）と2分割検証
    evidence_final_val.py / sim_app_policy.py  アプリと同じ判定方法（直近288枠の分位でENTRY）で未知データ検証
 4. train_export.py      1年全体で本番モデルを学習し、決定木をテキストに書き出し（書き出し誤差 0）
    gen_kotlin_model.py  EvidenceModelData.kt を生成
    gen_fixture.py       Kotlinとの一致テスト用データ（app/src/test/resources/v0744_evidence_parity.txt.gz）
 5. late_info.py / late_feats.py  直前1分の情報の効果、btc_draw.py / btc_policy.py  BTCの引き分けと向き
    hyp_features.py / hyp_tests.py  世界の研究から作った仮説の検証（結果: hypothesis_results.csv）

"""Final validation of the chosen model with realistic thresholds:
threshold per (weekday/weekend, hour) fitted on the TRAINING half only, applied to the test half."""
import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, random_state=0, early_stopping=False)
RATE = {True: 0.74, False: 0.46}
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def fitm(A, fresh):
    Xu, _ = design(A, 1, fresh); Xd, _ = design(A, -1, fresh)
    return HistGradientBoostingClassifier(**CFG).fit(np.vstack([Xu, Xd]), np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int))
def best_per_slot(m, df, fresh):
    Yu, _ = design(df, 1, fresh); Yd, _ = design(df, -1, fresh)
    t = df.copy(); pu = m.predict_proba(Yu)[:, 1]; pd_ = m.predict_proba(Yd)[:, 1]
    t['dir'] = np.where(pu >= pd_, 1, -1); t['p'] = np.maximum(pu, pd_); t['win'] = (t.move3 == t.dir).astype(int)
    return t.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
res = {}
for fresh in (True, False):
    sel = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        m = fitm(P[P.half == tr], fresh)
        btr = best_per_slot(m, P[P.half == tr], fresh); bte = best_per_slot(m, P[P.half == te], fresh)
        thr = btr.groupby(['weekday', 'hour']).p.apply(lambda v: v.quantile(1 - RATE[v.name[0]])).rename('thr').reset_index()
        bte = bte.merge(thr, on=['weekday', 'hour'], how='left'); bte['enter'] = bte.p >= bte.thr
        sel.append(bte)
    S = pd.concat(sel).sort_values('b'); res[fresh] = S
    print(f'\n== {"直前価格あり" if fresh else "直前価格なし"} (しきい値は学習期間だけで決定) ==')
    for wk in (True, False):
        x = S[S.weekday == wk]; e = x[x.enter]
        print(f'  {"平日" if wk else "土日"}: 入った枠 {len(e)/len(x)*100:4.1f}% (H1 {x[x.half=="H1"].enter.mean()*100:4.1f} H2 {x[x.half=="H2"].enter.mean()*100:4.1f})  勝率 {e.win.mean()*100:5.1f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} H2 {e[e.half=="H2"].win.mean()*100:5.1f})  件数 {len(e)}  最大連敗 {ms(e.win.values)}')
        hr = x.groupby('hour').enter.mean() * 100
        print(f'     時間帯別の入る割合 最小 {hr.min():.0f}% 最大 {hr.max():.0f}%')
pickle.dump(res, open('../work/evidence_final_val.pkl', 'wb'))

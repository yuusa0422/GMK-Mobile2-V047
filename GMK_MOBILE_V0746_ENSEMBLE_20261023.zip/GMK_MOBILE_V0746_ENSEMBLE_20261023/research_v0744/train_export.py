"""Train the production models (full year), export them for Kotlin, build parity fixtures."""
import pandas as pd, numpy as np, pickle, hashlib, json, math, gzip, random, sys
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])     # P + design()
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, random_state=0, early_stopping=False)
RATE = {True: 0.74, False: 0.46}
models = {}
for fresh in (True, False):
    Xu, names = design(P, 1, fresh); Xd, _ = design(P, -1, fresh)
    m = HistGradientBoostingClassifier(**CFG).fit(np.vstack([Xu, Xd]), np.r_[(P.move3.values == 1), (P.move3.values == -1)].astype(int))
    models[fresh] = m
    print('trained', 'fresh' if fresh else 'fallback', 'iters', m.n_iter_, 'features', len(names))
FEATURES = names
# ---------- export ----------
def export(m):
    base = float(m._baseline_prediction.ravel()[0])
    lines = [f'GMKEV1|{len(FEATURES)}|{base!r}|{len(m._predictors)}']
    for it in m._predictors:
        assert len(it) == 1
        nodes = it[0].nodes
        lines.append(f'T|{len(nodes)}')
        for nd in nodes:
            if nd['is_leaf']: lines.append(f'L|{float(nd["value"])!r}')
            else:
                assert not nd['is_categorical']
                lines.append(f'N|{int(nd["feature_idx"])}|{float(nd["num_threshold"])!r}|{int(nd["left"])}|{int(nd["right"])}|{1 if nd["missing_go_to_left"] else 0}')
    return '\n'.join(lines) + '\n'
texts = {f: export(models[f]) for f in (True, False)}
def eval_text(text, X):
    rows = text.strip().split('\n'); hdr = rows[0].split('|'); base = float(hdr[2]); trees = []; i = 1
    while i < len(rows):
        n = int(rows[i].split('|')[1]); trees.append([r.split('|') for r in rows[i + 1:i + 1 + n]]); i += 1 + n
    out = np.empty(len(X))
    for k, x in enumerate(X):
        raw = base
        for t in trees:
            j = 0
            while t[j][0] == 'N':
                f, thr, l, r, ml = int(t[j][1]), float(t[j][2]), int(t[j][3]), int(t[j][4]), t[j][5] == '1'
                v = x[f]; j = (l if ml else r) if math.isnan(v) else (l if v <= thr else r)
            raw += float(t[j][1])
        out[k] = 1.0 / (1.0 + math.exp(-raw))
    return out
for fresh in (True, False):
    Xs, _ = design(P.sample(3000, random_state=1), 1, fresh)
    diff = np.abs(eval_text(texts[fresh], Xs) - models[fresh].predict_proba(Xs)[:, 1]).max()
    print('export parity', fresh, diff); assert diff < 1e-12
# ---------- in-sample slot statistics (seeds) ----------
stats = {}
for fresh in (True, False):
    Xu, _ = design(P, 1, fresh); Xd, _ = design(P, -1, fresh)
    pu = models[fresh].predict_proba(Xu)[:, 1]; pdn = models[fresh].predict_proba(Xd)[:, 1]
    t = P[['b', 'inst', 'weekday', 'hour', 'move3']].copy(); t['p'] = np.maximum(pu, pdn); t['dir'] = np.where(pu >= pdn, 1, -1)
    best = t.sort_values('p', ascending=False).groupby('b').head(1)
    st = {}
    for wk in (True, False):
        x = best[best.weekday == wk].copy()
        off = x.groupby('hour').p.median().reindex(range(9, 23)).ffill().bfill()
        x['adj'] = x.p - x.hour.map(off)
        st['weekday' if wk else 'weekend'] = dict(offset=[float(v) for v in off.values],
            seed=float(x.adj.quantile(1 - RATE[wk])), q50=float(x.adj.quantile(0.50)), q75=float(x.adj.quantile(0.75)))
    stats['fresh' if fresh else 'fallback'] = st
print(json.dumps(stats, indent=1)[:1500])
pickle.dump(dict(models=models, texts=texts, stats=stats, features=FEATURES, cfg=CFG), open('../work/production_models.pkl', 'wb'))

"""Python port of FinalRankPolicy.kt + OfficialWinGate.kt (GMK mobile v0.7.42)."""
import re, math, os

DOM = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'R', 'app', 'src', 'main', 'java', 'jp', 'gmk', 'mobile', 'domain')
_frp = open(os.path.join(DOM, 'FinalRankPolicy.kt'), encoding='utf-8').read()
_gate = open(os.path.join(DOM, 'OfficialWinGate.kt'), encoding='utf-8').read()

FIELDS = ['instrument', 'regime', 'direction', 'hour3', 'rsiBin', 'scoreBin', 'agreeBin', 'effBin', 'emaBin', 'confBin', 'regcBin']

def _parse_rules(block):
    out = []
    for m in re.finditer(r'Rule\((.*?)\),?\s*\n', block):
        body = m.group(1)
        r = {}
        for k, v in re.findall(r'(\w+)\s*=\s*("[^"]*"|[^,]+)', body):
            v = v.strip()
            if v.startswith('"'): r[k] = v[1:-1]
            elif v in ('true', 'false'): r[k] = v == 'true'
            elif re.match(r'^-?\d+$', v): r[k] = int(v)
            else: r[k] = float(v)
        out.append(r)
    return out

def _section(start_pat, text):
    i = text.index(start_pat)
    j = text.index('\n    )\n', i)
    return text[i:j + 1]

RULES = _parse_rules(_section('private val rules = listOf(', _frp))
RESCUE1 = _parse_rules(_section('private val rescueStage1 = listOf(', _frp))
RESCUE2 = _parse_rules(_section('private val rescueStage2 = listOf(', _frp))
_ov = _section('private val rankOverrides', _frp)
OVERRIDES = {int(a): b for a, b in re.findall(r'(\d+) to "([A-Z])"', _ov)}

def rank_priority(r): return {'S': 4, 'A': 3, 'B': 2, 'C': 1}.get(r, 0)

def hour3(h):
    if 9 <= h <= 11: return '09-11'
    if 12 <= h <= 14: return '12-14'
    if 15 <= h <= 17: return '15-17'
    if 18 <= h <= 20: return '18-20'
    return '21-22'
def rsiBin(x): return '<30' if x < 30 else '30-40' if x < 40 else '40-50' if x < 50 else '50-60' if x < 60 else '60-70' if x < 70 else '70+'
def scoreBin(x): return '0-.08' if x <= .08 else '.08-.16' if x <= .16 else '.16-.24' if x <= .24 else '.24-.35' if x <= .35 else '.35+'
def agreeBin(x): return '<=.33' if x <= .34 else '.34-.50' if x <= .51 else '.51-.67' if x <= .68 else '.68-.84' if x <= .85 else '>=.85'
def effBin(x): return '0-.2' if x <= .2 else '.2-.4' if x <= .4 else '.4-.6' if x <= .6 else '.6-.8' if x <= .8 else '.8+'
def emaBin(x): return '0-.5' if x <= .5 else '.5-1' if x <= 1 else '1-1.5' if x <= 1.5 else '1.5-2.5' if x <= 2.5 else '2.5+'
def confBin(x): return '<.55' if x < .55 else '.55-.58' if x < .58 else '.58-.65' if x < .65 else '.65-.72' if x < .72 else '.72+'
def regcBin(x): return '<.5' if x <= .5 else '.5-.65' if x <= .65 else '.65-.8' if x <= .8 else '.8+'

def bins(f, hour):
    return dict(instrument=f['instrument'], regime=f['regime'], direction=f['direction'], hour3=hour3(hour),
                rsiBin=rsiBin(f['rsi14']), scoreBin=scoreBin(abs(f['score'])), agreeBin=agreeBin(f['agreement']),
                effBin=effBin(f['efficiency']), emaBin=emaBin(f['emaGapAtr']), confBin=confBin(f['confidence']),
                regcBin=regcBin(f['regimeConfidence']))

def matches(r, b):
    return all(r.get(k) is None or r[k] == b[k] for k in FIELDS)

def better(a, b):
    if a['specificity'] != b['specificity']: return a['specificity'] > b['specificity']
    ap, bp = rank_priority(a['finalRank']), rank_priority(b['finalRank'])
    if ap != bp: return ap > bp
    if a['minRate'] != b['minRate']: return a['minRate'] > b['minRate']
    if a['expectedRate'] != b['expectedRate']: return a['expectedRate'] > b['expectedRate']
    return a['n'] > b['n']

def _best(b):
    best = None
    for r in RULES:
        if matches(r, b) and (best is None or better(r, best)): best = r
    return best

def M(rank, rev, exp, mn, n, rid, stage):
    return dict(rank=rank, reverse=rev, expectedWinRate=exp, minPeriodWinRate=mn, sampleSize=n, ruleId=rid, stage=stage)

def classify_base(f, hour):
    if not (9 <= hour <= 22): return M('E', False, .5, 0, 0, -1, 'TIME_WINDOW')
    b = _best(bins(f, hour))
    if b is None: return M('E', False, .5, 0, 0, -1, 'BASE_UNMATCHED')
    return M(b['finalRank'], b['reverse'], b['expectedRate'], b['minRate'], b['n'], b['id'], 'LEGACY_BASE')

def classify(f, hour, min_stage2_n=25, use_rescue=True):
    if not (9 <= hour <= 22): return M('E', False, .5, 0, 0, -1, 'TIME_WINDOW')
    bb = bins(f, hour)
    b = _best(bb)
    rr = 'E' if b is None else OVERRIDES.get(b['id'], 'E')
    if b is not None and rr != 'E':
        return M(rr, b['reverse'], b['expectedRate'], b['minRate'], b['n'], b['id'], 'REMAPPED')
    if use_rescue:
        for r in RESCUE1:
            if matches(r, bb): return M(r['finalRank'], r['reverse'], r['expectedRate'], r['minRate'], r['n'], r['id'], 'RESCUE1')
        for r in RESCUE2:
            if r['n'] < min_stage2_n: continue
            if matches(r, bb): return M(r['finalRank'], r['reverse'], r['expectedRate'], r['minRate'], r['n'], r['id'], 'RESCUE2')
    return M('E', False, .5, 0, 0, b['id'] if b else -1, 'UNMATCHED' if b is None else 'REMAP_REJECTED')

# ---------------- gate ----------------
_ga = _gate[_gate.index('private val trees = arrayOf('):]
TREES = []
for m in re.finditer(r'Tree\(\s*feature = intArrayOf\(([^)]*)\),\s*threshold = doubleArrayOf\(([^)]*)\),\s*left = intArrayOf\(([^)]*)\),\s*right = intArrayOf\(([^)]*)\),\s*value = doubleArrayOf\(([^)]*)\)', _ga):
    TREES.append(tuple([float(x) if '.' in x or 'e' in x else int(x) for x in g.split(',')] for g in m.groups()))
INIT = float(re.search(r'INIT_LOGIT = ([\d.eE-]+)', _gate).group(1))
LR = float(re.search(r'LEARNING_RATE = ([\d.eE-]+)', _gate).group(1))
THRESHOLD = float(re.search(r'THRESHOLD = ([\d.eE-]+)', _gate).group(1))
INST = {"USDJPY": 0, "EURJPY": 1, "GBPJPY": 2, "AUDJPY": 3, "NZDJPY": 4, "BTCJPY": 5}
REG = {"TREND_DOWN": 0, "RANGE": 1, "CHOPPY": 2, "TREND_UP": 3}
GR = {"E": 0, "C": 1, "B": 2, "A": 3, "S": 4}
GATE_FEATURES = ['instrument', 'regime', 'direction', 'grade', 'stage', 'reverse', 'probability', 'effectiveScore',
                 'regimeConfidence', 'hour', 'rawConfidence', 'rsi14', 'atrPct', 'agreement', 'efficiency', 'emaGapAtr']

def stage_code(rid): return 0. if rid < 0 else 1. if rid < 10000 else 2. if rid < 20000 else 3.

def gate_score(g):
    if g['grade'] not in ('S', 'A', 'B', 'C') or not (9 <= g['hour'] <= 22): return 0.0
    x = [INST[g['instrument']], REG[g['regime']], 1. if g['direction'] == 'HIGH' else 0., GR[g['grade']], stage_code(g['ruleId']),
         1. if g['reverse'] else 0., g['probability'], g['effectiveScore'], g['regimeConfidence'], float(g['hour']),
         g['rawConfidence'], g['rsi14'], g['atrPct'], g['agreement'], g['efficiency'], g['emaGapAtr']]
    raw = INIT
    for feat, thr, left, right, val in TREES:
        node, guard = 0, 0
        while node >= 0 and feat[node] >= 0:
            guard += 1
            if guard > 16: break
            node = left[node] if x[feat[node]] <= thr[node] else right[node]
        raw += LR * (val[node] if 0 <= node < len(val) else 0.)
    return 1 / (1 + math.exp(-raw))

def used_gate_features():
    s = set()
    for feat, *_ in TREES:
        s |= {f for f in feat if f >= 0}
    return sorted(GATE_FEATURES[i] for i in s)

if __name__ == '__main__':
    print(len(RULES), 'base rules;', len(RESCUE1), 'rescue1;', len(RESCUE2), 'rescue2;', len(OVERRIDES), 'overrides;', len(TREES), 'trees')
    print('gate uses features:', used_gate_features())

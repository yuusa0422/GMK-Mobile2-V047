import pickle, pandas as pd, numpy as np
d = pd.DataFrame(pickle.load(open('../work/frames_year.pkl', 'rb')))
d = d[(d.inst == 'BTCJPY') & d.move3.notna()].copy()
d['grade'] = np.where(d.fin_rank.isin(['S','A','B','C']) & (d.gate.fillna(0) >= 0.53), d.fin_rank, 'E')
D = pd.read_pickle('../work/btc_draw.pkl'); Hf = pd.read_pickle('../work/hyp_fresh.pkl')[['b', 'inst', 'n1', 'n2', 'n5', 'n1L', 'n2L', 'n5L', 'n15L']]
d = d.merge(D, on=['b', 'inst'], how='left').merge(Hf, on=['b', 'inst'], how='left')
d['ts'] = pd.to_datetime(d.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo'); d['half'] = np.where(d.ts < pd.Timestamp('2026-04-01', tz='Asia/Tokyo'), 'H1', 'H2')
d['date'] = d.ts.dt.date
d['ndir'] = np.where(d.fin_dir == 'HIGH', 1, -1)
d['decisive'] = d.move3 != 0; d['nat_ok'] = np.sign(d.move3) == d.ndir
def ms(v):
    m = c = 0
    for x in v:
        c = 0 if x else c + 1; m = max(m, c)
    return m
print('BTC 元ルールの方向の精度(引分除く):')
for seg, sm in [('平日', d.weekday), ('土日', ~d.weekday)]:
    for g in [['A','B','C'], ['E']]:
        x = d[sm & d.grade.isin(g) & d.decisive]
        print(f'  {seg} ランク{"/".join(g)}: {x.nat_ok.mean()*100:5.1f}%  n={len(x)}  前半 {x[x.half=="H1"].nat_ok.mean()*100:5.1f} 後半 {x[x.half=="H2"].nat_ok.mean()*100:5.1f}')
    x = d[sm & d.decisive]; agree = np.sign(x.n1L) == x.ndir
    print(f'  {seg} 直前1分と同じ向き: {x[agree].nat_ok.mean()*100:5.1f}% (n={agree.sum()})  逆向き: {x[~agree].nat_ok.mean()*100:5.1f}% (n={(~agree).sum()})')
# direction candidates: native / fresh momentum (n1L, else n5L)
d['mdir'] = np.where(d.n1L.abs() >= 0.3, np.sign(d.n1L), np.sign(d.n5L)).astype(float)
for seg, sm in [('平日', d.weekday), ('土日', ~d.weekday)]:
    x = d[sm & d.decisive]
    print(f'{seg} 直前の勢いに順張り(引分除く): {(np.sign(x.move3)==x.mdir).mean()*100:5.1f}%  元ルールとの一致率 {(x.mdir==x.ndir).mean()*100:4.1f}%')
# weekend slot policy at equal coverage (46% of weekend slots): rank by low draw probability
w = d[~d.weekday & (d.order == 1)].copy()
cov = (w.grade != 'E').mean()
print(f'\n土日: 現行 入る枠 {cov*100:.1f}%  勝率 {((w.grade!="E") & w.nat_ok & w.decisive)[w.grade!="E"].mean()*100:.1f}%')
for dname, dcol in [('元ルールの向き', 'ndir'), ('直前の勢いの向き', 'mdir')]:
    w['win'] = (w.decisive & (np.sign(w.move3) == w[dcol])).astype(int)
    for rule, key in [('引分リスクの低い枠から', -w.p_draw), ('現行と同じ枠', (w.grade != 'E').astype(float))]:
        if rule == '現行と同じ枠': e = w[w.grade != 'E']
        else:
            thr = w.groupby('half').p_draw.transform(lambda v: v.quantile(cov)); e = w[w.p_draw <= thr]
        print(f'  {dname} × {rule}: 勝率 {e.win.mean()*100:5.1f}%  (前半 {e[e.half=="H1"].win.mean()*100:5.1f} 後半 {e[e.half=="H2"].win.mean()*100:5.1f})  件数 {len(e)}  引分 {(~e.decisive).mean()*100:4.1f}%  最大連敗 {ms(e.win.values)}')
pickle.dump(d, open('../work/btc_frames.pkl', 'wb'))

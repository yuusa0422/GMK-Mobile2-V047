"""Direction-relative win model: P(win | candidate, direction d).  2-fold time split (H1<->H2)."""
import pandas as pd, numpy as np, sys, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
P = pd.read_pickle('../work/policy_data.pkl')
INST = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY', 'BTCJPY']; REG = ['RANGE', 'TREND_UP', 'TREND_DOWN', 'CHOPPY']
GR = {'S': 4, 'A': 3, 'B': 2, 'C': 1, 'E': 0}
P['idio5'] = np.where(P.inst == 'BTCJPY', 0.0, P.r5 - P.yen5); P['idio15'] = np.where(P.inst == 'BTCJPY', 0.0, P.r15 - P.yen15)
P['idiof1'] = np.where(P.inst == 'BTCJPY', 0.0, P.f1 - P.yenf1)
P['grade_n'] = P.app_grade.map(GR).astype(float); P['wkend'] = (~P.weekday).astype(float)
SIGNED_FRESH = ['f1', 'f2', 'f5', 'f15', 'pos15L', 'bbzL', 'yenf1', 'idiof1']
SIGNED = ['r1', 'r3', 'r5', 'r10', 'r15', 'r30', 'r60', 'pos15', 'pos60', 'bbz', 'yen5', 'idio5', 'yen15', 'idio15', 'app_dir', 'app_score']
UNSIGNED = ['rv60', 'rv30_60', 'tie58', 'zero30', 'vol10', 'rvjpy', 'grade_n', 'app_prob', 'regconf', 'hour', 'wkend']
def design(df, d, fresh):
    cols = {}
    for c in SIGNED: cols[c] = df[c].values * d
    for c in SIGNED_FRESH: cols[c] = (df[c].values * d) if fresh else np.zeros(len(df))
    for c in UNSIGNED: cols[c] = df[c].values.astype(float)
    for s in INST: cols['is_' + s] = (df.inst.values == s).astype(float)
    for r in REG: cols['rg_' + r] = (df.regime.values == r).astype(float)
    cols['dir'] = np.full(len(df), float(d))
    X = np.column_stack([cols[k] for k in cols]); return X, list(cols)
def model():
    return HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, max_leaf_nodes=15, min_samples_leaf=1500,
                                          l2_regularization=1.0, random_state=0)
def fit(df, fresh):
    Xu, names = design(df, 1, fresh); Xd, _ = design(df, -1, fresh)
    X = np.vstack([Xu, Xd]); y = np.r_[(df.move3.values == 1), (df.move3.values == -1)].astype(int)
    return model().fit(X, y), names
def score(m, df, fresh):
    Xu, _ = design(df, 1, fresh); Xd, _ = design(df, -1, fresh)
    return m.predict_proba(Xu)[:, 1], m.predict_proba(Xd)[:, 1]
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
res = {}
for fresh in (False, True):
    parts = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        m, names = fit(P[P.half == tr], fresh)
        t = P[P.half == te].copy(); pu, pd_ = score(m, t, fresh)
        t['p_up'] = pu; t['p_dn'] = pd_; t['dir'] = np.where(pu >= pd_, 1, -1); t['p'] = np.maximum(pu, pd_)
        t['win'] = (t.move3 == t.dir).astype(int); parts.append(t)
    T = pd.concat(parts); res[fresh] = T
    best = T.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
    print(f'\n===== 直前の価格を {"使う" if fresh else "使わない"} =====')
    for seg, m_ in (('平日', best.weekday), ('土日', ~best.weekday)):
        bb = best[m_]
        for rate in ((0.25, 0.50, 0.74, 0.85, 1.0) if seg == '平日' else (0.46, 0.60, 1.0)):
            thr = bb.groupby('half').p.transform(lambda v: v.quantile(1 - rate)) if rate < 1 else -1
            e = bb[bb.p >= thr]
            hs = ' '.join(f'{h} {e[e.half == h].win.mean() * 100:5.1f}' for h in ('H1', 'H2'))
            print(f'  {seg} 枠の{rate * 100:3.0f}%: 勝率 {e.win.mean() * 100:5.1f}% ({hs}) 件数 {len(e):5d} 引分 {(e.move3 == 0).mean() * 100:4.1f}% 最大連敗 {ms(e.win.values):2d}  {e.inst.value_counts(normalize=True).round(2).to_dict()}')
# current app on the same slots
top = P[P.order == 1]; cur = top[top.app_grade != 'E']
for seg, m_ in (('平日', cur.weekday), ('土日', ~cur.weekday)):
    e = cur[m_]; w = (e.move3 == e.app_dir).astype(int)
    print(f'現行アプリ {seg}: 勝率 {w.mean() * 100:5.1f}% (H1 {w[e.half == "H1"].mean() * 100:5.1f} H2 {w[e.half == "H2"].mean() * 100:5.1f}) 件数 {len(e)} 枠の{len(e) / top[top.weekday == (seg == "平日")].b.nunique() * 100:4.1f}%  最大連敗 {ms(w.values)}')
pickle.dump(res, open('../work/evidence_model_oos.pkl', 'wb'))

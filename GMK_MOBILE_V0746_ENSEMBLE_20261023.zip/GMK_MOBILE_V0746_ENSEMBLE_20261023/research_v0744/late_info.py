"""Does the last minute before entry (bar B-60..B, not used by the app today) carry information?"""
import gzip, csv, numpy as np, pandas as pd, datetime as dt, pickle
JST = dt.timezone(dt.timedelta(hours=9))
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
T0 = int(dt.datetime(2025, 10, 1, tzinfo=JST).timestamp()) // 60
N = int(dt.datetime(2026, 10, 22, tzinfo=JST).timestamp()) // 60 - T0
def load(p):
    o = np.full(N, np.nan); c = o.copy()
    with gzip.open(p, 'rt') as f:
        for r in csv.DictReader(f):
            m = int(r['epoch_ms']) // 60000 - T0
            if 0 <= m < N: o[m] = float(r['open']); c[m] = float(r['close'])
    return o, c
H = pd.read_pickle('../work/hyp_features.pkl')
out = []
for s, p in SRC.items():
    o, c = load(p)
    x = H[H.inst == s]
    bm = (x.b.values // 60 - T0).astype(int)
    cL = c[bm - 1]; cP = c[bm - 2]; oB = o[bm]; oB1 = o[bm + 1]
    lr = np.log(cL) - np.log(cP)
    y = pd.DataFrame({'b': x.b.values, 'inst': s, 'n1L': lr / x.rv60.values,
                      'gapL': (np.log(oB) - np.log(cL)) / x.rv60.values,
                      'okL': ~np.isnan(cL) & ~np.isnan(cP)})
    out.append(y)
L = pd.concat(out)
H = H.merge(L, on=['b', 'inst'])
H['half'] = np.where(pd.to_datetime(H.date) < pd.Timestamp('2026-04-01'), 'H1', 'H2')
H.to_pickle('../work/hyp_late.pkl')
mv = H.move3.values
def rate(mask, d):
    m = mask & ~np.isnan(d) & (d != 0)
    w = (mv[m] == d[m]).mean() * 100; h1 = m & (H.half.values == 'H1'); h2 = m & (H.half.values == 'H2')
    return f'{w:5.1f}%  n={m.sum():6d}  前半 {(mv[h1]==d[h1]).mean()*100:5.1f}  後半 {(mv[h2]==d[h2]).mean()*100:5.1f}'
FX = H.inst.isin(['USDJPY','EURJPY','GBPJPY','AUDJPY','NZDJPY']).values & (H.dow.values < 5)
BT = (H.inst == 'BTCJPY').values
print('draw rate (move3==0):', H.groupby('inst').move3.apply(lambda v: round((v == 0).mean() * 100, 1)).to_dict())
for nm, m in [('為替', FX), ('BTC', BT)]:
    print(f'\n== {nm}: 直前1分 (B-60→B) の動きと次の3分 ==')
    for lo, hi in [(0.3, 0.8), (0.8, 1.5), (1.5, 2.5), (2.5, 99)]:
        mm = m & H.okL.values & (np.abs(H.n1L.values) >= lo) & (np.abs(H.n1L.values) < hi)
        print(f'  |n1L| {lo}-{hi}: 逆張り {rate(mm, -np.sign(H.n1L.values))}')
    print('  比較: 今アプリが見ている直近1分 (B-120→B-60)')
    for lo, hi in [(0.3, 0.8), (0.8, 1.5), (1.5, 2.5), (2.5, 99)]:
        mm = m & (np.abs(H.n1.values) >= lo) & (np.abs(H.n1.values) < hi)
        print(f'  |n1 | {lo}-{hi}: 逆張り {rate(mm, -np.sign(H.n1.values))}')

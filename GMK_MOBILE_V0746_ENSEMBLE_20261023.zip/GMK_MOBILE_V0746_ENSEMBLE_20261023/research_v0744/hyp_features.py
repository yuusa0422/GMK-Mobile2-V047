"""Research features computed directly from 1-minute candles, causal at decision time.
At boundary B the app sees completed bars up to the bar that opens at B-120 (closes at B-60).
Outcome: open(B+180) vs open(B)  (same as the app's 3-minute judgement)."""
import gzip, csv, sys, numpy as np, pandas as pd, datetime as dt
JST = dt.timezone(dt.timedelta(hours=9))
FX = ['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
T0 = int(dt.datetime(2025, 10, 1, 0, 0, tzinfo=JST).timestamp()) // 60
T1 = int(dt.datetime(2026, 10, 22, 0, 0, tzinfo=JST).timestamp()) // 60
N = T1 - T0

def load(path):
    o = np.full(N, np.nan); h = o.copy(); l = o.copy(); c = o.copy()
    with gzip.open(path, 'rt') as f:
        for r in csv.DictReader(f):
            m = int(r['epoch_ms']) // 60000 - T0
            if 0 <= m < N:
                o[m] = float(r['open']); h[m] = float(r['high']); l[m] = float(r['low']); c[m] = float(r['close'])
    return o, h, l, c

def ffill(a):
    idx = np.where(~np.isnan(a), np.arange(len(a)), 0)
    np.maximum.accumulate(idx, out=idx)
    out = a[idx]; out[:np.argmax(~np.isnan(a))] = np.nan
    return out

def roll_std(x, w):
    s = pd.Series(x); return s.rolling(w, min_periods=int(w * 0.8)).std().values

def roll_corr_lag1(x, w):
    s = pd.Series(x); return s.rolling(w, min_periods=int(w * 0.8)).corr(s.shift(1)).values

out = []
data = {s: load(p) for s, p in SRC.items()}
feat = {}
for s, (o, h, l, c) in data.items():
    have = ~np.isnan(c)
    cf = ffill(c); lc = np.log(cf)
    r1 = np.diff(lc, prepend=np.nan)
    r1_obs = np.where(have, r1, np.nan)
    rv60 = roll_std(r1, 60); rv240 = roll_std(r1, 240)
    ac1_240 = roll_corr_lag1(r1, 240)
    r5s = pd.Series(lc).diff(5).values
    vr5 = pd.Series(r5s).rolling(240, min_periods=190).var().values / (5 * pd.Series(r1).rolling(240, min_periods=190).var().values)
    hh15 = pd.Series(np.where(have, h, np.nan)).rolling(15, min_periods=10).max().values
    ll15 = pd.Series(np.where(have, l, np.nan)).rolling(15, min_periods=10).min().values
    hh60 = pd.Series(np.where(have, h, np.nan)).rolling(60, min_periods=45).max().values
    ll60 = pd.Series(np.where(have, l, np.nan)).rolling(60, min_periods=45).min().values
    obs60 = pd.Series(have.astype(float)).rolling(60).sum().values
    feat[s] = dict(o=o, c=c, cf=cf, lc=lc, rv60=rv60, rv240=rv240, ac1=ac1_240, vr5=vr5, hh15=hh15, ll15=ll15, hh60=hh60, ll60=ll60, obs60=obs60, have=have)

rows = []
day = dt.date(2025, 10, 1)
while day <= dt.date(2026, 10, 21):
    for hh in range(9, 23):
        for mm in range(0, 60, 5):
            B = int(dt.datetime(day.year, day.month, day.day, hh, mm, tzinfo=JST).timestamp())
            bm = B // 60 - T0; t = bm - 2   # index of bar opening at B-120
            if t < 300 or bm + 3 >= N: continue
            for s in feat:
                if day.weekday() >= 5 and s != 'BTCJPY': continue
                F = feat[s]
                if not F['have'][t] or np.isnan(F['o'][bm]) or np.isnan(F['o'][bm + 3]) or F['obs60'][t] < 45: continue
                p = F['cf'][t]; rv = F['rv60'][t]
                if not rv or np.isnan(rv) or rv <= 0: continue
                rec = dict(b=B, inst=s, date=day, hour=hh, minute=mm, dow=day.weekday(), price=p, rv60=rv, rv240=F['rv240'][t],
                           ac1=F['ac1'][t], vr5=F['vr5'][t], move3=int(np.sign(F['o'][bm + 3] - F['o'][bm])))
                for k in (1, 2, 3, 5, 10, 15, 30, 60, 120, 240):
                    if t - k >= 0: rec[f'n{k}'] = (F['lc'][t] - F['lc'][t - k]) / (rv * np.sqrt(k))
                rec['pos15'] = (p - F['ll15'][t]) / max(F['hh15'][t] - F['ll15'][t], 1e-12) * 2 - 1
                rec['pos60'] = (p - F['ll60'][t]) / max(F['hh60'][t] - F['ll60'][t], 1e-12) * 2 - 1
                if s != 'BTCJPY':
                    for step, nm in ((0.5, 'r50'), (1.0, 'r100')):
                        lv = np.round(p / step) * step
                        rec[nm + '_dist'] = (p - lv) / 0.01               # pips from nearest round level
                        rec[nm + '_lvl'] = lv
                        # crossed within last 15 minutes?  (+1 crossed upward, -1 downward)
                        lo, hi = F['ll15'][t], F['hh15'][t]
                        lv15 = np.round(F['cf'][t - 15] / step) * step if t >= 15 else np.nan
                        below = F['cf'][t - 15] < lv <= p if t >= 15 else False
                        above = F['cf'][t - 15] > lv >= p if t >= 15 else False
                        rec[nm + '_cross'] = 1 if below else (-1 if above else 0)
                else:
                    step = 100000.0
                    lv = np.round(p / step) * step
                    rec['r50_dist'] = (p - lv) / (rv * p); rec['r50_cross'] = 0
                rows.append(rec)
    day += dt.timedelta(days=1)
df = pd.DataFrame(rows)
# yen factor (4 crosses, normalised returns), per slot
fx4 = df[df.inst.isin(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY'])]
for k in (5, 15, 30):
    yf = fx4.groupby('b')[f'n{k}'].mean().rename(f'yen{k}')
    df = df.merge(yf, on='b', how='left')
    df[f'idio{k}'] = df[f'n{k}'] - df[f'yen{k}']
df.to_pickle('../work/hyp_features.pkl')
print(df.shape, df.inst.value_counts().to_dict())

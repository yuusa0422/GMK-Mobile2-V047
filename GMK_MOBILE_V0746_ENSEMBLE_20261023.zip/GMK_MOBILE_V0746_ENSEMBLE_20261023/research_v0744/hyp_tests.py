import pandas as pd, numpy as np, datetime as dt, sys
df = pd.read_pickle('../work/hyp_features.pkl')
df['half'] = np.where(pd.to_datetime(df.date) < pd.Timestamp('2026-04-01'), 'H1', 'H2')
mv = df.move3.values
def w(d): return ((mv != 0) & (np.sign(mv) == d)).astype(float)
out_rows = []
def test(cat, name, mask, d, minimum=150):
    mask = np.asarray(mask) & ~np.isnan(np.asarray(d, dtype=float))
    d = np.asarray(d, dtype=float)
    x = df[mask]; dd = d[mask]
    if len(x) < minimum: return
    win = ((x.move3.values != 0) & (np.sign(x.move3.values) == dd)).astype(float)
    opp = ((x.move3.values != 0) & (np.sign(x.move3.values) == -dd)).astype(float)
    h1 = (x.half == 'H1').values
    r = dict(区分=cat, 仮説=name, 件数=len(x), 勝率=win.mean() * 100, 前半=win[h1].mean() * 100 if h1.sum() else np.nan,
             後半=win[~h1].mean() * 100 if (~h1).sum() else np.nan, 反対=opp.mean() * 100, 引分=(x.move3.values == 0).mean() * 100,
             前半件数=int(h1.sum()), 後半件数=int((~h1).sum()))
    out_rows.append(r)
FX4 = df.inst.isin(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY'])
FX5 = df.inst.isin(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY'])
BTC = df.inst == 'BTCJPY'
HIGH = np.ones(len(df)); LOW = -HIGH
s5 = np.sign(df.n5.values); s2 = np.sign(df.n2.values); s15 = np.sign(df.n15.values); s30 = np.sign(df.n30.values)
tmin = df.hour * 60 + df.minute
# ---------- A: Tokyo fix ----------
d = pd.to_datetime(df.date)
gotobi = (d.dt.day % 5 == 0) | (d.dt.is_month_end)
for nm, m in [('全通貨', FX5), ('USDJPY', df.inst == 'USDJPY')]:
    test('仲値(9:55)', f'{nm} 9:00-9:50 HIGH', m & (tmin >= 540) & (tmin <= 590), HIGH)
    test('仲値(9:55)', f'{nm} 9:30-9:50 HIGH', m & (tmin >= 570) & (tmin <= 590), HIGH)
    test('仲値(9:55)', f'{nm} 9:55-10:25 LOW', m & (tmin >= 595) & (tmin <= 625), LOW)
    test('仲値(9:55)', f'{nm} 9:30-9:50 HIGH 五十日', m & (tmin >= 570) & (tmin <= 590) & gotobi, HIGH, 50)
    test('仲値(9:55)', f'{nm} 9:55-10:25 LOW 五十日', m & (tmin >= 595) & (tmin <= 625) & gotobi, LOW, 50)
# ---------- B: hour-of-day HIGH bias ----------
for h in range(9, 23):
    test('時間帯の偏り', f'為替 {h}時台 HIGH', FX5 & (df.hour == h), HIGH)
    test('時間帯の偏り', f'BTC {h}時台 HIGH', BTC & (df.hour == h), HIGH)
# ---------- C: round numbers (Osler) ----------
for lvl in ['r50', 'r100']:
    dist = df[lvl + '_dist'].values
    up_to = (dist < 0) & (dist >= -5) & (df.n5 > 0)        # just below level after rising -> take-profit sells -> LOW
    dn_to = (dist > 0) & (dist <= 5) & (df.n5 < 0)          # just above level after falling -> take-profit buys -> HIGH
    test('キリ番', f'{lvl} 直下まで上昇→反落(LOW)', FX5 & up_to, LOW)
    test('キリ番', f'{lvl} 直上まで下落→反発(HIGH)', FX5 & dn_to, HIGH)
    test('キリ番', f'{lvl} 15分以内に上抜け→加速(HIGH)', FX5 & (df[lvl + '_cross'] == 1), HIGH)
    test('キリ番', f'{lvl} 15分以内に下抜け→加速(LOW)', FX5 & (df[lvl + '_cross'] == -1), LOW)
    near = np.abs(dist) <= 3
    test('キリ番', f'{lvl} ±3pips以内で5分の動きに逆張り', FX5 & near & (np.abs(df.n5) >= 0.3), -s5)
# ---------- D: news / shocks ----------
def us_dst(day):
    y = day.year
    mar = dt.date(y, 3, 8); mar += dt.timedelta(days=(6 - mar.weekday()) % 7)
    nov = dt.date(y, 11, 1); nov += dt.timedelta(days=(6 - nov.weekday()) % 7)
    return mar <= day < nov
dst = np.array([us_dst(x) for x in df.date])
us830 = np.where(dst, 21 * 60 + 30, 22 * 60 + 30)
after = tmin.values - us830
for lag in (5, 10):
    m = FX5 & (after == lag) & (df.dow < 5)
    test('米指標(8:30ET)', f'発表{lag}分後 直近2分に順張り', m, s2, 50)
    test('米指標(8:30ET)', f'発表{lag}分後 直近5分に順張り', m, s5, 50)
m = BTC & (after == 5) & (df.dow < 5); test('米指標(8:30ET)', 'BTC 発表5分後 直近5分に順張り', m, s5, 50)
for thr in (2.5, 3.5):
    test('急変', f'為替 |5分|>={thr} 順張り', FX5 & (np.abs(df.n5) >= thr), s5)
    test('急変', f'BTC |5分|>={thr} 順張り', BTC & (np.abs(df.n5) >= thr), s5)
# ---------- E: yen factor vs pair-specific ----------
for k in (5, 15):
    test('円全体と個別', f'個別成分|idio{k}|>=1.0 に逆張り', FX4 & (np.abs(df[f'idio{k}']) >= 1.0), -np.sign(df[f'idio{k}'].values))
    test('円全体と個別', f'円全体|yen{k}|>=1.0 に順張り', FX4 & (np.abs(df[f'yen{k}']) >= 1.0), np.sign(df[f'yen{k}'].values))
    test('円全体と個別', f'円全体|yen{k}|>=1.0 に逆張り', FX4 & (np.abs(df[f'yen{k}']) >= 1.0), -np.sign(df[f'yen{k}'].values))
# ---------- F: adaptive regime (240-min lag-1 autocorrelation of 1-min returns) ----------
for nm, m in [('為替', FX5), ('BTC', BTC)]:
    q = df.loc[m, 'ac1'].quantile([1 / 3, 2 / 3]).values
    for lab, mm in [('自己相関 低(反転型)', df.ac1 <= q[0]), ('自己相関 中', (df.ac1 > q[0]) & (df.ac1 <= q[1])), ('自己相関 高(継続型)', df.ac1 > q[1])]:
        test('相場の型(過去4時間)', f'{nm} {lab}: 5分に逆張り', m & mm & (np.abs(df.n5) >= 0.6), -s5)
        test('相場の型(過去4時間)', f'{nm} {lab}: 5分に順張り', m & mm & (np.abs(df.n5) >= 0.6), s5)
    q = df.loc[m, 'vr5'].quantile([1 / 3, 2 / 3]).values
    for lab, mm in [('分散比 低(反転型)', df.vr5 <= q[0]), ('分散比 高(継続型)', df.vr5 > q[1])]:
        test('相場の型(過去4時間)', f'{nm} {lab}: 5分に逆張り', m & mm & (np.abs(df.n5) >= 0.6), -s5)
        test('相場の型(過去4時間)', f'{nm} {lab}: 5分に順張り', m & mm & (np.abs(df.n5) >= 0.6), s5)
# ---------- G: volatility condition for reversal ----------
vr = df.rv60 / df.rv240
for nm, m in [('為替', FX5), ('BTC', BTC)]:
    q = vr[m].quantile([1 / 3, 2 / 3]).values
    for lab, mm in [('直近の変動 小', vr <= q[0]), ('直近の変動 大', vr > q[1])]:
        test('変動の大きさ', f'{nm} {lab}: 5分に逆張り', m & mm & (np.abs(df.n5) >= 0.6), -s5)
        test('変動の大きさ', f'{nm} {lab}: 15分に逆張り', m & mm & (np.abs(df.n15) >= 0.6), -s15)
# ---------- H: BTC specifics ----------
for nm, h0, h1 in [('BTC 9時(資金調達)', 535, 560), ('BTC 17時(資金調達)', 1015, 1040)]:
    test('BTC', f'{nm} 前後 5分に順張り', BTC & (tmin >= h0) & (tmin <= h1), s5, 100)
for k, sk in [(15, s15), (30, s30)]:
    test('BTC', f'BTC {k}分の動きに順張り', BTC & (np.abs(df[f'n{k}']) >= 0.6), sk)
    test('BTC', f'BTC 平日 {k}分の動きに順張り', BTC & (df.dow < 5) & (np.abs(df[f'n{k}']) >= 0.6), sk)
    test('BTC', f'BTC 土日 {k}分の動きに順張り', BTC & (df.dow >= 5) & (np.abs(df[f'n{k}']) >= 0.6), sk)
# ---------- baselines ----------
test('基準', '為替 全枠 HIGH', FX5, HIGH); test('基準', '為替 全枠 LOW', FX5, LOW)
test('基準', 'BTC 全枠 HIGH', BTC, HIGH); test('基準', 'BTC 全枠 LOW', BTC, LOW)
test('基準', '為替 5分に逆張り(|5分|>=0.6)', FX5 & (np.abs(df.n5) >= 0.6), -s5)
r = pd.DataFrame(out_rows).round(1)
r['前後半で50%超'] = np.where((r.前半 > 50) & (r.後半 > 50), '○', '')
r.to_csv('../work/hypothesis_results.csv', index=False, encoding='utf-8-sig')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300); pd.set_option('display.max_colwidth', 42)
print(r.to_string(index=False))

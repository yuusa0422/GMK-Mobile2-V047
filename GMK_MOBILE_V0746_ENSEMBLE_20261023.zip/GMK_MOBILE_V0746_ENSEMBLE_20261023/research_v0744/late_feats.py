"""Fresh features that include the last minute before entry (bar opening at B-60, i.e. price just before B)."""
import gzip, csv, numpy as np, pandas as pd, datetime as dt
JST = dt.timezone(dt.timedelta(hours=9))
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
T0 = int(dt.datetime(2025, 10, 1, tzinfo=JST).timestamp()) // 60
N = int(dt.datetime(2026, 10, 22, tzinfo=JST).timestamp()) // 60 - T0
def load(p):
    o = np.full(N, np.nan); h = o.copy(); l = o.copy(); c = o.copy()
    with gzip.open(p, 'rt') as f:
        for r in csv.DictReader(f):
            m = int(r['epoch_ms']) // 60000 - T0
            if 0 <= m < N: o[m] = float(r['open']); h[m] = float(r['high']); l[m] = float(r['low']); c[m] = float(r['close'])
    return o, h, l, c
def ffill(a):
    idx = np.where(~np.isnan(a), np.arange(len(a)), 0); np.maximum.accumulate(idx, out=idx)
    out = a[idx]; out[:np.argmax(~np.isnan(a))] = np.nan; return out
H = pd.read_pickle('../work/hyp_late.pkl')
parts = []
for s, p in SRC.items():
    o, h, l, c = load(p)
    have = ~np.isnan(c); cf = ffill(c); lc = np.log(cf)
    hh = pd.Series(np.where(have, h, np.nan)).rolling(15, min_periods=10).max().values
    ll = pd.Series(np.where(have, l, np.nan)).rolling(15, min_periods=10).min().values
    x = H[H.inst == s]; bm = (x.b.values // 60 - T0).astype(int); L = bm - 1
    rv = x.rv60.values
    d = {'b': x.b.values, 'inst': s, 'freshOK': have[L]}
    for k in (2, 3, 5, 10, 15, 30):
        d[f'n{k}L'] = (lc[L] - lc[L - k]) / (rv * np.sqrt(k))
    d['pos15L'] = (cf[L] - ll[L]) / np.maximum(hh[L] - ll[L], 1e-12) * 2 - 1
    parts.append(pd.DataFrame(d))
F = pd.concat(parts)
H = H.merge(F, on=['b', 'inst'])
fx4 = H[H.inst.isin(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY'])]
for k in ('1L', '5L', '15L'):
    yf = fx4.groupby('b')[f'n{k}'].mean().rename(f'yen{k}')
    H = H.merge(yf, on='b', how='left'); H[f'idio{k}'] = H[f'n{k}'] - H[f'yen{k}']
H.to_pickle('../work/hyp_fresh.pkl'); print(H.shape)

"""What should pausing do if outcomes are pure chance? Same days/slot counts, Bernoulli(p) outcomes, same rules."""
import numpy as np, pandas as pd, pickle
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))[True]
x = S[S.enter & S.weekday].sort_values('b')
counts = x.groupby('date').size().values; p = x.win.mean()
rng = np.random.default_rng(5)
def day_max_taken(w, k, m):
    taken = []; streak = 0; skip = 0
    for a in w:
        if skip > 0:
            skip -= 1; streak = 0 if a else streak + 1; continue
        taken.append(a); streak = 0 if a else streak + 1
        if k and streak >= k: skip = m
    mx = c = 0
    for a in taken:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx, len(taken)
for k, m in ((0, 0), (3, 1), (3, 3), (5, 3), (5, 6)):
    d8 = []; d10 = []; share = []
    for _ in range(300):
        res = [day_max_taken(rng.random(n) < p, k, m) for n in counts]
        mx = np.array([r[0] for r in res]); d8.append((mx >= 8).mean()); d10.append((mx >= 10).mean()); share.append(sum(r[1] for r in res) / counts.sum())
    print(f'偶然の場合 {("なし" if k == 0 else f"{k}連敗で{m}回休む"):12s}: 入る {np.mean(share)*100:5.1f}%  8連敗以上の日 {np.mean(d8)*100:4.1f}% (90%範囲 {np.percentile(d8,5)*100:.1f}-{np.percentile(d8,95)*100:.1f})  10連敗以上 {np.mean(d10)*100:4.1f}%')

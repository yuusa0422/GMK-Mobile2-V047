"""Streak countermeasures on v0.7.44 weekday trades (out-of-sample decisions). Each rule is applied causally in time order."""
import pandas as pd, numpy as np, pickle, json
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))[True]
x = S[S.enter & S.weekday].sort_values('b').reset_index(drop=True)
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def evaluate(name, wins, halves, dates):
    t = pd.DataFrame({'win': wins, 'half': halves, 'date': dates}); dm = t.groupby('date').win.apply(lambda v: ms(v.values))
    r = dict(rule=name, n=len(t), share=round(len(t) / len(x) * 100, 1), win=round(t.win.mean() * 100, 2), H1=round(t[t.half == 'H1'].win.mean() * 100, 1),
             H2=round(t[t.half == 'H2'].win.mean() * 100, 1), maxs=ms(t.win.values), day_avg=round(dm.mean(), 2), day8=round((dm >= 8).mean() * 100, 1), day10=round((dm >= 10).mean() * 100, 1))
    print(r); return r
res = [evaluate('なし（v0.7.44）', x.win.values, x.half.values, x.date.values)]
def rule_pause(k, m):
    out = []; streak = 0; skip = 0; prev = None
    for r in x.itertuples(index=False):
        if r.date != prev: streak = 0; skip = 0; prev = r.date
        if skip > 0:
            skip -= 1; streak = 0 if r.win else streak + 1   # virtual result still observed
            continue
        out.append(r); streak = 0 if r.win else streak + 1
        if streak >= k: skip = m
    t = pd.DataFrame(out); return evaluate(f'{k}連敗で{m}回休む', t.win.values, t.half.values, t.date.values)
def rule_stop(k):
    out = []; streak = 0; stopped = False; prev = None
    for r in x.itertuples(index=False):
        if r.date != prev: streak = 0; stopped = False; prev = r.date
        if stopped: continue
        out.append(r); streak = 0 if r.win else streak + 1
        if streak >= k: stopped = True
    t = pd.DataFrame(out); return evaluate(f'{k}連敗でその日は終了', t.win.values, t.half.values, t.date.values)
def rule_flip(k):
    wins = []; streak = 0; prev = None
    for r in x.itertuples(index=False):
        if r.date != prev: streak = 0; prev = r.date
        w = r.win if streak < k else int(r.move3 == -r.dir)
        wins.append(w); streak = 0 if w else streak + 1
    return evaluate(f'{k}連敗中は向きを逆にする', np.array(wins), x.half.values, x.date.values)
def rule_flip_same(k):
    wins = []; hist = []; prev = None
    for r in x.itertuples(index=False):
        if r.date != prev: hist = []; prev = r.date
        last = hist[-k:]
        flip = len(last) == k and all(w == 0 for w, _ in last) and len({d for _, d in last}) == 1 and last[-1][1] == r.dir
        w = int(r.move3 == -r.dir) if flip else r.win
        wins.append(w); hist.append((w, r.dir if not flip else -r.dir))
    return evaluate(f'同じ向きで{k}連敗したら次は逆向き', np.array(wins), x.half.values, x.date.values)
for k, m in ((3, 1), (3, 3), (5, 3), (5, 6)): res.append(rule_pause(k, m))
for k in (5, 8): res.append(rule_stop(k))
for k in (3, 5): res.append(rule_flip(k))
for k in (2, 3): res.append(rule_flip_same(k))
json.dump(res, open('../work/countermeasures.json', 'w'), ensure_ascii=False, indent=1)

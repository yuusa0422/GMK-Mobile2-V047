import pandas as pd, numpy as np, pickle
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))
P = pd.read_pickle('../work/policy_data.pkl')
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
cur = P[(P.order == 1) & ~P.weekday].copy(); cur['go'] = cur.app_grade != 'E'; cur['win'] = (cur.move3 == cur.app_dir).astype(int)
cur['wkd'] = cur.ts.dt.to_period('W')
c = cur.groupby('wkd').go.mean(); cd = cur.groupby('date').go.mean()
print(f'現行 土日: 週末ごとのENTRY率 最小{c.min()*100:.0f}% 中央{c.median()*100:.0f}% 最大{c.max()*100:.0f}% / 日ごと 最小{cd.min()*100:.0f}% 中央{cd.median()*100:.0f}% 最大{cd.max()*100:.0f}%')
for fresh in (True, False):
    W = S[fresh][~S[fresh].weekday].sort_values('b').copy()
    W['wkd'] = pd.to_datetime(W.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.to_period('W')
    off = W.groupby(['half', 'hour']).p.median().unstack(0)
    W['adj'] = W.p - np.where(W.half == 'H1', W.hour.map(off['H2']), W.hour.map(off['H1']))
    for N in (288, 480, 576, 672, 864):
        x = W.copy(); thr = x.adj.shift(1).rolling(N, min_periods=96).quantile(0.54)
        x['go'] = np.where(thr.isna(), x.enter, x.adj >= thr)
        e = x[x.go]; dm = e.groupby('date').win.apply(lambda v: ms(v.values)); wk = x.groupby('wkd').go.mean(); cd = x.groupby('date').go.mean()
        print(f'{"直前価格あり" if fresh else "予備"} N={N:4d}: 入る {x.go.mean()*100:4.1f}% (週末ごと {wk.min()*100:.0f}-{wk.median()*100:.0f}-{wk.max()*100:.0f}%, 日ごと {cd.min()*100:.0f}-{cd.median()*100:.0f}-{cd.max()*100:.0f}%) 勝率 {e.win.mean()*100:5.1f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} H2 {e[e.half=="H2"].win.mean()*100:5.1f}) 引分 {(e.move3==0).mean()*100:4.1f}% 最大連敗 {ms(e.win.values):2d} 1日平均 {dm.mean():.2f} 8+ {(dm>=8).mean()*100:4.1f}% 10+ {(dm>=10).mean()*100:3.1f}%')

import pandas as pd, numpy as np
X = pd.read_pickle('../work/trades_runs.pkl')
rng = np.random.default_rng(0)
for pol in ('new', 'cur'):
    x = X[(X.policy == pol) & X.weekday].sort_values('b').reset_index(drop=True)
    long = x[(x.run_len >= 6) & (x.win == 0)]
    hs = long.groupby('run').d.apply(lambda v: max((v == 1).mean(), (v == -1).mean()))
    # baseline: random windows of the same length inside the same day
    base = []
    for L in long.groupby('run').size().values:
        for _ in range(30):
            i = rng.integers(0, len(x) - L); w = x.d.values[i:i + L]; base.append(max((w == 1).mean(), (w == -1).mean()))
    print(f'{pol} 平日: 6連敗以上の中の同じ向きの割合 {hs.mean()*100:.1f}% / 同じ長さの任意区間 {np.mean(base)*100:.1f}%')
    # next trade after k consecutive losses that were all in the same direction
    print('  直前の連敗が全部同じ向きのとき、次の取引:')
    d = x.d.values; w = x.win.values; date = x.date.values; half = x.half.values
    for k in (2, 3, 4):
        same = []; opp = []
        for i in range(k, len(x)):
            if not (date[i - k:i] == date[i]).all(): continue
            if w[i - k:i].sum() != 0: continue
            if len(set(d[i - k:i])) != 1: continue
            (same if d[i] == d[i - 1] else opp).append((w[i], half[i]))
        s = np.array([a for a, _ in same]); o = np.array([a for a, _ in opp])
        sh = {h: np.mean([a for a, hh in same if hh == h]) * 100 for h in ('H1', 'H2')}
        oh = {h: np.mean([a for a, hh in opp if hh == h]) * 100 for h in ('H1', 'H2')}
        print(f'   {k}連敗(同じ向き)の後 → また同じ向き {s.mean()*100:5.1f}% ({len(s)}件, H1 {sh["H1"]:.1f} H2 {sh["H2"]:.1f}) / 逆向き {o.mean()*100:5.1f}% ({len(o)}件, H1 {oh["H1"]:.1f} H2 {oh["H2"]:.1f})')
    # same instrument
    ins = x.inst.values
    for k in (2, 3):
        same = []; other = []
        for i in range(k, len(x)):
            if not (date[i - k:i] == date[i]).all() or w[i - k:i].sum() != 0: continue
            if len(set(ins[i - k:i])) != 1: continue
            (same if ins[i] == ins[i - 1] else other).append(w[i])
        print(f'   {k}連敗(同じ通貨)の後 → 同じ通貨 {np.mean(same)*100:5.1f}% ({len(same)}件) / 別の通貨 {np.mean(other)*100:5.1f}% ({len(other)}件)')

"""v0.7.45: weekend quota 47% over a 576-slot window. Models unchanged; only the weekend seed quantiles change."""
import pickle, numpy as np, pandas as pd
exec(open('evidence_model.py').read().split('def model():')[0])
M = pickle.load(open('../work/production_models.pkl', 'rb'))
for fresh in (True, False):
    Xu, _ = design(P, 1, fresh); Xd, _ = design(P, -1, fresh)
    pu = M['models'][fresh].predict_proba(Xu)[:, 1]; pdn = M['models'][fresh].predict_proba(Xd)[:, 1]
    t = P[['b', 'weekday', 'hour']].copy(); t['p'] = np.maximum(pu, pdn)
    best = t.sort_values('p', ascending=False).groupby('b').head(1)
    x = best[~best.weekday].copy(); st = M['stats']['fresh' if fresh else 'fallback']['weekend']
    off = dict(zip(range(9, 23), st['offset'])); x['adj'] = x.p - x.hour.map(off)
    old = st['seed']; st['seed'] = float(x.adj.quantile(1 - 0.47))
    print('fresh' if fresh else 'fallback', 'weekend seed', old, '->', st['seed'])
pickle.dump(M, open('../work/production_models_v0745.pkl', 'wb'))

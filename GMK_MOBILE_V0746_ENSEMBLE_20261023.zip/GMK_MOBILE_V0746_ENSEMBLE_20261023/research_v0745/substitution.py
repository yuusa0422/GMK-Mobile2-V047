"""Regime-feedback substitution: after k losses in the same direction, avoid that direction for M slots
(choose the best remaining candidate). Entry decisions (which slots) are unchanged -> same number of trades."""
import pandas as pd, numpy as np, pickle, json
C = pd.read_pickle('../work/oos_candidates.pkl')
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))[True][['b', 'enter']]
C = C.merge(S, on='b'); C = C[C.weekday & C.enter]
slots = []
for b, g in C.groupby('b', sort=True):
    rows = []
    for r in g.itertuples(index=False):
        for d, p in ((1, r.p_up), (-1, r.p_dn)):
            rows.append((p, d, r.inst, int(r.move3 == d), r.yen30, r.r30))
    rows.sort(key=lambda t: -t[0])
    slots.append((b, g.date.iloc[0], g.half.iloc[0], rows))
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def simulate(k, M, mode):
    wins = []; halves = []; dates = []; hist = []; block = 0; blocked_dir = 0; prev = None; switched = 0
    for b, date, half, rows in slots:
        if date != prev: hist = []; block = 0; prev = date
        choice = rows[0]
        if k and block > 0:
            alt = [r for r in rows if not (r[1] == blocked_dir and (mode == 'all' or (mode == 'fx' and r[2] != 'BTCJPY') or (mode == 'trend' and r[2] != 'BTCJPY' and np.sign(r[4]) == -blocked_dir)))]
            if alt and alt[0] is not rows[0]: switched += 1
            if alt: choice = alt[0]
            block -= 1
        w = choice[3]; wins.append(w); halves.append(half); dates.append(date)
        hist.append((w, choice[1]))
        if w: block = 0
        last = hist[-k:] if k else []
        if k and len(last) == k and all(x == 0 for x, _ in last) and len({d for _, d in last}) == 1:
            block = M; blocked_dir = last[-1][1]
    t = pd.DataFrame({'win': wins, 'half': halves, 'date': dates}); dm = t.groupby('date').win.apply(lambda v: ms(v.values))
    return dict(k=k, M=M, mode=mode, win=round(t.win.mean() * 100, 2), H1=round(t[t.half == 'H1'].win.mean() * 100, 2), H2=round(t[t.half == 'H2'].win.mean() * 100, 2),
                maxs=ms(t.win.values), day8=round((dm >= 8).mean() * 100, 1), day10=round((dm >= 10).mean() * 100, 1), switched=switched)
res = [simulate(0, 0, 'none')]
for k in (2, 3, 4):
    for M in (1, 3, 6, 12):
        for mode in ('all', 'fx', 'trend'):
            res.append(simulate(k, M, mode))
R = pd.DataFrame(res); pd.set_option('display.width', 200); print(R.to_string())
R.to_json('../work/substitution.json', force_ascii=False, orient='records')

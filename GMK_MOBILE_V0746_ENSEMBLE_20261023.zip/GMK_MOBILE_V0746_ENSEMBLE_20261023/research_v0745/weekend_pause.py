import numpy as np, pandas as pd, pickle
S = pickle.load(open('../work/sim_app_policy_v0745.pkl', 'rb'))[True]
x = S[S.enter & ~S.weekday].sort_values('b')
rng = np.random.default_rng(7)
def taken_max(w, k, m):
    taken = []; streak = 0; skip = 0
    for a in w:
        if skip > 0: skip -= 1; streak = 0 if a else streak + 1; continue
        taken.append(a); streak = 0 if a else streak + 1
        if k and streak >= k: skip = m
    mx = c = 0
    for a in taken:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx, len(taken), sum(taken)
p = x.win.mean(); counts = x.groupby('date').size().values
for k, m in ((0, 0), (3, 3), (5, 6)):
    res = [taken_max(g.win.values, k, m) for _, g in x.groupby('date')]
    mx = np.array([r[0] for r in res]); n = sum(r[1] for r in res); w = sum(r[2] for r in res)
    sims = []
    for _ in range(300):
        rr = [taken_max(rng.random(c) < p, k, m)[0] for c in counts]; sims.append(np.mean(np.array(rr) >= 8))
    print(f'土日(v0.7.45) {("なし" if k == 0 else f"{k}連敗で{m}回休む"):12s}: 入る {n/len(x)*100:5.1f}% 勝率 {w/n*100:5.1f}% 8連敗以上の日 実際 {np.mean(mx>=8)*100:4.1f}% / 偶然なら {np.mean(sims)*100:4.1f}%  10+ {np.mean(mx>=10)*100:4.1f}%')

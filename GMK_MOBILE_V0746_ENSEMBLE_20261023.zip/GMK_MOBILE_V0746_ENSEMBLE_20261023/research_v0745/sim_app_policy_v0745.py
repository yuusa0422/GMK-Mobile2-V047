"""Exact simulation of the app decision rule on unseen data (fold model trained on the other half):
hour offset + seed from the training half (in-sample), adaptive buffer (N=288, min 96) on the test half."""
import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, random_state=0, early_stopping=False)
RATE = {True: 0.74, False: 0.47}; NBUFD = {True: 288, False: 576}; NMIN = 96
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def best_slots(m, df, fresh):
    Xu, _ = design(df, 1, fresh); Xd, _ = design(df, -1, fresh)
    pu = m.predict_proba(Xu)[:, 1]; pdn = m.predict_proba(Xd)[:, 1]
    t = df[['b', 'inst', 'weekday', 'hour', 'move3', 'half', 'date']].copy(); t['p'] = np.maximum(pu, pdn); t['dir'] = np.where(pu >= pdn, 1, -1)
    t['win'] = (t.move3 == t.dir).astype(int)
    return t.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
def simulate(test, offs, seeds):
    out = []
    for wk in (True, False):
        x = test[test.weekday == wk].sort_values('b').copy()
        adj = (x.p - x.hour.map(offs[wk])).values; buf = []; enter = []; grade = []
        for a in adj:
            if len(buf) >= NMIN:
                arr = np.array(buf); thr = np.quantile(arr, 1 - RATE[wk]); q50 = np.quantile(arr, 0.5); q75 = np.quantile(arr, 0.75)
            else: thr, q50, q75 = seeds[wk]
            e = a >= thr; enter.append(e); grade.append(('A' if a >= q75 else 'B' if a >= q50 else 'C') if e else 'E')
            buf.append(a); buf = buf[-NBUFD[wk]:]
        x['enter'] = enter; x['grade'] = grade; out.append(x)
    return pd.concat(out).sort_values('b')
allsim = {}
for fresh in (True, False):
    sims = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        A = P[P.half == tr]
        Xu, _ = design(A, 1, fresh); Xd, _ = design(A, -1, fresh)
        m = HistGradientBoostingClassifier(**CFG).fit(np.vstack([Xu, Xd]), np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int))
        btr = best_slots(m, A, fresh); offs = {}; seeds = {}
        for wk in (True, False):
            x = btr[btr.weekday == wk]; off = x.groupby('hour').p.median(); offs[wk] = off
            adj = x.p - x.hour.map(off); seeds[wk] = (adj.quantile(1 - RATE[wk]), adj.quantile(0.5), adj.quantile(0.75))
        sims.append(simulate(best_slots(m, P[P.half == te], fresh), offs, seeds))
    S = pd.concat(sims).sort_values('b'); allsim[fresh] = S
    print(f'\n===== {"直前価格あり" if fresh else "直前価格なし（予備）"}: アプリと同じ判定方法で未知データに適用 =====')
    for wk in (True, False):
        x = S[S.weekday == wk]; e = x[x.enter]
        g = x.groupby(['date', 'hour']).agg(n=('enter', 'size'), k=('enter', 'sum')); g = g[g.n == 12]
        dm = e.groupby('date').win.apply(lambda v: ms(v.values))
        print(f' {"平日" if wk else "土日"}: 入る {len(e)/len(x)*100:4.1f}% (H1 {x[x.half=="H1"].enter.mean()*100:4.1f} / H2 {x[x.half=="H2"].enter.mean()*100:4.1f}; 時間帯別 {x.groupby("hour").enter.mean().min()*100:.0f}-{x.groupby("hour").enter.mean().max()*100:.0f}%)'
              f'  勝率 {e.win.mean()*100:5.1f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} / H2 {e[e.half=="H2"].win.mean()*100:5.1f}; 引分除く {e[e.move3!=0].win.mean()*100:4.1f}%)'
              f'  件数 {len(e)}  最大連敗 {ms(e.win.values)}  1日の最大連敗 平均 {dm.mean():.1f} / 8連敗以上の日 {(dm>=8).mean()*100:.0f}%')
        for gr in 'ABC':
            y = e[e.grade == gr]
            print(f'     ランク{gr}: {y.win.mean()*100:5.1f}% ({len(y)}件, H1 {y[y.half=="H1"].win.mean()*100:5.1f} / H2 {y[y.half=="H2"].win.mean()*100:5.1f})')
        print('     通貨:', (e.inst.value_counts(normalize=True) * 100).round(0).astype(int).to_dict(), ' 通貨別勝率:', e.groupby('inst').win.mean().mul(100).round(1).to_dict())
pickle.dump(allsim, open('../work/sim_app_policy_v0745.pkl', 'wb'))

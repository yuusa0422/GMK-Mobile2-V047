"""Are wins/losses clustered beyond chance?  runs test, autocorrelation, over-dispersion of daily/hourly win rates."""
import pandas as pd, numpy as np
X = pd.read_pickle('../work/trades_runs.pkl')
rng = np.random.default_rng(1)
def max_streak_by_day(df):
    out = []
    for _, g in df.groupby('date'):
        m = c = 0
        for w in g.win.values:
            c = 0 if w else c + 1; m = max(m, c)
        out.append(m)
    return np.array(out)
for pol in ('new', 'cur'):
    for wk in (True, False):
        x = X[(X.policy == pol) & (X.weekday == wk)].sort_values('b')
        w = x.win.values.astype(float); p = w.mean()
        ac = [np.corrcoef(w[:-k], w[k:])[0, 1] for k in (1, 2, 3, 6, 12)]
        # runs test
        runs = 1 + (w[1:] != w[:-1]).sum(); n1 = w.sum(); n0 = len(w) - n1
        mu = 2 * n1 * n0 / len(w) + 1; var = (mu - 1) * (mu - 2) / (len(w) - 1); z = (runs - mu) / np.sqrt(var)
        # over-dispersion of daily and hourly win rates
        disp = {}
        for key in ('date', ['date', 'hour']):
            g = x.groupby(key).win.agg(['mean', 'size']); g = g[g['size'] >= (40 if key == 'date' else 6)]
            exp_var = (p * (1 - p) / g['size']).mean(); disp['日' if key == 'date' else '時間'] = g['mean'].var() / exp_var
        # simulated daily max streaks under independence with the same per-day counts and p
        obs = max_streak_by_day(x)
        sims = []
        for _ in range(200):
            xs = x[['date']].copy(); xs['win'] = (rng.random(len(x)) < p).astype(int); sims.append(max_streak_by_day(xs))
        sims = np.array(sims)
        print(f'{pol} {"平日" if wk else "土日"}: 勝率{p*100:.1f}% 自己相関(1,2,3,6,12件後)', np.round(ac, 3), f'ラン検定 z={z:+.2f}',
              f'分散の倍率 日{disp["日"]:.2f} 時間{disp["時間"]:.2f}',
              f'| 1日の最大連敗 実際 平均{obs.mean():.2f}・8+ {np.mean(obs>=8)*100:.1f}% / 偶然なら 平均{sims.mean():.2f}・8+ {np.mean(sims>=8)*100:.1f}% (範囲 {np.percentile((sims>=8).mean(1)*100,5):.1f}〜{np.percentile((sims>=8).mean(1)*100,95):.1f}%)')

"""Out-of-sample probabilities for every candidate x direction (2-fold), to test substitution rules."""
import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, random_state=0, early_stopping=False)
parts = []
for tr, te in (('H1', 'H2'), ('H2', 'H1')):
    A = P[P.half == tr]
    Xu, _ = design(A, 1, True); Xd, _ = design(A, -1, True)
    m = HistGradientBoostingClassifier(**CFG).fit(np.vstack([Xu, Xd]), np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int))
    Bt = P[P.half == te].copy(); Yu, _ = design(Bt, 1, True); Yd, _ = design(Bt, -1, True)
    Bt['p_up'] = m.predict_proba(Yu)[:, 1]; Bt['p_dn'] = m.predict_proba(Yd)[:, 1]
    parts.append(Bt[['b', 'inst', 'weekday', 'hour', 'half', 'date', 'move3', 'p_up', 'p_dn', 'r30', 'r60', 'f1', 'yen15', 'regime']])
C = pd.concat(parts)
y30 = C[C.inst.isin(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY'])].groupby('b').r30.mean().rename('yen30')
C = C.merge(y30, on='b', how='left')
C.to_pickle('../work/oos_candidates.pkl'); print(C.shape)

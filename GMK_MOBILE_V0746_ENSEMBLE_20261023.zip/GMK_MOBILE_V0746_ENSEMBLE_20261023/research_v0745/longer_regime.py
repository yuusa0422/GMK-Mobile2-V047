"""Do 2-4 hour regime features (trend vs range: autocorrelation, variance ratio, 2h/4h move, vol ratio) add out-of-sample value?"""
import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
H = pd.read_pickle('../work/hyp_features.pkl')[['b', 'inst', 'ac1', 'vr5', 'n120', 'n240', 'rv240', 'rv60']].rename(columns={'rv60': 'rv60h'})
P2 = P.merge(H, on=['b', 'inst'], how='left')
P2['volr240'] = P2.rv60h / P2.rv240
for c in ['ac1', 'vr5', 'n120', 'n240', 'volr240']: P2[c] = P2[c].fillna(P2[c].median())
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, random_state=0, early_stopping=False)
def design2(df, d, fresh, extra):
    X, names = design(df, d, fresh)
    if not extra: return X
    add = np.column_stack([df.ac1.values, df.vr5.values, df.volr240.values, df.n120.values * d, df.n240.values * d])
    return np.hstack([X, add])
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
for extra in (False, True):
    parts = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        A = P2[P2.half == tr]
        m = HistGradientBoostingClassifier(**CFG).fit(np.vstack([design2(A, 1, True, extra), design2(A, -1, True, extra)]), np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int))
        Bt = P2[P2.half == te].copy(); pu = m.predict_proba(design2(Bt, 1, True, extra))[:, 1]; pdn = m.predict_proba(design2(Bt, -1, True, extra))[:, 1]
        Bt['p'] = np.maximum(pu, pdn); Bt['dir'] = np.where(pu >= pdn, 1, -1); Bt['win'] = (Bt.move3 == Bt.dir).astype(int); parts.append(Bt)
    T = pd.concat(parts); best = T.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
    for wk, rate in ((True, 0.74), (False, 0.47)):
        x = best[best.weekday == wk].copy()
        x['adj'] = x.p - x.groupby(['half', 'hour']).p.transform('median')
        thr = x.adj.shift(1).rolling(288 if wk else 576, min_periods=96).quantile(1 - rate)
        e = x[np.where(thr.isna(), True, x.adj >= thr)]
        dm = e.groupby('date').win.apply(lambda v: ms(v.values))
        print(f'{"4時間の相場の型を追加" if extra else "v0.7.45の入力のまま"} {"平日" if wk else "土日"}: 勝率 {e.win.mean()*100:5.2f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} H2 {e[e.half=="H2"].win.mean()*100:5.1f}) 件数 {len(e)} 最大連敗 {ms(e.win.values)} 8+ {(dm>=8).mean()*100:.1f}%')

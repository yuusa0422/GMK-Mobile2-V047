"""Per-trade dataset for loss/streak autopsy: v0.7.44 (out-of-sample) and the current app."""
import pickle, gzip, csv, math, numpy as np, pandas as pd, datetime as dt
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
idx = {}
for s, p in SRC.items():
    d = {}
    with gzip.open(p, 'rt') as f:
        for r in csv.DictReader(f): d[int(r['epoch_ms']) // 1000] = (float(r['open']), float(r['high']), float(r['low']), float(r['close']))
    idx[s] = d
P = pd.read_pickle('../work/policy_data.pkl')
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))[True]
new = S[S.enter][['b', 'inst', 'dir', 'p', 'grade', 'win', 'move3']].rename(columns={'dir': 'd'})
new['policy'] = 'new'
cur = P[(P.order == 1) & (P.app_grade != 'E')][['b', 'inst', 'app_dir', 'app_grade', 'move3']].rename(columns={'app_dir': 'd', 'app_grade': 'grade'})
cur['win'] = (cur.move3 == cur.d).astype(int); cur['p'] = np.nan; cur['policy'] = 'cur'
T = pd.concat([new, cur], ignore_index=True)
T = T.merge(P.drop(columns=['move3', 'grade'] if 'grade' in P.columns else ['move3']), on=['b', 'inst'], how='left')
# realised path after entry (normalised by the 1-minute RMS used by the model)
def path(r):
    d = idx[r.inst]; B = int(r.b); o0 = d.get(B)
    if o0 is None: return (np.nan,) * 5
    o0 = o0[0]; sig = r.rv60 / 1e4 * o0
    o3 = d.get(B + 180); o1 = d.get(B + 60); o2 = d.get(B + 120)
    hi = max(x[1] for x in (d.get(B), o1, o2) if x); lo = min(x[2] for x in (d.get(B), o1, o2) if x)
    m3 = (o3[0] - o0) / sig if o3 else np.nan
    fav = ((hi - o0) if r.d == 1 else (o0 - lo)) / sig          # best point in our favour during 3 minutes
    adv = ((o0 - lo) if r.d == 1 else (hi - o0)) / sig          # worst point against us
    m1 = (o1[0] - o0) / sig if o1 else np.nan
    return m3, fav, adv, m1, sig
vals = np.array([path(r) for r in T.itertuples(index=False)])
T['mv3_sig'] = vals[:, 0]; T['fav'] = vals[:, 1]; T['adv'] = vals[:, 2]; T['mv1_sig'] = vals[:, 3]
T['signed_mv3'] = T.mv3_sig * T.d                                 # + = our way, - = against
T['fade_last'] = np.sign(T.f1) == -T.d                            # we traded against the last minute
T['with_r30'] = np.sign(T.r30) == T.d
T['cont_last'] = np.sign(T.mv3_sig) == np.sign(T.f1)              # market continued the last-minute move
T['ts'] = pd.to_datetime(T.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo')
T['minute'] = T.ts.dt.minute; T['dow'] = T.ts.dt.dayofweek
def loss_type(r):
    if r.win == 1: return '勝ち'
    if r.move3 == 0: return '引き分け'
    a = abs(r.mv3_sig)
    if a >= 2.0: return '大きく逆行(2σ以上)'
    if a < 0.5: return '小さな逆行(0.5σ未満)'
    if r.fav >= 0.5: return '一度は有利→逆転'
    return '素直に逆行'
T['loss_type'] = [loss_type(r) for r in T.itertuples(index=False)]
T = T.sort_values(['policy', 'b']).reset_index(drop=True)
T.to_pickle('../work/trades.pkl')
print(T.groupby('policy').size().to_dict(), T.mv3_sig.isna().mean())

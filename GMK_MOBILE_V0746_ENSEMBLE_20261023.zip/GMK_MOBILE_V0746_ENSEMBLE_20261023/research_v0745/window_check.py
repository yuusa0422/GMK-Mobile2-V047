import pandas as pd, numpy as np, pickle, warnings
warnings.filterwarnings('ignore')
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))[True]
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def sim(wk, N, rate):
    x = S[S.weekday == wk].sort_values('b').copy()
    off = x.groupby(['half', 'hour']).p.median().unstack(0)
    x['adj'] = x.p - np.where(x.half == 'H1', x.hour.map(off['H2']), x.hour.map(off['H1']))
    thr = x.adj.shift(1).rolling(N, min_periods=96).quantile(1 - rate)
    x['go'] = np.where(thr.isna(), x.enter, x.adj >= thr); e = x[x.go]
    dm = e.groupby('date').win.apply(lambda v: ms(v.values)); hr = x.groupby('hour').go.mean()
    print(f'{"平日" if wk else "土日"} N={N} 目標{rate*100:.0f}%: 入る {x.go.mean()*100:4.1f}% (時間帯 {hr.min()*100:.0f}-{hr.max()*100:.0f}%) 勝率 {e.win.mean()*100:5.1f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} H2 {e[e.half=="H2"].win.mean()*100:5.1f}) 最大連敗 {ms(e.win.values)} 1日平均 {dm.mean():.2f} 8+ {(dm>=8).mean()*100:4.1f}% 10+ {(dm>=10).mean()*100:3.1f}%')
for N in (288, 576, 1152): sim(True, N, 0.74)
for r in (0.46, 0.47, 0.48): sim(False, 576, r)

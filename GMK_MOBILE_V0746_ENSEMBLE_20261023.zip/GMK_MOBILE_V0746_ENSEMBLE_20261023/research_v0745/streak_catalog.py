import pandas as pd, numpy as np, json
X = pd.read_pickle('../work/trades_runs_v0745.pkl')
X['方式'] = np.where(X.policy == 'new', 'v0.7.45', '現行')
DOW = '月火水木金土日'
rows = []
for (pol, wkd, run), g in X[(X.run_len >= 6) & (X.win == 0)].groupby(['方式', 'weekday', 'run']):
    g = g.sort_values('b')
    lt = g.loss_type.value_counts().to_dict()
    usd = g.inst.tolist()
    rows.append({'方式': pol, '日付': str(g.date.iloc[0]), '曜日': DOW[g.ts.iloc[0].dayofweek], '開始': g.ts.iloc[0].strftime('%H:%M'), '終了': g.ts.iloc[-1].strftime('%H:%M'),
                 '連敗数': len(g), '通貨の並び': ' '.join(s.replace('JPY', '') for s in usd), '向きの並び': ' '.join('H' if d == 1 else 'L' for d in g.d),
                 '同じ向きの割合%': round(max((g.d == 1).mean(), (g.d == -1).mean()) * 100), '引き分け': lt.get('引き分け', 0),
                 '大きく逆行': lt.get('大きく逆行(2σ以上)', 0), '一度は有利→逆転': lt.get('一度は有利→逆転', 0), '小さな逆行': lt.get('小さな逆行(0.5σ未満)', 0), '素直に逆行': lt.get('素直に逆行', 0),
                 '平均の予測勝率%': round(g.p.mean() * 100, 1) if g.p.notna().any() else '', '直前1分に逆張りの割合%': round(g.fade_last.mean() * 100)})
C = pd.DataFrame(rows).sort_values(['方式', '連敗数', '日付'], ascending=[True, False, True])
C.to_csv('../pages/GMK_連敗カタログ.csv', index=False, encoding='utf-8-sig')
print(len(C), 'streaks >=6'); print(C[C['方式'] == 'v0.7.45'].head(12).to_string())
# observed vs chance: number of streaks of each length (same days, same per-day counts, same p)
rng = np.random.default_rng(11)
out = {}
for pol in ('new', 'cur'):
    for wk in (True, False):
        x = X[(X.policy == pol) & (X.weekday == wk)]
        obs = x[x.run_pos == 1].run_len.value_counts()
        counts = x.groupby('date').size().values; p = x.win.mean()
        sim = np.zeros(20)
        R = 200
        for _ in range(R):
            for n in counts:
                w = rng.random(n) < p; c = 0
                for a in w:
                    if a:
                        if c: sim[min(c, 19)] += 1
                        c = 0
                    else: c += 1
                if c: sim[min(c, 19)] += 1
        sim /= R
        key = f'{"v0.7.45" if pol == "new" else "現行"} {"平日" if wk else "土日"}'
        out[key] = {'obs': {int(L): int(obs.get(L, 0)) for L in range(1, 19)}, 'chance': {L: round(sim[L], 1) for L in range(1, 19)},
                    'obs_6plus': int(obs[obs.index >= 6].sum()), 'chance_6plus': round(sim[6:].sum(), 1), 'obs_8plus': int(obs[obs.index >= 8].sum()), 'chance_8plus': round(sim[8:].sum(), 1),
                    'obs_10plus': int(obs[obs.index >= 10].sum()), 'chance_10plus': round(sim[10:].sum(), 1)}
        print(key, '6連敗以上', out[key]['obs_6plus'], '偶然なら', out[key]['chance_6plus'], '| 8以上', out[key]['obs_8plus'], 'vs', out[key]['chance_8plus'], '| 10以上', out[key]['obs_10plus'], 'vs', out[key]['chance_10plus'])
json.dump(out, open('../work/streak_vs_chance.json', 'w'), ensure_ascii=False, indent=1)

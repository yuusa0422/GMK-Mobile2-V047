v0.7.45 負け・連敗の分析コード（参考・再現用。アプリのビルドには使いません）
 trades_build.py      取引ごとに3分間の値動き（有利・不利の最大、2σ以上の逆行、引き分け）を付ける
 loss_anatomy.py      負け方の分類と、条件ごとの勝率（前半・後半）
 streak_anatomy.py    連敗の長さの分布、連敗の中の負け方・通貨・向き
 streak_direction.py  同じ向き・同じ通貨で負け続けた後の次の勝率
 streak_stats.py      自己相関・ラン検定・日ごと/時間ごとのばらつき・偶然との比較
 streak_catalog.py    6連敗以上の一覧（GMK_連敗カタログ.csv）と偶然の場合の回数
 countermeasures.py / pause_sim.py / weekend_pause.py  休む・止める・向きを逆にする等の対策と、偶然の場合の比較
 oos_candidates.py / substitution.py  負けた向きを避けて別候補に差し替える対策
 longer_regime*.py    2〜4時間の相場の型を入力に加えた場合
 weekend_days.py / weekend_window.py / window_check.py  土日の「静かな日」と配分（採用）
 sim_app_policy_v0745.py / reseed_v0745.py  v0.7.45 の判定の再現と土日の初期値

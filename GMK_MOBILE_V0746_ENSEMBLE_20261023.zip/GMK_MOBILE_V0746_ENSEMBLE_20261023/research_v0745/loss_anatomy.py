import pandas as pd, numpy as np
T = pd.read_pickle('../work/trades.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
for pol in ('cur', 'new'):
    for wk in (True, False):
        x = T[(T.policy == pol) & (T.weekday == wk)]
        lt = x.loss_type.value_counts(normalize=True).mul(100).round(1)
        print(f'{pol} {"平日" if wk else "土日"} n={len(x)}:', lt.to_dict())
x = T[(T.policy == 'new') & T.weekday]
L = x[x.win == 0]
print('\n新・平日の負け: 逆張りで負け', round((L.fade_last).mean() * 100, 1), '% / そのうち直前の動きがそのまま続いた', round(L[L.fade_last].cont_last.mean() * 100, 1), '%')
print('新・平日の勝ち/負けの平均: 有利方向の最大(σ)', x.groupby('win').fav.mean().round(2).to_dict(), ' 逆行の最大', x.groupby('win').adv.mean().round(2).to_dict())
# condition table for new policy weekday: loss rate by bucket, both halves
def tab(x, col, buckets=None, labels=None):
    g = x[col] if buckets is None else pd.cut(x[col], buckets, labels=labels)
    t = x.groupby(g, observed=True).agg(n=('win', 'size'), win=('win', 'mean'))
    t['H1'] = x[x.half == 'H1'].groupby(g[x.half == 'H1'], observed=True).win.mean(); t['H2'] = x[x.half == 'H2'].groupby(g[x.half == 'H2'], observed=True).win.mean()
    t[['win', 'H1', 'H2']] = (t[['win', 'H1', 'H2']] * 100).round(1); return t
x = x.copy(); x['absf1'] = x.f1.abs(); x['absr30'] = x.r30.abs(); x['absr60'] = x.r60.abs()
x['rvq'] = pd.qcut(x.rv60, 5, labels=['低', 'やや低', '中', 'やや高', '高'])
x['fade'] = np.where(x.fade_last, '直前に逆張り', '直前に順張り')
for col, b, l in [('hour', None, None), ('minute', None, None), ('dow', None, None), ('inst', None, None), ('grade', None, None), ('fade', None, None), ('regime', None, None),
                  ('rvq', None, None), ('rv30_60', [0, 0.8, 1.0, 1.2, 1.5, 9], ['縮小', 'やや縮小', 'やや拡大', '拡大', '急拡大']),
                  ('absr60', [0, 0.5, 1, 1.5, 2, 99], None), ('absf1', [0, 0.5, 1, 1.5, 2.5, 99], None)]:
    print(f'\n--- 新・平日 {col} ---'); print(tab(x, col, b, l).to_string())

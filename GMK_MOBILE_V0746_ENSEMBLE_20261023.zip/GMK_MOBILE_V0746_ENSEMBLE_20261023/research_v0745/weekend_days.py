import pandas as pd, numpy as np, pickle
S = pickle.load(open('../work/sim_app_policy.pkl', 'rb'))[True]
P = pd.read_pickle('../work/policy_data.pkl')
W = S[~S.weekday].sort_values('b').copy()
B = P[(P.inst == 'BTCJPY') & ~P.weekday][['b', 'tie58', 'vol10', 'rvjpy', 'zero30']]
W = W.merge(B, on='b', how='left')
W['tie'] = (W.move3 == 0).astype(int)
d = W.groupby('date').agg(tie=('tie', 'mean'), win_all=('win', 'mean'), morning_tie58=('tie58', lambda v: v.iloc[:24].mean()))
e = W[W.enter].groupby('date').agg(win=('win', 'mean'), n=('win', 'size'))
d = d.join(e)
d['q'] = pd.qcut(d.morning_tie58, 4, labels=['朝の引分リスク 低', 'やや低', 'やや高', '高'])
print('土日の日ごと: 朝(9-11時)の引き分けリスクで4分割 → その日のENTRYの勝率と引き分け率')
print(d.groupby('q', observed=True).agg(days=('win', 'size'), win=('win', 'mean'), tie=('tie', 'mean')).assign(win=lambda t: (t.win * 100).round(1), tie=lambda t: (t.tie * 100).round(1)).to_string())
print('日ごとの勝率と引き分け率の相関:', round(np.corrcoef(d.win.fillna(d.win.mean()), d.tie)[0, 1], 2))
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def run(rule, N=None, seed_q=None):
    x = W.copy()
    off = x.groupby(['half', 'hour']).p.median().unstack(0)
    x['adj'] = x.p - np.where(x.half == 'H1', x.hour.map(off['H2']), x.hour.map(off['H1']))
    if rule == 'rolling':
        thr = x.adj.shift(1).rolling(N, min_periods=96).quantile(0.54)
        x['go'] = np.where(thr.isna(), x.enter, x.adj >= thr)
    else:   # fixed threshold from the other half
        q = x.groupby('half').adj.quantile(0.54)
        x['go'] = x.adj >= np.where(x.half == 'H1', q['H2'], q['H1'])
    e = x[x.go]; dm = e.groupby('date').win.apply(lambda v: ms(v.values)); cov = x.groupby('date').go.mean()
    print(f'{rule}{"" if N is None else N:>6}: 入る {x.go.mean()*100:4.1f}% (日ごと 最小{cov.min()*100:.0f}% 中央{cov.median()*100:.0f}% 最大{cov.max()*100:.0f}%) 勝率 {e.win.mean()*100:5.1f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} H2 {e[e.half=="H2"].win.mean()*100:5.1f}) 引分 {(e.move3==0).mean()*100:4.1f}% 最大連敗 {ms(e.win.values)} 1日平均 {dm.mean():.2f} 8+ {(dm>=8).mean()*100:.1f}% 10+ {(dm>=10).mean()*100:.1f}%')
for N in (288, 672, 1344, 2688): run('rolling', N)
run('fixed')

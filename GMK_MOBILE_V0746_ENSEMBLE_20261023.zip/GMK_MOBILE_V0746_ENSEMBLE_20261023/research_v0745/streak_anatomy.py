import pandas as pd, numpy as np
T = pd.read_pickle('../work/trades.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300); pd.set_option('display.max_colwidth', 60)
def streaks(x):
    """label every trade with the id/length of the within-day losing run it belongs to"""
    x = x.sort_values('b').copy(); rid = np.zeros(len(x), int); cur = 0; k = 0; prev_date = None
    for i, (w, d) in enumerate(zip(x.win.values, x.date.values)):
        if d != prev_date: cur += 1; prev_date = d
        if w == 1: cur += 1; rid[i] = -1; cur += 1
        else: rid[i] = cur
    x['run'] = rid
    ln = x[x.run >= 0].groupby('run').size(); x['run_len'] = x.run.map(ln).fillna(0).astype(int)
    pos = x[x.run >= 0].groupby('run').cumcount() + 1; x['run_pos'] = 0; x.loc[pos.index, 'run_pos'] = pos
    return x
out = []
for pol in ('new', 'cur'):
    for wk in (True, False):
        x = streaks(T[(T.policy == pol) & (T.weekday == wk)])
        out.append(x)
        L = x[x.win == 0]
        print(f'\n===== {pol} {"平日" if wk else "土日"}: 負け {len(L)} 件 =====')
        print(' 連敗の長さ別の件数（その長さの連敗が何回起きたか）:', x[x.run_pos == 1].run_len.value_counts().sort_index().to_dict())
        long = x[(x.run_len >= 6) & (x.win == 0)]
        print(f' 6連敗以上の中の負け {len(long)} 件の内訳:', long.loss_type.value_counts(normalize=True).mul(100).round(1).to_dict())
        print('  比較: 全ての負けの内訳      :', L.loss_type.value_counts(normalize=True).mul(100).round(1).to_dict())
        for col in ['fade_last', 'with_r30']:
            print(f'  {col}: 6連敗以上の中 {long[col].mean()*100:5.1f}% / 全取引 {x[col].mean()*100:5.1f}%')
        for col in ['rv60', 'rv30_60', 'r60', 'f1', 'p']:
            if col in x and x[col].notna().any():
                print(f'  |{col}| 平均: 6連敗以上の中 {long[col].abs().mean():.3f} / 全取引 {x[col].abs().mean():.3f}')
        print('  6連敗以上が起きた時間帯(開始時刻):', x[(x.run_pos == 1) & (x.run_len >= 6)].hour.value_counts().sort_index().to_dict())
        print('  6連敗以上の中の通貨:', long.inst.value_counts(normalize=True).mul(100).round(0).to_dict(), ' 全取引:', x.inst.value_counts(normalize=True).mul(100).round(0).to_dict())
        # direction homogeneity inside streak
        g = long.groupby('run')
        homo = g.d.apply(lambda v: max((v == 1).mean(), (v == -1).mean())).mean()
        same_inst = g.inst.apply(lambda v: v.value_counts(normalize=True).iloc[0]).mean()
        print(f'  1つの連敗の中で同じ向きの割合(平均) {homo*100:.0f}% / 同じ通貨の割合 {same_inst*100:.0f}%')
pd.concat(out).to_pickle('../work/trades_runs.pkl')

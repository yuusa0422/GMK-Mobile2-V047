"""v0.7.44 evidence model: source gate layered on the unchanged v0.7.43 audit.

Every v0.7.43 check is re-run. Only rows for the explicitly modified files, the DIP-specific
v0.7.43 policy rows and the two version rows are re-pinned here; every other row must still
pass on its own. Each modified file must also reduce exactly to its v0.7.43 bytes when the
documented v0.7.44 edit is removed.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()

VM = 'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt'
REPO = 'app/src/main/java/jp/gmk/mobile/data/MarketRepository.kt'
ASSESS = 'app/src/main/java/jp/gmk/mobile/domain/CandidateAssessment.kt'
GRADLE = 'app/build.gradle.kts'
POLICY = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt'
DATA = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceModelData.kt'

VM_NEW = '''                // v0.7.44: final evidence-model ENTRY decision after every optional overlay.
                // Live quotes: Yahoo meta from this scan's candle fetch + the LIVE rate rows (BTC stream).
                val liveQuotes = EvidencePolicy.newestQuotes(LiveQuoteBoard.snapshot(), EvidencePolicy.quotesFromRates(liveRates.values.toList()))
                EvidencePolicy.apply(native, horizonRuntime.apply(native, eligible, prefs.forceThreeMinuteOutcome), eligible, liveQuotes)
'''
VM_OLD = '''                // v0.7.43: final evidence-based ENTRY decision after every optional overlay.
                EvidencePolicy.apply(native, horizonRuntime.apply(native, eligible, prefs.forceThreeMinuteOutcome), eligible)
'''
REPO_BLOCK = '''                // v0.7.44: the newest quote in this scan response is the live price ~10 s before entry
                // used by EvidencePolicy. Candles below are unchanged (completed minutes only).
                result.optJSONObject("meta")?.let { meta ->
                    val quoteSec = meta.optLong("regularMarketTime", 0L)
                    val quote = meta.optDouble("regularMarketPrice", Double.NaN)
                    if (quoteSec > 0L && quote.isFinite() && quote > 0.0) LiveQuoteBoard.record(instrument, quote, quoteSec * 1000L)
                }
'''
REPO_IMPORT = 'import jp.gmk.mobile.domain.LiveQuoteBoard\n'
ASSESS_LINE = '    LOW_EXPECTANCY("検証モデルで期待値が低い枠（平日は下位26%・土日は下位54%）のため見送り（観察のみ）"),\n'


def audit():
    spec = importlib.util.spec_from_file_location('v0743_audit', ROOT/'tools/audit_v0743.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0744_source_extension.json').read_text())
    changed = manifest['modified_existing']
    gradle = (ROOT/GRADLE).read_text()
    vm = (ROOT/VM).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0744_evidence_model:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.43 source bytes plus the pinned v0.7.44 change only.')
        elif name == 'evidence_policy_frozen_parameters':
            policy = (ROOT/POLICY).read_text()
            row.update(check='evidence_model_frozen_parameters', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0744_EVIDENCE_MODEL"', 'const val WEEKDAY_ENTRY_RATE = 0.74', 'const val WEEKEND_ENTRY_RATE = 0.46',
                'const val BUFFER_SIZE = 288', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
                'if (decision.enter) null else CandidateSkipReason.LOW_EXPECTANCY'))},
                detail='v0.7.44: entry quota 74%/46% of slots, rolling 288 AUTO slots (seeded until 96), live quote <= 40 s.')
        elif name == 'evidence_policy_runs_after_every_overlay':
            row.update(check='evidence_policy_runs_after_every_overlay_with_live_quotes', **{'pass': VM_NEW in vm and vm.count('horizonRuntime.apply(') == 1})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*114\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.44-evidence-model"' in gradle

    def check(name, ok, detail=None):
        row = {'check': name, 'pass': bool(ok)}
        if detail is not None: row['detail'] = detail
        result['results'].append(row)

    v0743 = json.loads((ROOT/'tools/v0743_source_extension.json').read_text())
    v0743_hashes = {p: x['updated_sha256'] for p, x in v0743['modified_existing'].items()} | v0743['new_source_files']
    for path, item in changed.items():
        known = v0743_hashes.get(path)
        check('v0743_original_before_v0744:' + path, known is None or known == item['v0743_sha256'])
        check('pinned_v0744_change:' + path, sha(ROOT/path) == item['updated_sha256'])
    for path, digest in manifest['new_source_files'].items():
        check('pinned_new_v0744_source:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    # Each edit is exactly the documented one.
    check('viewmodel_only_live_quote_call_changed', VM_NEW in vm and sha_text(vm.replace(VM_NEW, VM_OLD)) == changed[VM]['v0743_sha256'])
    repo = (ROOT/REPO).read_text()
    check('repository_only_records_yahoo_meta_quote', repo.count('LiveQuoteBoard.record(') == 1 and REPO_BLOCK in repo and REPO_IMPORT in repo
          and sha_text(repo.replace(REPO_BLOCK, '').replace(REPO_IMPORT, '')) == changed[REPO]['v0743_sha256'])
    assess = (ROOT/ASSESS).read_text()
    check('assessment_only_adds_low_expectancy_reason', ASSESS_LINE in assess and sha_text(assess.replace(ASSESS_LINE, '')) == changed[ASSESS]['v0743_sha256'])
    check('gradle_only_version_changed', sha_text(gradle.replace('versionCode = 114', 'versionCode = 113')
          .replace('versionName = "0.7.44-evidence-model"', 'versionName = "0.7.43-entry-guard"')) == changed[GRADLE]['v0743_sha256'])
    data = (ROOT/DATA).read_text()
    check('embedded_model_hashes_match_release_manifest',
          f'const val FRESH_SHA256 = "{manifest["model_text_sha256"]["fresh"]}"' in data
          and f'const val FALLBACK_SHA256 = "{manifest["model_text_sha256"]["fallback"]}"' in data)
    policy = (ROOT/POLICY).read_text()
    check('policy_never_promotes_outside_session', 'if (!TradingSession.isActive(entry)) return skipTop(' in policy)
    check('weekend_pool_is_btc_only', 'native.candidates.filter { !weekend || it.instrument == "BTCJPY" }' in policy)
    check('evidence_tests_present', all((ROOT/'app/src/test/java'/n).is_file() for n in
          ('EvidenceModelParityTest.kt', 'EvidencePolicyTest.kt', 'EvidenceFixture.kt', 'TradingSessionTest.kt', 'EntryQualityGuardTest.kt'))
          and (ROOT/'app/src/test/resources/v0744_evidence_parity.txt.gz').is_file())
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0744_EVIDENCE_MODEL_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']],
                  current_version='0.7.44-evidence-model')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

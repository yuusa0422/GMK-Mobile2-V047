"""v0.7.45 weekend regime: source gate layered on the unchanged v0.7.44 audit.

Every v0.7.44 check is re-run. Rows that fail only because a v0.7.45-modified file changed are
re-pinned to the v0.7.45 bytes; the v0.7.44 parameter/edit rows are re-checked with the new values.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()

POLICY = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt'
DATA = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceModelData.kt'
ASSESS = 'app/src/main/java/jp/gmk/mobile/domain/CandidateAssessment.kt'
GRADLE = 'app/build.gradle.kts'
ASSESS_V0745 = '    LOW_EXPECTANCY("検証モデルで期待値が低い枠（平日は下位26%・土日は下位53%）のため見送り（観察のみ）"),\n'
ASSESS_V0744 = '    LOW_EXPECTANCY("検証モデルで期待値が低い枠（平日は下位26%・土日は下位54%）のため見送り（観察のみ）"),\n'


def audit():
    spec = importlib.util.spec_from_file_location('v0744_audit', ROOT/'tools/audit_v0744.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0745_source_extension.json').read_text())
    changed = manifest['modified_existing']
    gradle = (ROOT/GRADLE).read_text()
    policy = (ROOT/POLICY).read_text()
    assess = (ROOT/ASSESS).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0745_weekend_regime:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.44 source bytes plus the pinned v0.7.45 change only.')
        elif name == 'evidence_model_frozen_parameters':
            row.update(check='evidence_model_frozen_parameters_v0745', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0745_EVIDENCE_MODEL"', 'const val WEEKDAY_ENTRY_RATE = 0.74', 'const val WEEKEND_ENTRY_RATE = 0.47',
                'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96',
                'const val LIVE_MAX_AGE_MS = 40_000L', 'while (buf.values.size > bufferLimit(weekend))',
                'if (decision.enter) null else CandidateSkipReason.LOW_EXPECTANCY'))},
                detail='v0.7.45: weekday 74% over 288 slots; weekend 47% over 576 slots; seeded until 96 slots; live quote <= 40 s.')
        elif name == 'assessment_only_adds_low_expectancy_reason':
            row.update(check='assessment_only_low_expectancy_label_changed', **{'pass': ASSESS_V0745 in assess
                       and sha_text(assess.replace(ASSESS_V0745, ASSESS_V0744)) == changed[ASSESS]['v0744_sha256']})
        elif name == 'gradle_only_version_changed':
            row.update(check='gradle_only_version_changed_v0745', **{'pass': sha_text(gradle.replace('versionCode = 115', 'versionCode = 114')
                       .replace('versionName = "0.7.45-weekend-regime"', 'versionName = "0.7.44-evidence-model"')) == changed[GRADLE]['v0744_sha256']})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*115\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.45-weekend-regime"' in gradle

    def check(name, ok, detail=None):
        row = {'check': name, 'pass': bool(ok)}
        if detail is not None: row['detail'] = detail
        result['results'].append(row)

    v0744 = json.loads((ROOT/'tools/v0744_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v0744['modified_existing'].items()} | v0744['new_source_files']
    for path, item in changed.items():
        check('v0744_original_before_v0745:' + path, known.get(path) == item['v0744_sha256'])
        check('pinned_v0745_change:' + path, sha(ROOT/path) == item['updated_sha256'])
    data = (ROOT/DATA).read_text()
    check('v0745_models_unchanged', f'const val FRESH_SHA256 = "{v0744["model_text_sha256"]["fresh"]}"' in data
          and f'const val FALLBACK_SHA256 = "{v0744["model_text_sha256"]["fallback"]}"' in data)
    check('v0745_only_weekend_seed_thresholds_changed', all(s in data for s in (
        'const val FRESH_WEEKEND_SEED_THRESHOLD = 0.005365667411369994', 'const val FALLBACK_WEEKEND_SEED_THRESHOLD = 0.004880298794818593',
        'const val FRESH_WEEKDAY_SEED_THRESHOLD = -0.008159328975610775', 'const val FALLBACK_WEEKDAY_SEED_THRESHOLD = -0.006258527224393799')))
    check('weekend_window_test_present', 'fun weekendWindowShiftsEntriesFromQuietToActiveDays()' in (ROOT/'app/src/test/java/EvidencePolicyTest.kt').read_text())
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0745_WEEKEND_REGIME_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']],
                  current_version='0.7.45-weekend-regime')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

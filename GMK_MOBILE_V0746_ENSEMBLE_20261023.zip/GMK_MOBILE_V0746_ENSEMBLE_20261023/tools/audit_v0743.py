"""v0.7.43 entry-quality guard: source gate layered on the unchanged v0.7.42 audit.

Every v0.7.42 check is re-run. Only rows for the five explicitly modified files and the
two version rows are re-pinned here; every other v0.7.42 row must still pass on its own.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def audit():
    spec = importlib.util.spec_from_file_location('v0742_audit', ROOT/'tools/audit_v0742.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0743_source_extension.json').read_text())
    changed = manifest['modified_existing']
    gradle = (ROOT/'app/build.gradle.kts').read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0743_entry_guard:' + path,
                       **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.42 source bytes plus the pinned v0.7.43 change only.')
        elif name == 'strict_six_instrument_scan':
            vm_text = (ROOT/'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt').read_text()
            row.update(check='strict_session_universe_scan', **{'pass': 'スキャン見送り: ${required.size}/${required.size}必須' in vm_text
                       and 'if (eligible.size != required.size) {' in vm_text},
                       detail='v0.7.43: all six on weekday sessions, BTCJPY only on weekend sessions; never a partial universe.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*113\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.43-entry-guard"' in gradle
    def check(name, ok, detail=None):
        row = {'check': name, 'pass': bool(ok)}
        if detail is not None: row['detail'] = detail
        result['results'].append(row)
    for path, item in changed.items():
        check('v0742_original_before_v0743:' + path, item['original_sha256'] in manifest['v0742_reference_sha256'].values())
    for path, digest in manifest['new_source_files'].items():
        check('pinned_new_v0743_source:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    engine = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/LocalRuleEngine.kt').read_text()
    restored = engine.replace('        // CHOPPY is a confidence penalty only (see below); it is NOT a hard SKIP.\n',
                              '        // CHOPPY is explicitly non-entry. This prevents whipsaw chasing.\n')
    check('native_engine_only_comment_changed',
          hashlib.sha256(restored.encode()).hexdigest() == changed['app/src/main/java/jp/gmk/mobile/domain/LocalRuleEngine.kt']['original_sha256'])
    session = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/TradingSession.kt').read_text()
    check('session_window_09_23_every_day_weekend_btc_only', 'jst(t).hour in 9..22' in session
          and 'if (fxOpen(t)) ALL else CRYPTO_ONLY' in session)
    policy = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt').read_text()
    check('evidence_policy_frozen_parameters', 'const val DIP_THRESHOLD = -1.57' in policy and 'j.hour in 9..22' in policy
          and 'nativeWindow' not in policy and 'listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY")' in policy
          and 'const val DIP_FEATURE_INDEX = 5' in policy)
    vmtext = (ROOT/'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt').read_text()
    perform = vmtext[vmtext.index('private suspend fun performScan('):]
    check('three_minute_scan_uses_session_universe', 'TradingSession.requiredInstruments(' in perform
          and 'listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")' not in perform.split('val eligible')[0])
    guard = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/EntryQualityGuard.kt').read_text()
    check('guard_is_demote_only', 'grade = "E", decision = "SKIP"' in guard and '"ENTRY", ' not in guard.split('fun apply', 1)[1])
    vm = (ROOT/'app/src/main/java/jp/gmk/mobile/ui/GmkViewModel.kt').read_text()
    check('evidence_policy_runs_after_every_overlay',
          'EvidencePolicy.apply(native, horizonRuntime.apply(native, eligible, prefs.forceThreeMinuteOutcome), eligible)' in vm
          and vm.count('horizonRuntime.apply(') == 1)
    october = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/october/OctoberSimilarityScanAdapter.kt').read_text()
    check('october_similarity_limited_to_2026', 't.year==2026 && t.monthValue==10' in october)
    check('guard_and_session_tests_present', all((ROOT/'app/src/test/java'/n).is_file() for n in ('EntryQualityGuardTest.kt','TradingSessionTest.kt','EvidencePolicyTest.kt')))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0743_ENTRY_GUARD_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']],
                  current_version='0.7.43-entry-guard')
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""v0.7.46 five-model average: source gate layered on the unchanged v0.7.45 audit."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
POLICY = 'app/src/main/java/jp/gmk/mobile/domain/EvidencePolicy.kt'
DATA = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceModelData.kt'
MODEL = 'app/src/main/java/jp/gmk/mobile/domain/EvidenceModel.kt'
GRADLE = 'app/build.gradle.kts'


def audit():
    spec = importlib.util.spec_from_file_location('v0745_audit', ROOT/'tools/audit_v0745.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0746_source_extension.json').read_text())
    changed = manifest['modified_existing']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text(); data = (ROOT/DATA).read_text(); model = (ROOT/MODEL).read_text()
    hashes_ok = all(f'"{h}"' in data for h in manifest['model_text_sha256']['fresh'] + manifest['model_text_sha256']['fallback']) \
        and 'val FRESH_SHA256 = listOf(' in data and 'val FALLBACK_SHA256 = listOf(' in data
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0746_ensemble:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.45 source bytes plus the pinned v0.7.46 change only.')
        elif name in ('embedded_model_hashes_match_release_manifest', 'v0745_models_unchanged'):
            row.update(check=name + '_v0746_ensemble', **{'pass': hashes_ok})
        elif name == 'v0745_only_weekend_seed_thresholds_changed':
            row.update(check='v0746_ensemble_seed_thresholds', **{'pass': all(s in data for s in (
                'const val FRESH_WEEKDAY_SEED_THRESHOLD = -0.00794529405910386', 'const val FRESH_WEEKEND_SEED_THRESHOLD = 0.005323323049522007',
                'const val FALLBACK_WEEKDAY_SEED_THRESHOLD = -0.006085393941473036', 'const val FALLBACK_WEEKEND_SEED_THRESHOLD = 0.004692138278546551'))})
        elif name == 'evidence_model_frozen_parameters_v0745':
            row.update(check='evidence_model_frozen_parameters_v0746', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0746_EVIDENCE_ENSEMBLE"', 'const val WEEKDAY_ENTRY_RATE = 0.74', 'const val WEEKEND_ENTRY_RATE = 0.47',
                'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96',
                'const val LIVE_MAX_AGE_MS = 40_000L', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback'))})
        elif name == 'gradle_only_version_changed_v0745':
            row.update(check='gradle_only_version_changed_v0746', **{'pass': sha_text(gradle.replace('versionCode = 116', 'versionCode = 115')
                       .replace('versionName = "0.7.46-ensemble"', 'versionName = "0.7.45-weekend-regime"')) == changed[GRADLE]['v0745_sha256']})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*116\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.46-ensemble"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v0745 = json.loads((ROOT/'tools/v0745_source_extension.json').read_text())
    v0744 = json.loads((ROOT/'tools/v0744_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v0744['modified_existing'].items()} | v0744['new_source_files'] \
        | {p: x['updated_sha256'] for p, x in v0745['modified_existing'].items()}
    for path, item in changed.items():
        check('v0745_original_before_v0746:' + path, known.get(path) == item['v0745_sha256'])
        check('pinned_v0746_change:' + path, sha(ROOT/path) == item['updated_sha256'])
    check('ensemble_of_five_members', 'check(texts.size == hashes.size && texts.size == 5)' in model and 'return s / members.size' in model)
    check('ensemble_model_texts_hash_pinned', hashes_ok and len(set(manifest['model_text_sha256']['fresh'])) == 5)
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0746_ENSEMBLE_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.46-ensemble')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

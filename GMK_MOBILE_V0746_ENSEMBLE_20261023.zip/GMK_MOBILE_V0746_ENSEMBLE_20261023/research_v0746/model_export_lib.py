import math, numpy as np
FEATURES = None
def export(m):
    base = float(m._baseline_prediction.ravel()[0])
    lines = [f'GMKEV1|{NFEAT}|{base!r}|{len(m._predictors)}']
    for it in m._predictors:
        assert len(it) == 1
        nodes = it[0].nodes
        lines.append(f'T|{len(nodes)}')
        for nd in nodes:
            if nd['is_leaf']: lines.append(f'L|{float(nd["value"])!r}')
            else:
                assert not nd['is_categorical']
                lines.append(f'N|{int(nd["feature_idx"])}|{float(nd["num_threshold"])!r}|{int(nd["left"])}|{int(nd["right"])}|{1 if nd["missing_go_to_left"] else 0}')
    return '\n'.join(lines) + '\n'

def eval_text(text, X):
    rows = text.strip().split('\n'); hdr = rows[0].split('|'); base = float(hdr[2]); trees = []; i = 1
    while i < len(rows):
        n = int(rows[i].split('|')[1]); trees.append([r.split('|') for r in rows[i + 1:i + 1 + n]]); i += 1 + n
    out = np.empty(len(X))
    for k, x in enumerate(X):
        raw = base
        for t in trees:
            j = 0
            while t[j][0] == 'N':
                f, thr, l, r, ml = int(t[j][1]), float(t[j][2]), int(t[j][3]), int(t[j][4]), t[j][5] == '1'
                v = x[f]; j = (l if ml else r) if math.isnan(v) else (l if v <= thr else r)
            raw += float(t[j][1])
        out[k] = 1.0 / (1.0 + math.exp(-raw))
    return out

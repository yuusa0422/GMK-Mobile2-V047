import pandas as pd, numpy as np, pickle, json
E = pickle.load(open('../work/sim_ensemble.pkl', 'rb'))[True]
V = pickle.load(open('../work/sim_app_policy_v0745.pkl', 'rb'))[True]
P = pd.read_pickle('../work/policy_data.pkl'); cur = P[(P.order == 1) & (P.app_grade != 'E')].copy(); cur['win'] = (cur.move3 == cur.app_dir).astype(int)
for d in (E, V): d['m'] = pd.to_datetime(d.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
cur['m'] = cur.ts.dt.strftime('%Y-%m')
rng = np.random.default_rng(21)
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def summ(e):
    e = e.sort_values('b'); dm = e.groupby('date').win.apply(lambda v: ms(v.values)); p = e.win.mean()
    counts = e.groupby('date').size().values
    sims = [np.mean([ms(rng.random(n) < p) >= 8 for n in counts]) for _ in range(300)]
    return dict(rate=round(p * 100, 1), n=len(e), days=int(e.date.nunique()), maxs=ms(e.win.values), day8=round((dm >= 8).mean() * 100, 0), day8_chance=round(np.mean(sims) * 100, 0),
                draw=round((e.move3 == 0).mean() * 100, 1))
out = {}
for m in ('2025-10', '2026-10'):
    for wk in (True, False):
        k = f'{m}|{"平日" if wk else "土日"}'
        out[k] = {'現行': summ(cur[(cur.m == m) & (cur.weekday == wk)]), 'v0.7.45': summ(V[V.enter & (V.m == m) & (V.weekday == wk)]), 'v0.7.46': summ(E[E.enter & (E.m == m) & (E.weekday == wk)])}
        print(k, json.dumps(out[k], ensure_ascii=False))
json.dump(out, open('../work/october_report.json', 'w'), ensure_ascii=False, indent=1)
# October weekend option: absolute threshold (fewer entries on quiet weekends)
W = E[~E.weekday].copy()
off = W.groupby(['half', 'hour']).p.median().unstack(0)
W['adj'] = W.p - np.where(W.half == 'H1', W.hour.map(off['H2']), W.hour.map(off['H1']))
q = W.groupby('half').adj.quantile(0.53)
W['fixed'] = W.adj >= np.where(W.half == 'H1', q['H2'], q['H1'])
for m in ('2025-10', '2026-10'):
    x = W[W.m == m]
    a = x[x.enter]; b = x[x.fixed]
    print(f'{m} 土日: 今の配分 {a.win.mean()*100:.1f}% ({len(a)}件, 引分{(a.move3==0).mean()*100:.0f}%) / 静かな週末は減らす配分 {b.win.mean()*100:.1f}% ({len(b)}件, 引分{(b.move3==0).mean()*100:.0f}%)')

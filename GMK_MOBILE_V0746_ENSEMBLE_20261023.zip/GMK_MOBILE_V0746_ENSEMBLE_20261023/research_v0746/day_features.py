"""Trend-day features: move since 09:00 JST and position in today's range (causal: bars up to OPEN(B-120))."""
import gzip, csv, numpy as np, pandas as pd, datetime as dt
SRC = {'USDJPY': '../hist/USDJPY_merged.csv.gz', 'BTCJPY': '../hist/combined/BTCJPY_1m.csv.gz'}
for s in ['EURJPY', 'GBPJPY', 'AUDJPY', 'NZDJPY']: SRC[s] = f'../hist/combined/{s}_1m.csv.gz'
P = pd.read_pickle('../work/policy_data.pkl')[['b', 'inst', 'rv60']]
out = []
for s, p in SRC.items():
    rows = []
    with gzip.open(p, 'rt') as f:
        for r in csv.DictReader(f): rows.append((int(r['epoch_ms']) // 1000, float(r['open']), float(r['high']), float(r['low']), float(r['close'])))
    a = pd.DataFrame(rows, columns=['t', 'o', 'h', 'l', 'c']).set_index('t').sort_index()
    x = P[P.inst == s]
    t_last = x.b.values - 120
    jst = pd.to_datetime(x.b.values, unit='s', utc=True).tz_convert('Asia/Tokyo')
    t9 = np.array([int(pd.Timestamp(d.date(), tz='Asia/Tokyo').timestamp()) + 9 * 3600 for d in jst])
    idx = a.index.values
    i_last = np.searchsorted(idx, t_last, side='right') - 1; i9 = np.searchsorted(idx, t9, side='left')
    c = a.c.values; o = a.o.values; h = a.h.values; l = a.l.values
    hm = np.maximum.accumulate; dmv = np.full(len(x), np.nan); dpos = np.full(len(x), np.nan)
    for k in range(len(x)):
        i0, i1 = i9[k], i_last[k]
        if i1 - i0 < 3 or idx[i0] > t9[k] + 600: continue
        mins = max((t_last[k] - t9[k]) / 60 + 1, 1)
        dmv[k] = np.log(c[i1] / o[i0]) / (x.rv60.values[k] / 1e4 * np.sqrt(mins))
        hi = h[i0:i1 + 1].max(); lo = l[i0:i1 + 1].min(); dpos[k] = (c[i1] - lo) / max(hi - lo, 1e-12) * 2 - 1
    out.append(pd.DataFrame({'b': x.b.values, 'inst': s, 'dmv': dmv, 'dpos': dpos}))
D = pd.concat(out); D.to_pickle('../work/day_features.pkl'); print(D.describe().round(3).to_string())

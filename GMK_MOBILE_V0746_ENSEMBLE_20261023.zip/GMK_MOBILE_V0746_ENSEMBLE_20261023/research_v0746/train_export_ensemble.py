"""v0.7.46: five production models per kind (seeds 0-4, full year), averaged. Export + in-sample slot statistics."""
import pandas as pd, numpy as np, pickle, hashlib, json, math
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
exec(open('model_export_lib.py').read()); NFEAT = 46
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
RATE = {True: 0.74, False: 0.47}; SEEDS = list(range(5))
models = {}; texts = {}
for fresh in (True, False):
    XA = np.vstack([design(P, 1, fresh)[0], design(P, -1, fresh)[0]]); yA = np.r_[(P.move3.values == 1), (P.move3.values == -1)].astype(int)
    _, names = design(P.head(2), 1, fresh); FEATURES = names
    models[fresh] = [HistGradientBoostingClassifier(random_state=s, **CFG).fit(XA, yA) for s in SEEDS]
    texts[fresh] = [export(m) for m in models[fresh]]
    Xs = design(P.sample(2000, random_state=1), 1, fresh)[0]
    for m, t in zip(models[fresh], texts[fresh]):
        diff = np.abs(eval_text(t, Xs) - m.predict_proba(Xs)[:, 1]).max(); assert diff < 1e-12, diff
    print('trained+verified', 'fresh' if fresh else 'fallback', [len(t) for t in texts[fresh]])
stats = {}
for fresh in (True, False):
    Xu = design(P, 1, fresh)[0]; Xd = design(P, -1, fresh)[0]
    pu = np.mean([m.predict_proba(Xu)[:, 1] for m in models[fresh]], axis=0); pdn = np.mean([m.predict_proba(Xd)[:, 1] for m in models[fresh]], axis=0)
    t = P[['b', 'weekday', 'hour']].copy(); t['p'] = np.maximum(pu, pdn)
    best = t.sort_values('p', ascending=False).groupby('b').head(1)
    st = {}
    for wk in (True, False):
        x = best[best.weekday == wk].copy(); off = x.groupby('hour').p.median().reindex(range(9, 23)).ffill().bfill()
        x['adj'] = x.p - x.hour.map(off)
        st['weekday' if wk else 'weekend'] = dict(offset=[float(v) for v in off.values], seed=float(x.adj.quantile(1 - RATE[wk])),
                                                  q50=float(x.adj.quantile(.5)), q75=float(x.adj.quantile(.75)))
    stats['fresh' if fresh else 'fallback'] = st
print(json.dumps({k: {d: {kk: vv for kk, vv in v.items() if kk != 'offset'} for d, v in s.items()} for k, s in stats.items()}, indent=1))
pickle.dump(dict(models=models, texts=texts, stats=stats, features=FEATURES, cfg=CFG, seeds=SEEDS), open('../work/production_ensemble.pkl', 'wb'))

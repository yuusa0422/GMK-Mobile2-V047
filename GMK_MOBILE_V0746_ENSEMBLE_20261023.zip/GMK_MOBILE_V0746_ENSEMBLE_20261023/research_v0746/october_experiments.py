"""October specialisation, validated on an October the model never saw.
T1: train on everything before 2026-10-01 -> test October 2026 (1-21)   [what the app could have done on Oct 1]
T2: train on everything from 2025-11-01   -> test October 2025          [the other October]"""
import pandas as pd, numpy as np, pickle, json
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
P['m'] = P.ts.dt.month
# slow regime features (causal: previous days only)
fx = P[P.weekday & (P.inst != 'BTCJPY') & (P.f1.abs() >= 1.0) & (P.move3 != 0)]
dfade = fx.assign(w=(fx.move3 == -np.sign(fx.f1)).astype(float)).groupby('date').w.mean()
bt = P[(P.inst == 'BTCJPY') & (P.f1.abs() >= 0.6) & (P.move3 != 0)]
dfol = bt.assign(w=(bt.move3 == np.sign(bt.f1)).astype(float)).groupby('date').w.mean()
dates = sorted(P.date.unique())
fade_s = dfade.reindex(dates).ffill(); fol_s = dfol.reindex(dates).ffill()
REG = pd.DataFrame({'date': dates, 'rg_fade3': fade_s.rolling(3, min_periods=1).mean().shift(1).values, 'rg_fade10': fade_s.rolling(10, min_periods=1).mean().shift(1).values,
                    'rg_fol10': fol_s.rolling(10, min_periods=1).mean().shift(1).values})
P = P.merge(REG, on='date', how='left'); P[['rg_fade3', 'rg_fade10', 'rg_fol10']] = P[['rg_fade3', 'rg_fade10', 'rg_fol10']].fillna(0.52)
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, random_state=0, early_stopping=False)
def X_(df, d, reg):
    X, _ = design(df, d, True)
    return np.hstack([X, df[['rg_fade3', 'rg_fade10', 'rg_fol10']].values]) if reg else X
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def run(train, test, w, reg, seed=0):
    cfg = dict(CFG, random_state=seed)
    m = HistGradientBoostingClassifier(**cfg).fit(np.vstack([X_(train, 1, reg), X_(train, -1, reg)]), np.r_[(train.move3.values == 1), (train.move3.values == -1)].astype(int), sample_weight=np.r_[w, w])
    t = test.copy(); pu = m.predict_proba(X_(t, 1, reg))[:, 1]; pdn = m.predict_proba(X_(t, -1, reg))[:, 1]
    t['p'] = np.maximum(pu, pdn); t['dir'] = np.where(pu >= pdn, 1, -1); t['win'] = (t.move3 == t.dir).astype(int)
    best = t.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
    out = {}
    for wk, rate in ((True, 0.74), (False, 0.47)):
        x = best[best.weekday == wk]
        thr = x.groupby('hour').p.transform(lambda v: v.quantile(1 - rate))
        e = x[x.p >= thr]
        out['平日' if wk else '土日'] = (e.win.mean() * 100, len(e), ms(e.win.values), x.win.mean() * 100)
    return out
TESTS = {'2026年10月(1-21日)': (P[P.ts < pd.Timestamp('2026-10-01', tz='Asia/Tokyo')], P[P.ts >= pd.Timestamp('2026-10-01', tz='Asia/Tokyo')], ('2026-08-01', '2026-10-01')),
         '2025年10月': (P[P.ts >= pd.Timestamp('2025-11-01', tz='Asia/Tokyo')], P[P.ts < pd.Timestamp('2025-11-01', tz='Asia/Tokyo')], ('2025-11-01', '2026-01-01'))}
res = {}
for name, (tr, te, (r0, r1)) in TESTS.items():
    oct_w = np.where(tr.m.values == 10, 3.0, 1.0)
    rec_w = np.where((tr.ts >= pd.Timestamp(r0, tz='Asia/Tokyo')) & (tr.ts < pd.Timestamp(r1, tz='Asia/Tokyo')), 3.0, 1.0)
    variants = {'今の学習（重みなし）': (np.ones(len(tr)), False), '10月を3倍重視': (oct_w, False), '直近2か月を3倍重視': (rec_w, False),
                '相場の型（過去の逆張り成績）を追加': (np.ones(len(tr)), True), '10月重視＋相場の型': (oct_w, True), '直近重視＋相場の型': (rec_w, True)}
    print(f'\n===== テスト: {name} （学習 {len(tr):,}行） =====')
    for vn, (w, reg) in variants.items():
        rs = [run(tr, te, w, reg, seed) for seed in (0, 1, 2)]
        wd = np.mean([r['平日'][0] for r in rs]); we = np.mean([r['土日'][0] for r in rs]); allwd = np.mean([r['平日'][3] for r in rs])
        res[(name, vn)] = dict(weekday=wd, weekend=we, weekday_all=allwd, n_wd=rs[0]['平日'][1], n_we=rs[0]['土日'][1], spread=max(r['平日'][0] for r in rs) - min(r['平日'][0] for r in rs))
        print(f'  {vn:22s} 平日 {wd:5.1f}% (3回の学習の差 {res[(name, vn)]["spread"]:.1f}) 全枠 {allwd:5.1f}%  土日 {we:5.1f}%   件数 平日{rs[0]["平日"][1]} 土日{rs[0]["土日"][1]}')
pickle.dump(res, open('../work/october_experiments.pkl', 'wb'))

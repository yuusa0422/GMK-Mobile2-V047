"""Calibration by instrument and a causal 'regime tilt': when FX reversal has been failing for the past days, prefer BTC."""
import pandas as pd, numpy as np, pickle
C = pd.read_pickle('../work/oos_candidates.pkl')          # out-of-sample p for every candidate (2-fold)
S = pickle.load(open('../work/sim_app_policy_v0745.pkl', 'rb'))[True][['b', 'enter']]
C = C.merge(S, on='b')
C['m'] = pd.to_datetime(C.b, unit='s', utc=True).dt.tz_convert('Asia/Tokyo').dt.strftime('%Y-%m')
W = C[C.weekday].copy()
# calibration of the chosen candidate per instrument
W['p'] = np.maximum(W.p_up, W.p_dn); W['d'] = np.where(W.p_up >= W.p_dn, 1, -1); W['win'] = (W.move3 == W.d).astype(int)
best = W.sort_values('p', ascending=False).groupby('b').head(1)
e = best[best.enter]
print('選ばれた候補: 通貨ごとの 予測勝率の平均 → 実際の勝率')
print(e.groupby('inst').agg(n=('win', 'size'), p=('p', 'mean'), win=('win', 'mean')).assign(p=lambda t: (t.p * 100).round(1), win=lambda t: (t.win * 100).round(1)).to_string())
# trailing regime per date (previous 10 trading days): FX fade success
P = pd.read_pickle('../work/policy_data.pkl')
fx = P[P.weekday & (P.inst != 'BTCJPY') & (P.f1.abs() >= 1.0) & (P.move3 != 0)]
dfade = fx.assign(w=(fx.move3 == -np.sign(fx.f1)).astype(float)).groupby('date').w.mean()
reg = dfade.rolling(10, min_periods=5).mean().shift(1).rename('fx_fade10')
W = W.merge(reg, left_on='date', right_index=True, how='left')
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def policy(bonus, cond):
    t = W.copy()
    adj = np.where((t.inst == 'BTCJPY') & cond(t), bonus, 0.0)
    t['score'] = t.p + adj
    b = t.sort_values('score', ascending=False).groupby('b').head(1)
    b = b[b.enter]
    r = {}
    for nm, sel in (('1年', b), ('2025年10月', b[b.m == '2025-10']), ('2026年9-10月', b[b.m.isin(['2026-09', '2026-10'])]), ('2026年10月', b[b.m == '2026-10'])):
        r[nm] = f'{sel.win.mean()*100:5.1f}% (BTC{(sel.inst=="BTCJPY").mean()*100:3.0f}%)'
    r['前半/後半'] = f'{b[b.half=="H1"].win.mean()*100:.1f}/{b[b.half=="H2"].win.mean()*100:.1f}'
    return r
print()
print('なし                        ', policy(0.0, lambda t: np.ones(len(t), bool)))
for bonus in (0.005, 0.01, 0.02):
    print(f'BTCを常に+{bonus:.3f}            ', policy(bonus, lambda t: np.ones(len(t), bool)))
    print(f'為替の逆張りが不調な時だけBTC+{bonus:.3f}', policy(bonus, lambda t: t.fx_fade10.fillna(0.52) < 0.505))

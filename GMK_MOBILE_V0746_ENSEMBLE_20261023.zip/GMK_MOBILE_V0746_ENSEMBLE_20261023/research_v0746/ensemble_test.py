"""Average of 5 differently-seeded models (less variance) and the BTC calibration tilt, out-of-sample."""
import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
P['m'] = P.ts.dt.strftime('%Y-%m')
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
PU = {}; PD = {}
for tr, te in (('H1', 'H2'), ('H2', 'H1')):
    A = P[P.half == tr]; Bt = P[P.half == te]
    XA = np.vstack([design(A, 1, True)[0], design(A, -1, True)[0]]); yA = np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int)
    Xu = design(Bt, 1, True)[0]; Xd = design(Bt, -1, True)[0]
    for seed in range(5):
        m = HistGradientBoostingClassifier(random_state=seed, **CFG).fit(XA, yA)
        PU.setdefault(seed, {})[te] = m.predict_proba(Xu)[:, 1]; PD.setdefault(seed, {})[te] = m.predict_proba(Xd)[:, 1]
pickle.dump((PU, PD), open('../work/ensemble_oos.pkl', 'wb'))
def evaluate(seeds, btc_bonus=0.0, label=''):
    parts = []
    for te in ('H2', 'H1'):
        Bt = P[P.half == te][['b', 'inst', 'weekday', 'hour', 'half', 'm', 'move3', 'date']].copy()
        pu = np.mean([PU[s][te] for s in seeds], axis=0); pdn = np.mean([PD[s][te] for s in seeds], axis=0)
        Bt['p'] = np.maximum(pu, pdn); Bt['dir'] = np.where(pu >= pdn, 1, -1); Bt['win'] = (Bt.move3 == Bt.dir).astype(int)
        Bt['score'] = Bt.p + np.where(Bt.inst == 'BTCJPY', btc_bonus, 0.0); parts.append(Bt)
    T = pd.concat(parts); best = T.sort_values('score', ascending=False).groupby('b').head(1).sort_values('b')
    out = []
    for wk, rate in ((True, 0.74), (False, 0.47)):
        x = best[best.weekday == wk]; thr = x.groupby(['half', 'hour']).score.transform(lambda v: v.quantile(1 - rate)); e = x[x.score >= thr]
        out.append(f'{"平日" if wk else "土日"} {e.win.mean()*100:5.2f}% (H1 {e[e.half=="H1"].win.mean()*100:4.1f} H2 {e[e.half=="H2"].win.mean()*100:4.1f}; 25/10 {e[e.m=="2025-10"].win.mean()*100:4.1f} 26/10 {e[e.m=="2026-10"].win.mean()*100:4.1f})')
    print(f'{label:28s}', ' | '.join(out))
for s in range(5): evaluate([s], label=f'単独モデル seed{s}')
evaluate(list(range(5)), label='5モデル平均')
evaluate(list(range(5)), 0.01, label='5モデル平均＋BTC補正0.01')
evaluate([0], 0.01, label='単独seed0＋BTC補正0.01')

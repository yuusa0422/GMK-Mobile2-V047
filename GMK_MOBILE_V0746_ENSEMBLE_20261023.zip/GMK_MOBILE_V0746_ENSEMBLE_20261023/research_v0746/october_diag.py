import pandas as pd, numpy as np, pickle
X = pd.read_pickle('../work/trades_runs_v0745.pkl')
X['m'] = X.ts.dt.strftime('%Y-%m')
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
rng = np.random.default_rng(3)
for pol in ('cur', 'new'):
    for wk in (True, False):
        x = X[(X.policy == pol) & (X.weekday == wk)]
        g = x.groupby('m').win.mean() * 100
        octs = g[g.index.str.endswith('-10')]; other = x[~x.m.str.endswith('-10')].win.mean() * 100
        print(f'{"現行" if pol=="cur" else "v0.7.45"} {"平日" if wk else "土日"}: 10月 ' + ' '.join(f'{k} {v:.1f}%' for k, v in octs.items()) + f' / 10月以外 {other:.1f}% / 月別の範囲 {g.min():.1f}〜{g.max():.1f}')
for m in ('2025-10', '2026-10'):
    for wk in (True, False):
        x = X[(X.policy == 'new') & (X.weekday == wk) & (X.m == m)].sort_values('b')
        dm = x.groupby('date').win.apply(lambda v: ms(v.values)); p = x.win.mean()
        sims = [np.mean([ms(rng.random(n) < p) >= 8 for n in x.groupby('date').size().values]) for _ in range(300)]
        L = x[x.win == 0]
        print(f'v0.7.45 {m} {"平日" if wk else "土日"}: {p*100:.1f}% ({len(x)}件, {x.date.nunique()}日) 最大連敗 {ms(x.win.values)} 8連敗以上の日 {(dm>=8).mean()*100:.0f}% (偶然なら {np.mean(sims)*100:.0f}%) 負け方 ' +
              ', '.join(f'{k[:4]} {v:.0f}%' for k, v in L.loss_type.value_counts(normalize=True).mul(100).items()))

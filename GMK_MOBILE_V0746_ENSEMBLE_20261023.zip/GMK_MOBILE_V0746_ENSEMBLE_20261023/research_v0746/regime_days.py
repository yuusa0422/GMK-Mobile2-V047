"""Slow regime: does the market-wide short-term reversal strength persist from day to day?"""
import pandas as pd, numpy as np
P = pd.read_pickle('../work/policy_data.pkl')
fx = P[P.weekday & (P.inst != 'BTCJPY') & (P.f1.abs() >= 1.0) & (P.move3 != 0)].copy()
fx['fade_win'] = (fx.move3 == -np.sign(fx.f1)).astype(float)
d = fx.groupby('date').agg(fade=('fade_win', 'mean'), n=('fade_win', 'size'))
d = d[d.n >= 100]
for k in (1, 3, 5, 10, 20):
    prev = d.fade.rolling(k).mean().shift(1)
    ok = prev.notna()
    print(f'過去{k:2d}日の逆張り勝率 → 当日: 相関 {np.corrcoef(prev[ok], d.fade[ok])[0,1]:+.3f}', end='  ')
    q = pd.qcut(prev[ok], 3, labels=['低', '中', '高'])
    print('当日の逆張り勝率(過去が低/中/高):', ' '.join(f'{v*100:.1f}' for v in d.fade[ok].groupby(q, observed=True).mean()))
b = P[(P.inst == 'BTCJPY') & (P.f1.abs() >= 0.6) & (P.move3 != 0)].copy(); b['fw'] = (b.move3 == np.sign(b.f1)).astype(float)
db = b.groupby('date').fw.mean()
for k in (3, 10):
    prev = db.rolling(k).mean().shift(1); ok = prev.notna()
    print(f'BTC 過去{k}日の順張り勝率 → 当日 相関 {np.corrcoef(prev[ok], db[ok])[0,1]:+.3f}')

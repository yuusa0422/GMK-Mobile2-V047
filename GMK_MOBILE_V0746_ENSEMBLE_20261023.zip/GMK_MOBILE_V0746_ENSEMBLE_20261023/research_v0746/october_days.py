"""October day by day: results, streaks, and what the market did (v0.7.45 decisions, out-of-sample)."""
import pandas as pd, numpy as np, gzip, csv
X = pd.read_pickle('../work/trades_runs_v0745.pkl'); X['m'] = X.ts.dt.strftime('%Y-%m')
o = {}
with gzip.open('../hist/USDJPY_merged.csv.gz', 'rt') as f:
    for r in csv.DictReader(f): o[int(r['epoch_ms']) // 1000] = float(r['open'])
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
rows = []
for (pol, d), g in X[X.m.str.endswith('-10')].groupby(['policy', 'date']):
    g = g.sort_values('b'); t0 = pd.Timestamp(str(d) + ' 09:00', tz='Asia/Tokyo'); t1 = pd.Timestamp(str(d) + ' 23:00', tz='Asia/Tokyo')
    a = o.get(int(t0.timestamp())); z = o.get(int(t1.timestamp()) - 60)
    fx = g[g.inst != 'BTCJPY']
    rows.append(dict(方式='現行' if pol == 'cur' else 'v0.7.45', 日付=str(d), 曜日='月火水木金土日'[g.ts.iloc[0].dayofweek], 件数=len(g), 勝率=round(g.win.mean() * 100, 1),
                     最大連敗=ms(g.win.values), 為替の勝率=round(fx.win.mean() * 100, 1) if len(fx) else np.nan, BTCの勝率=round(g[g.inst == 'BTCJPY'].win.mean() * 100, 1) if (g.inst == 'BTCJPY').any() else np.nan,
                     引き分け=int((g.move3 == 0).sum()), ドル円9_23時の値動き=round((z / a - 1) * 100, 2) if a and z else np.nan))
D = pd.DataFrame(rows)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 200)
print(D[D['方式'] == 'v0.7.45'].to_string(index=False))
D.to_csv('../work/october_days.csv', index=False, encoding='utf-8-sig')
v = D[(D['方式'] == 'v0.7.45') & D['為替の勝率'].notna()]
print('\nドル円の1日の値動きが大きい日(|move|>=0.6%)と小さい日の為替勝率:', v[v['ドル円9_23時の値動き'].abs() >= 0.6]['為替の勝率'].mean(), v[v['ドル円9_23時の値動き'].abs() < 0.6]['為替の勝率'].mean())

v0.7.46 10月の分析と5つのモデルの平均（参考・再現用）
 october_*.py: 10月の勝率・連敗・相場の特徴、10月専用学習の検証
 ensemble_test.py / sim_ensemble.py: 5つのモデルの平均の検証
 train_export_ensemble.py / gen_kotlin_ensemble.py / gen_fixture_ensemble.py: 本番モデルの学習と書き出し
 month_character.csv: 月ごとの相場の特徴、october_days.csv: 10月の日ごとの結果

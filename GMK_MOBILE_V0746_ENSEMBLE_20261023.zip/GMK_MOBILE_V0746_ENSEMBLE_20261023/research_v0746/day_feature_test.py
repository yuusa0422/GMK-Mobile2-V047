import pandas as pd, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
D = pd.read_pickle('../work/day_features.pkl')
P = P.merge(D, on=['b', 'inst'], how='left')
P['dmv'] = P.dmv.clip(-10, 10).fillna(0); P['dpos'] = P.dpos.fillna(0)
ymv = P[P.inst.isin(['USDJPY', 'EURJPY', 'GBPJPY', 'AUDJPY'])].groupby('b').dmv.mean().rename('ydmv')
P = P.merge(ymv, on='b', how='left'); P['ydmv'] = np.where(P.inst == 'BTCJPY', 0, P.ydmv.fillna(0))
P['m'] = P.ts.dt.strftime('%Y-%m')
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
def X_(df, d, extra):
    X, _ = design(df, d, True)
    return np.hstack([X, np.column_stack([df.dmv.values * d, df.dpos.values * d, df.ydmv.values * d])]) if extra else X
for extra in (False, True):
    for seed in (0, 1, 2):
        parts = []
        for tr, te in (('H1', 'H2'), ('H2', 'H1')):
            A = P[P.half == tr]
            m = HistGradientBoostingClassifier(random_state=seed, **CFG).fit(np.vstack([X_(A, 1, extra), X_(A, -1, extra)]), np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int))
            Bt = P[P.half == te].copy(); pu = m.predict_proba(X_(Bt, 1, extra))[:, 1]; pdn = m.predict_proba(X_(Bt, -1, extra))[:, 1]
            Bt['p'] = np.maximum(pu, pdn); Bt['dir'] = np.where(pu >= pdn, 1, -1); Bt['win'] = (Bt.move3 == Bt.dir).astype(int); parts.append(Bt)
        T = pd.concat(parts); best = T.sort_values('p', ascending=False).groupby('b').head(1)
        x = best[best.weekday]; thr = x.groupby(['half', 'hour']).p.transform(lambda v: v.quantile(0.26)); e = x[x.p >= thr]
        print(f'{"日中トレンドを追加" if extra else "v0.7.45の入力  "} seed{seed}: 平日 {e.win.mean()*100:5.2f}% (H1 {e[e.half=="H1"].win.mean()*100:5.1f} H2 {e[e.half=="H2"].win.mean()*100:5.1f})  2025年10月 {e[e.m=="2025-10"].win.mean()*100:5.1f}%  2026年10月 {e[e.m=="2026-10"].win.mean()*100:5.1f}%')

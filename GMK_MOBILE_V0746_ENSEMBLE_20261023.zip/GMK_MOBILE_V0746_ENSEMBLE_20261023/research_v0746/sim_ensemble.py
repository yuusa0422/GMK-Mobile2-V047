"""Exact app rule (training-half seeds/offsets, rolling 288 weekday / 576 weekend) with the 5-model average, fresh and backup."""
import pandas as pd, numpy as np, pickle
from sklearn.ensemble import HistGradientBoostingClassifier
exec(open('evidence_model.py').read().split('def model():')[0])
CFG = dict(max_iter=150, learning_rate=0.08, max_leaf_nodes=7, min_samples_leaf=2000, l2_regularization=1.0, early_stopping=False)
RATE = {True: 0.74, False: 0.47}; NBUF = {True: 288, False: 576}; NMIN = 96; SEEDS = range(5)
def ms(v):
    mx = c = 0
    for a in v:
        c = 0 if a else c + 1; mx = max(mx, c)
    return mx
def best_slots(models, df, fresh):
    Xu = design(df, 1, fresh)[0]; Xd = design(df, -1, fresh)[0]
    pu = np.mean([m.predict_proba(Xu)[:, 1] for m in models], axis=0); pdn = np.mean([m.predict_proba(Xd)[:, 1] for m in models], axis=0)
    t = df[['b', 'inst', 'weekday', 'hour', 'move3', 'half', 'date', 'ts']].copy(); t['p'] = np.maximum(pu, pdn); t['dir'] = np.where(pu >= pdn, 1, -1)
    t['win'] = (t.move3 == t.dir).astype(int)
    return t.sort_values('p', ascending=False).groupby('b').head(1).sort_values('b')
def simulate(test, offs, seeds):
    out = []
    for wk in (True, False):
        x = test[test.weekday == wk].sort_values('b').copy()
        adj = (x.p - x.hour.map(offs[wk])).values; buf = []; enter = []; grade = []
        for a in adj:
            if len(buf) >= NMIN:
                arr = np.array(buf); thr = np.quantile(arr, 1 - RATE[wk]); q50 = np.quantile(arr, .5); q75 = np.quantile(arr, .75)
            else: thr, q50, q75 = seeds[wk]
            e = a >= thr; enter.append(e); grade.append(('A' if a >= q75 else 'B' if a >= q50 else 'C') if e else 'E')
            buf.append(a); buf = buf[-NBUF[wk]:]
        x['enter'] = enter; x['grade'] = grade; out.append(x)
    return pd.concat(out).sort_values('b')
res = {}
for fresh in (True, False):
    sims = []
    for tr, te in (('H1', 'H2'), ('H2', 'H1')):
        A = P[P.half == tr]
        XA = np.vstack([design(A, 1, fresh)[0], design(A, -1, fresh)[0]]); yA = np.r_[(A.move3.values == 1), (A.move3.values == -1)].astype(int)
        models = [HistGradientBoostingClassifier(random_state=s, **CFG).fit(XA, yA) for s in SEEDS]
        btr = best_slots(models, A, fresh); offs = {}; seeds = {}
        for wk in (True, False):
            x = btr[btr.weekday == wk]; off = x.groupby('hour').p.median(); offs[wk] = off
            adj = x.p - x.hour.map(off); seeds[wk] = (adj.quantile(1 - RATE[wk]), adj.quantile(.5), adj.quantile(.75))
        sims.append(simulate(best_slots(models, P[P.half == te], fresh), offs, seeds))
    S = pd.concat(sims).sort_values('b'); S['m'] = S.ts.dt.strftime('%Y-%m'); res[fresh] = S
    print(f'\n== 5モデル平均 {"直前価格あり" if fresh else "予備"} ==')
    for wk in (True, False):
        x = S[S.weekday == wk]; e = x[x.enter]; dm = e.groupby('date').win.apply(lambda v: ms(v.values))
        print(f' {"平日" if wk else "土日"}: 入る {x.enter.mean()*100:4.1f}% 勝率 {e.win.mean()*100:5.2f}% (H1 {e[e.half=="H1"].win.mean()*100:4.1f} H2 {e[e.half=="H2"].win.mean()*100:4.1f}) '
              f'25/10 {e[e.m=="2025-10"].win.mean()*100:4.1f} 26/10 {e[e.m=="2026-10"].win.mean()*100:4.1f}  最大連敗 {ms(e.win.values)} 8+ {(dm>=8).mean()*100:.1f}% 10+ {(dm>=10).mean()*100:.1f}%  '
              + ' '.join(f'{g}:{e[e.grade==g].win.mean()*100:.1f}' for g in 'ABC' if (e.grade == g).any()))
pickle.dump(res, open('../work/sim_ensemble.pkl', 'wb'))

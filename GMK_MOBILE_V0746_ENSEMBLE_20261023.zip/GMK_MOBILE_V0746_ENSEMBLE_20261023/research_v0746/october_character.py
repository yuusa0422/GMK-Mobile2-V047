import pandas as pd, numpy as np
P = pd.read_pickle('../work/policy_data.pkl'); P['m'] = P.ts.dt.strftime('%y-%m')
H = pd.read_pickle('../work/hyp_features.pkl')[['b', 'inst', 'vr5', 'ac1']]
P = P.merge(H, on=['b', 'inst'], how='left')
fx = P[P.weekday & (P.inst != 'BTCJPY')]; bt = P[P.inst == 'BTCJPY']
rows = []
for m, g in fx.groupby('m'):
    big = g[g.f1.abs() >= 1.5]; fade = (big.move3 == -np.sign(big.f1)).mean()
    sh = g[g.r5.abs() >= 2.5]; shock = (sh.move3 == -np.sign(sh.r5)).mean()
    tr = g[g.r60.abs() >= 1.5]; cont = (tr.move3 == np.sign(tr.r60)).mean()
    b = bt[bt.m == m]; bw = b[~b.weekday]
    fol = b[(b.f1.abs() >= 0.6) & (b.move3 != 0)]; follow = (fol.move3 == np.sign(fol.f1)).mean()
    rows.append(dict(月=m, 為替の値動きσ=round(g.rv60.median(), 2), 分散比=round(g.vr5.median(), 3), 自己相関=round(g.ac1.median(), 3),
                     直前1分急変の逆張り=round(fade * 100, 1), 五分急変の逆張り=round(shock * 100, 1), 一時間トレンドの継続=round(cont * 100, 1),
                     BTC順張り_引分除く=round(follow * 100, 1), BTC土日の引分=round((bw.move3 == 0).mean() * 100, 1)))
R = pd.DataFrame(rows).set_index('月'); pd.set_option('display.width', 250); print(R.to_string())
R.to_csv('../work/month_character.csv')

GMK MOBILE v0.7.38 / versionCode 108 — AI・ルール・履歴・リアルタイム取得の全監査

24課題を修正・補強。Androidホストの全105試験PASS、失敗・スキップ0。Lintエラー0。
実BTC/JPYの公式WebSocketは約1秒間隔で配信元時刻が更新され、受信時の古さ0.598〜0.692秒。
実RESTは3回連続HTTP200、配信元時刻が全て更新。為替5通貨も実APIの新しい時刻でLIVEを確認。
継続実通信でも32配信、心拍応答1回、再接続後の新しい配信を確認。
上記はホストからの実通信です。実端末での通信・運転は未確認です。

BTCの更新はYahoo予約・スキャン・為替の応答待ちから独立。公式Socket.IO EIO4へ購読。
心拍応答・切断復旧・停止後の遅延応答を処理。配信停止時は専用RESTで回復。
BTCは配信元から15秒を超えたらLAST。接続し直すだけで古い価格をLIVEにしません。
為替は5通貨を個別更新。Yahoo同時2要求を維持し、スキャンへ枠を譲ります。
後着の古いRESTは画面とAI価格キャッシュの両方で拒否。

実ルール＋実HGBモデルの72枠、補正10枠（5分7枠）、3分固定6枠、20の異常保護条件を検証。
全11モデルを読込、19系列を各4,000本以上復元し、prepare/apply/commitと履歴確定・再読込を確認。
価格列は元の実測値。日時だけをモデル利用可能日に移動した機能試験で、成績バックテストではありません。
昼間は平日JST09:00〜17:00の共通4通貨のC・ENTRYのみ3/5分補正。
確率差0.10超のみ補正し、S/A/B・SKIP・対象外通貨を保護。3分固定は3分候補だけで選びます。
夕方は従来Horizon/PC R13、手動・1分は従来の経路を検証。
ルール31ファイル・モデル14資産はv0.7.36と同一。policyVersionはGMK_V0736を継続。
同梱モデルは学習済み固定モデルで、スマホ内の日次再学習は搭載していません。

履歴は新規追加時と復元時に検証。不正な待ち・必要価格は行を残して追跡と勝率から除外。
再実行・重複AUTO枠は確定結果を維持。DRAWはLOSE。1/3/5/10/15分を別集計。
360dp幅・文字倍率1.0/1.8で、履歴と診断のスクロール到達、HIGHの一行表示を確認。

詳しい結果: MOBILE_DEEP_AUDIT_REPORT.html / RELEASE_VERIFICATION.json
差分・不具合一覧: MOBILE_DEEP_AUDIT_CHANGES.json / release_evidence/v0738_full_audit
実AI動作: RULE_AI_FUNCTIONAL_AUDIT.json / RULE_AI_GUARD_AUDIT.json
ネットワーク再確認: python3 tools/probe_public_market_feeds.py --mode all
（streamモードはwebsockets16.0が必要。その他はPython標準ライブラリのみ。）

ビルド: JDK17 / Gradle8.10.2 / SDK35 / build-tools35.0.0
配布バンドルは最初に python3 tools/restore_bundled_assets.py を実行。
従来のGMK_V0735_TEST_DATA.zipの先頭フォルダを外して本プロジェクトへ展開します。
元の完全な実測特徴量fixtureは同梱済み。環境変数の追加指定は不要です。
 sha256sum --check --quiet PACKAGE_MANIFEST_SHA256.txt
 python3 tools/direct19_release_audit.py
 gradle :app:testDebugUnitTest :app:lintRelease :app:assembleRelease :app:assembleDebug --no-daemon --max-workers=2
 python3 tools/verify_mobile_test_results.py
現在版のワークフロー検証は tools/verify_full_audit_workflow.py を使用します。
tools/test_workflow.py と functional_contract_test.py はv0.7.35用の保存した比較ツールです。

独立ファイル GMK_MOBILE_V0738_BUILD_WORKFLOW_20261008.yml は .github/workflows/build.yml と同一。
配布バンドルまたはソースZIPを一つとGMK_V0735_TEST_DATA.zipをリポジトリへ配置するか、全ソースを配置して使用。
GMK_SIGNING_KEYSTORE_BASE64 / GMK_SIGNING_STORE_PASSWORD / GMK_SIGNING_KEY_ALIAS / GMK_SIGNING_KEY_PASSWORD
4つの既存Secretsが揃えば、その鍵でPRODUCTION APKを署名。一部だけはエラー。
鍵がなければTEST_ONLY debug APKとRELEASE_UNSIGNED APK。GitHub上の実行は未実施。

本番用APKは未署名。対象端末と既存鍵がこの環境にないため、実端末への適用は未実施です。
履歴を残して既存アプリを更新するには、同じ本番署名鍵による上書きが必要です。
APK内の11モデルと3マニフェストはソースと一致、debug署名は検証済みです。

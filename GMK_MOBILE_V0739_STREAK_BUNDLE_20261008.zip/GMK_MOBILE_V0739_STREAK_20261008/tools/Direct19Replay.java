import java.io.*;
import java.nio.file.*;
import jp.gmk.mobile.domain.direct19.*;

/** Uses actual portable model and policy classes, not copied predictor logic. */
public class Direct19Replay {
    public static void main(String[] args)throws Exception {
        double max=0;int frames=0,target=0,probabilities=0;
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(args[0])))) {
            int days=in.readInt();
            for(int day=0;day<days;day++) {
                Direct19Model[] models=new Direct19Model[2];
                for(int h=0;h<2;h++){String path=in.readUTF();String digest=in.readUTF();models[h]=Direct19Model.load(Files.readAllBytes(Path.of(path)),digest);}
                int count=in.readInt();
                for(int r=0;r<count;r++) {
                    int frame=in.readInt(),nativeAction=in.readInt();boolean entry=in.readBoolean();String grade=in.readUTF();
                    boolean[] eligible=new boolean[4];for(int s=0;s<4;s++)eligible[s]=in.readBoolean();
                    float[][] input=new float[4][165];for(float[] row:input)for(int j=0;j<165;j++)row[j]=in.readFloat();
                    float[][][] expected=new float[4][2][3];for(float[][] symbol:expected)for(float[] horizon:symbol)for(int j=0;j<3;j++)horizon[j]=in.readFloat();
                    int expectedAction=in.readInt(),fixedExpected=in.readInt();boolean isTarget=in.readBoolean();
                    float[][][] predicted=new float[4][2][3];
                    for(int s=0;s<4;s++)for(int h=0;h<2;h++) {
                        if(!eligible[s]){java.util.Arrays.fill(predicted[s][h],Float.NaN);continue;}
                        predicted[s][h]=models[h].predict(input[s],Long.MAX_VALUE);
                        for(int j=0;j<3;j++) {
                            double error=Math.abs(predicted[s][h][j]-expected[s][h][j]);max=Math.max(max,error);probabilities++;
                            if(error>1e-6)throw new AssertionError("probability frame="+frame+" error="+error);
                        }
                    }
                    int action=Direct19Policy.decide(nativeAction,entry,grade,eligible,predicted);
                    int fixed=Direct19Policy.decide(nativeAction,entry,grade,eligible,predicted,true);
                    if(action!=expectedAction || fixed!=fixedExpected)throw new AssertionError("action frame="+frame+" "+action+" != "+expectedAction+" fixed="+fixed+" != "+fixedExpected);
                    frames++;if(isTarget)target++;
                }
            }
            if(in.read()!=-1)throw new AssertionError("trailing fixture bytes");
        }
        System.out.println("{\"status\":\"PASS\",\"portable_frames\":"+frames+",\"target_frames\":"+target+",\"probability_values_checked\":"+probabilities+",\"max_abs_probability_error\":"+max+",\"auto_and_fixed3_actions_exact\":true}");
    }
}

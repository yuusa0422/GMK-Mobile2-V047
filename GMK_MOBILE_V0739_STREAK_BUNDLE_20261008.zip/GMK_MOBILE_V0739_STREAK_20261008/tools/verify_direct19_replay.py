from pathlib import Path
import importlib.util,json,struct,subprocess,sys,time,os
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2'
import numpy as np
from threadpoolctl import threadpool_limits

project=Path(__file__).resolve().parents[1];study=Path(sys.argv[1]).resolve();work=Path(sys.argv[2]).resolve();work.mkdir(parents=True,exist_ok=True)
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
runner=module('research',study/'run_study.py');exporter=module('exporter',project/'tools/export_direct19_models.py')
protocol=json.loads((study/'PROTOCOL.json').read_text());frames,eligible,x,coverage=runner.load_inputs(protocol)
decisions=dict(np.load(study/'policy_decisions.npz',allow_pickle=False))
auto=list(decisions['policies']).index('HGB15_TRAIN20__NATIVE_C_OPEN4_BOTH_M10')
fixed=list(decisions['policies']).index('HGB15_TRAIN20__NATIVE_C_OPEN4_M10_3')
days=np.unique(frames['dates']);fit_records=[];began=time.monotonic()
def utf(f,text):
    b=str(text).encode('utf-8');f.write(struct.pack('>H',len(b)));f.write(b)
fixture=work/'walkforward_fixture.bin'
with fixture.open('wb') as out,threadpool_limits(limits=2):
    out.write(struct.pack('>i',len(days)-10))
    for index in range(10,len(days)):
        day=str(days[index]);ef=np.flatnonzero(frames['dates']==day)
        for h in range(2):
            rr,ss,tx,ty=runner.train_arrays(frames,eligible,x,days,index,20,h)
            model=runner.estimator(protocol,protocol['specs'][0]);model.fit(tx,ty)
            path=work/(day+'_'+str((3,5)[h])+'.bin');digest=exporter.export(model,path)
            utf(out,path);utf(out,digest)
            fit_records.append({'day':day,'horizon':(3,5)[h],'model_sha256':digest,'latest_label':int(np.max(frames['boundaries'][rr]+(3,5)[h]*60))})
        out.write(struct.pack('>i',len(ef)))
        with np.load(study/'DAILY_PREDICTIONS'/(day+'.npz'),allow_pickle=False) as z:expected=z['predictions'][:,0]
        for local,f in enumerate(ef):
            old=int(frames['original_action'][f]);a=4*(old//2)+old%2 if old>=0 else -1
            out.write(struct.pack('>ii?',int(f),a,bool(frames['native_entry'][f])));utf(out,frames['original_grade'][f])
            out.write(eligible[f].astype(np.uint8).tobytes());out.write(x[f].astype('>f4').tobytes());out.write(expected[local].astype('>f4').tobytes())
            out.write(struct.pack('>ii?',int(decisions['action'][auto,f]),int(decisions['action'][fixed,f]),str(day)[:7] in protocol['target_months']))
        print(json.dumps({'verified_fixture_day':day,'days_done':index-9,'days_total':82,'seconds':round(time.monotonic()-began,1)}),flush=True)
classes=work/'classes';classes.mkdir(exist_ok=True)
sources=[project/'app/src/main/java/jp/gmk/mobile/domain/direct19'/v for v in ('Direct19Model.java','Direct19Policy.java')]+[project/'tools/Direct19Replay.java']
subprocess.run(['java','com.sun.tools.javac.Main','-d',str(classes)]+list(map(str,sources)),check=True)
result=subprocess.run(['java','-cp',str(classes),'Direct19Replay',str(fixture)],check=True,capture_output=True,text=True)
report=json.loads(result.stdout);assert report['target_frames']==6790
report.update(fits_for_portability_verification=164,model_fold_records=fit_records,
              scope='Portable model/policy replay with audited research feature inputs; Android feature builder is checked separately',
              protocol_sha256=runner.sha(study/'PROTOCOL.json'),elapsed_seconds=time.monotonic()-began)
(project/'DIRECT19_PORTABLE_REPLAY_AUDIT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(result.stdout,flush=True)

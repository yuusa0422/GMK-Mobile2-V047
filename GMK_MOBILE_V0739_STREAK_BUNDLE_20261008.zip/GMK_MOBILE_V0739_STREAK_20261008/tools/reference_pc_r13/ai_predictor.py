"""Read-only exported weights. NumPy CPU inference; no pickle, Torch or online fitting."""
import hashlib
import json
import math
from pathlib import Path
import time
import numpy as np


def checkpoint(deadline):
    if time.monotonic() >= deadline:
        raise TimeoutError('R13-INFERENCE-DEADLINE')


def softmax(x):
    e = np.exp(x - x.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)


def gelu(x):
    # PyTorch GELU default is erf, not the tanh approximation.
    erf = np.fromiter((math.erf(float(v) / math.sqrt(2)) for v in x.flat), dtype=np.float32, count=x.size).reshape(x.shape)
    return .5 * x * (1 + erf)


class NeuralPredictor:
    def __init__(self, path, kind):
        with np.load(path, allow_pickle=False) as z:
            self.weights = {k: z[k] for k in z.files}
        self.kind = kind
        if not all(np.isfinite(v).all() for v in self.weights.values()):
            raise ValueError('R13-WEIGHT-NONFINITE')
        if (self.weights['std'] <= 0).any():
            raise ValueError('R13-NORMALIZATION')

    def linear(self, x, name):
        return x @ self.weights[name + '.weight'].T + self.weights[name + '.bias']

    def tcn(self, x, width, dilations, deadline):
        x = self.linear(x, 'project')
        for index, dilation in enumerate(dilations):
            checkpoint(deadline)
            w = self.weights[f'body.{index}.conv.weight']
            z = np.broadcast_to(self.weights[f'body.{index}.conv.bias'], x.shape).copy()
            for k in range(3):
                shift = (2 - k) * dilation
                if shift < x.shape[1]:
                    z[:, shift:] += x[:, :x.shape[1]-shift] @ w[:, :, k].T
            x = x + gelu(z)
        return x[:, -1]

    def predict(self, sequence, context=None, deadline=math.inf):
        checkpoint(deadline)
        w = self.weights
        if self.kind == 'TCN':
            present = sequence[:, :, -1:] > 0
            x = np.clip((sequence[:, :, :-1] - w['mean']) / w['std'], -10, 10)
            x = np.where(present, x, 0)
            x = np.concatenate([x, present], -1).astype(np.float32)
            v = self.linear(self.tcn(x, 32, (1, 2, 4), deadline), 'head')
        else:
            c = np.clip((context - w['mean']) / w['std'], -10, 10).astype(np.float32)
            x = sequence.astype(np.float32, copy=False)
            if self.kind == 'M1_LINEAR':
                v = self.linear(np.concatenate([x.reshape(len(x), -1), c], -1), 'head')
            else:
                if self.kind == 'M1_TCN':
                    h = self.tcn(x, 24, (1, 2, 4, 8, 16), deadline)
                elif self.kind == 'M1_LSTM':
                    h = np.zeros((len(x), 24), np.float32)
                    state = np.zeros_like(h)
                    inp = x @ w['body.weight_ih_l0'].T + w['body.bias_ih_l0']
                    for t in range(x.shape[1]):
                        checkpoint(deadline)
                        gates = inp[:, t] + h @ w['body.weight_hh_l0'].T + w['body.bias_hh_l0']
                        i, f, g, o = np.split(gates, 4, axis=-1)
                        sigmoid = lambda q: 1 / (1 + np.exp(-np.clip(q, -80, 80)))
                        state = sigmoid(f) * state + sigmoid(i) * np.tanh(g)
                        h = sigmoid(o) * np.tanh(state)
                else:
                    raise ValueError('R13-MODEL-KIND')
                v = self.linear(np.concatenate([h, gelu(self.linear(c, 'context.0'))], -1), 'head')
        checkpoint(deadline)
        return softmax(v.reshape(-1, 3, 3))


class XgbPredictor:
    def __init__(self, path):
        learner = json.loads(Path(path).read_text())['learner']
        model = learner['gradient_booster']['model']
        self.trees = model['trees']
        self.classes = model['tree_info']
        base = learner['learner_model_param']['base_score']
        self.base = np.asarray(json.loads(base) if base.startswith('[') else [float(base)]*3, dtype=np.float32)
        if learner['objective']['name'] != 'multi:softprob':
            raise ValueError('R13-XGB-OBJECTIVE')
        for tree in self.trees:
            if any(tree['split_type']):
                raise ValueError('R13-XGB-CATEGORICAL-UNSUPPORTED')

    def predict(self, features, deadline=math.inf):
        x = np.asarray(features, dtype=np.float32)
        out = np.broadcast_to(self.base, (len(x), 3)).copy()
        for n, (tree, cls) in enumerate(zip(self.trees, self.classes)):
            if n % 30 == 0:
                checkpoint(deadline)
            left, right = tree['left_children'], tree['right_children']
            condition, feature = tree['split_conditions'], tree['split_indices']
            for r, row in enumerate(x):
                node = 0
                for _ in range(100):
                    if left[node] == -1:
                        out[r, cls] += np.float32(condition[node])
                        break
                    value = row[feature[node]]
                    take_left = tree['default_left'][node] if math.isnan(value) else value < np.float32(condition[node])
                    node = left[node] if take_left else right[node]
                else:
                    raise ValueError('R13-XGB-CYCLE')
        checkpoint(deadline)
        return softmax(out).reshape(-1, 3, 3)


class Predictors:
    def __init__(self, directory, fold='2026-08'):
        directory = Path(directory)
        self.manifest = json.loads((directory / 'manifest.json').read_text())
        if self.manifest.get('policy') != 'LONG_XGB_M1_C_PLUS_NON_NATIVE_OPEN36_M10':
            raise ValueError('R13-MANIFEST-POLICY')
        if hashlib.sha256((directory/'features.json').read_bytes()).hexdigest() != self.manifest.get('features_sha256'):
            raise ValueError('R13-FEATURE-SHA')
        self.fold = fold
        record = self.manifest['folds'][fold]
        self.available_from = record['available_from']
        self.models = {}
        for name, spec in record['models'].items():
            path = directory / spec['asset']
            if hashlib.sha256(path.read_bytes()).hexdigest() != spec['sha256']:
                raise ValueError('R13-MODEL-SHA:' + name)
            self.models[name] = XgbPredictor(path) if name == 'XGB' else NeuralPredictor(path, spec['kind'])
        self.model_ids = {name: spec['sha256'] for name, spec in record['models'].items()}

    def predict(self, inputs, native_c, deadline):
        banks = {'XGB': self.models['XGB'].predict(inputs['tree'], deadline)}
        if native_c:
            for name in ('M1_TCN', 'M1_LSTM', 'M1_LINEAR'):
                banks[name] = self.models[name].predict(inputs['minute'], inputs['context'], deadline)
            banks['RULE365'] = inputs['rule']
        else:
            banks['TCN'] = self.models['TCN'].predict(inputs['snapshot'], deadline=deadline)
        return banks

"""R13 fixed policy, inference and input contracts; no I/O or online training here."""

"""Causal minute inputs, extracted unchanged from audited R13."""
import numpy as np

PRICE=('return1','return2','return3','return5','return10','return15','return30','macd_hist','ema12_distance','ema26_distance','body','range','upper_wick','lower_wick','m5_return1','m5_trend12_26','m15_return1','m15_trend12_26','partial_body','partial_range','jpy_mean5','jpy_mean15','relative_strength5','underlying_USD_return1','underlying_USD_return5','driver_USD_strength1','driver_USD_strength5')

OTHER=('rsi7','rsi14','bb_z12','bb_z20','unchanged_fraction5','unchanged_fraction15','volume_ratio','m5_rsi7','m15_rsi7','jpy_agreement','correlation_12','correlation_36','time_sin','time_cos','spread_bps','partial_progress','quote_age','symbol0','symbol1','symbol2','symbol3','symbol4','symbol5')

def context_features(d):
    x=d['X'];names=d['names'].tolist();atr=np.maximum(np.abs(x[:,:,names.index('atr14')]),1e-4)
    v=[np.clip(x[:,:,names.index(q)]/atr,-100,100) for q in PRICE]
    v += [x[:,:,names.index(q)] for q in OTHER]
    raw=np.concatenate([np.stack(v,-1),d['candidate_features_3m']],-1)
    return np.nan_to_num(raw,nan=0.,posinf=100.,neginf=-100.).astype(np.float32),list(PRICE+OTHER)+['native_'+q for q in d['candidate_feature_names'].tolist()]

def sequence_batch(cache,d,indices,symbols,length=60):
    ix=np.asarray(indices);ss=np.asarray(symbols);b=d['boundaries'][ix]
    expected=b[:,None]-120-np.arange(length-1,-1,-1)[None]*60
    pos=(expected-cache['times'][0])//60
    within=(pos>=0)&(pos<len(cache['times']))
    pos=np.clip(pos,0,len(cache['times'])-1)
    present=within&cache['present'][pos,ss[:,None]]
    previous=within&cache['previous_present'][pos,ss[:,None]]
    q=cache['ohlcv'][pos,ss[:,None]];o,h,l,c,vol=np.moveaxis(q,-1,0)
    last=c[:,-1:]
    atr=np.maximum(np.abs(d['X'][ix,ss,d['names'].tolist().index('atr14')]),1e-4)[:,None]
    def rel(a,z):
        with np.errstate(invalid='ignore',divide='ignore'):return 10000*np.log(a/z)/atr
    f=[rel(c,last),rel(o,last),rel(c,o),rel(h,l),rel(h,np.maximum(o,c)),rel(np.minimum(o,c),l),cache['returns'][pos,ss[:,None]]/atr]
    lv=np.log1p(np.maximum(np.nan_to_num(vol,nan=0),0));den=present.sum(1,keepdims=True)
    vm=np.divide((lv*present).sum(1,keepdims=True),den,out=np.zeros((len(ix),1)),where=den>0)
    f += [lv-vm,cache['fx'][pos]/atr,cache['underlying'][pos,ss[:,None]]/atr]
    seq=np.clip(np.nan_to_num(np.stack(f,-1),nan=0.,posinf=20.,neginf=-20.),-20,20)
    seq[~present]=0
    # A final missing bar must not give an invalid reference level to earlier bars.
    seq[~present[:,-1],:,:2]=0
    return np.concatenate([seq,present[:,:,None],previous[:,:,None]],-1).astype(np.float32)


DESCRIPTORS=('return_sum','return_volatility','positive_fraction','sign_switch_fraction','path_efficiency','body_mean','range_mean','upper_wick_mean','lower_wick_mean','location_in_range','fx_return_sum','usd_return_sum','volume_last_relative','present_fraction')

def summarize(seq):
    values=[];names=[]
    for w in (3,5,10,15,30,60):
        z=seq[:,-w:];mask=z[:,:,10]>0;den=np.maximum(mask.sum(1),1)
        ret=z[:,:,6];valid=mask&(z[:,:,11]>0);vr=np.where(valid,ret,0);vd=np.maximum(valid.sum(1),1)
        total=vr.sum(1);mu=total/vd;vol=np.sqrt((np.square(vr-mu[:,None])*valid).sum(1)/vd)
        signs=np.sign(vr);switch=(signs[:,1:]*signs[:,:-1]<0)&valid[:,1:]&valid[:,:-1]
        paths=z[:,:,0];low=np.min(np.where(mask,paths,np.inf),1);high=np.max(np.where(mask,paths,-np.inf),1)
        location=np.divide(paths[:,-1]-low,high-low,out=np.zeros(len(z)),where=np.isfinite(high-low)&(high>low))
        out=[total,vol,((vr>0)&valid).sum(1)/vd,switch.sum(1)/np.maximum(vd-1,1),np.abs(total)/np.maximum(np.abs(vr).sum(1),1e-6)]
        out += [(z[:,:,j]*mask).sum(1)/den for j in (2,3,4,5)]
        out += [location,(z[:,:,8]*mask).sum(1),(z[:,:,9]*mask).sum(1),z[:,-1,7]-(z[:,:,7]*mask).sum(1)/den,mask.mean(1)]
        values.extend(out);names.extend(f'm{w}_{q}' for q in DESCRIPTORS)
    return np.nan_to_num(np.stack(values,-1),nan=0.,posinf=100.,neginf=-100.).astype(np.float32),names


def minute_cache(prices, boundary):
    """Exactly 61 completed minutes, including the predecessor of the first token."""
    from ..mobile_rule_engine import INSTRUMENTS
    symbols = tuple(INSTRUMENTS) + ('EURUSD', 'GBPUSD', 'AUDUSD', 'NZDUSD', 'BTCUSD')
    times = np.arange(int(boundary)-3720, int(boundary)-60, 60, dtype=np.int64)
    raw = np.full((len(times), len(symbols), 5), np.nan, np.float64)
    for s, code in enumerate(symbols):
        for b in prices.get(code, ()):
            if times[0] <= b.time <= times[-1] and (b.time-times[0]) % 60 == 0:
                raw[int((b.time-times[0])//60), s] = (b.open, b.high, b.low, b.close, b.volume)
    present = np.isfinite(raw[:,:,:4]).all(-1) & (raw[:,:,:4] > 0).all(-1) & (raw[:,:,1] >= raw[:,:,2])
    previous = np.zeros_like(present); previous[1:] = present[:-1]
    ret = np.zeros(present.shape, np.float32)
    with np.errstate(divide='ignore', invalid='ignore'):
        ret[1:] = np.where(present[1:] & present[:-1], 10000*np.log(raw[1:,:,3]/raw[:-1,:,3]), 0)
    den = present[:,:5].sum(1)
    fx = np.divide(ret[:,:5].sum(1), den, out=np.zeros(len(times), np.float32), where=den>0)
    underlying = np.zeros((len(times), 6), np.float32); underlying[:,1:] = ret[:,6:]
    return dict(times=times, ohlcv=raw[:,:6], present=present[:,:6], previous_present=previous[:,:6], returns=ret[:,:6], fx=fx, underlying=underlying)


def current_inputs(service, native_names, joint=None, joint_names=None):
    """Same float32 raw context and native feature ordering as the training archive."""
    names = list(PRICE + OTHER)
    # atr14 is needed for normalization but is not one of the 50 model columns.
    if joint is None:
        rows = np.asarray(service.joint_features(names + ['atr14'], 3), np.float32)
    else:
        source = np.asarray(joint[0], np.float32)
        rows = source[:, [joint_names.index(n) for n in names+['atr14']]]
    rules = service.rules(service.boundary)
    from ..mobile_rule_engine import INSTRUMENTS
    from ..mobile_horizon_features import SYMBOLS
    native = np.asarray([[rules.get(s,{}).get('mobile_'+k,np.nan) for k in native_names] for s in INSTRUMENTS], np.float32)
    d = dict(X=rows[None], names=np.array(names+['atr14']), candidate_features_3m=native[None], candidate_feature_names=np.array(native_names), boundaries=np.array([int(service.boundary)]))
    context, _ = context_features(d)
    atr = np.maximum(np.abs(rows[:,-1]), 1e-4)
    raw = np.concatenate([np.clip(rows[:,:len(PRICE)]/atr[:,None], -100, 100), rows[:,len(PRICE):-1]], -1)
    raw = np.nan_to_num(raw, nan=0., posinf=100., neginf=-100.).astype(np.float32)
    cache = minute_cache({s: series.bars for s,series in zip(SYMBOLS, service.series)}, service.boundary)
    minute = sequence_batch(cache, d, np.zeros(6, dtype=int), np.arange(6))
    stats, _ = summarize(minute)
    tree = np.concatenate([context[0], stats], -1)
    pooled = np.concatenate([np.repeat(tree[:,None,:], 3, axis=1), np.broadcast_to(np.eye(3, dtype=np.float32), (6,3,3))], -1).reshape(18,-1)
    return dict(context=context[0], minute=minute, tree=pooled), raw


def snapshot_sequence(current, history, boundary):
    """Missing scheduled observations are NOT reconstructed using later quotes."""
    from ..mobile_horizon_features import scheduled
    result = np.zeros((6,16,51), np.float32)
    missing = []
    for t in range(16):
        at = boundary - (15-t)*300
        # Research history resets across the non-scheduled overnight/weekend gap.
        if any(not scheduled(x) for x in range(int(at), int(boundary)+1, 300)):
            continue
        row = current if at == boundary else history.get(at)
        if row is None:
            missing.append(at)
            continue
        value = np.asarray(row, np.float32)
        if value.shape != (6,50) or not np.isfinite(value).all():
            raise ValueError('R13-HISTORY-INVALID')
        result[:,t,:50] = value
        result[:,t,50] = 1
    return result, missing

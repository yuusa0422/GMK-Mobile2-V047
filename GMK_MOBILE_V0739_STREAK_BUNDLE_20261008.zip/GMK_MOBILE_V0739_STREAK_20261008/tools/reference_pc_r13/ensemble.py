"""Exact frozen R11 -> R12 -> R13 action arithmetic. Outcome-free and stateless."""
import numpy as np
POLICY = 'LONG_XGB_M1_C_PLUS_NON_NATIVE_OPEN36_M10'
HORIZONS = (3, 10, 15)


def propose(probabilities, safe, base, eligible, same_symbol, margin):
    p = np.asarray(probabilities)
    if p.shape != (6, 3, 3) or not np.isfinite(p).all():
        raise ValueError('R13-PROBABILITY-SHAPE')
    if (p < 0).any() or (p > 1).any() or not np.allclose(p.sum(-1), 1, atol=2e-5):
        raise ValueError('R13-PROBABILITY-RANGE')
    if not eligible:
        return base
    values = p[:, :, [0, 2]].reshape(36)
    allowed = np.repeat(np.asarray(safe, dtype=bool), 6)
    if same_symbol:
        allowed &= np.arange(36) // 6 == base // 6
    scores = np.where(allowed, values, -np.inf)
    choice = int(scores.argmax())
    return choice if np.isfinite(scores[choice]) and scores[choice] > values[base] + margin else base


def decide(base, entry, native, grade, safe, banks):
    if not 0 <= base < 36 or len(safe) != 6:
        raise ValueError('R13-ACTION-CONTRACT')
    if not entry or (native and grade in ('S', 'A', 'B')):
        return base, []
    if not safe[base // 6]:
        raise ValueError('R13-UNSAFE-BASE')
    trace = []
    action = base
    if not native:
        after = propose(banks['TCN'], safe, action, True, True, .06)
        trace.append({'stage': 'R11', 'before': action, 'after': after})
        action = after
    if native and grade == 'C':
        # Keep float32 operations/order identical to the research reference.
        minute = np.mean([banks[k] for k in ('M1_TCN', 'M1_LSTM', 'M1_LINEAR')], axis=0)
        probability = .5 * (banks['RULE365'] + minute)
        after = propose(probability, safe, action, True, True, .10)
        trace.append({'stage': 'R12', 'before': action, 'after': after})
        action = after
    after = propose(banks['XGB'], safe, action, (not native) or grade == 'C', False, .10)
    trace.append({'stage': 'R13', 'before': action, 'after': after})
    if not safe[after // 6]:
        raise ValueError('R13-UNSAFE-RESULT')
    return after, trace

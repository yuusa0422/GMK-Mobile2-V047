"""Prepare a causal monthly replay from the original research inputs and minute DB.

Requires NumPy and the original inputs. Production August assets are never modified.
Use the compact ledger check for ordinary release builds.
"""
from pathlib import Path
import argparse, csv, hashlib, importlib.util, json, sqlite3, struct
import numpy as np
from export_pc_r13 import export

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    a=argparse.ArgumentParser()
    for k in ('pc','joint','r2','prior','reference','db','output'):a.add_argument('--'+k,required=True,type=Path)
    p=a.parse_args();p.output.mkdir(parents=True,exist_ok=True)
    spec=importlib.util.spec_from_file_location('pc_features',p.pc/'app/domain/r13/features.py')
    features=importlib.util.module_from_spec(spec);spec.loader.exec_module(features)
    z=np.load(p.joint,allow_pickle=False);ev=np.flatnonzero((z['months']>='2026-05')&(z['months']<='2026-08'))
    d={k:z[k][ev] for k in ('X','boundaries','months','candidate_features_3m','safe','Y','entry_price','expiry_price','feature_last_m1')}
    for k in ('names','candidate_feature_names'):d[k]=z[k]
    prior=np.load(p.prior,allow_pickle=False);ref=np.load(p.reference,allow_pickle=False)
    np.testing.assert_array_equal(d['boundaries'],prior['boundary'])
    for k in ('boundaries','months','safe','Y','entry_price','expiry_price'):np.testing.assert_array_equal(d[k],ref[k])
    for k in ('entry','supplement'):np.testing.assert_array_equal(prior[k],ref[k])
    symbols=['USDJPY','EURJPY','GBPJPY','AUDJPY','NZDJPY','BTCJPY']
    base=np.array([symbols.index(s)*6+[3,10,15].index(int(h))*2+int(dr=='HIGH')
                   for s,h,dr in zip(prior['instrument'],prior['horizon'],prior['direction'])],np.int32)
    y=d['Y'][np.arange(len(ev)),base//6,base%6//2]
    labels=np.where(y<0,'UNKNOWN',np.where(y==1,'DRAW',np.where(y==np.where(base%2,2,0),'WIN','LOSE')))
    np.testing.assert_array_equal(labels[prior['entry']],prior['outcome'][prior['entry']])
    last=d['feature_last_m1'];assert np.all(~np.isfinite(last)|(last<=d['boundaries'][:,None]-120))
    names=d['names'].tolist();rows=d['X'][:,:,[names.index(n) for n in features.PRICE+features.OTHER+('atr14',)]]
    context,_=features.context_features(d)
    begin=int(d['boundaries'][0]-3720);end=int(d['boundaries'][-1]-120)
    raw=np.full(((end-begin)//60+1,11,5),np.nan,np.float64)
    codes=['JPY=X','EURJPY=X','GBPJPY=X','AUDJPY=X','NZDJPY=X','BTC-JPY','EURUSD=X','GBPUSD=X','AUDUSD=X','NZDUSD=X','BTC-USD']
    with sqlite3.connect(p.db.resolve().as_uri()+'?mode=ro',uri=True) as db:
        for s,c in enumerate(codes):
            q=np.asarray(db.execute('SELECT time_utc,open,high,low,close,volume FROM candles_1m WHERE instrument=? AND time_utc BETWEEN ? AND ? ORDER BY time_utc',(c,begin,end)).fetchall(),np.float64)
            raw[((q[:,0]-begin)//60).astype(int),s]=q[:,1:]
    models={};rules=np.empty((len(ev),6,3,3),np.float32)
    source_hashes={str(q.name):sha(q) for q in (p.joint,p.prior,p.reference,p.db)}
    for month in sorted(np.unique(d['months'])):
        ix=np.flatnonzero(d['months']==month);models[str(month)]=export(p.pc,p.output/'folds'/str(month),str(month))
        assert np.all(d['boundaries'][ix]-10>=models[str(month)]['available_from'])
        bpath=p.r2/'evidence'/str(month)/'raw_predictions.npz';bank=np.load(bpath,allow_pickle=False)
        loc=np.searchsorted(bank['indices'],ev[ix]);np.testing.assert_array_equal(bank['indices'][loc],ev[ix])
        rules[ix]=bank['RULE_STATE365'][loc].astype(np.float32);source_hashes[str(month)+'/RULE_STATE365']=sha(bpath)
    with (p.output/'frames.bin').open('wb') as f:
        f.write(b'G70F'+struct.pack('<i',len(ev)))
        for n,b in enumerate(d['boundaries']):
            entry=bool(prior['entry'][n]);native=entry and not bool(prior['supplement'][n]);grade='SABC E'.replace(' ','').index(str(ref['grade'][n]))
            f.write(struct.pack('<q6i',int(b),int(str(d['months'][n])[-2:])-5,int(base[n]),int(entry),int(native),grade,int(ref['action'][n])))
            f.write(d['safe'][n].astype(np.uint8).tobytes())
            f.write(rows[n].astype('<f4').tobytes());f.write(d['candidate_features_3m'][n].astype('<f4').tobytes())
            pos=int((b-3720-begin)//60);f.write(raw[pos:pos+61].astype('<f8').tobytes())
            f.write(context[n].astype('<f4').tobytes());f.write(rules[n].astype('<f4').tobytes())
    with (p.output/'seed_ledger.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['boundary','month','entry','native','grade','base_action','expected_action']+
            ['safe_'+s for s in symbols]+['entry_price_'+s for s in symbols]+['judge3_price_'+s for s in symbols]+['y3_'+s for s in symbols])
        for n,b in enumerate(d['boundaries']):w.writerow([int(b),str(d['months'][n]),int(prior['entry'][n]),int(prior['entry'][n] and not prior['supplement'][n]),str(ref['grade'][n]),int(base[n]),int(ref['action'][n])]+d['safe'][n].astype(int).tolist()+d['entry_price'][n].tolist()+d['expiry_price'][n,:,0].tolist()+d['Y'][n,:,0].tolist())
    record={'scheduled_slots':len(ev),'source_sha256':source_hashes,'folds':models,'causal_feature_last_m1_checked':True,
        'minute_window':'boundary-3720 through boundary-120; no later bar supplied',
        'base_entry_mask':'Saved R9 decisions; identical to prior and R13 reference',
        'rule_bank':'Saved monthly RULE_STATE365 predictions from original R2; no refit',
        'replay_scope':'Actual mobile Java R13 features, neural/XGB inference and policy; saved PC base decisions/rule bank, not Android end-to-end',
        'frames_sha256':sha(p.output/'frames.bin'),'seed_ledger_sha256':sha(p.output/'seed_ledger.csv')}
    (p.output/'provenance.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'frames':len(ev),'binary_bytes':(p.output/'frames.bin').stat().st_size,'status':'PREPARED'},indent=2))

if __name__=='__main__':main()

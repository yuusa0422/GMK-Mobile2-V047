"""Summarize one user-supplied diagnostic; exported rows are not the full history."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import argparse, hashlib, json

def parse_time(value):
    return datetime.fromisoformat(value.split("[", 1)[0])

def minutes(row):
    try:
        seconds = (parse_time(row["judge_time_jst"]) - parse_time(row["entry_time_jst"])).total_seconds()
        return int(seconds // 60) if seconds > 0 and seconds % 60 == 0 else 0
    except (ValueError, TypeError, KeyError):
        return 0

def summarize(rows):
    entries = [r for r in rows if r.get("decision") == "ENTRY"]
    counts = Counter(r.get("result_status") for r in entries)
    wins, losses = counts["WIN"], counts["LOSE"]
    draws = sum(r.get("result_status") == "LOSE" and r.get("entry_rate") is not None and
        r.get("judge_rate") is not None and r["entry_rate"] == r["judge_rate"] for r in entries)
    return {"exported_rows": len(rows), "entry_rows": len(entries), "wins": wins,
        "losses": losses, "resolved": wins + losses,
        "win_rate_percent": wins * 100 / (wins + losses) if wins + losses else None,
        "draw_losses": draws, "status_counts": dict(sorted(counts.items())),
        "skip_rows": sum(r.get("decision") == "SKIP" for r in rows)}

def audit(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    rows = data["result_history"]
    win, lose = data["entry_win_count"], data["entry_lose_count"]
    return {"input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "app": data["app"], "version_code": data["version_code"],
        "generated_at_jst": data["generated_at_jst"],
        "cached_history_rows": data["history_persistence_stats"]["cached_rows"],
        "exported_history_rows": len(rows), "full_history_by_horizon_available": False,
        "aggregate_entry": {"wins": win, "losses": lose, "resolved": win + lose,
            "win_rate_percent": win * 100 / (win + lose),
            "same_as_legacy_outcome_totals": data["outcome_win_count"] == win and data["outcome_lose_count"] == lose},
        "skip_shadow_resolved_count": data["skip_shadow_resolved_count"],
        "one_minute_auto_scan": data["one_minute_auto_scan"],
        "exported_by_actual_minutes": {str(m): summarize([r for r in rows if minutes(r) == m])
            for m in sorted({minutes(r) for r in rows})},
        "horizon_policy": data["horizon_policy"],
        "history_persistence": data["history_persistence_stats"],
        "claim_scope": "AGGREGATE_AND_EXPORTED_ROWS_ONLY_NOT_BROKER_EXECUTION_OR_UPDATED_APP"}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("diagnostic", type=Path)
    print(json.dumps(audit(parser.parse_args().diagnostic), ensure_ascii=False, indent=2))

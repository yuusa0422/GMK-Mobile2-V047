"""Ground truth from the unmodified PC implementation, not the Android algorithms."""
from pathlib import Path
import sys,struct,json,math,io,os,hashlib
from contextlib import contextmanager
import numpy as np

def emit(f,a,dtype='<f4'):f.write(np.asarray(a,dtype=dtype).tobytes())
@contextmanager
def atomic_output(path):
    buffer=io.BytesIO()
    yield buffer
    content=buffer.getvalue()
    tmp=path.with_suffix('.tmp')
    with tmp.open('wb') as f:
        assert f.write(content)==len(content)
        f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
    assert path.read_bytes()==content, f'fixture integrity failed: {path}'
def build(pc,root):
    sys.path.insert(0,str(pc.resolve()))
    from app.domain.r13 import ai_predictor,features,ensemble
    from app.domain.mobile_rule_engine import INSTRUMENTS
    native_names=json.loads((pc/'app/domain/r13_data/features.json').read_text())['native_names']
    target=root/'tools/pc_r13_fixtures';target.mkdir(parents=True,exist_ok=True)
    assets=root/'app/src/main/assets/pc_r13';meta=json.loads((assets/'manifest.json').read_text())
    (target/'hashes.properties').write_text(''.join(f'{k}={s["sha256"]}\n' for k,s in meta['models'].items()))
    rng=np.random.default_rng(734)
    predictor=ai_predictor.Predictors(pc/'app/domain/r13_data')
    fixture=np.load(pc/'tests/fixtures/r13_inference.npz',allow_pickle=False)
    cases=[]
    for frame in range(12):
        take=slice(frame*6,frame*6+6);tree=slice(frame*18,frame*18+18)
        cases.append({k:fixture[k][tree if k=='tree' else take] for k in ('minute','context','tree','snapshot')})
    for _ in range(12):
        cases.append(dict(minute=rng.normal(0,.6,(6,60,12)).astype('f4'),context=rng.normal(0,1,(6,62)).astype('f4'),tree=rng.normal(0,1,(18,149)).astype('f4'),snapshot=np.concatenate([rng.normal(0,1,(6,16,50)),rng.choice([0.,1.],(6,16,1))],-1).astype('f4')))
    with atomic_output(target/'inference.bin') as f:
        f.write(struct.pack('<i',len(cases)))
        for inputs in cases:
            for k in ('minute','context','tree','snapshot'):emit(f,inputs[k])
            for k in ('TCN','M1_TCN','M1_LSTM','M1_LINEAR','XGB'):
                expected=predictor.models[k].predict(inputs['tree']) if k=='XGB' else predictor.models[k].predict(inputs['snapshot'] if k=='TCN' else inputs['minute'],None if k=='TCN' else inputs['context'])
                emit(f,expected)
                inputs['expected_'+k]=expected
            banks={k:inputs['expected_'+k] for k in ('TCN','M1_TCN','M1_LSTM','M1_LINEAR','XGB')}
            banks['RULE365']=np.full((6,3,3),1/3,dtype='f4')
            for native in (False,True):
                for base in range(36):
                    action,_=ensemble.decide(base,True,native,'C' if native else 'SUPPLEMENT',[True]*6,banks)
                    f.write(struct.pack('<i',action))
    with atomic_output(target/'features.bin') as f:
        f.write(struct.pack('<i',24))
        names=features.PRICE+features.OTHER+('atr14',)
        boundary=1791347700
        for case in range(24):
            rows=rng.normal(0,2,(6,51)).astype('f4');rows[:,-1]=rng.uniform(.01,15,6)
            native=rng.normal(0,1,(6,12)).astype('f4')
            # Twelve actual native/context vectors are also covered above by inference fixtures.
            base=np.array([150,160,180,100,90,10000000,1.1,1.3,.7,.6,60000.])
            closes=base[None]*np.exp(rng.normal(0,.0002,(61,11)).cumsum(0))
            opens=closes*np.exp(rng.normal(0,.0001,(61,11)));high=np.maximum(opens,closes)*1.0002;low=np.minimum(opens,closes)*.9998
            bars=np.stack([opens,high,low,closes,rng.integers(0,1000,(61,11))],-1)
            if case%3==1:bars[rng.integers(0,61,12),rng.integers(0,11,12)]=np.nan
            if case%4==2:bars[-1,2]=np.nan
            if case==4:rows[0,0]=np.nan;native[1,3]=np.inf;rows[2,-1]=0
            if case==5:bars[11,2,4]=np.inf;bars[14,3,4]=-np.inf
            times=np.arange(boundary-3720,boundary-60,60,dtype='i8')
            from app.domain.models import Candle
            symbols=tuple(INSTRUMENTS)+('EURUSD','GBPUSD','AUDUSD','NZDUSD','BTCUSD')
            prices={s:[Candle(int(t),*q) for t,q in zip(times,bars[:,j]) if np.isfinite(q[:4]).all()] for j,s in enumerate(symbols)}
            cache=features.minute_cache(prices,boundary)
            d=dict(X=rows[None],names=np.array(names),candidate_features_3m=native[None],candidate_feature_names=np.array(native_names),boundaries=np.array([boundary]))
            context,_=features.context_features(d)
            atr=np.maximum(np.abs(rows[:,-1]),1e-4)
            raw=np.concatenate([np.clip(rows[:,:27]/atr[:,None],-100,100),rows[:,27:-1]],-1)
            raw=np.nan_to_num(raw,nan=0.,posinf=100.,neginf=-100.).astype('f4')
            minute=features.sequence_batch(cache,d,np.zeros(6,dtype=int),np.arange(6))
            stats,_=features.summarize(minute)
            tree=np.concatenate([context[0],stats],-1)
            tree=np.concatenate([np.repeat(tree[:,None],3,1),np.broadcast_to(np.eye(3,dtype='f4'),(6,3,3))],-1).reshape(18,149)
            emit(f,rows);emit(f,native);emit(f,bars,'<f8')
            for a in (raw,context[0],minute,tree):emit(f,a)
    with atomic_output(target/'policy.bin') as f:
        count=2000;f.write(struct.pack('<i',count))
        for case in range(count):
            base=int(rng.integers(0,36));entry=case%7!=0;native=case%2==0;grade=(case//2)%4 if native else 4
            safe=rng.integers(0,2,6).astype(bool);safe[base//6]=True
            banks={k:rng.dirichlet([1,1,1],(6,3)).astype('f4') for k in ('TCN','M1_TCN','M1_LSTM','M1_LINEAR','RULE365','XGB')}
            # Stable first-action handling for all-safe exact ties.
            if case%50==0:
                for k in banks:banks[k][:]=np.float32(1/3)
            expected,_=ensemble.decide(base,entry,native,('S','A','B','C','SUPPLEMENT')[grade],safe,banks)
            f.write(struct.pack('<iiii',base,entry,native,grade));emit(f,safe.astype('i4'),'<i4')
            for p in banks.values():emit(f,p)
            f.write(struct.pack('<i',expected))
    for name,size,count in [('inference.bin',50448,len(cases)),('features.bin',59048,24),('policy.bin',1340,2000)]:
        assert (target/name).stat().st_size==4+size*count, name
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(target.iterdir()) if p.is_file() and p.name!='SHA256.json' and p.suffix!='.tmp'}
    (target/'SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    return {'inference_frames':len(cases),'actual_pc_fixture_frames':12,'feature_frames':24,'policy_frames':2000,'inferred_model_action_cases':len(cases)*72,'pc_policy':ensemble.POLICY}

if __name__=='__main__':
    pc=Path(sys.argv[1]);root=Path(__file__).resolve().parents[1]
    info=build(pc,root);(root/'release_evidence/v0735_pc_sync').mkdir(parents=True,exist_ok=True)
    (root/'release_evidence/v0735_pc_sync/fixture_build.json').write_text(json.dumps(info,indent=2)+'\n');print(info)

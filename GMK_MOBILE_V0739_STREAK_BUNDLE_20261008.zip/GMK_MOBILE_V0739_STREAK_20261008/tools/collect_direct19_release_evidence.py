"""Collect results from a real Android build; do not manufacture build success."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from zoneinfo import ZoneInfo

from verify_apk_assets import verify

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sdk', type=Path, required=True)
    parser.add_argument('--build-log', type=Path, required=True)
    parser.add_argument('--build-exit', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-tests', type=int, required=True)
    args = parser.parse_args()
    assert args.build_exit.read_text().strip() == '0', 'Actual build failed'
    assert 'BUILD SUCCESSFUL' in args.build_log.read_text(), 'Missing actual Gradle success'
    args.output.mkdir(parents=True, exist_ok=True)
    evidence = ROOT / 'release_evidence/v0738_full_audit'
    evidence.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(args.build_log, evidence / 'android_final_build.log')
    cases = []
    for path in sorted((ROOT / 'app/build/test-results/testDebugUnitTest').glob('TEST*.xml')):
        suite = ET.parse(path).getroot()
        assert int(suite.get('failures', 0)) == 0 and int(suite.get('errors', 0)) == 0
        assert int(suite.get('skipped', 0)) == 0, 'Required observed-input test skipped'
        cases.append(dict(suite=suite.get('name'), tests=int(suite.get('tests')), skipped=0,
            failures=0, errors=0, timestamp=suite.get('timestamp')))
        shutil.copyfile(path, evidence / path.name)
    assert sum(x['tests'] for x in cases) == args.expected_tests, cases
    lint_path = ROOT / 'app/build/reports/lint-results-release.xml'
    lint_issues = ET.parse(lint_path).findall('issue')
    assert not any(x.get('severity') in ('Error', 'Fatal') for x in lint_issues)
    shutil.copyfile(lint_path, evidence / lint_path.name)
    result = dict(status='PASS_BUILD_AND_HOST_VALIDATION',
        created_at_jst=datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(),
        application_id='jp.gmk.mobile.rule', version_code=108, version_name='0.7.38-mobile-full-audit',
        real_android_build=True, tests=cases,
        lint=dict(errors=0, warnings=sum(x.get('severity') == 'Warning' for x in lint_issues),
            issues=[dict(id=x.get('id'), severity=x.get('severity')) for x in lint_issues]),
        portable_replay=json.loads((ROOT/'DIRECT19_PORTABLE_REPLAY_AUDIT.json').read_text()),
        kotlin_feature_parity=json.loads((ROOT/'DIRECT19_KOTLIN_FEATURE_AUDIT.json').read_text()),
        rule_ai_functional=json.loads((ROOT/'RULE_AI_FUNCTIONAL_AUDIT.json').read_text()),
        rule_ai_guards=json.loads((ROOT/'RULE_AI_GUARD_AUDIT.json').read_text()),
        public_provider_probes={name:json.loads((evidence/name).read_text()) for name in (
            'LIVE_BTC_PROVIDER_PROBE.json','LIVE_BTC_WEBSOCKET_PROBE.json','LIVE_FOREX_PROVIDER_PROBE.json',
            'LIVE_BTC_HEARTBEAT_RECONNECT_PROBE.json')},
        original_signing_key_available=False, production_signature_applied=False,
        phone_updated=False, device_execution_verified=False, on_device_daily_training=False,
        apk={})
    bt = args.sdk / 'build-tools/35.0.0'
    for mode, source, name in [
        ('release_unsigned', ROOT/'app/build/outputs/apk/release/app-release-unsigned.apk', 'GMK_MOBILE_V0738_RELEASE_UNSIGNED.apk'),
        ('debug_test', ROOT/'app/build/outputs/apk/debug/app-debug.apk', 'GMK_MOBILE_V0738_TEST.apk')]:
        assert source.is_file(), mode
        assets = verify(source, ROOT)
        with zipfile.ZipFile(source) as z:
            dex = b''.join(z.read(n) for n in z.namelist() if n.endswith('.dex'))
            assert all(marker in dex for marker in (b'lastFixedThree', b'GMK_V0736_DIRECT19_C_3_5', b'INVALID_RATE_DATA', b'GmkRuntimeServiceControl', b'BitbankRealtimeFeed', b'btc_independent_of_yahoo_and_scans')), 'Stale APK implementation'
        badging = subprocess.run([str(bt/'aapt'), 'dump', 'badging', str(source)], capture_output=True, text=True, check=True).stdout
        assert "package: name='jp.gmk.mobile.rule' versionCode='108' versionName='0.7.38-mobile-full-audit'" in badging
        assert "sdkVersion:'26'" in badging and "targetSdkVersion:'35'" in badging
        signature = subprocess.run([str(bt/'apksigner'), 'verify', '--verbose', '--print-certs', str(source)], capture_output=True, text=True)
        if mode == 'debug_test':
            assert signature.returncode == 0, signature.stderr
        else:
            assert signature.returncode != 0, 'Release unexpectedly signed with an unknown key'
        (evidence/(mode+'_package.txt')).write_text(badging)
        (evidence/(mode+'_signature.txt')).write_text(signature.stdout+signature.stderr)
        (evidence/(mode+'_models.json')).write_text(json.dumps(assets, indent=2)+'\n')
        target = args.output/name
        shutil.copyfile(source, target)
        result['apk'][mode] = dict(filename=name, bytes=target.stat().st_size, sha256=digest(target),
            models=assets['assets_verified'], signature_verified=signature.returncode == 0,
            signing_mode='unsigned_requires_existing_key' if mode=='release_unsigned' else 'new_debug_key_for_testing')
    (ROOT/'RELEASE_VERIFICATION.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    (args.output/'RELEASE_VERIFICATION.json').write_bytes((ROOT/'RELEASE_VERIFICATION.json').read_bytes())
    print(json.dumps(dict(status=result['status'], tests=args.expected_tests, lint_errors=0,
        apk=result['apk'], phone_updated=False), ensure_ascii=False))

if __name__ == '__main__':
    main()

from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app/src/main/java/jp/gmk/mobile/domain/horizon/HorizonFeatureService.kt'
text=p.read_text()
if 'fun direct19Input' in text:raise SystemExit('already patched')
begin=text.index('    fun jointFeatures(names: List<String>,horizon: Int): Array<FloatArray> {')
part=text[begin:]
part=part.replace('    fun jointFeatures(names: List<String>,horizon: Int): Array<FloatArray> {', '''    fun jointFeatures(names: List<String>,horizon: Int): Array<FloatArray> =
        jointFeaturesUsing(names,horizon,::raw,::rules,true)
    private fun jointFeaturesUsing(names: List<String>,horizon: Int,
        rawAt: (Long)->List<MutableMap<String,Double>>,
        rulesAt: (Long)->Map<String,Map<String,Double>>, includeQuotes: Boolean): Array<FloatArray> {''',1)
part=part.replace('raw(', 'rawAt(').replace('rules(', 'rulesAt(')
part=part.replace('f.putAll(quoteFeatures(s));', 'if(includeQuotes)f.putAll(quoteFeatures(s));')
part=part.replace('            for(width in listOf(12,72,288)) {','            if(names.any { it.startsWith("past_settled_") }) for(width in listOf(12,72,288)) {')
addition='''    /** Completed-price research port. Live quotes remain safety checks only. */
    fun direct19Input(): jp.gmk.mobile.domain.direct19.Direct19Input {
        val requested=(jp.gmk.mobile.domain.r13.R13Features.PRICE.toList()+jp.gmk.mobile.domain.r13.R13Features.OTHER.toList()+"atr14")
        val memo=HashMap<Long,List<MutableMap<String,Double>>>()
        fun observedRaw(b: Long): List<MutableMap<String,Double>> = memo.getOrPut(b) {
            checkpoint()
            val time=Instant.ofEpochSecond(b).atZone(JST);val minute=time.hour*60+time.minute
            series.mapIndexed { s,z ->
                val row=z.features(b)
                row["time_sin"]=sin(2*PI*minute/1440);row["time_cos"]=cos(2*PI*minute/1440)
                for(k in 0..5)row["symbol$k"]=if(s==k)1.0 else 0.0
                for(name in requested) {
                    if(!z.valid(b) && name!="time_sin" && name!="time_cos" && !name.startsWith("symbol"))row[name]=Double.NaN
                    else if(!row.containsKey(name))row[name]=Double.NaN
                }
                row
            }
        }
        fun observedRules(b: Long): Map<String,Map<String,Double>> {
            checkpoint()
            val context=SYMBOLS.take(6).mapIndexedNotNull { s,name->if(series[s].valid(b))name to series[s].context(b,121) else null }.toMap()
            return ruleEngine.horizonRuleFeatures(context,Instant.ofEpochSecond(b).atZone(JST))
        }
        val joint=jointFeaturesUsing(requested,3,::observedRaw,::observedRules,false)
        val rules=observedRules(boundary)
        val native=Array(6) { s->FloatArray(12) { j->(rules[SYMBOLS[s]]?.get("mobile_"+jp.gmk.mobile.domain.r13.R13Features.NATIVE[j]) ?: Double.NaN).toFloat() } }
        val bars=Array(61) { Array(11) { DoubleArray(5) { Double.NaN } } }
        jp.gmk.mobile.domain.r13.R13Features.MINUTE_SYMBOLS.forEachIndexed { s,name->
            val i=SYMBOLS.indexOf(name)
            for(c in series[i].context(boundary,61)) {
                val delta=c.timeEpochMs/1000-(boundary-3720)
                if(delta in 0L..3600L && delta%60L==0L)bars[(delta/60).toInt()][s]=doubleArrayOf(c.open,c.high,c.low,c.close,c.volume)
            }
        }
        val input=jp.gmk.mobile.domain.r13.R13Features.build(joint,native,bars)
        val flags=jp.gmk.mobile.domain.direct19.Direct19Policy.COVERAGE.map { series[SYMBOLS.indexOf(it)].valid(boundary) }
        val features=Array(4) { s->FloatArray(165) { j->if(j<146)input.tree[s*3][j] else if(flags[j-146])1f else 0f } }
        return jp.gmk.mobile.domain.direct19.Direct19Input(boundary,features,BooleanArray(4) { series[it].valid(boundary) },
            SYMBOLS.take(4).mapIndexed { s,name->name to series[s].context(boundary) }.toMap())
    }

'''
p.write_text(text[:begin]+addition+part)
print('patched causal observed input without changing legacy feature methods')

"""Export the existing PC August fold, without retraining or pickle loading."""
from pathlib import Path
import argparse, hashlib, json, struct, shutil
import numpy as np


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def string(value):
    b=value.encode();return struct.pack('<i',len(b))+b


def export(pc_root, root, fold='2026-08'):
    assets=pc_root/'app/domain/r13_data'
    manifest=json.loads((assets/'manifest.json').read_text())
    record=manifest['folds'][fold]
    target=root/'app/src/main/assets/pc_r13';target.mkdir(parents=True,exist_ok=True)
    specs={}
    for name,spec in record['models'].items():
        original=assets/spec['asset']
        assert sha(original)==spec['sha256']
        if name=='XGB':
            learner=json.loads(original.read_text())['learner'];model=learner['gradient_booster']['model']
            assert learner['objective']['name']=='multi:softprob'
            base=learner['learner_model_param']['base_score']
            base=json.loads(base) if base.startswith('[') else [float(base)]*3
            payload=b'GXG1'+np.asarray(base,'<f4').tobytes()+struct.pack('<i',len(model['trees']))
            for tree,cls in zip(model['trees'],model['tree_info']):
                assert not any(tree['split_type'])
                n=len(tree['left_children']);payload+=struct.pack('<ii',cls,n)
                for k in ('left_children','right_children','split_indices'):
                    payload+=np.asarray(tree[k],'<i4').tobytes()
                payload+=np.asarray(tree['split_conditions'],'<f4').tobytes()+bytes(tree['default_left'])
        else:
            with np.load(original,allow_pickle=False) as z:weights={k:z[k] for k in z.files}
            rename={'body.weight_ih_l0':'body_ih.weight','body.weight_hh_l0':'body_hh.weight','body.bias_ih_l0':'body_ih.bias','body.bias_hh_l0':'body_hh.bias'}
            weights={rename.get(k,k):v for k,v in weights.items()}
            payload=b'GNN1'+string(spec['kind'])+struct.pack('<i',len(weights))
            for k,v in weights.items():
                assert np.isfinite(v).all()
                payload+=string(k)+struct.pack('<i',v.ndim)+struct.pack('<'+'i'*v.ndim,*v.shape)+np.asarray(v,'<f4').tobytes()
        out=target/(name+'.bin');out.write_bytes(payload)
        specs[name]={'asset':out.name,'sha256':sha(out),'pc_asset_sha256':spec['sha256'],'kind':spec.get('kind',name),'bytes':len(payload)}
    data={'policy':manifest['policy'],'version':'PC_R19_R13_MAX_V1','fold':fold,'available_from':record['available_from'],'models':specs,'pc_features_sha256':sha(assets/'features.json')}
    (target/'manifest.json').write_text(json.dumps(data,indent=2)+'\n')
    catalog=root/'app/src/main/java/jp/gmk/mobile/domain/r13/R13Catalog.kt'
    catalog.parent.mkdir(parents=True,exist_ok=True)
    hashes=',\n'.join(f'        "{name}" to "{spec["sha256"]}"' for name,spec in specs.items())
    catalog.write_text('package jp.gmk.mobile.domain.r13\n\nobject R13Catalog {\n'+f'    const val AVAILABLE_FROM = {record["available_from"]}L\n    val hashes = linkedMapOf(\n{hashes}\n    )\n'+'}\n')
    reference=root/'tools/reference_pc_r13';reference.mkdir(parents=True,exist_ok=True)
    for p in (pc_root/'app/domain/r13').glob('*.py'):shutil.copy2(p,reference/p.name)
    shutil.copy2(assets/'features.json',reference/'features.json')
    shutil.copy2(assets/'manifest.json',reference/'original_manifest.json')
    return data

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('pc_root',type=Path);args=parser.parse_args()
    print(json.dumps(export(args.pc_root,Path(__file__).resolve().parents[1]),indent=2))

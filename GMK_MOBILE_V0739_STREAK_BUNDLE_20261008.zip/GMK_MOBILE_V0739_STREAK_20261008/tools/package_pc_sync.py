"""Package source and tests separately; create a report with explicit verification scope."""
from pathlib import Path
import argparse, difflib, hashlib, html, json, re, zipfile

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "release_evidence/v0735_pc_sync"
SOURCE = "GMK_MOBILE_V0735_AI_ENTRY70_SOURCE_20261007.zip"
TESTS = "GMK_V0735_TEST_DATA.zip"
WORKFLOW = "GMK_V0735_WORKFLOW.zip"
REPORT = "GMK_MOBILE_V0735_AI_ENTRY70_REPORT_20261007.html"
PROJECT = "GMK_MOBILE_V0735_AI_ENTRY70_20261007"
FIXTURE_ROOTS = ("tools/fixtures/", "tools/pc_r13_fixtures/", "tools/entry70_fixtures/")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def eligible(path, root):
    rel = path.relative_to(root)
    return path.is_file() and not any(x in rel.parts for x in
        ("__pycache__", ".git", ".gradle", "build")) and path.suffix not in (".pyc", ".class", ".tmp")

def change_record(original):
    items, diff = [], []
    for p in sorted(ROOT.rglob("*")):
        if not eligible(p, ROOT):
            continue
        name = p.relative_to(ROOT).as_posix()
        if name == "PACKAGE_MANIFEST_SHA256.txt" or name.startswith(FIXTURE_ROOTS) or name.startswith("release_evidence/v0735_pc_sync/"):
            continue
        old = original / name
        if old.is_file() and sha(old) == sha(p):
            continue
        items.append({"path": name, "change": "MODIFIED" if old.is_file() else "ADDED",
            "old_sha256": sha(old) if old.is_file() else None, "new_sha256": sha(p)})
        if p.suffix in (".java", ".kt", ".kts", ".py", ".yml", ".txt"):
            try:
                diff.extend(difflib.unified_diff(old.read_text().splitlines(True) if old.is_file() else [],
                    p.read_text().splitlines(True), fromfile="v0733/" + name, tofile="v0735/" + name))
            except UnicodeDecodeError:
                pass
    (EVIDENCE / "source_changes.json").write_text(json.dumps(items, ensure_ascii=False, indent=2) + "\n")
    (EVIDENCE / "source_changes.diff").write_text("".join(diff))

def scope_record():
    log = (EVIDENCE / "java_pc_parity.log").read_text()
    assert "PASS PC_R13_MOBILE_OFFLINE" in log
    errors = {k: float(v) for k, v in re.findall(r"(TCN|M1_TCN|M1_LSTM|M1_LINEAR|XGB)=([0-9.Ee+-]+)", log)}
    audit = json.loads((EVIDENCE / "source_data_audit.json").read_text())
    workflow = json.loads((EVIDENCE / "workflow_control_test.json").read_text())
    replay = json.loads((EVIDENCE / "entry70_monthly_replay.json").read_text())
    assert replay["status"] == "PASS" and replay["after"]["entry_floor_70_pass"]
    assert audit["status"] == workflow["status"] == "PASS"
    assert "PASS 167/167" in (EVIDENCE / "source_contract.log").read_text()
    scope = {"release": "0.7.35-ai-entry70-candidate", "version_code": 105, "date_jst": "2026-10-07",
        "java_production_code_compiled_and_executed": True,
        "pc_feature_frames": 24, "pc_feature_max_absolute_error": 0.0,
        "pc_inferred_action_cases": 1728, "pc_policy_action_cases": 2000,
        "pc_action_cases_matching": 3728, "model_max_absolute_errors": errors,
        "historical_monthly_java_replay": {"scheduled_slots": 13104, "pc_actions_matching": 13104,
            "model_evaluated_frames": 7494, "monthly_model_folds": 4,
            "feature_context_max_absolute_error": 0.0,
            "entry_percent": replay["after"]["entry_percent"], "monthly_entry_floor_70_pass": True,
            "minimum_month_entry_percent": min(m["after"]["entry_percent"] for m in replay["monthly"]),
            "settlement_minutes": 3, "scope": replay["replay_scope"]},
        "host_combined_p95_ms": float(re.search(r"host_combined_p95_ms=([0-9.]+)", log)[1]),
        "static_source_checks": 167, "source_data_integrity_checks": audit["checks"],
        "workflow_shell_checks_with_mock_signer": workflow["checks"],
        "kotlin_compilation_executed": False, "gradle_unit_tests_executed": False,
        "android_lint_executed": False, "apk_built": False, "device_test_executed": False,
        "github_actions_executed": False, "updated_live_win_rate_measured": False,
        "blocker": "No Android SDK, Gradle or Kotlin compiler; dependency network fetch timed out.",
        "default_expiry_profile": "THREE_MINUTE_PROJECTION_AFTER_PC_ACTION_SELECTION",
        "pc_standard_expiry_minutes": [3, 10, 15],
        "comparison_scope": "IDENTICAL_INPUTS_JAVA_FEATURES_MODELS_POLICY_NOT_FULL_ANDROID_LIVE_OUTPUT"}
    (EVIDENCE / "verification_scope.json").write_text(json.dumps(scope, ensure_ascii=False, indent=2) + "\n")
    return scope

def write_zip(path, members):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, data in members:
            info = zipfile.ZipInfo(name, (2026, 10, 7, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data, compresslevel=9)
    assert path.stat().st_size < 25_000_000, path.name
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None

def package(out, original):
    change_record(original)
    scope_record()
    files = [p for p in sorted(ROOT.rglob("*")) if eligible(p, ROOT) and p.name != "PACKAGE_MANIFEST_SHA256.txt"]
    manifest = ROOT / "PACKAGE_MANIFEST_SHA256.txt"
    manifest.write_text("".join(f"{sha(p)}  {p.relative_to(ROOT).as_posix()}\n" for p in files))
    source, fixtures = [], []
    for p in files + [manifest]:
        rel = p.relative_to(ROOT).as_posix()
        (fixtures if rel.startswith(FIXTURE_ROOTS) else source).append((PROJECT + "/" + rel, p.read_bytes()))
    write_zip(out / SOURCE, source)
    write_zip(out / TESTS, fixtures)
    write_zip(out / WORKFLOW, [(".github/workflows/build.yml", (ROOT / ".github/workflows/build.yml").read_bytes()),
        ("README_CURRENT_JA.txt", (ROOT / "README_CURRENT_JA.txt").read_bytes())])
    print(json.dumps({"source_members": len(source), "test_members": len(fixtures),
        "files": [{"name": name, "bytes": (out / name).stat().st_size, "sha256": sha(out / name)}
            for name in (SOURCE, TESTS, WORKFLOW)]}, indent=2))

def report(out):
    diagnostic = json.loads((EVIDENCE / "mobile_diagnostic_summary.json").read_text())
    scope = json.loads((EVIDENCE / "verification_scope.json").read_text())
    models = json.loads((ROOT / "app/src/main/assets/pc_r13/manifest.json").read_text())
    replay = json.loads((EVIDENCE / "entry70_monthly_replay.json").read_text())
    verification = out / "package_verification.json"
    verified = json.loads(verification.read_text()) if verification.exists() else None
    esc = html.escape
    table_rows = ""
    aggregate = diagnostic["aggregate_entry"]
    table_rows += f'<tr><td>保存履歴全体・判定時間合算</td><td>{aggregate["resolved"]}</td><td>{aggregate["wins"]}</td><td>{aggregate["losses"]}</td><td>{aggregate["win_rate_percent"]:.2f}%</td><td>時間別の全件内訳は未取得</td></tr>'
    for minute in (1, 3):
        d = diagnostic["exported_by_actual_minutes"][str(minute)]
        table_rows += f'<tr><td>直近30件中・{minute}分</td><td>{d["resolved"]}</td><td>{d["wins"]}</td><td>{d["losses"]}</td><td>{d["win_rate_percent"]:.2f}%</td><td>同値負け{d["draw_losses"]}件・待機1件は分母外</td></tr>'
    model_rows = "".join(f'<tr><td>{esc(k)}</td><td>{v:.9g}</td></tr>' for k, v in scope["model_max_absolute_errors"].items())
    file_rows = "".join(f'<tr><td><a href="{esc(name)}">{esc(name)}</a></td><td>{(out/name).stat().st_size:,}</td></tr>' for name in (SOURCE, TESTS, WORKFLOW))
    signatures = "\n".join(f"{sha(out/name)}  {name}" for name in (SOURCE, TESTS, WORKFLOW))
    monthly_rows = ""
    for m in replay["monthly"]:
        b, a = m["before"], m["after"]
        label = m["month"] + ("（18日まで）" if m["month"] == "2026-08" else "")
        monthly_rows += f'<tr><td>{label}</td><td>{a["entries"]:,}/{a["scheduled_slots"]:,}</td><td>{a["entry_percent"]:.2f}%</td><td>{b["win_percent"]:.2f}% → {a["win_percent"]:.2f}%</td><td>{b["max_consecutive_non_wins"]} → {a["max_consecutive_non_wins"]}</td></tr>'
    b, a = replay["before"], replay["after"]
    monthly_rows += f'<tr><th>全体</th><th>{a["entries"]:,}/{a["scheduled_slots"]:,}</th><th>{a["entry_percent"]:.2f}%</th><th>{b["win_percent"]:.2f}% → {a["win_percent"]:.2f}%</th><th>{b["max_consecutive_non_wins"]} → {a["max_consecutive_non_wins"]}</th></tr>'
    package_text = (f'配布ZIPを使ったワークフロー構成確認も{verified["workflow_checks"]}項目合格。両ZIP展開後の全ファイルSHAとZIPの破損検査も合格。' if verified else '配布ZIPの最終再展開確認は未完了。')
    if verified and verified.get("actual_build_gates_executed"):
        package_text += '配布ZIPからSHA・ソース・Java・月別再生を実行し、Gradle成功／失敗の模擬分岐と改ざん停止も確認しました。Androidビルドは未実行です。'
    raw = json.dumps({"verification_scope": scope, "entry70_monthly_replay": replay, "diagnostic_summary": diagnostic, "portable_models": models,
        "package_verification": verified}, ensure_ascii=False, indent=2)
    readme = (ROOT / "README_CURRENT_JA.txt").read_text()
    page = f'''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>GMKスマホAI組み込み・エントリー率70％検証</title><style>
body{{font-family:system-ui,"Noto Sans JP",sans-serif;background:#f5f7fb;color:#172332;line-height:1.75;margin:0}}main{{max-width:960px;margin:auto;padding:30px 18px 70px}}h1{{font-size:clamp(24px,5vw,36px);line-height:1.45}}h2{{font-size:21px;margin-top:34px}}p{{margin:12px 0}}.lead{{font-size:18px}}.note{{background:#fff0d5;border-left:5px solid #c47b15;padding:15px 18px}}.ok{{background:#e8f3ee;border-left:5px solid #287757;padding:15px 18px}}.scroll{{overflow:auto}}table{{width:100%;border-collapse:collapse;background:white;font-size:14px}}th,td{{padding:11px 13px;border:1px solid #dbe1ea;text-align:left;vertical-align:top}}th{{background:#eaf0f7}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#edf1f6;padding:16px;font-size:12px;line-height:1.65}}a{{color:#1c5c9d;overflow-wrap:anywhere}}li{{margin:6px 0}}summary{{cursor:pointer;font-weight:600}}small{{color:#546779}}@media print{{body{{background:white}}main{{padding:0}}details{{display:block}}a{{color:inherit}}table{{font-size:11px}}}}
</style></head><body><main>
<small>2026-10-07 / GMK MOBILE 0.7.35-ai-entry70-candidate / versionCode 105</small>
<h1>スマホAI組み込みと、エントリー率70％条件</h1>
<p class="lead">PCのR13をスマホ用コードへ組み込み、AI補正でENTRY件数を減らさない制約を追加しました。3分再生で各月70％以上を確認しています。</p>
<p class="note"><strong>APKの生成と実機確認は未完了です。</strong>この配布物はソース・検証データ・ビルド手順です。Android SDK、Gradle、Kotlinコンパイラがなく、依存物取得先への通信も完了できませんでした。Android上での動作合格や、更新後の勝率向上を確認したものではありません。</p>
<h2>3分判定・70％条件の再生結果</h2>
<div class="scroll"><table><thead><tr><th>月</th><th>ENTRY / 全予定枠</th><th>エントリー率</th><th>勝率：補正前 → 後</th><th>最大連敗：前 → 後</th></tr></thead><tbody>{monthly_rows}</tbody></table></div>
<p>対象は2026年5月1日〜8月18日、平日09:00〜22:55の5分ごとの全13,104枠です。ENTRY9,431件、SKIP3,673件で、補正前後の件数は同じです。判定不明9件もエントリー率の分子・分母に残しています。勝率は確定ENTRY9,422件に対する比率で、同値は負けです。</p>
<p>補正前5,483勝3,939敗から、補正後5,507勝3,915敗へ、24勝・約0.25ポイント改善しました。不明9件をすべて非勝ちとして扱う保守的な勝率は58.14％ → 58.39％です。最大連敗は同値・不明を非勝ちとして数え、SKIPで連続を切りません。8月だけの最大連敗は5 → 8へ増えています。</p>
<p class="ok"><strong>実際のスマホ用Java特徴量・モデル・選択処理で13,104枠を新しく再生し、PCの保存判定と全件一致しました。</strong>5〜8月それぞれ、その月の固定モデルを使用し、8月モデルを過去月へ適用していません。モデル補正対象は7,494枠。元のR9のENTRY判定とRULE365予測は保存済みの月別入力を使用しています。Android全体や実機の再生ではありません。</p>
<p>AIからENTRY→SKIP、SKIP→ENTRY、スキャンID・ENTRY時刻などの変更が出た場合は、元の判定一式へ戻します。全13,104枠でENTRY判定の変更を注入し、この制約が変更を検出することも確認しました。70％は全体だけでなく各月をビルド時の採用条件として検査します。</p>
<p>今後の実運用でも必ず70％になるという保証ではありません。AIは元のENTRY件数を維持しますが、相場データの欠損や元ルールのSKIPは残ります。今回の評価はこの2026年5〜8月のデータで、2024・2025年まで検証した結果ではありません。</p>
<h2>SKIPが負けになっていたのか</h2>
<p><strong>勝率計算には入っていません。</strong>診断のENTRY勝敗と総勝敗はともに253勝295敗で、SKIP参考結果の確定件数は0でした。対応するv0.7.33ソースでもSKIPを勝率から除外しています。</p>
<p>ただし、履歴一覧と直近履歴では、SKIPの参考結果が通常ENTRYのWIN/LOSEと同じ画像・色になる分岐がありました。参考結果が通常の負けに見える表示を修正しました。</p>
<h2>低勝率について、いま分かる数字</h2>
<div class="scroll"><table><thead><tr><th>集計範囲</th><th>確定ENTRY</th><th>勝ち</th><th>負け</th><th>勝率</th><th>補足</th></tr></thead><tbody>{table_rows}</tbody></table></div>
<p>保存履歴は603件ですが、旧診断に含まれる明細は直近30件だけです。全548確定ENTRYの3分だけの勝率は復元できません。直近3分の5件・60%は長期評価には少なすぎます。1分AUTOもONで、直近確定28件中23件は1分でした。</p>
<p>旧画面は1分とそれ以外を分けていますが、それ以外の3分・10分・15分はまとめていました。新版は実際のENTRY時刻と判定時刻から各時間を分けます。同値を負けとする仕様は維持しています。</p>
<p>FXの約60〜70秒の取得遅れは、対応ソースでは「対象分のOPENが配信されるまで待った時間」です。その値だけで判定時刻がずれたバグとは断定できません。Yahoo/bitbankの参考価格と、実際の業者の約定価格は同じとは限りません。</p>
<h2>PCに合わせた部分</h2>
<p>最新PC_R27の有効設定は<strong>PC_R19_R13_MAX_V1</strong> / LONG_XGB_M1_C_PLUS_NON_NATIVE_OPEN36_M10です。native S/A/B保護、Cの補正、補完ENTRYのR11→R12→R13、36行動の選択を移植しました。5モデルの重みは2026年8月の固定モデルから変換し、再学習・新しい研究用SKIP条件の追加は行っていません。</p>
<p>確定したT-10レートの安全確認、入力差や締切の確認、処理失敗時の復帰を入れています。モデル用履歴は保存・採用されたスキャンだけ反映します。従来ルール、1分ルール、チャート、通貨強弱、カットインなど11ファイルは元ソースとのSHA一致を確認しました。</p>
<h2>3分判定の指定</h2>
<div class="scroll"><table><thead><tr><th>予測画面の設定</th><th>方向・通貨</th><th>最終判定時間</th></tr></thead><tbody>
<tr><td>3分固定 ON（初期値）</td><td>PCの行動選択</td><td>ENTRYから3分後へ固定</td></tr>
<tr><td>3分固定 OFF</td><td>PCの行動選択</td><td>PC標準の3・10・15分を使用</td></tr></tbody></table></div>
<p>ONではPC標準で選ばれた判定時間を3分へ変更します。そのため未変更のPC標準と判定時間まで同じにはなりません。両モードと旧版の成績は分けて集計し、旧履歴も残します。1分AUTOの既存設定は維持し、1分の成績は別表示です。</p>
<p>起動直後の履歴準備や、補完TCNに必要な最大75分の連続スキャン履歴が不足する間は、従来ルールへ復帰します。診断のpc_r13.statusと、履歴の「PC補正評価済／補正待機」で区別できます。</p>
<h2>確認済みと、未確認の境界</h2>
<p class="ok"><strong>部品比較でもJavaでPC判定3,728件すべて一致。</strong>モデル計算から選んだ1,728件、政策条件2,000件を比較しました。特徴量24組の最大絶対差は0です。ソース構造167項目、モデル・接続・保存などの確認{scope["source_data_integrity_checks"]}項目も合格しました。</p>
<div class="scroll"><table><thead><tr><th>モデル</th><th>PC計算との最大絶対差</th></tr></thead><tbody>{model_rows}</tbody></table></div>
<p>入力には実PC検証データ12組、追加生成12組、欠損・NaN・volume異常の特徴量条件を含みます。ホストの5モデル合計処理p95は{scope["host_combined_p95_ms"]:.2f}msでした。スマホでの処理速度ではありません。{package_text}</p>
<p><strong>未確認：</strong>Kotlin/Androidコンパイル、Gradle単体試験、Android Lint、APK署名の実検証、画面表示、端末のT-10動作、更新後の実運用勝率。ワークフローの署名分岐確認は模擬ツールによる構成試験です。</p>
<p>同じ入力でのモデル・特徴量・選択の比較であり、スマホとPCのライブ出力の完全一致は未確認です。価格配信、入力履歴、欠損、途中足、経済指標カレンダーなどの運用条件には差があります。診断JSONの版に対応するソースを使っており、端末APKのバイト一致までは確認できません。</p>
<h2>配布ファイルとビルド</h2>
<div class="scroll"><table><thead><tr><th>ファイル</th><th>バイト数</th></tr></thead><tbody>{file_rows}</tbody></table></div>
<p>本体ZIPと検証データZIPを両方、同じリポジトリ直下へアップロードします。WORKFLOW.zipを展開して得たbuild.yml（別添build.ymlも同じ内容）を、既定ブランチの.github/workflows/build.ymlへ置きます。Actionsの「Build GMK Mobile v0.7.35」から実行すると、SHA・コンパイル・単体試験・Lintに加え、APK内モデル11ファイル、署名、版と対応SDKを検査してAPKを出します。詳細は本体のREADME_CURRENT_JA.txtにあります。</p>
<p>既存スマホの履歴を残して更新するには、現在のAPKと同じ署名鍵を使います。未設定時のephemeral-debug署名では上書きできるとは限りません。更新に失敗しても、履歴を保存せずに既存アプリをアンインストールしないでください。鍵・パスワードは既存のSecrets管理を使い、チャットには貼らないでください。</p>
<details><summary>ビルド手順・制約の全文</summary><pre>{esc(readme)}</pre></details>
<details><summary>配布ZIPのSHA256</summary><pre>{esc(signatures)}</pre></details>
<details><summary>機械可読の検証結果・入力根拠</summary><pre>{esc(raw)}</pre></details>
<p><small>Android署名・ビルド条件の公式資料：<a href="https://developer.android.com/studio/publish/app-signing">アプリの署名</a> / <a href="https://developer.android.com/build/releases/agp-8-7-0-release-notes">AGP 8.7 の互換性</a>。旧版に付属した監査書・勝率CSVは過去資料として保持し、新版の動作合格や実成績とは区別しています。</small></p>
</main></body></html>'''
    (out / REPORT).write_text(page, encoding="utf-8")
    print(json.dumps({"report": REPORT, "bytes": (out / REPORT).stat().st_size,
        "package_verified": bool(verified)}, ensure_ascii=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--original", type=Path)
    parser.add_argument("--report-only", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if not args.report_only:
        if args.original is None or not (args.original / "app/build.gradle.kts").is_file():
            parser.error("--original must be the unmodified v0.7.33 project")
        package(args.output, args.original)
    report(args.output)

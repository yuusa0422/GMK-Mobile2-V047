"""APK bundling requires a newly verified Android build after source recovery."""
raise SystemExit("Source recovery has no APK. Run Android build and signing checks before creating an APK bundle.")

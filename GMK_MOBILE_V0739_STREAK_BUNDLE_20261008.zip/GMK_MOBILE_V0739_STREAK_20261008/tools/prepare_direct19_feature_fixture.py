"""Build observed-price inputs for the actual Kotlin feature builder.

The binary is an ephemeral replay fixture, not an Android asset. Reference
features come from the locked research arrays, not this mobile implementation.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path
import numpy as np

SYMBOLS = 'USDJPY EURJPY GBPJPY AUDJPY EURUSD GBPUSD NZDJPY BTCJPY AUDUSD BTCUSD USDCAD CADJPY USDCHF CHFJPY ETHUSD EURAUD EURGBP GBPAUD NZDUSD'.split()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('research', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    frames = np.load(args.research / 'frames.npz')
    tree = np.load(args.research / 'tree.npy', mmap_mode='r').reshape(-1, 6, 3, 149)
    coverage = np.load(args.research / 'coverage_diagnostics.npz')['valid']
    prices = np.load(args.research / 'observed_prices.npz')
    cases = [('2026-07-15', 14), ('2026-08-12', 14), ('2026-09-15', 14), ('2026-10-05', 14)]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    records = []
    with args.output.open('wb') as out:
        out.write(struct.pack('>i', len(cases)))
        for date, hour in cases:
            indexes = np.flatnonzero((frames['dates'] == date) & (frames['hour'] == hour) & (frames['minute'] == 0))
            assert len(indexes) == 1, (date, indexes)
            index = int(indexes[0]); boundary = int(frames['boundaries'][index])
            out.write(struct.pack('>qi', boundary, len(SYMBOLS)))
            counts = {}
            for symbol in SYMBOLS:
                times = prices['times_' + symbol]
                bars = prices['bars_' + symbol]
                end = int(np.searchsorted(times, boundary - 120, side='right'))
                begin = max(0, end - 6000)
                encoded = symbol.encode('utf-8')
                out.write(struct.pack('>H', len(encoded)) + encoded)
                out.write(struct.pack('>i', end - begin))
                for t, bar in zip(times[begin:end], bars[begin:end]):
                    out.write(struct.pack('>q5d', int(t)*1000, *map(float, bar[:5])))
                counts[symbol] = end - begin
            expected = np.concatenate((tree[index, :4, 0, :146], np.broadcast_to(coverage[index].astype('float32'), (4, 19))), axis=1)
            assert expected.shape == (4, 165)
            out.write(expected.astype('>f4').tobytes())
            records.append(dict(date=date, hour=hour, boundary=boundary, frame_index=index, counts=counts))
    manifest = dict(cases=records, sha256=hashlib.sha256(args.output.read_bytes()).hexdigest(),
        feature_count=165, traded_symbols=SYMBOLS[:4], coverage_symbols=SYMBOLS,
        reference='Locked PC_R13 common-price research features and observed M1 prices')
    args.manifest.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(dict(cases=len(cases), bytes=args.output.stat().st_size, sha256=manifest['sha256'])))

if __name__ == '__main__':
    main()

"""Lossless HGB export; no training or policy changes during model conversion."""
from pathlib import Path
import hashlib,json,struct,sys
import numpy as np
import joblib

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def export(model,path):
    assert model.n_iter_==80 and model.n_trees_per_iteration_==3 and model.n_features_in_==165
    assert np.array_equal(model.classes_,[0,1,2])
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('wb') as f:
        f.write(struct.pack('>qii',0x474D4B4847423131,165,3))
        f.write(np.asarray(model._baseline_prediction,dtype='>f8').tobytes());f.write(struct.pack('>i',240))
        for iteration in model._predictors:
            for cls,tree in enumerate(iteration):
                nodes=tree.nodes;assert not nodes['is_categorical'].any()
                f.write(struct.pack('>ii',cls,len(nodes)))
                for node in nodes:
                    f.write(struct.pack('>iddii??',int(node['feature_idx']),float(node['num_threshold']),float(node['value']),int(node['left']),int(node['right']),bool(node['missing_go_to_left']),bool(node['is_leaf'])))
    return sha(path)

def main():
    study=Path(sys.argv[1]).resolve();project=Path(__file__).resolve().parents[1]
    assets=project/'app/src/main/assets/direct19';assets.mkdir(exist_ok=True)
    hashes={}
    for h in (3,5):
        p=study/'FINAL_MODELS'/f'HGB15_TRAIN20__{h}min.joblib';model=joblib.load(p)
        hashes[f'hgb_{h}m.bin']=export(model,assets/f'hgb_{h}m.bin')
    record=json.loads((study/'DAILY_PREDICTIONS/2026-10-06.json').read_text())
    models=[v for v in record['models'] if v['spec']=='HGB15_TRAIN20']
    available=int(__import__('datetime').datetime.fromisoformat('2026-10-08T00:00:00+09:00').timestamp())
    manifest={'policy':'HGB15_TRAIN20__NATIVE_C_OPEN4_BOTH_M10','feature_count':165,
        'classes':['DOWN','DRAW','UP'],'horizon_minutes':[3,5],'available_from_epoch':available,
        'trained_for_day':'2026-10-06','latest_training_label_epoch':max(v['latest_training_label'] for v in models),
        'training_window_business_days':20,'mobile_training':'Bundled frozen latest model, not on-device daily fitting',
        'historical_daily_mean_monthly_win_rate':51.930418071984874,
        'historical_daily_pooled_win_rate':51.70217001791758,
        'historical_daily_minimum_monthly_entry_rate':72.68041237113403,
        'frozen_mobile_future_win_rate_measured':False,'hashes':hashes,
        'study_protocol_sha256':sha(study/'PROTOCOL.json'),'study_audit_sha256':sha(study/'INDEPENDENT_AUDIT.json')}
    (assets/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    rows='\n'.join(f'        "{name}" to "{value}"'+(',' if i<len(hashes)-1 else '') for i,(name,value) in enumerate(hashes.items()))
    path=project/'app/src/main/java/jp/gmk/mobile/domain/direct19/Direct19Catalog.kt'
    path.write_text('package jp.gmk.mobile.domain.direct19\n\nobject Direct19Catalog {\n    const val AVAILABLE_FROM = '+str(available)+'L\n    val hashes = mapOf(\n'+rows+'\n    )\n}\n')
    print(json.dumps(manifest,ensure_ascii=False))

if __name__=='__main__':main()

"""Release gate: independently settle the saved Java replay at exactly three minutes.

Standard library only. Requires the historical ledger in the accompanying test ZIP.
This checks the historical acceptance floor, not a guaranteed live entry frequency.
"""
from pathlib import Path
import argparse, csv, hashlib, json, math
from datetime import datetime, timedelta, timezone

ROOT=Path(__file__).resolve().parents[1]
SYMBOLS=['USDJPY','EURJPY','GBPJPY','AUDJPY','NZDJPY','BTCJPY']
JST=timezone(timedelta(hours=9))

def scheduled(b):
    t=datetime.fromtimestamp(b,JST)
    return b%300==0 and t.weekday()<5 and 9<=t.hour<=22

def outcome(row,action):
    symbol=SYMBOLS[action//6];y=int(row['y3_'+symbol])
    if y<0:return 'UNKNOWN'
    if y==1:return 'DRAW'
    return 'WIN' if y==(2 if action%2 else 0) else 'LOSE'

def metrics(rows,key):
    labels=[outcome(r,int(r[key])) for r in rows if r['entry']=='1']
    counts={label:labels.count(label) for label in ('WIN','LOSE','DRAW','UNKNOWN')}
    run=maximum=0
    for label in labels:
        run=0 if label=='WIN' else run+1;maximum=max(maximum,run)
    resolved=len(labels)-counts['UNKNOWN']
    return dict(scheduled_slots=len(rows),entries=len(labels),skips=len(rows)-len(labels),
        entry_percent=100*len(labels)/len(rows),wins=counts['WIN'],losses=counts['LOSE']+counts['DRAW'],
        draw_losses=counts['DRAW'],unknown=counts['UNKNOWN'],resolved_entries=resolved,
        win_percent=100*counts['WIN']/resolved if resolved else None,
        conservative_win_percent=100*counts['WIN']/len(labels) if labels else None,
        max_consecutive_non_wins=maximum,
        entry_floor_70_pass=(len(rows)>0 and len(labels)*100>=len(rows)*70))

def check(fixtures):
    hashes=json.loads((fixtures/'SHA256.json').read_text())
    for name,h in hashes.items():assert hashlib.sha256((fixtures/name).read_bytes()).hexdigest()==h,name
    with (fixtures/'ledger.csv').open(newline='') as f:rows=list(csv.DictReader(f))
    assert len(rows)==13104 and rows
    boundaries=[int(r['boundary']) for r in rows]
    assert boundaries==sorted(set(boundaries))
    expected=[b for b in range(boundaries[0],boundaries[-1]+1,300) if scheduled(b)]
    assert boundaries==expected,'missing or extra scheduled slot'
    protected=changed=fixed_changed=guard_faults=price_checks=0
    for row in rows:
        boundary=int(row['boundary']);assert scheduled(boundary)
        assert datetime.fromtimestamp(boundary,JST).strftime('%Y-%m')==row['month']
        base=int(row['base_action']);after=int(row['java_action']);pc=int(row['expected_action'])
        assert 0<=base<36 and 0<=after<36 and after==pc,'PC action mismatch'
        assert row['entry'] in ('0','1') and row['guard_fault_recovered']=='1'
        guard_faults+=1
        if row['entry']=='0':assert after==base,'SKIP action unexpectedly changed'
        else:
            assert row['safe_'+SYMBOLS[base//6]]=='1' and row['safe_'+SYMBOLS[after//6]]=='1','unsafe action'
            if row['native']=='1' and row['grade'] in ('S','A','B'):
                assert after==base,'protected native changed';protected+=1
            if after!=base:changed+=1
            if after//6!=base//6 or after%2!=base%2:fixed_changed+=1
        for symbol in SYMBOLS:
            y=int(row['y3_'+symbol]);assert y in (-1,0,1,2)
            if y>=0:
                entry=float(row['entry_price_'+symbol]);judge=float(row['judge3_price_'+symbol])
                assert math.isfinite(entry) and entry>0 and math.isfinite(judge) and judge>0
                assert y==(0 if judge<entry else 2 if judge>entry else 1),'price/label discrepancy'
                price_checks+=1
    months=[]
    for month in sorted({r['month'] for r in rows}):
        subset=[r for r in rows if r['month']==month]
        before=metrics(subset,'base_action');after=metrics(subset,'java_action')
        assert before['entries']==after['entries'] and before['entry_floor_70_pass'] and after['entry_floor_70_pass'],month+' below 70%'
        months.append({'month':month,'before':before,'after':after})
    before=metrics(rows,'base_action');after=metrics(rows,'java_action')
    assert before['entry_floor_70_pass'] and after['entry_floor_70_pass']
    provenance=json.loads((fixtures/'provenance.json').read_text())
    assert len(provenance['folds'])==4
    production=json.loads((ROOT/'app/src/main/assets/pc_r13/manifest.json').read_text())
    for name,spec in production['models'].items():
        assert spec['sha256']==provenance['folds']['2026-08']['models'][name]['sha256'],'production/replay August model mismatch'
    for row in rows:assert int(row['boundary'])-10>=provenance['folds'][row['month']]['available_from']
    return {'status':'PASS','minimum_entry_percent':70,'settlement_minutes':3,
        'period_jst':['2026-05-01','2026-08-18'],'entry_denominator':'All scheduled weekday slots 09:00-22:55 JST, every 5 minutes; SKIP/UNKNOWN remain in denominator',
        'win_denominator':'Resolved ENTRY only; DRAW is loss; UNKNOWN excluded',
        'max_loss_definition':'Consecutive ENTRY non-wins in time order, DRAW and UNKNOWN count as non-wins; SKIP does not reset',
        'replay_scope':provenance['replay_scope'],'android_end_to_end_replayed':False,
        'live_entry_floor_guaranteed':False,'before':before,'after':after,'monthly':months,
        'action_changes':changed,'three_minute_symbol_direction_changes':fixed_changed,
        'native_s_a_b_protected':protected,'entry_mask_faults_recovered':guard_faults,
        'independent_price_label_checks':price_checks,
        'win_change_count':after['wins']-before['wins'],
        'win_change_percentage_points':after['win_percent']-before['win_percent'],
        'provenance_sha256':hashes['provenance.json'],'ledger_sha256':hashes['ledger.csv']}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--fixtures',type=Path,default=ROOT/'tools/entry70_fixtures');a.add_argument('--output',type=Path);args=a.parse_args()
    result=check(args.fixtures)
    if args.output:args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

"""Package the complete Android build source, without old research ledgers.

The existing GMK_V0735_TEST_DATA.zip supplies the unchanged external replay
fixtures. Those inputs are preserved separately rather than copied again.
"""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PREFIX = 'GMK_MOBILE_V0738_FULL_AUDIT_20261008'
INPUTS = ('app/src', 'app/build.gradle.kts', 'build.gradle.kts',
    'settings.gradle.kts', 'gradle.properties', '.github/workflows/build.yml',
    'tools', 'README_CURRENT_JA.txt', 'OFFICIAL_WIN_GATE_OOS_202607_0818.csv',
    'DIRECT19_PORTABLE_REPLAY_AUDIT.json', 'DIRECT19_FEATURE_FIXTURE_MANIFEST.json',
    'DIRECT19_KOTLIN_FEATURE_AUDIT.json', 'RELEASE_VERIFICATION.json',
    'release_evidence/v0736_direct19', 'release_evidence/v0738_full_audit',
    'MOBILE_DEEP_AUDIT_CHANGES.json', 'MOBILE_DEEP_AUDIT_REPORT.html',
    'DIRECT19_BUNDLED_FIXTURE_MANIFEST.json', 'release_evidence/v0737_deep_audit',
    'RULE_AI_FUNCTIONAL_AUDIT.json', 'RULE_AI_GUARD_AUDIT.json')
EXCLUDED = {'__pycache__', 'fixtures', 'pc_r13_fixtures', 'entry70_fixtures'}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    paths = set()
    for name in INPUTS:
        path = ROOT / name
        if not path.exists():
            raise SystemExit('Missing release input: ' + name)
        for item in (path.rglob('*') if path.is_dir() else [path]):
            rel = item.relative_to(ROOT)
            if item.is_file() and not (set(rel.parts) & EXCLUDED):
                paths.add(item)
    paths = sorted(paths)
    manifest = ROOT / 'PACKAGE_MANIFEST_SHA256.txt'
    manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n' for p in paths))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in paths + [manifest]:
            z.write(p, PREFIX + '/' + p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(args.output) as z:
        assert z.testzip() is None
        for p in paths + [manifest]:
            assert z.read(PREFIX + '/' + p.relative_to(ROOT).as_posix()) == p.read_bytes()
    print('Complete Android source files:',len(paths), 'ZIP bytes:',args.output.stat().st_size)

if __name__ == '__main__':
    main()

"""Compile and execute the production Java port. Does not claim an Android APK build."""
from pathlib import Path
import subprocess,tempfile,shutil,json,hashlib
root=Path(__file__).resolve().parents[1]
fixtures=root/'tools/pc_r13_fixtures'
for name,value in json.loads((fixtures/'SHA256.json').read_text()).items():
    assert hashlib.sha256((fixtures/name).read_bytes()).hexdigest()==value,name
sources=list((root/'app/src/main/java/jp/gmk/mobile/domain/r13').glob('*.java'))
sources += [root/'app/src/main/java/jp/gmk/mobile/domain/OutcomeStatistics.java',root/'tools/R13OfflineTest.java']
compiler=['javac'] if shutil.which('javac') else ['java','--module','jdk.compiler/com.sun.tools.javac.Main']
with tempfile.TemporaryDirectory(prefix='gmk-r13-jvm-') as td:
    subprocess.run(compiler+['-d',td]+[str(p) for p in sources],check=True)
    subprocess.run(['java','-cp',td,'R13OfflineTest',str(root/'app/src/main/assets/pc_r13'),str(fixtures)],check=True)

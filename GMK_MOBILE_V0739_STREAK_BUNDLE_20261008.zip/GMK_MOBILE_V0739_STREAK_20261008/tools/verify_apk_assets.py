"""Verify packaged AI assets against the audited source; not an APK signature test."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile


def verify(apk, project):
    source = project / "app/src/main/assets"
    expected = {}
    pc_manifest = None
    for namespace in ("pc_r13", "horizon_policy"):
        manifest_path = source / namespace / "manifest.json"
        manifest = json.loads(manifest_path.read_text())
        if namespace == "pc_r13":
            pc_manifest = manifest
        models = manifest["models"]
        models = models.values() if isinstance(models, dict) else models
        expected[f"assets/{namespace}/manifest.json"] = manifest_path.read_bytes()
        for model in models:
            asset = model["asset"]
            if Path(asset).name != asset or asset in ("", ".", ".."):
                raise ValueError("invalid model asset name")
            content = (source / namespace / asset).read_bytes()
            digest = hashlib.sha256(content).hexdigest()
            if digest != model["sha256"] or len(content) != model["bytes"]:
                raise ValueError(f"source model integrity failure: {namespace}/{asset}")
            name = f"assets/{namespace}/{asset}"
            if name in expected:
                raise ValueError(f"duplicate source model: {name}")
            expected[name] = content
    direct_source = source / "direct19"
    direct_manifest = json.loads((direct_source / "manifest.json").read_text())
    if direct_manifest["feature_count"] != 165 or direct_manifest["horizon_minutes"] != [3, 5]:
        raise ValueError("invalid Direct19 input/horizon contract")
    expected["assets/direct19/manifest.json"] = (direct_source / "manifest.json").read_bytes()
    for asset, digest in direct_manifest["hashes"].items():
        if asset not in ("hgb_3m.bin", "hgb_5m.bin"):
            raise ValueError("unexpected Direct19 model")
        content = (direct_source / asset).read_bytes()
        if hashlib.sha256(content).hexdigest() != digest:
            raise ValueError(f"Direct19 model integrity failure: {asset}")
        expected[f"assets/direct19/{asset}"] = content
    if set(direct_manifest["hashes"]) != {"hgb_3m.bin", "hgb_5m.bin"}:
        raise ValueError("missing Direct19 model")
    records = []
    with zipfile.ZipFile(apk) as packaged:
        names = packaged.namelist()
        if len(names) != len(set(names)):
            raise ValueError("duplicate APK ZIP members")
        actual = {n for n in names if n.startswith(("assets/pc_r13/", "assets/horizon_policy/", "assets/direct19/")) and not n.endswith("/")}
        if actual != set(expected):
            raise ValueError(f"model asset set mismatch: missing={sorted(set(expected)-actual)}, extra={sorted(actual-set(expected))}")
        for name, content in sorted(expected.items()):
            actual_content = packaged.read(name)
            if actual_content != content:
                raise ValueError(f"packaged model/manifest differs from source: {name}")
            records.append({"asset": name, "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()})
    return {"status": "PASS", "scope": "PACKAGED_MODEL_BYTES_AND_MANIFESTS", "policy": direct_manifest["policy"], "trained_for_day": direct_manifest["trained_for_day"], "outside_session_policy": pc_manifest["version"], "assets_verified": len(records), "results": records}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.apk, Path(__file__).resolve().parents[1])
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as error:
        print(f"ERROR: APK model verification failed: {error}", file=sys.stderr)
        raise SystemExit(1)
    print(json.dumps(result, ensure_ascii=False, indent=2))

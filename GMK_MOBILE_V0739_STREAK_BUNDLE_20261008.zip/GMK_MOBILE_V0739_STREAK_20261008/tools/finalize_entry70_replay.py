"""Merge the full Java output with the independently labelled source ledger."""
from pathlib import Path
import argparse,csv,hashlib,json,re

def main():
    a=argparse.ArgumentParser();a.add_argument('--full',type=Path,required=True);a.add_argument('--log',type=Path,required=True)
    a.add_argument('--fixtures',type=Path,default=Path(__file__).resolve().parent/'entry70_fixtures');p=a.parse_args();p.fixtures.mkdir(parents=True,exist_ok=True)
    match=re.search(r'PASS ENTRY70_FULL_REPLAY frames=(\d+) actions_matching=(\d+) evaluated=(\d+) changed=(\d+) entries=(\d+) context_max_absolute_error=([\d.Ee+-]+) seconds=([\d.Ee+-]+)',p.log.read_text())
    if not match:raise SystemExit('Full Java replay must pass first')
    frames,matching,evaluated,changed,entries=map(int,match.group(1,2,3,4,5));assert frames==matching
    with (p.full/'java_actions.csv').open(newline='') as f:actions={r['boundary']:r for r in csv.DictReader(f)}
    with (p.full/'seed_ledger.csv').open(newline='') as f:rows=list(csv.DictReader(f));fields=list(rows[0])+['java_action','guard_fault_recovered']
    assert len(rows)==len(actions)==frames
    with (p.fixtures/'ledger.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in rows:
            v=actions[r['boundary']];assert v['pc_expected_action']==r['expected_action'] and v['entry']==r['entry']
            assert v['java_action']==r['expected_action'] and v['guard_fault_recovered']=='1'
            r.update(java_action=v['java_action'],guard_fault_recovered=v['guard_fault_recovered']);w.writerow(r)
    pro=json.loads((p.full/'provenance.json').read_text())
    pro['fresh_java_replay']={'status':'PASS','frames':frames,'pc_actions_matching':matching,'inferred_frames':evaluated,
        'context_max_absolute_error':float(match.group(6)),'elapsed_host_seconds':float(match.group(7)),'phone_runtime_measured':False}
    (p.fixtures/'provenance.json').write_text(json.dumps(pro,ensure_ascii=False,indent=2)+'\n')
    hashes={q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(p.fixtures.iterdir()) if q.name!='SHA256.json'}
    (p.fixtures/'SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print(json.dumps({'status':'FINALIZED','frames':frames,'entries':entries,'changed':changed}))

if __name__=='__main__':main()

"""Restore source assets from the bundled, SHA-verified unsigned APK."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT = Path(__file__).resolve().parents[1]

def main():
    manifest_path = ROOT / 'BUNDLED_ASSETS.json'
    if not manifest_path.exists():
        print('Full source assets already supplied; no bundle restoration required')
        return
    manifest = json.loads(manifest_path.read_text())
    apk = ROOT / manifest['apk_filename']
    assert apk.parent == ROOT and apk.is_file()
    assert hashlib.sha256(apk.read_bytes()).hexdigest() == manifest['apk_sha256']
    with zipfile.ZipFile(apk) as z:
        for entry in manifest['assets']:
            rel = PurePosixPath(entry['source_path'])
            assert not rel.is_absolute() and '..' not in rel.parts
            assert rel.parts[:4] in (('app', 'src', 'main', 'assets'), ('app', 'src', 'main', 'res'))
            content = z.read(entry['apk_member'])
            assert len(content) == entry['bytes']
            assert hashlib.sha256(content).hexdigest() == entry['sha256']
            target = ROOT.joinpath(*rel.parts)
            if target.exists():
                assert target.read_bytes() == content, 'Existing source asset differs: ' + str(rel)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
    print('Bundled source assets restored and SHA-verified:', len(manifest['assets']))

if __name__ == '__main__':
    main()

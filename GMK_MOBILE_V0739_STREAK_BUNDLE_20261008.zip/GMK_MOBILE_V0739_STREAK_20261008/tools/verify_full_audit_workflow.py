"""Execute the exact standalone workflow's preparation and unsigned verification.

Local QA needs PyYAML; the GitHub workflow itself uses the standard library.
Never sends data to GitHub and never uses a production signing key.
"""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import warnings
import zipfile
import yaml

ROOT=Path(__file__).resolve().parents[1]

def run(script,directory,env,ok=True):
    result=subprocess.run(['bash','--noprofile','--norc'],input=script,text=True,
                          capture_output=True,cwd=directory,env=env,timeout=60)
    assert (result.returncode==0)==ok,(result.returncode,result.stdout,result.stderr)
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--workflow',type=Path,required=True)
    parser.add_argument('--bundle',type=Path,required=True)
    parser.add_argument('--fixtures',type=Path,required=True)
    parser.add_argument('--sdk',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=ROOT/'release_evidence/v0738_full_audit/WORKFLOW_VALIDATION.json')
    args=parser.parse_args()
    assert args.workflow.read_bytes()==(ROOT/'.github/workflows/build.yml').read_bytes()
    doc=yaml.load(args.workflow.read_text(),Loader=yaml.BaseLoader)
    assert doc['permissions']=={'contents':'read'}
    steps={s['name']:s for s in doc['jobs']['build']['steps']if 'run'in s}
    for s in steps.values():
        checked=subprocess.run(['bash','-n'],input=s['run'],text=True,capture_output=True)
        assert checked.returncode==0,checked.stderr
    prepare=steps['Prepare production source']['run']
    lines=prepare.splitlines();start=lines.index("python3 <<'PY'")+1;end=lines.index('PY',start)
    ast.parse('\n'.join(lines[start:end]))
    guards=[]
    with tempfile.TemporaryDirectory(prefix='gmk-workflow-qa-')as temporary:
        temp=Path(temporary);good=temp/'good';good.mkdir()
        shutil.copyfile(args.bundle,good/args.bundle.name)
        shutil.copyfile(args.fixtures,good/args.fixtures.name)
        runner=temp/'runner';runner.mkdir();envfile=temp/'env';envfile.touch()
        env=os.environ.copy();env.update(RUNNER_TEMP=str(runner),GITHUB_ENV=str(envfile),
                                         GITHUB_WORKSPACE=str(good),ANDROID_HOME=str(args.sdk.resolve()))
        result=run(prepare,good,env)
        project=Path(dict(line.split('=',1)for line in envfile.read_text().splitlines())['GMK_PROJECT'])
        assert project.is_dir()
        checked=subprocess.run(['sha256sum','--check','--quiet','PACKAGE_MANIFEST_SHA256.txt'],cwd=project,capture_output=True,text=True)
        assert checked.returncode==0,checked.stderr
        checked=subprocess.run(['python3','tools/direct19_release_audit.py'],cwd=project,capture_output=True,text=True)
        assert checked.returncode==0,checked.stderr
        assets=json.loads((project/'BUNDLED_ASSETS.json').read_text())
        for x in assets['assets']:
            assert hashlib.sha256((project/x['source_path']).read_bytes()).hexdigest()==x['sha256']
        # Exercise the workflow's real error paths against small hostile ZIPs.
        for name,entries,reason in [
            ('traversal',[('../../escape.txt',b'test',None)],'unsafe ZIP path'),
            ('symlink',[('project/link',b'../escape',stat.S_IFLNK|0o777)],'links and special'),
            ('duplicate',[('project/same',b'a',None),('project/same',b'b',None)],'duplicate ZIP target')]:
            directory=temp/name;directory.mkdir();shutil.copyfile(args.fixtures,directory/args.fixtures.name)
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',UserWarning)
                with zipfile.ZipFile(directory/args.bundle.name,'w')as z:
                    for path,content,mode in entries:
                        info=zipfile.ZipInfo(path)
                        if mode:info.create_system=3;info.external_attr=mode<<16
                        z.writestr(info,content)
            rejected=run(prepare,directory,env,False)
            assert reason in rejected.stderr,(name,rejected.stderr)
            assert not (temp/'escape.txt').exists()
            guards.append(name)
        # A complete source still needs the original observed-price input.
        fixture=project/'tools/direct19_feature_fixture.bin';original=fixture.read_bytes()
        fixture.write_bytes(b'broken')
        rejected=run(prepare,project,env,False)
        assert 'missing or corrupted observed-price fixture'in rejected.stderr
        fixture.write_bytes(original);guards.append('corrupted_observed_fixture')
        metadata=project/'app/build.gradle.kts';original=metadata.read_bytes()
        metadata.write_text(original.decode().replace('versionCode = 108','versionCode = 107'))
        rejected=run(prepare,project,env,False)
        assert 'wrong applicationId or production version'in rejected.stderr
        metadata.write_bytes(original);guards.append('wrong_application_version')
        env.update(GMK_PROJECT=str(project),KEYSTORE_B64='',STORE_PASSWORD='',KEY_ALIAS='',KEY_PASSWORD='')
        signing=steps['Sign and verify APK']['run']
        partial=env.copy();partial['KEYSTORE_B64']='test-fixture-only'
        rejected=run(signing,good,partial,False)
        assert 'Missing store password'in rejected.stderr
        assert not (runner/'gmk.keystore').exists();guards.append('partial_signing_secrets')
        # Use the actual tested APKs in the exact no-secrets branch.
        for mode,apk in [('debug','app-debug.apk'),('release','app-release-unsigned.apk')]:
            target=project/'app/build/outputs/apk'/mode/apk;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/'app/build/outputs/apk'/mode/apk,target)
        (good/'build-environment.log').write_text('Local workflow QA: JDK17 / SDK35; remote runner not executed.\n')
        shutil.copyfile(ROOT/'release_evidence/v0738_full_audit/android_final_build.log',good/'gradle-build.log')
        reports=project/'app/build/test-results/testDebugUnitTest';reports.mkdir(parents=True,exist_ok=True)
        for report in (ROOT/'app/build/test-results/testDebugUnitTest').glob('TEST*.xml'):shutil.copyfile(report,reports/report.name)
        verified=run(signing,good,env)
        mode=(good/'artifacts/signing-mode.txt').read_text().strip()
        assert mode=='test-only-debug-production-unsigned'
        assert not (good/'artifacts/GMK_MOBILE_V0738_PRODUCTION.apk').exists()
        model_report=json.loads((good/'artifacts/model-verification.json').read_text())
        assert model_report['assets_verified']==14
        result={'status':'PASS_LOCAL_WORKFLOW_QA','yaml_and_all_four_bash_steps_valid':True,
                'standalone_equals_bundled_workflow':True,'exact_prepare_executed':True,
                'source_manifest_and_original_policy_verified':True,'restored_assets_verified':len(assets['assets']),
                'rejected_inputs':guards,'exact_unsigned_signing_step_executed':True,
                'packaged_model_assets_verified':14,'signing_mode':mode,
                'remote_github_actions_run':False,'production_signature_applied':False}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()

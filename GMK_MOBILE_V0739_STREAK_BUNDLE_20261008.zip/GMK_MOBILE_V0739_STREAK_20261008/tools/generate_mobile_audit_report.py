"""Generate the Japanese audit report from actual final build/probe evidence."""
import argparse
import base64
from datetime import datetime
from html import escape as esc
import json
from pathlib import Path
import xml.etree.ElementTree as ET
from zoneinfo import ZoneInfo

ROOT=Path(__file__).resolve().parents[1]
EVIDENCE=ROOT/'release_evidence/v0738_full_audit'
FINDINGS=[
 ('通信本文の途中切断','本文読込例外がコルーチンへ返らず、再試行が止まる。','例外を失敗として返し、通常の再試行を実行。'),
 ('チャートの時間切れ','20秒の時間切れ後も取得中表示が残る。','取得中を解除してエラー表示・再取得へ移行。'),
 ('通貨強弱の時間切れ','25秒の時間切れ後も取得中表示が残る。','取得中を解除して再取得可能にする。'),
 ('保存履歴の不正数値','NaNや必要価格のないWINが読込・集計へ混入。','不正な価格を無効化し、異常行を残して集計から除外。'),
 ('前景サービスの起動拒否','OSの開始・昇格拒否がクラッシュになる。','拒否を処理・記録し、状態画面に復旧案内と再試行を用意。'),
 ('端末復帰の直前枠','09:09:30の直前T-10が未来の09:09:50になる。','09:04:50を返し、現在以前の枠を正しく判定。'),
 ('5分の満期表示','5分満期が3分表示になる。','1・3・5・10・15分を実際の時刻差から表示。'),
 ('未来時刻・ゼロ価格','未来timestampのageを0へ丸めてLIVEにする。','有限で正の価格と過去の配信時刻だけをLIVE判定へ使用。'),
 ('実行中スキャンの重複','2.5秒のリースが8秒の実行中に切れ、枠を再取得できる。','プロセス内の実行中請求を保護し、完了・取消時に解放。'),
 ('保存された不正な判定待ち','時刻・通貨・満期が追跡不能でもWAITが残る。','INVALID_TIMING_DATAとして保持し、追跡・集計から除外。'),
 ('時間外の通信予約','実行しない時間帯までYahoo枠を予約する。','実際の次回ENTRY時間が稼働時間内の場合に予約。'),
 ('サービス状態の画面反映','開始・停止状態が画面再表示まで古いまま。','サービス状態の変更を継続購読して反映。'),
 ('小画面・大文字の履歴','集計欄が画面を占有し、履歴行へ到達できない。','集計と履歴を一つのスクロールへ統合。'),
 ('CIの必須実測入力','実測特徴量fixtureがないと比較をスキップできる。','元の完全な実測入力を同梱し、SHAと全試験数を必須チェック。'),
 ('履歴のHIGH表示','横幅不足でHIGHが複数行へ分割する。','通貨・方向・結果を折返し配置し、方向ラベルは一行で表示。'),
 ('モデル読込と履歴復元の結合','旧モデル一つの読込失敗でDirect19用履歴も復元されない。','モデル読込を分離し、正常な19系列の履歴を独立復元。'),
 ('AI補正済みの診断','再取得したAPPLIED結果のchangedがfalseになる。','補正状態と診断のchangedを一致させ、準備系列数も記録。'),
 ('同一枠でのAI結果再利用','元スキャンが変わっても旧ENTRYを再利用し得る。','元スキャン内容・IDを照合し、改訂時は元の判定へ戻す。'),
 ('新規履歴の検証漏れ','新しく追加された不正時刻が再読込までWAITを維持する。','追加時にも同じ検証を行い、直ちに追跡不能状態へ移す。'),
 ('BTC更新の停止・連動','Yahoo予約や実行中スキャンがBTC更新まで止める。','公式WebSocketと専用RESTを常時別処理で実行。再接続・心拍・取消を処理し、旧接続の後着閉鎖通知が新接続を切断扱いにしない。'),
 ('為替5通貨の一括待機','遅い通貨の完了を待ち、他通貨の表示更新も遅れる。','各通貨が完了次第反映。Yahoo同時2要求は維持し、スキャン前にFX要求を取消。'),
 ('複数配信の競合','FX更新でBTC行が消える、古いRESTで新しい配信を上書きする。','6通貨を維持し、配信元時刻を比較。古い要求の失敗も新しいBTC配信を無効化しない。'),
 ('BTCの鮮度・API異常','20秒までLIVEが残る、エラー応答や不正板・欠けた約定値を扱えていない。','BTCは15秒でLASTへ移行。success=1、正のlast、正常なbid/ask、未来でない時刻を必須化。'),
 ('AI価格キャッシュの逆戻り','画面で旧RESTを防いでも、AI用キャッシュは後着の古い配信を採用する。','受信時刻と配信元時刻の逆戻りをキャッシュでも拒否。次の正常な配信は採用。')
]
SUITE_SCOPE={
 'Direct19IntegrationTest':'実測2,640特徴量、未来価格排除、実モデル、3/5分・ENTRY保護',
 'ProductionRegressionTest':'従来のルール・モデル・特徴量・アダプター照合',
 'PcSyncRegressionTest':'PC実装とのモデル照合、ENTRYとスキャン同一性',
 'MobileDeepAuditRegressionTest':'API26/35の通信・履歴・サービス・タイムアウト・表示',
 'MobileFullAuditStateTest':'API26/35の重複枠・不正時刻・予約・状態通知',
 'MobileFullAuditUiTest':'360dp画面、文字倍率1.0/1.8、履歴と診断の到達・方向表示',
 'RuleAiFunctionalTest':'実ルールと実AIモデルの72枠、20保護条件、欠損・未来価格',
 'RuleAiRuntimeIntegrationTest':'API26/35の実読込・復元・補正・履歴確定・旧モデル・改訂',
 'MobileRealtimeAuditTest':'API26/35のSocket.IO、切断復旧、並行更新、鮮度・逆戻り・異常応答',
 'HistoryPipelineAuditTest':'API26/35の新規不正履歴、AI再実行・重複・非有限価格・DRAW'}

def table(head,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(str(x))+'</th>'for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(str(x))+'</td>'for x in row)+'</tr>'for row in rows)+'</tbody></table></div>'

def image(name,label):
    data=base64.b64encode((EVIDENCE/'screenshots'/name).read_bytes()).decode()
    return f'<figure><img src="data:image/png;base64,{data}" alt="{esc(label)}"><figcaption>{esc(label)}</figcaption></figure>'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    release=json.loads((ROOT/'RELEASE_VERIFICATION.json').read_text());functional=release['rule_ai_functional'];guards=release['rule_ai_guards']
    assert release['status']=='PASS_BUILD_AND_HOST_VALIDATION' and release['lint']['errors']==0
    tests=sum(x['tests']for x in release['tests']);assert tests==105
    assert all(x['failures']==x['errors']==x['skipped']==0 for x in release['tests'])
    probes=release['public_provider_probes'];btc=probes['LIVE_BTC_PROVIDER_PROBE.json'];stream=probes['LIVE_BTC_WEBSOCKET_PROBE.json'];fx=probes['LIVE_FOREX_PROVIDER_PROBE.json']
    assert btc['environment_live_feed_verified'] and btc['provider_timestamp_advanced']
    assert stream['environment_stream_verified'] and stream['provider_timestamp_advanced'] and fx['all_five_real_time']
    heartbeat=probes['LIVE_BTC_HEARTBEAT_RECONNECT_PROBE.json']
    assert heartbeat['live_heartbeat_and_reconnect_verified']
    qa_path=EVIDENCE/'WORKFLOW_VALIDATION.json';qa=json.loads(qa_path.read_text())if qa_path.is_file()else None
    changes_path=ROOT/'MOBILE_DEEP_AUDIT_CHANGES.json';changes=json.loads(changes_path.read_text())
    changes['findings']=[dict(id=f'MOB-{i:02}',issue=a,before=b,after=c)for i,(a,b,c)in enumerate(FINDINGS,1)]
    changes['finding_count']=len(FINDINGS);changes_path.write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
    pages=['<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GMK MOBILE v0.7.38 全監査</title>',
      '<style>body{font-family:system-ui,sans-serif;max-width:1100px;margin:28px auto;padding:0 18px;line-height:1.7;color:#162438;background:#f7f9fc}h1{font-size:26px}h2{font-size:21px;margin-top:34px}table{border-collapse:collapse;width:100%;background:white;font-size:13px}td,th{border:1px solid #cbd5e1;padding:9px;text-align:left;vertical-align:top}.scroll{overflow-x:auto}.ok{background:#dcfce7;border-radius:8px;padding:16px}.note{background:#fff4d6;border-radius:8px;padding:15px}code{overflow-wrap:anywhere}.images{display:flex;flex-wrap:wrap;gap:16px}figure{margin:0;width:300px}figure img{width:100%;border:1px solid #cbd5e1}figcaption{font-size:13px}.muted{color:#52667d}@media(max-width:600px){body{margin:14px auto}table{min-width:680px}}</style><body>',
      '<h1>GMK MOBILE v0.7.38 — AI・ルール・履歴・リアルタイム取得の全監査</h1>',
      '<p>対象: v0.7.36-direct19-3m5m → v0.7.38-mobile-full-audit / versionCode 108。作成: '+esc(release['created_at_jst'])+'</p>',
      f'<div class="ok"><b>{len(FINDINGS)}課題を修正・補強。最終{tests}試験PASS、失敗・エラー・スキップ0。Lintエラー0。</b><p>release/debug APK生成成功。BTC/JPYは公式の実WebSocket配信とRESTの両方で更新時刻を確認。為替5通貨も実APIで新しい価格時刻を確認しました。</p></div>',
      '<h2>BTC/JPYの実通信と更新経路</h2><p>スキャン、Yahooの通信予約、為替の応答待ちからBTC処理を分離しました。公式Socket.IO EIO4へ購読し、心拍応答、切断後の再接続、停止後の遅延コールバックを処理します。配信が新しく届かない場合は専用RESTで再取得します。BTC用HTTPは8秒、処理全体は9秒で時間切れ、回復確認の間隔は2秒です。データの配信元時刻を更新せずにLIVEへ戻す処理はありません。</p>',
      '<p>LIVEの条件は配信元から15秒以内、有限で正のlast、正常なbid/ask、未来ではない時刻。15秒を超えた価格はLAST、未取得はUNAVAILABLEと表示します。RESTの後着、FXの部分更新、古い要求の失敗が新しいBTC配信を消さないことも試験しました。</p>']
    realtime=[]
    for i,x in enumerate(btc['samples'],1):
        ts=x['body']['data']['timestamp'];realtime.append(('BTC REST',i,datetime.fromtimestamp(ts/1000,ZoneInfo('Asia/Tokyo')).isoformat(),x['provider_age_seconds'],x['latency_ms'],'HTTP 200 / success=1'))
    for i,x in enumerate(stream['samples'],1):
        realtime.append(('BTC WebSocket',i,datetime.fromtimestamp(x['provider_timestamp_ms']/1000,ZoneInfo('Asia/Tokyo')).isoformat(),x['provider_age_seconds'],'継続配信','接続・購読・更新確認'))
    for x in fx['samples']:
        a=x['attempts'][-1];realtime.append((x['instrument'],1,datetime.fromtimestamp(a['source_epoch_ms']/1000,ZoneInfo('Asia/Tokyo')).isoformat(),a['provider_age_seconds'],a['latency_ms'],'HTTP 200 / LIVE'))
    pages += [table(('取得方法・通貨','標本','配信元時刻 JST','受信時の古さ 秒','HTTP往復 ms','結果'),realtime),
      table(('実WebSocketの継続確認','結果'),[
          ('受信した実配信',len(heartbeat['ticks'])),('接続と再接続',heartbeat['connections']),
          ('Engine.IO心拍への応答',heartbeat['heartbeat_pongs_sent']),
          ('再接続後の新しい配信',sum(x['connection']==2 for x in heartbeat['ticks']))]),
      '<p class="muted">上表はホストから公共APIへ行った実通信の記録です。価格が同じでも配信元時刻が連続して進んだことを確認しました。Android側のSocket.IO・REST・画面更新はAPI26/35のRobolectricとMockWebServerで別途検証しています。実端末の通信・省電力下での継続運転は未実施です。通信不能時はLASTまたはUNAVAILABLEとなり、新しい配信の受信後にLIVEへ復帰します。</p>',
      '<h2>AIとルールの実動作</h2>',
      '<p>LocalRuleEngineと同梱の実HGBモデルを接続し、元の実測価格の72枠を実行しました。モデルを利用可能にするため日時だけを移動した機能試験で、価格列は変更していません。モックの予測確率で補正成功を作る試験ではありません。</p>',
      table(('検証項目','実行結果'),[
        ('実ルールの判定枠',functional['slots']),('共通4通貨のC・ENTRY',functional['native_common_four_c_entries']),
        ('実モデルの補正適用',functional['real_model_applied']),('5分の補正適用',functional['five_minute_applied']),('3分固定の補正適用',functional['fixed_three_applied']),
        ('保護された判定',json.dumps(functional['statuses'],ensure_ascii=False)),('実モデルフレームでの異常・締切保護',guards['guard_cases']),
        ('モデルの読込とAPK内照合','11モデル＋3マニフェスト = 14資産、ソースと完全一致'),
        ('19系列の履歴復元','各系列4,000本以上を復元して実prepare/apply/commitまで実行'),
        ('昼間・夕方・手動・1分','Direct19、旧Horizon/PC R13、手動と1分の経路を検証')]),
      '<p>モデル破損、準備不足、欠損、不正/未来/古い価格、価格改訂、公開締切、SKIP・S/A/B保護を検証しました。元の判定が同じ境界内で変わった場合に古いENTRYを再利用しないこと、再取得したAPPLIED結果の診断が一致することも確認。AIの価格キャッシュにも配信元時刻の逆戻りを拒否する保護を追加しました。</p>',
      '<p>ルールの31ファイルとモデル資産14ファイルはv0.7.36とSHA-256が一致します。固定モデルの165入力、C判定の3/5分選択、ENTRY条件を変更していません。今回は機能監査で、将来の勝率を実証する試験ではありません。スマホ内の日次再学習は実装されていません。正常な旧履歴を継続集計するためpolicyVersionはGMK_V0736を維持しています。</p>',
      '<h2>履歴の追跡・保存・集計</h2><p>実AI補正結果をHistoryStoreへ追加し、WAIT_ENTRY → WAIT_JUDGE → WIN、ディスク再読込まで確認。5分の満期と通貨・方向を維持します。同じIDや同じAUTO境界の再実行で確定結果を消さないこと、NaN/Infinityや不正な経過秒を採用しないこと、同値DRAWをLOSEとして再読込後も集計することを確認しました。勝敗確認で用いる評価価格は試験用に制御した値です。</p>',
      '<p>保存データの復元だけでなく、新規追加時も時刻・通貨・満期を検証。不正な判定待ちはINVALID_TIMING_DATA、不正な必要価格はINVALID_RATE_DATAとして残し、追跡と勝率集計から除外します。破損した本体のバックアップ・最新クラッシュジャーナルからの復元も試験しました。</p>',
      '<h2>修正・補強した課題</h2>',table(('ID','課題','修正前','修正後'),[(f'MOB-{i:02}',a,b,c)for i,(a,b,c)in enumerate(FINDINGS,1)]),
      '<h2>再現を確認した主な修正前試験</h2>']
    baseline=[]
    for name,label in [('BASELINE-MobileFullAuditStateTest.xml','v0.7.37 状態監査'),('BASELINE-MobileFullAuditUiTest.xml','v0.7.37 小画面UI'),('BASELINE-RuleAiRuntimeIntegrationTest.xml','v0.7.37 AI実行経路'),('BEFORE_NEW_HISTORY_VALIDATION-HistoryPipelineAuditTest.xml','新規履歴検証の追加前'),('BASELINE_BTC_LOOPS-MobileRealtimeAuditTest.xml','v0.7.37 BTC更新・併合・鮮度'),('BASELINE_INFERENCE_QUOTE_CACHE.xml','AI価格キャッシュ保護の追加前'),('BASELINE_LATE_SOCKET_CLOSE.xml','旧接続の閉鎖通知保護の追加前')]:
        r=ET.parse(EVIDENCE/name).getroot();baseline.append((label,r.get('tests'),r.get('failures'),name))
    pages += [table(('比較対象','実行数','修正前の失敗数','記録'),baseline),
      '<p>中間の調査ログには試験fixtureやUI判定方法を見直した記録も含まれます。bitbank fixtureは実APIどおりsuccess=1を含め、方向ラベルはComposeの段落幅ではなく実際の文字領域で検証しました。上表は不具合再現に対応する記録、最終判定は全105試験のXMLとビルドログです。</p>',
      '<h2>小画面・文字拡大の確認</h2><p>360dp幅、内容領域520dp、文字倍率1.0/1.8で履歴行と診断ボタンへスクロールで到達。HIGHの文字全体が一行のラベル内に収まることを検証しました。画像はRobolectricの実Android描画処理によるCPUレンダリングで、実スマホのスクリーンショットではありません。</p><div class="images">',
      image('BEFORE_DIRECTION_history_large_text.png','修正前: 文字倍率1.8で方向ラベルが分割'),image('history_large_text.png','修正後: 文字倍率1.8でもHIGHを一行で表示'),image('status_large_text.png','修正後: 拡大文字でも診断ボタンへ到達'),'</div>',
      '<h2>全試験とAndroid成果物</h2>',table(('試験スイート','件数','範囲'),[(x['suite'],x['tests'],SUITE_SCOPE[x['suite']])for x in release['tests']]),
      f'<p>Lint: エラー0、警告{release["lint"]["warnings"]}。既存の画面方向・アイコン・SharedPreferences等の指摘をXMLに残しています。JDK17 / Gradle8.10.2 / SDK35 / AGP8.7.3 / Kotlin2.0.21 / Robolectric4.14.1。API26・35のフレームワークJARは公式MavenのSHA-512と照合済みです。</p>',
      table(('APK','サイズ bytes','SHA-256','署名'),[(x['filename'],x['bytes'],x['sha256'],x['signing_mode'])for x in release['apk'].values()]),
      '<h2>独立ワークフローファイル</h2><p>GMK_MOBILE_V0738_BUILD_WORKFLOW_20261008.ymlはプロジェクトの.github/workflows/build.ymlと同一。JDK17/Gradle8.10.2/SDK35、ソース復元、必須実測fixtureのSHA、アプリ108識別、全105試験・スキップ0、Lint、APK内の14モデル資産と署名を検査します。元のGMK_V0735_TEST_DATA.zipは旧試験用の入力として併用します。</p>']
    if qa:
        assert qa['status']=='PASS_LOCAL_WORKFLOW_QA'
        pages += [table(('ローカル確認','結果'),[
          ('YAML・4つのbash・内包Python','PASS'),('実配布ZIPから正確なprepare手順を実行','PASS'),
          ('全ソースのSHAとモデル・元ルールの検証','PASS'),('APKから復元した資産',qa['restored_assets_verified']),
          ('拒否を実行確認した入力',', '.join(qa['rejected_inputs'])),('鍵なし署名確認の正確な手順','PASS / TEST_ONLYとRELEASE_UNSIGNEDを作成'),
          ('GitHub上の実行','未実施'),('本番鍵での署名','未実施')])]
    else:pages += ['<p>独立ZIPからの最終ワークフロー確認は梱包工程で実行中です。</p>']
    pages += ['<p>既存4つのGMK_SIGNING Secretsが全部揃う場合だけ、その鍵でPRODUCTION APKを署名します。一部だけの設定はエラーで停止。鍵がない場合はTEST_ONLYとRELEASE_UNSIGNEDを明記して出力します。新しいdebug署名を本番署名と表示する手順はありません。</p>',
      '<div class="note"><b>本番署名と実端末への適用は未実施です。</b><p>この環境に既存の署名鍵と対象端末がないため、本番APKは未署名です。既存アプリと同じ鍵で署名したAPKを上書きする必要があります。実端末の通知・OS独自の省電力・24時間継続運転は、今回のホスト試験と実API疎通の結果に含まれません。</p></div>',
      '<h2>記録と一次資料</h2><p>RELEASE_VERIFICATION.json / MOBILE_DEEP_AUDIT_CHANGES.json / release_evidence/v0738_full_audit / RULE_AI_FUNCTIONAL_AUDIT.json / RULE_AI_GUARD_AUDIT.json。変更差分はMOBILE_CHANGES_FROM_V0736.patchです。過去の移植照合はDIRECT19_PORTABLE_REPLAY_AUDIT.jsonとDIRECT19_KOTLIN_FEATURE_AUDIT.jsonに区別して保持しています。</p>',
      '<p><a href="https://github.com/bitbankinc/bitbank-api-docs/blob/master/public-stream.md">bitbank公式: Public Stream</a><br><a href="https://github.com/bitbankinc/bitbank-api-docs/blob/master/public-api.md">bitbank公式: Public API</a><br><a href="https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start">Android公式: 前景サービスの開始制限</a><br><a href="https://robolectric.org/getting-started/">Robolectric公式: フレームワーク試験</a></p></body></html>']
    html='\n'.join(pages);(ROOT/'MOBILE_DEEP_AUDIT_REPORT.html').write_text(html)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(html)
    readme=f'''GMK MOBILE v0.7.38 / versionCode 108 — AI・ルール・履歴・リアルタイム取得の全監査

{len(FINDINGS)}課題を修正・補強。Androidホストの全{tests}試験PASS、失敗・スキップ0。Lintエラー0。
実BTC/JPYの公式WebSocketは約1秒間隔で配信元時刻が更新され、受信時の古さ0.598〜0.692秒。
実RESTは3回連続HTTP200、配信元時刻が全て更新。為替5通貨も実APIの新しい時刻でLIVEを確認。
継続実通信でも{len(heartbeat['ticks'])}配信、心拍応答{heartbeat['heartbeat_pongs_sent']}回、再接続後の新しい配信を確認。
上記はホストからの実通信です。実端末での通信・運転は未確認です。

BTCの更新はYahoo予約・スキャン・為替の応答待ちから独立。公式Socket.IO EIO4へ購読。
心拍応答・切断復旧・停止後の遅延応答を処理。配信停止時は専用RESTで回復。
BTCは配信元から15秒を超えたらLAST。接続し直すだけで古い価格をLIVEにしません。
為替は5通貨を個別更新。Yahoo同時2要求を維持し、スキャンへ枠を譲ります。
後着の古いRESTは画面とAI価格キャッシュの両方で拒否。

実ルール＋実HGBモデルの72枠、補正10枠（5分7枠）、3分固定6枠、20の異常保護条件を検証。
全11モデルを読込、19系列を各4,000本以上復元し、prepare/apply/commitと履歴確定・再読込を確認。
価格列は元の実測値。日時だけをモデル利用可能日に移動した機能試験で、成績バックテストではありません。
昼間は平日JST09:00〜17:00の共通4通貨のC・ENTRYのみ3/5分補正。
確率差0.10超のみ補正し、S/A/B・SKIP・対象外通貨を保護。3分固定は3分候補だけで選びます。
夕方は従来Horizon/PC R13、手動・1分は従来の経路を検証。
ルール31ファイル・モデル14資産はv0.7.36と同一。policyVersionはGMK_V0736を継続。
同梱モデルは学習済み固定モデルで、スマホ内の日次再学習は搭載していません。

履歴は新規追加時と復元時に検証。不正な待ち・必要価格は行を残して追跡と勝率から除外。
再実行・重複AUTO枠は確定結果を維持。DRAWはLOSE。1/3/5/10/15分を別集計。
360dp幅・文字倍率1.0/1.8で、履歴と診断のスクロール到達、HIGHの一行表示を確認。

詳しい結果: MOBILE_DEEP_AUDIT_REPORT.html / RELEASE_VERIFICATION.json
差分・不具合一覧: MOBILE_DEEP_AUDIT_CHANGES.json / release_evidence/v0738_full_audit
実AI動作: RULE_AI_FUNCTIONAL_AUDIT.json / RULE_AI_GUARD_AUDIT.json
ネットワーク再確認: python3 tools/probe_public_market_feeds.py --mode all
（streamモードはwebsockets16.0が必要。その他はPython標準ライブラリのみ。）

ビルド: JDK17 / Gradle8.10.2 / SDK35 / build-tools35.0.0
配布バンドルは最初に python3 tools/restore_bundled_assets.py を実行。
従来のGMK_V0735_TEST_DATA.zipの先頭フォルダを外して本プロジェクトへ展開します。
元の完全な実測特徴量fixtureは同梱済み。環境変数の追加指定は不要です。
 sha256sum --check --quiet PACKAGE_MANIFEST_SHA256.txt
 python3 tools/direct19_release_audit.py
 gradle :app:testDebugUnitTest :app:lintRelease :app:assembleRelease :app:assembleDebug --no-daemon --max-workers=2
 python3 tools/verify_mobile_test_results.py
現在版のワークフロー検証は tools/verify_full_audit_workflow.py を使用します。
tools/test_workflow.py と functional_contract_test.py はv0.7.35用の保存した比較ツールです。

独立ファイル GMK_MOBILE_V0738_BUILD_WORKFLOW_20261008.yml は .github/workflows/build.yml と同一。
配布バンドルまたはソースZIPを一つとGMK_V0735_TEST_DATA.zipをリポジトリへ配置するか、全ソースを配置して使用。
GMK_SIGNING_KEYSTORE_BASE64 / GMK_SIGNING_STORE_PASSWORD / GMK_SIGNING_KEY_ALIAS / GMK_SIGNING_KEY_PASSWORD
4つの既存Secretsが揃えば、その鍵でPRODUCTION APKを署名。一部だけはエラー。
鍵がなければTEST_ONLY debug APKとRELEASE_UNSIGNED APK。GitHub上の実行は未実施。

本番用APKは未署名。対象端末と既存鍵がこの環境にないため、実端末への適用は未実施です。
履歴を残して既存アプリを更新するには、同じ本番署名鍵による上書きが必要です。
APK内の11モデルと3マニフェストはソースと一致、debug署名は検証済みです。
'''
    (ROOT/'README_CURRENT_JA.txt').write_text(readme)
    print(json.dumps({'report':str(args.output),'bytes':args.output.stat().st_size,'findings':len(FINDINGS),'tests':tests,'workflow_verified':qa is not None},ensure_ascii=False))

if __name__=='__main__':main()

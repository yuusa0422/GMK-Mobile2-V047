"""Archived v0.7.35 workflow checks (version 105, stubbed SDK/Gradle).

Current v0.7.38 uses verify_full_audit_workflow.py with the real tested APKs.
This preserves the earlier version's assertions for historical comparison.
"""
from pathlib import Path
import argparse, base64, json, os, shutil, subprocess, tempfile, warnings, zipfile
import yaml

parser = argparse.ArgumentParser()
parser.add_argument("--zipfile", type=Path)
parser.add_argument("--test-data", type=Path)
parser.add_argument("--exercise-build-gates", action="store_true", help="Run actual source/Java/replay gates; replace Gradle with an explicit stub")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
workflow = yaml.load((root / ".github/workflows/build.yml").read_text(), Loader=yaml.BaseLoader)
steps = workflow["jobs"]["build"]["steps"]
prepare = next(s["run"] for s in steps if s.get("name") == "Prepare production source")
sign = next(s["run"] for s in steps if s.get("name") == "Sign and verify APK")
environment = next(s["run"] for s in steps if s.get("name") == "Verify build environment")
archive_name = "GMK_MOBILE_V0735_AI_ENTRY70_SOURCE_20261007.zip"
metadata = (root / "app/build.gradle.kts").read_text()
records = []

def check(name, okay):
    if not okay:
        raise AssertionError(name)
    records.append({"check": name, "status": "PASS"})

check("workflow_events", workflow["on"] == ["workflow_dispatch", "push"])
check("minimal_permissions", workflow["permissions"] == {"contents": "read"})
check("no_ignored_build_errors", "continue-on-error" not in str(workflow))
for step in steps:
    if "run" in step:
        run = subprocess.run(["bash", "-n"], input=step["run"], text=True, capture_output=True)
        check("shell_syntax_" + step["name"], run.returncode == 0)
check("fixed_toolchain", all(any(s.get("with", {}).get(k) == v for s in steps) for k, v in [
    ("java-version", "17"), ("gradle-version", "8.9"),
    ("cmdline-tools-version", "12266719"),
    ("packages", "platform-tools platforms;android-35 build-tools;35.0.0")]))
build=next(s["run"] for s in steps if s.get("name")=="Compile Kotlin and build APK")
check("monthly_70_gate_before_apk",build.index("python3 tools/check_entry70_replay.py")<build.index("gradle :app:"))
check("model_verification_before_checksum", sign.index("verify_apk_assets.py") < sign.index("sha256sum GMK_MOBILE.apk"))
check("minimum_target_sdk_verified", all(x in sign for x in ["sdkVersion:'26'", "targetSdkVersion:'35'"]))

# Check environment-step failure propagation with explicit mock programs/files.
for mode in ("ok", "missing_platform", "missing_signer", "missing_aapt", "java_failure", "gradle_failure"):
    with tempfile.TemporaryDirectory(prefix="gmk-env-test-") as td:
        base = Path(td)
        mockbin = base / "bin"; mockbin.mkdir()
        sdk = base / "sdk"
        platform = sdk / "platforms/android-35/android.jar"; platform.parent.mkdir(parents=True)
        if mode != "missing_platform": platform.write_bytes(b"EXPLICIT MOCK PLATFORM")
        bt = sdk / "build-tools/35.0.0"; bt.mkdir(parents=True)
        for name in ("java", "javac", "gradle"):
            program = mockbin / name
            failure = mode == name + "_failure"
            program.write_text("#!/bin/bash\n" + ("exit 8\n" if failure else "echo 'EXPLICIT MOCK TOOL VERSION'\n"))
            program.chmod(0o755)
        for name, absent in (("apksigner", "missing_signer"), ("aapt", "missing_aapt")):
            if mode == absent: continue
            program = bt / name; program.write_text("#!/bin/bash\nexit 0\n"); program.chmod(0o755)
        result = subprocess.run(["bash", "-c", environment], cwd=base, capture_output=True, text=True,
            env={**os.environ, "PATH": str(mockbin) + os.pathsep + os.environ["PATH"], "ANDROID_HOME": str(sdk), "GITHUB_WORKSPACE": td})
        check("mock_environment_" + mode, (result.returncode == 0) == (mode == "ok"))

def source_case(name, entries=None, expected=True, unpacked=False, duplicate=False, raw=None, external=None, companion_mode="ok"):
    with tempfile.TemporaryDirectory(prefix="gmk-workflow-test-") as td:
        base = Path(td)
        repo = base / "repo"; repo.mkdir()
        tmp = base / "tmp"; tmp.mkdir()
        envfile = base / "github-env"
        if unpacked:
            p = repo / "source with spaces"; (p / "app").mkdir(parents=True)
            (p / "settings.gradle.kts").write_text("")
            (p / "app/build.gradle.kts").write_text(metadata)
        elif external:
            shutil.copyfile(external, repo / archive_name)
        elif raw is not None:
            (repo / archive_name).write_bytes(raw)
        elif entries is not None:
            with zipfile.ZipFile(repo / archive_name, "w") as z:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", UserWarning)
                    for path, content in entries:
                        z.writestr(path, content)
            if duplicate:
                (repo / "duplicate").mkdir()
                shutil.copyfile(repo / archive_name, repo / "duplicate" / archive_name)
        if (repo / archive_name).exists() and companion_mode != "missing":
            companion = repo / "GMK_V0735_TEST_DATA.zip"
            if external:
                if args.test_data is None: raise ValueError("--test-data required with --zipfile")
                shutil.copyfile(args.test_data, companion)
            else:
                with zipfile.ZipFile(companion, "w") as z:
                    if companion_mode == "collision": z.writestr("source/app/build.gradle.kts", metadata)
                if companion_mode == "duplicate":
                    (repo / "extra").mkdir()
                    shutil.copyfile(companion, repo / "extra/GMK_V0735_TEST_DATA.zip")
        result = subprocess.run(["bash", "-c", prepare], cwd=repo, capture_output=True, text=True,
            env={**os.environ, "RUNNER_TEMP": str(tmp), "GITHUB_ENV": str(envfile)})
        check(name, (result.returncode == 0) == expected)
        if expected:
            project = Path(envfile.read_text().strip().removeprefix("GMK_PROJECT="))
            check(name + "_project_identity", (project / "app/build.gradle.kts").read_text() == metadata)
            if external:
                result = subprocess.run(["sha256sum", "--check", "--quiet", "PACKAGE_MANIFEST_SHA256.txt"], cwd=project, capture_output=True)
                check("actual_archive_all_member_hashes", result.returncode == 0)
                if args.exercise_build_gates:
                    mockbin = base / "mockbin"; mockbin.mkdir()
                    gradle = mockbin / "gradle"
                    gradle.write_text("#!/usr/bin/env python3\nimport json, os, pathlib, sys\npathlib.Path(os.environ['MOCK_GRADLE_ARGS']).write_text(json.dumps(sys.argv[1:]))\nprint('EXPLICIT MOCK GRADLE: NO ANDROID BUILD')\nsys.exit(int(os.environ['MOCK_GRADLE_EXIT']))\n")
                    gradle.chmod(0o755)
                    argsfile = base / "gradle-args.json"
                    buildenv = {**os.environ, "GMK_PROJECT": str(project), "GITHUB_WORKSPACE": str(repo), "PATH": str(mockbin) + os.pathsep + os.environ["PATH"], "MOCK_GRADLE_ARGS": str(argsfile)}
                    for code in (0, 17):
                        argsfile.unlink(missing_ok=True)
                        result = subprocess.run(["bash", "-c", build], cwd=repo, env={**buildenv, "MOCK_GRADLE_EXIT": str(code)}, capture_output=True, text=True)
                        check("actual_build_gates_mock_gradle_exit_" + str(code), result.returncode == code and argsfile.is_file())
                        check("actual_gradle_tasks_" + str(code), json.loads(argsfile.read_text()) == [":app:compileDebugKotlin", ":app:testDebugUnitTest", ":app:lintDebug", ":app:assembleDebug", "--no-daemon", "--stacktrace", "--console=plain"])
                    argsfile.unlink()
                    (project / "README_CURRENT_JA.txt").write_text("deliberate test corruption")
                    result = subprocess.run(["bash", "-c", build], cwd=repo, env={**buildenv, "MOCK_GRADLE_EXIT": "0"}, capture_output=True, text=True)
                    check("actual_manifest_corruption_blocks_gradle", result.returncode != 0 and not argsfile.exists())

valid = [("source/settings.gradle.kts", ""), ("source/app/build.gradle.kts", metadata)]
source_case("valid_source_zip", valid)
source_case("missing_test_data_rejected", valid, expected=False, companion_mode="missing")
source_case("duplicate_test_data_rejected", valid, expected=False, companion_mode="duplicate")
source_case("cross_archive_collision_rejected", valid, expected=False, companion_mode="collision")
source_case("unpacked_project_with_spaces", unpacked=True)
source_case("missing_project_rejected", expected=False)
source_case("duplicate_archives_rejected", valid, expected=False, duplicate=True)
source_case("corrupt_zip_rejected", raw=b"broken", expected=False)
for key, old, new in [("version", "versionCode = 105", "versionCode = 101"),
                     ("appid", "jp.gmk.mobile.rule", "jp.gmk.research")]:
    source_case("wrong_" + key + "_rejected", [valid[0], (valid[1][0], metadata.replace(old, new))], expected=False)
for path in ["../escape", "/escape", "C:/escape", "source/../../escape", "..\\escape"]:
    source_case("unsafe_" + repr(path), valid + [(path, "bad")], expected=False)
source_case("duplicate_normalized_targets_rejected", valid + [("source/./app/build.gradle.kts", metadata)], expected=False)
source_case("multiple_projects_rejected", valid + [("other/settings.gradle.kts", ""), ("other/app/build.gradle.kts", metadata)], expected=False)
for mode in [0o120777, 0o020600]:
    info = zipfile.ZipInfo("source/link"); info.create_system = 3; info.external_attr = mode << 16
    source_case("special_file_rejected_" + oct(mode), valid + [(info, "target")], expected=False)
if args.zipfile:
    source_case("actual_delivery_zip", external=args.zipfile.resolve())

# These ZIPs and tools are explicit mocks: no Android build or signature is claimed.
for mode in ["ephemeral", "persistent", "partial", "invalid_base64", "signer_failure", "verify_failure", "wrong_apk", "wrong_min_sdk", "wrong_target_sdk", "missing_apk", "invalid_apk_zip", "missing_model", "corrupt_model", "altered_manifest", "extra_model", "duplicate_model"]:
    with tempfile.TemporaryDirectory(prefix="gmk-sign-test-") as td:
        base = Path(td); apk = base / "project/app/build/outputs/apk/debug/app-debug.apk"
        apk.parent.mkdir(parents=True)
        project = base / "project"
        shutil.copytree(root / "app/src/main/assets", project / "app/src/main/assets")
        (project / "tools").mkdir()
        shutil.copyfile(root / "tools/verify_apk_assets.py", project / "tools/verify_apk_assets.py")
        if mode != "missing_apk":
            with zipfile.ZipFile(apk, "w") as z:
                z.writestr("MOCK_ARCHIVE_ONLY.txt", "This is not an Android APK")
                for path in sorted((root / "app/src/main/assets").rglob("*")):
                    if not path.is_file(): continue
                    name = "assets/" + path.relative_to(root / "app/src/main/assets").as_posix()
                    content = path.read_bytes()
                    if name == "assets/pc_r13/TCN.bin":
                        if mode == "missing_model": continue
                        if mode == "corrupt_model": content = content[:-1] + bytes([content[-1] ^ 1])
                    if name == "assets/pc_r13/manifest.json" and mode == "altered_manifest": content += b" "
                    z.writestr(name, content)
                if mode == "extra_model": z.writestr("assets/pc_r13/unexpected.bin", b"bad")
                if mode == "duplicate_model":
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", UserWarning)
                        z.writestr("assets/pc_r13/TCN.bin", b"duplicate")
            if mode == "invalid_apk_zip": apk.write_bytes(b"not a zip")
        bt = base / "sdk/build-tools/35.0.0"; bt.mkdir(parents=True)
        signer = bt / "apksigner"
        signer.write_text("#!/usr/bin/env python3\nimport os, pathlib, shutil, sys\na=sys.argv[1:]\nif os.environ['MOCK_MODE']=='signer_failure': sys.exit(7)\nif a[0]=='sign': shutil.copyfile(a[-1],a[a.index('--out')+1])\nelse:\n if os.environ['MOCK_MODE']=='verify_failure': sys.exit(9)\n print('EXPLICIT MOCK SIGNATURE: NO CRYPTOGRAPHIC VERIFICATION')\n sys.exit(0 if pathlib.Path(a[-1]).is_file() else 8)\n")
        signer.chmod(0o755)
        aapt = bt / "aapt"
        package = "wrong.application" if mode == "wrong_apk" else "jp.gmk.mobile.rule"
        min_sdk = "25" if mode == "wrong_min_sdk" else "26"
        target_sdk = "34" if mode == "wrong_target_sdk" else "35"
        aapt.write_text("#!/usr/bin/env python3\nprint(" + repr(f"package: name='{package}' versionCode='105' versionName='0.7.35-ai-entry70-candidate'\nsdkVersion:'{min_sdk}'\ntargetSdkVersion:'{target_sdk}'") + ")\n")
        aapt.chmod(0o755)
        env = {**os.environ, "GMK_PROJECT": str(base / "project"), "ANDROID_HOME": str(base / "sdk"),
               "RUNNER_TEMP": td, "GITHUB_WORKSPACE": td, "MOCK_MODE": mode, "KEYSTORE_B64": "", "STORE_PASSWORD": "", "KEY_ALIAS": "", "KEY_PASSWORD": ""}
        (base / "build-environment.log").write_text("EXPLICIT MOCK ENVIRONMENT LOG")
        if mode in ["persistent", "invalid_base64"]:
            env.update(KEYSTORE_B64=base64.b64encode(b"test-only").decode(), STORE_PASSWORD="test", KEY_ALIAS="test", KEY_PASSWORD="test")
        if mode == "partial": env["KEY_ALIAS"] = "test"
        if mode == "invalid_base64": env["KEYSTORE_B64"] = "!invalid!"
        result = subprocess.run(["bash", "-c", sign], cwd=base, env=env, capture_output=True, text=True)
        check("mock_signing_branch_" + mode, (result.returncode == 0) == (mode in ["ephemeral", "persistent"]))
        if result.returncode == 0:
            files = {p.name for p in (base / "artifacts").iterdir()}
            check("artifact_contents_" + mode, files == {"GMK_MOBILE.apk", "SHA256.txt", "signing-mode.txt", "package.txt", "signature.txt", "model-verification.json", "build-environment.log"})
            check("reported_mode_" + mode, (base / "artifacts/signing-mode.txt").read_text().strip() == ("persistent" if mode == "persistent" else "ephemeral-debug"))
            report = json.loads((base / "artifacts/model-verification.json").read_text())
            check("model_assets_" + mode, report["status"] == "PASS" and report["assets_verified"] == 11 and report["fold"] == "2026-08")
print(json.dumps({"status": "PASS", "checks": len(records), "github_actions_executed": False,
    "sdk_gradle_apk_build_executed": False, "actual_build_gates_executed": bool(args.zipfile and args.exercise_build_gates), "signing_test_scope": "SHELL_CONTROL_FLOW_WITH_MOCK_TOOLS_AND_EXPLICIT_NON_APK_ZIP", "results": records}, ensure_ascii=False, indent=2))

"""Source/data integrity gates. SDK compilation, phone timing and live win rate are separate."""
from pathlib import Path
import hashlib,json,struct,sys
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/jp/gmk/mobile'
checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,ok):checks.append({'check':name,'pass':bool(ok)})
def read(p):return p.read_text(encoding='utf-8')
old=json.loads(read(root/'tools/pc_sync_preserved_sha256.json'))
for name,value in old.items():check('preserved:'+name,sha(root/name)==value)
meta=json.loads(read(root/'app/src/main/assets/pc_r13/manifest.json'))
check('policy',meta['policy']=='LONG_XGB_M1_C_PLUS_NON_NATIVE_OPEN36_M10' and meta['fold']=='2026-08')
check('available_from',meta['available_from']==1785715190)
catalog=read(src/'domain/r13/R13Catalog.kt')
for name,spec in meta['models'].items():
 p=root/'app/src/main/assets/pc_r13'/spec['asset']
 check('model:'+name,sha(p)==spec['sha256'] and spec['sha256'] in catalog and p.stat().st_size==spec['bytes'])
base=json.loads(read(root/'app/src/main/assets/horizon_policy/manifest.json'))
for model in base['models']:check('base:'+model['asset'],sha(root/'app/src/main/assets/horizon_policy'/model['asset'])==model['sha256'])
vm=read(src/'ui/GmkViewModel.kt');hist=read(src/'data/HistoryStore.kt');runtime=read(src/'data/HorizonRuntime.kt');main=read(src/'MainActivity.kt');adapter=read(src/'domain/horizon/HorizonScanAdapter.kt')
check('r13_connected','r13?.apply(base,native,frame,quotes,candles)' in runtime)
check('native_quote_safety','top.decision=="ENTRY" && safeNative' in adapter)
check('exception_gate_rollback','gate.restore(seed)' in adapter)
check('accepted_history_before_policy_commit',vm.index('historyStore.add(result)',vm.index('val result0'))<vm.index('horizonRuntime.commit(result.scanId)'))
check('discard_aborted_proposals','horizonRuntime.discardPending()' in vm and 'restoreState' in runtime)
check('version_persisted_all_decode_routes',hist.count('x.optString("policy_version", "LEGACY_UNVERSIONED")')==2 and '.put("policy_version", h.policyVersion)' in hist and 'policyVersion = result.policyVersion' in hist)
check('stats_actual_expiry','historyStatistics' in main and 'statisticsRow().minutes()' in main)
check('skip_reference_visuals','if (h.decision == "SKIP")' in main and 'h.decision == "ENTRY" && h.resultStatus == "LOSE"' in main)
check('diagnostic_scope','outcome_statistics' in vm and 'result_history_truncated' in vm and 'take(1000)' in vm)
check('three_minute_default','prefs.getBoolean("force_three_minute_outcome", true)' in read(src/'data/AppPrefs.kt'))
check('separate_expiry_profiles','ExpiryProfiles.includes' in main and 'ExpiryProfiles.apply' in runtime)
check('candidate_identity','versionCode = 105' in read(root/'app/build.gradle.kts') and '0.7.35-ai-entry70-candidate' in read(root/'app/build.gradle.kts'))
check('no_new_research_skip_filter',all('ResearchRuleIdPolicy.get(' not in read(p) for p in src.rglob('*.kt')))
check('no_automatic_fitting',not any('fit(' in read(p) for p in (src/'domain/r13').glob('*.java')))
check('java_test_copy_identical',sha(root/'tools/R13OfflineTest.java')==sha(root/'app/src/test/java/R13OfflineTest.java'))
correction=read(src/'domain/r13/R13ScanAdapter.kt')
check('entry_guard_connected','EntryMaskGuard.rejectionReason(' in correction and 'if (rejected == null) result else base' in correction)
check('cached_scan_entry_guard','if (rejected == null) return cached' in correction and correction.count('EntryMaskGuard.rejectionReason(')==2)
check('entry_guard_diagnostic','preserves_base_entry_mask' in runtime and 'minimum_research_entry_percent' in runtime)
check('monthly_70_release_gate','python3 tools/check_entry70_replay.py' in read(root/'.github/workflows/build.yml'))
failed=[x['check'] for x in checks if not x['pass']]
print(json.dumps({'status':'FAIL' if failed else 'PASS','checks':len(checks),'failed':failed,
 'android_compilation_executed':False,'device_live_test_executed':False,'checks_detail':checks},ensure_ascii=False,indent=2))
if failed:sys.exit(1)

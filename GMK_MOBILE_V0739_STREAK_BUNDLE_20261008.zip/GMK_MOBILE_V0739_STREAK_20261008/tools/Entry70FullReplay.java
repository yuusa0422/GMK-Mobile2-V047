import jp.gmk.mobile.domain.r13.*;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;

/** Historical replay of the actual production Java feature/model/policy implementation. */
public class Entry70FullReplay {
    static int integer(DataInputStream in)throws IOException{return Integer.reverseBytes(in.readInt());}
    static long longValue(DataInputStream in)throws IOException{return Long.reverseBytes(in.readLong());}
    static float value(DataInputStream in)throws IOException{return Float.intBitsToFloat(integer(in));}
    static float[][] matrix(DataInputStream in,int r,int c)throws IOException{float[][] z=new float[r][c];for(float[] row:z)for(int j=0;j<c;j++)row[j]=value(in);return z;}
    static float[][][] tensor(DataInputStream in)throws IOException{float[][][] z=new float[6][][];for(int s=0;s<6;s++)z[s]=matrix(in,3,3);return z;}
    static boolean scheduled(long b){ZonedDateTime z=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"));return b%300==0&&z.getDayOfWeek().getValue()<=5&&z.getHour()>=9&&z.getHour()<=22;}
    static class Models {
        Map<String,R13Models.Neural> nn=new HashMap<>();R13Models.Xgb xgb;
        Models(Path p)throws Exception{for(String n:new String[]{"TCN","M1_TCN","M1_LSTM","M1_LINEAR","XGB"}){byte[] b=Files.readAllBytes(p.resolve(n+".bin"));if(n.equals("XGB"))xgb=new R13Models.Xgb(b,R13Models.sha256(b));else nn.put(n,new R13Models.Neural(b,R13Models.sha256(b)));}}
    }
    public static void main(String[] args)throws Exception{
        Path root=Paths.get(args[0]);Models[] models=new Models[4];for(int m=0;m<4;m++)models[m]=new Models(root.resolve("folds/2026-0"+(m+5)+"/app/src/main/assets/pc_r13"));
        LinkedHashMap<Long,float[][]> history=new LinkedHashMap<>();int changed=0,matched=0,evaluated=0,entries=0;double contextError=0;long began=System.nanoTime();
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(root.resolve("frames.bin")),1024*1024));PrintWriter out=new PrintWriter(Files.newBufferedWriter(root.resolve("java_actions.csv")))){
            if(!new String(in.readNBytes(4),java.nio.charset.StandardCharsets.US_ASCII).equals("G70F"))throw new AssertionError("format");int count=integer(in);out.println("boundary,java_action,pc_expected_action,entry,guard_fault_recovered");
            for(int n=0;n<count;n++){
                long boundary=longValue(in);int month=integer(in),base=integer(in);boolean entry=integer(in)!=0,nativeEntry=integer(in)!=0;String grade=new String[]{"S","A","B","C","E"}[integer(in)];int expected=integer(in);
                boolean[] safe=new boolean[6];for(int s=0;s<6;s++)safe[s]=in.readByte()!=0;
                float[][] rows=matrix(in,6,51),nativeFeatures=matrix(in,6,12);double[][][] bars=new double[61][11][5];for(double[][] t:bars)for(double[] s:t)for(int j=0;j<5;j++)s[j]=Double.longBitsToDouble(longValue(in));
                float[][] expectedContext=matrix(in,6,62);float[][][] rule=tensor(in);R13Features.Inputs input=R13Features.build(rows,nativeFeatures,bars);
                for(int s=0;s<6;s++)for(int j=0;j<62;j++)contextError=Math.max(contextError,Math.abs(input.context[s][j]-expectedContext[s][j]));
                int selected=base;
                if(entry && !(nativeEntry&&(grade.equals("S")||grade.equals("A")||grade.equals("B")))){
                    long deadline=System.nanoTime()+2_000_000_000L;Models m=models[month];float[][][] snapshot=null,tcn=null,mt=null,ml=null,lin=null;
                    if(!nativeEntry){snapshot=new float[6][16][51];for(int t=0;t<16;t++){long at=boundary-(15-t)*300L;boolean continuous=true;for(long b=at;b<=boundary;b+=300L)if(!scheduled(b)){continuous=false;break;}if(!continuous)continue;float[][] raw=at==boundary?input.raw:history.get(at);if(raw==null)throw new AssertionError("missing history "+at);for(int s=0;s<6;s++){System.arraycopy(raw[s],0,snapshot[s][t],0,50);snapshot[s][t][50]=1;}}tcn=m.nn.get("TCN").predict(snapshot,null,deadline);}
                    else{mt=m.nn.get("M1_TCN").predict(input.minute,input.context,deadline);ml=m.nn.get("M1_LSTM").predict(input.minute,input.context,deadline);lin=m.nn.get("M1_LINEAR").predict(input.minute,input.context,deadline);}
                    selected=R13Policy.decide(base,true,nativeEntry,grade,safe,tcn,mt,ml,lin,rule,m.xgb.predict(input.tree,deadline));evaluated++;
                }
                String id=Long.toString(boundary);
                if(EntryMaskGuard.rejectionReason(entry,entry,id,id,"AUTO","AUTO",id,id)!=null)throw new AssertionError("valid action guard");
                boolean faultRecovered=EntryMaskGuard.rejectionReason(entry,!entry,id,id,"AUTO","AUTO",id,id)!=null;
                if(!faultRecovered)throw new AssertionError("mask fault accepted");
                if(entry)entries++;if(selected!=base)changed++;if(selected==expected)matched++;
                out.println(boundary+","+selected+","+expected+","+(entry?1:0)+",1");
                history.put(boundary,input.raw);while(history.size()>16)history.remove(history.keySet().iterator().next());
                if((n+1)%1000==0)System.out.println("REPLAY frames="+(n+1)+" matched="+matched+" seconds="+((System.nanoTime()-began)/1e9));
            }
            if(in.read()!=-1)throw new AssertionError("trailing bytes");
            if(contextError>1e-5||matched!=count||!EntryMaskGuard.meetsResearchFloor(entries,count))throw new AssertionError("replay mismatch matched="+matched+"/"+count+" context="+contextError);
            System.out.println("PASS ENTRY70_FULL_REPLAY frames="+count+" actions_matching="+matched+" evaluated="+evaluated+" changed="+changed+" entries="+entries+" context_max_absolute_error="+contextError+" seconds="+((System.nanoTime()-began)/1e9));
        }
    }
}

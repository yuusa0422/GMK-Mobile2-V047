"""Read-only, time-stamped public-provider evidence; no simulated quotes.

Python 3.12; --mode stream additionally needs websockets 16.0.
An HTTPS proxy is used when the execution environment provides one.
This checks provider connectivity from the host, not an Android device.
"""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json
import math
import os
from pathlib import Path
import time
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
PROXY = os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy')
PAIRS = {'USDJPY':'JPY=X','EURJPY':'EURJPY=X','GBPJPY':'GBPJPY=X',
         'AUDJPY':'AUDJPY=X','NZDJPY':'NZDJPY=X'}

def request(url):
    started = round(time.time()*1000)
    result = {'endpoint':url,'sent_epoch_ms':started}
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({'https':PROXY}) if PROXY
                                             else urllib.request.ProxyHandler({}))
        req = urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0','Cache-Control':'no-cache'})
        with opener.open(req,timeout=12) as response:
            result['http_status'] = response.status
            body = json.load(response)
        received = round(time.time()*1000)
        result.update(received_epoch_ms=received,latency_ms=received-started)
        return result,body
    except Exception as exc:
        result['error_type'] = type(exc).__name__
        if hasattr(exc,'code'):result['http_status'] = exc.code
        result['received_epoch_ms'] = round(time.time()*1000)
        return result,None

def positive(value):
    try:
        n = float(value)
        return n if math.isfinite(n) and n>0 else None
    except (TypeError,ValueError):return None

def bitcoin():
    samples=[]
    for i in range(3):
        result,body=request('https://public.bitbank.cc/btc_jpy/ticker')
        if body:
            result['body']=body
            data=body.get('data',{});ts=data.get('timestamp',0)
            age=(result['received_epoch_ms']-ts)/1000
            bid,ask,last=(positive(data.get(k))for k in ('buy','sell','last'))
            result['provider_age_seconds']=age
            result['freshness_status']='LIVE' if body.get('success')==1 and last and bid and ask and ask>=bid and 0<=age<=15 else 'LAST'
        samples.append(result)
        if i<2:time.sleep(2)
    timestamps=[x.get('body',{}).get('data',{}).get('timestamp')for x in samples]
    return {'actual_network_request':True,'endpoint':'https://public.bitbank.cc/btc_jpy/ticker',
            'samples':samples,'environment_live_feed_verified':all(x.get('freshness_status')=='LIVE'for x in samples),
            'provider_timestamp_advanced':None not in timestamps and len(set(timestamps))==3}

def forex_pair(pair):
    attempts=[]
    for host in ('query2.finance.yahoo.com','query1.finance.yahoo.com'):
        now=int(time.time());symbol=urllib.parse.quote(PAIRS[pair],safe='=')
        query=urllib.parse.urlencode({'interval':'1m','period1':now-600,'period2':now+60,'includePrePost':'true','events':'history'})
        result,body=request(f'https://{host}/v8/finance/chart/{symbol}?{query}')
        if body:
            try:
                data=body['chart']['result'][0];meta=data.get('meta',{})
                received=result['received_epoch_ms'];quotes=[]
                for ts,p in zip(data.get('timestamp',[]),data.get('indicators',{}).get('quote',[{}])[0].get('close',[])):
                    if positive(p) and 0<ts*1000<=received:quotes.append((ts*1000,p))
                ts=meta.get('regularMarketTime',0)*1000;p=meta.get('regularMarketPrice')
                if positive(p) and 0<ts<=received:quotes.append((ts,p))
                if quotes:
                    ts,p=max(quotes,key=lambda x:x[0]);age=(received-ts)/1000
                    result.update(source_epoch_ms=ts,price=p,provider_age_seconds=age,
                                  freshness_status='LIVE'if age<=20 else 'LAST')
                else:result['freshness_status']='UNAVAILABLE'
            except (KeyError,TypeError,IndexError):result['freshness_status']='UNAVAILABLE'
        attempts.append(result)
        if result.get('freshness_status')=='LIVE':break
    return {'instrument':pair,'actual_network_request':True,'attempts':attempts}

def forex():
    with ThreadPoolExecutor(max_workers=5)as pool:rows=list(pool.map(forex_pair,PAIRS))
    return {'actual_network_request':True,'samples':rows,
            'all_five_real_time':all(x['attempts'][-1].get('freshness_status')=='LIVE'for x in rows)}

async def stream():
    result={'endpoint':'wss://stream.bitbank.cc/socket.io/?EIO=4&transport=websocket',
            'actual_network_request':True,'connected':False,'subscribed':False,
            'samples':[],'environment_stream_verified':False}
    try:
        import websockets
        async with websockets.connect(result['endpoint'],proxy=PROXY,open_timeout=12,close_timeout=2,max_size=65536)as ws:
            result['connected']=True;deadline=time.monotonic()+28
            while len(result['samples'])<3 and time.monotonic()<deadline:
                packet=await asyncio.wait_for(ws.recv(),timeout=max(1,deadline-time.monotonic()))
                if packet.startswith('0'):
                    result['engine_open']=json.loads(packet[1:]);await ws.send('40')
                elif packet.startswith('40'):
                    await ws.send('42["join-room","ticker_btc_jpy"]');result['subscribed']=True
                elif packet=='2':await ws.send('3')
                elif packet.startswith('42'):
                    p=json.loads(packet[2:])
                    if p[0]=='message' and p[1].get('room_name')=='ticker_btc_jpy':
                        d=p[1]['message']['data'];received=round(time.time()*1000)
                        result['samples'].append({'received_epoch_ms':received,'provider_timestamp_ms':d.get('timestamp'),
                            'provider_age_seconds':(received-d['timestamp'])/1000,
                            'last':d.get('last'),'buy':d.get('buy'),'sell':d.get('sell')})
        result['environment_stream_verified']=len(result['samples'])==3 and all(0<=x['provider_age_seconds']<=15 for x in result['samples'])
        result['provider_timestamp_advanced']=len(set(x['provider_timestamp_ms']for x in result['samples']))==3
    except Exception as exc:
        result['error_type']=type(exc).__name__
        response=getattr(exc,'response',None)
        if response is not None:result['http_status']=getattr(response,'status_code',None)
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['btc','forex','stream','all'],default='all')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'release_evidence/v0738_full_audit')
    args=parser.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    actions={'btc':('LIVE_BTC_PROVIDER_PROBE.json',bitcoin),'forex':('LIVE_FOREX_PROVIDER_PROBE.json',forex),
             'stream':('LIVE_BTC_WEBSOCKET_PROBE.json',lambda:asyncio.run(stream()))}
    for mode,(name,action)in actions.items():
        if args.mode not in ('all',mode):continue
        result=action();(args.output_dir/name).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps({'mode':mode,'result':result},ensure_ascii=False))

if __name__=='__main__':main()

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import jp.gmk.mobile.data.HorizonMarketCache
import java.io.*
import java.nio.file.Files
import java.security.MessageDigest
import java.time.*

private fun digest(b: ByteArray)=MessageDigest.getInstance("SHA-256").digest(b).joinToString(""){"%02x".format(it)}
private fun constantModel(names: List<String>, leaves: DoubleArray): PortableTreeModel {
    val buffer=ByteArrayOutputStream()
    DataOutputStream(buffer).use { out->
        out.writeBytes("GMKTREE1");out.writeInt(names.size);out.writeInt(leaves.size);out.writeInt(leaves.size)
        for(n in names){val b=n.toByteArray();out.writeInt(b.size);out.write(b)}
        for(v in leaves){out.writeInt(1);out.writeInt(-1);out.writeDouble(0.0);out.writeBoolean(false);out.writeBoolean(false);out.writeInt(-1);out.writeInt(-1);out.writeDouble(v)}
    }
    return PortableTreeModel.load(buffer.toByteArray(),digest(buffer.toByteArray()))
}
fun main(args: Array<String>) {
    val assets=File(args[0]);fun load(n: String)=PortableTreeModel.load(File(assets,n).readBytes(),HorizonModelCatalog.hashes.getValue(n))
    val originals=listOf(3,10,15).map { load("base_${it}m.bin") };val correction=load("r15_path_protect15.bin")
    // Build continuous causal input through B-120 for all19 symbols; no future price rows.
    val b=ZonedDateTime.parse("2026-10-01T12:00:00+09:00").toEpochSecond()
    val prices=HorizonFeatureService.SYMBOLS.mapIndexed { s,name->name to (0 until 5000).map { i->
        val t=(b-120-(4999-i)*60)*1000;val o=100.0+s+i*.0001;Candle(t,o,o+.02,o-.01,o+.003,1.0)
    }}.toMap()
    val ctx=prices.filterKeys { it in HorizonFeatureService.SYMBOLS.take(6) }.mapValues { it.value.takeLast(120) }
    val entry=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
    val native=LocalRuleEngine().scan(ctx,"AUTO",entry.minusSeconds(10),entry)
    val asSkip=native.copy(candidates=native.candidates.map { if(it.rank==1)it.copy(grade="E",decision="SKIP")else it })
    val asEntry=native.copy(candidates=native.candidates.map { if(it.rank==1)it.copy(grade="A",decision="ENTRY")else it })
    val quotes=HorizonFeatureService.SYMBOLS.take(6).associateWith { s->HorizonQuote((b-11)*1000,(b-12)*1000,prices.getValue(s).last().close,null,null,true) }
    val models=originals.mapIndexed { j,m->constantModel(m.featureNames,doubleArrayOf(0.0,-5.0,if(j==2)5.0 else 0.0)) }
    val flip=constantModel(correction.featureNames,doubleArrayOf(.05))
    fun adapter()=HorizonScanAdapter(models,flip)
    fun frame(): PreparedHorizonFrame { val service=HorizonFeatureService(prices,emptyMap(),b,LocalRuleEngine());val cols=models.mapIndexed { j,m->service.jointFeatures(m.featureNames,listOf(3,10,15)[j]) };return PreparedHorizonFrame(b,service,Array(6){s->Array(3){j->cols[j][s]}},(b-20)*1000) }
    val protected=adapter();check(protected.apply(asEntry,ctx,null,quotes,b*1000-1)==asEntry)
    val missingQuote=adapter().apply(asEntry,ctx,null,emptyMap(),(b-5)*1000)
    check(missingQuote.top1!!.decision=="SKIP")
    val unsafeSymbol=asEntry.top1!!.instrument
    val alternatives=adapter().apply(asEntry,ctx,frame(),quotes-unsafeSymbol,(b-5)*1000)
    check(alternatives.top1!!.decision=="ENTRY" && alternatives.top1!!.instrument!=unsafeSymbol)
    check(adapter().apply(asSkip,ctx,null,quotes,(b-5)*1000)==asSkip)
    val policy=adapter();val r=policy.apply(asSkip,ctx,frame(),quotes,(b-5)*1000)
    check(r.top1!!.decision=="ENTRY" && r.top1!!.grade=="R" && r.top1!!.instrument=="USDJPY" && r.top1!!.direction=="LOW")
    check(Duration.between(ZonedDateTime.parse(r.entryTimeJst),ZonedDateTime.parse(r.judgeTimeJst)).toMinutes()==3L)
    check(policy.status=="R15_APPLIED" && r.candidates.map { it.rank }.toSet()==(1..6).toSet())
    val before=policy.snapshot();check(policy.apply(asSkip,ctx,null,emptyMap(),b*1000)==r);check(policy.snapshot()==before)
    val stale=quotes.mapValues { (_,q)->q.copy(sourceMs=(b-21)*1000) }
    check(adapter().apply(asSkip,ctx,frame(),stale,(b-5)*1000)==asSkip)
    val future=quotes.mapValues { (_,q)->q.copy(receivedMs=(b-9)*1000) }
    check(adapter().apply(asSkip,ctx,frame(),future,(b-5)*1000)==asSkip)
    check(adapter().apply(asSkip,ctx,frame(),quotes,b*1000-499)==asSkip)
    check(adapter().apply(asSkip.copy(source="MANUAL"),ctx,frame(),quotes,(b-5)*1000).source=="MANUAL")
    val nativeSymbol=native.top1!!.instrument;val revised=ctx+mapOf(nativeSymbol to ctx.getValue(nativeSymbol).dropLast(1))
    check(adapter().apply(asSkip,revised,frame(),quotes,(b-5)*1000)==asSkip)
    for((j,h) in listOf(3,10,15).withIndex()) {
        val m=originals.mapIndexed { k,x->constantModel(x.featureNames,doubleArrayOf(0.0,-5.0,if(j==k)5.0 else 0.0)) }
        val a=HorizonScanAdapter(m,constantModel(correction.featureNames,doubleArrayOf(-.1)))
        val out=a.apply(asSkip,ctx,frame(),quotes,(b-5)*1000)
        check(Duration.between(ZonedDateTime.parse(out.entryTimeJst),ZonedDateTime.parse(out.judgeTimeJst)).toMinutes()==h.toLong())
    }
    val row=HistoryRow(1,"one","AUTO",entry.toString(),"USDJPY","HIGH","R","ENTRY",entryTimeJst=entry.toString(),judgeTimeJst=entry.plusMinutes(15).toString())
    val other=ScanResult(scanId="two",source="AUTO",entryTimeJst=entry.plusMinutes(5).toString(),judgeTimeJst=entry.plusMinutes(15).toString())
    check(!HistoryIdentity.sameAutoFrame(row,other));check(HistoryIdentity.sameAutoFrame(row,other.copy(entryTimeJst=entry.toString())))
    check(!HistoryIdentity.sameAutoFrame(row,other.copy(source="AUTO_1M",entryTimeJst=entry.toString())))
    val dir=Files.createTempDirectory("horizon-cache-test").toFile()
    val cache=HorizonMarketCache(dir);cache.merge("USDJPY",prices.getValue("USDJPY")+Candle(b*1000,1.0,1.0,1.0,1.0),b*1000-10_000)
    check(cache.size("USDJPY")==5000);cache.persist("USDJPY");val reloaded=HorizonMarketCache(dir);reloaded.load("USDJPY");check(cache.snapshot()==reloaded.snapshot())
    val rate=RateRow("USDJPY",100.0,null,null,"TEST",1.0,"LIVE",sourceEpochMs=(b-12)*1000,receivedEpochMs=(b-11)*1000)
    cache.observe(listOf(rate));cache.observe(listOf(rate.copy(sourceEpochMs=(b-9)*1000,receivedEpochMs=(b-8)*1000)))
    check(cache.quoteSnapshot((b-10)*1000).getValue("USDJPY").sourceMs==(b-12)*1000)
    dir.deleteRecursively()
    val warmFrame=frame();val times=mutableListOf<Double>()
    repeat(110) { i->
        val a=HorizonScanAdapter(originals,correction);val started=System.nanoTime()
        a.apply(asSkip,ctx,warmFrame,quotes,(b-5)*1000)
        if(i>=10)times.add((System.nanoTime()-started)/1e6)
    }
    times.sort()
    println("BENCHMARK real_model_adapter samples=100 median_ms=${times[49]} p95_ms=${times[94]} max_ms=${times.last()} excludes_network_and_background_prepare=true device=JVM_container")
    println("PASS horizon integration: real adapter activation, native ENTRY protection, 3/10/15 timing, 15-to3 reverse, duplicate boundary, stale/future quotes, missing input, deadline, revision, history collision, cache restart")
}

import android.content.Context
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.domain.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.annotation.*
import java.time.ZonedDateTime

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
@LooperMode(LooperMode.Mode.PAUSED)
class HistoryPipelineAuditTest {
    private val app get()=RuntimeEnvironment.getApplication()
    private val stores=mutableListOf<HistoryStore>()
    @Before fun setup() { listOf("gmk_mobile_history","gmk_mobile_history_journal").forEach { app.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit() } }
    @After fun flush() {
        for(store in stores) {
            val end=System.nanoTime()+3_000_000_000L
            while((store.diagnosticStats().getBoolean("write_pending") || store.diagnosticStats().getBoolean("writer_active")) && System.nanoTime()<end)Thread.sleep(5)
        }
    }
    private fun store()=HistoryStore(app).also { stores+=it }
    private fun result():ScanResult {
        val at=ZonedDateTime.parse("2026-10-08T09:05:00+09:00")
        return ScanResult("btc-five",at.minusSeconds(10).toString(),at.toString(),at.plusMinutes(5).toString(),
            listOf(ScanCandidate(1,"BTCJPY","BTC/JPY","LOW","C",null,"ENTRY")),source="AUTO",policyVersion="GMK_V0736_DIRECT19_C_3_5")
    }
    @Test fun anInvalidNewPendingResultCannotKeepTheRuntimeAlive() {
        val store=store();store.add(result().copy(entryTimeJst="",judgeTimeJst=""))
        assertTrue("Validation must run before a new row enters the live tracking queue",store.pending().isEmpty())
        assertEquals("INVALID_TIMING_DATA",store.load().single().resultStatus)
    }
    @Test fun replayedAiSignalsCannotEraseASettledFiveMinuteOutcome() {
        val store=store();val r=result();store.add(r)
        store.updateEntryRate(r.scanId,10_000_000.0,"test",r.entryTimeJst,0,0.0)
        store.settle(r.scanId,9_999_990.0,"test",r.judgeTimeJst,0,0.0)
        store.add(r.copy(judgeTimeJst=ZonedDateTime.parse(r.entryTimeJst).plusMinutes(3).toString(),candidates=listOf(r.top1!!.copy(instrument="USDJPY",direction="HIGH"))))
        store.add(r.copy(scanId="another-id-same-auto-boundary"))
        val row=store.load().single();assertEquals("WIN",row.resultStatus);assertEquals("BTCJPY",row.instrument)
        assertEquals(r.judgeTimeJst,row.judgeTimeJst);assertTrue(store.pending().isEmpty())
        assertEquals(1,historyStatistics(store.load()).getValue(5).wins)
        assertEquals(row,HistoryStore(app).load().single())
    }
    @Test fun nonfiniteQuotesCannotResolveAnEntryAndADrawRemainsALossAfterReload() {
        val store=store();val r=result();store.add(r)
        store.updateEntryRate(r.scanId,Double.NaN,"test",r.entryTimeJst,0,0.0)
        assertEquals("WAIT_ENTRY",store.pending().single().resultStatus)
        store.updateEntryRate(r.scanId,10_000_000.0,"test",r.entryTimeJst,0,Double.NaN)
        assertEquals("WAIT_ENTRY",store.pending().single().resultStatus)
        store.updateEntryRate(r.scanId,10_000_000.0,"test",r.entryTimeJst,0,0.0)
        store.settle(r.scanId,Double.POSITIVE_INFINITY,"test",r.judgeTimeJst,0,0.0)
        assertEquals("WAIT_JUDGE",store.pending().single().resultStatus)
        store.settle(r.scanId,10_000_000.0,"test",r.judgeTimeJst,0,0.0)
        val reloaded=HistoryStore(app).load();assertEquals("LOSE",reloaded.single().resultStatus)
        val stats=historyStatistics(reloaded).getValue(5);assertEquals(1,stats.losses);assertEquals(1,stats.draws)
    }
}

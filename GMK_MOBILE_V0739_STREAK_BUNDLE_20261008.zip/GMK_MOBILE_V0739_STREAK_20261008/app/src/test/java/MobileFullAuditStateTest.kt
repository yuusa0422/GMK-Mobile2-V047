import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModelStore
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.runtime.GmkRuntimeServiceControl
import jp.gmk.mobile.ui.GmkViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestCoroutineScheduler
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.test.resetMain
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowSystemClock
import java.time.Duration
import java.time.ZonedDateTime

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
@LooperMode(LooperMode.Mode.PAUSED)
@OptIn(ExperimentalCoroutinesApi::class)
class MobileFullAuditStateTest {
    private lateinit var app: Application
    private val scheduler=TestCoroutineScheduler()
    private val stores=mutableListOf<ViewModelStore>()
    @Before fun setup() {
        app=RuntimeEnvironment.getApplication()
        listOf("gmk_mobile_local","gmk_mobile_history","gmk_mobile_history_journal","gmk_runtime_service")
            .forEach { app.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit() }
        AppPrefs(app).apply { autoScan=false;oneMinuteAutoScan=false }
        GmkRuntimeServiceControl.markStopped()
        Dispatchers.setMain(StandardTestDispatcher(scheduler))
    }
    @After fun cleanup() { stores.forEach { it.clear() };scheduler.runCurrent();Dispatchers.resetMain();GmkRuntimeServiceControl.markStopped() }
    private fun vm():GmkViewModel=GmkViewModel(app).also { it.shutdownRuntime();stores+=ViewModelStore().apply { put("full-audit",it) } }
    @Test fun activeBoundaryCannotBeReclaimedAfterShortLeaseExpires() {
        ShadowSystemClock.advanceBy(Duration.ofMillis(10))
        val a=AppPrefs(app);val key="2026-10-08T09:11"
        assertTrue(a.claimOneMinuteBoundary(key))
        ShadowSystemClock.advanceBy(Duration.ofSeconds(3))
        assertFalse("The same process must retain ownership while its 8s scan is still running",AppPrefs(app).claimOneMinuteBoundary(key))
        a.releaseOneMinuteBoundary(key);assertTrue(a.claimOneMinuteBoundary(key));a.completeOneMinuteBoundary(key)
        assertFalse(a.claimOneMinuteBoundary(key))
        assertTrue(a.claimThreeMinuteBoundary(key));ShadowSystemClock.advanceBy(Duration.ofSeconds(3))
        assertFalse(AppPrefs(app).claimThreeMinuteBoundary(key));a.releaseThreeMinuteBoundary(key)
    }
    private fun seed(entry:String,judge:String,status:String="WAIT_ENTRY") {
        val row=JSONObject().put("id",1).put("scan_id","bad-time").put("source","AUTO")
            .put("at_jst","2026-10-08T09:04:50+09:00").put("instrument","USDJPY").put("direction","HIGH")
            .put("grade","C").put("decision","ENTRY").put("entry_time_jst",entry).put("judge_time_jst",judge)
            .put("result_status",status)
        if(status=="WAIT_JUDGE")row.put("entry_rate",150.0)
        app.getSharedPreferences("gmk_mobile_history",Context.MODE_PRIVATE).edit().putString("items",JSONArray().put(row).toString()).commit()
    }
    @Test fun missingTimesCannotLeaveUntrackablePendingRow() {
        seed("","");val store=HistoryStore(app)
        assertTrue("Untrackable rows cannot keep the foreground service running forever",store.pending().isEmpty())
        assertEquals("INVALID_TIMING_DATA",store.load().single().resultStatus)
    }
    @Test fun reversedJudgeTimeCannotEnterOutcomeRecovery() {
        seed("2026-10-08T09:05:00+09:00","2026-10-08T09:04:00+09:00","WAIT_JUDGE")
        val store=HistoryStore(app);assertTrue(store.pending().isEmpty());assertEquals("INVALID_TIMING_DATA",store.load().single().resultStatus)
    }
    @Test fun outsideSessionDoesNotReserveNetworkForScanThatCannotRun() {
        val model=vm();AppPrefs(app).apply { autoScan=true;oneMinuteAutoScan=true }
        val method=GmkViewModel::class.java.getDeclaredMethod("shouldReserveYahooForUpcomingAuto",ZonedDateTime::class.java).apply { isAccessible=true }
        fun reserves(at:String)=method.invoke(model,ZonedDateTime.parse(at)) as Boolean
        assertFalse(reserves("2026-10-08T08:44:45+09:00"))
        assertTrue(reserves("2026-10-08T08:59:45+09:00"))
        assertTrue(reserves("2026-10-08T22:54:45+09:00"))
        assertFalse(reserves("2026-10-08T22:59:45+09:00"))
    }
    @Test fun serviceLifecycleUpdatesStatusWithoutReopeningActivity() {
        val model=vm();val field=GmkViewModel::class.java.getDeclaredField("historyInitialized").apply { isAccessible=true }
        val end=System.nanoTime()+3_000_000_000L
        while(!field.getBoolean(model)&&System.nanoTime()<end) { scheduler.runCurrent();Thread.sleep(5) }
        scheduler.runCurrent();assertTrue(field.getBoolean(model));assertFalse(model.state.value.runtimeServiceRunning)
        GmkRuntimeServiceControl.markStarted(app);scheduler.runCurrent()
        assertTrue("Service start must reach the already open status screen",model.state.value.runtimeServiceRunning)
        GmkRuntimeServiceControl.markStopped();scheduler.runCurrent();assertFalse(model.state.value.runtimeServiceRunning)
    }
}

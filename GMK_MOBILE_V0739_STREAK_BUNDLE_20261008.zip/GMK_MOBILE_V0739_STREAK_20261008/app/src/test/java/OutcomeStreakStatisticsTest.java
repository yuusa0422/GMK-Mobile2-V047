import jp.gmk.mobile.domain.OutcomeStatistics;
import org.junit.Test;
import static org.junit.Assert.*;
import java.time.ZonedDateTime;
import java.util.*;

public class OutcomeStreakStatisticsTest {
    private static OutcomeStatistics.Row row(int index, int horizon, String decision, String status) {
        ZonedDateTime at=ZonedDateTime.parse("2026-10-08T09:00:00+09:00").plusMinutes(index*6L);
        return new OutcomeStatistics.Row(decision,status,at.toString(),at.plusMinutes(horizon).toString(),"CURRENT",100.0,status.equals("WIN")?101.0:99.0);
    }
    @Test public void newestFirstHistoryIsSortedBeforeCounting() {
        List<OutcomeStatistics.Row> rows=Arrays.asList(row(4,5,"ENTRY","LOSE"),row(3,5,"ENTRY","LOSE"),row(2,5,"ENTRY","WIN"),row(1,5,"ENTRY","LOSE"));
        OutcomeStatistics.Summary s=OutcomeStatistics.byHorizon(rows).get(5);
        assertEquals(1,s.wins);assertEquals(3,s.losses);assertEquals(2,s.currentLossStreak);assertEquals(2,s.maxConsecutiveLosses);
    }
    @Test public void skipPendingAndMissingDoNotResetRealLosses() {
        List<OutcomeStatistics.Row> rows=Arrays.asList(row(1,5,"ENTRY","LOSE"),row(2,5,"SKIP","WIN"),row(3,5,"ENTRY","WAIT_JUDGE"),row(4,5,"ENTRY","JUDGE_RATE_MISSED"),row(5,5,"ENTRY","LOSE"));
        OutcomeStatistics.Summary s=OutcomeStatistics.overall(rows);
        assertEquals(2,s.currentLossStreak);assertEquals(1,s.skips);assertEquals(1,s.skipShadow);assertEquals(1,s.pending);assertEquals(1,s.missed);
    }
    @Test public void midnightAndDifferentOffsetsKeepOneSequence() {
        OutcomeStatistics.Row first=new OutcomeStatistics.Row("ENTRY","LOSE","2026-10-08T23:58:00+09:00","2026-10-09T00:03:00+09:00","CURRENT",100.0,99.0);
        OutcomeStatistics.Row second=new OutcomeStatistics.Row("ENTRY","LOSE","2026-10-08T15:00:00Z","2026-10-08T15:05:00Z","CURRENT",100.0,99.0);
        OutcomeStatistics.Summary s=OutcomeStatistics.overall(Arrays.asList(second,first));
        assertEquals(2,s.maxConsecutiveLosses);assertEquals(2,s.currentLossStreak);
    }
    @Test public void drawsRemainLosses() {
        OutcomeStatistics.Row loss=new OutcomeStatistics.Row("ENTRY","LOSE","2026-10-08T09:00:00+09:00","2026-10-08T09:05:00+09:00","CURRENT",100.0,100.0);
        OutcomeStatistics.Summary s=OutcomeStatistics.overall(Collections.singletonList(loss));
        assertEquals(1,s.draws);assertEquals(1,s.losses);assertEquals(1,s.currentLossStreak);assertEquals(0.0,s.winRate(),0.0);
    }
    @Test public void combinedAndHorizonLossesAreDifferent() {
        List<OutcomeStatistics.Row> rows=Arrays.asList(row(1,5,"ENTRY","LOSE"),row(2,3,"ENTRY","LOSE"),row(3,10,"ENTRY","LOSE"));
        assertEquals(3,OutcomeStatistics.overall(rows).maxConsecutiveLosses);
        for(int m:new int[]{3,5,10})assertEquals(1,OutcomeStatistics.byHorizon(rows).get(m).maxConsecutiveLosses);
    }
    @Test public void longRunsAreCountedOnceAndUnknownTimingIsExcluded() {
        List<OutcomeStatistics.Row> rows=new ArrayList<>();
        for(int i=0;i<5;i++)rows.add(row(i,5,"ENTRY","LOSE"));
        rows.add(row(5,5,"ENTRY","WIN"));
        for(int i=6;i<13;i++)rows.add(row(i,5,"ENTRY","LOSE"));
        rows.add(new OutcomeStatistics.Row("ENTRY","WIN","unknown","unknown","LEGACY",100.0,101.0));
        Collections.reverse(rows);
        OutcomeStatistics.Summary s=OutcomeStatistics.overall(rows);
        assertEquals(7,s.currentLossStreak);assertEquals(7,s.maxConsecutiveLosses);assertEquals(2,s.runsAtLeast3);assertEquals(2,s.runsAtLeast5);assertEquals(1,s.wins);
    }
}

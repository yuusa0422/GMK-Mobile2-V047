import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.direct19.*
import jp.gmk.mobile.domain.horizon.*
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.*
import java.time.*
import kotlin.math.abs

class Direct19IntegrationTest {
    private val root=File(requireNotNull(System.getProperty("gmk.projectRoot")))
    private val b=ZonedDateTime.parse("2026-10-08T12:00:00+09:00").toEpochSecond()
    private fun model(name: String)=Direct19Model.load(File(root,"app/src/main/assets/direct19/$name").readBytes(),Direct19Catalog.hashes.getValue(name))
    private fun adapter()=Direct19ScanAdapter(model("hgb_3m.bin"),model("hgb_5m.bin"))
    private fun prices()=Direct19Policy.TRADED.associateWith {
        (0 until 120).map { i->Candle((b-120-(119-i)*60)*1000,100.0,100.01,99.99,100.0,1.0) }
    }
    private fun frame(prices: Map<String,List<Candle>>): Direct19Frame {
        val p=Array(4) { Array(2) { floatArrayOf(.4f,.2f,.4f) } }
        p[0][0]=floatArrayOf(.2f,.2f,.6f)
        p[3][0]=floatArrayOf(.1f,.1f,.8f)
        p[2][1]=floatArrayOf(.01f,.01f,.98f)
        return Direct19Frame(Direct19Input(b,Array(4) { FloatArray(165) },BooleanArray(4) { true },prices),p,(b-20)*1000)
    }
    private fun quotes()=Direct19Policy.TRADED.associateWith { HorizonQuote((b-11)*1000,(b-12)*1000,100.0,99.999,100.001,true) }
    private fun native(grade: String="C",decision: String="ENTRY"): ScanResult {
        val at=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
        return ScanResult("live",at.minusSeconds(10).toString(),at.toString(),at.plusMinutes(3).toString(),
            Direct19Policy.TRADED.mapIndexed { i,s->ScanCandidate(i+1,s,s,"LOW",if(i==0)grade else "C",null,if(i==0)decision else "SKIP") },source="AUTO")
    }
    private fun duration(result: ScanResult)=Duration.between(ZonedDateTime.parse(result.entryTimeJst),ZonedDateTime.parse(result.judgeTimeJst)).toMinutes()

    @Test fun actualKotlinFeaturesMatchObservedResearchAndRejectFutureRows() {
        val path=System.getProperty("gmk.direct19Fixture")
        assertTrue("Bundled observed-price fixture is required",path != null && File(path).isFile())
        var maxError=0.0;var values=0;var cases=0
        DataInputStream(BufferedInputStream(File(path!!).inputStream())).use { input->
            repeat(input.readInt()) {
                val boundary=input.readLong()
                val prices=LinkedHashMap<String,List<Candle>>()
                repeat(input.readInt()) {
                    val symbol=input.readUTF()
                    prices[symbol]=List(input.readInt()) { Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble()) }
                }
                val expected=Array(4) { FloatArray(165) { input.readFloat() } }
                val actual=HorizonFeatureService(prices,emptyMap(),boundary,LocalRuleEngine()).direct19Input()
                for(s in 0..3)for(j in 0..164) {
                    val a=actual.features[s][j];val e=expected[s][j]
                    if(e.isNaN()) assertTrue("boundary=$boundary symbol=$s feature=$j expected NaN got $a",a.isNaN())
                    else {
                        assertTrue("boundary=$boundary symbol=$s feature=$j nonfinite $a",a.isFinite())
                        val error=abs(a.toDouble()-e.toDouble());maxError=maxOf(maxError,error)
                        assertEquals("boundary=$boundary symbol=$s feature=$j",e.toDouble(),a.toDouble(),3e-5)
                    }
                    values++
                }
                val poisoned=prices.mapValues { (_,rows)->
                    val last=rows.last(); rows+listOf(boundary-60,boundary,boundary+300).map { t->
                        Candle(t*1000,last.open*2,last.high*2,last.low*2,last.close*2,last.volume*3)
                    }
                }
                val future=HorizonFeatureService(poisoned,emptyMap(),boundary,LocalRuleEngine()).direct19Input()
                for(s in 0..3)assertArrayEquals("future rows changed completed inputs",actual.features[s],future.features[s],0f)
                cases++
            }
            assertEquals(-1,input.read())
        }
        File(root,"DIRECT19_KOTLIN_FEATURE_AUDIT.json").writeText("{\"status\":\"PASS\",\"cases\":$cases,\"values\":$values,\"max_absolute_error\":$maxError,\"future_poison_cases\":$cases}\n")
    }

    @Test fun autoAndFixedThreeChooseTheirOwnActionsAndPreserveEntry() {
        val rows=prices();val n=native();val auto=adapter().apply(n,rows,frame(rows),quotes(),false,(b-5)*1000)
        assertEquals("GBPJPY",auto.top1!!.instrument);assertEquals("HIGH",auto.top1!!.direction);assertEquals(5L,duration(auto))
        val fixed=adapter().apply(n,rows,frame(rows),quotes(),true,(b-5)*1000)
        assertEquals("AUDJPY",fixed.top1!!.instrument);assertEquals(3L,duration(fixed));assertTrue(fixed.policyVersion.endsWith("_3M_FIXED"))
        for(r in listOf(auto,fixed)) {
            assertEquals(n.scanId,r.scanId);assertEquals(n.entryTimeJst,r.entryTimeJst);assertEquals("AUTO",r.source)
            assertEquals("ENTRY",r.top1!!.decision);assertEquals(4,r.candidates.map { it.instrument }.toSet().size)
            assertEquals(listOf(1,2,3,4),r.candidates.map { it.rank })
        }
    }

    @Test fun deadlinesQuotesAndRevisionFallBackAndProtectNativeDecisions() {
        val rows=prices();val n=native()
        fun unchanged(frame: Direct19Frame?=frame(rows),q: Map<String,HorizonQuote> =quotes(),candles: Map<String,List<Candle>> =rows,time: Long=(b-5)*1000) {
            val result=adapter().apply(n,candles,frame,q,false,time)
            assertEquals(n.candidates,result.candidates);assertEquals(n.judgeTimeJst,result.judgeTimeJst)
            assertTrue(result.policyVersion.startsWith(Direct19ScanAdapter.FALLBACK))
        }
        unchanged(frame=null)
        unchanged(q=quotes().mapValues { (_,q)->q.copy(sourceMs=(b-21)*1000) })
        unchanged(q=quotes().mapValues { (_,q)->q.copy(receivedMs=(b-9)*1000) })
        unchanged(candles=rows+mapOf("USDJPY" to rows.getValue("USDJPY").dropLast(1)))
        unchanged(time=b*1000-799)
        for(grade in listOf("S","A","B")) {
            val protected=native(grade)
            assertEquals(protected.candidates,adapter().apply(protected,rows,frame(rows),quotes(),false,(b-5)*1000).candidates)
        }
        val skipped=native(decision="SKIP")
        assertEquals("SKIP",adapter().apply(skipped,rows,frame(rows),quotes(),false,(b-5)*1000).top1!!.decision)
        val manual=n.copy(source="MANUAL")
        assertEquals(manual,adapter().apply(manual,rows,frame(rows),quotes(),false,(b-5)*1000))
        assertFalse(Direct19ScanAdapter.supports(ZonedDateTime.parse("2026-10-08T18:00:00+09:00").toEpochSecond()))
    }

    @Test fun repeatScanCannotReuseEntryAfterNativeChangesToSkip() {
        val a=adapter();val rows=prices();val n=native()
        val first=a.apply(n,rows,frame(rows),quotes(),false,(b-5)*1000)
        assertEquals(first,a.apply(n,rows,frame(rows),quotes(),false,(b-5)*1000))
        assertEquals(3L,duration(a.apply(n,rows,frame(rows),quotes(),true,(b-5)*1000)))
        val skipped=native(decision="SKIP")
        assertEquals("SKIP",a.apply(skipped,rows,frame(rows),quotes(),false,(b-5)*1000).top1!!.decision)
    }

    @Test fun fiveMinuteHistoryCountsDrawAsNonwinAndSeparatesOldPolicies() {
        val at=Instant.ofEpochSecond(b).atZone(ZoneId.of("Asia/Tokyo"))
        val rows=listOf(
            OutcomeStatistics.Row("ENTRY","WIN",at.toString(),at.plusMinutes(5).toString(),Direct19Policy.VERSION,100.0,100.1),
            OutcomeStatistics.Row("ENTRY","LOSE",at.toString(),at.plusMinutes(5).toString(),Direct19Policy.VERSION,100.0,100.0),
            OutcomeStatistics.Row("SKIP","WIN",at.toString(),at.plusMinutes(5).toString(),Direct19Policy.VERSION,100.0,100.1))
        val summary=OutcomeStatistics.byHorizon(rows).getValue(5)
        assertEquals(1,summary.wins);assertEquals(1,summary.losses);assertEquals(1,summary.draws);assertEquals(1,summary.skips)
        assertEquals(50.0,summary.winRate()!!,0.0)
        val old=HistoryRow(1,source="AUTO",atJst=at.toString(),instrument="USDJPY",direction="HIGH",grade="C",decision="ENTRY",policyVersion="GMK_V0735_PC_R13")
        assertFalse(ExpiryProfiles.includes(old,false,false));assertTrue(ExpiryProfiles.includes(old,false,true))
    }

    @Test fun corruptedModelMustFailHashCheck() {
        val bytes=File(root,"app/src/main/assets/direct19/hgb_3m.bin").readBytes();bytes[20]=(bytes[20].toInt() xor 1).toByte()
        try { Direct19Model.load(bytes,Direct19Catalog.hashes.getValue("hgb_3m.bin"));fail("corrupted model accepted") }
        catch(expected: IOException) { assertEquals("DIRECT19_MODEL_SHA",expected.message) }
    }
}

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.direct19.*
import jp.gmk.mobile.domain.horizon.*
import org.junit.Assert.*
import org.junit.Test
import java.io.*
import java.time.*
import kotlin.math.abs

/** Real observed OHLC + production rule engine + actual frozen HGB assets.
 * Only the date/clock is moved into the model availability window; prices are unchanged.
 * This checks operation, not out-of-sample accuracy or a trading return.
 */
internal object RuleAiObservedFixture {
    val root=File(requireNotNull(System.getProperty("gmk.projectRoot")))
    val target=ZonedDateTime.parse("2026-10-08T14:00:00+09:00").toEpochSecond()
    data class Observed(val boundary:Long,val prices:Map<String,List<Candle>>)
    val frames:List<Observed> by lazy {
        DataInputStream(BufferedInputStream(File(requireNotNull(System.getProperty("gmk.direct19Fixture"))).inputStream())).use { input ->
            List(input.readInt()) {
                val b=input.readLong();val prices=linkedMapOf<String,List<Candle>>()
                repeat(input.readInt()) {
                    val symbol=input.readUTF()
                    prices[symbol]=List(input.readInt()) { Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble()) }
                }
                repeat(4*165) { input.readFloat() }
                Observed(b,prices)
            }.also { check(input.read()==-1) }
        }
    }
    fun at(case:Int,slot:Int=0):Observed {
        val original=frames[case];val delta=(target-original.boundary)*1000
        return Observed(target-slot*300,original.prices.mapValues { (_,bars)->bars.map { it.copy(timeEpochMs=it.timeEpochMs+delta) } })
    }
    fun native(observed:Observed):Pair<ScanResult,Map<String,List<Candle>>> {
        val candles=HorizonFeatureService.SYMBOLS.take(6).associateWith { symbol ->
            observed.prices.getValue(symbol).filter { it.timeEpochMs/1000<=observed.boundary-120 }.takeLast(120)
        }
        val at=Instant.ofEpochSecond(observed.boundary).atZone(ZoneId.of("Asia/Tokyo"))
        return LocalRuleEngine().scan(candles,"AUTO",at.minusSeconds(10),at) to candles
    }
    fun adapter():Direct19ScanAdapter {
        fun model(name:String)=Direct19Model.load(File(root,"app/src/main/assets/direct19/$name").readBytes(),Direct19Catalog.hashes.getValue(name))
        return Direct19ScanAdapter(model("hgb_3m.bin"),model("hgb_5m.bin"))
    }
    fun quotes(observed:Observed):Map<String,HorizonQuote> = Direct19Policy.TRADED.associateWith { symbol ->
        val close=observed.prices.getValue(symbol).last { it.timeEpochMs/1000<=observed.boundary-120 }.close
        HorizonQuote((observed.boundary-11)*1000,(observed.boundary-12)*1000,close,close*.99999,close*1.00001,true)
    }
}

class RuleAiFunctionalTest {
    @Test fun realModelFrameObeysCausalitySafetyAndAvailabilityGuards() {
        val observed=RuleAiObservedFixture.at(0,1);val b=observed.boundary
        val (native,candles)=RuleAiObservedFixture.native(observed)
        val frame=RuleAiObservedFixture.adapter().prepare(observed.prices,b).copy(preparedMs=(b-20)*1000)
        val quotes=RuleAiObservedFixture.quotes(observed)
        val reasons=mutableListOf<String>()
        fun guarded(reason:String,f:Direct19Frame?=frame,q:Map<String,HorizonQuote> =quotes,c:Map<String,List<Candle>> =candles,now:Long=(b-5)*1000,n:ScanResult=native) {
            val a=RuleAiObservedFixture.adapter();val result=a.apply(n,c,f,q,false,now)
            assertEquals(reason,a.status);assertEquals(n.candidates,result.candidates);assertEquals(n.judgeTimeJst,result.judgeTimeJst)
            assertEquals(n.scanId,result.scanId);assertEquals(n.top1?.decision,result.top1?.decision);reasons+=reason
        }
        guarded("FRAME_NOT_READY",f=null)
        guarded("FRAME_NOT_READY",f=frame.copy(preparedMs=(b-9)*1000))
        guarded("FRAME_NOT_READY",f=frame.copy(input=frame.input.copy(boundary=b+300)))
        guarded("QUOTE_NOT_SAFE",q=emptyMap())
        for(transform in listOf<(HorizonQuote)->HorizonQuote>(
            { it.copy(sourceMs=(b-21)*1000) },{ it.copy(sourceMs=(b-9)*1000) },
            { it.copy(receivedMs=(b-9)*1000) },{ it.copy(live=false) },
            { it.copy(price=0.0) },{ it.copy(price=Double.NaN) },
            { it.copy(bid=it.price*1.01,ask=it.price*.99) },{ it.copy(price=it.price*1.01) }
        ))guarded("QUOTE_NOT_SAFE",q=quotes.mapValues { transform(it.value) })
        guarded("INPUT_REVISION:USDJPY",c=candles+mapOf("USDJPY" to candles.getValue("USDJPY").dropLast(1)))
        guarded("PUBLISH_DEADLINE",now=b*1000-799)
        guarded("NATIVE_SKIP",n=native.copy(candidates=native.candidates.map { if(it.rank==1)it.copy(grade="E",decision="SKIP") else it }))
        for(grade in listOf("S","A","B"))guarded("NATIVE_S_A_B_PROTECTED",n=native.copy(candidates=native.candidates.map { if(it.rank==1)it.copy(grade=grade) else it }))
        val before=ZonedDateTime.parse("2026-10-07T14:00:00+09:00")
        guarded("MODEL_NOT_AVAILABLE",n=native.copy(entryTimeJst=before.toString(),judgeTimeJst=before.plusMinutes(3).toString()))
        val corrupt=frame.copy(probability=Array(4) { s->Array(2) { h->frame.probability[s][h].copyOf() } })
        corrupt.probability[0][0][0]=Float.NaN
        guarded("NATIVE_FALLBACK:IllegalArgumentException",f=corrupt)
        for(source in listOf("MANUAL","AUTO_1M")) {
            val n=native.copy(source=source);assertEquals(n,RuleAiObservedFixture.adapter().apply(n,candles,frame,quotes,true,(b-5)*1000))
        }
        RuleAiObservedFixture.root.resolve("RULE_AI_GUARD_AUDIT.json").writeText("{\"status\":\"PASS\",\"real_model_frame\":true,\"guard_cases\":${reasons.size},\"manual_and_one_minute_unchanged\":true,\"reasons\":[${reasons.joinToString(",") { "\"$it\"" }}]}\n")
    }
    @Test fun unfinishedAndFutureObservedCandlesCannotChangeRealModelInputs() {
        val observed=RuleAiObservedFixture.at(0,1);val adapter=RuleAiObservedFixture.adapter()
        val all=adapter.prepare(observed.prices,observed.boundary)
        val completed=adapter.prepare(observed.prices.mapValues { (_,bars)->bars.filter { it.timeEpochMs+60_000<=(observed.boundary-10)*1000 } },observed.boundary)
        for(s in 0..3)for(j in 0..164)assertEquals("future observed candles symbol=$s feature=$j",completed.input.features[s][j],all.input.features[s][j],0f)
    }
    @Test fun observedPricesDriveNativeRulesAndRealModelCorrections() {
        val statuses=sortedMapOf<String,Int>();var slots=0;var cEntries=0;var applied=0;var fiveMinute=0;var fixedApplied=0
        val examples=mutableListOf<String>()
        for(case in 0..1) for(slot in 0..35) {
            val observed=RuleAiObservedFixture.at(case,slot);val (native,candles)=RuleAiObservedFixture.native(observed)
            assertEquals(6,native.candidates.size)
            assertEquals((1..6).toList(),native.candidates.map { it.rank })
            assertTrue(candles.values.all { it.last().timeEpochMs/1000==observed.boundary-120 })
            assertTrue(native.candidates.all { (it.grade in setOf("S","A","B","C"))==(it.decision=="ENTRY") })
            val (repeatNative,_)=RuleAiObservedFixture.native(observed)
            assertEquals(native.copy(scanId=""),repeatNative.copy(scanId=""))
            val adapter=RuleAiObservedFixture.adapter()
            val isC=native.top1!!.decision=="ENTRY" && native.top1!!.grade=="C" && native.top1!!.instrument in Direct19Policy.TRADED
            val frame=if(isC)adapter.prepare(observed.prices,observed.boundary).copy(preparedMs=(observed.boundary-20)*1000) else null
            if(isC) {
                cEntries++
                for(probability in frame!!.probability.flatMap { it.toList() }) {
                    assertTrue(probability.all { it.isFinite() && it in 0f..1f })
                    assertEquals(1.0,probability.sum().toDouble(),3e-5)
                }
            }
            val result=adapter.apply(native,candles,frame,RuleAiObservedFixture.quotes(observed),false,(observed.boundary-5)*1000)
            statuses[adapter.status]=(statuses[adapter.status] ?: 0)+1
            assertEquals(native.scanId,result.scanId);assertEquals(native.source,result.source);assertEquals(native.entryTimeJst,result.entryTimeJst)
            assertEquals(native.top1!!.decision,result.top1!!.decision)
            assertEquals(native.candidates.map { it.instrument }.toSet(),result.candidates.map { it.instrument }.toSet())
            assertEquals((1..6).toList(),result.candidates.map { it.rank })
            if(!isC)assertEquals(native.candidates,result.candidates)
            if(adapter.status=="APPLIED") {
                applied++;if(Duration.between(ZonedDateTime.parse(result.entryTimeJst),ZonedDateTime.parse(result.judgeTimeJst)).toMinutes()==5L)fiveMinute++
                examples+="{\"case\":$case,\"slot\":$slot,\"native_symbol\":\"${native.top1!!.instrument}\",\"symbol\":\"${result.top1!!.instrument}\",\"direction\":\"${result.top1!!.direction}\",\"judge\":\"${result.judgeTimeJst}\"}"
            }
            val fixed=adapter.apply(native,candles,frame,RuleAiObservedFixture.quotes(observed),true,(observed.boundary-5)*1000)
            assertEquals(3L,Duration.between(ZonedDateTime.parse(fixed.entryTimeJst),ZonedDateTime.parse(fixed.judgeTimeJst)).toMinutes())
            assertEquals(native.top1!!.decision,fixed.top1!!.decision)
            if(adapter.status=="APPLIED")fixedApplied++
            slots++
        }
        val report="{\"status\":\"PASS\",\"scope\":\"functional replay; observed prices, shifted dates; not a performance backtest\",\"slots\":$slots,\"native_common_four_c_entries\":$cEntries,\"real_model_applied\":$applied,\"five_minute_applied\":$fiveMinute,\"fixed_three_applied\":$fixedApplied,\"statuses\":{${statuses.entries.joinToString(",") { "\"${it.key}\":${it.value}" }}},\"examples\":[${examples.joinToString(",")}] }\n"
        RuleAiObservedFixture.root.resolve("RULE_AI_FUNCTIONAL_AUDIT.json").writeText(report)
        println(report)
        assertTrue("The real models must actually correct a native C entry in the observed scenarios",applied>0)
        assertTrue("The fixed-three profile must exercise a real correction",fixedApplied>0)
    }

    @Test fun missingAuxiliaryPricesStayMissingAndOwnGapsDisableInference() {
        val observed=RuleAiObservedFixture.at(0);val adapter=RuleAiObservedFixture.adapter()
        val mainOnly=observed.prices.filterKeys { it in HorizonFeatureService.SYMBOLS.take(6) }
        val partial=adapter.prepare(mainOnly,observed.boundary)
        assertTrue(partial.input.eligible.all { it })
        for(features in partial.input.features) {
            assertEquals(6,features.drop(146).count { it==1f })
            assertEquals(13,features.drop(146).count { it==0f })
            assertTrue("The trained preprocessing encodes missing raw inputs as zero",features.take(146).all { it.isFinite() })
            for(name in listOf("driver_USD_strength1","driver_USD_strength5")) {
                assertEquals(0f,features[jp.gmk.mobile.domain.r13.R13Features.PRICE.indexOf(name)],0f)
            }
        }
        assertTrue(partial.probability.flatMap { it.toList() }.all { p->p.all { it.isFinite() } && abs(p.sum()-1f)<3e-5 })
        val broken=observed.prices+mapOf("USDJPY" to observed.prices.getValue("USDJPY").dropLast(1))
        val gap=adapter.prepare(broken,observed.boundary)
        assertFalse(gap.input.eligible[0]);assertTrue(gap.probability[0].all { it.all { value->value.isNaN() } })
        assertTrue(gap.input.eligible.drop(1).all { it })
    }
}

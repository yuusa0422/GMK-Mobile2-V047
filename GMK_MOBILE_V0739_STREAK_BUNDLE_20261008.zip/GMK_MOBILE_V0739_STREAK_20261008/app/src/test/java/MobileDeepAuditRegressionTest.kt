import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import androidx.lifecycle.ViewModelStore
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.domain.historyStatistics
import jp.gmk.mobile.runtime.GmkBootReceiver
import jp.gmk.mobile.ui.GmkViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestCoroutineScheduler
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.json.JSONArray
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [26, 35])
@LooperMode(LooperMode.Mode.PAUSED)
@OptIn(ExperimentalCoroutinesApi::class)
class MobileDeepAuditRegressionTest {
    private lateinit var app: Application
    private val stores = mutableListOf<ViewModelStore>()
    private val clients = mutableListOf<OkHttpClient>()
    private val scheduler = TestCoroutineScheduler()

    @Before fun setup() {
        app = RuntimeEnvironment.getApplication()
        listOf("gmk_mobile_local", "gmk_mobile_history", "gmk_mobile_history_journal", "gmk_runtime_service")
            .forEach { app.getSharedPreferences(it, Context.MODE_PRIVATE).edit().clear().commit() }
        AppPrefs(app).apply { autoScan = false; oneMinuteAutoScan = false }
        jp.gmk.mobile.runtime.GmkRuntimeServiceControl.markStopped()
        Dispatchers.setMain(StandardTestDispatcher(scheduler))
    }
    @After fun cleanup() {
        stores.forEach { it.clear() }
        scheduler.runCurrent()
        clients.forEach { it.dispatcher.cancelAll(); it.dispatcher.executorService.shutdownNow(); it.connectionPool.evictAll() }
        Dispatchers.resetMain()
    }
    private fun row(id: String, status: String = "WAIT_JUDGE"): JSONObject = JSONObject()
        .put("id", 1).put("scan_id", id).put("source", "AUTO")
        .put("policy_version", "GMK_V0736_DIRECT19")
        .put("at_jst", "2026-10-08T09:04:50+09:00")
        .put("instrument", "USDJPY").put("direction", "HIGH").put("grade", "C").put("decision", "ENTRY")
        .put("entry_time_jst", "2026-10-08T09:05:00+09:00")
        .put("judge_time_jst", "2026-10-08T09:08:00+09:00")
        .put("entry_rate", 150.0).put("result_status", status)
    private fun seed(vararg rows: JSONObject) {
        val array = JSONArray(); rows.forEach { array.put(it) }
        app.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE).edit().putString("items", array.toString()).commit()
    }
    @Test fun malformedEntryRateCannotCrashOrBecomeLoss() {
        seed(row("bad-entry").put("entry_rate", "broken"))
        val store = HistoryStore(app)
        val loaded = store.load().single()
        assertNull("Invalid price must not enter memory as NaN", loaded.entryRate)
        store.settle("bad-entry", 151.0, "test", "2026-10-08T09:08:01+09:00", 1000, 1.0)
        assertEquals("INVALID_RATE_DATA", store.load().single().resultStatus)
        assertEquals(0, historyStatistics(store.load()).getValue(3).resolved())
    }
    @Test fun settledRowMissingRequiredPricesIsExcluded() {
        seed(row("false-win", "WIN").put("entry_rate", JSONObject.NULL).put("judge_rate", 151.0))
        val store = HistoryStore(app)
        assertEquals("INVALID_RATE_DATA", store.load().single().resultStatus)
        assertEquals(0, historyStatistics(store.load()).getValue(3).resolved())
    }
    @Test fun malformedAgeDoesNotBlockNewOutcomePersistence() {
        seed(row("age-bad").put("entry_provider_age_seconds", "NaN").put("entry_capture_delay_ms", -1))
        val store = HistoryStore(app)
        assertNull(store.load().single().entryProviderAgeSeconds)
        assertNull(store.load().single().entryCaptureDelayMs)
        store.settle("age-bad", 151.0, "test", "2026-10-08T09:08:01+09:00", 1000, 1.0)
        assertEquals("WIN", store.load().single().resultStatus)
        assertEquals("WIN", HistoryStore(app).load().single().resultStatus)
    }
    @Test fun corruptPrimaryRecoversBackupAndNewestCrashJournal() {
        val backup = JSONArray().put(row("journal", "WAIT_ENTRY").put("entry_rate", JSONObject.NULL)).toString()
        app.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE).edit()
            .putString("items", "{broken").putString("items_backup", backup).commit()
        val latest = row("journal", "WIN").put("judge_rate", 151.0)
        app.getSharedPreferences("gmk_mobile_history_journal", Context.MODE_PRIVATE).edit()
            .putString("critical_row_journal", JSONArray().put(latest).toString()).commit()
        assertEquals("WIN", HistoryStore(app).load().single().resultStatus)
    }
    @Test fun refusedBootServiceStartDoesNotCrashReceiver() {
        AppPrefs(app).autoScan = true
        val refused = object : ContextWrapper(app) {
            override fun startForegroundService(service: Intent): ComponentName? {
                throw IllegalStateException("Foreground start denied by OS")
            }
        }
        GmkBootReceiver().onReceive(refused, Intent(Intent.ACTION_BOOT_COMPLETED))
        assertTrue(app.getSharedPreferences("gmk_runtime_service", Context.MODE_PRIVATE)
            .getString("last_start_error", "").orEmpty().contains("denied"))
    }
    @Test fun actualOsForegroundServiceRefusalIsRecorded() {
        val refused = object : ContextWrapper(app) {
            override fun startForegroundService(service: Intent): ComponentName? {
                if (android.os.Build.VERSION.SDK_INT >= 31) {
                    throw android.app.ForegroundServiceStartNotAllowedException("Background start denied")
                }
                throw IllegalStateException("Background start denied")
            }
        }
        assertFalse(jp.gmk.mobile.runtime.GmkRuntimeServiceControl.start(refused))
        assertTrue(jp.gmk.mobile.runtime.GmkRuntimeServiceControl.lastError(app).orEmpty().contains("denied"))
        if (android.os.Build.VERSION.SDK_INT >= 31) assertTrue(jp.gmk.mobile.runtime.GmkRuntimeServiceControl.lastError(app).orEmpty().contains("ForegroundServiceStartNotAllowedException"))
        jp.gmk.mobile.runtime.GmkRuntimeServiceControl.markStarted(app)
        assertNull(jp.gmk.mobile.runtime.GmkRuntimeServiceControl.lastError(app))
        jp.gmk.mobile.runtime.GmkRuntimeServiceControl.markStopped()
    }
    @Test fun fiveMinuteHistoryAndStatusLabelsStayFiveMinutes() {
        val entry = "2026-10-08T09:05:00+09:00"
        val judge = "2026-10-08T09:10:00+09:00"
        assertEquals(5, jp.gmk.mobile.expiryMinutes(entry, judge, 3))
        val scan = jp.gmk.mobile.domain.ScanResult("label-test", "2026-10-08T09:04:50+09:00", entry, judge,
            listOf(jp.gmk.mobile.domain.ScanCandidate(1,"USDJPY","USD/JPY","HIGH","C",0.65,"ENTRY")), source="AUTO")
        assertTrue(jp.gmk.mobile.latestCandidateStatusText(jp.gmk.mobile.ui.GmkUiState(scan=scan)).endsWith("5分"))
    }
    private fun mockQuote(instrument: String, body: String): jp.gmk.mobile.domain.RateRow = runBlocking {
        val server = MockWebServer(); server.start()
        try {
            repeat(4) { server.enqueue(MockResponse().setBody(body)) }
            val repo = MarketRepository(AppPrefs(app))
            installClient(repo, OkHttpClient.Builder().addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().url(server.url("/quote")).build())
            }.build())
            withTimeout(2500) { repo.fetchRate(instrument) }
        } finally { server.shutdown() }
    }
    @Test fun futureBitcoinTimestampCannotBeLive() {
        val body = JSONObject().put("success",1).put("data", JSONObject().put("buy","9999999").put("sell","10000001")
            .put("last","10000000").put("timestamp",System.currentTimeMillis()+3600000)).toString()
        val result = mockQuote("BTCJPY", body)
        assertNotEquals("LIVE", result.freshnessStatus)
        assertEquals(10000000.0,result.price!!,0.0)
        assertNull(result.ageSeconds)
    }
    private fun yahooQuote(metaPrice: Double, metaSeconds: Long): String {
        val result = JSONObject().put("meta", JSONObject().put("regularMarketPrice",metaPrice).put("regularMarketTime",metaSeconds))
            .put("timestamp",JSONArray().put(System.currentTimeMillis()/1000-60))
            .put("indicators", JSONObject().put("quote",JSONArray().put(JSONObject().put("close",JSONArray().put(150.0)))))
        return JSONObject().put("chart",JSONObject().put("result",JSONArray().put(result))).toString()
    }
    @Test fun futureYahooMetaCannotOverrideValidPastPrice() {
        val result = mockQuote("USDJPY", yahooQuote(999.0, System.currentTimeMillis()/1000+3600))
        assertEquals(150.0, result.price!!, 0.0)
        assertNotEquals("LIVE", result.freshnessStatus)
    }
    @Test fun nonPositiveYahooMetaCannotBecomeLiveQuote() {
        val result = mockQuote("USDJPY", yahooQuote(0.0, System.currentTimeMillis()/1000))
        assertEquals(150.0, result.price!!, 0.0)
        assertNotEquals("LIVE", result.freshnessStatus)
    }
    private fun installClient(repository: MarketRepository, client: OkHttpClient) {
        clients += client
        MarketRepository::class.java.getDeclaredField("client").apply { isAccessible = true }.set(repository, client)
    }
    @Test fun truncatedResponseBodyIsRetriedWithoutHanging() = runBlocking {
        val server = MockWebServer(); server.start()
        try {
            server.enqueue(MockResponse().setBody("x".repeat(20000)).setSocketPolicy(SocketPolicy.DISCONNECT_DURING_RESPONSE_BODY))
            server.enqueue(MockResponse().setBody(JSONObject().put("success",1).put("data", JSONObject()
                .put("buy", "9999999").put("sell", "10000001").put("last", "10000000")
                .put("timestamp", System.currentTimeMillis())).toString()))
            val repository = MarketRepository(AppPrefs(app))
            val client = OkHttpClient.Builder().addInterceptor { chain ->
                chain.proceed(chain.request().newBuilder().url(server.url("/ticker")).build())
            }.build()
            installClient(repository, client)
            val result = withTimeout(2500) { repository.fetchRate("BTCJPY") }
            assertEquals(10000000.0, result.price!!, 0.0)
            assertEquals(2, server.requestCount)
            assertEquals(1, repository.diagnosticStats().getLong("failure"))
        } finally { server.shutdown() }
    }
    private fun viewModelWithBlockedNetwork(): Pair<GmkViewModel, CountDownLatch> {
        val vm = GmkViewModel(app)
        vm.shutdownRuntime()
        val latch = CountDownLatch(1)
        val client = OkHttpClient.Builder().addInterceptor { chain ->
            latch.countDown()
            while (!chain.call().isCanceled()) Thread.sleep(5)
            throw IOException("Canceled test request")
        }.build()
        val repository = GmkViewModel::class.java.getDeclaredField("repository").apply { isAccessible = true }.get(vm) as MarketRepository
        installClient(repository, client)
        stores += ViewModelStore().also { it.put("audit", vm) }
        return vm to latch
    }
    private fun awaitCancelledNetworkCompletion(done: () -> Boolean) {
        // Coroutine deadlines are virtual; OkHttp callbacks still finish on real IO threads.
        // Drain Main after that cancellation handshake before asserting the UI state.
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(3)
        while (!done() && System.nanoTime() < deadline) {
            scheduler.runCurrent()
            Thread.sleep(5)
        }
        scheduler.runCurrent()
    }
    @Test fun previousAutoSlotBeforeWindowDoesNotPointIntoFuture() {
        val (vm, _) = viewModelWithBlockedNetwork()
        val method = GmkViewModel::class.java.getDeclaredMethod("latestScheduledT10AtOrBefore", java.time.ZonedDateTime::class.java)
            .apply { isAccessible = true }
        val now = java.time.ZonedDateTime.parse("2026-10-08T09:09:30+09:00")
        assertEquals(java.time.ZonedDateTime.parse("2026-10-08T09:04:50+09:00"), method.invoke(vm, now))
        val onSlot = java.time.ZonedDateTime.parse("2026-10-08T09:09:50+09:00")
        assertEquals(onSlot, method.invoke(vm, onSlot))
    }
    @Test fun chartTimeoutClearsLoadingAndAllowsRetry() {
        val (vm, started) = viewModelWithBlockedNetwork()
        vm.loadChart("USDJPY", "1m")
        scheduler.runCurrent()
        assertTrue(started.await(5, TimeUnit.SECONDS))
        scheduler.advanceTimeBy(20001); scheduler.runCurrent()
        awaitCancelledNetworkCompletion { !vm.state.value.chartLoading }
        assertFalse("Chart loading must end after its 20s deadline", vm.state.value.chartLoading)
        assertTrue(vm.state.value.chartError.orEmpty().contains("タイムアウト"))
        vm.loadChart("EURJPY", "5m"); assertTrue(vm.state.value.chartLoading)
    }
    @Test fun strengthTimeoutClearsLoadingAndAllowsRetry() {
        val (vm, started) = viewModelWithBlockedNetwork()
        vm.loadStrength("1m")
        scheduler.runCurrent()
        assertTrue(started.await(5, TimeUnit.SECONDS))
        scheduler.advanceTimeBy(25001); scheduler.runCurrent()
        awaitCancelledNetworkCompletion { !vm.state.value.strengthLoading }
        assertFalse("Strength loading must end after its 25s deadline", vm.state.value.strengthLoading)
        assertTrue(vm.state.value.strengthErrors.getValue("all").contains("タイムアウト"))
        vm.loadStrength("5m"); assertTrue(vm.state.value.strengthLoading)
    }
}

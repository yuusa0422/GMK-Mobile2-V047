import jp.gmk.mobile.domain.r13.*;
import jp.gmk.mobile.domain.OutcomeStatistics;
import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.*;

/** Runs the actual Android Java code against frozen, independently produced PC outputs. */
public class R13OfflineTest {
    static ByteBuffer read(Path p)throws IOException{return ByteBuffer.wrap(Files.readAllBytes(p)).order(ByteOrder.LITTLE_ENDIAN);}
    static float[][] matrix(ByteBuffer b,int rows,int cols){float[][] x=new float[rows][cols];for(float[] r:x)for(int j=0;j<cols;j++)r[j]=b.getFloat();return x;}
    static float[][][] tensor(ByteBuffer b,int rows,int steps,int cols){float[][][] x=new float[rows][][];for(int i=0;i<rows;i++)x[i]=matrix(b,steps,cols);return x;}
    static void require(boolean good,String message){if(!good)throw new AssertionError(message);}
    static double difference(float[][] a,float[][] b,double tol){double max=0;for(int i=0;i<a.length;i++)for(int j=0;j<a[i].length;j++){require(Float.isFinite(a[i][j]),"nonfinite result");double delta=Math.abs(a[i][j]-b[i][j]);if(delta>tol)System.out.println("DIFF row="+i+" column="+j+" actual="+a[i][j]+" expected="+b[i][j]);max=Math.max(max,delta);}require(max<=tol,"max difference="+max+" tolerance="+tol);return max;}
    static double difference(float[][][] a,float[][][] b,double tol){double max=0;for(int i=0;i<a.length;i++)max=Math.max(max,difference(a[i],b[i],tol));return max;}
    static float[][][] probabilities(){float[][][] p=new float[6][3][3];for(float[][] s:p)for(float[] h:s)Arrays.fill(h,1f/3);return p;}
    static void inference(Path assets,Path fixtures)throws Exception{
        Properties hashes=new Properties();try(InputStream in=Files.newInputStream(fixtures.resolve("hashes.properties"))){hashes.load(in);}
        Map<String,R13Models.Neural> nn=new LinkedHashMap<>();
        for(String k:new String[]{"TCN","M1_TCN","M1_LSTM","M1_LINEAR"})nn.put(k,new R13Models.Neural(Files.readAllBytes(assets.resolve(k+".bin")),hashes.getProperty(k)));
        R13Models.Xgb xgb=new R13Models.Xgb(Files.readAllBytes(assets.resolve("XGB.bin")),hashes.getProperty("XGB"));
        ByteBuffer b=read(fixtures.resolve("inference.bin"));int count=b.getInt();Map<String,Double> errors=new LinkedHashMap<>();double[] latency=new double[count];
        for(int n=0;n<count;n++){
            float[][][] minute=tensor(b,6,60,12);float[][] context=matrix(b,6,62),tree=matrix(b,18,149);float[][][] snapshot=tensor(b,6,16,51);
            long started=System.nanoTime();long deadline=started+2_000_000_000L;
            Map<String,float[][][]> banks=new HashMap<>();
            for(String k:nn.keySet()){
                float[][][] expected=tensor(b,6,3,3),p=nn.get(k).predict(k.equals("TCN")?snapshot:minute,k.equals("TCN")?null:context,deadline);
                errors.merge(k,difference(p,expected,3e-5),Math::max);
                banks.put(k,p);
            }
            float[][][] xp=xgb.predict(tree,deadline);banks.put("XGB",xp);
            errors.merge("XGB",difference(xp,tensor(b,6,3,3),3e-6),Math::max);
            boolean[] safe={true,true,true,true,true,true};
            for(boolean nativeEntry:new boolean[]{false,true})for(int base=0;base<36;base++) {
                int expected=b.getInt(),actual=R13Policy.decide(base,true,nativeEntry,nativeEntry?"C":"SUPPLEMENT",safe,banks.get("TCN"),banks.get("M1_TCN"),banks.get("M1_LSTM"),banks.get("M1_LINEAR"),probabilities(),xp);
                require(actual==expected,"inferred action mismatch frame="+n+" base="+base);
            }
            latency[n]=(System.nanoTime()-started)/1e6;
        }
        require(!b.hasRemaining(),"inference trailing bytes");Arrays.sort(latency);
        byte[] altered=Files.readAllBytes(assets.resolve("M1_TCN.bin"));altered[altered.length-1]^=1;
        try{new R13Models.Neural(altered,hashes.getProperty("M1_TCN"));throw new AssertionError("SHA accepted alteration");}catch(IllegalArgumentException expected){}
        try{xgb.predict(new float[18][149],System.nanoTime()-1);throw new AssertionError("deadline ignored");}catch(IllegalStateException expected){}
        System.out.println("INFERENCE cases="+count+" inferred_actions_matching="+(count*72)+" errors="+errors+" host_combined_p95_ms="+latency[(int)Math.ceil(count*.95)-1]);
    }
    static void features(Path fixtures)throws Exception{
        ByteBuffer b=read(fixtures.resolve("features.bin"));int count=b.getInt();double max=0;
        for(int n=0;n<count;n++){
            float[][] rows=matrix(b,6,51),nativeFeatures=matrix(b,6,12);double[][][] bars=new double[61][11][5];
            for(double[][] t:bars)for(double[] s:t)for(int j=0;j<5;j++)s[j]=b.getDouble();
            R13Features.Inputs input=R13Features.build(rows,nativeFeatures,bars);
            max=Math.max(max,difference(input.raw,matrix(b,6,50),1e-5));
            max=Math.max(max,difference(input.context,matrix(b,6,62),1e-5));
            max=Math.max(max,difference(input.minute,tensor(b,6,60,12),2e-5));
            max=Math.max(max,difference(input.tree,matrix(b,18,149),3e-5));
        }
        require(!b.hasRemaining(),"features trailing bytes");System.out.println("FEATURES cases="+count+" max_absolute_error="+max);
    }
    static void policy(Path fixtures)throws Exception{
        ByteBuffer b=read(fixtures.resolve("policy.bin"));int count=b.getInt();int changed=0;
        for(int n=0;n<count;n++){
            int base=b.getInt();boolean entry=b.getInt()!=0,nativeEntry=b.getInt()!=0;String grade=new String[]{"S","A","B","C","SUPPLEMENT"}[b.getInt()];
            boolean[] safe=new boolean[6];for(int s=0;s<6;s++)safe[s]=b.getInt()!=0;
            float[][][][] banks=new float[6][][][];for(int k=0;k<6;k++)banks[k]=tensor(b,6,3,3);
            int expected=b.getInt(),actual=R13Policy.decide(base,entry,nativeEntry,grade,safe,banks[0],banks[1],banks[2],banks[3],banks[4],banks[5]);
            require(actual==expected,"policy case="+n+" expected="+expected+" actual="+actual);if(actual!=base)changed++;
        }
        require(!b.hasRemaining(),"policy trailing bytes");
        boolean[] safe=new boolean[]{false,false,false,false,false,false};float[][][] p=probabilities();
        try{R13Policy.decide(0,true,false,"SUPPLEMENT",safe,p,p,p,p,p,p);throw new AssertionError("unsafe accepted");}catch(IllegalArgumentException expected){}
        p[1][0][0]=Float.NaN;Arrays.fill(safe,true);
        try{R13Policy.decide(0,true,false,"SUPPLEMENT",safe,p,p,p,p,p,p);throw new AssertionError("NaN accepted");}catch(IllegalArgumentException expected){}
        System.out.println("POLICY cases="+count+" actions_matching="+count+" changed="+changed);
    }
    static void history()throws Exception{
        String entry="2026-10-07T13:35:00+09:00",three="2026-10-07T13:38:00+09:00",one="2026-10-07T13:36:00+09:00";
        List<OutcomeStatistics.Row> rows=Arrays.asList(
            new OutcomeStatistics.Row("ENTRY","WIN",entry,three,"new",1.,2.),new OutcomeStatistics.Row("ENTRY","LOSE",entry,three,"new",1.,1.),
            new OutcomeStatistics.Row("SKIP","LOSE",entry,three,"old",1.,0.),new OutcomeStatistics.Row("SKIP","WIN",entry,three,"old",1.,2.),
            new OutcomeStatistics.Row("ENTRY","WAIT_JUDGE",entry,three,"new",1.,null),new OutcomeStatistics.Row("ENTRY","JUDGE_RATE_MISSED",entry,three,"new",1.,null),
            new OutcomeStatistics.Row("ENTRY","LOSE",entry,one,"old",1.,0.),new OutcomeStatistics.Row("ENTRY","WIN","","","old",1.,2.));
        Map<Integer,OutcomeStatistics.Summary> stats=OutcomeStatistics.byHorizon(rows);OutcomeStatistics.Summary s=stats.get(3);
        require(s.wins==1 && s.losses==1 && s.resolved()==2 && s.winRate()==50. && s.draws==1 && s.skips==2 && s.skipShadow==2 && s.pending==1 && s.missed==1,"SKIP/resolved aggregation");
        require(stats.get(1).resolved()==1 && stats.get(1).winRate()==0. && stats.get(0).wins==1,"horizon partition");
        Path dir=Files.createTempDirectory("gmk-r13-test-");File f=dir.resolve("frames.bin").toFile();R13FrameStore store=new R13FrameStore(f);
        for(int i=0;i<20;i++)store.commit(i*300L,new float[6][50]);R13FrameStore recovered=new R13FrameStore(f);recovered.load();
        require(recovered.snapshotBefore(6000).size()==16 && !recovered.snapshotBefore(6000).containsKey(0L),"history persistence/capacity");
        require(recovered.snapshotBefore(1200).isEmpty(),"future context excluded");
        byte[] data=Files.readAllBytes(f.toPath());Files.write(f.toPath(),Arrays.copyOf(data,data.length-2));
        try{new R13FrameStore(f).load();throw new AssertionError("truncated history accepted");}catch(IOException expected){}
        Files.delete(f.toPath());Files.delete(dir);System.out.println("HISTORY PASS SKIP, DRAW-as-loss, pending, missed, horizon, persistence, causal cutoff, corruption");
    }
    public static void main(String[] args)throws Exception{
        Path assets=Paths.get(args[0]),fixtures=Paths.get(args[1]);inference(assets,fixtures);features(fixtures);policy(fixtures);history();entryGuard();System.out.println("PASS PC_R13_MOBILE_OFFLINE");
    }
    static void entryGuard() {
        for(boolean entry:new boolean[]{false,true}) {
            require(EntryMaskGuard.rejectionReason(entry,entry,"id","id","AUTO","AUTO","time","time")==null,"valid proposal rejected");
            require("ENTRY_MASK_CHANGED".equals(EntryMaskGuard.rejectionReason(entry,!entry,"id","id","AUTO","AUTO","time","time")),"entry mask alteration accepted");
            require("SCAN_IDENTITY_CHANGED".equals(EntryMaskGuard.rejectionReason(entry,entry,"id","other","AUTO","AUTO","time","time")),"scan id alteration accepted");
            require("SCAN_IDENTITY_CHANGED".equals(EntryMaskGuard.rejectionReason(entry,entry,"id","id","AUTO","AUTO_1M","time","time")),"source alteration accepted");
            require("SCAN_IDENTITY_CHANGED".equals(EntryMaskGuard.rejectionReason(entry,entry,"id","id","AUTO","AUTO","time","later")),"entry time alteration accepted");
        }
        require(EntryMaskGuard.meetsResearchFloor(70,100),"70% boundary rejected");
        require(!EntryMaskGuard.meetsResearchFloor(69,100),"below 70% accepted");
        require(!EntryMaskGuard.meetsResearchFloor(0,0),"empty research accepted");
        require(!EntryMaskGuard.meetsResearchFloor(101,100),"invalid counts accepted");
        System.out.println("ENTRY_CONTRACT PASS preserves ENTRY/SKIP and scan identity; research floor 70%");
    }
}

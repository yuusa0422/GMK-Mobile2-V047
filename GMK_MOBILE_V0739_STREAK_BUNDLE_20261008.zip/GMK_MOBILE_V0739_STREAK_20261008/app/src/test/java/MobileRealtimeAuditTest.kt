import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModelStore
import jp.gmk.mobile.data.*
import jp.gmk.mobile.domain.RateRow
import jp.gmk.mobile.ui.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.*
import okhttp3.*
import okhttp3.mockwebserver.*
import org.json.JSONObject
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.annotation.*
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[26,35])
@LooperMode(LooperMode.Mode.PAUSED)
@OptIn(ExperimentalCoroutinesApi::class)
class MobileRealtimeAuditTest {
    private lateinit var app:Application
    private val scheduler=TestCoroutineScheduler()
    private val servers=mutableListOf<MockWebServer>()
    private val feeds=mutableListOf<Pair<BitbankRealtimeFeed,Job>>()
    private val stores=mutableListOf<ViewModelStore>()
    private val clients=mutableListOf<OkHttpClient>()
    private val base=1_791_400_000_000L
    @Before fun setup() {
        app=RuntimeEnvironment.getApplication()
        listOf("gmk_mobile_local","gmk_mobile_history","gmk_mobile_history_journal","gmk_runtime_service")
            .forEach { app.getSharedPreferences(it,Context.MODE_PRIVATE).edit().clear().commit() }
        AppPrefs(app).apply { autoScan=false;oneMinuteAutoScan=false }
        jp.gmk.mobile.runtime.GmkRuntimeServiceControl.markStopped()
        Dispatchers.setMain(StandardTestDispatcher(scheduler))
    }
    @After fun cleanup() {
        stores.forEach { it.clear() };scheduler.runCurrent()
        feeds.forEach { (feed,job)->feed.stop();job.cancel();runBlocking { job.join() } }
        clients.forEach { it.dispatcher.cancelAll();it.connectionPool.evictAll();it.dispatcher.executorService.shutdownNow() }
        servers.forEach { it.shutdown() };Dispatchers.resetMain()
    }
    private fun server():MockWebServer=MockWebServer().also { it.start();servers+=it }
    private fun ticker(time:Long,price:Long=10_000_000):String = "{\"last\":\"$price\",\"buy\":\"${price-1}\",\"sell\":\"${price+1}\",\"timestamp\":$time}"
    private fun packet(time:Long,price:Long=10_000_000,room:String="ticker_btc_jpy"):String = "42[\"message\",{\"room_name\":\"$room\",\"message\":{\"data\":${ticker(time,price)}}}]"
    private fun waitFor(message:String,condition:()->Boolean) {
        val end=System.nanoTime()+8_000_000_000L
        while(!condition() && System.nanoTime()<end) { scheduler.runCurrent();Thread.sleep(5) }
        scheduler.runCurrent();assertTrue(message,condition())
    }
    private fun subscribe(server:MockWebServer,clock:AtomicLong,onJoin:(WebSocket)->Unit,received:MutableList<String> = CopyOnWriteArrayList()):BitbankRealtimeFeed {
        server.enqueue(MockResponse().withWebSocketUpgrade(object:WebSocketListener() {
            override fun onOpen(ws:WebSocket,response:Response) { ws.send("0{\"sid\":\"test\",\"upgrades\":[],\"pingInterval\":25000,\"pingTimeout\":60000}") }
            override fun onMessage(ws:WebSocket,text:String) {
                received+=text
                if(text=="40")ws.send("40{\"sid\":\"namespace\"}")
                if(text=="42[\"join-room\",\"ticker_btc_jpy\"]")onJoin(ws)
            }
            override fun onClosed(ws:WebSocket,code:Int,reason:String) { received+="closed:$code" }
        }))
        return BitbankRealtimeFeed(server.url("/socket.io/?EIO=4&transport=websocket").toString(),clock::get)
    }
    private fun runFeed(feed:BitbankRealtimeFeed) { val owner=SupervisorJob();feeds+=feed to owner;feed.start(CoroutineScope(owner+Dispatchers.Default)) }
    @Test fun actualSocketHandshakePublishesJPYTicksAndAnswersHeartbeat() {
        val clock=AtomicLong(base);val received=CopyOnWriteArrayList<String>();val s=server()
        val feed=subscribe(s,clock,{ ws->ws.send(packet(base-1000));ws.send("2") },received)
        runFeed(feed);waitFor("Ticker or Engine.IO pong missing") { feed.latest.value!=null && "3" in received }
        assertEquals("40",received.first());assertTrue("42[\"join-room\",\"ticker_btc_jpy\"]" in received)
        assertEquals("BTCJPY",feed.latest.value!!.instrument);assertEquals(10_000_000.0,feed.latest.value!!.price!!,0.0)
        assertEquals(base-1000,feed.latest.value!!.sourceEpochMs);assertEquals("LIVE",feed.latest.value!!.freshnessStatus)
        assertTrue(feed.hasFreshStream(base));assertFalse(feed.hasFreshStream(base+5000))
    }
    @Test fun malformedForeignFutureAndOutOfOrderPacketsCannotReplaceCurrentTick() {
        val clock=AtomicLong(base);val s=server()
        val feed=subscribe(s,clock,{ ws->
            ws.send(packet(base-1000));ws.send(packet(base,20_000_000,"ticker_btc_usd"))
            ws.send(packet(base+1000,30_000_000));ws.send(packet(base-2000,40_000_000));ws.send("42bad-json")
        })
        runFeed(feed);waitFor("Invalid packets were not processed") { feed.diagnosticStats().getLong("rejected_ticks")>=3 }
        assertEquals(10_000_000.0,feed.latest.value!!.price!!,0.0)
        assertEquals(base-1000,feed.latest.value!!.sourceEpochMs)
    }
    @Test fun reconnectHandshakeNeverRefreshesTheOldPriceTimestamp() {
        val clock=AtomicLong(base);val s=server();val sockets=CopyOnWriteArrayList<WebSocket>()
        val feed=subscribe(s,clock,{ ws->sockets+=ws;ws.send(packet(base-1000)) })
        // The second connection completes its handshake but publishes no new quote.
        subscribe(s,clock,{ ws->sockets+=ws })
        runFeed(feed);waitFor("Initial quote missing") { feed.latest.value!=null }
        clock.addAndGet(20_000);sockets.first().close(1000,"disconnect fixture")
        waitFor("Socket was not reconnected") { sockets.size>=2 && feed.status=="SUBSCRIBED" }
        assertEquals(base-1000,feed.latest.value!!.sourceEpochMs)
        assertEquals(1L,feed.diagnosticStats().getLong("accepted_ticks"));assertFalse(feed.hasFreshStream(clock.get()))
    }
    @Test fun stopCancelsTheSubscriptionAndLateSocketDataCannotReopenIt() {
        val clock=AtomicLong(base);val s=server();val sockets=CopyOnWriteArrayList<WebSocket>()
        val feed=subscribe(s,clock,{ ws->sockets+=ws;ws.send(packet(base-1000)) })
        runFeed(feed);waitFor("Initial quote missing") { feed.latest.value!=null }
        val count=feed.diagnosticStats().getLong("accepted_ticks");feed.stop()
        sockets.first().send(packet(base,20_000_000));Thread.sleep(40)
        assertEquals("STOPPED",feed.status);assertEquals(count,feed.diagnosticStats().getLong("accepted_ticks"))
    }
    @Test fun aLateCloseFromTheOldNamespaceCannotDisconnectTheNewSubscription() {
        val clock=AtomicLong(base);val s=server();val sockets=CopyOnWriteArrayList<WebSocket>()
        val oldEvents=CopyOnWriteArrayList<String>()
        val feed=subscribe(s,clock,{ ws->sockets+=ws;ws.send(packet(base-1000));ws.send("41") },oldEvents)
        subscribe(s,clock,{ ws->sockets+=ws;ws.send(packet(base-100,10_000_030)) })
        runFeed(feed)
        waitFor("The new subscription did not replace the disconnected namespace") { sockets.size>=2 && feed.status=="SUBSCRIBED" && feed.latest.value?.price==10_000_030.0 }
        // The old server deliberately delays its close acknowledgement until the
        // replacement socket is already subscribed and publishing genuine ticks.
        sockets.first().close(1000,"old close acknowledged late")
        waitFor("The delayed old close was not delivered") { oldEvents.any { it.startsWith("closed:") } }
        Thread.sleep(100)
        assertEquals("Old connection callbacks must not change the active socket status","SUBSCRIBED",feed.status)
        assertTrue(feed.hasFreshStream(base))
    }
    private fun mockRepository(repository:MarketRepository,s:MockWebServer) {
        val client=OkHttpClient.Builder().addInterceptor { chain->chain.proceed(chain.request().newBuilder().url(s.url("/ticker")).build()) }.build()
        clients+=client;MarketRepository::class.java.getDeclaredField("client").apply { isAccessible=true }.set(repository,client)
    }
    @Test fun realRestRequestsRejectErrorPayloadsMissingTradesCrossedBooksAndStaleTimes()=runBlocking {
        val s=server();val repo=MarketRepository(AppPrefs(app));mockRepository(repo,s)
        val now=System.currentTimeMillis()
        val cases=listOf(
            "{\"success\":1,\"data\":${ticker(now-100)}}" to "LIVE",
            "{\"success\":0,\"data\":${ticker(now-100)}}" to "UNAVAILABLE",
            "{\"success\":1,\"data\":${ticker(now-100).replace("\"last\":\"10000000\"","\"last\":\"0\"")}}" to "LAST",
            "{\"success\":1,\"data\":${ticker(now-20_000)}}" to "LAST",
            "{\"success\":1,\"data\":${ticker(now+60_000)}}" to "LAST",
            "{\"success\":1,\"data\":${ticker(now-100).replace("\"buy\":\"9999999\"","\"buy\":\"10000002\"")}}" to "LAST"
        )
        for((body,status) in cases) { s.enqueue(MockResponse().setBody(body));assertEquals(status,repo.fetchRate("BTCJPY").freshnessStatus) }
        assertEquals(6,s.requestCount)
    }
    private fun vm():GmkViewModel=GmkViewModel(app).also { it.shutdownRuntime();stores+=ViewModelStore().apply { put("realtime",it) } }
    private fun state(model:GmkViewModel):MutableStateFlow<GmkUiState> {
        @Suppress("UNCHECKED_CAST")
        return GmkViewModel::class.java.getDeclaredField("_state").apply { isAccessible=true }.get(model) as MutableStateFlow<GmkUiState>
    }
    private fun restart(model:GmkViewModel) { GmkViewModel::class.java.getDeclaredMethod("startRateLoop").apply { isAccessible=true }.invoke(model) }
    private fun installVmFeed(model:GmkViewModel):Pair<BitbankRealtimeFeed,MockWebServer> {
        val http=server();http.dispatcher=object:okhttp3.mockwebserver.Dispatcher() {
            override fun dispatch(request:RecordedRequest)=MockResponse().setBody("{\"success\":1,\"data\":${ticker(System.currentTimeMillis()-100)}}")
        }
        val repoField=runCatching { GmkViewModel::class.java.getDeclaredField("bitcoinRepository") }.getOrElse { GmkViewModel::class.java.getDeclaredField("repository") }
        val repo=repoField.apply { isAccessible=true }.get(model) as MarketRepository;mockRepository(repo,http)
        val ws=server();val clock=AtomicLong(System.currentTimeMillis())
        val feed=subscribe(ws,clock,{ socket->socket.send(packet(clock.get()-100)) })
        runCatching { GmkViewModel::class.java.getDeclaredField("bitcoinRealtime").apply { isAccessible=true }.set(model,feed) }
        return feed to ws
    }
    @Test fun bitcoinStillUpdatesWhenBothScannersAreBusy() {
        val model=vm();state(model).value=state(model).value.copy(busy=true,oneMinuteBusy=true)
        installVmFeed(model);restart(model)
        waitFor("BTC must update independently while both scans own Yahoo slots") { model.state.value.rates.any { it.instrument=="BTCJPY" && it.price!=null && it.freshnessStatus=="LIVE" } }
        assertTrue(model.state.value.busy);assertTrue(model.state.value.oneMinuteBusy)
    }
    @Test fun aHungForexPairCannotDelayOtherCurrenciesOrBitcoin() {
        val model=vm();installVmFeed(model)
        val http=server();http.dispatcher=object:okhttp3.mockwebserver.Dispatcher() {
            override fun dispatch(request:RecordedRequest):MockResponse {
                if(request.path?.startsWith("/v8/finance/chart/JPY=X")==true)
                    return MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE)
                val now=System.currentTimeMillis()/1000
                return MockResponse().setBody("{\"chart\":{\"result\":[{\"meta\":{\"regularMarketTime\":$now,\"regularMarketPrice\":100.0},\"timestamp\":[],\"indicators\":{\"quote\":[{\"close\":[]}]}}],\"error\":null}}")
            }
        }
        val repo=GmkViewModel::class.java.getDeclaredField("forexRepository").apply { isAccessible=true }.get(model)as MarketRepository
        val client=OkHttpClient.Builder().addInterceptor { chain->
            chain.proceed(chain.request().newBuilder().url(http.url(chain.request().url.encodedPath)).build())
        }.build()
        clients+=client;MarketRepository::class.java.getDeclaredField("client").apply { isAccessible=true }.set(repo,client)
        restart(model)
        waitFor("A hanging USDJPY request blocked a healthy currency or the independent BTC stream") {
            model.state.value.rates.any { it.instrument=="EURJPY" && it.price==100.0 && it.freshnessStatus=="LIVE" } &&
                model.state.value.rates.any { it.instrument=="BTCJPY" && it.price!=null && it.freshnessStatus=="LIVE" }
        }
        assertNull(model.state.value.rates.single { it.instrument=="USDJPY" }.price)
        assertEquals("SUBSCRIBED",GmkViewModel::class.java.getDeclaredField("bitcoinRealtime").apply { isAccessible=true }.get(model).let { (it as BitbankRealtimeFeed).status })
    }
    private fun merge(model:GmkViewModel,old:List<RateRow>,incoming:List<RateRow>,elapsed:Double=0.0):List<RateRow> {
        val method=GmkViewModel::class.java.getDeclaredMethod("mergeRates",List::class.java,List::class.java,Double::class.javaPrimitiveType).apply { isAccessible=true }
        @Suppress("UNCHECKED_CAST")
        return method.invoke(model,old,incoming,elapsed) as List<RateRow>
    }
    private fun quote(symbol:String,ageMs:Long=100,price:Double=100.0):RateRow {
        val now=System.currentTimeMillis();return RateRow(symbol,price,null,null,"test live",ageMs/1000.0,"LIVE",sourceEpochMs=now-ageMs,receivedEpochMs=now)
    }
    @Test fun aPartialForexRefreshCannotDeleteTheLiveBitcoinRow() {
        val model=vm();val bitcoin=quote("BTCJPY",price=10_000_000.0)
        val rows=merge(model,listOf(bitcoin),listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY").map { quote(it) })
        assertEquals(6,rows.size);assertEquals(bitcoin.price,rows.single { it.instrument=="BTCJPY" }.price)
        assertEquals("LIVE",rows.single { it.instrument=="BTCJPY" }.freshnessStatus)
    }
    @Test fun anOlderRestSnapshotCannotReplaceANewerStreamTick() {
        val model=vm();val current=quote("BTCJPY",100,10_000_020.0);val older=quote("BTCJPY",3000,10_000_000.0)
        assertEquals(current.price,merge(model,listOf(current),listOf(older)).single { it.instrument=="BTCJPY" }.price)
        val staleFailure=RateRow("BTCJPY",null,null,null,"REST unavailable",null,"UNAVAILABLE",receivedEpochMs=current.receivedEpochMs!!-1)
        assertEquals("LIVE",merge(model,listOf(current),listOf(staleFailure)).single { it.instrument=="BTCJPY" }.freshnessStatus)
    }
    @Test fun inferenceQuoteCacheCannotRollBackToAnOlderRestSource() {
        val now=System.currentTimeMillis()
        val cache=HorizonMarketCache(java.io.File(app.cacheDir,"btc-quote-regression"))
        val current=quote("BTCJPY",100,10_000_020.0).copy(sourceEpochMs=now-100,receivedEpochMs=now)
        val delayed=quote("BTCJPY",3000,10_000_000.0).copy(sourceEpochMs=now-3000,receivedEpochMs=now+5)
        cache.observe(listOf(current));cache.observe(listOf(delayed))
        val snapshot=cache.quoteSnapshot(now+10).getValue("BTCJPY")
        assertEquals("AI must see the same newer source as the rate screen",current.price!!,snapshot.price,0.0)
        assertEquals(now-100,snapshot.sourceMs)
        val next=current.copy(price=10_000_030.0,sourceEpochMs=now+100,receivedEpochMs=now+110)
        cache.observe(listOf(next));assertEquals(10_000_030.0,cache.quoteSnapshot(now+200).getValue("BTCJPY").price,0.0)
    }
    @Test fun bitcoinUsesFifteenSecondExpiryWhileForexKeepsItsOwnLimit() {
        val model=vm();val symbols=listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY")
        val old=symbols.map { quote(it,16_000).copy(ageSeconds=10.0) }
        val incoming=symbols.map { quote(it,16_000).copy(freshnessStatus=if(it=="BTCJPY")"LAST" else "LIVE") }
        val rows=merge(model,old,incoming,6.0)
        assertEquals("LAST",rows.single { it.instrument=="BTCJPY" }.freshnessStatus)
        assertTrue(rows.filter { it.instrument!="BTCJPY" }.all { it.freshnessStatus=="LIVE" })
    }
    @Test fun loopRestartDoesNotLetTheCancelledOwnerStopTheNewSocket() {
        val model=vm();state(model).value=state(model).value.copy(busy=true)
        val (feed,ws)=installVmFeed(model)
        // Queue a second subscription for the explicit restart.
        subscribe(ws,AtomicLong(System.currentTimeMillis()),{ socket->socket.send(packet(System.currentTimeMillis()-100,10_000_030)) })
        restart(model);waitFor("First subscription missing") { feed.status=="SUBSCRIBED" }
        restart(model);waitFor("Restarted subscription was stopped by old cleanup") { feed.diagnosticStats().getLong("connections")>=2 && feed.status=="SUBSCRIBED" }
        assertEquals("SUBSCRIBED",feed.status)
    }
}

import org.junit.Test
import jp.gmk.mobile.domain.*
import java.io.File
import java.time.ZonedDateTime
import java.time.Duration
import jp.gmk.mobile.domain.r13.EntryMaskGuard

class PcSyncRegressionTest {
    private val root=File(requireNotNull(System.getProperty("gmk.projectRoot")))
    @Test fun actualJavaModelsFeaturesAndActionsMatchPc() {
        Class.forName("R13OfflineTest").getMethod("main",Array<String>::class.java).invoke(null,arrayOf(
            File(root,"app/src/main/assets/pc_r13").path,File(root,"tools/pc_r13_fixtures").path) as Any)
    }
    @Test fun aiMustPreserveEntryMaskAndScanIdentity() {
        for (entry in listOf(false,true)) {
            check(EntryMaskGuard.rejectionReason(entry,entry,"id","id","AUTO","AUTO","at","at")==null)
            check(EntryMaskGuard.rejectionReason(entry,!entry,"id","id","AUTO","AUTO","at","at")=="ENTRY_MASK_CHANGED")
            check(EntryMaskGuard.rejectionReason(entry,entry,"id","other","AUTO","AUTO","at","at")=="SCAN_IDENTITY_CHANGED")
        }
        check(EntryMaskGuard.meetsResearchFloor(70,100))
        check(!EntryMaskGuard.meetsResearchFloor(69,100))
    }
    @Test fun threeMinuteProfilePreservesEntrySymbolDirectionAndIdentity() {
        val at=ZonedDateTime.parse("2026-10-07T13:35:00+09:00")
        val top=ScanCandidate(1,"USDJPY","USD/JPY","HIGH","R",null,"ENTRY",reasons=listOf("判定: 15分"))
        val original=ScanResult("fixed-test",entryTimeJst=at.toString(),judgeTimeJst=at.plusMinutes(15).toString(),
            candidates=listOf(top),source="AUTO",policyVersion="GMK_V0736_PC_R13")
        val fixed=ExpiryProfiles.apply(original,true)
        check(fixed.top1!!.instrument==top.instrument && fixed.top1!!.direction==top.direction && fixed.top1!!.decision==top.decision)
        check(fixed.scanId==original.scanId && Duration.between(at,ZonedDateTime.parse(fixed.judgeTimeJst)).toMinutes()==3L)
        check(fixed.policyVersion.endsWith("_3M_FIXED") && ExpiryProfiles.apply(fixed,true)==fixed)
        check(ExpiryProfiles.apply(original,false)==original)
        check(ExpiryProfiles.apply(original.copy(source="AUTO_1M"),true).judgeTimeJst==original.judgeTimeJst)
        val row=HistoryRow(1,"fixed-test","AUTO",at.toString(),"USDJPY","HIGH","R","ENTRY",
            entryTimeJst=at.toString(),judgeTimeJst=fixed.judgeTimeJst,policyVersion=fixed.policyVersion)
        check(ExpiryProfiles.includes(row,true,false));check(!ExpiryProfiles.includes(row,false,false))
        check(ExpiryProfiles.includes(row.copy(policyVersion="LEGACY_UNVERSIONED"),false,true))
        check(!ExpiryProfiles.includes(row.copy(policyVersion="LEGACY_UNVERSIONED"),true,false))
    }
}

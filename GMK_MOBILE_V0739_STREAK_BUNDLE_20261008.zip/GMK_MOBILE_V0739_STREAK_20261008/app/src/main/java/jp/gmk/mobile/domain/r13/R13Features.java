package jp.gmk.mobile.domain.r13;

import java.util.Arrays;

/** Exact causal 60 x 12 minute sequence and 149-column PC XGB input. */
public final class R13Features {
    public static final String[] PRICE = {"return1","return2","return3","return5","return10","return15","return30","macd_hist","ema12_distance","ema26_distance","body","range","upper_wick","lower_wick","m5_return1","m5_trend12_26","m15_return1","m15_trend12_26","partial_body","partial_range","jpy_mean5","jpy_mean15","relative_strength5","underlying_USD_return1","underlying_USD_return5","driver_USD_strength1","driver_USD_strength5"};
    public static final String[] OTHER = {"rsi7","rsi14","bb_z12","bb_z20","unchanged_fraction5","unchanged_fraction15","volume_ratio","m5_rsi7","m15_rsi7","jpy_agreement","correlation_12","correlation_36","time_sin","time_cos","spread_bps","partial_progress","quote_age","symbol0","symbol1","symbol2","symbol3","symbol4","symbol5"};
    public static final String[] NATIVE = {"score","confidence","regimeConfidence","rsi14","rsi7","atrPct","agreement","efficiency","emaGapAtr","alternation","emaSlopeAtr","switchCounterTrend"};
    public static final String[] MINUTE_SYMBOLS = {"USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY","EURUSD","GBPUSD","AUDUSD","NZDUSD","BTCUSD"};
    private R13Features() {}
    public static final class Inputs {
        public final float[][] raw, context, tree;
        public final float[][][] minute;
        private Inputs(float[][] raw, float[][] context, float[][][] minute, float[][] tree) {
            this.raw=raw; this.context=context; this.minute=minute; this.tree=tree;
        }
    }
    private static float clean(double v, double limit, boolean clip) {
        if (Double.isNaN(v)) return 0;
        if (v == Double.POSITIVE_INFINITY) return (float) limit;
        if (v == Double.NEGATIVE_INFINITY) return (float) -limit;
        return (float) (clip ? Math.max(-limit, Math.min(limit, v)) : v);
    }
    private static double log(double a, double b, float atr) { return 10000 * Math.log(a / b) / atr; }
    private static double volumeLog(double v) {return Math.log1p(Double.isNaN(v)||v<0?0:v==Double.POSITIVE_INFINITY?Double.MAX_VALUE:v);}
    /** NumPy uses eight accumulators for contiguous float32 reductions of >=8 values. */
    private static float sum(float[] v) {
        if(v.length<8){float total=-0f;for(float x:v)total+=x;return total;}
        float[] r=Arrays.copyOf(v,8);int i=8;
        for(;i<v.length-v.length%8;i+=8)for(int k=0;k<8;k++)r[k]+=v[i+k];
        float total=((r[0]+r[1])+(r[2]+r[3]))+((r[4]+r[5])+(r[6]+r[7]));
        for(;i<v.length;i++)total+=v[i];return total;
    }
    public static Inputs build(float[][] rows, float[][] nativeFeatures, double[][][] bars) {
        if (rows.length != 6 || nativeFeatures.length != 6 || bars.length != 61) throw new IllegalArgumentException("R13-FEATURE-SHAPE");
        float[][] raw = new float[6][50], context = new float[6][62]; float[] atr = new float[6];
        for (int s = 0; s < 6; s++) {
            if (rows[s].length != 51 || nativeFeatures[s].length != 12) throw new IllegalArgumentException("R13-CONTEXT-SHAPE");
            atr[s] = Math.max(Math.abs(rows[s][50]), 1e-4f);
            for (int j = 0; j < 50; j++) {
                float x = j < PRICE.length ? Math.max(-100, Math.min(100, rows[s][j] / atr[s])) : rows[s][j];
                raw[s][j] = clean(x, 100, false); context[s][j] = raw[s][j];
            }
            for (int j = 0; j < 12; j++) context[s][50 + j] = clean(nativeFeatures[s][j],100,false);
        }
        boolean[][] present = new boolean[61][11]; float[][] returns = new float[61][11]; float[] fx = new float[61];
        for (int t = 0; t < 61; t++) {
            if (bars[t].length != 11) throw new IllegalArgumentException("R13-MINUTE-SHAPE");
            for (int s = 0; s < 11; s++) {
                double[] q = bars[t][s]; if (q.length != 5) throw new IllegalArgumentException("R13-OHLCV-SHAPE");
                boolean p = q[1] >= q[2];
                for (int j = 0; j < 4; j++) p &= Double.isFinite(q[j]) && q[j] > 0;
                present[t][s] = p;
                if (t > 0 && p && present[t - 1][s]) returns[t][s] = (float) (10000 * Math.log(q[3] / bars[t - 1][s][3]));
            }
            int den = 0; float sum = 0;
            for (int s = 0; s < 5; s++) { if (present[t][s]) den++; sum += returns[t][s]; }
            fx[t] = den > 0 ? sum / den : 0;
        }
        float[][][] seq = new float[6][60][12];
        for (int s = 0; s < 6; s++) {
            double vm = 0; int den = 0;
            for (int t = 1; t < 61; t++) if (present[t][s]) { vm += volumeLog(bars[t][s][4]); den++; }
            vm = den > 0 ? vm / den : 0;
            double last = bars[60][s][3];
            for (int t = 1; t < 61; t++) {
                float[] z = seq[s][t - 1];
                z[10]=present[t][s]?1:0;z[11]=present[t-1][s]?1:0;
                if (!present[t][s]) continue;
                double[] q = bars[t][s]; double o=q[0],h=q[1],l=q[2],c=q[3];
                z[0]=clean(log(c,last,atr[s]),20,true); z[1]=clean(log(o,last,atr[s]),20,true);
                z[2]=clean(log(c,o,atr[s]),20,true); z[3]=clean(log(h,l,atr[s]),20,true);
                z[4]=clean(log(h,Math.max(o,c),atr[s]),20,true); z[5]=clean(log(Math.min(o,c),l,atr[s]),20,true);
                z[6]=clean(returns[t][s]/atr[s],20,true);
                z[7]=clean(volumeLog(q[4])-vm,20,true);
                z[8]=clean(fx[t]/atr[s],20,true); z[9]=s==0?0:clean(returns[t][s+5]/atr[s],20,true);
                z[10]=1; z[11]=present[t-1][s]?1:0;
            }
            if (!present[60][s]) for (float[] z : seq[s]) {z[0]=0;z[1]=0;}
        }
        float[][] summary = summarize(seq), tree = new float[18][149];
        for (int s = 0; s < 6; s++) for (int h = 0; h < 3; h++) {
            System.arraycopy(context[s],0,tree[s*3+h],0,62);
            System.arraycopy(summary[s],0,tree[s*3+h],62,84);
            tree[s*3+h][146+h]=1;
        }
        return new Inputs(raw,context,seq,tree);
    }
    public static float[][] summarize(float[][][] seq) {
        float[][] result = new float[seq.length][84]; int[] windows={3,5,10,15,30,60};
        for (int s=0;s<seq.length;s++) for (int wi=0;wi<windows.length;wi++) {
            int w=windows[wi],start=60-w,den=0,vd=0,pos=0,switches=0; float total=0,absTotal=0,low=Float.POSITIVE_INFINITY,high=Float.NEGATIVE_INFINITY;
            float[] sums=new float[10];float[][] masked=new float[10][w];
            for (int t=start;t<60;t++) {
                float[] z=seq[s][t]; boolean valid=z[10]>0 && z[11]>0;
                if (z[10]>0) {
                    den++;low=Math.min(low,z[0]);high=Math.max(high,z[0]);
                    for(int j=2;j<=5;j++)masked[j][t-start]=z[j];
                    masked[7][t-start]=z[7];masked[8][t-start]=z[8];masked[9][t-start]=z[9];
                }
                if(valid) {
                    vd++;masked[0][t-start]=z[6];masked[1][t-start]=Math.abs(z[6]);if(z[6]>0)pos++;
                    if(t>start && seq[s][t-1][10]>0 && seq[s][t-1][11]>0 && z[6]*seq[s][t-1][6]<0)switches++;
                }
            }
            total=sum(masked[0]);absTotal=sum(masked[1]);for(int j=2;j<10;j++)sums[j]=sum(masked[j]);
            double mu=total/(double)Math.max(vd,1), variance=0;
            for(int t=start;t<60;t++)if(seq[s][t][10]>0 && seq[s][t][11]>0) {double delta=seq[s][t][6]-mu;variance+=delta*delta;}
            double location=Float.isFinite(high-low) && high>low?(seq[s][59][0]-low)/(high-low):0;
            double[] values={total,Math.sqrt(variance/Math.max(vd,1)),pos/(double)Math.max(vd,1),switches/(double)Math.max(vd-1,1),Math.abs(total)/Math.max(absTotal,1e-6f),
                sums[2]/(double)Math.max(den,1),sums[3]/(double)Math.max(den,1),sums[4]/(double)Math.max(den,1),sums[5]/(double)Math.max(den,1),location,sums[8],sums[9],seq[s][59][7]-sums[7]/(double)Math.max(den,1),den/(double)w};
            for(int j=0;j<14;j++)result[s][wi*14+j]=clean(values[j],100,false);
        }
        return result;
    }
}

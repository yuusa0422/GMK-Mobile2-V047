package jp.gmk.mobile.domain.horizon

import java.util.ArrayDeque
import kotlin.math.floor

data class HorizonDecision(val symbol: Int, val high: Boolean, val minutes: Int, val entry: Boolean)
data class HorizonCorrection(val decision: HorizonDecision, val changed: Boolean, val utility: Double?, val reason: String)

/** Pure correction contract: never changes ENTRY/SKIP or instrument, and protects native3m. */
class HorizonFlipPolicy(private val model: PortableTreeModel) {
    init { require(model.featureNames.size == 90) }
    fun correct(base: HorizonDecision, pathFeatures: FloatArray?, strictSafe: Boolean, pathValid: Boolean,
                exactNative: Boolean, boundaryEpoch: Long, availableFromEpoch: Long = HorizonModelCatalog.AVAILABLE_FROM_EPOCH): HorizonCorrection {
        fun keep(reason: String) = HorizonCorrection(base,false,null,reason)
        if (!base.entry || base.minutes != 15 || base.symbol !in 0..5 || exactNative) return keep("BASE_PROTECTED")
        if (boundaryEpoch-10 < availableFromEpoch) return keep("MODEL_NOT_AVAILABLE_AT_SCAN")
        if (!strictSafe || !pathValid || pathFeatures == null || pathFeatures.size != 90 || pathFeatures.any { !it.isFinite() }) return keep("INPUT_UNAVAILABLE")
        val utility = model.predict(pathFeatures)[0]
        if (!utility.isFinite()) return keep("MODEL_UNAVAILABLE")
        return if (utility >= 0.025) HorizonCorrection(base.copy(high=!base.high,minutes=3),true,utility,"R15_APPLIED")
        else HorizonCorrection(base,false,utility,"BASE_UTILITY_HIGHER")
    }
}

/** Rolling, past-only coverage gate. Current score is added after the decision. */
class PastCoverageGate(seed: List<Double> = emptyList()) {
    private val scores = ArrayDeque<Double>()
    init { seed.filterNot { it.isNaN() }.takeLast(1000).forEach { scores.addLast(it) } }
    fun decide(score: Double, available: Boolean, forced: Boolean): Pair<Boolean,Double> {
        val sorted=scores.toDoubleArray().sortedArray()
        val cut=if(sorted.isEmpty()) Double.NEGATIVE_INFINITY else sorted[floor((1.0-0.72)*(sorted.size-1)).toInt()]
        val enter=available && (forced || score>=cut)
        scores.addLast(if(available && forced) Double.POSITIVE_INFINITY else if(available) score else Double.NEGATIVE_INFINITY)
        if(scores.size>1000) scores.removeFirst()
        return enter to cut
    }
    fun snapshot(): List<Double> = scores.toList()
    fun restore(seed: List<Double>) {
        scores.clear()
        seed.filterNot { it.isNaN() }.takeLast(1000).forEach { scores.addLast(it) }
    }
}

data class HorizonChoice(val decision: HorizonDecision, val score: Double, val cutoff: Double)

class JointHorizonPolicy(private val models: List<PortableTreeModel>, private val gate: PastCoverageGate) {
    init { require(models.size==3 && models.all { it.featureNames.size==152 }) }
    fun choose(features: Array<Array<FloatArray>>, safe: BooleanArray, native: HorizonDecision): HorizonChoice {
        require(features.size==6 && safe.size==6 && features.all { it.size==3 })
        val horizons=intArrayOf(3,10,15)
        var best=Double.NEGATIVE_INFINITY
        var selected=HorizonDecision(0,false,3,false)
        var nativeScore=Double.NEGATIVE_INFINITY
        for(s in 0..5) for(j in 0..2) {
            val probabilities=models[j].predict(features[s][j])
            for(side in 0..1) {
                val score=probabilities[if(side==0) 0 else 2]
                if(s==native.symbol && j==0 && (side==1)==native.high) nativeScore=score
                if(safe[s] && score.isFinite() && score>best) {
                    best=score; selected=HorizonDecision(s,side==1,horizons[j],false)
                }
            }
        }
        val force=native.entry && safe[native.symbol]
        if(force) { selected=native; best=nativeScore }
        val (entry,cut)=gate.decide(best,best.isFinite() || force,force)
        return HorizonChoice(selected.copy(entry=entry),best,cut)
    }
}

package jp.gmk.mobile.domain.r13;

/** Frozen PC R11 -> R12 -> R13 arithmetic. No fitting, outcomes or online tuning. */
public final class R13Policy {
    public static final String VERSION = "PC_R19_R13_MAX_V1";
    public static final String POLICY = "LONG_XGB_M1_C_PLUS_NON_NATIVE_OPEN36_M10";
    public static final int[] HORIZONS = {3, 10, 15};
    private R13Policy() {}

    private static void validate(float[][][] p) {
        if (p.length != 6) throw new IllegalArgumentException("R13-PROBABILITY-SHAPE");
        for (float[][] symbol : p) {
            if (symbol.length != 3) throw new IllegalArgumentException("R13-PROBABILITY-SHAPE");
            for (float[] horizon : symbol) {
                if (horizon.length != 3) throw new IllegalArgumentException("R13-PROBABILITY-SHAPE");
                float sum = 0;
                for (float x : horizon) {
                    if (!Float.isFinite(x) || x < 0 || x > 1) throw new IllegalArgumentException("R13-PROBABILITY-RANGE");
                    sum += x;
                }
                if (Math.abs(sum - 1) > 3e-5) throw new IllegalArgumentException("R13-PROBABILITY-RANGE");
            }
        }
    }
    public static int propose(float[][][] p, boolean[] safe, int base, boolean sameSymbol, double margin) {
        validate(p);
        int choice = -1;
        float score = Float.NEGATIVE_INFINITY;
        for (int action = 0; action < 36; action++) {
            int symbol = action / 6;
            if (!safe[symbol] || (sameSymbol && symbol != base / 6)) continue;
            float value = p[symbol][action % 6 / 2][action % 2 == 0 ? 0 : 2];
            // First action wins an exact tie, as in numpy.argmax.
            if (value > score) { score = value; choice = action; }
        }
        float original = p[base / 6][base % 6 / 2][base % 2 == 0 ? 0 : 2];
        // PC uses float32 probabilities with NumPy 2 scalar promotion.
        return choice >= 0 && score > original + (float) margin ? choice : base;
    }
    public static int decide(int base, boolean entry, boolean nativeEntry, String grade, boolean[] safe,
            float[][][] tcn, float[][][] minuteTcn, float[][][] minuteLstm, float[][][] minuteLinear,
            float[][][] rule, float[][][] xgb) {
        if (base < 0 || base >= 36 || safe.length != 6) throw new IllegalArgumentException("R13-ACTION-CONTRACT");
        if (!entry || (nativeEntry && (grade.equals("S") || grade.equals("A") || grade.equals("B")))) return base;
        if (!safe[base / 6]) throw new IllegalArgumentException("R13-UNSAFE-BASE");
        int action = base;
        if (!nativeEntry) action = propose(tcn, safe, action, true, .06);
        if (nativeEntry && grade.equals("C")) {
            float[][][] combined = new float[6][3][3];
            for (int s = 0; s < 6; s++) for (int h = 0; h < 3; h++) for (int c = 0; c < 3; c++) {
                float minute = ((minuteTcn[s][h][c] + minuteLstm[s][h][c]) + minuteLinear[s][h][c]) / 3f;
                combined[s][h][c] = .5f * (rule[s][h][c] + minute);
            }
            action = propose(combined, safe, action, true, .10);
        }
        action = propose(xgb, safe, action, false, .10);
        if (!safe[action / 6]) throw new IllegalArgumentException("R13-UNSAFE-RESULT");
        return action;
    }
}

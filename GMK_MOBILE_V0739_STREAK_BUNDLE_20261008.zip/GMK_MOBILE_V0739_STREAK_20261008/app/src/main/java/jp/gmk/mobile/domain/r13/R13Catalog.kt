package jp.gmk.mobile.domain.r13

object R13Catalog {
    const val AVAILABLE_FROM = 1785715190L
    val hashes = linkedMapOf(
        "TCN" to "a47bc6ebae8141d034d36eac5ad078b07c33e483b8dda65fd05b16b82ed36668",
        "M1_TCN" to "222fb59bd42e51f7b371e63d9b66f085cbe884cdbf7278ae1fe9f8d95b3bd72d",
        "M1_LSTM" to "2d5fd00d5c32b38884d4092dd4de33f73c3db0488cea69757152681260eeb28a",
        "M1_LINEAR" to "85bd213f509b67b10b21fb71e8f29650c850e0eb8438bdff7e662a8e7ff63743",
        "XGB" to "ecf071653053c35411688791cd0097e45674ae79d81ba3ef45df85a4b328ea5c"
    )
}

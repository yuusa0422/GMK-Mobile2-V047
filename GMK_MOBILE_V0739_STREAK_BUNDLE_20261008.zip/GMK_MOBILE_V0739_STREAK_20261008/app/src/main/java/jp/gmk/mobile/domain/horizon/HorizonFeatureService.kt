package jp.gmk.mobile.domain.horizon

import jp.gmk.mobile.domain.Candle
import jp.gmk.mobile.domain.LocalRuleEngine
import java.time.Instant
import java.time.ZoneId
import kotlin.math.*

data class HorizonQuote(val receivedMs: Long, val sourceMs: Long, val price: Double,
    val bid: Double?, val ask: Double?, val live: Boolean,
    val partialStartMs: Long? = null, val partialOpen: Double? = null,
    val partialHigh: Double? = null, val partialLow: Double? = null,
    val partialCount: Int = 0)

/** All values are assembled from data available by B-10. This class never fetches data. */
class HorizonFeatureService(
    prices: Map<String,List<Candle>>,
    private var quotes: Map<String,HorizonQuote>,
    private val boundary: Long,
    private val ruleEngine: LocalRuleEngine,
    private val deadlineNanos: Long = Long.MAX_VALUE
) {
    companion object {
        val SYMBOLS=listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY","AUDUSD","BTCUSD","USDCAD","CADJPY","USDCHF","CHFJPY","ETHUSD","EURAUD","EURGBP","EURUSD","GBPAUD","GBPUSD","NZDUSD")
        private val JST=ZoneId.of("Asia/Tokyo")
        private val SIGNED_ATR=listOf("return1","return2","return3","return5","return10","return15","return30","return60","macd","macd_hist","ema12_distance","ema26_distance","body","m5_return1","m15_return1","m5_trend12_26","m15_trend12_26","currency_strength_gap3","currency_strength_gap5","currency_strength_gap15")
        private val RSI=listOf("rsi7","rsi14","m5_rsi7","m15_rsi7")
        private val DIRECT=listOf("bb_z12","bb_z20","direction3","engulf")
        private val PATH_SIGNED=listOf("return3_atr_signed","return15_atr_signed","macd_hist_atr_signed","ema26_distance_atr_signed","body_atr_signed","m5_trend12_26_atr_signed","m15_trend12_26_atr_signed","currency_strength_gap5_atr_signed","rsi7_centered_signed","bb_z20_signed")
        private val PATH_UNSIGNED=listOf("volatility15_60_ratio","range_atr","unchanged_fraction15")
        fun scheduled(epoch: Long): Boolean {
            val t=Instant.ofEpochSecond(epoch).atZone(JST)
            return epoch%300L==0L && t.dayOfWeek.value<=5 && t.hour in 9..22
        }
        fun previousSlots(epoch: Long,count: Int): List<Long> {
            val out=ArrayList<Long>();var at=epoch-300
            while(out.size<count) { if(scheduled(at)) out.add(at);at-=300 }
            return out.reversed()
        }
        /** PC quote_safe check; independent of model/history readiness. */
        fun nativeQuoteSafe(symbol: String, q: HorizonQuote?, boundary: Long, close: Double): Boolean {
            if (q == null || !close.isFinite() || close <= 0) return false
            val scan = (boundary - 10) * 1000
            val age = (scan - q.sourceMs) / 1000.0
            if (q.receivedMs > scan || age !in 0.0..10.0 || !q.live || !q.price.isFinite() || q.price <= 0) return false
            if (q.bid != null || q.ask != null) {
                val bid = q.bid ?: return false
                val ask = q.ask ?: return false
                if (!bid.isFinite() || !ask.isFinite() || bid <= 0 || ask < bid || (ask-bid)/q.price*1e4 > 30) return false
            }
            return abs(q.price/close-1) < if (symbol == "BTCJPY") .015 else .005
        }
        private fun clean(v: Float): Float=when { v.isNaN()->0f;v==Float.POSITIVE_INFINITY->20f;v==Float.NEGATIVE_INFINITY->-20f;else->v.coerceIn(-20f,20f) }
        private fun mean(x: List<Double>): Double=if(x.isEmpty() || x.any { !it.isFinite() }) Double.NaN else x.average()
        private fun sd(x: List<Double>): Double { val m=mean(x);return sqrt(x.sumOf { (it-m)*(it-m) }/x.size) }
        private fun rsi(c: List<Double>, n: Int): Double {
            if(c.size<=n)return Double.NaN
            val d=c.takeLast(n+1).zipWithNext { a,b->b-a };val gain=d.sumOf { max(0.0,it) };val loss=d.sumOf { max(0.0,-it) }
            return if(gain+loss==0.0) .5 else gain/(gain+loss)
        }
    }

    private class Series(val bars: List<Candle>) {
        val ema12=DoubleArray(bars.size);val ema26=DoubleArray(bars.size);val signal=DoubleArray(bars.size)
        private val higher=HashMap<Int,Series>()
        init {
            for(i in bars.indices) {
                val c=bars[i].close
                ema12[i]=if(i==0)c else (2.0/13)*c+(1-2.0/13)*ema12[i-1]
                ema26[i]=if(i==0)c else (2.0/27)*c+(1-2.0/27)*ema26[i-1]
                val macd=ema12[i]-ema26[i];signal[i]=if(i==0)macd else .2*macd+.8*signal[i-1]
            }
        }
        fun index(epoch: Long): Int { var lo=0;var hi=bars.size;while(lo<hi){val m=(lo+hi)/2;if(bars[m].timeEpochMs/1000<=epoch)lo=m+1 else hi=m};return lo-1 }
        fun open(epoch: Long): Double { val i=index(epoch);return if(i>=0 && bars[i].timeEpochMs/1000==epoch)bars[i].open else Double.NaN }
        fun valid(b: Long): Boolean {
            val i=index(b-70);if(i<60 || bars[i].timeEpochMs/1000!=b-120)return false
            return (i-59..i).all { j->bars[j].timeEpochMs-bars[j-1].timeEpochMs==60_000L }
        }
        fun context(b: Long, limit: Int = 120): List<Candle> { val i=index(b-70);return if(i<0)emptyList() else bars.subList(max(0,i-limit+1),i+1) }
        fun higher(minutes: Int): Series = higher.getOrPut(minutes) {
            val width=minutes*60_000L
            val groups=bars.groupBy { it.timeEpochMs/width*width }
            Series(groups.entries.filter { (start,v)->v.size==minutes && v.first().timeEpochMs==start && v.last().timeEpochMs==start+width-60_000 && v.zipWithNext().all { (a,b)->b.timeEpochMs-a.timeEpochMs==60_000L } }.sortedBy { it.key }.map { (start,v)->Candle(start+width,v.first().open,v.maxOf { it.high },v.minOf { it.low },v.last().close,v.sumOf { it.volume }) })
        }
        fun features(b: Long): MutableMap<String,Double> {
            val f=linkedMapOf<String,Double>();val i=index(b-70)
            if(i<60)return f
            val x=bars[i];val c=x.close
            for(n in listOf(1,2,3,5,10,15,30,60))f["return$n"]=(c/bars[i-n].close-1)*1e4
            for(n in listOf(7,14)) {
                f["rsi$n"]=rsi(bars.subList(i-n,i+1).map { it.close },n)
                f["atr$n"]=(i-n+1..i).map { j->max(bars[j].high-bars[j].low,max(abs(bars[j].high-bars[j-1].close),abs(bars[j].low-bars[j-1].close))) }.average()/c*1e4
            }
            for(n in listOf(12,20)) { val v=bars.subList(i-n+1,i+1).map { it.close };val m=v.average();val s=sd(v);f["bb_z$n"]=if(s==0.0)0.0 else (c-m)/s;f["bb_width$n"]=s/m*4e4 }
            val macd=ema12[i]-ema26[i];f["macd"]=macd/c*1e4;f["macd_hist"]=(macd-signal[i])/c*1e4;f["ema12_distance"]=(c/ema12[i]-1)*1e4;f["ema26_distance"]=(c/ema26[i]-1)*1e4
            for(n in listOf(5,15,60)) {
                f["volatility$n"]=sd((i-n+1..i).map { j->ln(bars[j].close)-ln(bars[j-1].close) })*1e4
                f["unchanged_fraction$n"]=(i-n+1..i).count { j->bars[j].close==bars[j-1].close }.toDouble()/n
            }
            f["body"]=(c-x.open)/c*1e4;f["range"]=(x.high-x.low)/c*1e4;f["upper_wick"]=(x.high-max(c,x.open))/c*1e4;f["lower_wick"]=(min(c,x.open)-x.low)/c*1e4
            f["volume_ratio"]=x.volume/(bars.subList(i-29,i+1).map { it.volume }.average()+1e-9)
            f["direction3"]=(i-2..i).sumOf { j->sign(bars[j].close-bars[j].open) }/3.0
            val p=bars[i-1];f["engulf"]=if(c>x.open && p.close<p.open && c>=p.open && x.open<=p.close)1.0 else if(c<x.open && p.close>p.open && c<=p.open && x.open>=p.close)-1.0 else 0.0
            for(n in listOf(5,15)) {
                val z=higher(n);val j=z.index(b-10);val prefix="m${n}_"
                if(j>=26) {
                    val last=z.bars[j];f[prefix+"return1"]=(last.close/z.bars[j-1].close-1)*1e4
                    f[prefix+"trend12_26"]=(z.ema12[j]/z.ema26[j]-1)*1e4;f[prefix+"rsi7"]=rsi(z.bars.subList(j-7,j+1).map { it.close },7)
                    f[prefix+"range"]=(last.high-last.low)/last.close*1e4;f[prefix+"age"]=(b-10-last.timeEpochMs/1000).toDouble()/(n*60)
                } else for(k in listOf("return1","trend12_26","rsi7","range","age"))f[prefix+k]=Double.NaN
            }
            f["feature_age"]=(b-10-x.timeEpochMs/1000-60)/60.0
            return f
        }
    }

    private val series=SYMBOLS.map { symbol -> Series(prices[symbol].orEmpty().filter { c->c.timeEpochMs>0 && listOf(c.open,c.high,c.low,c.close).all { it.isFinite() } && minOf(c.open,c.high,c.low,c.close)>0 && c.high>=max(c.open,c.close) && c.low<=min(c.open,c.close) }.distinctBy { it.timeEpochMs }.sortedBy { it.timeEpochMs }) }
    private val rawCache=HashMap<Long,List<MutableMap<String,Double>>>()
    private val ruleCache=HashMap<Long,Map<String,Map<String,Double>>>()
    private fun checkpoint() { check(System.nanoTime()<deadlineNanos) { "FEATURE_PREPARE_DEADLINE" } }
    /** Prepared frame is consumed once by the scan adapter; never shared across scans. */
    fun attachQuotes(values: Map<String,HorizonQuote>) { quotes=values }
    fun currentRuleFeatures(): Map<String,Map<String,Double>> = rules(boundary)
    fun completedPrices(): Map<String,List<Candle>> = SYMBOLS.mapIndexed { i,s ->
        s to series[i].bars.filter { it.timeEpochMs / 1000 <= boundary - 120 }
    }.toMap()
    fun fillQuotes(features: Array<Array<FloatArray>>, names: List<List<String>>) {
        for(s in 0..5) for(j in 0..2) for((name,value) in quoteFeatures(s)) {
            val index=names[j].indexOf(name)
            if(index>=0)features[s][j][index]=value.toFloat()
        }
    }
    fun matchesNative(values: Map<String,List<Candle>>): Boolean = SYMBOLS.take(6).withIndex().all { (i,s) ->
        series[i].context(boundary)==values[s].orEmpty().filter { it.timeEpochMs/1000<=boundary-70 }.takeLast(120)
    }
    private fun rules(b: Long): Map<String,Map<String,Double>> = ruleCache.getOrPut(b) {
        checkpoint()
        val context=SYMBOLS.take(6).mapIndexed { i,s->s to series[i].context(b,121) }.toMap()
        val unavailable=context.values.any { rows->rows.size<21 || rows.last().timeEpochMs/1000!=b-120 ||
            rows.takeLast(30).zipWithNext().any { (a,z)->z.timeEpochMs-a.timeEpochMs!=60_000L } }
        if(unavailable)emptyMap() else ruleEngine.horizonRuleFeatures(context,Instant.ofEpochSecond(b).atZone(JST))
    }
    private fun raw(b: Long): List<MutableMap<String,Double>> = rawCache.getOrPut(b) {
        checkpoint()
        val f=series.map { it.features(b) };val time=Instant.ofEpochSecond(b).atZone(JST);val minute=time.hour*60+time.minute
        val valid=series.map { it.valid(b) }
        for((s,m) in f.withIndex()) {
            m["time_sin"]=sin(2*PI*minute/1440);m["time_cos"]=cos(2*PI*minute/1440)
            for(day in 0..4)m["dow$day"]=if(time.dayOfWeek.value-1==day)1.0 else 0.0
            for(k in 0..5)m["symbol$k"]=if(s==k)1.0 else 0.0
            m["cross_available"]=valid.take(6).count { it }/6.0
        }
        for(n in listOf(3,5,15)) {
            val currencies=SYMBOLS.flatMap { listOf(it.take(3),it.drop(3)) }.toSet()
            val strength=currencies.associateWith { currency->
                val terms=SYMBOLS.indices.filter { valid[it] && currency in listOf(SYMBOLS[it].take(3),SYMBOLS[it].drop(3)) }.map { s->(f[s]["return$n"] ?: Double.NaN)*(if(SYMBOLS[s].take(3)==currency)1 else -1) }.filter { it.isFinite() }
                if(terms.isEmpty())Double.NaN else terms.average()
            }
            for(s in f.indices)f[s]["currency_strength_gap$n"]=strength.getValue(SYMBOLS[s].take(3))-strength.getValue(SYMBOLS[s].drop(3))
        }
        f
    }
    val ready: Boolean get()=series.take(6).all { it.index(boundary-70)>=3999 && it.valid(boundary) && it.higher(15).index(boundary-10)>=180 } && rules(boundary).size==6
    fun strictSafe(symbol: Int): Boolean {
        if(symbol !in 0..5 || !series[symbol].valid(boundary))return false
        val q=quotes[SYMBOLS[symbol]] ?: return false;val scan=(boundary-10)*1000;val age=(scan-q.sourceMs)/1000.0
        if(q.receivedMs>scan || age !in 0.0..10.0 || !q.live || !q.price.isFinite() || q.price<=0)return false
        if(q.bid!=null || q.ask!=null) {
            val bid=q.bid ?: return false;val ask=q.ask ?: return false
            if(!bid.isFinite() || !ask.isFinite() || bid<=0 || ask<bid || (ask-bid)/q.price*1e4>30)return false
        }
        val last=series[symbol].context(boundary).last().close
        return abs(q.price/last-1)<if(symbol==5).015 else .005
    }
    private fun quoteFeatures(symbol: Int): Map<String,Double> {
        val q=quotes[SYMBOLS[symbol]];val f=linkedMapOf<String,Double>();val scan=(boundary-10)*1000L
        val present=q!=null && q.price.isFinite() && q.price>0 && q.receivedMs<=scan && q.sourceMs<=scan
        f["quote_present"]=if(present)1.0 else 0.0;f["partial_present"]=0.0
        for(k in listOf("quote_age","quote_gap","spread_bps","partial_body","partial_range","partial_upper","partial_lower","partial_tick_count","partial_progress"))f[k]=Double.NaN
        if(!present)return f
        val c=series[symbol].context(boundary).lastOrNull()?.close ?: return f
        f["quote_age"]=min((scan-q.sourceMs)/1000.0,300.0)/300.0;f["quote_gap"]=ln(q.price/c)*1e4
        if(q.bid!=null && q.ask!=null && q.bid.isFinite() && q.ask.isFinite() && q.bid>0 && q.ask>=q.bid)f["spread_bps"]=(q.ask-q.bid)/q.price*1e4
        val po=q.partialOpen;val ph=q.partialHigh;val pl=q.partialLow
        if(q.partialStartMs==(boundary-60)*1000 && po!=null && ph!=null && pl!=null && po>0 && pl>0 && ph>=max(po,q.price) && pl<=min(po,q.price) && q.partialCount>=1) {
            f["partial_present"]=1.0;f["partial_body"]=(q.price-po)/q.price*1e4;f["partial_range"]=(ph-pl)/q.price*1e4;f["partial_upper"]=(ph-max(po,q.price))/q.price*1e4;f["partial_lower"]=(min(po,q.price)-pl)/q.price*1e4;f["partial_tick_count"]=ln1p(q.partialCount.toDouble());f["partial_progress"]=5.0/6
        }
        return f
    }
    private fun normalized(symbol: Int,b: Long): Map<String,Float> {
        val source=raw(b)[symbol];fun f(k: String)=(source[k] ?: Double.NaN).toFloat()
        val atr=max(f("atr14"),.01f);val values=linkedMapOf<String,Float>()
        for(k in SIGNED_ATR)values[k+"_atr_signed"]=f(k)/atr
        for(k in RSI)values[k+"_centered_signed"]=2f*f(k)-1f
        for(k in DIRECT)values[k+"_signed"]=f(k)
        values["wick_support_signed"]=(f("lower_wick")-f("upper_wick"))/max(f("range"),.01f)
        values["atr7_ratio"]=f("atr7")/atr;values["volatility5_15_ratio"]=f("volatility5")/max(f("volatility15"),.01f);values["volatility15_60_ratio"]=f("volatility15")/max(f("volatility60"),.01f)
        values["range_atr"]=f("range")/atr;values["bb_width20_atr"]=f("bb_width20")/atr
        for(k in listOf("unchanged_fraction5","unchanged_fraction15","unchanged_fraction60","volume_ratio","time_sin","time_cos"))values[k]=f(k)
        values["crypto"]=if(SYMBOLS[symbol].startsWith("BTC") || SYMBOLS[symbol].startsWith("ETH"))1f else 0f;values["atr_zero"]=if(f("atr14")<=0)1f else 0f
        val missing=values.values.count { !it.isFinite() }.toFloat()/values.size
        return values.mapValues { clean(it.value) }+mapOf("missing_fraction" to missing)
    }
    fun pathValid(): Boolean=(0..3).all { lag->scheduled(boundary-300*lag) && series.take(6).all { it.valid(boundary-300*lag) } }
    fun flipFeatures(symbol: Int,high: Boolean,names: List<String>): FloatArray {
        val sequence=(0..3).map { normalized(symbol,boundary-300*it) };val f=LinkedHashMap(sequence[0]);val q=quoteFeatures(symbol).mapValues { it.value.toFloat() };val atr=max(raw(boundary)[symbol].getValue("atr14").toFloat(),.01f)
        val qp=q.getValue("quote_present")>.5f;val pp=q.getValue("partial_present")>.5f
        f["quote_gap_atr_signed"]=clean(if(qp)q.getValue("quote_gap")/atr else 0f);f["partial_body_atr_signed"]=clean(if(pp)q.getValue("partial_body")/atr else 0f);f["partial_wick_support_signed"]=clean(if(pp)(q.getValue("partial_lower")-q.getValue("partial_upper"))/max(q.getValue("partial_range"),.01f) else 0f)
        f["partial_range_atr"]=clean(if(pp)q.getValue("partial_range")/atr else 0f);f["spread_atr"]=clean(if(qp)q.getValue("spread_bps")/atr else 0f)
        f["quote_age"]=clean(if(qp)q.getValue("quote_age") else 0f);f["partial_tick_count"]=clean(if(pp)q.getValue("partial_tick_count") else 0f);f["partial_progress"]=clean(if(pp)q.getValue("partial_progress") else 0f);f["quote_present"]=if(qp)1f else 0f;f["partial_present"]=if(pp)1f else 0f
        for(lag in listOf(1,3))for(k in PATH_SIGNED+PATH_UNSIGNED)f[k+"_delta${lag*5}m"]=clean(sequence[0].getValue(k)-sequence[lag].getValue(k))
        for(k in listOf("return3_atr_signed","m5_trend12_26_atr_signed")) {
            val signs=sequence.map { sign(it.getValue(k)) };f[k+"_consistency"]=signs.count { it==signs[0] }/4f;f[k+"_turns"]=signs.zipWithNext().count { (a,b)->a!=b }/3f
        }
        f["path_available"]=if(pathValid())1f else 0f
        for(s in 0..5)f["symbol_"+SYMBOLS[s]]=if(s==symbol)1f else 0f
        return FloatArray(names.size) { index->val name=names[index];val value=f[name] ?: error("Unknown R15 feature: $name");if(index<52 && !high)-value else value }
    }
    /** Completed-price research port. Live quotes remain safety checks only. */
    fun direct19Input(): jp.gmk.mobile.domain.direct19.Direct19Input {
        val requested=(jp.gmk.mobile.domain.r13.R13Features.PRICE.toList()+jp.gmk.mobile.domain.r13.R13Features.OTHER.toList()+"atr14")
        val memo=HashMap<Long,List<MutableMap<String,Double>>>()
        fun observedRaw(b: Long): List<MutableMap<String,Double>> = memo.getOrPut(b) {
            checkpoint()
            val time=Instant.ofEpochSecond(b).atZone(JST);val minute=time.hour*60+time.minute
            series.mapIndexed { s,z ->
                val row=z.features(b)
                row["time_sin"]=sin(2*PI*minute/1440);row["time_cos"]=cos(2*PI*minute/1440)
                for(k in 0..5)row["symbol$k"]=if(s==k)1.0 else 0.0
                for(name in requested) {
                    if(!z.valid(b) && name!="time_sin" && name!="time_cos" && !name.startsWith("symbol"))row[name]=Double.NaN
                    else if(!row.containsKey(name))row[name]=Double.NaN
                }
                row
            }
        }
        fun observedRules(b: Long): Map<String,Map<String,Double>> {
            checkpoint()
            val context=SYMBOLS.take(6).mapIndexedNotNull { s,name->if(series[s].valid(b))name to series[s].context(b,121) else null }.toMap()
            return ruleEngine.horizonRuleFeatures(context,Instant.ofEpochSecond(b).atZone(JST))
        }
        val joint=jointFeaturesUsing(requested,3,::observedRaw,::observedRules,false)
        val rules=observedRules(boundary)
        val native=Array(6) { s->FloatArray(12) { j->(rules[SYMBOLS[s]]?.get("mobile_"+jp.gmk.mobile.domain.r13.R13Features.NATIVE[j]) ?: Double.NaN).toFloat() } }
        val bars=Array(61) { Array(11) { DoubleArray(5) { Double.NaN } } }
        jp.gmk.mobile.domain.r13.R13Features.MINUTE_SYMBOLS.forEachIndexed { s,name->
            val i=SYMBOLS.indexOf(name)
            for(c in series[i].context(boundary,61)) {
                val delta=c.timeEpochMs/1000-(boundary-3720)
                if(delta in 0L..3600L && delta%60L==0L)bars[(delta/60).toInt()][s]=doubleArrayOf(c.open,c.high,c.low,c.close,c.volume)
            }
        }
        val input=jp.gmk.mobile.domain.r13.R13Features.build(joint,native,bars)
        val flags=jp.gmk.mobile.domain.direct19.Direct19Policy.COVERAGE.map { series[SYMBOLS.indexOf(it)].valid(boundary) }
        val features=Array(4) { s->FloatArray(165) { j->if(j<146)input.tree[s*3][j] else if(flags[j-146])1f else 0f } }
        return jp.gmk.mobile.domain.direct19.Direct19Input(boundary,features,BooleanArray(4) { series[it].valid(boundary) },
            SYMBOLS.take(4).mapIndexed { s,name->name to series[s].context(boundary) }.toMap())
    }

    fun jointFeatures(names: List<String>,horizon: Int): Array<FloatArray> =
        jointFeaturesUsing(names,horizon,::raw,::rules,true)
    private fun jointFeaturesUsing(names: List<String>,horizon: Int,
        rawAt: (Long)->List<MutableMap<String,Double>>,
        rulesAt: (Long)->Map<String,Map<String,Double>>, includeQuotes: Boolean): Array<FloatArray> {
        val current=rawAt(boundary);val state=rulesAt(boundary);val prior=previousSlots(boundary,305);val settled=prior.filter { it+horizon*60<=boundary-10 }
        val fxMean5=mean(current.take(5).map { it["return5"] ?: Double.NaN });val fxMean15=mean(current.take(5).map { it["return15"] ?: Double.NaN });val agreement=mean(current.take(5).map { sign(it["return5"] ?: Double.NaN) })
        val prior36=previousSlots(boundary,35)+boundary
        val fx=prior36.map { b->mean(rawAt(b).take(5).map { it["return5"] ?: Double.NaN }) }
        fun ret(s: Int,b: Long,n: Int): Double=if(series[s].valid(b))rawAt(b)[s]["return$n"] ?: Double.NaN else Double.NaN
        fun close(s: Int,b: Long): Double=if(series[s].valid(b))series[s].context(b).last().close else Double.NaN
        val under=intArrayOf(-1,15,17,6,18,7)
        fun basis(s: Int,b: Long): Double=(close(s,b)/(close(0,b)*(if(under[s]<0)1.0 else close(under[s],b)))-1)*1e4
        val time=Instant.ofEpochSecond(boundary).atZone(JST)
        return Array(6) { s->
            val f=LinkedHashMap(current[s]);f.putAll(state[SYMBOLS[s]] ?: emptyMap());if(includeQuotes)f.putAll(quoteFeatures(s));f["jpy_mean5"]=fxMean5;f["jpy_mean15"]=fxMean15;f["jpy_agreement"]=agreement;f["relative_strength5"]=(f["return5"] ?: Double.NaN)-fxMean5
            for(n in listOf(12,36)) {
                val own=prior36.takeLast(n).map { rawAt(it)[s]["return5"] ?: Double.NaN };val other=fx.takeLast(n);val ma=mean(own);val mb=mean(other);val cov=own.indices.sumOf { (own[it]-ma)*(other[it]-mb) }/n;val denom=sd(own)*sd(other);f["correlation_$n"]=if(denom==0.0)Double.NaN else cov/denom
            }
            val driverNames=mapOf(6 to "AUDUSD",7 to "BTC_USD",8 to "CAD",9 to "CADJPY",10 to "CHF",11 to "CHFJPY",12 to "ETH_USD",13 to "EURAUD",14 to "EURGBP",15 to "EURUSD",16 to "GBPAUD",17 to "GBPUSD",18 to "NZDUSD")
            for((symbol,label) in driverNames)for(n in listOf(1,5))f["driver_${label}_r$n"]=ret(symbol,boundary,n)
            for(n in listOf(1,3,5,15)) {
                f["driver_USD_strength$n"]=mean(listOf(-ret(15,boundary,n),-ret(17,boundary,n),-ret(6,boundary,n),-ret(18,boundary,n),ret(8,boundary,n),ret(10,boundary,n)))
                f["underlying_USD_return$n"]=if(under[s]<0)0.0 else ret(under[s],boundary,n)
            }
            f["closed_triangular_basis_bps"]=basis(s,boundary)
            for(lag in listOf(1,3))f["closed_basis_change_${lag*5}m"]=basis(s,boundary)-basis(s,prior[prior.size-lag])
            f["auxiliary_valid_fraction"]=(6..18).count { series[it].valid(boundary) }/13.0;f["minute_phase_sin"]=sin(time.minute/60.0*2*PI);f["minute_phase_cos"]=cos(time.minute/60.0*2*PI)
            if(names.any { it.startsWith("past_settled_") }) for(width in listOf(12,72,288)) {
                var known=0;var up=0;var draw=0;var win=0
                for(b in settled.takeLast(width)) {
                    val p=series[s].open(b);val end=series[s].open(b+horizon*60)
                    if(series[s].valid(b) && p.isFinite() && end.isFinite()) {
                        known++;if(end>p)up++;if(end==p)draw++
                        val high=rulesAt(b)[SYMBOLS[s]]?.get("mobile_high")==1.0
                        if(end!=p && (end>p)==high)win++
                    }
                }
                f["past_settled_${width}_up"]=(up+10.0)/(known+20);f["past_settled_${width}_draw"]=(draw+.6)/(known+20);f["past_settled_${width}_native_win"]=(win+10.0)/(known+20);f["past_settled_${width}_known_fraction"]=known.toDouble()/width
            }
            f["past_settled_age_day"]=if(settled.isEmpty())Double.NaN else min((boundary-(settled.last()+horizon*60)).toDouble(),86400.0)/86400
            FloatArray(names.size) { j->require(f.containsKey(names[j])) { "Unknown joint feature: ${names[j]}" };val value=f.getValue(names[j]).toFloat();if(value.isInfinite())Float.NaN else value }
        }
    }
}

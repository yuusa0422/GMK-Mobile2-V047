package jp.gmk.mobile.runtime

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** OS refusal must not crash scans, boot recovery or outcome completion. */
object GmkRuntimeServiceControl {
    private val lifecycleState = kotlinx.coroutines.flow.MutableStateFlow(false to (null as String?))
    val lifecycle: kotlinx.coroutines.flow.StateFlow<Pair<Boolean, String?>> = lifecycleState
    val foregroundRunning: Boolean get() = lifecycleState.value.first

    private fun prefs(context: Context) = context.getSharedPreferences("gmk_runtime_service", Context.MODE_PRIVATE)

    fun start(context: Context): Boolean {
        if (foregroundRunning) return true
        return try {
            ContextCompat.startForegroundService(context, Intent(context, GmkRuntimeKeepAliveService::class.java))
            true
        } catch (e: IllegalStateException) {
            recordFailure(context, e)
            false
        } catch (e: SecurityException) {
            recordFailure(context, e)
            false
        }
    }

    fun recordFailure(context: Context, error: RuntimeException) {
        val message = "${error.javaClass.simpleName}: ${error.message.orEmpty()}".take(240)
        prefs(context).edit()
            .putString("last_start_error", message)
            .putLong("last_start_error_ms", System.currentTimeMillis()).apply()
        lifecycleState.value = false to message
    }

    fun markStarted(context: Context) {
        prefs(context).edit().remove("last_start_error").remove("last_start_error_ms").apply()
        lifecycleState.value = true to null
    }

    fun markStopped() { lifecycleState.value = false to lifecycleState.value.second }
    fun lastError(context: Context): String? = prefs(context).getString("last_start_error", null)
    fun diagnosticStats(context: Context): JSONObject = JSONObject()
        .put("foreground_running", foregroundRunning)
        .put("last_start_error", lastError(context) ?: JSONObject.NULL)
        .put("last_start_error_ms", prefs(context).getLong("last_start_error_ms", 0L))
}

package jp.gmk.mobile.domain.r13;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Only committed raw frames are retained. A failed scan cannot warm the TCN history. */
public final class R13FrameStore {
    private final TreeMap<Long,float[][]> frames=new TreeMap<>();
    private final File file;
    public R13FrameStore(File file) {this.file=file;}
    public synchronized void load() throws IOException {
        if(!file.isFile())return;
        TreeMap<Long,float[][]> decoded=new TreeMap<>();
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            if(!in.readUTF().equals(R13Policy.VERSION))return;
            int count=in.readInt();if(count<0 || count>16)throw new IOException("R13-HISTORY-SIZE");
            for(int n=0;n<count;n++) {
                long at=in.readLong();float[][] raw=new float[6][50];
                for(float[] row:raw)for(int j=0;j<row.length;j++){row[j]=in.readFloat();if(!Float.isFinite(row[j]))throw new IOException("R13-HISTORY-NONFINITE");}
                if(decoded.put(at,raw)!=null)throw new IOException("R13-HISTORY-DUPLICATE");
            }
            if(in.read()!=-1)throw new IOException("R13-HISTORY-TRAILING");
        }
        frames.clear();frames.putAll(decoded);
    }
    public synchronized Map<Long,float[][]> snapshotBefore(long boundary) {return new TreeMap<>(frames.headMap(boundary,false));}
    public synchronized void commit(long boundary,float[][] raw) throws IOException {
        if(raw.length!=6)throw new IOException("R13-HISTORY-SHAPE");
        float[][] copy=new float[6][50];
        for(int s=0;s<6;s++){if(raw[s].length!=50)throw new IOException("R13-HISTORY-SHAPE");for(float v:raw[s])if(!Float.isFinite(v))throw new IOException("R13-HISTORY-NONFINITE");copy[s]=raw[s].clone();}
        frames.put(boundary,copy);while(frames.size()>16)frames.pollFirstEntry();
        file.getParentFile().mkdirs();File tmp=new File(file.getPath()+".tmp");
        try(FileOutputStream stream=new FileOutputStream(tmp);DataOutputStream out=new DataOutputStream(new BufferedOutputStream(stream))) {
            out.writeUTF(R13Policy.VERSION);out.writeInt(frames.size());
            for(Map.Entry<Long,float[][]> item:frames.entrySet()){out.writeLong(item.getKey());for(float[] row:item.getValue())for(float v:row)out.writeFloat(v);}
            out.flush();stream.getFD().sync();
        }
        try {Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        catch(AtomicMoveNotSupportedException e){Files.move(tmp.toPath(),file.toPath(),StandardCopyOption.REPLACE_EXISTING);}
    }
}

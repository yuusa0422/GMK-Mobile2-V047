package jp.gmk.mobile.domain.r13;

import java.util.Objects;

/** AI may revise an existing entry's action, but must preserve its entry mask and identity. */
public final class EntryMaskGuard {
    public static final double MINIMUM_RESEARCH_ENTRY_PERCENT = 70.0;
    private EntryMaskGuard() {}

    /** null accepts the proposal; any reason requires returning the complete original scan. */
    public static String rejectionReason(boolean baseEntry, boolean proposedEntry,
            String baseId, String proposedId, String baseSource, String proposedSource,
            String baseEntryTime, String proposedEntryTime) {
        if (baseEntry != proposedEntry) return "ENTRY_MASK_CHANGED";
        if (!Objects.equals(baseId, proposedId) || !Objects.equals(baseSource, proposedSource)
                || !Objects.equals(baseEntryTime, proposedEntryTime)) return "SCAN_IDENTITY_CHANGED";
        return null;
    }

    /** Research acceptance uses every scheduled slot, including SKIP and unknown outcomes. */
    public static boolean meetsResearchFloor(int entries, int scheduledSlots) {
        return scheduledSlots > 0 && entries >= 0 && entries <= scheduledSlots
                && entries * 100L >= scheduledSlots * 70L;
    }
}

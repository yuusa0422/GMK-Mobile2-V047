package jp.gmk.mobile.domain.r13;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/** Portable float32 weights exported byte-for-byte from the current PC model fold. */
public final class R13Models {
    public static void checkpoint(long deadline) {
        if (System.nanoTime() >= deadline || Thread.currentThread().isInterrupted())
            throw new IllegalStateException("R13-INFERENCE-DEADLINE");
    }
    public static String sha256(byte[] data) {
        try {
            StringBuilder value = new StringBuilder();
            for (byte b : MessageDigest.getInstance("SHA-256").digest(data)) value.append(String.format("%02x", b & 255));
            return value.toString();
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    private static ByteBuffer buffer(byte[] bytes, String hash, String magic) {
        if (!sha256(bytes).equals(hash)) throw new IllegalArgumentException("R13-MODEL-SHA");
        ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        byte[] header = new byte[4]; b.get(header);
        if (!new String(header, StandardCharsets.US_ASCII).equals(magic)) throw new IllegalArgumentException("R13-MODEL-FORMAT");
        return b;
    }
    private static String string(ByteBuffer b) {
        int n = b.getInt();
        if (n < 0 || n > 256 || n > b.remaining()) throw new IllegalArgumentException("R13-STRING");
        byte[] s = new byte[n]; b.get(s); return new String(s, StandardCharsets.UTF_8);
    }
    private static float[] floats(ByteBuffer b, int n) {
        if (n < 0 || n > b.remaining() / 4) throw new IllegalArgumentException("R13-WEIGHT-SIZE");
        float[] a = new float[n];
        for (int i = 0; i < n; i++) { a[i] = b.getFloat(); if (!Float.isFinite(a[i])) throw new IllegalArgumentException("R13-WEIGHT-NONFINITE"); }
        return a;
    }
    private static float[] linear(float[] x, float[] weight, float[] bias) {
        if (weight.length != x.length * bias.length) throw new IllegalArgumentException("R13-LINEAR-SHAPE");
        float[] y = bias.clone();
        for (int out = 0; out < y.length; out++) {
            // Bias follows the matrix product, matching the PC implementation.
            float dot = 0;
            for (int in = 0; in < x.length; in++) dot += x[in] * weight[out * x.length + in];
            y[out] = dot + bias[out];
        }
        return y;
    }
    private static float sigmoid(float v) { return (float) (1 / (1 + Math.exp(-Math.max(-80, Math.min(80, v))))); }
    private static float gelu(float v) {
        // Abramowitz-Stegun 7.1.26, erf error < 1.5e-7. PC GELU uses erf.
        double x = Math.abs(v) / Math.sqrt(2), t = 1 / (1 + .3275911 * x);
        double erf = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - .284496736) * t + .254829592) * t * Math.exp(-x * x);
        float signedErf = (float) Math.copySign(erf, v);
        return .5f * v * (1f + signedErf);
    }
    private static float[] softmax(float[] logits) {
        float[] p = new float[logits.length];
        for (int i = 0; i < logits.length; i += 3) {
            float max = Math.max(logits[i], Math.max(logits[i + 1], logits[i + 2])); float den = 0;
            for (int c = 0; c < 3; c++) { p[i + c] = (float) Math.exp(logits[i + c] - max); den += p[i + c]; }
            for (int c = 0; c < 3; c++) p[i + c] /= den;
        }
        return p;
    }
    public static final class Neural {
        private final Map<String, float[]> weights = new HashMap<>();
        private final String kind;
        public Neural(byte[] bytes, String expectedHash) {
            ByteBuffer b = buffer(bytes, expectedHash, "GNN1"); kind = string(b);
            int count = b.getInt(); if (count < 1 || count > 100) throw new IllegalArgumentException("R13-MODEL-TENSORS");
            for (int i = 0; i < count; i++) {
                String name = string(b); int rank = b.getInt();
                if (rank < 1 || rank > 3) throw new IllegalArgumentException("R13-WEIGHT-RANK");
                int size = 1;
                for (int j = 0; j < rank; j++) { int dim = b.getInt(); if (dim < 1 || dim > 10000) throw new IllegalArgumentException("R13-WEIGHT-DIM"); size = Math.multiplyExact(size, dim); }
                if (weights.put(name, floats(b, size)) != null) throw new IllegalArgumentException("R13-DUPLICATE-TENSOR");
            }
            if (b.hasRemaining()) throw new IllegalArgumentException("R13-TRAILING-BYTES");
            for (float v : w("std")) if (v <= 0) throw new IllegalArgumentException("R13-NORMALIZATION");
        }
        private float[] w(String name) { float[] v = weights.get(name); if (v == null) throw new IllegalArgumentException("R13-WEIGHT:" + name); return v; }
        private float[] layer(float[] x, String name) { return linear(x, w(name + ".weight"), w(name + ".bias")); }
        private float[] tcn(float[][] input, int[] dilations, long deadline) {
            float[][] x = new float[input.length][];
            for (int t = 0; t < x.length; t++) x[t] = layer(input[t], "project");
            int width = x[0].length;
            for (int layer = 0; layer < dilations.length; layer++) {
                checkpoint(deadline);
                float[] kernel = w("body." + layer + ".conv.weight"), bias = w("body." + layer + ".conv.bias");
                if (kernel.length != width * width * 3 || bias.length != width) throw new IllegalArgumentException("R13-TCN-SHAPE");
                float[][] next = new float[x.length][width];
                for (int t = 0; t < x.length; t++) for (int out = 0; out < width; out++) {
                    float z = bias[out];
                    for (int k = 0; k < 3; k++) {
                        int at = t - (2 - k) * dilations[layer]; if (at < 0) continue;
                        float dot = 0;
                        for (int in = 0; in < width; in++) dot += x[at][in] * kernel[(out * width + in) * 3 + k];
                        z += dot;
                    }
                    next[t][out] = x[t][out] + gelu(z);
                }
                x = next;
            }
            return x[x.length - 1];
        }
        public float[][][] predict(float[][][] sequence, float[][] context, long deadline) {
            checkpoint(deadline); if (sequence.length != 6) throw new IllegalArgumentException("R13-BATCH-SHAPE");
            float[][][] result = new float[6][3][3];
            for (int s = 0; s < 6; s++) {
                checkpoint(deadline); float[] logits;
                if (kind.equals("TCN")) {
                    float[][] x = new float[16][51];
                    for (int t = 0; t < 16; t++) {
                        boolean present = sequence[s][t][50] > 0;
                        for (int j = 0; j < 50; j++) x[t][j] = present ? Math.max(-10, Math.min(10, (sequence[s][t][j] - w("mean")[j]) / w("std")[j])) : 0;
                        x[t][50] = present ? 1 : 0;
                    }
                    logits = layer(tcn(x, new int[]{1, 2, 4}, deadline), "head");
                } else {
                    float[] c = new float[62];
                    for (int j = 0; j < 62; j++) c[j] = Math.max(-10, Math.min(10, (context[s][j] - w("mean")[j]) / w("std")[j]));
                    if (kind.equals("M1_LINEAR")) {
                        float[] x = new float[782];
                        for (int t = 0; t < 60; t++) System.arraycopy(sequence[s][t], 0, x, t * 12, 12);
                        System.arraycopy(c, 0, x, 720, 62); logits = layer(x, "head");
                    } else {
                        float[] h;
                        if (kind.equals("M1_TCN")) h = tcn(sequence[s], new int[]{1, 2, 4, 8, 16}, deadline);
                        else if (kind.equals("M1_LSTM")) {
                            h = new float[24]; float[] state = new float[24];
                            for (int t = 0; t < 60; t++) {
                                checkpoint(deadline);
                                float[] inp = layer(sequence[s][t], "body_ih"), rec = linear(h,w("body_hh.weight"),new float[96]), next = new float[24];
                                for(int j=0;j<96;j++)rec[j]=(inp[j]+rec[j])+w("body_hh.bias")[j];
                                for (int j = 0; j < 24; j++) {
                                    state[j] = sigmoid(rec[j + 24]) * state[j] + sigmoid(rec[j]) * (float) Math.tanh(rec[j + 48]);
                                    next[j] = sigmoid(rec[j + 72]) * (float) Math.tanh(state[j]);
                                }
                                h = next;
                            }
                        } else throw new IllegalArgumentException("R13-MODEL-KIND");
                        float[] cHidden = layer(c, "context.0"), merged = new float[48];
                        System.arraycopy(h, 0, merged, 0, 24);
                        for (int j = 0; j < 24; j++) merged[j + 24] = gelu(cHidden[j]);
                        logits = layer(merged, "head");
                    }
                }
                float[] p = softmax(logits);
                for (int h = 0; h < 3; h++) System.arraycopy(p, h * 3, result[s][h], 0, 3);
            }
            checkpoint(deadline); return result;
        }
    }
    public static final class Xgb {
        private final float[] base;
        private final Tree[] trees;
        private static final class Tree {
            int cls; int[] left, right, feature; boolean[] defaultLeft; float[] condition;
        }
        public Xgb(byte[] bytes, String expectedHash) {
            ByteBuffer b = buffer(bytes, expectedHash, "GXG1"); base = floats(b, 3);
            int count = b.getInt(); if (count < 1 || count > 10000) throw new IllegalArgumentException("R13-XGB-TREES");
            trees = new Tree[count];
            for (int t = 0; t < count; t++) {
                Tree tree = new Tree(); tree.cls = b.getInt(); int n = b.getInt();
                if (tree.cls < 0 || tree.cls > 2 || n < 1 || n > 10000) throw new IllegalArgumentException("R13-XGB-SHAPE");
                tree.left = new int[n]; tree.right = new int[n]; tree.feature = new int[n]; tree.defaultLeft = new boolean[n];
                for (int i = 0; i < n; i++) tree.left[i] = b.getInt();
                for (int i = 0; i < n; i++) tree.right[i] = b.getInt();
                for (int i = 0; i < n; i++) tree.feature[i] = b.getInt();
                tree.condition = floats(b, n);
                for (int i = 0; i < n; i++) tree.defaultLeft[i] = b.get() != 0;
                for (int i = 0; i < n; i++) if (tree.left[i] != -1 && (tree.left[i] < 0 || tree.left[i] >= n || tree.right[i] < 0 || tree.right[i] >= n || tree.feature[i] < 0 || tree.feature[i] >= 149)) throw new IllegalArgumentException("R13-XGB-NODE");
                trees[t] = tree;
            }
            if (b.hasRemaining()) throw new IllegalArgumentException("R13-TRAILING-BYTES");
        }
        public float[][][] predict(float[][] features, long deadline) {
            if (features.length != 18) throw new IllegalArgumentException("R13-XGB-INPUT");
            float[][] out = new float[18][3]; for (int i = 0; i < 18; i++) out[i] = base.clone();
            for (int t = 0; t < trees.length; t++) {
                if (t % 30 == 0) checkpoint(deadline);
                Tree tree = trees[t];
                for (int r = 0; r < 18; r++) {
                    int node = 0, depth = 0;
                    while (tree.left[node] != -1) {
                        if (++depth > 100) throw new IllegalArgumentException("R13-XGB-CYCLE");
                        float v = features[r][tree.feature[node]];
                        node = (Float.isNaN(v) ? tree.defaultLeft[node] : v < tree.condition[node]) ? tree.left[node] : tree.right[node];
                    }
                    out[r][tree.cls] += tree.condition[node];
                }
            }
            float[][][] result = new float[6][3][3];
            for (int r = 0; r < 18; r++) result[r / 3][r % 3] = softmax(out[r]);
            checkpoint(deadline); return result;
        }
    }
}

package jp.gmk.mobile.domain.r13

import jp.gmk.mobile.domain.*
import jp.gmk.mobile.domain.horizon.*
import java.time.ZonedDateTime

/** Optional final PC correction. Failures return the complete original proposal. */
class R13ScanAdapter(
    private val neural: Map<String, R13Models.Neural>,
    private val xgb: R13Models.Xgb,
    private val baseModels: List<PortableTreeModel>,
    private val store: R13FrameStore
) {
    companion object {
        const val RELEASE = "GMK_V0735_PC_R13"
        const val FALLBACK = "GMK_V0735_R9_FALLBACK"
    }
    @Volatile var status = "WARMING"; private set
    @Volatile var changed = false; private set
    @Volatile var inferenceMs = 0.0; private set
    @Volatile var persistenceStatus = "OK"; private set
    private val pending = HashMap<String, Pair<Long, Array<FloatArray>>>()
    private var lastBoundary = 0L
    private var lastResult: ScanResult? = null
    private var committedBoundary = 0L
    private var committedResult: ScanResult? = null

    @Synchronized
    fun apply(base: ScanResult, native: ScanResult, prepared: PreparedHorizonFrame?,
              quotes: Map<String, HorizonQuote>, candles: Map<String, List<Candle>>): ScanResult {
        if (base.source != "AUTO") return base.copy(policyVersion = "GMK_V0735_NATIVE_3M")
        val boundary = runCatching { ZonedDateTime.parse(base.entryTimeJst).toEpochSecond() }.getOrNull() ?: return base
        if (!HorizonFeatureService.scheduled(boundary)) return base.copy(policyVersion = "GMK_V0735_NATIVE_3M")
        if (boundary == lastBoundary) {
            val cached = lastResult ?: return base
            val rejected = EntryMaskGuard.rejectionReason(
                base.top1?.decision == "ENTRY", cached.top1?.decision == "ENTRY",
                base.scanId, cached.scanId, base.source, cached.source,
                base.entryTimeJst, cached.entryTimeJst
            )
            if (rejected == null) return cached
            status = "ENTRY_CONTRACT_FALLBACK:$rejected"; changed = false
            return base.copy(policyVersion = FALLBACK)
        }
        if (boundary < lastBoundary) return base.copy(policyVersion = FALLBACK)
        val began = System.nanoTime()
        val remaining = boundary * 1000 - 800 - System.currentTimeMillis()
        val deadline = began + minOf(2000L, maxOf(0L, remaining)) * 1_000_000
        changed = false
        fun finish(result: ScanResult, reason: String, evaluated: Boolean = false): ScanResult {
            val rejected = EntryMaskGuard.rejectionReason(
                base.top1?.decision == "ENTRY", result.top1?.decision == "ENTRY",
                base.scanId, result.scanId, base.source, result.source,
                base.entryTimeJst, result.entryTimeJst
            )
            if (rejected != null) changed = false
            status = rejected?.let { "ENTRY_CONTRACT_FALLBACK:$it" } ?: reason
            inferenceMs = (System.nanoTime() - began) / 1e6
            lastBoundary = boundary
            val accepted = if (rejected == null) result else base
            val done = accepted.copy(policyVersion = if (evaluated && rejected == null) RELEASE else FALLBACK)
            lastResult = done
            return done
        }
        if (boundary - 10 < R13Catalog.AVAILABLE_FROM) return finish(base, "MODEL_NOT_AVAILABLE_AT_SCAN")
        if (prepared == null || prepared.boundary != boundary) return finish(base, "FRAME_MISSING")
        if (!prepared.service.matchesNative(candles)) return finish(base, "INPUT_REVISION_NATIVE")
        return try {
            R13Models.checkpoint(deadline)
            val service = prepared.service
            service.attachQuotes(quotes)
            service.fillQuotes(prepared.features, baseModels.map { it.featureNames })
            val names = baseModels[0].featureNames
            val indices = (R13Features.PRICE.toList() + R13Features.OTHER.toList() + "atr14").map { names.indexOf(it).also { n -> require(n >= 0) } }
            val rows = Array(6) { s -> FloatArray(51) { j -> prepared.features[s][0][indices[j]] } }
            val rules = service.currentRuleFeatures()
            val nativeFeatures = Array(6) { s -> FloatArray(12) { j ->
                (rules[HorizonFeatureService.SYMBOLS[s]]?.get("mobile_" + R13Features.NATIVE[j]) ?: Double.NaN).toFloat()
            } }
            val prices = service.completedPrices()
            val bars = Array(61) { Array(11) { DoubleArray(5) { Double.NaN } } }
            R13Features.MINUTE_SYMBOLS.forEachIndexed { s, symbol ->
                prices[symbol].orEmpty().forEach { c ->
                    val delta = c.timeEpochMs / 1000 - (boundary - 3720)
                    if (delta in 0L..3600L && delta % 60L == 0L) bars[(delta / 60).toInt()][s] = doubleArrayOf(c.open, c.high, c.low, c.close, c.volume)
                }
            }
            val input = R13Features.build(rows, nativeFeatures, bars)
            R13Models.checkpoint(deadline)
            // Store only after the ViewModel has published and journalled this scan.
            pending.clear()
            pending[base.scanId] = boundary to input.raw
            if (!service.ready) return finish(base, "R13_CONTEXT_NOT_READY")
            val top = base.top1 ?: return finish(base, "BASE_SKIP", true)
            if (top.decision != "ENTRY") return finish(base, "BASE_SKIP", true)
            val safe = BooleanArray(6) { service.strictSafe(it) }
            val nativeTop = native.top1
            val nativeSymbol = nativeTop?.instrument?.let { HorizonFeatureService.SYMBOLS.indexOf(it) } ?: -1
            val isNative = nativeTop?.decision == "ENTRY" && nativeSymbol in 0..5 && safe[nativeSymbol]
            val grade = if (isNative) requireNotNull(nativeTop).grade else "SUPPLEMENT"
            if (isNative && grade in setOf("S", "A", "B")) return finish(base, "NATIVE_S_A_B_PROTECTED", true)
            if (isNative && grade != "C") return finish(base, "UNEXPECTED_NATIVE_GRADE")
            val symbol = HorizonFeatureService.SYMBOLS.indexOf(top.instrument)
            val minutes = java.time.Duration.between(ZonedDateTime.parse(base.entryTimeJst), ZonedDateTime.parse(base.judgeTimeJst)).toMinutes().toInt()
            val horizon = R13Policy.HORIZONS.indexOf(minutes)
            require(symbol in 0..5 && horizon >= 0 && safe[symbol]) { "R13_UNSAFE_BASE" }
            val action = symbol * 6 + horizon * 2 + if (top.direction == "HIGH") 1 else 0
            var snapshot: Array<Array<FloatArray>>? = null
            if (!isNative) {
                val history = store.snapshotBefore(boundary)
                val sequence = Array(6) { Array(16) { FloatArray(51) } }
                var missing = 0
                for (t in 0..15) {
                    val at = boundary - (15 - t) * 300L
                    if ((at..boundary step 300L).any { !HorizonFeatureService.scheduled(it) }) continue
                    val raw = if (at == boundary) input.raw else history[at]
                    if (raw == null) { missing++; continue }
                    for (s in 0..5) { raw[s].copyInto(sequence[s][t]); sequence[s][t][50] = 1f }
                }
                if (missing > 0) return finish(base, "TCN_HISTORY_WARMING:$missing")
                snapshot = sequence
            }
            val xgbBank = xgb.predict(input.tree, deadline)
            val tcnBank = if (!isNative) neural.getValue("TCN").predict(snapshot, null, deadline) else null
            val m1Tcn = if (isNative) neural.getValue("M1_TCN").predict(input.minute, input.context, deadline) else null
            val m1Lstm = if (isNative) neural.getValue("M1_LSTM").predict(input.minute, input.context, deadline) else null
            val m1Linear = if (isNative) neural.getValue("M1_LINEAR").predict(input.minute, input.context, deadline) else null
            val rule = if (isNative) Array(6) { s -> Array(3) { h -> baseModels[h].predict(prepared.features[s][h]).map { it.toFloat() }.toFloatArray() } } else null
            R13Models.checkpoint(deadline)
            val selected = R13Policy.decide(action, true, isNative, grade, safe, tcnBank, m1Tcn, m1Lstm, m1Linear, rule, xgbBank)
            if (selected == action) return finish(base, "UNCHANGED", true)
            val target = HorizonFeatureService.SYMBOLS[selected / 6]
            val expiry = R13Policy.HORIZONS[selected % 6 / 2]
            val entry = ZonedDateTime.parse(base.entryTimeJst)
            val candidate = base.candidates.single { it.instrument == target }.copy(
                rank = 1, direction = if (selected % 2 == 1) "HIGH" else "LOW", grade = "R", decision = "ENTRY", probability = null,
                reasons = listOf("判定: ${expiry}分", R13Policy.VERSION, R13Policy.POLICY, "R13 action=$action->$selected") + top.reasons
            )
            val candidates = listOf(candidate) + base.candidates.filter { it.instrument != target }.mapIndexed { i, c -> c.copy(rank = i + 2) }
            R13Models.checkpoint(deadline)
            changed = true
            finish(base.copy(candidates = candidates, judgeTimeJst = entry.plusMinutes(expiry.toLong()).toString()), "APPLIED", true)
        } catch (e: Exception) {
            finish(base, "R9_FALLBACK:${e.javaClass.simpleName}:${e.message?.take(80)}")
        }
    }
    @Synchronized
    fun commit(scanId: String) {
        val frame = pending.remove(scanId) ?: return
        committedBoundary = lastBoundary; committedResult = lastResult
        try { store.commit(frame.first, frame.second); persistenceStatus = "OK" }
        catch (e: Exception) { persistenceStatus = "HISTORY_WRITE_FAILED:${e.javaClass.simpleName}" }
    }
    @Synchronized
    fun discardPending() {
        pending.clear();lastBoundary = committedBoundary;lastResult = committedResult
    }
}

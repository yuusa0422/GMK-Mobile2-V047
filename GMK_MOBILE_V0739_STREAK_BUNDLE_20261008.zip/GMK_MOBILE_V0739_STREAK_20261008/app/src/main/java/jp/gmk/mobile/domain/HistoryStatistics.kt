package jp.gmk.mobile.domain

fun HistoryRow.statisticsRow() = OutcomeStatistics.Row(decision,resultStatus,entryTimeJst,judgeTimeJst,policyVersion,entryRate,judgeRate)

fun historyStatistics(rows: List<HistoryRow>): Map<Int,OutcomeStatistics.Summary> =
    OutcomeStatistics.byHorizon(rows.map { it.statisticsRow() })

fun historyCombinedStatistics(rows: List<HistoryRow>): OutcomeStatistics.Summary =
    OutcomeStatistics.overall(rows.map { it.statisticsRow() })

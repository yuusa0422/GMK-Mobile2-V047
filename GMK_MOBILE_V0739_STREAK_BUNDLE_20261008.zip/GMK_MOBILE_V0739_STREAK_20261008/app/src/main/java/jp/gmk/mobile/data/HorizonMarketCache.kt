package jp.gmk.mobile.data

import jp.gmk.mobile.domain.Candle
import jp.gmk.mobile.domain.RateRow
import jp.gmk.mobile.domain.horizon.HorizonQuote
import java.io.*
import java.util.ArrayDeque

/** Separate bounded cache; historical quotes are never promoted to fresh quotes. */
class HorizonMarketCache(private val directory: File) {
    private val prices=HashMap<String,List<Candle>>()
    private val quotes=HashMap<String,ArrayDeque<HorizonQuote>>()
    init { directory.mkdirs() }
    @Synchronized fun observe(rows: List<RateRow>) {
        for(row in rows) {
            val received=row.receivedEpochMs ?: continue
            val source=row.sourceEpochMs ?: continue
            val price=row.price ?: continue
            if(!price.isFinite() || price<=0 || source<=0 || source>received)continue
            val ring=quotes.getOrPut(row.instrument){ArrayDeque()}
            val previous=ring.lastOrNull()
            // The socket and REST recovery arrive independently. Later receipt does
            // not make an older provider timestamp a newer inference quote.
            if(previous!=null && (received<=previous.receivedMs || source<previous.sourceMs))continue
            // Partial OHLC and trade count are unavailable from these quote APIs. Keep missing.
            ring.addLast(HorizonQuote(received,source,price,row.bid,row.ask,row.freshnessStatus=="LIVE"))
            while(ring.size>120 || (ring.isNotEmpty() && received-ring.first.receivedMs>180_000))ring.removeFirst()
        }
    }
    @Synchronized fun quoteSnapshot(scanMs: Long): Map<String,HorizonQuote> = quotes.mapNotNull { (s,q)->q.filter { it.receivedMs<=scanMs }.maxByOrNull { it.receivedMs }?.let { s to it } }.toMap()
    @Synchronized fun snapshot(): Map<String,List<Candle>> = prices.toMap()
    @Synchronized fun size(symbol: String): Int=prices[symbol]?.size ?: 0
    @Synchronized fun merge(symbol: String, incoming: List<Candle>, receivedMs: Long) {
        val map=prices[symbol].orEmpty().associateBy { it.timeEpochMs }.toMutableMap()
        incoming.filter { c->c.timeEpochMs%60_000L==0L && c.timeEpochMs+60_000<=receivedMs &&
            listOf(c.open,c.high,c.low,c.close).all { it.isFinite() && it>0 } &&
            c.high>=maxOf(c.open,c.close) && c.low<=minOf(c.open,c.close) }.forEach { map[it.timeEpochMs]=it }
        prices[symbol]=map.values.sortedBy { it.timeEpochMs }.takeLast(7000)
    }
    fun load(symbol: String, receivedMs: Long = System.currentTimeMillis()) {
        val file=File(directory,"$symbol.bin")
        if(!file.isFile)return
        try {
            val bars=DataInputStream(BufferedInputStream(FileInputStream(file))).use { input->
                require(input.readLong()==0x474D4B4341434831L)
                val n=input.readInt();require(n in 1..7000)
                List(n){Candle(input.readLong(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble(),input.readDouble())}.also { require(input.read()==-1) }
            }
            merge(symbol,bars,receivedMs)
        } catch(_: Exception) { /* Invalid cache stays unavailable until fetched. */ }
    }
    fun persist(symbol: String) {
        val rows=synchronized(this){prices[symbol].orEmpty()}
        if(rows.isEmpty())return
        val temporary=File(directory,"$symbol.tmp");val target=File(directory,"$symbol.bin")
        DataOutputStream(BufferedOutputStream(FileOutputStream(temporary))).use { output->
            output.writeLong(0x474D4B4341434831L);output.writeInt(rows.size)
            for(c in rows) { output.writeLong(c.timeEpochMs);for(v in listOf(c.open,c.high,c.low,c.close,c.volume))output.writeDouble(v) }
        }
        check(temporary.renameTo(target)) { "History cache replace failed" }
    }
}

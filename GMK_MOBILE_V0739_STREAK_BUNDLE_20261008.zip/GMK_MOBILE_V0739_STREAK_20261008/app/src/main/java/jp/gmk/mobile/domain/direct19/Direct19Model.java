package jp.gmk.mobile.domain.direct19;

import java.io.*;
import java.security.MessageDigest;
import java.util.Arrays;

/** Exact double-precision sklearn histogram tree traversal; output float32. */
public final class Direct19Model {
    private final double[] baseline;
    private final Tree[] trees;
    private final int[] classes;
    private static final class Tree {
        int[] feature,left,right; double[] threshold,value; boolean[] missingLeft,leaf;
    }
    private Direct19Model(double[] baseline,Tree[] trees,int[] classes) {
        this.baseline=baseline;this.trees=trees;this.classes=classes;
    }
    public static Direct19Model load(byte[] bytes,String expectedSha) throws Exception {
        StringBuilder digest=new StringBuilder();
        for(byte b:MessageDigest.getInstance("SHA-256").digest(bytes))digest.append(String.format("%02x",b&255));
        if(!digest.toString().equals(expectedSha))throw new IOException("DIRECT19_MODEL_SHA");
        try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes))) {
            if(in.readLong()!=0x474D4B4847423131L || in.readInt()!=165 || in.readInt()!=3)throw new IOException("DIRECT19_MODEL_HEADER");
            double[] base=new double[3];for(int k=0;k<3;k++){base[k]=in.readDouble();if(!Double.isFinite(base[k]))throw new IOException("DIRECT19_BASELINE");}
            int count=in.readInt();if(count!=240)throw new IOException("DIRECT19_TREE_COUNT");
            Tree[] trees=new Tree[count];int[] classes=new int[count];
            for(int t=0;t<count;t++) {
                classes[t]=in.readInt();int n=in.readInt();if(classes[t]<0 || classes[t]>2 || n<1 || n>29)throw new IOException("DIRECT19_TREE_SHAPE");
                Tree tree=new Tree();trees[t]=tree;tree.feature=new int[n];tree.left=new int[n];tree.right=new int[n];
                tree.threshold=new double[n];tree.value=new double[n];tree.missingLeft=new boolean[n];tree.leaf=new boolean[n];
                for(int j=0;j<n;j++) {
                    tree.feature[j]=in.readInt();tree.threshold[j]=in.readDouble();tree.value[j]=in.readDouble();
                    tree.left[j]=in.readInt();tree.right[j]=in.readInt();tree.missingLeft[j]=in.readBoolean();tree.leaf[j]=in.readBoolean();
                    if(!Double.isFinite(tree.value[j]) || (!tree.leaf[j] && (tree.feature[j]<0 || tree.feature[j]>=165 || !Double.isFinite(tree.threshold[j]) || tree.left[j]<=j || tree.right[j]<=j || tree.left[j]>=n || tree.right[j]>=n)))throw new IOException("DIRECT19_NODE");
                }
            }
            if(in.read()!=-1)throw new IOException("DIRECT19_TRAILING");return new Direct19Model(base,trees,classes);
        }
    }
    public float[] predict(float[] input,long deadline) {
        if(input.length!=165)throw new IllegalArgumentException("DIRECT19_INPUT_SHAPE");
        double[] logits=baseline.clone();
        for(int t=0;t<trees.length;t++) {
            if((t&31)==0 && System.nanoTime()>=deadline)throw new IllegalStateException("DIRECT19_DEADLINE");
            Tree tree=trees[t];int node=0;
            while(!tree.leaf[node]) {
                float x=input[tree.feature[node]];
                node=(Float.isNaN(x)?tree.missingLeft[node]:x<=tree.threshold[node])?tree.left[node]:tree.right[node];
            }
            logits[classes[t]]+=tree.value[node];
        }
        double max=Arrays.stream(logits).max().getAsDouble();double sum=0;
        for(int k=0;k<3;k++){logits[k]=Math.exp(logits[k]-max);sum+=logits[k];}
        float[] out=new float[3];for(int k=0;k<3;k++)out[k]=(float)(logits[k]/sum);return out;
    }
}

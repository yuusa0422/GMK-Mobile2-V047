package jp.gmk.mobile.domain.direct19;

/** C-only open-four-symbol, directly trained 3/5-minute correction. */
public final class Direct19Policy {
    public static final String VERSION="GMK_V0736_DIRECT19_C_3_5";
    public static final String POLICY="HGB15_TRAIN20__NATIVE_C_OPEN4_BOTH_M10";
    public static final String[] TRADED={"USDJPY","EURJPY","GBPJPY","AUDJPY"};
    public static final String[] COVERAGE={"USDJPY","EURJPY","GBPJPY","AUDJPY","EURUSD","GBPUSD","NZDJPY","BTCJPY","AUDUSD","BTCUSD","USDCAD","CADJPY","USDCHF","CHFJPY","ETHUSD","EURAUD","EURGBP","GBPAUD","NZDUSD"};
    private Direct19Policy() {}
    public static int decide(int nativeAction,boolean entry,String grade,boolean[] eligible,float[][][] probability) {
        return decide(nativeAction,entry,grade,eligible,probability,false);
    }
    public static int decide(int nativeAction,boolean entry,String grade,boolean[] eligible,float[][][] probability,boolean fixedThree) {
        if(nativeAction<0 || nativeAction>=16 || eligible.length!=4)return nativeAction;
        if(!entry || !"C".equals(grade) || !eligible[nativeAction/4])return nativeAction;
        if(probability.length!=4)throw new IllegalArgumentException("DIRECT19_PROBABILITY_SHAPE");
        int best=-1;float score=Float.NEGATIVE_INFINITY;
        for(int s=0;s<4;s++) {
            if(probability[s].length!=2)throw new IllegalArgumentException("DIRECT19_HORIZON_SHAPE");
            if(!eligible[s])continue;
            for(int h=0;h<(fixedThree?1:2);h++) {
                float[] p=probability[s][h];if(p.length!=3)throw new IllegalArgumentException("DIRECT19_CLASSES");
                float sum=0;for(float v:p){if(!Float.isFinite(v) || v<0 || v>1)throw new IllegalArgumentException("DIRECT19_PROBABILITY_RANGE");sum+=v;}
                if(Math.abs(sum-1)>3e-5)throw new IllegalArgumentException("DIRECT19_PROBABILITY_SUM");
                for(int direction=0;direction<2;direction++)if(p[direction*2]>score){score=p[direction*2];best=4*s+2*h+direction;}
            }
        }
        float base=probability[nativeAction/4][0][(nativeAction%2)*2];
        return best>=0 && score>base+.10f ? best:nativeAction;
    }
}

package jp.gmk.mobile.domain.direct19

object Direct19Catalog {
    const val AVAILABLE_FROM = 1791385200L
    val hashes = mapOf(
        "hgb_3m.bin" to "1ccc6d02e3a5cf43e1e755975724878bfb5be4a1163b546b7c6c10d380534183",
        "hgb_5m.bin" to "61fe1753e6abfb78602d92fffadf196168b8ea27d601d5a617e0370303eb8360"
    )
}

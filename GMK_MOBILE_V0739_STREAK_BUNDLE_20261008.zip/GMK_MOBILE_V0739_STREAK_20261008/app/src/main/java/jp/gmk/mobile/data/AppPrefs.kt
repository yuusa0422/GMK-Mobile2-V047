package jp.gmk.mobile.data

import android.content.Context
import android.os.SystemClock

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("gmk_mobile_local", Context.MODE_PRIVATE)
    init {
        if(!prefs.getBoolean("direct19_v0736_migrated",false)) {
            prefs.edit().putBoolean("force_three_minute_outcome",false)
                .putBoolean("direct19_v0736_migrated",true).commit()
        }
    }

    var oandaToken: String
        get() = prefs.getString("oanda_token", "") ?: ""
        set(value) = prefs.edit().putString("oanda_token", value.trim()).apply()

    var oandaAccountId: String
        get() = prefs.getString("oanda_account_id", "") ?: ""
        set(value) = prefs.edit().putString("oanda_account_id", value.trim()).apply()

    var oandaEnvironment: String
        get() = prefs.getString("oanda_environment", "practice") ?: "practice"
        set(value) = prefs.edit().putString("oanda_environment", if (value == "live") "live" else "practice").apply()

    var yahooFallback: Boolean
        get() = true
        set(value) { prefs.edit().putBoolean("yahoo_fallback", true).apply() }

    var autoScan: Boolean
        get() = prefs.getBoolean("auto_scan", true)
        set(value) = prefs.edit().putBoolean("auto_scan", value).apply()

    var oneMinuteAutoScan: Boolean
        get() = prefs.getBoolean("one_minute_auto_scan", false)
        set(value) = prefs.edit().putBoolean("one_minute_auto_scan", value).apply()

    /** User's three-minute research constraint; OFF selects the PC's variable expiry. */
    var forceThreeMinuteOutcome: Boolean
        get() = prefs.getBoolean("force_three_minute_outcome", false)
        set(value) = prefs.edit().putBoolean("force_three_minute_outcome", value).apply()

    var cutInEnabled: Boolean
        get() = prefs.getBoolean("cut_in_enabled", true)
        set(value) = prefs.edit().putBoolean("cut_in_enabled", value).apply()

    var lastAutoBoundaryKey: String
        get() = prefs.getString("last_auto_boundary_key", "") ?: ""
        set(value) {
            prefs.edit().putString("last_auto_boundary_key", value).commit()
        }

    var lastOneMinuteBoundaryKey: String
        get() = prefs.getString("last_one_minute_boundary_key", "") ?: ""
        set(value) {
            prefs.edit().putString("last_one_minute_boundary_key", value).commit()
        }

    /**
     * Boundary ownership is a short lease, not completion. A process crash must not
     * permanently consume the :50-:54 retry window. Completion is recorded separately.
     */
    fun claimThreeMinuteBoundary(key: String): Boolean = synchronized(boundaryLock) {
        if ((prefs.getString("last_auto_boundary_key", "") ?: "") == key) return@synchronized false
        claimLease("three_minute_claim_key", "three_minute_claim_at_ms", key)
    }

    fun completeThreeMinuteBoundary(key: String): Boolean = synchronized(boundaryLock) {
        if (inProcessClaims["three_minute_claim_key"] == key) inProcessClaims.remove("three_minute_claim_key")
        prefs.edit()
            .putString("last_auto_boundary_key", key)
            .remove("three_minute_claim_key")
            .remove("three_minute_claim_at_ms")
            .commit()
    }

    fun releaseThreeMinuteBoundary(key: String) = synchronized(boundaryLock) {
        if (inProcessClaims["three_minute_claim_key"] == key) inProcessClaims.remove("three_minute_claim_key")
        if ((prefs.getString("three_minute_claim_key", "") ?: "") == key) {
            prefs.edit().remove("three_minute_claim_key").remove("three_minute_claim_at_ms").commit()
        }
    }

    fun claimOneMinuteBoundary(key: String): Boolean = synchronized(boundaryLock) {
        if ((prefs.getString("last_one_minute_boundary_key", "") ?: "") == key) return@synchronized false
        claimLease("one_minute_claim_key", "one_minute_claim_at_ms", key)
    }

    fun completeOneMinuteBoundary(key: String): Boolean = synchronized(boundaryLock) {
        if (inProcessClaims["one_minute_claim_key"] == key) inProcessClaims.remove("one_minute_claim_key")
        prefs.edit()
            .putString("last_one_minute_boundary_key", key)
            .remove("one_minute_claim_key")
            .remove("one_minute_claim_at_ms")
            .commit()
    }

    fun releaseOneMinuteBoundary(key: String) = synchronized(boundaryLock) {
        if (inProcessClaims["one_minute_claim_key"] == key) inProcessClaims.remove("one_minute_claim_key")
        if ((prefs.getString("one_minute_claim_key", "") ?: "") == key) {
            prefs.edit().remove("one_minute_claim_key").remove("one_minute_claim_at_ms").commit()
        }
    }

    private fun claimLease(keyName: String, atName: String, key: String): Boolean {
        // A network scan can last 8s. The 2.5s crash lease must never expire while
        // this process still owns the job, or the :55 miss check consumes its frame.
        if (inProcessClaims[keyName] == key) return false
        val nowElapsed = SystemClock.elapsedRealtime()
        val currentKey = prefs.getString(keyName, "") ?: ""
        val claimedAtElapsed = prefs.getLong(atName, 0L)
        val leaseAge = nowElapsed - claimedAtElapsed
        val leaseFresh = currentKey == key && claimedAtElapsed > 0L &&
            leaseAge in 0 until BOUNDARY_CLAIM_LEASE_MS
        if (leaseFresh) return false
        // elapsedRealtime survives process death in the same boot and is immune to wall-clock/NTP
        // changes. After a device reboot the stored value is larger than the new clock and is
        // therefore treated as stale automatically.
        val claimed = prefs.edit().putString(keyName, key).putLong(atName, nowElapsed).commit()
        if (claimed) inProcessClaims[keyName] = key
        return claimed
    }

    companion object {
        private val boundaryLock = Any()
        private val inProcessClaims = mutableMapOf<String, String>()
        private const val BOUNDARY_CLAIM_LEASE_MS = 2_500L
    }
}

GMK Mobile v0.7.39 復旧ソース / versionCode 109

【現在の状態】
ソース・試験データ・ワークフローを復旧しました。インストールできるAPKは同梱していません。
前回のAPKと署名鍵は失われたため、前回TESTと同じ署名の更新APKは再生成できていません。
以前の「113試験成功」は消失前のビルド結果です。今回の復旧版について成功を確認したのは、Javaで実行した連敗集計6試験と予測ルール・モデル資産の保存検証です。
復旧版のAndroid用111試験、UI試験、Lint、APKビルドはこれからGitHub Actionsで実行する必要があります。

【復旧した修正】
履歴の保存と再読込の競合を防ぐため、主履歴・バックアップ・確定結果ジャーナルを共通ロックで取得。
現在・最大連敗、3/5連敗以上の回数をENTRY時刻の昇順で集計。SKIP・未確定・取得失敗では連敗を消しません。同値はLOSE。
履歴イラストを判定時刻・価格の下へ配置して重なりを防止。
予測ルール、AIモデル、ENTRY保護、1分手動/AUTO、BTC/JPY取得はv0.7.38を維持。研究用反転AIは未採用です。

【GitHubでのビルド】
1. このダウンロードZIPをパソコン等で展開します。
2. GMK_MOBILE_V0739_STREAK_SOURCE_20261008.zip と GMK_V0735_TEST_DATA.zip をリポジトリへ配置します。
3. GMK_MOBILE_V0739_BUILD_WORKFLOW_20261008.yml の内容を .github/workflows/build.yml に配置します。
4. Pushまたは手動実行で111試験・Lint・ビルドを実行し、すべて成功後に GMK_MOBILE_V0739_APK の成果物を取得します。
5. 同じ既存本番鍵を使う場合はGMK_SIGNING_KEYSTORE_BASE64 / GMK_SIGNING_STORE_PASSWORD / GMK_SIGNING_KEY_ALIAS / GMK_SIGNING_KEY_PASSWORDをActions Secretsへ設定します。
署名鍵がない場合のTEST_ONLYは、インストール済みアプリと署名が一致する保証がありません。
履歴保持のため、既存アプリをアンインストールしないでください。同じ鍵で署名したAPKによる上書き更新が必要です。

【ソースを直接配置する場合】
SOURCE ZIPとTEST_DATA ZIPを同じプロジェクトに展開します。TEST_DATAの旧ルート名だけをGMK_MOBILE_V0739_STREAK_20261008へ読み替えます。
sha256sum --check --quiet PACKAGE_MANIFEST_SHA256.txt と python3 tools/direct19_release_audit.py で復元内容を検証できます。
署名鍵・APK・SDK・Gradle配布物は含まれていません。過去の監査資料はv0.7.38として区別して保持しています。

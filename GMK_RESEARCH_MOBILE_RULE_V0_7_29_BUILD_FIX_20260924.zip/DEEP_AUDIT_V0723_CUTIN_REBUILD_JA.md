# GMK MOBILE v0.7.23 カットイン全面再構築監査
更新日: 2026-09-23

## 結論
v0.7.22で確認された以下の問題を全面再構築した。

1. カットイン画像の見切れ / 隣接パネル混入
2. 勝ち優勢 / 負け優勢が表示されない
3. 30秒 / 15秒トリガーの狭い時間窓依存
4. 微小値動きデッドバンドにより優勢イベントが消える
5. 複数結果確定時に表示中カットインが上書きされる
6. カットイン発火の診断情報が不足

## 画像資源修正
- 既存60枚を流用せず、元コラージュから再切り出し。
- 水平/垂直セパレータを検出して、各パネル境界を正しく分離。
- 全60枚を 1600x500 (16:5) に統一。
- 元絵は一切Cropせず、Fitで安全領域内へ配置。
- 背景のみ同一絵のblur拡張を使用。
- 1分優勢20枚は専用「15秒前 / 00:15」表記へ再生成。
- 全60 WebP decode PASS。

## UI表示修正
- Image: `aspectRatio(16f / 5f)` + `ContentScale.Fit`
- Card幅: 96%
- 画像を固定比率コンテナ内へ完全表示。
- タップでカットインを閉じられる。
- 勝ち優勢 / 負け優勢 / WIN / LOSEを下段ステータスで明示。
- 画像素材自体に隣接パネルが混ざらないため、端末幅によらず見切れない。

## 優勢トリガー再構築
純Kotlin `CutInPolicy.kt` を追加。

### 3分
- judge残り30秒以内に入った後、未表示なら1回発火。
- 30秒ジャスト付近を逃しても、判定前なら回収可能。

### 1分
- judge残り15秒以内に入った後、未表示なら1回発火。
- 同様に遅延復帰しても判定前なら回収可能。

### 勝ち/負け優勢
- HIGH: current > entry なら WIN_ADVANTAGE、それ以外は LOSE_ADVANTAGE
- LOW: current < entry なら WIN_ADVANTAGE、それ以外は LOSE_ADVANTAGE
- GMK仕様上DRAWはLOSEなので、同値は負け優勢側。
- LIVEかつage<=20秒のみ使用。
- 従来の `minMovePct` デッドバンドは撤去。

### 重複防止
- 同一scanIdで優勢は `scanId:ADVANTAGE` 1回のみ。
- 価格が途中反転しても勝ち優勢→負け優勢の二重表示はしない。
- 確定結果は `scanId:FINAL` として別に1回表示可能。

## 複数イベント
- 表示中カットインは別イベントで上書きしない。
- 表示終了後、20秒以内の未表示確定結果を順次回収。
- 1分/3分pendingが重なっても、lead時刻に最も近いものから処理。

## 診断ログ追加
- cut_in_shown_count
- cut_in_last_type
- cut_in_last_scan_id
- cut_in_last_instrument
- cut_in_last_at_jst
- cut_in_suppressed_reason
- cut_in_suppressed_scan_id

優勢が出ない場合も `NO_FRESH_LIVE_RATE` 等を診断可能。

## 回帰テスト
- Functional contract: 86/86 PASS
- CutInPolicy pure Kotlin unit test: PASS
- 全domain Kotlin compile: PASS
- Android source brace/paren balance: PASS
- Cut-in assets: 60/60, 1600x500, WebP decode PASS
- 履歴UI / スキャンUI / 通信 / AUTO / 結果追跡 / ランクロジック:変更なし

## 最新診断ログとの関係
v0.7.22ログでは cut_in_enabled=true。ログ生成時点の唯一のpendingは手動3分 USDJPY LOWで、judgeは17:06:44、ログ生成は17:04:09だったため、そのログ採取時点ではまだ30秒前ではない。v0.7.23以降は30秒以内へ入った任意のtickで優勢判定を必ず再評価し、発火/抑止理由を診断JSONに残す。

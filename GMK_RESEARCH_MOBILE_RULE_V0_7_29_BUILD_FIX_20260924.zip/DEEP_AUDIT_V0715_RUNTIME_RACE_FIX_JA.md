# GMK MOBILE RULE v0.7.15 RESEARCH DEEP HARDENED 追加監査

更新日: 2026-09-23

## 今回の追加修正

1. 3分AUTO boundary claim順序を修正
   - 旧: T-10ウィンドウに入った時点でboundaryをclaimし、その後busyならMISSED。
   - 問題: 50秒台前半で一瞬busyだと、同一50-54秒ウィンドウ内の再試行が不可能。
   - 新: 実際にscan開始可能になった瞬間だけclaim。50-54秒内は再試行。
   - 55-59秒まで開始できなかった場合のみMISSED確定。

2. 1分AUTO boundary claim順序を同様に修正
   - 50-54秒内でbusy解除を待って再試行。
   - 55-59秒で未開始ならMISSED確定。

3. 3分AUTO優先時の1分スキャン停止処理を修正
   - oneMinuteJob.cancel() + repository.cancelAll() を廃止。
   - cancelAndJoin() で対象1分ジョブのみ停止し、共有MarketRepositoryの別通信を不用意に巻き込まない。

4. 1分SKIP表示を修正
   - confidence < 53% は履歴上E/SKIPであるにもかかわらず、画面statusが「完了 / 1分後判定」と見える問題を修正。
   - ENTRY時のみ「1分後判定」、Eは明示的に「見送り: 53%未満」と表示。

5. バージョン更新
   - versionCode 85
   - versionName 0.7.15-research-deep-hardened

## 継続して維持するv0.7.14修正

- S>=75 / A>=65 / B>=58 / C>=53 / 53未満E/SKIP
- DRAWは方向判定上LOSE
- Activity/Service単一Runtime
- BOOT_COMPLETED復旧
- 1分AUTO単独時の5分ごと欠落修正
- 23:00境界をENTRY時刻基準で制限
- 手動3分 +10秒をnano丸めなしで厳密化
- T-10 false MISSED guard
- 3分M1 gap >90秒 fail-safe
- quote/candle大乖離 fail-safe
- outcome quoteはtargetより前を不採用
- 履歴上限20,000
- 研究ZIPをGitHub自動本番ビルド対象外

## テスト

- functional_contract_test.py: 39/39 PASS
- 今回変更はruntime scheduling/UI statusのみで、LocalRuleEngine/ResearchRuleIdPolicyは未変更。
- よって同一入力データのReplay判定結果はv0.7.14と同一。

## 残る重要事項

- この版はRESEARCH版であり、9月Dukascopyデータを研究に使用しているため完全OOSではない。
- Yahoo本番provider一致の9月履歴データでの再Replayが必要。
- Android実機のDoze/メーカー独自省電力下ではForeground Serviceのみで秒単位起床を完全保証できない。実機長時間試験が必要。
- SharedPreferencesへ20,000件の履歴を保持する設計は長期的にはRoom/SQLite移行が望ましい。現状は機能互換を優先して据え置き。

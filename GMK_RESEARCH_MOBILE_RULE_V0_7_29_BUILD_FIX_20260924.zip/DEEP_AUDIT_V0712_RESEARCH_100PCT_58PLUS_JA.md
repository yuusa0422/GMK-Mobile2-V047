# v0.7.12 RESEARCH 100% ENTRY / 58%+

- 研究版。9月データを用いてルールID品質を探索したため、9月はOOSではない。
- S/A/B/Cが1つ以上ある枠では必ず1件ENTRY。S/A/B/Cを勝率目的でSKIPしない。
- D/E/F/G/H/I相当のみ除外。
- 複数ENTRY候補は研究用rule-id品質で1件選択。
- sample>=8のrule-idのみ方向反転可。
- 2026-09 replay: eligible 2249, ENTRY 2249, WIN 1255, LOSE 888, DRAW 106, WR 58.5628% (WIN/(WIN+LOSE)).
- これは研究値であり将来勝率の保証ではない。

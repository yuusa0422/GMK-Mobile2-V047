# GMK MOBILE RULE v0.7.18 Cut-in Implementation

更新日: 2026-09-23

## 実装内容

v0.7.17 STABILITY FIX を基準に、スマホ版へ東方風カットインを追加した。
判定エンジン、レート取得、AUTOスキャン、結果追跡ロジックは変更していない。

### 4状態
- WIN_ADVANTAGE: 勝ち優勢
- LOSE_ADVANTAGE: 負け優勢
- WIN_FINAL: 勝ち確定
- LOSE_FINAL: 負け確定

### 表示タイミング
- 3分判定: judge_time の30秒前
- 1分判定: judge_time の15秒前
- WIN/LOSE確定: HistoryStore の正式 resultStatus 更新直後

### 優勢判定
優勢カットインは HistoryRow.entryRate と現在のLIVE価格を比較する。
- HIGH: current > entry なら勝ち優勢、current < entry なら負け優勢
- LOW: current < entry なら勝ち優勢、current > entry なら負け優勢
- 同値の場合は優勢カットインを出さない
- freshnessStatus=LIVE かつ age<=20秒の価格のみ使用
- LAST/STALE価格では優勢判定を出さない

### 確定判定
- resultStatus=WIN -> 勝ち確定
- resultStatus=LOSE -> 負け確定
- WAIT/MISSED/SKIP では確定カットインを出さない

### 画像
- 10パターン x 4状態 = 40 WebP
- app/src/main/res/drawable-nodpi/ に同梱
- scanId/instrument の安定ハッシュで1〜10を選択
- 同一scanId・同一状態は二重表示しない

### 表示時間
- 優勢/負け優勢: 約2.4秒
- WIN/LOSE: 約3.0秒
- UI Overlayのみ。市場通信・スキャン・結果追跡をキャンセル/停止しない。

### 設定
設定画面に「東方カットイン」ON/OFFを追加。
初期値ON。
AppPrefs cut_in_enabled に保存。
診断JSONにも cut_in_enabled を出力。

## 安全性
- カットインロジックはCompose UI層に限定。
- LocalRuleEngine / OneMinuteLocalEngine への影響なし。
- outcome tracking の正式履歴を参照するのみ。
- カットインのための追加ネットワーク通信なし。

## 検証
- functional_contract_test.py: 59/59 PASS
- Domain Kotlin compile: PASS
- 40画像リソース存在確認: PASS
- WIN/LOSE/勝ち優勢/負け優勢: PASS
- 3分30秒 / 1分15秒: PASS
- LIVE限定: PASS
- WIN/LOSE履歴限定: PASS
- ON/OFF設定: PASS

## 注意
Android全体のCompose compileDebugKotlinは、この作業環境にGradle Wrapperがないため未実行。
GitHub Actionsの既存compileDebugKotlin工程で最終確認すること。

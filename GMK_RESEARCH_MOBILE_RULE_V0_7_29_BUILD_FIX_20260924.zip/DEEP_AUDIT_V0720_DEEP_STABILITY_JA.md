# GMK MOBILE RULE v0.7.20 Deep Stability Audit
更新日: 2026-09-23

## 結論
v0.7.19を再監査し、長時間運転・通信・時刻境界・復旧系で追加不具合を修正した。
判定ルール/ランク閾値/カットイン仕様そのものは変更していない。

## 今回の追加修正

1. 1分AUTOの23:00越境
- 22:59:50台で現在時刻だけを見るとAUTOが起動し、ENTRY=23:00を作れる経路があった。
- AUTO boundary自体を09:00以上23:00未満で検証して見送りに変更。

2. 1分AUTO boundaryの1分ずれ
- schedulerで15:00 boundaryを選んでも、Coroutine開始が15:00:00を跨ぐとstartOneMinuteScan側が15:01を再計算する可能性があった。
- schedulerが決めたentry boundaryを明示的にOneMinuteLocalEngineへ渡す方式へ変更。

3. 手動3分とM1 OPEN方式の不整合
- 手動3分は押下+10秒の任意秒がENTRYなのに、v0.7.16以降は完全一致するM1 OPENを探していたため原理上一致しないケースがあった。
- AUTO/1分はexact M1 OPEN、手動3分だけは対象秒付近のfresh LIVE quoteを採用する二系統契約へ修正。

4. Yahoo query2が古いがHTTP成功する場合のfallback漏れ
- query2がLASTを返しても成功扱いでquery1を試さない問題を修正。
- LIVEでない場合はquery1も確認し、両方古い場合のみ最も新しいLASTを採用。

5. Yahoo M1が古いがHTTP成功する場合のfallback漏れ
- query2にローソク足が存在しても最新完成M1が欠けている場合、query1を試さない問題を修正。
- 最新完成M1時刻を満たすまでquery1へfallback。

6. Yahoo通常レート取得の過剰payload/burst
- 最新レートだけのために毎回range=1d/1mを取得していた。
- 通常レートは直近10分程度のperiod windowへ縮小。
- Yahoo同時通信をprocess-wide Semaphore(2)で制限し、rate/candle/outcomeのburstを抑制。

7. pending outcome復旧洪水
- 再起動時に多数のWAIT_ENTRY/WAIT_JUDGEがあると大量Coroutineから同時取得する可能性があった。
- outcome captureをSemaphore(2)で制限。
- exact-minute endpointのretry間隔も3秒へ緩和。

8. HistoryStore disk write backlog
- 20,000件snapshotを更新ごとにsingle-thread executorへ全件積むと、書込みキューが長時間蓄積する可能性があった。
- pendingWrite + AtomicBooleanによるcoalescing writerへ変更し、常に最新snapshotを優先保存。

9. Doze / battery optimizationの可視化
- Foreground Serviceだけではメーカー省電力/Dozeで秒精度を保証できない。
- battery optimization exemption / background restrictionを検出。
- 画面警告とAndroid設定への導線を追加。
- 診断JSONにも両状態を記録。

10. カットインslot hash edge case
- Int.MIN_VALUEでabsが負のままになる稀なedge caseをMath.floorModへ変更。

## 検証
- Functional contract: 78/78 PASS
- Domain Kotlin compile: PASS
- Full Android source parser sanity: syntax error / redeclarationなし
- 60 cut-in assets: retained

## 残る実機確認
- Android全体 compileDebugKotlin / assembleDebug
- 実機Doze・メーカー省電力下での長時間AUTO
- Yahoo 429/5xx実測カウンタ
- 再起動後pending outcome回収
- 22:59境界の実機確認

# GMK Mobile v0.7.28 横断監査・修正レポート

更新日: 2026-09-24  
対象: v0.7.27スマートフォン版ソース、画面・状態連携、データ取得、スキャン/判定、履歴保存、カットイン、GitHub Actionsワークフロー  
修正版: versionCode `98` / versionName `0.7.28-cross-audit-fixes`

## 結論

全機能を横断して確認し、重大な不整合を2件修正した。9月研究専用ランク表が本番候補選択に混入する問題を解消し、Androidアプリのソースセット外へ隔離した。また、履歴のクラッシュジャーナル書き込みと非同期掃除が競合して、復旧用の最新履歴を消し得る問題をロックで防止した。

研究・本番のビルド経路はGitHub Actionsの入力で分離し、研究APKには `RESEARCH_ONLY` を表示する。回帰契約テストは **160/160 PASS**。ワークフロー14個のBash構文、ソース選択、研究/本番の分離、壊れたZIPとパストラバーサルの拒否、研究インストールZIP生成を擬似実行で確認した。

**9月の勝率57%は達成していない。** 研究表を除いた固定本番ポリシーの9/2〜9/22データ再生では、対象2,519枠中2,224件がENTRY（88.29%）だが、DRAWを負けとして数える勝率は48.70%。この数字はオフラインのポリシー再生であり、実機・ライブ配信の結果ではない。9月に合わせて再調整した表は同じ9月データ由来のため、OOS成績として扱えない。

Android SDK / Gradle / Kotlin compilerがこの実行環境になく、実APKのコンパイル・組み立てと実機/実通信の検証は未実施。納品ZIPはソースZIPであり、インストール用APKではない。

## 検出・修正

| # | 問題 | 修正 |
|---|---|---|
| 1 | 2026-09-02〜22から作られた研究用 `ResearchRuleIdPolicy` が3分本番スキャンから呼び出され、ランク・方向反転・ENTRY/SKIPへ作用していた。9月の結果を同期間の本番判定へ戻すデータ漏洩になる。 | ライブの `LocalRuleEngine` から研究補正適用を削除。研究表は `app/src/main` の外へ移し、Androidビルド対象から除外。全Kotlinソースで再参照を検査する回帰条件を追加。 |
| 2 | 履歴のメイン保存が非同期で走る間、クラッシュジャーナルを読み取って削除する直前に新しい重要行が保存されると、唯一の復旧コピーまで削除する競合があった。 | ジャーナルへの行追加/更新と、保存後のジャーナル掃除を同じ `journalLock` で直列化。 |
| 3 | GitHub ActionsがソースZIPを自動選択するため、研究ソースを本番ビルドへ誤って取り込む余地があった。 | `workflow_dispatch` に `production/research` の明示選択を追加。各トラックのZIPだけを選び、productionでは研究ZIPを無視。研究用インストール手順には `RESEARCH_ONLY` とOOS扱い禁止の説明を追加。 |

この監査で新たに確認した不具合は上記2件（研究/本番ビルド分離は再発防止と誤配布防止）。未確認の挙動を「問題なし」と断定していない。

## 横断した確認範囲

- **予測/スキャン:** 1分・3分エンジン、6/6通貨条件、直近完成1分足、鮮度/乖離判定、09:00以上〜23:00未満、T-10境界、手動ENTRY予定時刻
- **市場データ:** Yahoo FXレート/ローソク足、bitbank BTCJPY、fallback、stale応答、対象分のENTRY/JUDGE価格取得
- **ランク/結果:** S/A/B/C/Eの実運用ランク判定、TOP候補、方向反転、ENTRY/SKIP契約、DRAWをLOSEとする判定
- **履歴/状態:** ENTRY→判定待ち→WIN/LOSE、重複防止、クラッシュジャーナル、バックアップ復旧、保存診断、結果の再開
- **チャート:** 1分〜日足、確定足、ボリンジャーバンド/MACD、ENTRY/判定/結果マーカー、履歴からのジャンプ
- **通貨強弱:** 共通計測区間、セッション比較、ヒートマップ、予測候補との方向整合、チャート遷移
- **カットイン:** 4状態、WIN/LOSE優勢と確定、鮮度ゲート、二重発火抑止、画面横断表示/サイズ
- **実行管理:** Foreground Service、単一Runtime、再起動/省電力診断、自動スキャン境界のリース
- **配布ワークフロー:** ZIPの内部version/applicationId検査、安全展開、研究/本番分離、コンパイル工程、署名経路、APK metadata、固定4ファイルのインストールZIP/SHA-256

## 再生値の注意

固定されたJan-Aug由来の本番ポリシーを9/2〜22の再生フレームへ適用した参考値:

| 指標 | 結果 |
|---|---:|
| 再生対象枠 | 2,519 |
| ENTRY | 2,224 |
| ENTRY率 | 88.29% |
| WIN / LOSE / DRAW | 1,083 / 1,043 / 98 |
| DRAW=LOSE 勝率 | 48.70% |
| DRAWを除外する参考勝率 | 50.94% |

比較対象の9月研究表は同じ9月期間から作られたin-sample値で、ENTRY 1,231/2,519 (48.87%)、DRAW=LOSE勝率60.03%。これは本番や独立OOSの成績ではない。再生データはDukascopy系CSVで、アプリのYahoo/bitbankライブ通信とも同一ではない。したがって、このレポートは勝率57%やENTRY率85%の同時達成を認定しない。

## 変更ファイル

- `app/src/main/java/jp/gmk/mobile/domain/LocalRuleEngine.kt`: 研究用ポリシー適用を除去し、不要な確率ランク関数を削除。
- `research/ResearchRuleIdPolicy.kt`: 9月研究表をAndroidソースセット外へ移動。
- `app/src/main/java/jp/gmk/mobile/data/HistoryStore.kt`: journal追加/掃除を共有ロックで直列化。
- `app/build.gradle.kts`: versionCode 98 / versionName 0.7.28へ更新。
- `.github/workflows/build.yml`: 明示的な本番/研究ビルドトラックを実装し、成果物名・研究ラベルへ反映。
- `tools/functional_contract_test.py`: 研究ロジック非混入、journal排他、ワークフロー/画面/結果条件を検査。

## 検証結果

- 機能回帰契約: **160/160 PASS**
- Workflow YAML parse、14個の埋め込みBash構文: PASS
- Workflowのsource preflightを実行: PASS
- ソース選択の疑似実行:
  - research指定で研究ZIPを選択・展開し、RESEARCHを出力: PASS
  - production指定で研究ZIPを無視し、プロジェクトソースを使用: PASS
  - 同一トラックの破損ZIPをfail-closedで拒否: PASS
  - ZIP path traversalを拒否し、展開先外へ書き出さない: PASS
- 研究インストールZIP生成: 固定4ファイル、CRC、APK SHA-256、RESEARCH_ONLYラベル: PASS
- Python AST、AndroidManifest XML: PASS
- 9/2〜22固定本番ポリシー再生: ENTRY 88.29%、DRAW=LOSE勝率48.70%（オフライン参考値）
- Android compile/assemble、署名済APK、実端末UI、実際のYahoo/bitbank通信: 未実施

## 未解決/制約

1. Android SDK / Gradle / Kotlin compilerがなく、実ビルドと実機表示を確認できていない。CIのAndroid runnerで `:app:compileDebugKotlin` と `:app:assembleDebug` を通す必要がある。
2. GitHub Actionsの永続署名を継続更新に使う場合は4つの `GMK_SIGNING_*` secretが必要。未設定時のdebug署名は実行ごとに異なり得る。
3. 実ネットワーク上でYahoo Finance/bitbankのレート制限、配信遅延、休場時の応答は未検証。
4. 9月固定本番ポリシー再生はENTRY率85%を超える一方、勝率57%に達していない。独立期間・実機履歴で検証しながら改善が必要。

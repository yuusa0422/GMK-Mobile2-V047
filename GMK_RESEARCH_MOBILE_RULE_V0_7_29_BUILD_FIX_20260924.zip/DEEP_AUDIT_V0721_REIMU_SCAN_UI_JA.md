# GMK MOBILE RULE v0.7.21 霊夢スキャンUI実装監査

更新日: 2026-09-23

## 変更目的
v0.7.20の安定化済み判定・通信・AUTO・結果追跡を維持したまま、スキャン画面をユーザー選択の「霊夢 / 夜の神社 / 桜 / ネオン」案へ統一する。

## 実装内容
- スキャン画面背景を夜の神社・桜・月のダークテーマへ変更。
- 霊夢メインのヒーローバナーを追加。
- スキャン開始ボタンを赤紫ネオンの主CTAへ変更。
- 6/6 LIVE・判定可能数・取得状態をダークネオンパネル化。
- 3分AUTOパネルを同系統デザインへ変更。
- 1分専用板を紫/青系の独立カードへ変更。
- TOP1を金縁＋赤紫/青グラデーションの強調カードへ変更。
- 候補一覧をHIGH=赤桃、LOW=青水色のネオン枠へ変更。
- 下部ナビゲーションを夜色＋桜色の選択表現へ変更。
- 背景/ヒーロー画像はWebP化し、UI表示専用。判定処理から完全分離。

## 非変更領域
- LocalRuleEngine
- OneMinuteLocalEngine
- ResearchRuleIdPolicy
- Yahoo/bitbank取得処理
- 1分/3分AUTO scheduler
- outcome tracking
- rank threshold
- cut-in logic
- history persistence

## 回帰確認
- functional_contract_test.py: 78/78 PASS
- MainActivity.kt 括弧/波括弧バランス確認 PASS
- 新規画像2枚 decode PASS
- 既存60 cut-in assets 非変更

## 新規リソース
- scan_reimu_hero.webp
- scan_reimu_bg.webp

## 注意
Android全体のcompileDebugKotlin / assembleDebugはGitHub ActionsまたはAndroid SDK/Gradle環境で最終確認すること。

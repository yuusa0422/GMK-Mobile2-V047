# GMK MOBILE v0.7.22 幻想郷履歴UI 実装監査

更新日: 2026-09-23

## 実装内容
- v0.7.21を基準に履歴画面のみ幻想郷UIへ変更。
- 夜の神社・月・桜・ネオンを基調にした背景を追加。
- 上部サマリーを3枚のネオンタイルへ変更。
  - 3分
  - 1分
  - 3分SKIP参考
- 履歴カードを状態別デザインへ変更。
  - WIN: 緑/桃系 + 霊夢装飾
  - LOSE: 赤系 + 妖夢装飾
  - WAIT_ENTRY / WAIT_JUDGE: 紫系
  - RATE_MISSED / MISSING: 警告色
- HIGH/LOWを赤桃/水色で視認しやすくした。
- ENTRY/JUDGE時刻、価格、provider、取得遅延、provider ageは従来どおり保持。

## 変更していないもの
- LocalRuleEngine
- FinalRankPolicy
- ResearchRuleIdPolicy
- Yahoo/bitbank取得
- 1分/3分AUTO
- 結果追跡
- カットイン判定
- 履歴データ構造

## 追加アセット
- history_gensokyo_bg.webp
- history_reimu_win.webp
- history_youmu_lose.webp

## 検証
- Functional contract: 82/82 PASS
- 追加WebP decode: PASS
- MainActivity.kt braces: balanced
- MainActivity.kt parentheses: balanced

## 注意
Android全体のcompileDebugKotlin / assembleDebugはGitHub ActionsまたはAndroid SDK/Gradle Wrapperのある環境で最終確認すること。

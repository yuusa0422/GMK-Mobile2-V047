# GMK MOBILE v0.7.17 Stability Fix 深掘り監査

更新日: 2026-09-23

## 目的
v0.7.9実機診断ログで、通常の6通貨LIVEレートは取得できている一方、ENTRY_RATE_MISSED / JUDGE_RATE_MISSED、AUTO_SCAN_MISSEDが複数発生していたため、v0.7.16を基準に通信・鮮度・結果追跡を再監査した。

## ログから確認した事実
- connected_6 / available_6 / live_6 は true。
- 6通貨の通常レート age は概ね1〜2秒。
- 一方でENTRY_RATE_MISSED / JUDGE_RATE_MISSEDが複数存在。
- したがって通常レート供給そのものより、スキャン/結果追跡時の通信競合と取得契約が主問題。

## v0.7.17 追加修正
1. 1分スキャン開始時の repository.cancelInFlightRequests() を撤去。
2. 3分スキャン開始時の repository.cancelInFlightRequests() を撤去。
   - scan開始で通常LIVEレート通信を自分でキャンセルする構造を除去。
   - cancelAllはruntime shutdown時のみ使用。
3. Yahoo scan candle取得を range=5d から range=1d へ削減。
   - 09:00-23:00運用で直近120本取得には十分。
   - 毎分の1m AUTOでの通信量を大幅削減。
4. Yahoo exact-minute OPEN取得を period1/period2 指定へ変更。
   - query2成功でも対象足未掲載ならquery1へフォールバック。
   - targetが過去になったpending outcomeも回収可能にした。
5. outcome recovery:
   - target+90秒を過ぎてprocess復帰した場合も、復帰後20秒間はexact historical M1 OPENを再取得。
6. LIVE freshnessを75秒から20秒へ厳格化。
   - 古いキャッシュをLIVEと表示し続けない。
7. scan busy中もcached rate ageを進める。
   - scan中にage表示が1〜2秒で凍る不具合を修正。
   - 20秒超はLASTへ遷移。
8. Yahoo host failoverを高速化。
   - 同一host内の長い再試行より query2 -> query1 を優先。
   - connectTimeout 3秒 / readTimeout 4秒 / callTimeout 4秒。
9. HTTP 429/5xx retryを強化。
   - Retry-Afterを尊重。
   - deterministic backoffを追加。
10. lastRateSuccessMsを「6/6すべてLIVE成功時」のみ更新。
    - 一部通貨だけ成功した取得を完全成功として記録しない。
11. 診断ログに network stats を追加。
    - requests / success / failure / http_429 / http_5xx / last_error
    - market用とoutcome用を分離。

## 維持した既存修正
- 単一process runtime
- BOOT_COMPLETED復旧
- 3分/1分AUTO boundary claim race修正
- 09:00 <= ENTRY < 23:00
- 6/6必須
- completed M1 freshness / continuity gate
- quote/candle divergence fail-safe
- exact target minute OPENでのENTRY/JUDGE
- rank thresholds S75/A65/B58/C53
- DRAWはdirectional LOSE

## テスト
- functional contract: 53/53 PASS
- domain Kotlin compile: PASS
- Android full compileDebugKotlin: この実行環境にはGradle wrapperが無いため未実行。GitHub Actionsで最終確認が必要。

## 注意
本版はResearch系列。勝率ロジックはv0.7.16から変更していない。通信/Runtime安定化のみ。

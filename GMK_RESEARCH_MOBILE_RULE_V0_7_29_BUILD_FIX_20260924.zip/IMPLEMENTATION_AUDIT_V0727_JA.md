# GMK MOBILE v0.7.27 再監査・修正レポート

更新日: 2026-09-24  
更新元: `GMK_RESEARCH_MOBILE_RULE_V0_7_26_CHART_STRENGTH_20260923.zip`  
修正版: versionCode `97` / versionName `0.7.27-chart-strength-fixes`

## 結論

チャート・通貨強弱・状態表示とGitHub Actionsワークフローを再監査し、アプリ表示の7項目に加えてCI/配布の不具合を修正した。スキャン判定、ランク閾値、ENTRY/SKIP条件は変更していない。

ソース契約テストは **157/157 PASS**。GitHub ActionsのYAMLと全Bashスクリプト構文、ZIPの選択・展開、破損ZIPのfail-closed、インストールZIPの4ファイル構成とSHA-256検査も個別に実行確認した。Android SDK / Gradle / Kotlin compilerがこの実行環境にないため、`:app:compileDebugKotlin`、`:app:assembleDebug`、実機表示・実通信は未検証。納品ZIPは修正版ソースであり、インストール用APKではない。

## 検出・修正した不具合

| # | 不具合 | 修正 |
|---|---|---|
| 1 | 通貨強弱のFXは数か月、BTCは直近数日で計算され、異なる期間の値を同じランキングへ混在させていた。 | 強弱計算の共通開始・終了時刻にBTC足も含め、比較可能な同一期間へそろえた。 |
| 2 | MACDの信号EMAを先頭足から計算し、遅いEMAの初期化区間を含めた値を早期表示していた。 | MACDの信号線は26本の遅いEMAが揃った後から計算し、12-26-9では34本目から表示する。少数足の警告条件も34本に統一した。 |
| 3 | ローソク足を等間隔で描く一方、ENTRY/判定線とボリンジャー線は実時刻間隔で描き、休場や欠落足で位置がずれていた。 | ローソク足・ボリンジャー・ENTRY/判定マーカーを同じ時刻座標へ統一した。 |
| 4 | SKIP候補や時刻を過ぎた候補も「予定ENTRY」としてチャート表示されていた。 | 3分は`decision=ENTRY`、1分は実際の判定と同じ確信度53%以上に限定し、ENTRY予定時刻を過ぎたら予定線を消す。履歴から開いたSKIP行もENTRYマーカーにはしない。 |
| 5 | 表示範囲外の履歴価格がチャートの縦軸を歪め、ENTRY時刻が範囲外だと判定マーカーも描かれない場合があった。 | 表示範囲内のENTRY/判定価格だけを縦軸へ反映し、ENTRY線と判定線を独立して表示する。 |
| 6 | 初回未取得でもチャート・強弱が「同期済/更新済」と表示され、ペアや時間足の再取得時に前回更新時刻が残っていた。状態画面の直近候補も古い3分候補を優先する場合があった。 | 正常取得時刻がある場合だけ同期済と表示し、再取得開始時に時刻をクリア。3分/1分の候補は時刻を比べて最新を表示する。 |
| 7 | bitbankチャートの日別取得失敗を空データへ変換して捨て、部分取得の警告が画面に出なかった。 | 日付ごとの取得警告を結果に保持。部分データでもチャートを表示しつつ状態・診断ログへ警告を流し、全失敗時は原因をエラーに含める。キャンセルは取得失敗として扱わない。 |
| 8 | CIがZIP内のversionCode/versionNameは照合してもapplicationIdを照合せず、認識済みGMKソースZIPが壊れていても黙って別ソースへ進む可能性があった。 | 3項目すべてを照合し、該当名のZIPが不正ならビルドを停止する。抽出時はパストラバーサル、リンク、特殊ファイル、重複パスを拒否する。 |
| 9 | Kotlin補間の事前検査がMainActivityだけで、別画面の日本語文字列補間ミスを見逃す可能性があった。ソース契約テストもCIで実行していなかった。 | 全Kotlinソースを検査し、`functional_contract_test.py`をビルド前に実行する。 |
| 10 | CIはAPKだけを成果物化し、スマホ向けの固定内容インストールZIPを作っていなかった。 | `GMK_MOBILE.apk`、`インストール手順.txt`、`SHA256.txt`、`診断ログ説明.txt`の4ファイルだけを含むZIPを作成し、ZIP整合性と内包APKのSHA-256を検証する。 |
| 11 | 毎回のGitHub runnerで生成されるdebug署名鍵は実行間で同じとは限らず、更新APKの署名が一致せず上書きできない場合がある。 | 永続署名用の4つのActions secretに対応し、指定時はAPKをその鍵で署名する。未設定時はdebug署名と明記し、署名モードを成果物に記録する。 |

## 変更一覧

- `ChartIndicators.kt`: MACD信号線のウォームアップ区間を修正。
- `StrengthAnalysis.kt`: BTCを含めた共通比較期間を計算。
- `MarketScreens.kt`: 実時刻にそろえた描画、ENTRY条件、履歴スケール、未取得表示、直近候補の時刻比較を修正。
- `MarketRepository.kt`: 部分取得警告を`ChartCandleResult`に保持し、通貨強弱・診断表示へ伝達。
- `GmkViewModel.kt`: MACD必要足数の警告を修正し、チャート更新時刻をリセット。
- `.github/workflows/build.yml`: ZIP検証・メタデータ照合・全Kotlin事前検査・契約テスト実行・インストールZIP作成/検証・永続署名鍵対応を追加。
- `functional_contract_test.py`: 表示修正とワークフロー不変条件の再発防止チェックを追加。
- アプリ版をversionCode `97`へ更新。

## 検証結果

- ソース契約テスト: **157/157 PASS**
- CI workflow YAML、全embedded Bash構文、Python AST: PASS
- ZIP選択/展開スモーク: versionCode `97`、applicationId `jp.gmk.mobile.rule`、プロジェクト出力を確認
- 破損したGMKソースZIP: 古いソースへ進まず停止することを確認
- インストールZIP: 必須4ファイルのみ、ZIP CRC、内包APK SHA-256一致を確認
- 署名処理: 永続署名設定、未設定debug経路、部分設定時の停止を確認（署名コマンドはfake signerで分岐試験）
- PythonテストスクリプトAST parse: PASS
- AndroidManifest XML parse: PASS
- カットインWebP: **60/60** decode、各1600×500。代表画像2点の表示サイズ・見切れを目視確認。
- APKビルド: 未実行（Gradle、Kotlin compiler、Android SDKなし）
- 実機UI、Yahoo/bitbankライブ応答: 未実行

## 未解決項目

1. AndroidのKotlin compileとAPK assembleは未実行。Android SDK / Gradle / Kotlin compilerのあるCI runnerでの実ビルドが必要。
2. 同一アプリを継続更新するには、GitHub Actions secrets `GMK_SIGNING_KEYSTORE_BASE64`、`GMK_SIGNING_STORE_PASSWORD`、`GMK_SIGNING_KEY_ALIAS`、`GMK_SIGNING_KEY_PASSWORD`を初回配布前に設定する必要がある。未設定時は実行ごとに異なる可能性のあるdebug署名となり、既存APKへ更新できない場合がある。今回、この環境からActions secretsは設定していない。
3. 実端末で5タブ、ノッチ/ナビゲーション領域、チャート時間軸とENTRY位置、カットインを検証する必要がある。
4. Yahoo Finance / bitbankのライブ応答、レート制限、休場時の欠落・遅延は実通信で未検証。
5. BTC日足チャートは取得要求を抑えるため直近14日、BTC 1分/5分/15分/1時間は直近2日、4時間は7日。
6. 今回の修正は表示・比較期間・診断・ワークフローの整合性を対象とし、勝率57%やエントリー率85%を新たに保証するものではない。

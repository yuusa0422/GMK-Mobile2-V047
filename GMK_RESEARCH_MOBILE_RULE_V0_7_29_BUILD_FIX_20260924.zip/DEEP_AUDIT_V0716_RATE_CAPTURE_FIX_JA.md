# GMK v0.7.16 Rate Capture Fix

- 旧v0.7.9診断ログで通常レート6/6 LIVEにもかかわらず ENTRY_RATE_MISSED / JUDGE_RATE_MISSED が頻発することを確認。
- 原因: outcome追跡だけがtarget+6秒の狭い窓でYahoo/bitbankへ別リクエストを連打し、HTTP遅延/429/regularMarketTime遅延で失敗していた。
- 修正: ENTRY/JUDGE価格を対象分の1分足OPENで取得する。Replayと同一価格契約。
- 対象分足の公開遅延を考慮し最大90秒待機、1.5秒間隔で再試行。
- Yahoo結果追跡のサブ秒連打を廃止し429圧力を低減。
- 通常リアルタイム表示の6秒更新は維持。
- versionCode 86 / 0.7.16-research-rate-capture-fix。

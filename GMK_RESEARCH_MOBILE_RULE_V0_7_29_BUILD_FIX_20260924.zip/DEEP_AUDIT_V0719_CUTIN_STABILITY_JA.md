# GMK MOBILE v0.7.19 カットイン回帰・安定性監査

## 基準
v0.7.18 CUT-IN IMPLEMENTED を基準に再監査。

## 発見・修正
1. 複数の1分/3分 WAIT_JUDGE が重なると history.firstOrNull の先頭1件だけを見て、対象の30秒前/15秒前カットインを取りこぼす。
   - 修正: recent pendingを全件評価し、各自のlead時刻に最も近い対象を選択。

2. 20,000件履歴を250msごとに走査する可能性。
   - 修正: カットイン監視対象は先頭256件へ限定。active outcomeは必ず新しい側に存在する。

3. shown mapが長時間運転で無制限増加。
   - 修正: 1時間TTLでde-dup keyを削除。

4. ENTRY価格付近のごく小さなtick差でも勝ち/負け優勢を発火。
   - 修正: FX 0.002%、BTC 0.01%の最小変動幅を下回る場合は優勢表示しない。

5. 1分版は15秒前発火なのに画像内が「30秒前 / 00:30」。
   - 修正: 1分専用15秒前アセット20枚を追加。3分用と分離。

6. UI tickerが少し遅れただけで30秒/15秒トリガーを逃す。
   - 修正: lead後5秒までの遅延復帰を許容。ただし同scanId/同kindは一度だけ表示。

7. 履歴最大20,000件をSharedPreferencesへメインスレッドでJSON全書換え+commitしていた。
   - 修正: HistoryStoreにインメモリキャッシュを追加。JSON生成・disk commitは専用 single-thread I/O executorへ移動。
   - AUTO 100ms scheduler/UI threadを履歴I/Oから分離。

## カットインアセット
- 3分勝ち優勢 10
- 3分負け優勢 10
- 1分勝ち優勢(15秒表記) 10
- 1分負け優勢(15秒表記) 10
- 勝ち確定 10
- 負け確定 10
- 合計60 WebP
- 総容量 約2.0MB
- 全WebP decode検査 PASS

## 回帰監査
- functional_contract_test.py: 67/67 PASS
- 判定ルール本体、ランク閾値、結果取得方式は今回変更なし。

## 残る実機確認
- Android全体 compileDebugKotlin / assembleDebug はGitHub Actionsで最終確認が必要。
- Doze/メーカー独自省電力下のT-10実行精度は実機長時間試験が必要。

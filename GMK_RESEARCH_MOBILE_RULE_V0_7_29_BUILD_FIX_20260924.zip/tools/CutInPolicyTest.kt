import jp.gmk.mobile.domain.*

fun main() {
    check(CutInPolicy.leadMs(false) == 30_000L)
    check(CutInPolicy.leadMs(true) == 15_000L)
    check(CutInPolicy.isInAdvantageWindow(30_000L, false))
    check(CutInPolicy.isInAdvantageWindow(25_000L, false)) // delayed UI tick still shows
    check(CutInPolicy.isInAdvantageWindow(15_000L, true))
    check(CutInPolicy.isInAdvantageWindow(5_000L, true))   // delayed UI tick still shows
    check(!CutInPolicy.isInAdvantageWindow(0L, false))
    check(!CutInPolicy.isInAdvantageWindow(35_000L, false))
    check(CutInPolicy.advantageSignal("HIGH", 100.0, 100.1) == CutInAdvantageSignal.WIN_ADVANTAGE)
    check(CutInPolicy.advantageSignal("HIGH", 100.0, 99.9) == CutInAdvantageSignal.LOSE_ADVANTAGE)
    check(CutInPolicy.advantageSignal("LOW", 100.0, 99.9) == CutInAdvantageSignal.WIN_ADVANTAGE)
    check(CutInPolicy.advantageSignal("LOW", 100.0, 100.1) == CutInAdvantageSignal.LOSE_ADVANTAGE)
    check(CutInPolicy.advantageSignal("HIGH", 100.0, 100.0) == CutInAdvantageSignal.LOSE_ADVANTAGE)
    check(CutInPolicy.advantageSignal("LOW", 100.0, 100.0) == CutInAdvantageSignal.LOSE_ADVANTAGE)
    check(CutInPolicy.advantageSignal("SIDE", 100.0, 101.0) == null)
    println("CUTIN_POLICY_TEST PASS")
}

package jp.gmk.mobile.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import jp.gmk.mobile.runtime.GmkRuntimeKeepAliveService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import jp.gmk.mobile.BuildConfig
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.domain.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import org.json.JSONArray
import org.json.JSONObject


data class GmkUiState(
    val connected: Boolean = false,
    val busy: Boolean = false,
    val error: String? = null,
    val rateStatus: String? = null,
    val scanStatus: String? = null,
    val rates: List<RateRow> = emptyList(),
    val scan: ScanResult? = null,
    val history: List<HistoryRow> = emptyList(),
    val autoScan: Boolean = true,
    val oneMinuteAutoScan: Boolean = false,
    val cutInEnabled: Boolean = true,
    val oandaToken: String = "",
    val oandaAccountId: String = "",
    val oandaEnvironment: String = "practice",
    val yahooFallback: Boolean = true,
    val lastRateUpdateMs: Long = 0L,
    val lastRateSuccessMs: Long = 0L,
    val lastScanAttemptMs: Long = 0L,
    val lastScanSuccessMs: Long = 0L,
    val modeLabel: String = "端末単体",
    val rateLiveCount: Int = 0,
    val rateAvailableCount: Int = 0,
    val scannableCount: Int = 0,
    val lastScanExcluded: Map<String, String> = emptyMap(),
    val lastCandleErrors: Map<String, String> = emptyMap(),
    val lastCandleLatestMs: Map<String, Long> = emptyMap(),
    val quoteCandleDivergencePct: Map<String, Double> = emptyMap(),
    val oneMinuteBusy: Boolean = false,
    val oneMinuteStatus: String? = null,
    val oneMinuteScan: OneMinuteScanResult? = null,
    val outcomeStatus: String? = null,
    val batteryOptimizationExempt: Boolean = false,
    val backgroundRestricted: Boolean = false,
    val cutInShownCount: Int = 0,
    val lastCutInType: String? = null,
    val lastCutInScanId: String? = null,
    val lastCutInInstrument: String? = null,
    val lastCutInAtJst: String? = null,
    val lastCutInSuppressedReason: String? = null,
    val lastCutInSuppressedScanId: String? = null,
    val chartCandles: List<Candle> = emptyList(),
    val chartInstrument: String = "EURJPY",
    val chartTimeframe: String = "1m",
    val chartLoading: Boolean = false,
    val chartError: String? = null,
    val chartUpdatedAtMs: Long = 0L,
    val strengthCandles: Map<String, List<Candle>> = emptyMap(),
    val strengthTimeframe: String = "1h",
    val strengthLoading: Boolean = false,
    val strengthErrors: Map<String, String> = emptyMap(),
    val strengthUpdatedAtMs: Long = 0L,
    val networkRequestCount: Long = 0L,
    val networkFailureCount: Long = 0L,
    val networkCancelledCount: Long = 0L,
    val network429Count: Long = 0L,
    val network5xxCount: Long = 0L,
    val lastNetworkError: String? = null
)

class GmkViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    private val historyStore = HistoryStore(app)
    private val repository = MarketRepository(prefs)
    private val outcomeRepository = MarketRepository(prefs)
    private val ruleEngine = LocalRuleEngine()
    private val oneMinuteEngine = OneMinuteLocalEngine()
    private val jst = ZoneId.of("Asia/Tokyo")

    private val _state = MutableStateFlow(
        GmkUiState(
            history = emptyList(),
            autoScan = prefs.autoScan,
            oneMinuteAutoScan = prefs.oneMinuteAutoScan,
            cutInEnabled = prefs.cutInEnabled,
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = prefs.yahooFallback,
            batteryOptimizationExempt = isBatteryOptimizationExempt(app),
            backgroundRestricted = isBackgroundRestricted(app)
        )
    )
    val state: StateFlow<GmkUiState> = _state

    private var rateJob: Job? = null
    private var autoJob: Job? = null
    private var oneMinuteAutoJob: Job? = null
    private var oneMinuteJob: Job? = null
    private var outcomeRecoveryJob: Job? = null
    private var chartJob: Job? = null
    private var strengthJob: Job? = null
    private val outcomeJobs = mutableMapOf<String, Job>()
    private val outcomeUnexpectedRetryCounts = mutableMapOf<String, Int>()
    private val outcomeCaptureSemaphore = Semaphore(2)
    private val MAX_OUTCOME_TRACKING_JOBS = 8
    private var lastAutoBoundaryKey: String? = prefs.lastAutoBoundaryKey.takeIf { it.isNotBlank() }
    private var lastOneMinuteBoundaryKey: String? = prefs.lastOneMinuteBoundaryKey.takeIf { it.isNotBlank() }
    private var lastSchedulerTickMs: Long = 0L
    private var lastSchedulerElapsedMs: Long = 0L
    private var lastOneMinuteSchedulerTickMs: Long = 0L
    private var lastOneMinuteSchedulerElapsedMs: Long = 0L
    @Volatile private var historyInitialized: Boolean = false

    private fun isBatteryOptimizationExempt(app: Application): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) return true
        val pm = app.getSystemService(android.os.PowerManager::class.java)
        return pm?.isIgnoringBatteryOptimizations(app.packageName) == true
    }

    private fun isBackgroundRestricted(app: Application): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.P) return false
        val am = app.getSystemService(android.app.ActivityManager::class.java)
        return am?.isBackgroundRestricted == true
    }

    fun refreshDevicePowerState() {
        val app = getApplication<Application>()
        _state.value = _state.value.copy(
            batteryOptimizationExempt = isBatteryOptimizationExempt(app),
            backgroundRestricted = isBackgroundRestricted(app)
        )
    }

    init {
        startRateLoop()
        // Start the foreground runtime immediately only when AUTO itself requires it.
        // Pending manual outcomes are discovered from history below and then keep the service alive.
        syncForegroundRuntimeService()

        // Large history JSON must never be parsed on Activity/Service main thread.
        // AUTO schedulers are intentionally started only after recovery finishes so a boot/process
        // restore cannot publish a new trade before dedup/pending state has been reconstructed.
        viewModelScope.launch(Dispatchers.IO) {
            var loaded = historyStore.load()

            // AUTO and 1m use exact minute OPEN, so a transient provider outage can be repaired
            // after restart. Reopen only recent misses; arbitrary-second MANUAL 3m is intentionally
            // excluded because its original quote cannot be reconstructed from M1 history.
            val now = ZonedDateTime.now(jst)
            loaded.asSequence()
                .filter { it.decision == "ENTRY" && it.source != "MANUAL" }
                .filter { it.resultStatus in setOf("ENTRY_RATE_MISSED", "JUDGE_RATE_MISSED") }
                .filter { row ->
                    val judge = runCatching { ZonedDateTime.parse(row.judgeTimeJst) }.getOrNull()
                    judge != null && !judge.isAfter(now) &&
                        java.time.Duration.between(judge, now).toHours() <= 24L
                }
                .take(32)
                .forEach { historyStore.reopenMinuteAlignedMissForRecovery(it.scanId) }

            loaded = historyStore.load()
            val pending = loaded.filter {
                it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
            }
            withContext(Dispatchers.Main.immediate) {
                _state.value = _state.value.copy(history = loaded)
                historyInitialized = true
                resumePendingOutcomes(pending)
                startAutoLoop()
                startOneMinuteAutoLoop()
                syncForegroundRuntimeService()
            }
        }
    }

    private fun allRatesAvailable(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rows.all { it.price != null }

    private fun rateLiveCount(rows: List<RateRow>): Int =
        rows.count { it.price != null && it.freshnessStatus == "LIVE" }

    private fun allFresh(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rateLiveCount(rows) == 6

    private fun rateSummary(rows: List<RateRow>): String? {
        if (rows.isEmpty()) return "レート取得待機中"
        val missing = rows.filter { it.price == null }.map { it.instrument }
        val last = rows.filter { it.price != null && it.freshnessStatus != "LIVE" }.map { it.instrument }
        return when {
            missing.isNotEmpty() -> "未取得: ${missing.joinToString(",")}"
            last.isNotEmpty() -> "LIVE ${rateLiveCount(rows)}/6 / LAST: ${last.joinToString(",")}"
            else -> null
        }
    }

    private fun refreshNetworkDiagnosticState() {
        val market = repository.diagnosticStats()
        val outcomes = outcomeRepository.diagnosticStats()
        val marketError = market.optString("last_error").takeIf { it.isNotBlank() && it != "null" }
        val outcomeError = outcomes.optString("last_error").takeIf { it.isNotBlank() && it != "null" }
        _state.value = _state.value.copy(
            networkRequestCount = market.optLong("requests") + outcomes.optLong("requests"),
            networkFailureCount = market.optLong("failure") + outcomes.optLong("failure"),
            networkCancelledCount = market.optLong("cancelled") + outcomes.optLong("cancelled"),
            network429Count = market.optLong("http_429") + outcomes.optLong("http_429"),
            network5xxCount = market.optLong("http_5xx") + outcomes.optLong("http_5xx"),
            lastNetworkError = marketError ?: outcomeError
        )
    }

    private fun mergeRates(previous: List<RateRow>, incoming: List<RateRow>, elapsedSeconds: Double): List<RateRow> {
        val old = previous.associateBy { it.instrument }

        fun effectiveAge(r: RateRow): Double =
            r.ageSeconds ?: Double.MAX_VALUE

        return incoming.map { candidate ->
            val cached = old[candidate.instrument]

            if (cached?.price == null) {
                candidate.copy(fetchAgeSeconds = if (candidate.price != null) 0.0 else candidate.fetchAgeSeconds)
            } else if (candidate.price == null) {
                cached.copy(
                    ageSeconds = effectiveAge(cached) + elapsedSeconds.coerceAtLeast(0.0),
                    fetchAgeSeconds = (cached.fetchAgeSeconds ?: 0.0) + elapsedSeconds.coerceAtLeast(0.0),
                    freshnessStatus = "LAST",
                    source = "${cached.source.removeSuffix(" cache")} cache"
                )
            } else {
                val cachedAdvancedAge = effectiveAge(cached) + elapsedSeconds.coerceAtLeast(0.0)

                val chooseIncoming = when {
                    candidate.freshnessStatus == "LIVE" && cached.freshnessStatus != "LIVE" -> true
                    candidate.freshnessStatus != "LIVE" && cached.freshnessStatus == "LIVE" &&
                        cachedAdvancedAge <= 20.0 -> false
                    else -> effectiveAge(candidate) <= cachedAdvancedAge
                }

                if (chooseIncoming) {
                    candidate.copy(fetchAgeSeconds = 0.0)
                } else {
                    cached.copy(
                        ageSeconds = cachedAdvancedAge,
                        fetchAgeSeconds = (cached.fetchAgeSeconds ?: 0.0) + elapsedSeconds.coerceAtLeast(0.0),
                        freshnessStatus = if (cachedAdvancedAge <= 20.0 && cached.freshnessStatus == "LIVE") "LIVE" else "LAST",
                        source = "${cached.source.removeSuffix(" cache")} cache"
                    )
                }
            }
        }
    }

    private fun millisUntilNextOneMinuteT10(now: ZonedDateTime = ZonedDateTime.now(jst)): Long {
        var candidate = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        if (!candidate.isAfter(now)) candidate = candidate.plusMinutes(1)
        return java.time.Duration.between(now, candidate).toMillis()
    }

    private fun shouldReserveYahooForUpcomingAuto(now: ZonedDateTime = ZonedDateTime.now(jst)): Boolean {
        // A normal quote refresh may occupy Yahoo slots for several seconds. Reserve the final
        // 10 seconds before T-10 AND the active :50-:54 window itself. At exactly :50.000,
        // "next T-10" already points to the following slot, so the explicit current-window
        // check prevents a race where live polling starts just before AUTO sets busy=true.
        val inCurrentThreeMinuteWindow = prefs.autoScan && now.minute % 5 == 4 && now.second in 40..54
        val inCurrentOneMinuteWindow = prefs.oneMinuteAutoScan && now.second in 40..54
        val threeMinuteSoon = prefs.autoScan && millisUntilNextAutoT10(now) in 0L..10_000L
        val oneMinuteSoon = prefs.oneMinuteAutoScan && millisUntilNextOneMinuteT10(now) in 0L..10_000L
        return inCurrentThreeMinuteWindow || inCurrentOneMinuteWindow || threeMinuteSoon || oneMinuteSoon
    }

    private fun pauseAuxiliaryMarketRequestsForScan() {
        val chartWasActive = chartJob?.isActive == true
        val strengthWasActive = strengthJob?.isActive == true
        chartJob?.cancel()
        strengthJob?.cancel()
        if (chartWasActive || strengthWasActive) {
            val s = _state.value
            _state.value = s.copy(
                chartLoading = if (chartWasActive) false else s.chartLoading,
                chartError = if (chartWasActive) "スキャンを優先して更新を一時停止" else s.chartError,
                strengthLoading = if (strengthWasActive) false else s.strengthLoading,
                strengthErrors = if (strengthWasActive) mapOf("sync" to "スキャンを優先して更新を一時停止") else s.strengthErrors
            )
        }
    }

    private fun startRateLoop() {
        rateJob?.cancel()
        rateJob = viewModelScope.launch {
            while (isActive) {
                if (_state.value.busy || _state.value.oneMinuteBusy || shouldReserveYahooForUpcomingAuto()) {
                    // Scans (and the short pre-T10 reservation window) own the network window, but
                    // displayed rate age must keep moving. This prevents a 6-second quote refresh
                    // started just before T-10 from starving the time-critical candle acquisition.
                    // Otherwise stale cached quotes look permanently 1-2 seconds old while a scan is busy.
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    if (elapsed > 0.0 && s.rates.isNotEmpty()) {
                        val aged = s.rates.map { r ->
                            if (r.price == null) r.copy(freshnessStatus = "UNAVAILABLE") else {
                                val age = (r.ageSeconds ?: 0.0) + elapsed
                                r.copy(
                                    ageSeconds = age,
                                    fetchAgeSeconds = (r.fetchAgeSeconds ?: 0.0) + elapsed,
                                    freshnessStatus = if (age <= 20.0 && r.freshnessStatus == "LIVE") "LIVE" else "LAST",
                                    source = if (age > 20.0) "${r.source.removeSuffix(" cache")} cache" else r.source
                                )
                            }
                        }
                        _state.value = s.copy(
                            rates = aged,
                            connected = allFresh(aged),
                            rateLiveCount = rateLiveCount(aged),
                            rateAvailableCount = aged.count { it.price != null },
                            rateStatus = rateSummary(aged),
                            lastRateUpdateMs = nowMs
                        )
                    }
                    delay(250)
                    continue
                }

                try {
                    val before = _state.value
                    val attemptStartedMs = System.currentTimeMillis()
                    val elapsed = if (before.lastRateUpdateMs > 0L) {
                        (attemptStartedMs - before.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0

                    val incoming = withTimeout(10_000) { repository.fetchRates() }
                    val completedMs = System.currentTimeMillis()
                    // Include the network call duration when aging cached quotes. Otherwise a
                    // partial/slow refresh can make cached values appear several seconds younger.
                    val mergeElapsed = if (before.lastRateUpdateMs > 0L) {
                        (completedMs - before.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else elapsed
                    val rows = mergeRates(before.rates, incoming, mergeElapsed)
                    val providerReturnedFullLive = incoming.size >= 6 && incoming.all { it.price != null && it.freshnessStatus == "LIVE" }

                    _state.value = _state.value.copy(
                        rates = rows,
                        connected = allFresh(rows),
                        rateLiveCount = rateLiveCount(rows),
                        rateAvailableCount = rows.count { it.price != null },
                        rateStatus = rateSummary(rows),
                        lastRateUpdateMs = completedMs,
                        lastRateSuccessMs = if (providerReturnedFullLive) completedMs else before.lastRateSuccessMs
                    )
                    refreshNetworkDiagnosticState()
                } catch (te: TimeoutCancellationException) {
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    val cached = s.rates.map { r ->
                        if (r.price != null) {
                            r.copy(
                                ageSeconds = (r.ageSeconds ?: 0.0) + elapsed,
                                fetchAgeSeconds = (r.fetchAgeSeconds ?: 0.0) + elapsed,
                                freshnessStatus = "LAST",
                                source = "${r.source.removeSuffix(" cache")} cache"
                            )
                        } else r.copy(freshnessStatus = "UNAVAILABLE")
                    }
                    _state.value = s.copy(
                        connected = false,
                        rates = cached,
                        rateLiveCount = 0,
                        rateAvailableCount = cached.count { it.price != null },
                        rateStatus = "レート再取得タイムアウト（表示値はキャッシュ）",
                        lastRateUpdateMs = nowMs
                    )
                    refreshNetworkDiagnosticState()
                } catch (ce: CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    val cached = s.rates.map { r ->
                        if (r.price != null) {
                            r.copy(
                                ageSeconds = (r.ageSeconds ?: 0.0) + elapsed,
                                fetchAgeSeconds = (r.fetchAgeSeconds ?: 0.0) + elapsed,
                                freshnessStatus = "LAST",
                                source = "${r.source.removeSuffix(" cache")} cache"
                            )
                        } else r.copy(freshnessStatus = "UNAVAILABLE")
                    }
                    _state.value = s.copy(
                        connected = false,
                        rates = cached,
                        rateLiveCount = 0,
                        rateAvailableCount = cached.count { it.price != null },
                        rateStatus = "レート再取得失敗（表示値はキャッシュ）: ${e.message}",
                        lastRateUpdateMs = nowMs
                    )
                    refreshNetworkDiagnosticState()
                }
                delay(6_000)
            }
        }
    }

    private fun latestScheduledT10AtOrBefore(now: ZonedDateTime): ZonedDateTime {
        var m = now.truncatedTo(ChronoUnit.MINUTES)
        while (m.minute % 5 != 4) m = m.minusMinutes(1)
        return m.withSecond(50).withNano(0)
    }

    private fun latestOneMinuteT10AtOrBefore(now: ZonedDateTime): ZonedDateTime {
        var t = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        if (t.isAfter(now)) t = t.minusMinutes(1)
        return t
    }

    private fun isExpectedFxWeekendGap(aMs: Long, bMs: Long): Boolean {
        if (aMs <= 0L || bMs <= aMs) return false
        val gapMs = bMs - aMs
        if (gapMs < 24L * 60L * 60L * 1000L) return false

        val a = java.time.Instant.ofEpochMilli(aMs).atZone(java.time.ZoneOffset.UTC)
        val b = java.time.Instant.ofEpochMilli(bMs).atZone(java.time.ZoneOffset.UTC)

        val olderOk = a.dayOfWeek == java.time.DayOfWeek.FRIDAY
        val newerOk = b.dayOfWeek == java.time.DayOfWeek.SUNDAY ||
            b.dayOfWeek == java.time.DayOfWeek.MONDAY

        return olderOk && newerOk && gapMs <= 80L * 60L * 60L * 1000L
    }

    private fun isKnownEntryContractGrade(grade: String): Boolean {
        return grade.uppercase() in setOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I")
    }

    private fun startAutoLoop() {
        autoJob?.cancel()
        // A preference toggle/restart is not a device sleep. Reset the monotonic baseline
        // so time spent with AUTO disabled can never generate a false MISSED event.
        lastSchedulerTickMs = 0L
        lastSchedulerElapsedMs = 0L
        autoJob = viewModelScope.launch {
            while (isActive) {
                if (!historyInitialized) {
                    delay(100)
                    continue
                }
                val now = ZonedDateTime.now(jst)
                val nowMs = System.currentTimeMillis()
                val elapsedNow = android.os.SystemClock.elapsedRealtime()

                if (prefs.autoScan) {
                    // Use monotonic elapsed time so manual clock/NTP changes do not create a false MISSED.
                    if (lastSchedulerTickMs > 0L &&
                        lastSchedulerElapsedMs > 0L &&
                        elapsedNow - lastSchedulerElapsedMs > 1_500L) {
                        val previousTick = java.time.Instant.ofEpochMilli(lastSchedulerTickMs).atZone(jst)
                        val scheduled = latestScheduledT10AtOrBefore(now)

                        if (scheduled.isAfter(previousTick) && !now.isBefore(scheduled.plusSeconds(5))) {
                            val boundary = scheduled.plusSeconds(10).truncatedTo(ChronoUnit.MINUTES)
                            val key = boundary.toLocalDateTime().toString()

                            if (boundary.hour in 9..22 && lastAutoBoundaryKey != key && prefs.claimThreeMinuteBoundary(key)) {
                                prefs.completeThreeMinuteBoundary(key)
                                lastAutoBoundaryKey = key
                                _state.value = _state.value.copy(
                                    scan = null,
                                    scanStatus = "AUTO_SCAN_MISSED: 端末スリープ/停止中にT-10有効ウィンドウを通過"
                                )
                            }
                        }
                    }

                    val inSlotWindow = now.minute % 5 == 4 && now.second in 50..54

                    if (inSlotWindow) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        if (boundary.hour !in 9..22) {
                            _state.value = _state.value.copy(
                                scanStatus = "AUTO待機: 本番時間外 (09:00-23:00)"
                            )
                            delay(100)
                            continue
                        }
                        val key = boundary.toLocalDateTime().toString()

                        if (lastAutoBoundaryKey != key) {
                            if (!_state.value.busy) {
                                // Do not consume the boundary while another operation is still winding down.
                                // Keep retrying throughout the valid :50-:54 window.
                                if (_state.value.oneMinuteBusy) {
                                    oneMinuteJob?.cancelAndJoin()
                                    _state.value = _state.value.copy(
                                        oneMinuteBusy = false,
                                        oneMinuteStatus = "1分手動停止: 3分AUTO T-10を優先"
                                    )
                                }
                                if (prefs.claimThreeMinuteBoundary(key)) {
                                    val beforeSuccessMs = _state.value.lastScanSuccessMs
                                    performScan("AUTO", boundary, null)
                                    val published = _state.value.lastScanSuccessMs > beforeSuccessMs
                                    val after = ZonedDateTime.now(jst)
                                    if (published) {
                                        prefs.completeThreeMinuteBoundary(key)
                                        lastAutoBoundaryKey = key
                                    } else if (after.isBefore(boundary) && after.second <= 54) {
                                        // Data/provider failure inside the valid window: release the short lease
                                        // so the same boundary can retry before :55.
                                        prefs.releaseThreeMinuteBoundary(key)
                                    } else {
                                        prefs.completeThreeMinuteBoundary(key)
                                        lastAutoBoundaryKey = key
                                    }
                                }
                            } else {
                                _state.value = _state.value.copy(
                                    scanStatus = "AUTO待機: T-10有効ウィンドウ内で実行中処理の終了待ち"
                                )
                            }
                        }
                    } else if (now.minute % 5 == 4 && now.second in 55..59) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()
                        if (boundary.hour in 9..22 && lastAutoBoundaryKey != key && prefs.claimThreeMinuteBoundary(key)) {
                            prefs.completeThreeMinuteBoundary(key)
                            lastAutoBoundaryKey = key
                            _state.value = _state.value.copy(
                                scan = null,
                                scanStatus = "AUTO_SCAN_MISSED: T-10有効ウィンドウ内に開始できませんでした"
                            )
                        }
                    }
                }

                // Use the actual end-of-iteration clocks. performScan() may suspend for
                // several seconds; counting its own work as scheduler sleep creates false gap alarms.
                lastSchedulerTickMs = System.currentTimeMillis()
                lastSchedulerElapsedMs = android.os.SystemClock.elapsedRealtime()
                delay(100)
            }
        }
    }

    private fun millisUntilNextAutoT10(now: ZonedDateTime = ZonedDateTime.now(jst)): Long {
        var candidate = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        while (candidate.minute % 5 != 4 || !candidate.isAfter(now)) {
            candidate = candidate.plusMinutes(1).withSecond(50).withNano(0)
        }
        return java.time.Duration.between(now, candidate).toMillis()
    }

    fun manualScan() {
        if (!historyInitialized) {
            _state.value = _state.value.copy(scanStatus = "手動スキャン待機: 履歴/結果追跡を復旧中")
            return
        }
        if (_state.value.busy) return
        val now = ZonedDateTime.now(jst)
        val manualEntryTarget = now.plusSeconds(10)
        if (manualEntryTarget.hour !in 9..22) {
            _state.value = _state.value.copy(scanStatus = "3分手動見送り: ENTRY時刻が本番時間外 (09:00-23:00)")
            return
        }
        if (_state.value.oneMinuteBusy) {
            _state.value = _state.value.copy(scanStatus = "3分手動待機: 1分手動スキャン中")
            return
        }

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..20_000L) {
                _state.value = _state.value.copy(
                    scanStatus = "手動スキャン待機: AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        viewModelScope.launch { performScan("MANUAL", null, manualEntryTarget) }
    }

    fun manualOneMinuteScan() {
        if (!historyInitialized) {
            _state.value = _state.value.copy(oneMinuteStatus = "1分手動待機: 履歴/結果追跡を復旧中")
            return
        }
        if (_state.value.oneMinuteBusy || _state.value.busy) return
        val now = ZonedDateTime.now(jst)
        val oneMinuteEntryTarget = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
        if (oneMinuteEntryTarget.hour !in 9..22) {
            _state.value = _state.value.copy(oneMinuteStatus = "1分手動見送り: ENTRY時刻が本番時間外 (09:00-23:00)")
            return
        }

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..15_000L) {
                _state.value = _state.value.copy(
                    oneMinuteStatus = "1分手動待機: 3分AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        startOneMinuteScan("MANUAL_1M", oneMinuteEntryTarget)
    }

    private fun startOneMinuteAutoLoop() {
        oneMinuteAutoJob?.cancel()
        lastOneMinuteSchedulerTickMs = 0L
        lastOneMinuteSchedulerElapsedMs = 0L
        oneMinuteAutoJob = viewModelScope.launch {
            while (isActive) {
                if (!historyInitialized) {
                    delay(100)
                    continue
                }
                val now = ZonedDateTime.now(jst)
                val nowMs = System.currentTimeMillis()
                val elapsedNow = android.os.SystemClock.elapsedRealtime()
                if (prefs.oneMinuteAutoScan) {
                    // Detect a real scheduler suspension that skipped the whole :50-:54 window.
                    // Do not count the 3m-reserved minute as a 1m miss when 3m AUTO is enabled.
                    if (lastOneMinuteSchedulerTickMs > 0L && lastOneMinuteSchedulerElapsedMs > 0L &&
                        elapsedNow - lastOneMinuteSchedulerElapsedMs > 1_500L) {
                        val previousTick = java.time.Instant.ofEpochMilli(lastOneMinuteSchedulerTickMs).atZone(jst)
                        val scheduled = latestOneMinuteT10AtOrBefore(now)
                        val reservedFor3m = prefs.autoScan && scheduled.minute % 5 == 4
                        if (!reservedFor3m && scheduled.isAfter(previousTick) && !now.isBefore(scheduled.plusSeconds(5))) {
                            val boundary = scheduled.plusSeconds(10).truncatedTo(ChronoUnit.MINUTES)
                            val key = boundary.toLocalDateTime().toString()
                            if (boundary.hour in 9..22 && lastOneMinuteBoundaryKey != key && prefs.claimOneMinuteBoundary(key)) {
                                prefs.completeOneMinuteBoundary(key)
                                lastOneMinuteBoundaryKey = key
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = "1分AUTO_MISSED: 端末スリープ/停止中にT-10有効ウィンドウを通過"
                                )
                            }
                        }
                    }

                    // Operating hours are enforced on the ENTRY boundary, not the current
                    // scan clock. This allows the valid 08:59:50 -> 09:00:00 first entry while
                    // still blocking 22:59:50 -> 23:00:00.

                    // 3m AUTO uses the same :50 at minutes 4/9/14/... and always has priority.
                    val isThreeMinuteAutoMinute = prefs.autoScan && now.minute % 5 == 4
                    val inWindow = now.second in 50..54

                    if (inWindow && !isThreeMinuteAutoMinute) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()

                        if (lastOneMinuteBoundaryKey != key) {
                            if (boundary.hour !in 9..22) {
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = "1分AUTO見送り: ENTRY時刻が本番時間外 (09:00-23:00)"
                                )
                            } else if (!_state.value.busy && !_state.value.oneMinuteBusy) {
                                // Claim only when the scan can actually start. Completion is recorded
                                // only after a result is published; failed attempts release the lease
                                // while the :50-:54 retry window is still open.
                                if (prefs.claimOneMinuteBoundary(key)) {
                                    startOneMinuteScan("AUTO_1M", boundary)
                                }
                            } else {
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = "1分AUTO待機: T-10有効ウィンドウ内で実行中処理の終了待ち"
                                )
                            }
                        }
                    } else if (!isThreeMinuteAutoMinute && now.second in 55..59) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()
                        if (boundary.hour in 9..22 && lastOneMinuteBoundaryKey != key && prefs.claimOneMinuteBoundary(key)) {
                            prefs.completeOneMinuteBoundary(key)
                            lastOneMinuteBoundaryKey = key
                            _state.value = _state.value.copy(
                                oneMinuteStatus = "1分AUTO_MISSED: T-10有効ウィンドウ内に開始できませんでした"
                            )
                        }
                    }
                }
                lastOneMinuteSchedulerTickMs = nowMs
                lastOneMinuteSchedulerElapsedMs = elapsedNow
                delay(100)
            }
        }
    }

    private fun startOneMinuteScan(source: String, requestedEntryTarget: ZonedDateTime? = null) {
        if (_state.value.oneMinuteBusy || _state.value.busy) return

        oneMinuteJob?.cancel()
        oneMinuteJob = viewModelScope.launch {
            val autoBoundaryKey = if (source == "AUTO_1M" && requestedEntryTarget != null) {
                requestedEntryTarget.toLocalDateTime().toString()
            } else null
            var published = false

            _state.value = _state.value.copy(
                oneMinuteBusy = true,
                oneMinuteScan = null,
                oneMinuteStatus = "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}: 6通貨Context取得中"
            )
            pauseAuxiliaryMarketRequestsForScan()

            // Do not cancel shared rate requests here. Scan traffic and live-rate polling
            // must not abort each other; cancellation is reserved for runtime shutdown.

            try {
                val now = ZonedDateTime.now(jst)
                val entry = (requestedEntryTarget ?: now.plusMinutes(1)).truncatedTo(ChronoUnit.MINUTES)
                if (entry.hour !in 9..22) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分見送り: ENTRY時刻が本番時間外 (09:00-23:00)"
                    )
                    return@launch
                }
                val remainingMs = java.time.Duration.between(now, entry).toMillis()

                if (remainingMs < 2_500L) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 次1分枠まで${remainingMs.coerceAtLeast(0L)}ms"
                    )
                    return@launch
                }

                val fetchBudget = minOf(8_000L, (remainingMs - 1_000L).coerceAtLeast(1_500L))
                val batch = withTimeout(fetchBudget) { repository.fetchAllCandles() }

                val required = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
                val eligible = linkedMapOf<String, List<Candle>>()
                val errors = linkedMapOf<String, String>()
                val nowMs = System.currentTimeMillis()

                required.forEach { ins ->
                    val rows = batch.candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                    val fetchError = batch.errors[ins]
                    val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                    val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE
                    val expectedLastStartMs = ((nowMs / 60_000L) * 60_000L) - 60_000L
                    val latestLagMs = if (last > 0L) (expectedLastStartMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                    val tail15 = rows.takeLast(15)
                    val gaps = tail15.zipWithNext { a, b -> b.timeEpochMs - a.timeEpochMs }
                    val maxGapMs = gaps.maxOrNull() ?: 0L
                    val spanMs = if (tail15.size >= 2) {
                        tail15.last().timeEpochMs - tail15.first().timeEpochMs
                    } else Long.MAX_VALUE

                    when {
                        fetchError != null -> errors[ins] = "取得失敗: $fetchError"
                        rows.size < 15 -> errors[ins] = "1分足不足 ${rows.size}/15"
                        last <= 0L || latestLagMs > 5_000L ->
                            errors[ins] = "直近完成1分足欠損 lag=${if (latestLagMs == Long.MAX_VALUE) "不明" else "${latestLagMs / 1000}s"}"
                        ageMs > 180_000L ->
                            errors[ins] = "1分足STALE ${ageMs / 1000}s"
                        maxGapMs > 90_000L ->
                            errors[ins] = "1分足不連続 gap=${maxGapMs / 1000L}s"
                        spanMs > 16L * 60_000L ->
                            errors[ins] = "1分足不連続 span=${spanMs / 60_000L}m"
                        else -> eligible[ins] = rows
                    }
                }

                if (eligible.size != 6) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 6/6必須 / " +
                            errors.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                    )
                    return@launch
                }

                val latestTimes = eligible.mapValues { (_, rows) -> rows.last().timeEpochMs }
                val latestSpreadMs = (latestTimes.values.maxOrNull() ?: 0L) -
                    (latestTimes.values.minOrNull() ?: 0L)

                if (latestSpreadMs > 90_000L) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 6通貨M1時刻ずれ ${latestSpreadMs / 1000L}s"
                    )
                    return@launch
                }

                val decisionNow = ZonedDateTime.now(jst)
                if (!decisionNow.isBefore(entry)) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 次1分枠開始後"
                    )
                    return@launch
                }

                val raw = withContext(Dispatchers.Default) {
                    oneMinuteEngine.scan(eligible, now, entry)
                }
                val result = raw.copy(source = source)

                if (result.candidates.size != 6 || result.top1 == null) {
                    error("1分候補数異常 ${result.candidates.size}/6")
                }

                val topGuarded = result.top1?.reasons?.any {
                    it.startsWith("1M_TREND_SWITCH_GUARD")
                } == true

                if (topGuarded) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: TOP1がトレンド切替逆方向"
                    )
                    return@launch
                }

                if (!ZonedDateTime.now(jst).isBefore(entry)) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 判定完了が次枠開始後"
                    )
                    return@launch
                }

                val top = result.top1!!
                val historyResult = ScanResult(
                    scanId = result.scanId,
                    atJst = result.atJst,
                    entryTimeJst = result.entryTimeJst,
                    judgeTimeJst = result.judgeTimeJst,
                    candidates = listOf(
                        ScanCandidate(
                            rank = 1,
                            instrument = top.instrument,
                            display = top.instrument,
                            direction = top.direction,
                            grade = when {
                                top.confidence >= 0.75 -> "S"
                                top.confidence >= 0.65 -> "A"
                                top.confidence >= 0.58 -> "B"
                                top.confidence >= 0.53 -> "C"
                                else -> "E"
                            },
                            probability = top.confidence,
                            decision = if (top.confidence >= 0.53) "ENTRY" else "SKIP",
                            score = top.score,
                            regime = top.regime,
                            regimeConfidence = top.confidence,
                            reasons = top.reasons
                        )
                    ),
                    warnings = emptyList(),
                    source = source
                )

                historyStore.add(historyResult)
                scheduleOutcomeTracking(historyResult)

                val topDecision = historyResult.top1?.decision ?: "SKIP"
                val topGrade = historyResult.top1?.grade ?: "E"
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteScan = result,
                    history = historyStore.load(),
                    oneMinuteStatus = if (topDecision == "ENTRY") {
                        "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}完了: ${top.instrument} ${top.direction} / $topGrade / 1分後判定"
                    } else {
                        "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}見送り: ${top.instrument} / $topGrade / 53%未満"
                    }
                )
                published = true
            } catch (e: TimeoutCancellationException) {
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = "1分技術見送り: 市場Contextタイムアウト"
                )
            } catch (ce: CancellationException) {
                val current = _state.value.oneMinuteStatus
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = if (current?.contains("3分AUTO T-10を優先") == true) current else "1分スキャン停止"
                )
                throw ce
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = "1分スキャン失敗: ${e.message}"
                )
            } finally {
                if (autoBoundaryKey != null && requestedEntryTarget != null) {
                    val after = ZonedDateTime.now(jst)
                    if (published) {
                        prefs.completeOneMinuteBoundary(autoBoundaryKey)
                        lastOneMinuteBoundaryKey = autoBoundaryKey
                    } else if (after.isBefore(requestedEntryTarget) && after.second <= 54) {
                        prefs.releaseOneMinuteBoundary(autoBoundaryKey)
                    } else {
                        prefs.completeOneMinuteBoundary(autoBoundaryKey)
                        lastOneMinuteBoundaryKey = autoBoundaryKey
                    }
                }
            }
        }
    }

    private suspend fun performScan(source: String, autoBoundary: ZonedDateTime?, manualEntryOverride: ZonedDateTime? = null) {
        val scanStarted = ZonedDateTime.now(jst)
        val manualEntryTarget = manualEntryOverride ?: scanStarted.plusSeconds(10)
        if (source == "MANUAL" && manualEntryTarget.hour !in 9..22) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "3分手動見送り: ENTRY時刻が本番時間外 (09:00-23:00)"
            )
            return
        }

        // Raise the scan lock first so the rate loop cannot start a new request
        // between cancelAll() and the beginning of candle acquisition.
        _state.value = _state.value.copy(
            busy = true,
            scan = null,
            scannableCount = 0,
            lastScanExcluded = emptyMap(),
            lastCandleErrors = emptyMap(),
            lastCandleLatestMs = emptyMap(),
            quoteCandleDivergencePct = emptyMap(),
            lastScanAttemptMs = System.currentTimeMillis(),
            scanStatus = if (source == "AUTO") "AUTOスキャン実行中" else "手動スキャン実行中",
            error = null
        )
        pauseAuxiliaryMarketRequestsForScan()

        // Do not cancel shared live-rate requests when a scan starts. The old cancelAll()
        // caused periodic LIVE-rate dropouts exactly when AUTO scans were active.

        try {
            val batch = if (source == "AUTO") {
                // AUTO starts at T-10. Do not let slow network publish after entry time.
                withTimeout(8_500) { repository.fetchAllCandles() }
            } else {
                // MANUAL entry is scan-start +10s. Data acquisition must finish before that.
                val remainingToEntry = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (remainingToEntry <= 1_200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scanStatus = "手動技術見送り: +10秒ENTRYまで時間不足"
                    )
                    return
                }
                withTimeout(minOf(8_000L, (remainingToEntry - 700L).coerceAtLeast(1_000L))) {
                    repository.fetchAllCandles()
                }
            }

            val candles = batch.candles
            val required = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
            val nowMs = System.currentTimeMillis()
            val latestTimes = required.associateWith { ins ->
                candles[ins].orEmpty().maxOfOrNull { it.timeEpochMs } ?: 0L
            }

            val excluded = linkedMapOf<String, String>()
            val eligible = linkedMapOf<String, List<Candle>>()

            required.forEach { ins ->
                val rows = candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                val fetchError = batch.errors[ins]

                when {
                    fetchError != null -> excluded[ins] = "取得失敗: $fetchError"
                    rows.size < 21 -> excluded[ins] = "1分足不足 ${rows.size}/21"
                    else -> {
                        val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                        val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE
                        val expectedLastStartMs = ((nowMs / 60_000L) * 60_000L) - 60_000L
                        val latestLagMs = if (last > 0L) (expectedLastStartMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                        // Timestamp is the beginning of the completed M1 candle.
                        // 240s keeps short provider delays usable without accepting closed-market history.
                        val tail = rows.takeLast(30)
                        val gapPairs = tail.zipWithNext { a, b -> Triple(a.timeEpochMs, b.timeEpochMs, b.timeEpochMs - a.timeEpochMs) }
                        val unexpectedGaps = gapPairs.filter { (a, b, gap) ->
                            gap > 90_000L &&
                                !(ins != "BTCJPY" && isExpectedFxWeekendGap(a, b))
                        }
                        val spanMs = if (tail.size >= 2) tail.last().timeEpochMs - tail.first().timeEpochMs else Long.MAX_VALUE
                        val hasWeekendBridge = gapPairs.any { (a, b, gap) ->
                            gap > 90_000L && ins != "BTCJPY" && isExpectedFxWeekendGap(a, b)
                        }

                        when {
                            last <= 0L || latestLagMs > 5_000L ->
                                excluded[ins] = "直近完成1分足欠損 lag=${if (latestLagMs == Long.MAX_VALUE) "不明" else "${latestLagMs / 1000}s"}"
                            ageMs > 240_000L ->
                                excluded[ins] = "1分足STALE ${ageMs / 1000}s"
                            unexpectedGaps.isNotEmpty() ->
                                excluded[ins] = "1分足不連続 gap=${unexpectedGaps.maxOf { it.third } / 1000L}s"
                            !hasWeekendBridge && tail.size >= 30 && spanMs > 45L * 60_000L ->
                                excluded[ins] = "1分足欠損多発 span=${spanMs / 60_000L}m"
                            else -> eligible[ins] = rows
                        }
                    }
                }
            }

            val liveRates = _state.value.rates.associateBy { it.instrument }
            val divergence = linkedMapOf<String, Double>()
            eligible.forEach { (ins, rows) ->
                val q = liveRates[ins]
                val candleClose = rows.lastOrNull()?.close
                if (q?.price != null && q.freshnessStatus == "LIVE" &&
                    candleClose != null && candleClose > 0.0) {
                    val pct = kotlin.math.abs(q.price - candleClose) / candleClose * 100.0
                    divergence[ins] = pct
                }
            }

            val divergenceWarnings = divergence
                .filter { (ins, pct) -> pct >= if (ins == "BTCJPY") 1.50 else 0.50 }
                .map { (ins, pct) -> "$ins quote/candle乖離 ${"%.3f".format(pct)}%" }

            val divergenceBlocked = divergence.filter { (ins, pct) ->
                pct >= if (ins == "BTCJPY") 1.50 else 0.50
            }.keys
            divergenceBlocked.forEach { ins ->
                eligible.remove(ins)
                excluded[ins] = "quote/candle乖離大: fail-safe SKIP"
            }

            if (eligible.isEmpty()) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = 0,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン待機: " + excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // v0.7.8 production policy was validated by comparing all six instruments.
            // Never choose TOP1 from a partial universe because that changes the ranking distribution.
            if (eligible.size != required.size) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = eligible.size,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン見送り: 6/6必須 (${eligible.size}/6) / " +
                        excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // MANUAL also has a hard publish deadline: scan-start +10 seconds.
            if (source == "MANUAL") {
                val remainingMs = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (remainingMs <= 500L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "手動技術見送り: +10秒ENTRY直前/超過"
                    )
                    return
                }
            }

            // AUTO result must still be ready before the target frame opens.
            if (source == "AUTO" && autoBoundary != null) {
                val remainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (remainingMs <= 400L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 対象枠開始まで${remainingMs.coerceAtLeast(0)}ms"
                    )
                    return
                }
            }

            val entryTarget = if (source == "AUTO") autoBoundary else manualEntryTarget
            val result0 = withContext(Dispatchers.Default) {
                ruleEngine.scan(eligible, source, scanStarted, entryTarget)
            }

            if (source == "AUTO" && autoBoundary != null) {
                val publishRemainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (publishRemainingMs <= 200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 判定完了が対象枠直前/開始後"
                    )
                    return
                }
            }

            if (source == "MANUAL") {
                val publishRemainingMs = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (publishRemainingMs <= 200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "手動技術見送り: 判定完了が+10秒ENTRY直前/超過"
                    )
                    return
                }
            }

            if (result0.candidates.isEmpty()) error("有効候補0件")
            if (result0.candidates.size != eligible.size) {
                error("候補数異常: ${result0.candidates.size}/${eligible.size}")
            }

            val expectedRanks = (1..result0.candidates.size).toSet()
            if (result0.candidates.map { it.rank }.toSet() != expectedRanks) {
                error("順位整合性エラー")
            }

            if (result0.candidates.any { it.direction !in setOf("HIGH", "LOW") }) {
                error("方向値エラー")
            }

            if (result0.candidates.any { !isKnownEntryContractGrade(it.grade) }) {
                error("未知ランク検出")
            }

            if (result0.candidates.any {
                    (it.grade in setOf("D", "E", "F", "G", "H", "I") && it.decision != "SKIP") ||
                    (it.grade !in setOf("D", "E", "F", "G", "H", "I") && it.decision != "ENTRY")
                }) {
                error("ENTRY/SKIP契約違反")
            }

            val coverageWarning = if (excluded.isNotEmpty()) {
                "6/6確認後に除外発生: " + excluded.entries.joinToString(", ") { "${it.key}=${it.value}" }
            } else null

            val result = result0.copy(
                warnings = result0.warnings + listOfNotNull(coverageWarning) + divergenceWarnings
            )

            historyStore.add(result)
            scheduleOutcomeTracking(result)

            _state.value = _state.value.copy(
                busy = false,
                scan = result,
                history = historyStore.load(),
                lastScanSuccessMs = System.currentTimeMillis(),
                scannableCount = eligible.size,
                lastScanExcluded = excluded,
                lastCandleErrors = batch.errors,
                lastCandleLatestMs = latestTimes,
                quoteCandleDivergencePct = divergence,
                scanStatus = coverageWarning ?: "スキャン完了 ${eligible.size}/6",
                error = null
            )
        } catch (e: TimeoutCancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "${source}スキャン失敗: 市場データ取得タイムアウト",
                error = null
            )
        } catch (ce: CancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = if (source == "AUTO") "AUTOスキャン停止" else "スキャン停止",
                error = null
            )
            throw ce
        } catch (e: Exception) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "スキャン失敗: ${e.message}",
                error = null
            )
        }
    }

    private fun scheduleOutcomeTracking(result: ScanResult) {
        val top = result.top1 ?: return
        if (top.decision != "ENTRY") return
        val scanId = result.scanId
        if (scanId.isBlank()) return
        if (outcomeJobs[scanId]?.isActive == true) return

        val job = viewModelScope.launch {
            try {
                val entryTarget = ZonedDateTime.parse(result.entryTimeJst)
                val judgeTarget = ZonedDateTime.parse(result.judgeTimeJst)

                var row = historyStore.load().firstOrNull { it.scanId == scanId } ?: return@launch

                if (row.resultStatus == "WAIT_ENTRY") {
                    delayUntil(entryTarget)
                    val entryRate = fetchOutcomeRateAtTarget(
                        top.instrument, entryTarget, exactMinuteOpen = result.source != "MANUAL"
                    )
                    if (entryRate == null) {
                        historyStore.markEntryMissed(scanId)
                        refreshHistory("結果追跡: ENTRYレート取得失敗/時刻超過")
                        return@launch
                    }

                    historyStore.updateEntryRate(
                        scanId = scanId,
                        rate = entryRate.price,
                        source = entryRate.source,
                        capturedAtJst = entryRate.capturedAtJst,
                        captureDelayMs = entryRate.captureDelayMs,
                        providerAgeSeconds = entryRate.providerAgeSeconds
                    )
                    refreshHistory("結果追跡: ENTRY ${top.instrument} ${formatOutcomeRate(entryRate.price)}")
                    row = historyStore.load().firstOrNull { it.scanId == scanId } ?: return@launch
                }

                if (row.resultStatus != "WAIT_JUDGE") return@launch

                delayUntil(judgeTarget)
                val judgeRate = fetchOutcomeRateAtTarget(
                    top.instrument, judgeTarget, exactMinuteOpen = result.source != "MANUAL"
                )
                if (judgeRate == null) {
                    historyStore.markJudgeMissed(scanId)
                    refreshHistory("結果追跡: 判定レート取得失敗/時刻超過")
                    return@launch
                }

                historyStore.settle(
                    scanId = scanId,
                    judgeRate = judgeRate.price,
                    source = judgeRate.source,
                    settledAtJst = judgeRate.capturedAtJst,
                    captureDelayMs = judgeRate.captureDelayMs,
                    providerAgeSeconds = judgeRate.providerAgeSeconds
                )
                refreshHistory("結果確定: ${top.instrument}")
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                val retry = (outcomeUnexpectedRetryCounts[scanId] ?: 0) + 1
                outcomeUnexpectedRetryCounts[scanId] = retry
                if (retry <= 2) {
                    refreshHistory("結果追跡エラー: ${e.message ?: e::class.java.simpleName} / ${retry}回目・再試行")
                } else {
                    val pendingRow = historyStore.load().firstOrNull { it.scanId == scanId }
                    when (pendingRow?.resultStatus) {
                        "WAIT_ENTRY" -> historyStore.markEntryMissed(scanId, "ENTRY_RATE_MISSED")
                        "WAIT_JUDGE" -> historyStore.markJudgeMissed(scanId, "JUDGE_RATE_MISSED")
                    }
                    outcomeUnexpectedRetryCounts.remove(scanId)
                    refreshHistory("結果追跡エラー: 再試行上限 / ${e.message ?: e::class.java.simpleName}")
                }
            } finally {
                outcomeJobs.remove(scanId)
                val retryCount = outcomeUnexpectedRetryCounts[scanId] ?: 0
                val stillPending = historyStore.load().any {
                    it.scanId == scanId && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
                }
                if (retryCount in 1..2 && stillPending) {
                    viewModelScope.launch {
                        delay(3_000)
                        scheduleOutcomeTracking(result)
                    }
                } else if (!stillPending) {
                    outcomeUnexpectedRetryCounts.remove(scanId)
                }
                syncForegroundRuntimeService()
            }
        }

        outcomeJobs[scanId] = job
        // Manual ENTRYs also need background protection even when both AUTO toggles are OFF.
        syncForegroundRuntimeService()
    }

    private fun resumePendingOutcomes(pendingRows: List<HistoryRow>) {
        outcomeRecoveryJob?.cancel()
        outcomeRecoveryJob = viewModelScope.launch {
            val ordered = pendingRows.sortedBy { row ->
                runCatching { ZonedDateTime.parse(row.judgeTimeJst).toInstant().toEpochMilli() }
                    .getOrDefault(Long.MAX_VALUE)
            }
            for (h in ordered) {
                if (!isActive) break
                if (h.scanId.isBlank() || h.entryTimeJst.isBlank() || h.judgeTimeJst.isBlank()) continue

                // Bound the number of live waiting jobs. Capture concurrency is separately
                // limited to 2, while this cap prevents a corrupt/large backlog from creating
                // thousands of suspended coroutines at process start.
                while (isActive && outcomeJobs.values.count { it.isActive } >= MAX_OUTCOME_TRACKING_JOBS) {
                    delay(250)
                }
                if (!isActive) break

                val synthetic = ScanResult(
                    scanId = h.scanId,
                    atJst = h.atJst,
                    entryTimeJst = h.entryTimeJst,
                    judgeTimeJst = h.judgeTimeJst,
                    candidates = listOf(
                        ScanCandidate(
                            rank = h.candidateRank,
                            instrument = h.instrument,
                            display = h.instrument,
                            direction = h.direction,
                            grade = h.grade,
                            probability = null,
                            decision = h.decision,
                            regime = h.regime
                        )
                    ),
                    source = h.source
                )
                scheduleOutcomeTracking(synthetic)
                delay(20)
            }
        }
    }

    private suspend fun delayUntil(target: ZonedDateTime) {
        val waitMs = java.time.Duration.between(ZonedDateTime.now(jst), target).toMillis()
        if (waitMs > 0L) delay(waitMs)
    }

    private data class CapturedOutcomeRate(
        val price: Double,
        val source: String,
        val capturedAtJst: String,
        val captureDelayMs: Long,
        val providerAgeSeconds: Double
    )

    private suspend fun fetchOutcomeRateAtTarget(
        instrument: String,
        target: ZonedDateTime,
        exactMinuteOpen: Boolean
    ): CapturedOutcomeRate? = outcomeCaptureSemaphore.withPermit {
        if (!exactMinuteOpen) {
            // 3-minute MANUAL entries are intentionally +10 seconds and are not aligned to
            // a minute boundary. A candle OPEN can never represent e.g. 15:00:37, so capture
            // a genuinely fresh provider quote around the requested second instead.
            val deadline = target.plusSeconds(20)
            while (ZonedDateTime.now(jst).isBefore(deadline)) {
                val now = ZonedDateTime.now(jst)
                if (now.isBefore(target)) {
                    delay(java.time.Duration.between(now, target).toMillis().coerceAtMost(1_000L))
                    continue
                }
                try {
                    val q = withTimeout(6_000) { outcomeRepository.fetchRate(instrument) }
                    val price = q.price
                    val ageSec = q.ageSeconds
                    if (price != null && price.isFinite() && price > 0.0 &&
                        q.freshnessStatus == "LIVE" && ageSec != null && ageSec.isFinite()) {
                        val captured = ZonedDateTime.now(jst)
                        val providerAtMs = captured.toInstant().toEpochMilli() - (ageSec * 1000.0).toLong()
                        // Yahoo timestamps are second-resolution. Require the provider sample to
                        // belong to the target second or later; never accept a quote from a prior second.
                        val targetSecondMs = target.truncatedTo(ChronoUnit.SECONDS).toInstant().toEpochMilli()
                        if (providerAtMs >= targetSecondMs) {
                            val lateMs = java.time.Duration.between(target, captured).toMillis().coerceAtLeast(0L)
                            return@withPermit CapturedOutcomeRate(
                                price = price,
                                source = "${q.source} manual live",
                                capturedAtJst = captured.toString(),
                                captureDelayMs = lateMs,
                                providerAgeSeconds = ageSec
                            )
                        }
                    }
                } catch (ce: CancellationException) {
                    throw ce
                } catch (_: Throwable) {
                }
                delay(1_500)
            }
            return@withPermit null
        }

        // AUTO and 1-minute modes are minute-aligned: use exact target-minute candle OPEN.
        val targetMs = target.toInstant().toEpochMilli()
        val startNow = ZonedDateTime.now(jst)
        val hardDeadline = if (startNow.isAfter(target.plusSeconds(90))) {
            startNow.plusSeconds(20)
        } else {
            target.plusSeconds(90)
        }

        while (ZonedDateTime.now(jst).isBefore(hardDeadline)) {
            try {
                val candle = withTimeout(6_000) { outcomeRepository.fetchMinuteOpenAt(instrument, targetMs) }
                if (candle != null && candle.open.isFinite() && candle.open > 0.0) {
                    val now = ZonedDateTime.now(jst)
                    val lateMs = java.time.Duration.between(target, now).toMillis().coerceAtLeast(0L)
                    return@withPermit CapturedOutcomeRate(
                        price = candle.open,
                        source = if (instrument == "BTCJPY") "bitbank 1m open" else "Yahoo 1m open",
                        capturedAtJst = now.toString(),
                        captureDelayMs = lateMs,
                        providerAgeSeconds = lateMs / 1000.0
                    )
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Throwable) {
            }
            delay(3_000)
        }

        null
    }

    private fun refreshHistory(status: String) {
        _state.value = _state.value.copy(
            history = historyStore.load(),
            outcomeStatus = status
        )
    }

    private fun formatOutcomeRate(v: Double): String =
        if (v >= 1_000_000.0) "%,.0f".format(v) else "%.3f".format(v)

    fun buildDiagnosticJson(): String {
        val s = _state.value
        val strengthCandidate = listOfNotNull(
            s.scan?.let { scan -> scan.top1?.let { Triple(scan.atJst, it.instrument, it.direction) } },
            s.oneMinuteScan?.let { scan -> scan.top1?.let { Triple(scan.atJst, it.instrument, it.direction) } }
        ).maxByOrNull { runCatching { ZonedDateTime.parse(it.first).toInstant().toEpochMilli() }.getOrDefault(0L) }
        val strengthScores = currencyRelativeStrength(s.strengthCandles)
        val candidateStrengthCheck = strengthCandidate?.let { (at, pair, direction) ->
            val gap = strengthScores[pair.removeSuffix("JPY")]?.let { base -> strengthScores["JPY"]?.let { base - it } }
            JSONObject()
                .put("at_jst", at)
                .put("instrument", pair)
                .put("direction", direction)
                .put("strength_gap_percent", gap ?: JSONObject.NULL)
                .put("direction_aligned", gap?.let { (direction == "HIGH" && it > 0.0) || (direction == "LOW" && it < 0.0) } ?: JSONObject.NULL)
                .put("ranking_weight", 0.0)
        } ?: JSONObject.NULL
        val selectedCandidateJson: Any = strengthCandidate?.let { (at, pair, direction) ->
            JSONObject()
                .put("at_jst", at)
                .put("instrument", pair)
                .put("direction", direction)
                .put("source", if (s.oneMinuteScan?.atJst == at) s.oneMinuteScan?.source else s.scan?.source)
                .put("entry_time_jst", if (s.oneMinuteScan?.atJst == at) s.oneMinuteScan?.entryTimeJst else s.scan?.entryTimeJst)
                .put("judge_time_jst", if (s.oneMinuteScan?.atJst == at) s.oneMinuteScan?.judgeTimeJst else s.scan?.judgeTimeJst)
        } ?: JSONObject.NULL
        val root = JSONObject()
            .put("generated_at_jst", ZonedDateTime.now(jst).toString())
            .put("app", "GMK MOBILE Rule v${BuildConfig.VERSION_NAME}")
            .put("version_code", BuildConfig.VERSION_CODE)
            .put("connected_6", s.connected)
            .put("available_6", allRatesAvailable(s.rates))
            .put("live_6", allFresh(s.rates))
            .put("busy", s.busy)
            .put("error", s.error ?: JSONObject.NULL)
            .put("rate_status", s.rateStatus ?: JSONObject.NULL)
            .put("scan_status", s.scanStatus ?: JSONObject.NULL)
            .put("auto_scan", s.autoScan)
            .put("fx_provider", "YahooFinanceChart-keyless")
            .put("fx_provider_official_api", false)
            .put("fx_provider_freshness_gate_seconds", 20)
            .put("btc_provider", "bitbank-public")
            .put("battery_optimization_exempt", s.batteryOptimizationExempt)
            .put("background_restricted", s.backgroundRestricted)
            .put("market_network_stats", repository.diagnosticStats())
            .put("outcome_network_stats", outcomeRepository.diagnosticStats())
            .put("history_persistence_stats", historyStore.diagnosticStats())
            .put("history_initialized", historyInitialized)
            .put("outcome_active_jobs", outcomeJobs.values.count { it.isActive })
            .put("outcome_unexpected_retry_entries", outcomeUnexpectedRetryCounts.size)
            .put("auto_network_reservation_active", shouldReserveYahooForUpcomingAuto())
            .put("last_rate_update_ms", s.lastRateUpdateMs)
            .put("last_rate_success_ms", s.lastRateSuccessMs)
            .put("last_auto_boundary_key", lastAutoBoundaryKey ?: JSONObject.NULL)
            .put("last_scan_attempt_ms", s.lastScanAttemptMs)
            .put("last_scan_success_ms", s.lastScanSuccessMs)
            .put("rate_live_count", s.rateLiveCount)
            .put("rate_available_count", s.rateAvailableCount)
            .put("scannable_count", s.scannableCount)
            .put("last_scan_excluded", JSONObject(s.lastScanExcluded))
            .put("last_candle_errors", JSONObject(s.lastCandleErrors))
            .put("last_candle_latest_ms", JSONObject(s.lastCandleLatestMs))
            .put("quote_candle_divergence_pct", JSONObject(s.quoteCandleDivergencePct))
            .put("last_scan_full_coverage", s.scan?.candidates?.size == 6)
            .put("last_scan_candidate_count", s.scan?.candidates?.size ?: 0)
            .put("selected_candidate", selectedCandidateJson)
            .put("network_error_count", s.networkFailureCount)
            .put("last_network_error", s.lastNetworkError ?: JSONObject.NULL)
            .put("one_minute_mode", "SMARTPHONE_LOCAL_1M")
            .put("one_minute_auto_scan", s.oneMinuteAutoScan)
            .put("chart_sync", JSONObject()
                .put("instrument", s.chartInstrument)
                .put("timeframe", s.chartTimeframe)
                .put("candle_count", s.chartCandles.size)
                .put("latest_candle_ms", s.chartCandles.lastOrNull()?.timeEpochMs ?: JSONObject.NULL)
                .put("updated_at_ms", s.chartUpdatedAtMs)
                .put("loading", s.chartLoading)
                .put("error", s.chartError ?: JSONObject.NULL))
            .put("currency_strength_sync", JSONObject()
                .put("timeframe", s.strengthTimeframe)
                .put("instrument_count", s.strengthCandles.count { it.value.isNotEmpty() })
                .put("updated_at_ms", s.strengthUpdatedAtMs)
                .put("loading", s.strengthLoading)
                .put("errors", JSONObject(s.strengthErrors))
                .put("candidate_check", candidateStrengthCheck))
            .put("cut_in_enabled", s.cutInEnabled)
            .put("cut_in_shown_count", s.cutInShownCount)
            .put("cut_in_last_type", s.lastCutInType ?: JSONObject.NULL)
            .put("cut_in_last_scan_id", s.lastCutInScanId ?: JSONObject.NULL)
            .put("cut_in_last_instrument", s.lastCutInInstrument ?: JSONObject.NULL)
            .put("cut_in_last_at_jst", s.lastCutInAtJst ?: JSONObject.NULL)
            .put("cut_in_suppressed_reason", s.lastCutInSuppressedReason ?: JSONObject.NULL)
            .put("cut_in_suppressed_scan_id", s.lastCutInSuppressedScanId ?: JSONObject.NULL)
            .put("one_minute_busy", s.oneMinuteBusy)
            .put("one_minute_status", s.oneMinuteStatus ?: JSONObject.NULL)
            .put("outcome_status", s.outcomeStatus ?: JSONObject.NULL)
            .put("outcome_pending_count", s.history.count { it.resultStatus == "WAIT_ENTRY" || it.resultStatus == "WAIT_JUDGE" })
            .put("outcome_win_count", s.history.count { it.resultStatus == "WIN" })
            .put("outcome_lose_count", s.history.count { it.resultStatus == "LOSE" })
            .put("entry_win_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "WIN" })
            .put("entry_lose_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" })
            .put("skip_shadow_resolved_count", s.history.count {
                it.decision == "SKIP" && it.resultStatus in setOf("WIN", "LOSE")
            })
        val rates = JSONArray()
        s.rates.forEach { r -> rates.put(JSONObject()
            .put("instrument", r.instrument).put("price", r.price ?: JSONObject.NULL)
            .put("last", r.price ?: JSONObject.NULL)
            .put("bid", r.bid ?: JSONObject.NULL).put("ask", r.ask ?: JSONObject.NULL)
            .put("source", r.source).put("age_seconds", r.ageSeconds ?: JSONObject.NULL)
            .put("fetch_age_seconds", r.fetchAgeSeconds ?: JSONObject.NULL)
            .put("freshness", r.freshnessStatus)) }
        root.put("rates", rates)
        val historyJson = JSONArray()
        s.history.take(30).forEach { h ->
            historyJson.put(JSONObject()
                .put("scan_id", h.scanId)
                .put("source", h.source)
                .put("instrument", h.instrument)
                .put("direction", h.direction)
                .put("grade", h.grade)
                .put("decision", h.decision)
                .put("entry_time_jst", h.entryTimeJst)
                .put("judge_time_jst", h.judgeTimeJst)
                .put("entry_rate", h.entryRate ?: JSONObject.NULL)
                .put("judge_rate", h.judgeRate ?: JSONObject.NULL)
                .put("entry_capture_delay_ms", h.entryCaptureDelayMs ?: JSONObject.NULL)
                .put("judge_capture_delay_ms", h.judgeCaptureDelayMs ?: JSONObject.NULL)
                .put("entry_provider_age_seconds", h.entryProviderAgeSeconds ?: JSONObject.NULL)
                .put("judge_provider_age_seconds", h.judgeProviderAgeSeconds ?: JSONObject.NULL)
                .put("result_status", h.resultStatus))
        }
        root.put("result_history", historyJson)

        s.oneMinuteScan?.let { scan ->
            root.put("last_one_minute_manual", JSONObject()
                .put("scan_id", scan.scanId)
                .put("source", scan.source)
                .put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst)
                .put("judge_time_jst", scan.judgeTimeJst)
                .put("candidate_count", scan.candidates.size)
                .put("top1", scan.top1?.let { c ->
                    JSONObject()
                        .put("instrument", c.instrument)
                        .put("direction", c.direction)
                        .put("confidence", c.confidence)
                        .put("regime", c.regime)
                        .put("score", c.score)
                        .put("reasons", JSONArray(c.reasons))
                } ?: JSONObject.NULL))
        }

        s.scan?.let { scan ->
            val cands = JSONArray()
            scan.candidates.forEach { c -> cands.put(JSONObject()
                .put("rank", c.rank).put("instrument", c.instrument).put("direction", c.direction)
                .put("grade", c.grade).put("probability", c.probability ?: JSONObject.NULL)
                .put("decision", c.decision).put("score", c.score)
                .put("regime", c.regime)
                .put("regime_confidence", c.regimeConfidence)
                .put("reasons", JSONArray(c.reasons))) }
            root.put("last_scan", JSONObject()
                .put("scan_id", scan.scanId).put("source", scan.source).put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst).put("judge_time_jst", scan.judgeTimeJst)
                .put("warnings", JSONArray(scan.warnings)).put("candidates", cands))
        }
        return root.toString(2)
    }

    fun needsKeepAliveService(): Boolean {
        if (prefs.autoScan || prefs.oneMinuteAutoScan) return true
        // If the service is already running while history recovery is in progress, keep it alive
        // until pending manual outcomes have been reconstructed.
        if (!historyInitialized) return true
        if (outcomeJobs.values.any { it.isActive }) return true
        return _state.value.history.any {
            it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
        }
    }

    private fun syncForegroundRuntimeService() {
        val app = getApplication<Application>()
        val intent = Intent(app, GmkRuntimeKeepAliveService::class.java)
        val shouldStart = prefs.autoScan || prefs.oneMinuteAutoScan ||
            outcomeJobs.values.any { it.isActive } ||
            (historyInitialized && _state.value.history.any {
                it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
            })
        if (shouldStart) {
            ContextCompat.startForegroundService(app, intent)
        } else {
            app.stopService(intent)
        }
    }

    fun setOneMinuteAuto(value: Boolean) {
        prefs.oneMinuteAutoScan = value
        _state.value = _state.value.copy(oneMinuteAutoScan = value)
        startOneMinuteAutoLoop()
        syncForegroundRuntimeService()
    }

    fun setAuto(value: Boolean) {
        prefs.autoScan = value
        _state.value = _state.value.copy(autoScan = value)
        startAutoLoop()
        syncForegroundRuntimeService()
    }

    fun recordCutInShown(type: String, scanId: String, instrument: String) {
        val s = _state.value
        _state.value = s.copy(
            cutInShownCount = s.cutInShownCount + 1,
            lastCutInType = type,
            lastCutInScanId = scanId,
            lastCutInInstrument = instrument,
            lastCutInAtJst = ZonedDateTime.now(jst).toString(),
            lastCutInSuppressedReason = null,
            lastCutInSuppressedScanId = null
        )
    }

    fun recordCutInSuppressed(reason: String, scanId: String, instrument: String) {
        val s = _state.value
        if (s.lastCutInSuppressedReason == reason && s.lastCutInSuppressedScanId == scanId) return
        _state.value = s.copy(
            lastCutInSuppressedReason = reason,
            lastCutInSuppressedScanId = scanId,
            lastCutInInstrument = instrument
        )
    }

    fun setCutInEnabled(value: Boolean) {
        prefs.cutInEnabled = value
        _state.value = _state.value.copy(cutInEnabled = value)
    }

    fun loadChart(instrument: String = _state.value.chartInstrument, timeframe: String = _state.value.chartTimeframe, focusEpochMs: Long? = null) {
        if (instrument !in setOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")) return
        if (timeframe !in setOf("1m", "5m", "15m", "1h", "4h", "1d")) return
        if (_state.value.busy || _state.value.oneMinuteBusy || shouldReserveYahooForUpcomingAuto()) {
            chartJob?.cancel()
            _state.value = _state.value.copy(
                chartInstrument = instrument,
                chartTimeframe = timeframe,
                chartCandles = emptyList(),
                chartLoading = false,
                chartUpdatedAtMs = 0L,
                chartError = "スキャンを優先中。次回更新時にチャートを取得します"
            )
            return
        }
        chartJob?.cancel()
        _state.value = _state.value.copy(
            chartInstrument = instrument,
            chartTimeframe = timeframe,
            chartCandles = emptyList(),
            chartLoading = true,
            chartUpdatedAtMs = 0L,
            chartError = null
        )
        chartJob = viewModelScope.launch {
            try {
                val result = withTimeout(20_000L) { repository.fetchChartCandles(instrument, timeframe, focusEpochMs) }
                val candles = result.candles
                val chartWarnings = buildList {
                    addAll(result.warnings)
                    if (candles.size < 34) add("取得足が少なく、BB20/MACD 12-26-9の表示範囲が限られます")
                }.take(3).joinToString(" / ").takeIf { it.isNotBlank() }
                if (isActive && _state.value.chartInstrument == instrument && _state.value.chartTimeframe == timeframe) {
                    _state.value = _state.value.copy(
                        chartCandles = candles,
                        chartLoading = false,
                        chartError = chartWarnings,
                        chartUpdatedAtMs = System.currentTimeMillis()
                    )
                    refreshNetworkDiagnosticState()
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                if (isActive && _state.value.chartInstrument == instrument && _state.value.chartTimeframe == timeframe) {
                    _state.value = _state.value.copy(chartLoading = false, chartError = t.message ?: "チャート取得に失敗しました")
                    refreshNetworkDiagnosticState()
                }
            }
        }
    }

    fun loadStrength(timeframe: String = _state.value.strengthTimeframe) {
        if (timeframe !in setOf("1m", "5m", "15m", "1h", "4h", "1d")) return
        if (_state.value.busy || _state.value.oneMinuteBusy || shouldReserveYahooForUpcomingAuto()) {
            strengthJob?.cancel()
            _state.value = _state.value.copy(
                strengthTimeframe = timeframe,
                strengthCandles = emptyMap(),
                strengthLoading = false,
                strengthUpdatedAtMs = 0L,
                strengthErrors = mapOf("sync" to "スキャンを優先中。次回更新時に通貨足を取得します")
            )
            return
        }
        strengthJob?.cancel()
        _state.value = _state.value.copy(
            strengthTimeframe = timeframe,
            strengthCandles = emptyMap(),
            strengthLoading = true,
            strengthUpdatedAtMs = 0L,
            strengthErrors = emptyMap()
        )
        strengthJob = viewModelScope.launch {
            try {
                val batch = withTimeout(25_000L) { repository.fetchAllChartCandles(timeframe) }
                if (isActive && _state.value.strengthTimeframe == timeframe) {
                    _state.value = _state.value.copy(
                        strengthCandles = batch.candles,
                        strengthErrors = batch.errors,
                        strengthLoading = false,
                        strengthUpdatedAtMs = System.currentTimeMillis()
                    )
                    refreshNetworkDiagnosticState()
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                if (isActive && _state.value.strengthTimeframe == timeframe) {
                    _state.value = _state.value.copy(
                        strengthLoading = false,
                        strengthErrors = mapOf("all" to (t.message ?: "通貨強弱の取得に失敗しました"))
                    )
                    refreshNetworkDiagnosticState()
                }
            }
        }
    }

    fun loadHistory() {
        _state.value = _state.value.copy(history = historyStore.load())
    }

    fun saveSettings(token: String, accountId: String, environment: String, yahooFallback: Boolean) {
        // v0.7.8: OANDA runtime dependency removed. Keep signature only for source compatibility.
        prefs.yahooFallback = true
        _state.value = _state.value.copy(
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = true,
            rateStatus = "設定を保存しました。レート再接続中",
            error = null
        )
        startRateLoop()
    }

    fun shutdownRuntime() {
        rateJob?.cancel()
        chartJob?.cancel()
        strengthJob?.cancel()
        autoJob?.cancel()
        oneMinuteAutoJob?.cancel()
        oneMinuteJob?.cancel()
        outcomeRecoveryJob?.cancel()
        outcomeJobs.values.forEach { it.cancel() }
        repository.cancelInFlightRequests()
        outcomeRepository.cancelInFlightRequests()
    }

    override fun onCleared() {
        shutdownRuntime()
        super.onCleared()
    }
}

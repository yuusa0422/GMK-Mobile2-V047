package jp.gmk.mobile.runtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HistoryStore

class GmkBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = AppPrefs(context)
        if (prefs.autoScan || prefs.oneMinuteAutoScan) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, GmkRuntimeKeepAliveService::class.java)
            )
            return
        }

        // AUTO can be OFF while a manual trade is still WAIT_ENTRY/WAIT_JUDGE. Check history
        // off the receiver main thread so a reboot never abandons a pending result capture.
        val pendingResult = goAsync()
        Thread({
            try {
                if (HistoryStore(context.applicationContext).pending().isNotEmpty()) {
                    ContextCompat.startForegroundService(
                        context,
                        Intent(context, GmkRuntimeKeepAliveService::class.java)
                    )
                }
            } finally {
                pendingResult.finish()
            }
        }, "gmk-boot-recovery").start()
    }
}

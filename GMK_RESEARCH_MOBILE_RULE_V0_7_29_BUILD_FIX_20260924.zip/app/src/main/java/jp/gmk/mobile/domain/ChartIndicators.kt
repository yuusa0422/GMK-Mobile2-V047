package jp.gmk.mobile.domain

data class BollingerPoint(val middle: Double, val upper: Double, val lower: Double)
data class MacdPoint(val macd: Double, val signal: Double, val histogram: Double)

/** Pure indicator calculations over chronologically ordered candles. */
fun bollingerBands(candles: List<Candle>, period: Int = 20, deviations: Double = 2.0): List<BollingerPoint?> {
    require(period >= 2)
    val closes = candles.map { it.close }
    return closes.indices.map { index ->
        if (index + 1 < period) null else {
            val window = closes.subList(index + 1 - period, index + 1)
            val mean = window.average()
            val variance = window.sumOf { (it - mean) * (it - mean) } / period
            val width = kotlin.math.sqrt(variance) * deviations
            BollingerPoint(mean, mean + width, mean - width)
        }
    }
}

fun macd(candles: List<Candle>, fast: Int = 12, slow: Int = 26, signalPeriod: Int = 9): List<MacdPoint?> {
    require(fast > 0 && slow > fast && signalPeriod > 0)
    val closes = candles.map { it.close }
    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val alpha = 2.0 / (period + 1.0)
        return buildList(values.size) {
            var previous = values.first()
            add(previous)
            for (i in 1 until values.size) {
                previous = values[i] * alpha + previous * (1.0 - alpha)
                add(previous)
            }
        }
    }
    val fastEma = ema(closes, fast)
    val slowEma = ema(closes, slow)
    val raw = closes.indices.map { fastEma[it] - slowEma[it] }
    // The signal EMA must start only after the slow EMA has warmed up. Starting it
    // at candle zero makes the first visible signal/histogram values misleading.
    val signalStartIndex = slow - 1
    val signal = ema(raw.drop(signalStartIndex), signalPeriod)
    return raw.indices.map { i ->
        val signalIndex = i - signalStartIndex
        if (signalIndex < 0 || signalIndex + 1 < signalPeriod) null
        else MacdPoint(raw[i], signal[signalIndex], raw[i] - signal[signalIndex])
    }
}

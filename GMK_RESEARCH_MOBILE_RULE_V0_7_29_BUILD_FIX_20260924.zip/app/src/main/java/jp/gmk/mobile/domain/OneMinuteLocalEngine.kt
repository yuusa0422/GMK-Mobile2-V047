
package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Dedicated smartphone-only 1-minute engine.
 * It does not call or instantiate the 3-minute engine.
 */
class OneMinuteLocalEngine {
    private val jst = ZoneId.of("Asia/Tokyo")
    private val fmt = DateTimeFormatter.ISO_OFFSET_DATE_TIME
    private val order = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")

    fun scan(
        candlesByInstrument: Map<String, List<Candle>>,
        now: ZonedDateTime = ZonedDateTime.now(jst),
        entryTarget: ZonedDateTime? = null
    ): OneMinuteScanResult {
        val raw = mutableListOf<Raw1m>()

        for (instrument in order) {
            val candles = candlesByInstrument[instrument].orEmpty()
                .filter { c ->
                    c.close > 0.0 && c.open > 0.0 && c.high >= c.low &&
                        c.high >= max(c.open, c.close) &&
                        c.low <= minOf(c.open, c.close)
                }
                .sortedBy { it.timeEpochMs }
                .distinctBy { it.timeEpochMs }
                .takeLast(60)

            if (candles.size < 15) continue
            raw += score(instrument, candles)
        }

        val ranked = raw
            .sortedWith(
                compareBy<Raw1m> { it.switchCounterTrend }
                    .thenByDescending { it.confidence }
                    .thenByDescending { abs(it.score) }
                    .thenBy { it.instrument }
            )
            .mapIndexed { index, r ->
                OneMinuteCandidate(
                    rank = index + 1,
                    instrument = r.instrument,
                    direction = if (r.score >= 0.0) "HIGH" else "LOW",
                    confidence = r.confidence,
                    regime = r.regime,
                    score = r.score,
                    reasons = r.reasons
                )
            }

        val entry = (entryTarget ?: now.plusMinutes(1)).withSecond(0).withNano(0)
        return OneMinuteScanResult(
            scanId = "1m-local-${UUID.randomUUID()}",
            atJst = now.format(fmt),
            entryTimeJst = entry.format(fmt),
            judgeTimeJst = entry.plusMinutes(1).format(fmt),
            candidates = ranked
        )
    }

    private fun score(instrument: String, candles: List<Candle>): Raw1m {
        val closes = candles.map { it.close }
        val last = closes.last()

        val ret1 = timedReturn(candles, 1)
        val ret2 = timedReturn(candles, 2)
        val ema3 = ema(closes, 3)
        val ema8 = ema(closes, 8)
        val emaSpread = if (last == 0.0) 0.0 else (ema3 - ema8) / last
        val rsi7 = rsi(closes, 7)
        val bb12 = bollingerZ(closes, 12)
        val atr7 = atrPct(candles, 7)
        val body = if (last == 0.0) 0.0 else (candles.last().close - candles.last().open) / last

        val score = (
            0.34 * tanh(ret1 / 0.00070) +
            0.20 * tanh(ret2 / 0.00100) +
            0.20 * tanh(emaSpread / 0.00070) +
            0.12 * ((rsi7 - 50.0) / 20.0).coerceIn(-1.0, 1.0) +
            0.08 * tanh(bb12 / 1.00) +
            0.06 * tanh(body / 0.00060)
        ).coerceIn(-1.0, 1.0)

        val regimeInfo = classifyRegime(candles)
        val direction = sign(score)

        val previous = closes.dropLast(2)
        val prevEma3 = if (previous.size >= 8) ema(previous, 3) else ema3
        val prevEma8 = if (previous.size >= 8) ema(previous, 8) else ema8
        val prevSpread = if (previous.isNotEmpty() && previous.last() != 0.0)
            (prevEma3 - prevEma8) / previous.last()
        else emaSpread

        val currentTrend = sign(emaSpread)
        val previousTrend = sign(prevSpread)
        val switchDetected =
            isTailContinuous(candles, 3) &&
                currentTrend != 0 &&
                previousTrend != 0 &&
                currentTrend != previousTrend

        val switchCounterTrend =
            switchDetected && direction != 0 && direction != currentTrend

        val agreement = listOf(ret1, ret2, emaSpread, rsi7 - 50.0, bb12, body)
            .count { if (score >= 0.0) it > 0.0 else it < 0.0 } / 6.0

        val volPenalty = ((atr7 - 0.0010) / 0.0040).coerceIn(0.0, 0.12)

        var confidence = (
            0.50 +
                abs(score) * 0.34 +
                agreement * 0.08 -
                volPenalty
        ).coerceIn(0.50, 0.90)

        // Trend-switch counter-direction is heavily demoted here.
        // ViewModel additionally refuses publication if a guarded candidate would still become TOP1.
        if (switchCounterTrend) {
            confidence = confidence.coerceAtMost(0.51)
        }

        // Choppy is only a caution penalty, never a blanket skip.
        if (regimeInfo.name == "CHOPPY") {
            confidence = (confidence - 0.03).coerceAtLeast(0.50)
        }

        val reasons = buildList {
            add("1M ${regimeInfo.name} ${(regimeInfo.confidence * 100).toInt()}%")
            add("1分momentum ${pct(ret1)}")
            add("2分momentum ${pct(ret2)}")
            add("EMA3-8 ${pct(emaSpread)}")
            add("RSI7 ${"%.1f".format(rsi7)}")
            add("BB12 ${"%.2f".format(bb12)}σ")
            add("短期一致 ${(agreement * 100).toInt()}%")
            if (switchDetected) add("1M_TREND_SWITCH ${if (currentTrend > 0) "UP" else "DOWN"}")
            if (switchCounterTrend) add("1M_TREND_SWITCH_GUARD: 新方向への逆張りをTOP候補から抑制")
            if (instrument == "BTCJPY") add("BTC短期ボラ補正")
        }

        return Raw1m(
            instrument = instrument,
            score = score,
            confidence = confidence,
            regime = regimeInfo.name,
            switchCounterTrend = switchCounterTrend,
            reasons = reasons
        )
    }

    private fun classifyRegime(candles: List<Candle>): Regime1m {
        val tail = continuousTail(candles).takeLast(8)
        if (tail.size < 4) return Regime1m("TRANSITION", 0.50)

        val closes = tail.map { it.close }
        val diffs = closes.zipWithNext { a, b -> b - a }
        val travel = diffs.sumOf { abs(it) }
        val net = abs(closes.last() - closes.first())
        val efficiency = if (travel <= 1e-12) 0.0 else (net / travel).coerceIn(0.0, 1.0)

        val signs = diffs.mapNotNull {
            when {
                it > 0.0 -> 1
                it < 0.0 -> -1
                else -> null
            }
        }
        val flips = signs.zipWithNext().count { (a, b) -> a != b }
        val alternation = if (signs.size <= 1) 0.0 else flips.toDouble() / (signs.size - 1)

        val ema3 = ema(closes, 3)
        val ema8 = ema(closes, minOf(8, closes.size))
        val last = closes.last()
        val spread = if (last == 0.0) 0.0 else (ema3 - ema8) / last
        val direction = sign(spread)

        return when {
            alternation >= 0.65 && efficiency <= 0.35 ->
                Regime1m("CHOPPY", (0.55 + alternation * 0.35).coerceAtMost(0.95))
            efficiency >= 0.55 && direction > 0 ->
                Regime1m("TREND_UP", (0.55 + efficiency * 0.40).coerceAtMost(0.95))
            efficiency >= 0.55 && direction < 0 ->
                Regime1m("TREND_DOWN", (0.55 + efficiency * 0.40).coerceAtMost(0.95))
            efficiency <= 0.30 ->
                Regime1m("RANGE", (0.58 + (0.30 - efficiency)).coerceAtMost(0.90))
            else ->
                Regime1m("TRANSITION", 0.58)
        }
    }

    private fun isTailContinuous(candles: List<Candle>, count: Int): Boolean {
        val tail = candles.takeLast(count)
        if (tail.size < count) return false
        return tail.zipWithNext().all { (a, b) ->
            val gap = b.timeEpochMs - a.timeEpochMs
            gap in 1L..90_000L
        }
    }

    private fun continuousTail(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        var start = candles.lastIndex
        while (start > 0) {
            val gap = candles[start].timeEpochMs - candles[start - 1].timeEpochMs
            if (gap !in 1L..90_000L) break
            start--
        }
        return candles.subList(start, candles.size)
    }

    private fun timedReturn(candles: List<Candle>, barsBack: Int): Double {
        val tail = candles.takeLast(barsBack + 1)
        if (tail.size < barsBack + 1) return 0.0
        if (!tail.zipWithNext().all { (a, b) ->
                val gap = b.timeEpochMs - a.timeEpochMs
                gap in 1L..90_000L
            }) return 0.0
        return safeReturn(tail.last().close, tail.first().close)
    }

    private fun ema(values: List<Double>, period: Int): Double {
        if (values.isEmpty()) return 0.0
        val p = period.coerceAtLeast(1)
        val alpha = 2.0 / (p + 1.0)
        var e = values.first()
        values.drop(1).forEach { v -> e += alpha * (v - e) }
        return e
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        if (values.size < 2) return 50.0
        val diffs = values.takeLast(period + 1).zipWithNext { a, b -> b - a }
        val gains = diffs.sumOf { if (it > 0.0) it else 0.0 }
        val losses = diffs.sumOf { if (it < 0.0) -it else 0.0 }
        if (gains + losses <= 1e-12) return 50.0
        if (losses <= 1e-12) return 100.0
        val rs = gains / losses
        return 100.0 - 100.0 / (1.0 + rs)
    }

    private fun bollingerZ(values: List<Double>, period: Int): Double {
        val s = values.takeLast(period)
        if (s.size < 2) return 0.0
        val mean = s.average()
        val variance = s.sumOf { (it - mean) * (it - mean) } / s.size
        val sd = sqrt(max(variance, 1e-16))
        return (s.last() - mean) / sd
    }

    private fun atrPct(candles: List<Candle>, period: Int): Double {
        val s = candles.takeLast(period + 1)
        if (s.size < 2) return 0.0
        val tr = mutableListOf<Double>()
        for (i in 1 until s.size) {
            val c = s[i]
            val prev = s[i - 1].close
            tr += max(c.high - c.low, max(abs(c.high - prev), abs(c.low - prev)))
        }
        val last = s.last().close
        return if (last == 0.0 || tr.isEmpty()) 0.0 else tr.average() / last
    }

    private fun safeReturn(a: Double, b: Double): Double =
        if (b == 0.0) 0.0 else a / b - 1.0

    private fun sign(x: Double, eps: Double = 0.0): Int = when {
        x > eps -> 1
        x < -eps -> -1
        else -> 0
    }

    private fun pct(x: Double): String = "%+.3f%%".format(x * 100.0)

    private data class Raw1m(
        val instrument: String,
        val score: Double,
        val confidence: Double,
        val regime: String,
        val switchCounterTrend: Boolean,
        val reasons: List<String>
    )

    private data class Regime1m(
        val name: String,
        val confidence: Double
    )
}

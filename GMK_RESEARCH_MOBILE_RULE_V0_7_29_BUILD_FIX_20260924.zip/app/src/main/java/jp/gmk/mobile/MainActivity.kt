package jp.gmk.mobile

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Duration
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import jp.gmk.mobile.ui.GmkViewModel
import jp.gmk.mobile.runtime.GmkRuntimeHolder
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val Paper = Color(0xFFF6EBDD)
private val Paper2 = Color(0xFFFFF8EE)
private val Wood = Color(0xFF4A3029)
private val Wine = Color(0xFFA63847)
private val WineDark = Color(0xFF6D2430)
private val Ink = Color(0xFF35211E)
private val High = Color(0xFFC73B4D)
private val Low = Color(0xFF315FB6)
private val Gold = Color(0xFFB7893C)

// Reimu night-shrine scan theme
private val ScanBg = Color(0xFF07142A)
private val ScanPanel = Color(0xD9142343)
private val ScanPanel2 = Color(0xE21A1834)
private val ScanCyan = Color(0xFF35D9FF)
private val ScanPink = Color(0xFFFF4F91)
private val ScanPurple = Color(0xFF9E6CFF)
private val ScanText = Color(0xFFF6F2FF)
private val ScanMuted = Color(0xFF9FB4D9)
private val ScanGreen = Color(0xFF53E6A4)

class MainActivity : ComponentActivity() {
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Foreground runtime still functions; UI power/runtime diagnostics remain visible if denied. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Wine, background = Paper)) { GmkApp() }
        }
    }

    override fun onResume() {
        super.onResume()
        GmkRuntimeHolder.get(application).refreshDevicePowerState()
    }
}

enum class Tab { Prediction, Chart, Strength, History, Status }

@Composable
fun GmkApp() {
    val app = LocalContext.current.applicationContext as android.app.Application
    val vm = remember(app) { GmkRuntimeHolder.get(app) }
    val state by vm.state.collectAsState()
    var tabName by rememberSaveable { mutableStateOf(Tab.Prediction.name) }
    val tab = runCatching { Tab.valueOf(tabName) }.getOrDefault(Tab.Prediction)
    var selectedInstrument by rememberSaveable { mutableStateOf("EURJPY") }
    var chartTimeframe by rememberSaveable { mutableStateOf("1m") }
    var autoFollowScan by rememberSaveable { mutableStateOf(true) }
    var focusHistory by remember { mutableStateOf<HistoryRow?>(null) }
    val newestScanCandidate = listOfNotNull(
        state.scan?.let { scan -> scan.top1?.let { scan.atJst to it.instrument } },
        state.oneMinuteScan?.let { scan -> scan.top1?.let { scan.atJst to it.instrument } }
    ).maxByOrNull { (at, _) -> runCatching { ZonedDateTime.parse(at).toInstant().toEpochMilli() }.getOrDefault(0L) }
    LaunchedEffect(newestScanCandidate?.first, autoFollowScan) {
        if (autoFollowScan) newestScanCandidate?.second?.let {
            selectedInstrument = it
            focusHistory = null
        }
    }
    val context = LocalContext.current
    val diagnosticLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching {
                val stream = requireNotNull(context.contentResolver.openOutputStream(uri)) { "保存先を開けません" }
                stream.use { out ->
                    out.write(vm.buildDiagnosticJson().toByteArray(Charsets.UTF_8))
                    out.flush()
                }
                true
            }.getOrDefault(false)
            Toast.makeText(
                context,
                if (ok) "診断ログを保存しました" else "診断ログの保存に失敗しました",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
    Scaffold(
        containerColor = Paper,
        bottomBar = {
            BottomBar(tab) {
                tabName = it.name
                if (it == Tab.History) vm.loadHistory()
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.Prediction -> ScanScreen(
                    state,
                    vm::manualScan,
                    vm::manualOneMinuteScan,
                    vm::setAuto,
                    vm::setOneMinuteAuto
                )
                Tab.Chart -> ChartScreen(
                    state = state,
                    instrument = selectedInstrument,
                    timeframe = chartTimeframe,
                    focusHistory = focusHistory,
                    autoFollowScan = autoFollowScan,
                    onToggleAutoFollow = { autoFollowScan = !autoFollowScan },
                    onInstrument = { selectedInstrument = it; focusHistory = null; autoFollowScan = false },
                    onTimeframe = { chartTimeframe = it },
                    onRefresh = vm::loadChart
                )
                Tab.Strength -> CurrencyStrengthScreen(
                    state = state,
                    onRefresh = vm::loadStrength,
                    onSelectPair = { selectedInstrument = it; focusHistory = null; autoFollowScan = false; tabName = Tab.Chart.name }
                )
                Tab.History -> HistoryScreen(state.history) { row ->
                    selectedInstrument = row.instrument
                    focusHistory = row
                    chartTimeframe = "1m"
                    autoFollowScan = false
                    tabName = Tab.Chart.name
                }
                Tab.Status -> StatusScreen(
                    state = state,
                    setCutInEnabled = vm::setCutInEnabled,
                    exportDiagnostic = { diagnosticLauncher.launch("GMK_DIAGNOSTICS_${System.currentTimeMillis()}.json") }
                )
            }
            CutInOverlay(
                state = state,
                onShown = vm::recordCutInShown,
                onSuppressed = vm::recordCutInSuppressed
            )
        }
    }
}


@Composable
private fun PowerPolicyWarning(state: GmkUiState) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE6E6))
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("バックグラウンド制限を確認してください", color = WineDark, fontWeight = FontWeight.Bold)
            Text(
                if (state.backgroundRestricted)
                    "Androidがバックグラウンド実行を制限中です。AUTO/T-10が遅延する可能性があります。"
                else
                    "電池最適化の対象です。画面OFF/DozeでAUTO/T-10が遅延する可能性があります。",
                color = Ink, fontSize = 12.sp
            )
            TextButton(onClick = {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) { Text("電池最適化設定を開く") }
        }
    }
}

@Composable
private fun ScanScreen(
    state: GmkUiState,
    onScan: () -> Unit,
    onOneMinuteScan: () -> Unit,
    onAuto: (Boolean) -> Unit,
    onOneMinuteAuto: (Boolean) -> Unit
) {
    Box(Modifier.fillMaxSize().background(ScanBg)) {
        Image(
            painter = painterResource(R.drawable.scan_reimu_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0x66030A19), Color(0xCC07142A), Color(0xF207142A))
                )
            )
        )
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Box(Modifier.fillMaxWidth()) {
                    Image(
                        painterResource(R.drawable.scan_reimu_hero), null,
                        Modifier.fillMaxWidth().aspectRatio(1024f / 680f),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        Modifier.matchParentSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, Color(0xB807142A)))
                        )
                    )
                    Column(
                        Modifier.align(Alignment.BottomStart).padding(start = 18.dp, end = 18.dp, bottom = 14.dp)
                    ) {
                        Text("豪徳寺 三花システム", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("GMK MOBILE  •  幻想の相場に、弾を放て", color = Color(0xFFE9C8FF), fontSize = 11.sp)
                    }
                }
                StatusStrip(state)
                if (!state.batteryOptimizationExempt || state.backgroundRestricted) {
                    PowerPolicyWarning(state)
                }
                ModePanel(state.autoScan, onAuto)
                CountdownPanel(onScan, state.busy || state.oneMinuteBusy)
                OneMinuteManualPanel(
                    scan = state.oneMinuteScan,
                    status = state.oneMinuteStatus,
                    busy = state.oneMinuteBusy || state.busy,
                    auto = state.oneMinuteAutoScan,
                    onAuto = onOneMinuteAuto,
                    onScan = onOneMinuteScan
                )
            }
            item { Top1Card(state.scan?.top1, state.scan?.candidates?.size ?: 0) }
            item { SectionTitle("スキャン結果") }
            val results = state.scan?.candidates.orEmpty()
            if (results.isEmpty()) {
                items(state.rates) { RateOnlyRow(it) }
            } else {
                items(results) { c -> ResultRow(c, state.rates.firstOrNull { it.instrument == c.instrument }) }
                val candidateSet = results.map { it.instrument }.toSet()
                val excludedRates = state.rates.filter { it.instrument !in candidateSet }
                if (excludedRates.isNotEmpty()) {
                    item { SectionTitle("今回の判定対象外") }
                    items(excludedRates) { RateOnlyRow(it) }
                }
            }
            if (state.lastScanExcluded.isNotEmpty()) {
                item {
                    Text(
                        state.lastScanExcluded.entries.joinToString(" / ") { "${it.key}: ${it.value}" },
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        color = Color(0xFFFF9AAE), fontSize = 11.sp
                    )
                }
            }
            val divergenceAlerts = state.quoteCandleDivergencePct.filter { (ins, pct) ->
                pct >= if (ins == "BTCJPY") 1.50 else 0.50
            }
            if (divergenceAlerts.isNotEmpty()) {
                item {
                    Text(
                        "価格整合注意: " + divergenceAlerts.entries.joinToString(" / ") {
                            "${it.key} ${"%.3f".format(it.value)}%"
                        },
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        color = Color(0xFFFF728F), fontSize = 11.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
            item { RecentHistoryPreview(state.history) }
            item { Spacer(Modifier.height(18.dp)) }
        }
    }
}

private enum class CutInKind { WIN_ADVANTAGE, LOSE_ADVANTAGE, WIN_FINAL, LOSE_FINAL }

private data class CutInDisplay(
    val key: String,
    val scanId: String,
    val instrument: String,
    val kind: CutInKind,
    val slot: Int,
    val oneMinuteAdvantage: Boolean = false
)

private fun cutInDrawable(kind: CutInKind, slot: Int, oneMinuteAdvantage: Boolean = false): Int {
    val i = slot.coerceIn(1, 10) - 1
    val winAdv = intArrayOf(
        R.drawable.cutin_win_adv_01, R.drawable.cutin_win_adv_02, R.drawable.cutin_win_adv_03,
        R.drawable.cutin_win_adv_04, R.drawable.cutin_win_adv_05, R.drawable.cutin_win_adv_06,
        R.drawable.cutin_win_adv_07, R.drawable.cutin_win_adv_08, R.drawable.cutin_win_adv_09,
        R.drawable.cutin_win_adv_10
    )
    val winFinal = intArrayOf(
        R.drawable.cutin_win_final_01, R.drawable.cutin_win_final_02, R.drawable.cutin_win_final_03,
        R.drawable.cutin_win_final_04, R.drawable.cutin_win_final_05, R.drawable.cutin_win_final_06,
        R.drawable.cutin_win_final_07, R.drawable.cutin_win_final_08, R.drawable.cutin_win_final_09,
        R.drawable.cutin_win_final_10
    )
    val loseAdv = intArrayOf(
        R.drawable.cutin_lose_adv_01, R.drawable.cutin_lose_adv_02, R.drawable.cutin_lose_adv_03,
        R.drawable.cutin_lose_adv_04, R.drawable.cutin_lose_adv_05, R.drawable.cutin_lose_adv_06,
        R.drawable.cutin_lose_adv_07, R.drawable.cutin_lose_adv_08, R.drawable.cutin_lose_adv_09,
        R.drawable.cutin_lose_adv_10
    )
    val loseFinal = intArrayOf(
        R.drawable.cutin_lose_final_01, R.drawable.cutin_lose_final_02, R.drawable.cutin_lose_final_03,
        R.drawable.cutin_lose_final_04, R.drawable.cutin_lose_final_05, R.drawable.cutin_lose_final_06,
        R.drawable.cutin_lose_final_07, R.drawable.cutin_lose_final_08, R.drawable.cutin_lose_final_09,
        R.drawable.cutin_lose_final_10
    )
    val winAdv1m = intArrayOf(
        R.drawable.cutin_win_adv_1m_01, R.drawable.cutin_win_adv_1m_02, R.drawable.cutin_win_adv_1m_03,
        R.drawable.cutin_win_adv_1m_04, R.drawable.cutin_win_adv_1m_05, R.drawable.cutin_win_adv_1m_06,
        R.drawable.cutin_win_adv_1m_07, R.drawable.cutin_win_adv_1m_08, R.drawable.cutin_win_adv_1m_09,
        R.drawable.cutin_win_adv_1m_10
    )
    val loseAdv1m = intArrayOf(
        R.drawable.cutin_lose_adv_1m_01, R.drawable.cutin_lose_adv_1m_02, R.drawable.cutin_lose_adv_1m_03,
        R.drawable.cutin_lose_adv_1m_04, R.drawable.cutin_lose_adv_1m_05, R.drawable.cutin_lose_adv_1m_06,
        R.drawable.cutin_lose_adv_1m_07, R.drawable.cutin_lose_adv_1m_08, R.drawable.cutin_lose_adv_1m_09,
        R.drawable.cutin_lose_adv_1m_10
    )
    return when (kind) {
        CutInKind.WIN_ADVANTAGE -> if (oneMinuteAdvantage) winAdv1m[i] else winAdv[i]
        CutInKind.LOSE_ADVANTAGE -> if (oneMinuteAdvantage) loseAdv1m[i] else loseAdv[i]
        CutInKind.WIN_FINAL -> winFinal[i]
        CutInKind.LOSE_FINAL -> loseFinal[i]
    }
}

private fun stableCutInSlot(scanId: String, instrument: String): Int {
    val hash = (scanId.ifBlank { instrument }).hashCode()
    return Math.floorMod(hash, 10) + 1
}

@Composable
private fun CutInOverlay(
    state: GmkUiState,
    onShown: (String, String, String) -> Unit,
    onSuppressed: (String, String, String) -> Unit
) {
    if (!state.cutInEnabled) return

    val jst = remember { ZoneId.of("Asia/Tokyo") }
    // A single logical ADVANTAGE event is allowed per scan. Final result can still follow it.
    val shownAtMs = remember { mutableMapOf<String, Long>() }
    var current by remember { mutableStateOf<CutInDisplay?>(null) }
    var expiresAtMs by remember { mutableLongStateOf(0L) }
    var now by remember { mutableStateOf(ZonedDateTime.now(jst)) }

    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now(jst)
            delay(250)
        }
    }

    LaunchedEffect(now, state.history, state.rates, state.cutInEnabled) {
        val nowMs = System.currentTimeMillis()
        if (current != null && nowMs >= expiresAtMs) current = null

        // Keep on-screen events sequential. Do not overwrite one cut-in with the next one.
        if (current != null) return@LaunchedEffect

        val recent = state.history.take(256)
        val dedupeCutoff = nowMs - 2L * 60L * 60L * 1000L
        shownAtMs.entries.removeAll { it.value < dedupeCutoff }

        // Official settled results have the highest priority and stay recoverable for 20 seconds.
        val finalRow = recent.asSequence()
            .filter { row ->
                row.decision == "ENTRY" && row.resultStatus in setOf("WIN", "LOSE") && row.settledAtJst.isNotBlank()
            }
            .mapNotNull { row ->
                val settled = runCatching { ZonedDateTime.parse(row.settledAtJst) }.getOrNull() ?: return@mapNotNull null
                val ageMs = Duration.between(settled, now).toMillis()
                if (ageMs !in 0..20_000) return@mapNotNull null
                val kind = if (row.resultStatus == "WIN") CutInKind.WIN_FINAL else CutInKind.LOSE_FINAL
                val key = "${row.scanId}:FINAL"
                if (shownAtMs.containsKey(key)) return@mapNotNull null
                Triple(row, kind, ageMs)
            }
            .minByOrNull { it.third }

        if (finalRow != null) {
            val row = finalRow.first
            val kind = finalRow.second
            val key = "${row.scanId}:FINAL"
            shownAtMs[key] = nowMs
            current = CutInDisplay(
                key = key,
                scanId = row.scanId,
                instrument = row.instrument,
                kind = kind,
                slot = stableCutInSlot(row.scanId, row.instrument)
            )
            expiresAtMs = nowMs + 3_600L
            onShown(kind.name, row.scanId, row.instrument)
            return@LaunchedEffect
        }

        // Reliable advantage trigger:
        // 3m = once at any time after entering the final 30 seconds.
        // 1m = once at any time after entering the final 15 seconds.
        // This intentionally does NOT require hitting a narrow 5-second polling window.
        val pendingCandidate = recent.asSequence()
            .filter { row ->
                row.decision == "ENTRY" && row.resultStatus == "WAIT_JUDGE" &&
                    row.entryRate != null && row.judgeTimeJst.isNotBlank()
            }
            .mapNotNull { row ->
                val judge = runCatching { ZonedDateTime.parse(row.judgeTimeJst) }.getOrNull() ?: return@mapNotNull null
                val remainingMs = Duration.between(now, judge).toMillis()
                val isOneMinute = row.source.contains("1M", ignoreCase = true)
                val leadMs = CutInPolicy.leadMs(isOneMinute)
                if (!CutInPolicy.isInAdvantageWindow(remainingMs, isOneMinute)) return@mapNotNull null
                val key = "${row.scanId}:ADVANTAGE"
                if (shownAtMs.containsKey(key)) return@mapNotNull null
                Triple(row, remainingMs, kotlin.math.abs(remainingMs - leadMs))
            }
            .minByOrNull { it.third }
            ?.first ?: return@LaunchedEffect

        val live = state.rates.firstOrNull {
            it.instrument == pendingCandidate.instrument && it.price != null &&
                it.freshnessStatus == "LIVE" && (it.ageSeconds ?: 999.0) <= 20.0
        }
        if (live == null) {
            onSuppressed("NO_FRESH_LIVE_RATE", pendingCandidate.scanId, pendingCandidate.instrument)
            return@LaunchedEffect
        }

        val currentPrice = live.price
        val entry = pendingCandidate.entryRate
        if (currentPrice == null || entry == null || !currentPrice.isFinite() || !entry.isFinite() || entry <= 0.0) {
            onSuppressed("INVALID_ADVANTAGE_PRICE", pendingCandidate.scanId, pendingCandidate.instrument)
            return@LaunchedEffect
        }

        val signal = CutInPolicy.advantageSignal(pendingCandidate.direction, entry, currentPrice)
        if (signal == null) {
            onSuppressed("INVALID_ADVANTAGE_SIGNAL", pendingCandidate.scanId, pendingCandidate.instrument)
            return@LaunchedEffect
        }
        val kind = when (signal) {
            CutInAdvantageSignal.WIN_ADVANTAGE -> CutInKind.WIN_ADVANTAGE
            CutInAdvantageSignal.LOSE_ADVANTAGE -> CutInKind.LOSE_ADVANTAGE
        }
        val key = "${pendingCandidate.scanId}:ADVANTAGE"
        shownAtMs[key] = nowMs
        current = CutInDisplay(
            key = key,
            scanId = pendingCandidate.scanId,
            instrument = pendingCandidate.instrument,
            kind = kind,
            slot = stableCutInSlot(pendingCandidate.scanId, pendingCandidate.instrument),
            oneMinuteAdvantage = pendingCandidate.source.contains("1M", ignoreCase = true)
        )
        expiresAtMs = nowMs + 3_200L
        onShown(kind.name, pendingCandidate.scanId, pendingCandidate.instrument)
    }

    AnimatedVisibility(
        visible = current != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 3 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it / 3 })
    ) {
        current?.let { cut ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.18f))
                    .clickable { current = null },
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(0.96f),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF070A12))
                ) {
                    Column {
                        // Every asset is rebuilt to exactly 16:5. Fit + explicit aspect ratio means
                        // character faces, labels, and countdowns can never be cropped by the container.
                        Image(
                            painter = painterResource(cutInDrawable(cut.kind, cut.slot, cut.oneMinuteAdvantage)),
                            contentDescription = "GMK ${cut.kind.name} cut-in",
                            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 5f),
                            contentScale = ContentScale.Fit
                        )
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Color(0xF211131C))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (cut.kind) {
                                    CutInKind.WIN_ADVANTAGE -> "勝ち優勢"
                                    CutInKind.LOSE_ADVANTAGE -> "負け優勢"
                                    CutInKind.WIN_FINAL -> "WIN"
                                    CutInKind.LOSE_FINAL -> "LOSE"
                                },
                                color = when (cut.kind) {
                                    CutInKind.WIN_ADVANTAGE, CutInKind.WIN_FINAL -> Color(0xFF71E3A6)
                                    else -> Color(0xFFFF7A8C)
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(cut.instrument, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            Text("GMK MOBILE", color = Color.LightGray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LocalOnlyStrip() {
    Row(
        Modifier.fillMaxWidth().background(Color(0xCC101D3B)).padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("✦ 端末単体版", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ScanCyan)
        Spacer(Modifier.width(8.dp))
        Text("判定・履歴はスマホ内 / クラウド不要", fontSize = 10.sp, color = ScanMuted)
    }
}

@Composable
private fun StatusStrip(state: GmkUiState) {
    val allLive = state.rateLiveCount == 6
    val edge = if (allLive) ScanCyan else ScanPink
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .border(1.dp, edge.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
            .background(ScanPanel, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when {
                    allLive -> "● 6/6 LIVE"
                    state.rateAvailableCount > 0 -> "● LIVE ${state.rateLiveCount}/6  取得 ${state.rateAvailableCount}/6"
                    else -> "● レート取得待機"
                },
                fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = if (allLive) ScanGreen else Color(0xFFFF8DA8)
            )
            Spacer(Modifier.weight(1f))
            if (state.scannableCount > 0) {
                Text("判定可能 ${state.scannableCount}/6", fontSize = 10.sp, color = ScanMuted)
            }
        }
        state.rateStatus?.let { Text(it.take(180), fontSize = 10.sp, color = Color(0xFFFFA7B8), maxLines = 2) }
        state.scanStatus?.let { Text(it.take(220), fontSize = 10.sp, color = ScanText, maxLines = 3) }
        state.outcomeStatus?.let { Text(it.take(220), fontSize = 10.sp, color = ScanGreen, maxLines = 2) }
        state.error?.let { Text(it.take(180), fontSize = 10.sp, color = Color(0xFFFF728F), maxLines = 2) }
    }
}

@Composable
private fun ModePanel(auto: Boolean, onAuto: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            .border(1.dp, ScanPurple.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .background(ScanPanel2, RoundedCornerShape(12.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("判定モード", fontWeight = FontWeight.Bold, color = ScanText)
        Spacer(Modifier.width(10.dp))
        ModeChip("3分", true)
        Spacer(Modifier.width(6.dp))
        ModeChip("1分", false)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("AUTO SCAN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ScanMuted)
            Switch(checked = auto, onCheckedChange = onAuto)
        }
    }
}

@Composable
private fun ModeChip(text: String, active: Boolean) {
    Box(
        Modifier.background(
            if (active) Brush.horizontalGradient(listOf(ScanPink, ScanPurple)) else Brush.horizontalGradient(listOf(Color(0xFF1A2848), Color(0xFF1A2848))),
            RoundedCornerShape(8.dp)
        ).border(1.dp, if (active) Color(0xFFFFB1D0) else Color(0xFF35517A), RoundedCornerShape(8.dp))
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun CountdownPanel(onScan: () -> Unit, busy: Boolean) {
    var seconds by remember { mutableStateOf(nextScanSeconds()) }
    LaunchedEffect(Unit) { while (true) { seconds = nextScanSeconds(); delay(1000) } }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Card(
            Modifier.weight(0.9f).border(1.dp, ScanCyan.copy(alpha = .6f), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ScanPanel)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text("次回AUTOまで", fontSize = 11.sp, color = ScanMuted)
                Text(String.format("%02d:%02d", seconds / 60, seconds % 60), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = ScanCyan)
            }
        }
        Spacer(Modifier.width(8.dp))
        Button(
            onClick = onScan, enabled = !busy,
            modifier = Modifier.weight(1.35f).height(78.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(12.dp)
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(listOf(Color(0xFFDA2367), Color(0xFF7B3BFF))), RoundedCornerShape(12.dp)
                ).border(1.dp, Color(0xFFFFB5DA), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (busy) "スキャン中…" else "▶ スキャン開始", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

@Composable
private fun OneMinuteManualPanel(
    scan: OneMinuteScanResult?,
    status: String?,
    busy: Boolean,
    auto: Boolean,
    onAuto: (Boolean) -> Unit,
    onScan: () -> Unit
) {
    val top = scan?.top1
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .border(1.dp, ScanPurple.copy(alpha = .7f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = ScanPanel2)
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("1分専用板", fontWeight = FontWeight.Bold, color = ScanText, fontSize = 17.sp)
                    Text("SMARTPHONE LOCAL / T-10", fontSize = 10.sp, color = ScanMuted)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("1分AUTO", fontSize = 10.sp, color = ScanMuted)
                        Spacer(Modifier.width(6.dp))
                        Switch(checked = auto, onCheckedChange = onAuto)
                    }
                }
                Button(onClick = onScan, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D3BEA))) {
                    Text(if (busy) "判定中…" else "1分スキャン")
                }
            }
            status?.let { Spacer(Modifier.height(6.dp)); Text(it, fontSize = 11.sp, color = ScanText) }
            top?.let { c ->
                Spacer(Modifier.height(8.dp)); HorizontalDivider(color = Color(0x4435D9FF)); Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.instrument, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ScanText)
                        Text("${c.regime} / 1M ${(c.confidence * 100).toInt()}%", fontSize = 10.sp, color = ScanMuted)
                    }
                    DirectionBox(c.direction)
                }
            }
        }
    }
}

private fun nextScanSeconds(): Int {
    val z = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"))
    var boundary = z.truncatedTo(ChronoUnit.MINUTES).withSecond(0).withNano(0)
    val add = (5 - boundary.minute % 5) % 5
    boundary = boundary.plusMinutes(add.toLong())
    var scanAt = boundary.minusSeconds(10)
    if (scanAt.isBefore(z) && ChronoUnit.MILLIS.between(scanAt, z) >= 1000L) {
        scanAt = boundary.plusMinutes(5).minusSeconds(10)
    }
    return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())
}

@Composable
private fun Top1Card(top: ScanCandidate?, coverageCount: Int) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .border(1.dp, Color(0xFFFFB04A), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xE3151C36))
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF7C2757), Color(0xFF2E4D91)))).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (coverageCount in 1..5) "✦ TOP1（部分 ${coverageCount}/6）" else "✦ TOP1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            if (top == null) {
                Text("まだスキャン結果がありません", Modifier.padding(18.dp), color = ScanMuted)
            } else {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(top.instrument, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ScanText)
                        Text("RANK ${top.grade}  •  ${top.regime}", color = Color(0xFFFFC76A), fontWeight = FontWeight.Bold)
                        top.probability?.let { Text("RULE ${(it * 100).toInt()}%", fontSize = 11.sp, color = ScanMuted) }
                    }
                    DirectionBox(top.direction)
                    Spacer(Modifier.width(10.dp))
                    Text(top.decision, color = if (top.decision == "ENTRY") ScanGreen else ScanMuted, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        "✦ $text",
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF351546), Color(0xFF123B65))), RoundedCornerShape(8.dp))
            .padding(horizontal = 13.dp, vertical = 8.dp),
        color = Color.White, fontWeight = FontWeight.Bold
    )
}

@Composable
private fun ResultRow(c: ScanCandidate, rate: RateRow?) {
    val high = c.direction.uppercase() == "HIGH"
    val accent = if (high) ScanPink else ScanCyan
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .border(1.dp, accent.copy(alpha = if (c.rank == 1) .95f else .45f), RoundedCornerShape(10.dp))
            .background(if (c.rank == 1) Color(0xE2311834) else Color(0xD913213D), RoundedCornerShape(10.dp))
            .padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).background(Color(0xFF182A4B), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Text("${c.rank}", fontWeight = FontWeight.Bold, color = Color(0xFFFFD16C))
        }
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(c.instrument, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ScanText)
            Text(rate?.price?.let(::formatPrice) ?: "—", fontSize = 11.sp, color = ScanMuted)
            Text("${c.regime} ${(c.regimeConfidence * 100).toInt()}%", fontSize = 10.sp, color = ScanMuted)
        }
        DirectionBox(c.direction)
        Spacer(Modifier.width(8.dp))
        Text(c.grade, Modifier.width(28.dp), fontWeight = FontWeight.Bold, color = Color(0xFFFFD16C), textAlign = TextAlign.Center)
        val displayDecision = when { c.rank == 1 -> c.decision; c.decision == "ENTRY" -> "候補"; else -> "SKIP" }
        Text(displayDecision, Modifier.width(48.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold,
            color = if (c.rank == 1 && c.decision == "ENTRY") ScanGreen else ScanMuted, textAlign = TextAlign.End)
    }
}

@Composable
private fun RateOnlyRow(r: RateRow) {
    val status = when {
        r.price == null -> "UNAVAILABLE"
        r.freshnessStatus == "LIVE" -> "LIVE"
        r.freshnessStatus == "LAST" -> "LAST"
        else -> r.freshnessStatus
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .border(1.dp, Color(0x5535D9FF), RoundedCornerShape(10.dp))
            .background(Color(0xD913213D), RoundedCornerShape(10.dp)).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(r.instrument, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = ScanText)
        Column(horizontalAlignment = Alignment.End) {
            Text(r.price?.let(::formatPrice) ?: "—", fontWeight = FontWeight.Bold, color = ScanText)
            val ageLabel = r.ageSeconds?.let { " ${it.toInt()}s" } ?: ""
            Text("$status$ageLabel ${r.source}", fontSize = 10.sp,
                color = when (status) { "LIVE" -> ScanGreen; "LAST" -> Color(0xFFFFC76A); else -> Color(0xFFFF728F) })
        }
    }
}

@Composable
private fun DirectionBox(direction: String) {
    val normalized = direction.uppercase()
    val (label, color) = when (normalized) {
        "HIGH" -> "▲ HIGH" to ScanPink
        "LOW" -> "▼ LOW" to Color(0xFF2E8DFF)
        else -> "—" to Color.Gray
    }
    Surface(color = color.copy(alpha = .92f), shape = RoundedCornerShape(8.dp)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun formatJstTime(iso: String): String {
    if (iso.isBlank()) return "—"
    return runCatching {
        ZonedDateTime.parse(iso)
            .withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
            .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
    }.getOrElse { "—" }
}

private fun formatPrice(x: Double): String = if (x >= 100000) "%,.0f".format(x) else if (x >= 100) "%.3f".format(x) else "%.5f".format(x)

@Composable
private fun RecentHistoryPreview(rows: List<HistoryRow>) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp)) {
        Text("直近の予測結果", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))

        if (rows.isEmpty()) {
            Text("まだ結果はありません。", fontSize = 11.sp, color = Color.Gray)
        } else {
            rows.take(5).forEach { h ->
                val resultColor = when (h.resultStatus) {
                    "WIN" -> Color(0xFF2E7D32)
                    "LOSE" -> Wine
                    else -> Color.Gray
                }
                Row(
                    Modifier.fillMaxWidth()
                        .background(Paper2)
                        .padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(h.instrument, Modifier.width(72.dp), fontWeight = FontWeight.Bold)
                    Text(
                        h.direction,
                        Modifier.width(50.dp),
                        color = if (h.direction == "HIGH") High else Low,
                        fontWeight = FontWeight.Bold
                    )
                    Text(h.source, Modifier.width(64.dp), fontSize = 10.sp, color = Color.Gray)
                    Spacer(Modifier.weight(1f))
                    Text(
                        when (h.resultStatus) {
                            "WIN" -> "WIN"
                            "LOSE" -> "LOSE"
                            "WAIT_ENTRY" -> if (h.source == "MANUAL_1M") "ENTRY待ち" else "10秒後待ち"
                             "WAIT_JUDGE" -> if (h.source.contains("1M")) "1分判定待ち" else "3分判定待ち"
                            "ENTRY_RATE_MISSED" -> "ENTRY取得失敗"
                            "JUDGE_RATE_MISSED" -> "判定取得失敗"
                            "LEGACY_NO_OUTCOME" -> "旧履歴"
                            else -> h.resultStatus
                        },
                        color = resultColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(rows: List<HistoryRow>, onOpenChart: (HistoryRow) -> Unit) {
    val threeRows = rows.filter { !it.source.contains("1M") }
    val oneRows = rows.filter { it.source.contains("1M") }

    val threeWins = threeRows.count { it.decision == "ENTRY" && it.resultStatus == "WIN" }
    val threeLosses = threeRows.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" }
    val threeResolved = threeWins + threeLosses
    val threeWr = if (threeResolved > 0) threeWins * 100.0 / threeResolved else null

    val oneWins = oneRows.count { it.decision == "ENTRY" && it.resultStatus == "WIN" }
    val oneLosses = oneRows.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" }
    val oneResolved = oneWins + oneLosses
    val oneWr = if (oneResolved > 0) oneWins * 100.0 / oneResolved else null

    val skipResolved = threeRows.count {
        it.decision == "SKIP" && it.resultStatus in setOf("WIN", "LOSE")
    }

    Box(Modifier.fillMaxSize().background(ScanBg)) {
        Image(
            painter = painterResource(R.drawable.history_gensokyo_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.58f
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x44120A2A),
                        Color(0xAA07142A),
                        Color(0xE8071020)
                    )
                )
            )
        )

        Column(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xAA1A0D36), Color(0x6610162A))))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "予測結果一覧",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "— 幻想の相場に、弾を放て —",
                            fontSize = 11.sp,
                            color = Color(0xFFDFB8FF)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("博麗神社", color = ScanPink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("GMK MOBILE", color = ScanMuted, fontSize = 9.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "3分",
                        value = if (threeWr != null) "${threeResolved}件\n${"%.2f".format(threeWr)}%" else "確定なし",
                        accent = ScanPink,
                        icon = "✿"
                    )
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "1分",
                        value = if (oneWr != null) "${oneResolved}件\n${"%.2f".format(oneWr)}%" else "確定なし",
                        accent = ScanCyan,
                        icon = "☯"
                    )
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "3分SKIP",
                        value = "参考\n${skipResolved}件",
                        accent = ScanPurple,
                        icon = "✦"
                    )
                }
            }

            if (rows.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier.padding(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xDD101B34)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x669E6CFF))
                    ) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("履歴はまだありません", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "3分/1分のENTRYと判定結果が、ここに幻想郷風カードで記録されます。",
                                color = ScanMuted,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    items(rows) { h ->
                        val isWin = h.resultStatus == "WIN"
                        val isLose = h.resultStatus == "LOSE"
                        val isWaiting = h.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
                        val statusColor = when {
                            isWin -> ScanGreen
                            isLose -> Color(0xFFFF4F73)
                            isWaiting -> ScanPurple
                            h.resultStatus.contains("MISSED") || h.resultStatus.contains("MISSING") -> Color(0xFFFFB84F)
                            else -> ScanMuted
                        }
                        val directionColor = if (h.direction == "HIGH") ScanPink else ScanCyan
                        val cardTop = when {
                            isWin -> Color(0xDD24102A)
                            isLose -> Color(0xDD251026)
                            else -> Color(0xDD0B2140)
                        }
                        val cardBottom = Color(0xEE081329)
                        val statusText = when (h.resultStatus) {
                            "WIN" -> "✿  WIN"
                            "LOSE" -> "⚔  LOSE"
                            "WAIT_ENTRY" -> if (h.source == "MANUAL_1M") "⌛ ENTRY待ち" else "⌛ 10秒後待ち"
                            "WAIT_JUDGE" -> if (h.source.contains("1M")) "⌛ 1分判定待ち" else "⌛ 3分判定待ち"
                            "ENTRY_RATE_MISSED" -> "⚠ ENTRY取得失敗"
                            "JUDGE_RATE_MISSED" -> "⚠ 判定取得失敗"
                            "ENTRY_RATE_MISSING" -> "⚠ ENTRY不明"
                            "LEGACY_NO_OUTCOME" -> "旧履歴・結果なし"
                            else -> if (h.decision == "SKIP" && h.resultStatus in setOf("WIN", "LOSE")) {
                                "SKIP参考 ${h.resultStatus}"
                            } else h.resultStatus
                        }

                        Box(
                            Modifier.fillMaxWidth()
                                .border(1.dp, statusColor.copy(alpha = 0.72f), RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(cardTop, cardBottom)), RoundedCornerShape(14.dp))
                                .clickable { onOpenChart(h) }
                        ) {
                            if (isWin) {
                                Image(
                                    painter = painterResource(R.drawable.history_reimu_win),
                                    contentDescription = null,
                                    modifier = Modifier.align(Alignment.BottomEnd).size(118.dp),
                                    contentScale = ContentScale.Crop,
                                    alpha = 0.82f
                                )
                            } else if (isLose) {
                                Image(
                                    painter = painterResource(R.drawable.history_youmu_lose),
                                    contentDescription = null,
                                    modifier = Modifier.align(Alignment.BottomEnd).width(145.dp).height(105.dp),
                                    contentScale = ContentScale.Crop,
                                    alpha = 0.78f
                                )
                            }

                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(34.dp)
                                            .background(directionColor.copy(alpha = 0.18f), RoundedCornerShape(17.dp))
                                            .border(1.dp, directionColor.copy(alpha = 0.75f), RoundedCornerShape(17.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(if (h.instrument == "BTCJPY") "₿" else if (h.direction == "HIGH") "↗" else "↘", color = directionColor, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.width(9.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(h.instrument, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                h.direction,
                                                color = directionColor,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                modifier = Modifier
                                                    .background(directionColor.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
                                                    .border(1.dp, directionColor.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                        Text(
                                            "${h.source} / ${h.grade} / ${h.regime}",
                                            fontSize = 10.sp,
                                            color = ScanMuted
                                        )
                                    }
                                    Text(
                                        statusText,
                                        color = statusColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        modifier = Modifier
                                            .background(statusColor.copy(alpha = 0.10f), RoundedCornerShape(8.dp))
                                            .border(1.dp, statusColor.copy(alpha = 0.72f), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 9.dp, vertical = 6.dp)
                                    )
                                }

                                Spacer(Modifier.height(9.dp))
                                Box(Modifier.fillMaxWidth().height(1.dp).background(statusColor.copy(alpha = 0.20f)))
                                Spacer(Modifier.height(8.dp))

                                Text("スキャン  ${formatJstTime(h.atJst)}", fontSize = 10.sp, color = ScanMuted)
                                Text(
                                    "${if (h.source == "MANUAL_1M") "ENTRY・市場参考" else "ENTRY(+10秒・市場参考)"}  ${formatJstTime(h.entryTimeJst)}  ${h.entryRate?.let(::formatPrice) ?: "—"}",
                                    fontSize = 11.sp,
                                    color = ScanText
                                )
                                Text(
                                    "${if (h.source.contains("1M")) "1分後" else "3分後"}・市場参考  ${formatJstTime(h.judgeTimeJst)}  ${h.judgeRate?.let(::formatPrice) ?: "—"}",
                                    fontSize = 11.sp,
                                    color = ScanText
                                )

                                if (h.entryRateSource.isNotBlank() || h.judgeRateSource.isNotBlank()) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(
                                        "ENTRY: ${h.entryRateSource.ifBlank { "—" }} / 判定: ${h.judgeRateSource.ifBlank { "—" }}",
                                        fontSize = 8.sp,
                                        color = Color(0xFF8FA6C7)
                                    )
                                    Text(
                                        "取得遅延 ENTRY=${h.entryCaptureDelayMs?.let { "${it}ms" } ?: "—"} / 判定=${h.judgeCaptureDelayMs?.let { "${it}ms" } ?: "—"}  " +
                                            "provider age ENTRY=${h.entryProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"} / 判定=${h.judgeProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"}",
                                        fontSize = 8.sp,
                                        color = Color(0xFF7186A7)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistorySummaryTile(
    modifier: Modifier,
    title: String,
    value: String,
    accent: Color,
    icon: String
) {
    Column(
        modifier
            .border(1.dp, accent.copy(alpha = 0.72f), RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.14f), Color(0xCC09142B))
                ),
                RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 7.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, color = accent, fontSize = 17.sp)
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun BottomBar(tab: Tab, select: (Tab) -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A1022), Color(0xFF26102B), Color(0xFF0A1022))))
            .windowInsetsPadding(WindowInsets.navigationBars).height(66.dp)
            .border(1.dp, Color(0x55FF4F91))
    ) {
        BottomItem("✿", "予測", tab == Tab.Prediction) { select(Tab.Prediction) }
        BottomItem("⌁", "チャート", tab == Tab.Chart) { select(Tab.Chart) }
        BottomItem("◉", "通貨強弱", tab == Tab.Strength) { select(Tab.Strength) }
        BottomItem("▤", "履歴", tab == Tab.History) { select(Tab.History) }
        BottomItem("≡", "状態", tab == Tab.Status) { select(Tab.Status) }
    }
}

@Composable
private fun RowScope.BottomItem(icon: String, text: String, active: Boolean, click: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable(onClick = click)
            .background(if (active) Brush.verticalGradient(listOf(Color(0x884F173E), Color(0xAA9C1E53))) else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = if (active) Color(0xFFFFB6D0) else Color.White, fontSize = 22.sp)
        Text(text, color = Color.White, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp, maxLines = 1)
        if (active) Box(Modifier.padding(top = 3.dp).height(3.dp).width(36.dp).background(ScanPink, RoundedCornerShape(2.dp)))
    }
}

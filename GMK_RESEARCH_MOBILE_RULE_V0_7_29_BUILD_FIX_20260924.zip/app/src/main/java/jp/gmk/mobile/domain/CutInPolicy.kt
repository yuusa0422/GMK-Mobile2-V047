package jp.gmk.mobile.domain

enum class CutInAdvantageSignal { WIN_ADVANTAGE, LOSE_ADVANTAGE }

/**
 * Pure policy used by the UI cut-in controller.
 * No Android/Compose dependency so the timing and direction rules can be regression-tested.
 */
object CutInPolicy {
    fun leadMs(isOneMinute: Boolean): Long = if (isOneMinute) 15_000L else 30_000L

    fun isInAdvantageWindow(remainingMs: Long, isOneMinute: Boolean): Boolean {
        val lead = leadMs(isOneMinute)
        return remainingMs in 1L..(lead + 1_500L)
    }

    fun advantageSignal(direction: String, entryPrice: Double, currentPrice: Double): CutInAdvantageSignal? {
        if (!entryPrice.isFinite() || !currentPrice.isFinite() || entryPrice <= 0.0 || currentPrice <= 0.0) return null
        val favorable = when (direction) {
            "HIGH" -> currentPrice > entryPrice
            "LOW" -> currentPrice < entryPrice
            else -> return null
        }
        // Directional draw/equality is LOSE by GMK result specification.
        return if (favorable) CutInAdvantageSignal.WIN_ADVANTAGE else CutInAdvantageSignal.LOSE_ADVANTAGE
    }
}

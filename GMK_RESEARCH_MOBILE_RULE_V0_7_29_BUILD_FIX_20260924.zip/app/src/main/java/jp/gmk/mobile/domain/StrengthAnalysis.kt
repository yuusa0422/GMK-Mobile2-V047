package jp.gmk.mobile.domain

/**
 * Returns synchronized relative currency scores from available JPY crosses.
 * JPY is the common reference; cross-pair values are relative estimates, not direct quotes.
 */
fun currencyRelativeStrength(data: Map<String, List<Candle>>): Map<String, Double> {
    val pairs = mapOf("USDJPY" to "USD", "EURJPY" to "EUR", "GBPJPY" to "GBP", "AUDJPY" to "AUD", "NZDJPY" to "NZD")
    val fxRows = pairs.keys.mapNotNull { pair -> data[pair]?.takeIf { it.size >= 2 } }
    val btcRow = data["BTCJPY"]?.takeIf { it.size >= 2 }
    val commonRows = fxRows + listOfNotNull(btcRow)
    if (commonRows.isEmpty()) return emptyMap()
    // Every currency must cover the same interval. BTC has shorter provider
    // history for some timeframes, so leaving it out here compared a few days
    // of BTC movement with months of FX movement.
    val commonStart = commonRows.maxOf { it.first().timeEpochMs }
    val commonEnd = commonRows.minOf { it.last().timeEpochMs }
    if (commonEnd <= commonStart) return emptyMap()

    fun alignedMove(candles: List<Candle>?): Double? {
        if (candles == null) return null
        val first = candles.firstOrNull { it.timeEpochMs >= commonStart } ?: return null
        val last = candles.lastOrNull { it.timeEpochMs <= commonEnd } ?: return null
        if (last.timeEpochMs <= first.timeEpochMs || first.open <= 0.0 || !first.open.isFinite() || !last.close.isFinite()) return null
        return (last.close / first.open - 1.0) * 100.0
    }

    val moves = pairs.mapNotNull { (pair, currency) -> alignedMove(data[pair])?.let { currency to it } }.toMap()
    val allMoves = moves.toMutableMap()
    btcRow?.let { alignedMove(it)?.let { move -> allMoves["BTC"] = move } }
    if (moves.isEmpty()) return emptyMap()
    val yenScore = -moves.values.average() / 2.0
    val result = moves.mapValues { (_, move) -> move + yenScore }.toMutableMap()
    result["JPY"] = yenScore
    allMoves["BTC"]?.let { result["BTC"] = it + yenScore }
    return result
}

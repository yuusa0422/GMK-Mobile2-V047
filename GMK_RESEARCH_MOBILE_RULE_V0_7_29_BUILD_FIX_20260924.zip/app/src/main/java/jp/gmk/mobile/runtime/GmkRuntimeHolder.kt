package jp.gmk.mobile.runtime

import android.app.Application
import jp.gmk.mobile.ui.GmkViewModel

/**
 * Process-wide single runtime owner.
 * Both Activity UI and foreground service share exactly one GmkViewModel instance.
 * This prevents duplicate Yahoo/bitbank polling, duplicate schedulers, duplicate
 * pending-outcome workers, and SharedPreferences read/modify/write races.
 */
object GmkRuntimeHolder {
    @Volatile private var instance: GmkViewModel? = null

    fun get(app: Application): GmkViewModel =
        instance ?: synchronized(this) {
            instance ?: GmkViewModel(app).also { instance = it }
        }
}

package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Deterministic, on-device rule engine.
 * No LLM, no server-side model and no remote inference are used.
 *
 * The engine consumes completed 1-minute candles and produces a 3-minute
 * directional score for each of the six mobile instruments. The score is a
 * fixed weighted combination of momentum, EMA spread, RSI, Bollinger position,
 * recent candle impulse and volatility penalty.
 */
class LocalRuleEngine {
    private val jst = ZoneId.of("Asia/Tokyo")
    private val fmt = DateTimeFormatter.ISO_OFFSET_DATE_TIME

    fun scan(
        candlesByInstrument: Map<String, List<Candle>>,
        source: String,
        now: ZonedDateTime = ZonedDateTime.now(jst),
        entryOverride: ZonedDateTime? = null
    ): ScanResult {
        val warnings = mutableListOf<String>()
        val raw = mutableListOf<RawCandidate>()
        val order = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")

        for (instrument in order) {
            val candles = candlesByInstrument[instrument].orEmpty()
                .filter { it.close > 0.0 && it.high > 0.0 && it.low > 0.0 }
                .sortedBy { it.timeEpochMs }
                .takeLast(120)
            if (candles.size < 21) {
                warnings += "$instrument: 1分足不足(${candles.size}/21)"
                continue
            }
            raw += scoreInstrument(instrument, candles)
        }

        val entry = entryOverride ?: nextFiveMinuteBoundary(now)

        // v0.7.8 production order: classify all six candidates first, apply any
        // validated historical direction reversal, then choose TOP1 by final rank.
        // E is the only SKIP rank. No AI/ML inference is used.
        data class Classified(val raw: RawCandidate, val policy: FinalRankPolicy.Match, val effectiveScore: Double)

        val classified = raw.map { x ->
            val direction = if (x.score >= 0.0) "HIGH" else "LOW"
            val p = FinalRankPolicy.classifyBase(
                FinalRankPolicy.Features(
                    instrument = x.instrument,
                    regime = x.regime,
                    direction = direction,
                    score = x.score,
                    confidence = x.confidence,
                    rsi14 = x.rsi14,
                    agreement = x.agreement,
                    efficiency = x.efficiency,
                    emaGapAtr = x.emaGapAtr,
                    regimeConfidence = x.regimeConfidence
                ),
                entry.hour
            )
            Classified(x, p, if (p.reverse) -x.score else x.score)
        }

        val ordered = classified.sortedWith(
            compareByDescending<Classified> { FinalRankPolicy.rankPriority(it.policy.rank) }
                .thenByDescending { it.policy.minPeriodWinRate }
                .thenByDescending { it.policy.expectedWinRate }
                .thenByDescending { it.raw.confidence }
                .thenByDescending { abs(it.effectiveScore) }
                .thenBy { it.raw.instrument }
        )

        val ranked = ordered.mapIndexed { idx, c ->
            val x = c.raw
            val baseDirection = if (x.score >= 0.0) "HIGH" else "LOW"
            val p = if (idx == 0) FinalRankPolicy.classify(
                FinalRankPolicy.Features(
                    instrument = x.instrument,
                    regime = x.regime,
                    direction = baseDirection,
                    score = x.score,
                    confidence = x.confidence,
                    rsi14 = x.rsi14,
                    agreement = x.agreement,
                    efficiency = x.efficiency,
                    emaGapAtr = x.emaGapAtr,
                    regimeConfidence = x.regimeConfidence
                ), entry.hour
            ) else c.policy
            val reasons = buildList {
                addAll(x.reasons)
                if (p.ruleId >= 0) {
                    add("V076_FIXED_RULE id=${p.ruleId} n=${p.sampleSize} min=${"%.1f".format(p.minPeriodWinRate * 100.0)}% avg=${"%.1f".format(p.expectedWinRate * 100.0)}%")
                } else {
                    add("V076_FIXED_RULE no-stable-pattern -> E/SKIP")
                }
                if (p.reverse) add("V076_DIRECTION_REVERSE historical losing-pattern inversion")
                if (entry.hour !in 9..22) add("V076_TIME_GATE outside 09:00-23:00 -> E/SKIP")
            }
            ScanCandidate(
                rank = idx + 1,
                instrument = x.instrument,
                display = displayName(x.instrument),
                direction = if ((if (p.reverse) -x.score else x.score) >= 0.0) "HIGH" else "LOW",
                grade = p.rank,
                probability = p.expectedWinRate,
                decision = if (isEntryGrade(p.rank)) "ENTRY" else "SKIP",
                score = if (p.reverse) -x.score else x.score,
                regime = x.regime,
                regimeConfidence = x.regimeConfidence,
                reasons = reasons
            )
        }

        // Do not apply ResearchRuleIdPolicy here. That table was fitted on
        // 2026-09-02..22 and is research-only; using it in the live path leaks
        // September outcomes into rank, direction and ENTRY selection. Live
        // decisions use only FinalRankPolicy's production replay rules.

        val judge = entry.plusMinutes(3)
        return ScanResult(
            scanId = "local-${UUID.randomUUID()}",
            atJst = now.format(fmt),
            entryTimeJst = entry.format(fmt),
            judgeTimeJst = judge.format(fmt),
            candidates = ranked,
            warnings = warnings,
            source = source
        )
    }

    private fun scoreInstrument(instrument: String, candles: List<Candle>): RawCandidate {
        val closes = candles.map { it.close }
        val last = closes.last()
        val ret1 = timedReturn(candles, 1)
        val mom3 = timedReturn(candles, 3)
        val mom5 = timedReturn(candles, 5)
        val ema8 = ema(closes, 8)
        val ema21 = ema(closes, 21)
        val emaSpread = if (last == 0.0) 0.0 else (ema8 - ema21) / last
        val rsi14 = rsi(closes, 14)
        val bb = bollingerZ(closes, 20)
        val atrPct = atrPct(candles, 14)
        val body = if (last == 0.0) 0.0 else (candles.last().close - candles.last().open) / last

        val momentumTerm = 0.26 * tanh(mom3 / 0.0018) + 0.18 * tanh(mom5 / 0.0027)
        val trendTerm = 0.24 * tanh(emaSpread / 0.0014)
        val rsiTerm = 0.12 * ((rsi14 - 50.0) / 25.0).coerceIn(-1.0, 1.0)
        val bbTerm = 0.10 * tanh(bb / 1.2)
        val impulseTerm = 0.10 * tanh((0.55 * ret1 + 0.45 * body) / 0.0012)
        val baseScore = (momentumTerm + trendTerm + rsiTerm + bbTerm + impulseTerm).coerceIn(-1.0, 1.0)

        // --- Dedicated market-regime classifier ------------------------------------
        // Uses completed candles only. No future information.
        //
        // TREND_UP / TREND_DOWN:
        //   EMA separation and slope normalized by ATR, efficiency ratio and
        //   directional persistence must agree.
        // RANGE:
        //   low EMA separation/slope, low efficiency and contracted Bollinger width.
        // CHOPPY:
        //   frequent one-minute direction flips + low efficiency / unstable EMA sign.
        //
        // The thresholds are intentionally conservative: ambiguous transitions become
        // CHOPPY/RANGE instead of being forced into a trend label.
        val regime = classifyRegime(candles)

        // --- Trend-switch hard guard ------------------------------------------------
        // A confirmed EMA8/EMA21 regime flip must never be entered counter-trend.
        // During the transition itself, if momentum/impulse do not confirm the new
        // direction, confidence is hard-capped to D so the candidate becomes SKIP.
        val prevCloses = closes.dropLast(3)
        val prevEma8 = if (prevCloses.size >= 21) ema(prevCloses, 8) else ema8
        val prevEma21 = if (prevCloses.size >= 21) ema(prevCloses, 21) else ema21
        val prevSpread = if (prevCloses.isNotEmpty() && prevCloses.last() != 0.0)
            (prevEma8 - prevEma21) / prevCloses.last() else emaSpread

        fun sign(x: Double, eps: Double = 0.00005): Int = when {
            x > eps -> 1
            x < -eps -> -1
            else -> 0
        }

        val currentTrend = sign(emaSpread)
        val previousTrend = sign(prevSpread)
        val recentSwitchWindowContinuous = isTailContinuous(candles, 4)
        val trendSwitched = recentSwitchWindowContinuous &&
            currentTrend != 0 && previousTrend != 0 && currentTrend != previousTrend
        val scoreDirection = sign(baseScore, 0.0)
        val trendConfirmVotes = listOf(mom3, mom5, ret1, body)
            .count { sign(it, 0.0) == currentTrend }
        val counterTrendOnSwitch = trendSwitched && scoreDirection != 0 && scoreDirection != currentTrend
        val unconfirmedSwitch = trendSwitched && trendConfirmVotes < 3

        // Regime hard guards.
        val regimeCounterTrend =
            (regime.name == "TREND_UP" && scoreDirection < 0) ||
            (regime.name == "TREND_DOWN" && scoreDirection > 0)

        // CHOPPY is explicitly non-entry. This prevents whipsaw chasing.
        val choppyGuard = regime.name == "CHOPPY"

        // RANGE: do not chase the outer Bollinger edge in the same outward direction.
        // This is a defensive cap, not a forced reversal.
        val rangeBreakoutChase =
            regime.name == "RANGE" &&
            ((bb >= 1.35 && scoreDirection > 0) || (bb <= -1.35 && scoreDirection < 0))

        // Very high one-minute volatility reduces confidence but never reverses direction.
        val volatilityPenalty = ((atrPct - 0.0012) / 0.0040).coerceIn(0.0, 0.16)
        val agreement = listOf(mom3, mom5, emaSpread, rsi14 - 50.0, bb, body)
            .count { if (baseScore >= 0.0) it > 0.0 else it < 0.0 } / 6.0
        var confidence = (0.50 + abs(baseScore) * 0.31 + agreement * 0.08 - volatilityPenalty)
            .coerceIn(0.50, 0.88)

        // Hard D/SKIP is reserved for an actual counter-trend candidate
        // immediately after a confirmed EMA trend switch.
        if (counterTrendOnSwitch) {
            confidence = min(confidence, 0.54)
        }

        // A weakly confirmed switch is uncertainty, not an automatic D.
        // Penalize only, so REGIME/switch logic does not mass-produce SKIP.
        if (unconfirmedSwitch && !counterTrendOnSwitch) {
            confidence = (confidence - 0.04).coerceIn(0.50, 0.88)
        }

        // Established-trend counter direction is a penalty, not an automatic skip.
        // Strong independent evidence can still remain ENTRY.
        fun cautionPenalty(value: Double, penalty: Double, upper: Double = 0.88): Double {
            val reduced = (value - penalty).coerceIn(0.50, upper)
            // REGIME caution must not be the sole reason an existing ENTRY becomes D.
            return if (value >= 0.55) max(0.55, reduced) else reduced
        }

        if (regimeCounterTrend && !trendSwitched) {
            val penalty = 0.03 + 0.04 * regime.confidence.coerceIn(0.0, 1.0)
            confidence = cautionPenalty(confidence, penalty)
        }

        // CHOPPY is uncertainty information, not a blanket D.
        if (choppyGuard) {
            confidence = cautionPenalty(confidence, 0.05, 0.64)
        }

        // RANGE outer-edge chase gets a small penalty only.
        if (rangeBreakoutChase) {
            confidence = cautionPenalty(confidence, 0.03)
        }

        val direction = if (baseScore >= 0.0) "上" else "下"
        val reasons = buildList {
            add("REGIME ${regime.name} ${(regime.confidence * 100).toInt()}%")
            add("REGIME trend=${(regime.trendEvidence * 100).toInt()} range=${(regime.rangeEvidence * 100).toInt()} chop=${(regime.choppyEvidence * 100).toInt()}")
            add("ER12 ${"%.2f".format(regime.efficiencyRatio)} ALT ${"%.2f".format(regime.alternationRatio)}")
            add("EMA gap/ATR ${"%.2f".format(regime.emaGapAtr)} slope/ATR ${"%.2f".format(regime.emaSlopeAtr)}")
            add("3分モメンタム ${pct(mom3)}")
            add("5分モメンタム ${pct(mom5)}")
            add("EMA8-21 ${pct(emaSpread)}")
            add("RSI14 ${"%.1f".format(rsi14)}")
            add("BB位置 ${"%.2f".format(bb)}σ")
            add("${direction}方向一致 ${(agreement * 100).toInt()}%")
            if (trendSwitched) add("TREND_SWITCH ${if (currentTrend > 0) "UP" else "DOWN"} confirm=$trendConfirmVotes/4")
            if (counterTrendOnSwitch) add("TREND_SWITCH_GUARD: 新トレンド逆方向のためD/SKIP")
            if (unconfirmedSwitch && !counterTrendOnSwitch) add("TREND_SWITCH_CAUTION: 切替確認不足は減点のみ")
            if (regimeCounterTrend && !trendSwitched) add("REGIME_CAUTION: ${regime.name}逆方向は減点のみ")
            if (choppyGuard) add("REGIME_CAUTION: CHOPPYは信頼度減点のみ")
            if (rangeBreakoutChase) add("REGIME_CAUTION: RANGE外縁追随は軽減点")
            if (atrPct > 0.0030) add("高ボラ補正 -${"%.1f".format(volatilityPenalty * 100)}pt")
            if (instrument == "BTCJPY") add("BTCはFXよりボラ補正を重視")
        }

        return RawCandidate(
            instrument = instrument,
            score = baseScore,
            confidence = confidence,
            regime = regime.name,
            regimeConfidence = regime.confidence,
            rsi14 = rsi14,
            atrPct = atrPct,
            agreement = agreement,
            efficiency = regime.efficiencyRatio,
            emaGapAtr = regime.emaGapAtr,
            reasons = reasons
        )
    }

    private fun classifyRegime(candles: List<Candle>): RegimeInfo {
        val closes = candles.map { it.close }
        val last = closes.last()
        val atrAbs = max(atrAbs(candles, 14), max(last * 1e-8, 1e-12))

        val ema8Now = ema(closes, 8)
        val ema21Now = ema(closes, 21)
        val prev3 = closes.dropLast(3)
        val ema8Prev3 = if (prev3.size >= 8) ema(prev3, 8) else ema8Now

        val emaGapAtr = abs(ema8Now - ema21Now) / atrAbs
        val emaSlopeAtr = abs(ema8Now - ema8Prev3) / atrAbs

        val contiguous = continuousTail(candles).map { it.close }
        val recent = contiguous.takeLast(13)
        val diffs = recent.zipWithNext { a, b -> b - a }
        val travel = diffs.sumOf { abs(it) }
        val net = if (recent.size >= 2) abs(recent.last() - recent.first()) else 0.0
        val efficiency = if (travel <= 1e-12) 0.0 else (net / travel).coerceIn(0.0, 1.0)

        val nonZeroSigns = diffs.mapNotNull {
            when {
                it > 0.0 -> 1
                it < 0.0 -> -1
                else -> null
            }
        }
        val flips = nonZeroSigns.zipWithNext().count { (a, b) -> a != b }
        val alternation = if (nonZeroSigns.size <= 1) 0.0
            else flips.toDouble() / (nonZeroSigns.size - 1).toDouble()

        val netDirection = when {
            recent.last() > recent.first() -> 1
            recent.last() < recent.first() -> -1
            else -> 0
        }
        val directionalPersistence = if (nonZeroSigns.isEmpty() || netDirection == 0) 0.0
            else nonZeroSigns.count { it == netDirection }.toDouble() / nonZeroSigns.size.toDouble()

        val currentBbWidth = bollingerWidthPct(closes, 20)
        val olderCloses = closes.dropLast(10)
        val previousBbWidth = if (olderCloses.size >= 20) bollingerWidthPct(olderCloses, 20) else currentBbWidth
        val bbExpansion = if (previousBbWidth <= 1e-12) 1.0
            else (currentBbWidth / previousBbWidth).coerceIn(0.25, 4.0)

        val emaSigns = mutableListOf<Int>()
        val start = max(22, closes.size - 12)
        for (end in start..closes.size) {
            val prefix = closes.take(end)
            if (prefix.size < 21) continue
            val gap = ema(prefix, 8) - ema(prefix, 21)
            emaSigns += when {
                gap > atrAbs * 0.05 -> 1
                gap < -atrAbs * 0.05 -> -1
                else -> 0
            }
        }
        val stableSigns = emaSigns.filter { it != 0 }
        val emaSignFlips = stableSigns.zipWithNext().count { (a, b) -> a != b }
        val emaFlipRatio = if (stableSigns.size <= 1) 0.0
            else emaSignFlips.toDouble() / (stableSigns.size - 1).toDouble()

        fun unit(x: Double): Double = x.coerceIn(0.0, 1.0)

        val trendEvidence = (
            0.28 * unit(emaGapAtr / 0.90) +
            0.24 * unit(emaSlopeAtr / 0.80) +
            0.24 * efficiency +
            0.16 * directionalPersistence +
            0.08 * unit((bbExpansion - 0.90) / 0.50)
        ).coerceIn(0.0, 1.0)

        val choppyEvidence = (
            0.38 * alternation +
            0.27 * (1.0 - efficiency) +
            0.20 * emaFlipRatio +
            0.15 * unit(1.0 - emaGapAtr / 0.65)
        ).coerceIn(0.0, 1.0)

        val contraction = unit((1.15 - bbExpansion) / 0.45)
        val rangeEvidence = (
            0.30 * unit(1.0 - emaGapAtr / 0.75) +
            0.22 * unit(1.0 - emaSlopeAtr / 0.65) +
            0.24 * (1.0 - efficiency) +
            0.14 * contraction +
            0.10 * unit(1.0 - emaFlipRatio)
        ).coerceIn(0.0, 1.0)

        val direction = when {
            ema8Now > ema21Now && (ema8Now - ema8Prev3) > 0.0 -> 1
            ema8Now < ema21Now && (ema8Now - ema8Prev3) < 0.0 -> -1
            else -> 0
        }

        val name = when {
            choppyEvidence >= 0.62 && choppyEvidence >= trendEvidence + 0.08 -> "CHOPPY"
            trendEvidence >= 0.60 && direction > 0 && directionalPersistence >= 0.55 -> "TREND_UP"
            trendEvidence >= 0.60 && direction < 0 && directionalPersistence >= 0.55 -> "TREND_DOWN"
            rangeEvidence >= 0.52 -> "RANGE"
            alternation >= 0.55 && efficiency <= 0.40 -> "CHOPPY"
            direction > 0 && trendEvidence >= 0.52 -> "TREND_UP"
            direction < 0 && trendEvidence >= 0.52 -> "TREND_DOWN"
            else -> "RANGE"
        }

        val chosen = when (name) {
            "TREND_UP", "TREND_DOWN" -> trendEvidence
            "CHOPPY" -> choppyEvidence
            else -> rangeEvidence
        }

        val second = listOf(trendEvidence, rangeEvidence, choppyEvidence)
            .sortedDescending()
            .getOrElse(1) { 0.0 }

        // Confidence reflects both winning evidence and separation from the runner-up.
        val confidence = (0.55 * chosen + 0.45 * unit(0.5 + (chosen - second)))
            .coerceIn(0.50, 0.95)

        return RegimeInfo(
            name = name,
            confidence = confidence,
            trendEvidence = trendEvidence,
            rangeEvidence = rangeEvidence,
            choppyEvidence = choppyEvidence,
            efficiencyRatio = efficiency,
            alternationRatio = alternation,
            emaGapAtr = emaGapAtr,
            emaSlopeAtr = emaSlopeAtr,
            bollingerExpansion = bbExpansion
        )
    }

    private fun bollingerWidthPct(values: List<Double>, period: Int): Double {
        val s = values.takeLast(period)
        if (s.isEmpty()) return 0.0
        val mean = s.average()
        if (mean == 0.0) return 0.0
        val variance = s.sumOf { (it - mean) * (it - mean) } / s.size
        val sd = sqrt(max(variance, 1e-16))
        return (4.0 * sd) / abs(mean)
    }

    private fun atrAbs(candles: List<Candle>, period: Int): Double {
        val s = candles.takeLast(period + 1)
        val tr = mutableListOf<Double>()
        for (i in 1 until s.size) {
            val c = s[i]
            val prev = s[i - 1].close
            tr += max(c.high - c.low, max(abs(c.high - prev), abs(c.low - prev)))
        }
        return if (tr.isEmpty()) 0.0 else tr.average()
    }
    private fun isEntryGrade(grade: String): Boolean {
        return grade.uppercase() in setOf("S", "A", "B", "C")
    }

    private fun nextFiveMinuteBoundary(now: ZonedDateTime): ZonedDateTime {
        var x = now.withSecond(0).withNano(0)
        val add = (5 - (x.minute % 5)) % 5
        x = x.plusMinutes(add.toLong())
        if (!x.isAfter(now)) x = x.plusMinutes(5)
        return x
    }

    private fun isTailContinuous(candles: List<Candle>, count: Int): Boolean {
        if (count <= 1) return candles.isNotEmpty()
        val tail = candles.takeLast(count)
        if (tail.size < count) return false
        return tail.zipWithNext().all { (a, b) ->
            val gap = b.timeEpochMs - a.timeEpochMs
            gap in 1L..90_000L
        }
    }

    private fun continuousTail(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        var start = candles.lastIndex
        while (start > 0) {
            val gap = candles[start].timeEpochMs - candles[start - 1].timeEpochMs
            if (gap !in 1L..90_000L) break
            start--
        }
        return candles.subList(start, candles.size)
    }

    private fun timedReturn(candles: List<Candle>, barsBack: Int): Double {
        if (barsBack <= 0 || candles.size <= barsBack) return 0.0
        val tail = candles.takeLast(barsBack + 1)
        if (tail.size < barsBack + 1) return 0.0
        if (!tail.zipWithNext().all { (a, b) ->
                val gap = b.timeEpochMs - a.timeEpochMs
                gap in 1L..90_000L
            }) return 0.0
        return safeReturn(tail.last().close, tail.first().close)
    }

    private fun safeReturn(a: Double, b: Double): Double = if (b == 0.0) 0.0 else a / b - 1.0

    private fun ema(values: List<Double>, period: Int): Double {
        val slice = values.takeLast(max(period * 4, period))
        val alpha = 2.0 / (period + 1.0)
        var out = slice.first()
        for (i in 1 until slice.size) out = alpha * slice[i] + (1.0 - alpha) * out
        return out
    }

    private fun rsi(values: List<Double>, period: Int): Double {
        val s = values.takeLast(period + 1)
        var gains = 0.0
        var losses = 0.0
        for (i in 1 until s.size) {
            val d = s[i] - s[i - 1]
            if (d >= 0.0) gains += d else losses -= d
        }
        if (losses == 0.0) return if (gains > 0.0) 100.0 else 50.0
        val rs = (gains / period) / (losses / period)
        return 100.0 - 100.0 / (1.0 + rs)
    }

    private fun bollingerZ(values: List<Double>, period: Int): Double {
        val s = values.takeLast(period)
        val mean = s.average()
        val variance = s.sumOf { (it - mean) * (it - mean) } / s.size
        val sd = sqrt(max(variance, 1e-16))
        return (s.last() - mean) / sd
    }

    private fun atrPct(candles: List<Candle>, period: Int): Double {
        val s = candles.takeLast(period + 1)
        val tr = mutableListOf<Double>()
        for (i in 1 until s.size) {
            val c = s[i]
            val prev = s[i - 1].close
            tr += max(c.high - c.low, max(abs(c.high - prev), abs(c.low - prev)))
        }
        val atr = if (tr.isEmpty()) 0.0 else tr.average()
        return atr / max(s.last().close, 1e-12)
    }

    private fun pct(x: Double): String = "%+.3f%%".format(x * 100.0)

    private fun displayName(x: String): String = when (x) {
        "USDJPY" -> "米ドル / 円"
        "EURJPY" -> "ユーロ / 円"
        "GBPJPY" -> "ポンド / 円"
        "AUDJPY" -> "豪ドル / 円"
        "NZDJPY" -> "NZドル / 円"
        "BTCJPY" -> "ビットコイン / 円"
        else -> x
    }

    private data class RawCandidate(
        val instrument: String,
        val score: Double,
        val confidence: Double,
        val regime: String,
        val regimeConfidence: Double,
        val rsi14: Double,
        val atrPct: Double,
        val agreement: Double,
        val efficiency: Double,
        val emaGapAtr: Double,
        val reasons: List<String>
    )

    private data class RegimeInfo(
        val name: String,
        val confidence: Double,
        val trendEvidence: Double,
        val rangeEvidence: Double,
        val choppyEvidence: Double,
        val efficiencyRatio: Double,
        val alternationRatio: Double,
        val emaGapAtr: Double,
        val emaSlopeAtr: Double,
        val bollingerExpansion: Double
    )
}

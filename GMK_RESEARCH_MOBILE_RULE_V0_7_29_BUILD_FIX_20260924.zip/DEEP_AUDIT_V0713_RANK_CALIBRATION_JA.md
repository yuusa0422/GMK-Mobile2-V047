# GMK MOBILE RULE v0.7.13 Research Rank Calibration

更新日: 2026-09-23

## 目的
- v0.7.12研究版のENTRY選択・方向反転は変更しない。
- S/A/B/C対象は100% ENTRYを維持する。
- ランク表示のみ、選択に使用している rule-id quality に基づき再校正する。

## ランク境界
- S: quality >= 0.640
- A: 0.600 <= quality < 0.640
- B: 0.545 <= quality < 0.600
- C: quality < 0.545

## 2026-09 Replay
- S/A/B/C対象ENTRY: 2,249 / 2,249 = 100%
- WIN: 1,255
- LOSE: 888
- DRAW: 106
- 勝率(WIN/(WIN+LOSE)): 58.56%

### ランク別
- S: 185 entry / 175 scored / 133W 42L / 76.00%
- A: 271 entry / 262 scored / 175W 87L / 66.79%
- B: 643 entry / 608 scored / 362W 246L / 59.54%
- C: 1,150 entry / 1,098 scored / 585W 513L / 53.28%

## 注意
- 本版は2026年9月データを使用して探索・再校正した研究版であり、9月はOOSではない。
- 次の完全未使用期間で固定条件のまま検証すること。

# GMK MOBILE RULE v0.7.25 Runtime Hardening / Full Audit

更新日: 2026-09-23

## 結論
v0.7.23 を基準に、AUTO境界、履歴永続化、結果追跡、Yahoo通信、再起動復旧、手動/1分時刻契約、カットイン、Androidバックグラウンド動作を再監査し、追加の実害バグを修正した。
判定ルールの研究ポリシー自体は変更していない。

## 今回の主要修正

1. 手動3分 +10秒のナノ秒切り捨てを撤去
   - `LocalRuleEngine` の `entryOverride?.withNano(0)` を廃止。
   - ボタン押下時に固定したENTRY時刻を最後まで使用。
   - Coroutine開始遅延によるENTRY時刻後ズレと23:00越境レースを防止。

2. スキャン履歴時刻を実際の開始時刻へ統一
   - 1分/3分とも、データ取得完了時刻ではなくスキャン開始時刻を `atJst` として記録。

3. 履歴復旧完了前のスキャン競合を防止
   - 大容量履歴ロードをI/Oスレッドへ移動。
   - 復旧完了前はAUTO/手動スキャンを開始しない。

4. AUTO OFFでも手動ENTRY/JUDGE追跡を維持
   - pending結果またはactive outcome jobがある間はForeground Serviceを維持。
   - 再起動時もAUTO OFFのpending手動結果を復旧。

5. 結果追跡の復旧洪水を抑制
   - 起動時の追跡job生成数に上限。
   - provider取得同時数も別途制限。

6. 一時的な結果追跡例外で静かに停止する問題を修正
   - 予期しない例外を最大2回自動再試行。
   - 上限後はWAIT状態を放置せず明示的にMISSEDへ遷移。

7. 過去M1で復元可能なENTRY/JUDGE取得失敗を再回収
   - AUTO/1分の直近24時間 `ENTRY_RATE_MISSED/JUDGE_RATE_MISSED` を再起動時に再取得。
   - 任意秒quoteが必要なMANUAL 3分は対象外。

8. Yahoo直前競合を防止
   - T-10直前/有効windowは通常レートpollを予約停止。
   - :50.000ちょうどでも通常pollがYahoo枠を奪わないよう40〜54秒を明示予約。

9. YahooスキャンM1取得量を削減
   - 1日分から4時間窓へ縮小。
   - エンジンが使う直近120本は保持しつつpayload/解析負荷/429圧力を削減。

10. 履歴クラッシュジャーナルを別SharedPreferencesへ分離
    - 20,000件本体と同一XMLへの同期commitを廃止。
    - 直近16件を小型ジャーナルへ保存し、プロセスkill時の直近結果消失を防止。

11. 履歴バックアップ書込みを5分間隔へ制限
    - 毎mutationで巨大primary+backupを二重書込みする構造を廃止。
    - 最新状態は小型ジャーナルで保護。

12. 3分AUTOの時間外誤MISSEDを修正
    - 23:00等の運用時間外boundaryをsleep-missとして記録しない。

13. 1分AUTO境界の固定
    - schedulerが決めたENTRY boundaryをそのままengineへ渡す。
    - Coroutine開始が分境界を跨いでも次分へずれない。

14. Android 13+通知権限
    - POST_NOTIFICATIONSを宣言・初回要求。

15. 電池最適化/バックグラウンド制限の可視化
    - 診断ログと画面警告へ反映。

16. カットイン再構築を維持
    - 60枚すべて1600x500 (16:5)。
    - Fit表示、4状態、3分30秒/1分15秒、重複防止、診断ログを維持。

## 検証
- Functional contract: 113 / 113 PASS
- CutInPolicy pure Kotlin test: PASS
- 判定domain Kotlin compile: PASS
- AndroidManifest / res XML parse: PASS
- 画像decode: 66 / 66 PASS
- cut-in: 60 / 60、全画像1600x500一致
- drawable参照整合: PASS
- GitHub workflow: RESEARCH ZIP認識、compileDebugKotlin、assembleDebug工程を確認

## 重要な残余確認
この実行環境にはAndroid SDK/Gradle本体が無いため、Androidアプリ全体の `:app:compileDebugKotlin` と `:app:assembleDebug` はGitHub Actionsで最終実行する。
静的契約テストのPASSだけをAPKビルド成功とは扱わない。

## 研究版について
本ZIPは `0.7.25-research-runtime-hardening`。9月データ由来のResearchRuleIdPolicyを含むため、勝率を完全OOSと表現しない。

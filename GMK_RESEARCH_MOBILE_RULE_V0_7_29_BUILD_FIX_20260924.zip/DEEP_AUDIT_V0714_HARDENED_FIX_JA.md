# GMK MOBILE RULE v0.7.14 RESEARCH HARDENED 修正監査

更新日: 2026-09-23

## 位置づけ

この版は研究版。2026年9月データを使って作成された ResearchRuleIdPolicy を含むため、9月はOOSではない。
GitHub自動ビルドでは research を含むZIPを選択しないよう build.yml を強化した。

## 今回修正した重大事項

1. ランク契約を S>=75%, A>=65%, B>=58%, C>=53%, 53%未満=E/SKIP に統一。
2. 1分履歴の grade="C" 固定を廃止し、confidenceから同じ閾値でランク付け。
3. DRAWは実機仕様どおりLOSEとして公式勝率に含める。
4. ActivityとForeground Serviceを process-wide GmkRuntimeHolder の単一Runtimeへ統合。
5. Foreground Service停止時にshared runtimeをshutdownしないよう修正。
6. BOOT_COMPLETED Receiverを追加し、AUTO設定時は端末再起動後にForeground Serviceを復旧。
7. 1分AUTOの「3分AUTO OFFでも5分ごとに1回欠落」を修正。3分AUTO ON時のみ4/9/14/...分を譲る。
8. 手動1分/3分の運用時間を押下時刻ではなくENTRY targetで判定。
9. 3分手動ENTRY targetの+10秒をnano切り捨てせず厳密化。
10. T-10 current-second復帰を誤ってMISSEDにする判定を緩和。
11. AUTOは50..54秒のT-10 window内なら開始可能にし、50秒ジャスト依存を廃止。
12. 3分側M1連続性を90秒超gapでfail-safeへ統一。
13. quote/candle乖離がFX>=0.5% / BTC>=1.5%ならwarningのみで続行せず、その通貨を除外して6/6 fail-safeへ。
14. ENTRY/JUDGE outcome quoteはtargetより前のprovider timestampを採用しない。
15. HistoryStore保持上限を200件から20,000件へ拡張。
16. UI上、TOP1以外のS/A/B/C候補は「ENTRY」ではなく「候補」と表示。
17. research ZIPをGitHubの最大versionCode自動選択から除外。

## 9月再計算（Dukascopy版データ、研究政策を使用）

ランク契約修正後:
- 全判定枠: 2,519
- S/A/B/C ENTRY: 1,231
- E/SKIP: 1,288
- 最終S/A/B/Cに対するENTRY率: 100%
- 全判定枠ベースENTRY率: 48.87%
- WIN: 739
- LOSE: 435
- DRAW: 57（公式集計ではLOSE）
- 公式勝率: 739 / 1,231 = 60.03%

ランク別（DRAW=LOSE）:
- S: 41件 / 32勝 / 78.05%
- A: 128件 / 90勝 / 70.31%
- B: 420件 / 269勝 / 64.05%
- C: 642件 / 348勝 / 54.21%

注意: これは9月を使って作ったResearchRuleIdPolicyの再計算であり、OOS勝率ではない。またFXデータは本番Yahooと異なるDukascopy版であり、最終本番性能の証明には使わない。

## テスト

- functional_contract_test.py: 35/35 PASS
- Kotlin domain compile: PASS

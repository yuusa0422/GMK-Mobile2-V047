# GMK 週末暗号資産 OHLCV 収集（2026年9–10月）

GitHub Actionsから取引所の公開APIを読み、1分足OHLCVをCSV.gzと原レスポンス付きZIP artifactに保存します。取引注文、シグナル、アプリの設定変更は行いません。APIキー・Secretsは不要です。

## 収集対象

| 出力銘柄 | データ源 | 内容 |
|---|---|---|
| BTCJPY | bitbank `btc_jpy` | BTC/JPY実配信1分足 |
| ETHJPY | bitbank `eth_jpy` | ETH/JPY実配信1分足 |
| XRPJPY | bitbank `xrp_jpy` | XRP/JPY実配信1分足 |
| BTCUSD | Coinbase Exchange `BTC-USD` | USDで表示したBTC価格の実配信1分足 |
| USDBTC | Coinbase `BTC-USD`から派生 | BTCUSD価格の逆数。独立した取引所ペアではない |

「USD/BTC」はCoinbaseで実際に取引される銘柄名ではありません。標準の商品ID `BTC-USD` を取得し、USDBTC列は価格の逆数 (`open=1/open`, `high=1/low`, `low=1/high`, `close=1/close`) として別系列にします。出来高は原市場と同じBTC単位と明記します。

bitbank公式ペア一覧ではBTC/JPY・ETH/JPY・XRP/JPYが有効ペアとして掲載されています。bitbankの1分足はUTC日付ごとのAPI分割です。Coinbaseの1リクエストは最大300本のため、collectorは300本以下に分割し、返却OHLC順を検証します。

## GitHubへの配置と実行

1. 空のGitHubリポジトリ、または既存リポジトリへ、このZIPの中身を配置します。ソース一式はリポジトリ直下でも `gmk_weekend_crypto_collector/` 配下でも構いません。
2. workflowは必ずリポジトリ直下の `.github/workflows/collect_weekend_crypto_data.yml` に配置します。workflowはソース位置を検出し、テスト数が0件なら取得処理へ進まず理由を表示します。
3. GitHubの **Actions → GMK weekend crypto candles (Sep-Oct 2026) → Run workflow** を開き、開始日 `2026-09-01`、終了日 `2026-10-10` で実行します。workflowが既定ブランチにある必要があります。
4. 実行完了後、Artifact `GMK_CRYPTO_1M_JST_2026-09-01_2026-10-10` をダウンロードします。GitHubはCSV、API原文、manifestを一つのZIPにまとめます。

## 出力・品質管理

- `GMK_CRYPTO_1M_JST_YYYYMMDD_YYYYMMDD.csv.gz`: 5系列のUTC/JST時刻・OHLCV。対象JST期間外、未来足、形成中の1分足を除外します。
- `raw/`: 各API応答。再検査用の原文です。
- `manifest.json`: URL/分割、HTTP状態、行数、SHA-256、各銘柄の欠損分数とカバレッジを記録。
- 欠損足は補間・埋め戻ししません。重複で価格が衝突した場合、異常なOHLCや過去パーティションの取得失敗がある場合はworkflowを失敗させます。最新UTC分割は未公開の可能性を警告として残します。
- workflowは手動起動のみ。GitHubに自動コミットせず、取引所に注文を出しません。Artifactは90日保持です。

## 重要

これはデータ取得キットです。データが取れることは、スマホ版がETH/XRPでスキャンすることや勝率が高いことの証明ではありません。JPY建てETH/XRPはBTCとは別に現行のKotlinルール、AI/ランク、ENTRY率、連敗を過去データで検証してからアプリへ追加してください。

公式仕様: bitbank [Public API](https://github.com/bitbankinc/bitbank-api-docs/blob/master/public-api.md) / [pairs](https://github.com/bitbankinc/bitbank-api-docs/blob/master/pairs.md); Coinbase [product candles](https://docs.cdp.coinbase.com/api-reference/exchange-api/rest-api/products/get-product-candles).

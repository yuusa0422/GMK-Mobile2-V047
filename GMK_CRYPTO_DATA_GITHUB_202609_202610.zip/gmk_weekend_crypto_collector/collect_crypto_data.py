#!/usr/bin/env python3
"""Collect Sep/Oct 2026 crypto OHLCV from public exchange APIs. No signals/trades."""
from __future__ import annotations
import argparse, csv, datetime as dt, gzip, hashlib, io, json, math, os, pathlib, time, urllib.error, urllib.parse, urllib.request
import re
from collections import defaultdict
from zoneinfo import ZoneInfo

UTC=dt.timezone.utc
JST=ZoneInfo("Asia/Tokyo")
BITBANK="https://public.bitbank.cc"
COINBASE="https://api.exchange.coinbase.com"
# USDBTC is a derived reciprocal view of the actual BTC-USD market, not a separate listing.
PAIRS={
    "BTCJPY":{"source":"bitbank","pair":"btc_jpy"},
    "ETHJPY":{"source":"bitbank","pair":"eth_jpy"},
    "XRPJPY":{"source":"bitbank","pair":"xrp_jpy"},
    "BTCUSD":{"source":"coinbase-exchange","pair":"BTC-USD"},
}
FIELDS=["instrument","source","source_pair","time_utc","time_jst","open","high","low","close","volume","volume_unit","derived","raw_key"]

class FetchError(RuntimeError): pass

class HTTPStatusError(FetchError):
    def __init__(self, status: int, url: str):
        self.status = status
        self.url = url
        super().__init__(f"HTTP {status}: {url}")

def parse_date(s:str)->dt.date:
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}",s):
        raise argparse.ArgumentTypeError("date must be YYYY-MM-DD")
    try: return dt.date.fromisoformat(s)
    except ValueError as e: raise argparse.ArgumentTypeError("date must be YYYY-MM-DD") from e

def validate_range(start:dt.date,end:dt.date)->None:
    if start>end: raise ValueError("start date must be on or before end date")
    if start.year!=2026 or end.year!=2026 or start.month not in (9,10) or end.month not in (9,10):
        raise ValueError("this collector is restricted to September–October 2026")
    if (end-start).days>60: raise ValueError("date range exceeds the 61-day safety limit")

def request_bytes(url:str, *, timeout:int=30, retries:int=5, pause:float=.25)->bytes:
    last=None
    for attempt in range(retries):
        req=urllib.request.Request(url,headers={"Accept":"application/json","User-Agent":"GMK-weekend-history-collector/1.0"})
        try:
            with urllib.request.urlopen(req,timeout=timeout) as response:
                body=response.read()
                if response.status!=200: raise FetchError(f"HTTP {response.status}: {url}")
                time.sleep(pause)
                return body
        except urllib.error.HTTPError as e:
            last=e
            if e.code not in (408,429,500,502,503,504): raise HTTPStatusError(e.code,url) from e
            try: wait=min(30.0,max(1.0,float(e.headers.get("Retry-After","1"))))
            except (TypeError,ValueError): wait=min(16.0,2.0**attempt)
        except (urllib.error.URLError,TimeoutError,ConnectionError) as e:
            last=e; wait=min(16.0,2.0**attempt)
        if attempt+1<retries: time.sleep(wait)
    if isinstance(last,urllib.error.HTTPError): raise HTTPStatusError(last.code,url) from last
    raise FetchError(f"request failed after {retries} attempts: {url}: {last}")

def _finite_positive(x)->float:
    v=float(x)
    if not math.isfinite(v) or v<=0: raise ValueError("non-finite/non-positive price")
    return v

def _bar(instrument,source,pair,ts_ms,ohlc,volume,raw_key,derived="false"):
    o,h,l,c=map(_finite_positive,ohlc);v=float(volume)
    if not math.isfinite(v) or v<0 or h<max(o,c) or l>min(o,c) or h<l:
        raise ValueError(f"invalid OHLCV: {instrument} {ts_ms}")
    stamp=dt.datetime.fromtimestamp(ts_ms/1000,UTC)
    return {"instrument":instrument,"source":source,"source_pair":pair,
      "time_utc":stamp.isoformat().replace("+00:00","Z"),"time_jst":stamp.astimezone(JST).isoformat(),
      "open":o,"high":h,"low":l,"close":c,"volume":v,"volume_unit":"base_asset",
      "derived":derived,"raw_key":raw_key}

def parse_bitbank(payload:bytes, instrument:str, pair:str, raw_key:str):
    doc=json.loads(payload);data=doc.get("data") or {}
    if doc.get("success")!=1: raise FetchError(f"bitbank returned success={doc.get('success')} data={data}")
    out=[]
    for group in data.get("candlestick",[]):
        for row in group.get("ohlcv",[]):
            if len(row)<6: raise FetchError("bitbank candle has fewer than six fields")
            out.append(_bar(instrument,"bitbank",pair,int(row[5]),row[:4],row[4],raw_key))
    return out

def parse_coinbase(payload:bytes, raw_key:str):
    rows=json.loads(payload)
    if not isinstance(rows,list): raise FetchError("Coinbase candle response is not an array")
    if len(rows)>300: raise FetchError(f"Coinbase returned {len(rows)} candles (limit 300)")
    out=[]
    for row in rows:
        if not isinstance(row,list) or len(row)<6: raise FetchError("Coinbase candle has invalid shape")
        # Coinbase order: [unix_seconds, low, high, open, close, volume].
        ts_ms=int(row[0])*1000
        out.append(_bar("BTCUSD","coinbase-exchange","BTC-USD",ts_ms,[row[3],row[2],row[1],row[4]],row[5],raw_key))
    return out

def add_inverse(rows):
    out=[]
    for r in rows:
        o,h,l,c=(float(r[k]) for k in ("open","high","low","close"))
        x=dict(r);x.update(instrument="USDBTC",source_pair="BTC-USD (reciprocal)",
          open=1/o,high=1/l,low=1/h,close=1/c,derived="reciprocal price; volume remains BTC base volume")
        out.append(x)
    return out

def _save_raw(path:pathlib.Path,body:bytes,relative_name:str):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
    return {"file":relative_name,"bytes":len(body),"sha256":hashlib.sha256(body).hexdigest()}

def collect(start:dt.date,end:dt.date,outdir:pathlib.Path, now:dt.datetime|None=None):
    validate_range(start,end);outdir.mkdir(parents=True,exist_ok=True)
    now=(now or dt.datetime.now(UTC)).astimezone(UTC)
    range_start=dt.datetime.combine(start,dt.time(0),JST).astimezone(UTC)
    range_end=min(dt.datetime.combine(end+dt.timedelta(days=1),dt.time(0),JST).astimezone(UTC),now.replace(second=0,microsecond=0))
    if range_end<=range_start: raise ValueError("selected range has no completed minutes yet")
    first_utc=range_start.date();last_utc=(range_end-dt.timedelta(milliseconds=1)).date()
    raw_meta=[];rows=[];warnings=[]
    for instrument in ("BTCJPY","ETHJPY","XRPJPY"):
        pair=PAIRS[instrument]["pair"];day=first_utc
        while day<=last_utc:
            key=day.strftime("%Y%m%d");url=f"{BITBANK}/{pair}/candlestick/1min/{key}";rawkey=f"raw/bitbank/{instrument}/{key}.json"
            path=outdir/rawkey
            try:
                body=request_bytes(url);meta=_save_raw(path,body,rawkey);raw_meta.append({**meta,"source":"bitbank","pair":pair,"utc_key":key,"request_url":url,"http_status":200})
                parsed=parse_bitbank(body,instrument,pair,rawkey);rows.extend(parsed)
            except HTTPStatusError as e:
                if day==now.date() and e.status==404:
                    warnings.append(f"{instrument} current UTC partition {key} not published yet (HTTP 404)")
                    raw_meta.append({"source":"bitbank","pair":pair,"utc_key":key,"http_status":404,"warning":"current partition may not yet be published"})
                else: raise FetchError(f"historical bitbank partition failed: {instrument}/{key}: HTTP {e.status}") from e
            except FetchError as e:
                # At UTC rollover the API can return success=0/code=10000 before its first bar.
                if day==now.date() and "success=0" in str(e):
                    warnings.append(f"{instrument} current UTC partition {key} not published yet ({e})")
                    raw_meta.append({"source":"bitbank","pair":pair,"utc_key":key,"http_status":200,"warning":str(e)})
                else: raise
            day+=dt.timedelta(days=1)
    # Coinbase permits at most 300 1-minute candles per response. Request <=300 aligned minutes.
    start_s=int(range_start.timestamp());end_s=int(range_end.timestamp());cursor=(start_s//60)*60;chunk=0
    while cursor<end_s:
        last_start=min(cursor+299*60,((end_s-1)//60)*60)
        params=urllib.parse.urlencode({"start":dt.datetime.fromtimestamp(cursor,UTC).isoformat().replace("+00:00","Z"),
             "end":dt.datetime.fromtimestamp(last_start,UTC).isoformat().replace("+00:00","Z"),"granularity":"60"})
        url=f"{COINBASE}/products/BTC-USD/candles?{params}";rawkey=f"raw/coinbase/BTC-USD/chunk_{chunk:03d}.json"
        body=request_bytes(url);meta=_save_raw(outdir/rawkey,body,rawkey);raw_meta.append({**meta,"source":"coinbase-exchange","pair":"BTC-USD","chunk":chunk,"request_url":url,"http_status":200})
        rows.extend(parse_coinbase(body,rawkey));cursor=last_start+60;chunk+=1
    # Restrict the published data to the requested JST date range and completed minutes only.
    low_ms=int(range_start.timestamp()*1000);high_ms=int(range_end.timestamp()*1000)
    rows=[r for r in rows if low_ms<=int(dt.datetime.fromisoformat(r["time_utc"].replace("Z","+00:00")).timestamp()*1000)<high_ms]
    byinstrument=defaultdict(dict)
    for r in rows:
        ts=int(dt.datetime.fromisoformat(r["time_utc"].replace("Z","+00:00")).timestamp()*1000)
        key=(r["instrument"],ts)
        # Duplicate chunk boundary rows must be identical; otherwise stop instead of choosing one.
        if ts in byinstrument[r["instrument"]] and byinstrument[r["instrument"]][ts]!=r:
            raise FetchError(f"conflicting duplicate candle: {r['instrument']} {r['time_utc']}")
        byinstrument[r["instrument"]][ts]=r
    unique=sorted((r for d in byinstrument.values() for r in d.values()),key=lambda x:(x["time_utc"],x["instrument"]))
    base_rows=[r for r in unique if r["instrument"]=="BTCUSD"]
    all_rows=sorted(unique+add_inverse(base_rows),key=lambda x:(x["time_utc"],x["instrument"]))
    expected=int((range_end-range_start).total_seconds()//60)
    coverage={}
    for sym in ("BTCJPY","ETHJPY","XRPJPY","BTCUSD","USDBTC"):
        srows=[r for r in all_rows if r["instrument"]==sym];times=[int(dt.datetime.fromisoformat(r["time_utc"].replace("Z","+00:00")).timestamp()//60) for r in srows]
        missing=max(0,expected-len(set(times)))
        gaps=sum(max(0,b-a-1) for a,b in zip(times,times[1:]))
        coverage[sym]={"rows":len(srows),"expected_minutes":expected,"missing_minutes":missing,
          "first_utc":srows[0]["time_utc"] if srows else None,"last_utc":srows[-1]["time_utc"] if srows else None,
          "internal_missing_minutes":gaps,"coverage_pct":round(100*len(set(times))/expected,4) if expected else 0,
          "missing_minutes_filled":0}
    for sym in ("BTCJPY","ETHJPY","XRPJPY","BTCUSD"):
        if coverage[sym]["rows"]==0: raise FetchError(f"no candles received for {sym}")
    data_path=outdir/f"GMK_CRYPTO_1M_JST_{start:%Y%m%d}_{end:%Y%m%d}.csv.gz"
    with data_path.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw,mode="wb",mtime=0) as zipped:
            with io.TextIOWrapper(zipped,encoding="utf-8",newline="") as text:
                writer=csv.DictWriter(text,fieldnames=FIELDS);writer.writeheader();writer.writerows(all_rows)
    manifest={"status":"PASS_WITH_WARNINGS" if warnings else "PASS","requested_jst":{"from":range_start.isoformat(),"through_exclusive":range_end.isoformat(),"start_date":start.isoformat(),"end_date_inclusive":end.isoformat()},
      "retrieved_at_utc":now.isoformat(),"granularity_seconds":60,"sources":{"bitbank":"public REST candlestick 1min; UTC YYYYMMDD partitions","coinbase":"Exchange public REST BTC-USD candles; 1min, <=300/request","USDBTC":"reciprocal derived from BTCUSD, not a separately listed market"},
      "instruments":coverage,"raw_response_count":len(raw_meta),"raw_responses":raw_meta,"warnings":warnings,
      "normalised_file":{"name":data_path.name,"bytes":data_path.stat().st_size,"sha256":hashlib.sha256(data_path.read_bytes()).hexdigest()},
      "integrity":{"future_or_incomplete_bars_included":False,"missing_minutes_filled":False,"duplicate_conflicts":"fatal","ohlc_validation":"positive finite prices; high/low contain open/close; nonnegative volume"}}
    (outdir/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--start-date",type=parse_date,default=dt.date(2026,9,1));p.add_argument("--end-date",type=parse_date,default=dt.date(2026,10,10));p.add_argument("--output",type=pathlib.Path,default=pathlib.Path("artifacts/crypto-data"));a=p.parse_args()
    try:
        m=collect(a.start_date,a.end_date,a.output)
        print(json.dumps({"status":m["status"],"instruments":m["instruments"],"raw_response_count":m["raw_response_count"],"warnings":m["warnings"],"output":str(a.output)},ensure_ascii=False))
    except Exception as e:
        print(f"ERROR: {type(e).__name__}: {e}")
        raise SystemExit(1)
if __name__=="__main__": main()

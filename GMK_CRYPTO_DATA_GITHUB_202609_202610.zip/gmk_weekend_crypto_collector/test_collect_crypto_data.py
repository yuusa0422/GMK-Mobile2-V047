import datetime as dt
import csv
import gzip
import json
import pathlib
import tempfile
import unittest
import urllib.error
from unittest.mock import patch
import collect_crypto_data as c

class CollectorTests(unittest.TestCase):
    def test_window_limited_to_requested_months(self):
        c.validate_range(dt.date(2026,9,1),dt.date(2026,10,10))
        for a,b in [(dt.date(2026,8,31),dt.date(2026,10,1)),(dt.date(2026,9,1),dt.date(2026,11,1)),(dt.date(2025,9,1),dt.date(2025,10,1))]:
            with self.assertRaises(ValueError): c.validate_range(a,b)
    def test_date_format_is_strict(self):
        self.assertEqual(c.parse_date("2026-09-01"),dt.date(2026,9,1))
        for value in ("20260901","2026-W36-2","2026-9-1"):
            with self.assertRaises(Exception): c.parse_date(value)
    def test_bitbank_payload_parser_preserves_ohlcv(self):
        payload=json.dumps({"success":1,"data":{"candlestick":[{"type":"1min","ohlcv":[["100","105","98","102","7",1790899200000]]}]}}).encode()
        r=c.parse_bitbank(payload,"ETHJPY","eth_jpy","raw.json")[0]
        self.assertEqual((r['open'],r['high'],r['low'],r['close'],r['volume']),(100.,105.,98.,102.,7.))
        self.assertEqual(r['volume_unit'],'base_asset')
    def test_coinbase_candle_order_is_correctly_mapped(self):
        payload=b'[[1790899200,98,105,100,102,7]]'
        r=c.parse_coinbase(payload,'chunk.json')[0]
        self.assertEqual((r['instrument'],r['open'],r['high'],r['low'],r['close'],r['volume']),('BTCUSD',100.,105.,98.,102.,7.))
    def test_reciprocal_reverses_high_low(self):
        r={'instrument':'BTCUSD','source_pair':'BTC-USD','open':100.,'high':120.,'low':80.,'close':110.,'volume':2.,'volume_unit':'base_asset','derived':'false'}
        x=c.add_inverse([r])[0]
        self.assertAlmostEqual(x['open'],.01);self.assertAlmostEqual(x['high'],1/80);self.assertAlmostEqual(x['low'],1/120);self.assertAlmostEqual(x['close'],1/110)
        self.assertEqual(x['volume'],2.)
    def test_bad_ohlc_is_rejected(self):
        for row in [["100","99","98","101","1",1790899200000],["nan","105","98","102","1",1790899200000]]:
            body=json.dumps({"success":1,"data":{"candlestick":[{"ohlcv":[row]}]}}).encode()
            with self.assertRaises(ValueError): c.parse_bitbank(body,"BTCJPY","btc_jpy","raw")
    def test_coinbase_limit_rejects_oversized_response(self):
        with self.assertRaises(c.FetchError): c.parse_coinbase(json.dumps([[1790899200,1,2,1,2,1]]*301).encode(),'x')
    def test_http_status_is_preserved_for_current_partition_handling(self):
        error=urllib.error.HTTPError("https://example.invalid",404,"Not Found",None,None)
        with patch.object(c.urllib.request,"urlopen",side_effect=error):
            with self.assertRaises(c.HTTPStatusError) as caught: c.request_bytes("https://example.invalid")
        self.assertEqual(caught.exception.status,404)
    def test_raw_response_manifest_path_is_portable(self):
        with tempfile.TemporaryDirectory() as temp:
            path=pathlib.Path(temp)/"raw"/"sample.json"
            meta=c._save_raw(path,b"{}","raw/sample.json")
            self.assertEqual(meta["file"],"raw/sample.json")
            self.assertNotIn(temp,meta["file"])
    def test_collect_writes_manifest_and_reciprocal_series(self):
        start=dt.date(2026,9,1);end=start
        now=dt.datetime(2026,8,31,15,3,tzinfo=c.UTC)
        stamps=[int(dt.datetime(2026,8,31,15,i,tzinfo=c.UTC).timestamp()) for i in range(3)]
        bitbank=json.dumps({"success":1,"data":{"candlestick":[{"type":"1min","ohlcv":[["100","105","98","102","7",ts*1000] for ts in stamps]}]}}).encode()
        coinbase=json.dumps([[ts,98,105,100,102,7] for ts in stamps]).encode()
        def response(url): return coinbase if "/products/BTC-USD/" in url else bitbank
        with tempfile.TemporaryDirectory() as temp, patch.object(c,"request_bytes",side_effect=response):
            manifest=c.collect(start,end,pathlib.Path(temp),now)
            self.assertEqual(manifest["instruments"]["ETHJPY"]["rows"],3)
            self.assertEqual(manifest["instruments"]["USDBTC"]["rows"],3)
            self.assertEqual(manifest["instruments"]["BTCJPY"]["missing_minutes_filled"],0)
            self.assertTrue(all(not pathlib.Path(x["file"]).is_absolute() for x in manifest["raw_responses"]))
            with gzip.open(pathlib.Path(temp)/manifest["normalised_file"]["name"],"rt",encoding="utf-8") as f:
                instruments={row["instrument"] for row in csv.DictReader(f)}
            self.assertEqual(instruments,{"BTCJPY","ETHJPY","XRPJPY","BTCUSD","USDBTC"})
    def test_workflow_is_dispatch_only_and_uploads_artifact(self):
        y=(pathlib.Path(__file__).parent/'.github/workflows/collect_weekend_crypto_data.yml').read_text()
        self.assertIn('workflow_dispatch:',y);self.assertNotIn('schedule:',y);self.assertIn('actions/upload-artifact@v4',y)
        self.assertIn('contents: read',y);self.assertIn('2026-09-01',y);self.assertIn('2026-10-10',y)
        self.assertIn('Locate collector source',y)
        self.assertIn('unittest.defaultTestLoader.discover',y)
        self.assertIn('refusing to continue',y)
        self.assertIn('steps.collector.outputs.project_dir',y)
    def test_no_runtime_dependencies(self):
        source=pathlib.Path(__file__).with_name('collect_crypto_data.py').read_text()
        self.assertNotIn('requests.',source);self.assertNotIn('pandas.',source)

if __name__=='__main__': unittest.main(verbosity=2)


from pathlib import Path
import re, sys, json

root = Path(__file__).resolve().parents[1]
app = root / "app/src/main"
vm = (app / "java/jp/gmk/mobile/ui/GmkViewModel.kt").read_text(encoding="utf-8")
prefs = (app / "java/jp/gmk/mobile/data/AppPrefs.kt").read_text(encoding="utf-8")
hist = (app / "java/jp/gmk/mobile/data/HistoryStore.kt").read_text(encoding="utf-8")
main = (app / "java/jp/gmk/mobile/MainActivity.kt").read_text(encoding="utf-8")
manifest = (app / "AndroidManifest.xml").read_text(encoding="utf-8")
service = (app / "java/jp/gmk/mobile/runtime/GmkRuntimeKeepAliveService.kt").read_text(encoding="utf-8")
gradle = (root / "app/build.gradle.kts").read_text(encoding="utf-8")
workflow = (root / ".github/workflows/build.yml").read_text(encoding="utf-8")

checks = {
    "v070": 'versionCode = 70' in gradle and 'versionName = "0.7.0-local"' in gradle,
    "foreground_service_declared": "GmkRuntimeKeepAliveService" in manifest and "foregroundServiceType=\"specialUse\"" in manifest,
    "foreground_service_runtime": "runtime = GmkViewModel" in service and "START_STICKY" in service,
    "1m_auto_pref": "oneMinuteAutoScan" in prefs,
    "1m_auto_scheduler": "startOneMinuteAutoLoop" in vm and 'startOneMinuteScan("AUTO_1M")' in vm,
    "3m_priority_over_1m": "isThreeMinuteAutoMinute" in vm,
    "1m_history_saved": "historyStore.add(historyResult)" in vm,
    "1m_outcome_tracking": "scheduleOutcomeTracking(historyResult)" in vm,
    "1m_judge_is_one_minute": "judgeTimeJst = result.judgeTimeJst" in vm,
    "1m_and_3m_winrate_split": "val threeRows" in main and "val oneRows" in main,
    "outcome_status_visible": "state.outcomeStatus" in main,
    "atomic_3m_boundary_claim": "claimThreeMinuteBoundary" in prefs and "prefs.claimThreeMinuteBoundary" in vm,
    "atomic_1m_boundary_claim": "claimOneMinuteBoundary" in prefs and "prefs.claimOneMinuteBoundary" in vm,
    "auto_history_dedup": 'result.source.startsWith("AUTO")' in hist,
    "github_compile_step": "name: Compile Kotlin" in workflow,
}
failed = [k for k,v in checks.items() if not v]
print(json.dumps(checks, ensure_ascii=False, indent=2))
if failed:
    print("FAILED:", failed)
    sys.exit(1)
print(f"PASS {len(checks)}/{len(checks)}")

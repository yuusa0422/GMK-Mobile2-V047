package jp.gmk.mobile

import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import jp.gmk.mobile.ui.GmkViewModel
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.max

private val Paper = Color(0xFFF6EBDD)
private val Paper2 = Color(0xFFFFF8EE)
private val Wood = Color(0xFF4A3029)
private val Wine = Color(0xFFA63847)
private val WineDark = Color(0xFF6D2430)
private val Ink = Color(0xFF35211E)
private val High = Color(0xFFC73B4D)
private val Low = Color(0xFF315FB6)
private val Gold = Color(0xFFB7893C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Wine, background = Paper)) { GmkApp() }
        }
    }
}

enum class Tab { Scan, History, Settings }

@Composable
fun GmkApp(vm: GmkViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    var tab by remember { mutableStateOf(Tab.Scan) }
    val context = LocalContext.current
    val diagnosticLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching {
                val stream = requireNotNull(context.contentResolver.openOutputStream(uri)) { "保存先を開けません" }
                stream.use { out ->
                    out.write(vm.buildDiagnosticJson().toByteArray(Charsets.UTF_8))
                    out.flush()
                }
                true
            }.getOrDefault(false)
            Toast.makeText(
                context,
                if (ok) "診断ログを保存しました" else "診断ログの保存に失敗しました",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
    Scaffold(
        containerColor = Paper,
        bottomBar = { BottomBar(tab) { tab = it; if (it == Tab.History) vm.loadHistory() } }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.Scan -> ScanScreen(
                    state,
                    vm::manualScan,
                    vm::manualOneMinuteScan,
                    vm::setAuto,
                    vm::setOneMinuteAuto
                )
                Tab.History -> HistoryScreen(state.history)
                Tab.Settings -> SettingsScreen(state, vm::saveSettings) { diagnosticLauncher.launch("GMK_DIAGNOSTICS_${System.currentTimeMillis()}.json") }
            }
        }
    }
}

@Composable
private fun ScanScreen(
    state: GmkUiState,
    onScan: () -> Unit,
    onOneMinuteScan: () -> Unit,
    onAuto: (Boolean) -> Unit,
    onOneMinuteAuto: (Boolean) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().background(Paper)) {
        item {
            Image(
                painterResource(R.drawable.gmk_header), null,
                Modifier.fillMaxWidth().aspectRatio(864f / 415f),
                contentScale = ContentScale.Crop
            )
            StatusStrip(state)
            LocalOnlyStrip()
            ModePanel(state.autoScan, onAuto)
            CountdownPanel(onScan, state.busy || state.oneMinuteBusy)
            OneMinuteManualPanel(
                scan = state.oneMinuteScan,
                status = state.oneMinuteStatus,
                busy = state.oneMinuteBusy || state.busy,
                auto = state.oneMinuteAutoScan,
                onAuto = onOneMinuteAuto,
                onScan = onOneMinuteScan
            )
        }
        item { Top1Card(state.scan?.top1, state.scan?.candidates?.size ?: 0) }
        item { SectionTitle("スキャン結果一覧") }
        val results = state.scan?.candidates.orEmpty()
        if (results.isEmpty()) {
            items(state.rates) { RateOnlyRow(it) }
        } else {
            items(results) { c -> ResultRow(c, state.rates.firstOrNull { it.instrument == c.instrument }) }

            val candidateSet = results.map { it.instrument }.toSet()
            val excludedRates = state.rates.filter { it.instrument !in candidateSet }
            if (excludedRates.isNotEmpty()) {
                item { SectionTitle("今回の判定対象外") }
                items(excludedRates) { RateOnlyRow(it) }
            }
        }

        if (state.lastScanExcluded.isNotEmpty()) {
            item {
                Text(
                    state.lastScanExcluded.entries.joinToString(" / ") { "${it.key}: ${it.value}" },
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    color = WineDark,
                    fontSize = 11.sp
                )
            }
        }

        val divergenceAlerts = state.quoteCandleDivergencePct.filter { (ins, pct) ->
            pct >= if (ins == "BTCJPY") 1.50 else 0.50
        }
        if (divergenceAlerts.isNotEmpty()) {
            item {
                Text(
                    "価格整合注意: " + divergenceAlerts.entries.joinToString(" / ") {
                        "${it.key} ${"%.3f".format(it.value)}%"
                    },
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    color = WineDark,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        item { RecentHistoryPreview(state.history) }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun LocalOnlyStrip() {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFFEFE3D3)).padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("端末単体版", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = WineDark)
        Spacer(Modifier.width(8.dp))
        Text("判定・履歴はスマホ内 / クラウド不要", fontSize = 10.sp, color = Ink)
    }
}

@Composable
private fun StatusStrip(state: GmkUiState) {
    val allLive = state.rateLiveCount == 6
    val bg = when {
        allLive -> Color(0xFFE9F1E5)
        state.rateAvailableCount > 0 -> Color(0xFFFFF1D7)
        else -> Color(0xFFF7E0E0)
    }

    Column(
        Modifier.fillMaxWidth().background(bg).padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when {
                    allLive -> "● 6/6 LIVE"
                    state.rateAvailableCount > 0 ->
                        "● LIVE ${state.rateLiveCount}/6  取得 ${state.rateAvailableCount}/6"
                    else -> "● レート取得待機"
                },
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (allLive) Color(0xFF416C3C) else WineDark
            )
            Spacer(Modifier.weight(1f))
            if (state.scannableCount > 0) {
                Text("判定可能 ${state.scannableCount}/6", fontSize = 10.sp, color = Ink)
            }
        }

        state.rateStatus?.let {
            Text(it.take(180), fontSize = 10.sp, color = WineDark, maxLines = 2)
        }
        state.scanStatus?.let {
            Text(it.take(220), fontSize = 10.sp, color = Ink, maxLines = 3)
        }
        state.outcomeStatus?.let {
            Text(it.take(220), fontSize = 10.sp, color = Color(0xFF416C3C), maxLines = 2)
        }
        state.error?.let {
            Text(it.take(180), fontSize = 10.sp, color = WineDark, maxLines = 2)
        }
    }
}

@Composable
private fun ModePanel(auto: Boolean, onAuto: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(10.dp)
            .border(1.dp, Color(0xFFB89A84), RoundedCornerShape(8.dp))
            .background(Paper2).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("判定モード", fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.width(10.dp))
        ModeChip("3分判定", true)
        Spacer(Modifier.width(6.dp))
        ModeChip("5分枠", false)
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("AUTO SCAN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Switch(checked = auto, onCheckedChange = onAuto)
        }
    }
}

@Composable
private fun ModeChip(text: String, active: Boolean) {
    Box(
        Modifier.background(if (active) Wine else Color(0xFFE5D8CC), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(text, color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun CountdownPanel(onScan: () -> Unit, busy: Boolean) {
    var seconds by remember { mutableStateOf(nextScanSeconds()) }
    LaunchedEffect(Unit) { while (true) { seconds = nextScanSeconds(); delay(1000) } }
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp)) {
        Card(Modifier.weight(0.9f), colors = CardDefaults.cardColors(containerColor = Paper2)) {
            Column(Modifier.padding(12.dp)) {
                Text("次回AUTOまで", fontSize = 12.sp, color = Ink)
                Text(String.format("%02d:%02d", seconds / 60, seconds % 60), fontSize = 29.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
        Spacer(Modifier.width(8.dp))
        Button(
            onClick = onScan,
            enabled = !busy,
            modifier = Modifier.weight(1.35f).height(78.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Wine),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(if (busy) "スキャン中…" else "今すぐスキャン  ›", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun OneMinuteManualPanel(
    scan: OneMinuteScanResult?,
    status: String?,
    busy: Boolean,
    auto: Boolean,
    onAuto: (Boolean) -> Unit,
    onScan: () -> Unit
) {
    val top = scan?.top1

    Card(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1ECFF)),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("1分 手動スキャン", fontWeight = FontWeight.Bold, color = Ink, fontSize = 17.sp)
                    Text("スマホ単体 / 1分専用Engine / 3分ルール不使用", fontSize = 11.sp, color = Color.Gray)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("1分AUTO T-10", fontSize = 10.sp, color = Ink)
                        Spacer(Modifier.width(6.dp))
                        Switch(checked = auto, onCheckedChange = onAuto)
                    }
                }
                Button(
                    onClick = onScan,
                    enabled = !busy,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5A3C8C))
                ) {
                    Text(if (busy) "判定中…" else "1分手動")
                }
            }

            status?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, fontSize = 11.sp, color = Ink)
            }

            top?.let { c ->
                Spacer(Modifier.height(10.dp))
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.instrument, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("${c.regime} / 1M ${(c.confidence * 100).toInt()}%", fontSize = 11.sp, color = Color.Gray)
                        Text("判定 ${scan.judgeTimeJst.takeLast(14)}", fontSize = 10.sp, color = Color.Gray)
                    }
                    DirectionBox(c.direction)
                }
                Spacer(Modifier.height(6.dp))
                c.reasons.take(4).forEach { reason ->
                    Text("・$reason", fontSize = 10.sp, color = Ink)
                }
            }
        }
    }
}

private fun nextScanSeconds(): Int {
    val z = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"))
    var boundary = z.truncatedTo(ChronoUnit.MINUTES).withSecond(0).withNano(0)
    val add = (5 - boundary.minute % 5) % 5
    boundary = boundary.plusMinutes(add.toLong())
    var scanAt = boundary.minusSeconds(10)
    if (scanAt.isBefore(z) && ChronoUnit.MILLIS.between(scanAt, z) >= 1000L) {
        scanAt = boundary.plusMinutes(5).minusSeconds(10)
    }
    return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())
}

@Composable
private fun Top1Card(top: ScanCandidate?, coverageCount: Int) {
    Card(
        Modifier.fillMaxWidth().padding(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5EA)),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Column {
            Row(Modifier.fillMaxWidth().background(WineDark).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (coverageCount in 1..5) "♛  TOP1（部分 ${coverageCount}/6）" else "♛  TOP1 結果",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
            if (top == null) {
                Text("まだスキャン結果がありません", Modifier.padding(18.dp), color = Ink)
            } else {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(top.instrument, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("第${top.rank}位  RANK ${top.grade}", color = Gold, fontWeight = FontWeight.Bold)
                        top.probability?.let { Text("RULE ${(it * 100).toInt()}%", fontSize = 11.sp, color = Color.Gray) }
                        Text(
                            "${top.regime} ${(top.regimeConfidence * 100).toInt()}%",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                    DirectionBox(top.direction)
                    Spacer(Modifier.width(10.dp))
                    Text(top.decision, color = if (top.decision == "ENTRY") Wine else Color.Gray, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        Modifier.fillMaxWidth().background(Wood).padding(horizontal = 14.dp, vertical = 9.dp),
        color = Color.White,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun ResultRow(c: ScanCandidate, rate: RateRow?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp)
            .border(0.5.dp, Color(0xFFD4C1AF))
            .background(if (c.rank == 1) Color(0xFFFFE4E3) else Paper2)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${c.rank}", Modifier.width(25.dp), fontWeight = FontWeight.Bold, color = Gold)
        Column(Modifier.weight(1f)) {
            Text(c.instrument, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            Text(rate?.price?.let(::formatPrice) ?: "—", fontSize = 11.sp, color = Color.Gray)
            Text("${c.regime} ${(c.regimeConfidence * 100).toInt()}%", fontSize = 10.sp, color = Color.Gray)
        }
        DirectionBox(c.direction)
        Spacer(Modifier.width(10.dp))
        Text(c.grade, Modifier.width(30.dp), fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
        Text(
            c.decision,
            Modifier.width(54.dp),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (c.decision == "ENTRY") Wine else Color.Gray,
            textAlign = TextAlign.End
        )
    }
}

@Composable
private fun RateOnlyRow(r: RateRow) {
    val status = when {
        r.price == null -> "UNAVAILABLE"
        r.freshnessStatus == "LIVE" -> "LIVE"
        r.freshnessStatus == "LAST" -> "LAST"
        else -> r.freshnessStatus
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp)
            .border(0.5.dp, Color(0xFFD4C1AF)).background(Paper2).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(r.instrument, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Ink)
        Column(horizontalAlignment = Alignment.End) {
            Text(r.price?.let(::formatPrice) ?: "—", fontWeight = FontWeight.Bold, color = Ink)
            val ageLabel = r.ageSeconds?.let { " ${it.toInt()}s" } ?: ""
            Text(
                "$status$ageLabel ${r.source}",
                fontSize = 10.sp,
                color = when (status) {
                    "LIVE" -> Color(0xFF416C3C)
                    "LAST" -> Gold
                    else -> WineDark
                }
            )
        }
    }
}

@Composable
private fun DirectionBox(direction: String) {
    val normalized = direction.uppercase()
    val (label, color) = when (normalized) {
        "HIGH" -> "▲ HIGH" to High
        "LOW" -> "▼ LOW" to Low
        else -> "—" to Color.Gray
    }
    Surface(color = color, shape = RoundedCornerShape(6.dp)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun formatJstTime(iso: String): String {
    if (iso.isBlank()) return "—"
    return runCatching {
        ZonedDateTime.parse(iso)
            .withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
            .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
    }.getOrElse { "—" }
}

private fun formatPrice(x: Double): String = if (x >= 100000) "%,.0f".format(x) else if (x >= 100) "%.3f".format(x) else "%.5f".format(x)

@Composable
private fun RecentHistoryPreview(rows: List<HistoryRow>) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp)) {
        Text("直近の予測結果", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))

        if (rows.isEmpty()) {
            Text("まだ結果はありません。", fontSize = 11.sp, color = Color.Gray)
        } else {
            rows.take(5).forEach { h ->
                val resultColor = when (h.resultStatus) {
                    "WIN" -> Color(0xFF2E7D32)
                    "LOSE" -> Wine
                    else -> Color.Gray
                }
                Row(
                    Modifier.fillMaxWidth()
                        .background(Paper2)
                        .padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(h.instrument, Modifier.width(72.dp), fontWeight = FontWeight.Bold)
                    Text(
                        h.direction,
                        Modifier.width(50.dp),
                        color = if (h.direction == "HIGH") High else Low,
                        fontWeight = FontWeight.Bold
                    )
                    Text(h.source, Modifier.width(64.dp), fontSize = 10.sp, color = Color.Gray)
                    Spacer(Modifier.weight(1f))
                    Text(
                        when (h.resultStatus) {
                            "WIN" -> "WIN"
                            "LOSE" -> "LOSE"
                            "WAIT_ENTRY" -> "10秒後待ち"
                             "WAIT_JUDGE" -> if (h.source.contains("1M")) "1分判定待ち" else "3分判定待ち"
                            "ENTRY_RATE_MISSED" -> "ENTRY取得失敗"
                            "JUDGE_RATE_MISSED" -> "判定取得失敗"
                            "LEGACY_NO_OUTCOME" -> "旧履歴"
                            else -> h.resultStatus
                        },
                        color = resultColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(rows: List<HistoryRow>) {
    Column(Modifier.fillMaxSize().background(Paper)) {
        PageHeader("予測結果一覧")

        val threeRows = rows.filter { !it.source.contains("1M") }
        val oneRows = rows.filter { it.source.contains("1M") }

        val threeWins = threeRows.count { it.decision == "ENTRY" && it.resultStatus == "WIN" }
        val threeLosses = threeRows.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" }
        val threeResolved = threeWins + threeLosses
        val threeWr = if (threeResolved > 0) threeWins * 100.0 / threeResolved else null

        val oneWins = oneRows.count { it.decision == "ENTRY" && it.resultStatus == "WIN" }
        val oneLosses = oneRows.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" }
        val oneResolved = oneWins + oneLosses
        val oneWr = if (oneResolved > 0) oneWins * 100.0 / oneResolved else null

        val skipResolved = threeRows.count {
            it.decision == "SKIP" && it.resultStatus in setOf("WIN", "LOSE")
        }

        Text(
            "3分 ${if (threeWr != null) "${threeResolved}件 ${"%.2f".format(threeWr)}%" else "確定なし"}" +
                "  |  1分 ${if (oneWr != null) "${oneResolved}件 ${"%.2f".format(oneWr)}%" else "確定なし"}" +
                "  |  3分SKIP参考 ${skipResolved}件",
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            fontWeight = FontWeight.Bold,
            color = Ink,
            fontSize = 12.sp
        )

        if (rows.isEmpty()) {
            Text(
                "手動/AUTOの3分予測は、スキャン基準から10秒後のレートをENTRYとして、その3分後にWIN/LOSEを自動判定します。SKIP結果は参考扱いでENTRY勝率には含めません。",
                Modifier.padding(16.dp),
                color = Color.Gray,
                fontSize = 12.sp
            )
        } else {
            LazyColumn {
                items(rows) { h ->
                    val resultColor = when (h.resultStatus) {
                        "WIN" -> Color(0xFF2E7D32)
                        "LOSE" -> Wine
                        else -> Color.Gray
                    }

                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)
                            .border(0.5.dp, Color(0xFFD4C1AF))
                            .background(Paper2)
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "${h.instrument}  ${h.direction}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (h.direction == "HIGH") High else Low,
                                    fontSize = 16.sp
                                )
                                Text(
                                    "${h.source} / ${h.grade} / ${h.regime}",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }

                            Text(
                                when (h.resultStatus) {
                                    "WIN" -> "WIN"
                                    "LOSE" -> "LOSE"
                                    "WAIT_ENTRY" -> "10秒後待ち"
                                     "WAIT_JUDGE" -> if (h.source.contains("1M")) "1分判定待ち" else "3分判定待ち"
                                    "ENTRY_RATE_MISSED" -> "ENTRY取得失敗"
                                    "JUDGE_RATE_MISSED" -> "判定取得失敗"
                                    "ENTRY_RATE_MISSING" -> "ENTRY不明"
                                    "LEGACY_NO_OUTCOME" -> "旧履歴・結果なし"
                                    else -> if (h.decision == "SKIP" && h.resultStatus in setOf("WIN", "LOSE")) {
                                        "SKIP参考 ${h.resultStatus}"
                                    } else {
                                        h.resultStatus
                                    }
                                },
                                color = resultColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(Modifier.height(6.dp))

                        Text(
                            "スキャン ${formatJstTime(h.atJst)}",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                        Text(
                            "ENTRY(+10秒・市場参考) ${formatJstTime(h.entryTimeJst)}  ${h.entryRate?.let(::formatPrice) ?: "—"}",
                            fontSize = 11.sp,
                            color = Ink
                        )
                        Text(
                            "${if (h.source.contains("1M")) "1分後" else "3分後"}・市場参考 ${formatJstTime(h.judgeTimeJst)}  ${h.judgeRate?.let(::formatPrice) ?: "—"}",
                            fontSize = 11.sp,
                            color = Ink
                        )

                        if (h.entryRateSource.isNotBlank() || h.judgeRateSource.isNotBlank()) {
                            Text(
                                "ENTRY: ${h.entryRateSource.ifBlank { "—" }} / 判定: ${h.judgeRateSource.ifBlank { "—" }}",
                                fontSize = 9.sp,
                                color = Color.Gray
                            )
                            Text(
                                "取得遅延 ENTRY=${h.entryCaptureDelayMs?.let { "${it}ms" } ?: "—"} " +
                                    "/ 判定=${h.judgeCaptureDelayMs?.let { "${it}ms" } ?: "—"}  " +
                                    "provider age ENTRY=${h.entryProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"} " +
                                    "/ 判定=${h.judgeProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"}",
                                fontSize = 9.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(state: GmkUiState, save: (String, String, String, Boolean) -> Unit, exportDiagnostic: () -> Unit) {
    var token by remember(state.oandaToken) { mutableStateOf(state.oandaToken) }
    var account by remember(state.oandaAccountId) { mutableStateOf(state.oandaAccountId) }
    var env by remember(state.oandaEnvironment) { mutableStateOf(state.oandaEnvironment) }
    var fallback by remember(state.yahooFallback) { mutableStateOf(state.yahooFallback) }

    LazyColumn(Modifier.fillMaxSize().background(Paper).padding(14.dp)) {
        item {
            PageHeader("設定")
            Text("レート取得", fontWeight = FontWeight.Bold, color = Ink)
            Text("スマホから直接取得します。バックエンドURLやPCは使いません。", fontSize = 12.sp, color = Color.Gray)
            Spacer(Modifier.height(12.dp))
            Text("OANDA Personal Access Token", fontWeight = FontWeight.Bold, color = Ink)
            OutlinedTextField(
                token, { token = it }, Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                placeholder = { Text("未設定でもYahoo fallbackは利用可") }
            )
            Spacer(Modifier.height(10.dp))
            Text("OANDA Account ID", fontWeight = FontWeight.Bold, color = Ink)
            OutlinedTextField(account, { account = it }, Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            Text("OANDA環境", fontWeight = FontWeight.Bold, color = Ink)
            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = env == "practice", onClick = { env = "practice" }, label = { Text("practice") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = env == "live", onClick = { env = "live" }, label = { Text("live") })
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Yahoo FX fallback", fontWeight = FontWeight.Bold, color = Ink)
                    Text("OANDA未設定・障害時の補完。古い値はLAST表示し、判定には使いません。", fontSize = 11.sp, color = Color.Gray)
                }
                Switch(checked = fallback, onCheckedChange = { fallback = it })
            }
            Spacer(Modifier.height(16.dp))
            Button(
                { save(token, account, env, fallback) },
                Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Wine)
            ) { Text("保存") }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = exportDiagnostic,
                modifier = Modifier.fillMaxWidth()
            ) { Text("詳細診断ログを保存") }
            Spacer(Modifier.height(20.dp))
            Text("AUTO有効時はForeground Runtimeを使用。3分は5分境界T-10、1分AUTOは各1分境界T-10（3分AUTO枠は3分優先）。", color = Ink, fontSize = 12.sp)
            Text("1分・3分ともスマホ単体判定。OCR / Railway / PC依存なし。", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun PageHeader(text: String) {
    Text(text, Modifier.fillMaxWidth().padding(vertical = 16.dp), fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
private fun BottomBar(tab: Tab, select: (Tab) -> Unit) {
    Row(Modifier.fillMaxWidth().height(72.dp).background(Wood)) {
        BottomItem("⌕", "スキャン", tab == Tab.Scan) { select(Tab.Scan) }
        BottomItem("▤", "履歴", tab == Tab.History) { select(Tab.History) }
        BottomItem("⚙", "設定", tab == Tab.Settings) { select(Tab.Settings) }
    }
}

@Composable
private fun RowScope.BottomItem(icon: String, text: String, active: Boolean, click: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable(onClick = click)
            .background(if (active) WineDark else Color.Transparent),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = Color.White, fontSize = 22.sp)
        Text(text, color = Color.White, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.random.Random

/** v0.7.44+ final ENTRY decision; v0.7.48 strength ladder (v0.7.51 session ranks: SessionRanksV0751Test). */
class EvidencePolicyTest {
    @Before fun reset() = EvidencePolicy.resetState()

    private fun contractHolds(r: ScanResult) {
        assertEquals((1..r.candidates.size).toSet(), r.candidates.map { it.rank }.toSet())
        assertTrue(r.candidates.all { it.direction in setOf("HIGH", "LOW") })
        // v0.7.56: the 1st candidate's C is SKIP when the ENTRY amount setting does not enter C (library default: 55%優先)
        assertTrue(r.candidates.all { (it.grade in setOf("D", "E", "F", "G", "H", "I") && it.decision == "SKIP") || (it.grade in setOf("S", "A", "B", "C") && it.decision == "ENTRY") ||
            (it.grade == "C" && it.rank == 1 && it.decision == "SKIP") })
    }

    @Test fun weekdaySlotPicksTheModelChoiceAsTop1AndKeepsAllSix() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val native = s.native()
        val out = EvidencePolicy.apply(native, native, s.candles(), s.quotes())
        contractHolds(out)
        assertEquals(6, out.candidates.size)
        val top = out.top1!!
        val want = s.best.getValue("fresh")
        // v0.7.51: only a time-of-day rule may replace the model's choice (none of the fixture slots is at a rule minute)
        assertFalse(top.reasons[1].contains(" RULE="))
        // v0.7.57: a confirmed strong trade (B) keeps the 3-minute model's choice; otherwise the 5-minute model's FX trade; both 5 minutes
        val five = Regex(" FIVE=([A-Z]+) (HIGH|LOW) ").find(top.reasons[1])
        if (top.grade == "B") { assertEquals(want.instrument, top.instrument); assertEquals(want.direction, top.direction) }
        else { assertNotNull(five); assertEquals(five!!.groupValues[1], top.instrument); assertEquals(five.groupValues[2], top.direction) }
        assertEquals("判定: 5分", top.reasons.first())
        assertTrue(top.reasons[1].startsWith(EvidencePolicy.VERSION))
        assertEquals(s.entry.plusMinutes(5).toOffsetDateTime().toString(), out.judgeTimeJst)
        assertTrue(out.policyVersion.startsWith("GMK_V0740"))
        assertNotNull(top.assessment)
        assertEquals(top.grade, top.assessment!!.chosenAction.operationalGrade)
    }

    @Test fun weekendUsesBitcoinOnly() {
        val s = EvidenceFixture.slots.first { it.weekend }
        val out = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes())
        contractHolds(out)
        assertEquals(listOf("BTCJPY"), out.candidates.map { it.instrument })
    }

    @Test fun staleOrMissingLivePriceFallsBackToTheBackupModel() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val stale = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(ageMs = 45_000L))
        assertTrue(stale.warnings.any { it.contains("予備モデル") })
        assertTrue(stale.top1!!.reasons[1].contains("fallback"))
        assertEquals(s.best.getValue("fallback").instrument, stale.top1!!.instrument)
        val fresh = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(ageMs = 9_000L))
        assertTrue(fresh.top1!!.reasons[1].contains("fresh"))
        assertNull(EvidencePolicy.freshPrice(mapOf("USDJPY" to EvidencePolicy.LiveQuote(150.0, s.boundary * 1000L + 5_000L)), "USDJPY", s.boundary))
    }

    private fun wdInputs(rnd: Random, inst: String = "USDJPY", dir: Int = 1, hour: Int = 14) = EvidenceStrength.Inputs(
        inst, dir, 0.0, rnd.nextDouble(-3.0, 3.0), rnd.nextDouble(-1.5, 1.5), rnd.nextDouble(-2.0, 2.0), kotlin.math.exp(rnd.nextDouble(-0.6, 1.2)), 0.0, 0.0, hour, 3)
    private fun weInputs(rnd: Random, tie: Double, move: Double) = EvidenceStrength.Inputs(
        "BTCJPY", 1, 0.0, move * rnd.nextDouble(0.0, 2.0), 0.0, 0.0, kotlin.math.exp(rnd.nextDouble(0.0, 1.3)), tie * rnd.nextDouble(0.5, 1.5), tie, 15, 6)

    /** v0.7.48: weekday ENTER = strongest 85% of the rolling window; skipped slots split D (upper half) / E. */
    @Test fun weekdayEntersTheStrongest85PercentAndSplitsSkipsIntoDE() {
        val rnd = Random(3)
        var entered = 0; var counted = 0; val grades = mutableMapOf<String, Int>()
        for (i in 0 until 3000) {
            val adj = rnd.nextDouble(-0.05, 0.05) + if (i > 1500) 0.02 else 0.0      // level shift: the window must adapt
            val d = EvidencePolicy.decide(EvidencePolicy.Choice("USDJPY", "HIGH", 0.5 + adj, adj, true, wdInputs(rnd)), false, 1_800_000_000L + i * 300L, record = true)
            assertEquals(d.grade in setOf("S", "A", "B", "C"), d.enter)
            assertTrue(d.grade in setOf("S", "A", "B", "C", "D", "E"))
            if (!d.enter) assertTrue(d.reason in EvidenceStrength.REASON_SKIP.values) else assertTrue(d.reason in EvidenceStrength.REASON_STRONG.values)
            if (i >= 400) { counted++; if (d.enter) entered++; grades.merge(d.grade, 1, Int::plus) }
        }
        assertEquals(EvidencePolicy.WEEKDAY_ENTRY_RATE, entered.toDouble() / counted, 0.03)
        assertEquals(0.075, grades.getValue("D").toDouble() / counted, 0.03)
        assertEquals(0.075, grades.getValue("E").toDouble() / counted, 0.03)
        assertTrue(grades.getValue("S") > 0 && grades.getValue("A") > 0 && grades.getValue("B") > 0 && grades.getValue("C") > 0)
        assertEquals(EvidencePolicy.bufferLimit(false), EvidencePolicy.bufferSize(true, false))
        assertEquals(288, EvidencePolicy.WEEKDAY_BUFFER_SIZE)
        assertEquals(576, EvidencePolicy.WEEKEND_BUFFER_SIZE)
    }

    /** Weekday ranks follow the rank strength; D/E never ENTER; validated rates fall from S to E. */
    @Test fun weekdayRanksAreOrderedByStrength() {
        val rnd = Random(11)
        val byGrade = mutableMapOf<String, MutableList<Double>>()
        for (i in 0 until 1200) {
            val adj = rnd.nextDouble(-0.05, 0.05)
            val d = EvidencePolicy.decide(EvidencePolicy.Choice("EURJPY", "LOW", 0.5 + adj, adj, true, wdInputs(rnd, "EURJPY", -1, 9 + i % 14)), false, 1_810_000_000L + i * 300L, record = true)
            if (d.enter) byGrade.getOrPut(d.grade) { mutableListOf() } += d.rankStrength
        }
        val order = listOf("S", "A", "B", "C").filter { it in byGrade }
        assertTrue(order.size >= 3)
        for (k in 0 until order.size - 1) assertTrue(byGrade.getValue(order[k]).minOrNull()!! >= byGrade.getValue(order[k + 1]).maxOrNull()!!)
        val v = listOf("S", "A", "B", "C", "D", "E").map { EvidencePolicy.validatedRate(true, false, it)!! }
        assertTrue(v[0] > v[1] && v[1] > v[2] && v[2] > v[3] && v[3] > v[5])
        assertNull(EvidencePolicy.validatedRate(true, false, "H"))
    }

    /** Weekend: ENTER when strength >= the fixed cut; S..H strictly by strength; draw-prone skips carry the draw reason. */
    @Test fun weekendLadderFollowsStrengthAndExplainsDrawRisk() {
        val rnd = Random(5)
        val seen = mutableMapOf<String, MutableList<Double>>()
        var drawReasons = 0; var drawSkips = 0
        for (i in 0 until 1500) {
            val adj = rnd.nextDouble(-0.08, 0.08)
            val tie = rnd.nextDouble(0.0, 0.6)
            val d = EvidencePolicy.decide(EvidencePolicy.Choice("BTCJPY", "HIGH", 0.45 + adj, adj, true, weInputs(rnd, tie, if (tie > 0.3) 0.0 else 1.0)), true, 1_820_000_000L + i * 300L, record = true)
            assertEquals(d.strength >= EvidenceStrengthData.FRESH_WEEKEND_CUTS[0], d.enter)
            assertEquals(d.grade in setOf("S", "A", "B", "C"), d.enter)
            seen.getOrPut(d.grade) { mutableListOf() } += d.strength
            if (!d.enter && tie > 0.45) { drawSkips++; if (d.reason == EvidenceStrength.REASON_SKIP.getValue("tie")) drawReasons++ }
        }
        val order = "SABCDEFGH".map { it.toString() }.filter { it in seen }
        assertTrue(order.containsAll(listOf("S", "D", "H")))
        for (k in 0 until order.size - 1) assertTrue(seen.getValue(order[k]).minOrNull()!! >= seen.getValue(order[k + 1]).maxOrNull()!!)
        assertTrue("draw reason $drawReasons/$drawSkips", drawSkips > 50 && drawReasons >= drawSkips * 0.8)
        assertFalse("weekend uses S/A/B for entries", "C" in seen)
        val v = "SABDEFGH".map { EvidencePolicy.validatedRate(true, true, it.toString())!! }
        assertTrue(v.zipWithNext().all { (a, b) -> a > b })
    }

    /** v0.7.45 idea kept: on the weekend, quiet draw-prone days get fewer entries and active days more. */
    @Test fun weekendWindowShiftsEntriesFromQuietToActiveDays() {
        val rnd = Random(9)
        var t = 1_900_000_000L
        fun feed(n: Int, lo: Double, hi: Double, tie: Double, move: Double): Double {
            var e = 0
            repeat(n) {
                val adj = rnd.nextDouble(lo, hi)
                if (EvidencePolicy.decide(EvidencePolicy.Choice("BTCJPY", "HIGH", 0.45 + adj, adj, true, weInputs(rnd, tie, move)), true, t, record = true).enter) e++
                t += 300L
            }
            return e.toDouble() / n
        }
        feed(576, -0.05, 0.05, 0.2, 0.5)                    // a normal weekend fills the window
        val quiet = feed(168, -0.05, 0.0, 0.40, 0.0)        // quiet day: weak slots, price standing still
        val active = feed(168, 0.0, 0.05, 0.05, 1.0)        // active day: strong slots, moving price
        assertTrue("quiet=$quiet", quiet < 0.30)
        assertTrue("active=$active", active > 0.65)
    }

    @Test fun seedPercentileAndShareBelow() {
        val t = doubleArrayOf(0.0, 1.0, 2.0, 4.0)
        assertEquals(0.0, EvidencePolicy.seedPct(t, -1.0), 0.0)
        assertEquals(0.5 / 3.0, EvidencePolicy.seedPct(t, 0.5), 1e-15)
        assertEquals(2.5 / 3.0, EvidencePolicy.seedPct(t, 3.0), 1e-15)
        assertEquals(1.0, EvidencePolicy.seedPct(t, 9.0), 0.0)
        assertEquals(0.5, EvidencePolicy.shareBelow(listOf(1.0, 2.0, 3.0, 4.0), 3.0), 0.0)
    }

    /** v0.7.49: win pattern -> S/A/B by its rate, reversal -> opposite side, no pattern -> C (ENTRY) or D..H (skip). */
    @Test fun manualScansDoNotMoveTheRollingDistribution() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        EvidencePolicy.apply(s.native("MANUAL"), s.native("MANUAL"), s.candles(), s.quotes())
        assertEquals(0, EvidencePolicy.bufferSize(true, false))
        EvidencePolicy.apply(s.native("AUTO"), s.native("AUTO"), s.candles(), s.quotes())
        EvidencePolicy.apply(s.native("AUTO"), s.native("AUTO"), s.candles(), s.quotes())   // same boundary twice
        assertEquals(1, EvidencePolicy.bufferSize(true, false))
    }

    @Test fun outsideSessionAndBrokenInputsNeverEnter() {
        val s = EvidenceFixture.slots.first { !it.weekend }
        val night = s.native().let { n ->
            val t = ZonedDateTime.of(2026, 10, 20, 23, 30, 0, 0, ZoneId.of("Asia/Tokyo"))
            n.copy(entryTimeJst = t.toOffsetDateTime().toString())
        }
        val out = EvidencePolicy.apply(night, night, s.candles(), s.quotes())
        assertTrue(out.candidates.none { it.rank == 1 && it.decision == "ENTRY" })
        val empty = EvidencePolicy.apply(s.native(), s.native(), emptyMap(), s.quotes())
        assertEquals("SKIP", empty.top1!!.decision)
        assertEquals("I", empty.top1!!.grade)
        contractHolds(empty)
    }

    @Test fun quantileMatchesNumpyLinear() {
        val v = listOf(5.0, 1.0, 3.0, 2.0, 4.0)
        assertEquals(1.0, EvidencePolicy.quantile(v, 0.0), 0.0)
        assertEquals(3.0, EvidencePolicy.quantile(v, 0.5), 0.0)
        assertEquals(2.04, EvidencePolicy.quantile(v, 0.26), 1e-12)
        assertEquals(5.0, EvidencePolicy.quantile(v, 1.0), 0.0)
    }
}

import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

/** v0.7.56: the ENTRY amount setting. Grades are the same in every mode; only whether C is ENTRY changes. */
class EntrySixtyV0756Test {
    @Before fun reset() = EvidencePolicy.resetState()

    @Test fun modesRatesAndCuts() {
        // v0.7.57 version constants: FiveMinuteV0757Test
        assertEquals(RankStatistics.CURRENT_RANK_VERSIONS, setOf(RankStatistics.evidenceVersion(EvidencePolicy.POLICY_TAG)))
        assertEquals(EntryMode.WEEKDAY_60, EntryMode.DEFAULT); assertEquals(EntryMode.DEFAULT, EntryMode.parse(null)); assertEquals(EntryMode.DEFAULT, EntryMode.parse("x"))
        for (m in EntryMode.values()) assertEquals(m, EntryMode.parse(m.key))
        assertEquals(setOf("S", "A", "B"), EntryMode.FIFTY_FIVE.entryGrades(false)); assertEquals(setOf("S", "A", "B"), EntryMode.FIFTY_FIVE.entryGrades(true))
        assertEquals(setOf("S", "A", "B", "C"), EntryMode.WEEKDAY_60.entryGrades(false)); assertEquals(setOf("S", "A", "B"), EntryMode.WEEKDAY_60.entryGrades(true))
        assertEquals(setOf("S", "A", "B", "C"), EntryMode.ALL_60.entryGrades(false)); assertEquals(setOf("S", "A", "B", "C"), EntryMode.ALL_60.entryGrades(true))
        for (m in EntryMode.values()) for (w in listOf(false, true)) for (g in listOf("D", "E", "F", "G", "H", "I")) assertFalse(m.enters(g, w))
        // S/A/B validated at 55% or more; C below (the honest price of 60%); every skip grade below C on the fresh tables
        for (w in listOf(false, true)) for (g in listOf("S", "A", "B")) EvidencePolicy.gradeRate(true, w, g)?.let { assertTrue("$g $w", it >= 0.55) }
        assertEquals(0.5322, EvidencePolicy.gradeRate(true, false, "C")!!, 0.0); assertEquals(0.4787, EvidencePolicy.gradeRate(true, true, "C")!!, 0.0)
        val wd = listOf("S", "A", "B", "C", "D").map { EvidencePolicy.gradeRate(true, false, it)!! }   // v0.7.57: weekday S..D
        assertTrue(wd.toString(), wd.zipWithNext().all { (a, b) -> a > b })
        val we = listOf("B", "C", "D", "E", "F", "G", "H").map { EvidencePolicy.gradeRate(true, true, it)!! }
        assertTrue(we.toString(), we.zipWithNext().all { (a, b) -> a > b })
        val fb = listOf("B", "C", "D", "E", "F", "G", "H").map { EvidencePolicy.gradeRate(false, true, it)!! }
        assertTrue(fb.toString(), fb.zipWithNext().all { (a, b) -> a > b })
        // the C cuts sit between the v0.7.48 cuts they split
        assertTrue(RankLadder.FRESH_WEEKDAY_C_CUT < EvidenceStrengthData.FRESH_WEEKDAY_RANK_CUTS[2])
        assertTrue(RankLadder.FRESH_WEEKEND_C_CUT < EvidenceStrengthData.FRESH_WEEKEND_CUTS[0] && RankLadder.FRESH_WEEKEND_C_CUT > EvidenceStrengthData.FRESH_WEEKEND_CUTS[4])
        assertTrue(RankLadder.FALLBACK_WEEKEND_C_CUT < EvidenceStrengthData.FALLBACK_WEEKEND_CUTS[0] && RankLadder.FALLBACK_WEEKEND_C_CUT > EvidenceStrengthData.FALLBACK_WEEKEND_CUTS[4])
        assertEquals("C", SignalAlerts.normalizeMinGrade("C")); assertEquals("C", SignalAlerts.normalizeMinGrade("Z"))   /* v0.7.60 default */; assertEquals("A", SignalAlerts.normalizeMinGrade("A"))
        val tag = EvidencePolicy.POLICY_TAG
        assertTrue(SignalAlerts.shouldNotify("ENTRY", "C", tag, "C")); assertFalse(SignalAlerts.shouldNotify("ENTRY", "C", tag, "B"))
        assertFalse(SignalAlerts.shouldNotify("SKIP", "C", tag, "C"))
    }

    @Test fun modelGradeSplitsTheFormerC() {
        val cut = RankLadder.FRESH_WEEKDAY_C_CUT; val wcut = RankLadder.FRESH_WEEKEND_C_CUT
        for (g in listOf("S", "A", "B", "C")) {
            assertEquals(g, "C", RankLadder.modelGrade(g, false, false, 14, rank = cut))
            assertEquals(g, "D", RankLadder.modelGrade(g, false, false, 14, rank = cut - 1e-9))
            assertEquals(g, "F", RankLadder.modelGrade(g, false, false, 9, rank = 0.9))           // 09h never C
            assertEquals(g, "D", RankLadder.modelGrade(g, false, false, 14))                       // NaN rank never C
        }
        assertEquals("B", RankLadder.modelGrade("S", false, true, 14, rank = 0.0)); assertEquals("E", RankLadder.modelGrade("D", false, false, 14, rank = 0.9))
        assertEquals("C", RankLadder.modelGrade("A", false, false, 14, rank = RankLadder.FALLBACK_WEEKDAY_C_CUT, fresh = false))
        assertEquals("D", RankLadder.modelGrade("A", false, false, 14, rank = RankLadder.FALLBACK_WEEKDAY_C_CUT, fresh = true))
        // weekend: S against the hour -> B; anything else in the top 60% by strength -> C
        assertEquals("B", RankLadder.modelGrade("S", true, againstHour = true, strength = 0.6))
        assertEquals("C", RankLadder.modelGrade("S", true, againstHour = false, strength = 0.6))
        for (g in listOf("A", "B", "C", "D")) {
            assertEquals(g, "C", RankLadder.modelGrade(g, true, strength = wcut)); assertEquals(g, "D", RankLadder.modelGrade(g, true, strength = wcut - 1e-9))
        }
        assertEquals("E", RankLadder.modelGrade("E", true, strength = 0.38)); for (g in listOf("F", "G", "H")) assertEquals(g, RankLadder.modelGrade(g, true, strength = 0.2))
        // reasons follow the mode
        assertNull(RankLadder.demotion("B", false, false, 14, grade = "C", mode = EntryMode.WEEKDAY_60))
        assertTrue(RankLadder.demotion("B", false, false, 14, grade = "C", mode = EntryMode.FIFTY_FIVE)!!.contains("52.8%"))
        assertTrue(RankLadder.demotion("D", true, false, 14, grade = "C", mode = EntryMode.WEEKDAY_60)!!.contains("49.1%"))
        assertNull(RankLadder.demotion("D", true, false, 14, grade = "C", mode = EntryMode.ALL_60))
        assertTrue(RankLadder.demotion("S", true, false, 14, grade = "C", mode = EntryMode.FIFTY_FIVE)!!.contains("追いかける"))
        assertTrue(RankLadder.demotion("A", false, false, 14, grade = "D", mode = EntryMode.ALL_60)!!.contains("50.8%"))
        assertNull(RankLadder.demotion("D", true, false, 14, grade = "D", mode = EntryMode.ALL_60))
    }

    @Test fun realSlotsFollowTheModeAndTheCuts() {
        val seen = HashMap<String, Int>()
        for (s in EvidenceFixture.slots) for (mode in EntryMode.values()) {
            EvidencePolicy.resetState()
            val top = EvidencePolicy.apply(s.native(), s.native(), s.candles(), s.quotes(), mode).top1!!
            val note = top.reasons[1]; val label = top.assessment!!.correctionLabel!!.removePrefix("【3分判定】").removePrefix("【5分判定】")
            assertTrue(note, " MODE=${mode.key}" in note)
            val rule = " RULE=" in note; val caution = " CAUTION" in note
            if (!rule && !caution) {
                val e = Regex(" e=([0-9.]+)").find(note)!!.groupValues[1].toDouble()
                val r = Regex(" r=([0-9.]+)").find(note)!!.groupValues[1].toDouble()
                val v48 = Regex(" v0748=([A-Z])").find(note)!!.groupValues[1]
                // v0.7.57: weekday C/D come from the 5-minute model (FiveMinuteV0757Test); the weekend keeps the v0.7.56 C
                if (top.grade == "C" && s.weekend) assertTrue(note, e >= RankLadder.weekendCut(" fresh" in note) - 1e-4)
            }
            assertEquals("$mode ${top.grade} $note", !caution && mode.enters(top.grade, s.weekend), top.decision == "ENTRY")
            if (top.grade == "C") {
                seen.merge("C|${s.weekend}|${top.decision}", 1, Int::plus)
                if (top.decision == "ENTRY") assertTrue(label, label.contains("設定「${mode.label}」で入るC"))
                else assertTrue(label, label.startsWith("見送り C") && label.contains("設定「${mode.label}」"))   // label without the 【N分判定】 prefix
            }
        }
        // the fixture holds weekday former-C slots on both sides of the cut and weekend slots in the top 60%
        assertTrue(seen.toString(), (seen["C|false|ENTRY"] ?: 0) > 0 && (seen["C|false|SKIP"] ?: 0) > 0)
        assertTrue(seen.toString(), (seen["C|true|ENTRY"] ?: 0) > 0 && (seen["C|true|SKIP"] ?: 0) > 0)
    }

    @Test fun skippedCIsFollowedAndCountedApart() {
        val tag = EvidencePolicy.POLICY_TAG
        assertTrue(ObservationPolicy.tracks("SKIP", "C", tag)); assertFalse(ObservationPolicy.tracks("ENTRY", "C", tag))
        assertFalse(ObservationPolicy.tracks("SKIP", "C", "GMK_V0740_V0755_EVIDENCE"))      // no earlier version skipped a C
        fun row(id: String, grade: String, decision: String, status: String, at: String = "2026-11-02T10:05:00+09:00") =
            HistoryRow(id.hashCode().toLong(), id, "AUTO", at, "USDJPY", "HIGH", grade, decision, entryTimeJst = at,
                judgeTimeJst = java.time.ZonedDateTime.parse(at).plusMinutes(3).toString(), entryRate = 150.0, judgeRate = 150.1, resultStatus = status, policyVersion = tag)
        val rows = listOf(row("a", "C", "ENTRY", "WIN"), row("b", "C", "ENTRY", "LOSE"), row("c", "C", "SKIP", "WIN"),
            row("d", "B", "ENTRY", "WIN"), row("e", "D", "SKIP", "LOSE", "2026-11-02T11:05:00+09:00"))
        val t = RankStatistics.tables(rows).single()
        val lines = t.counts.map { RankStatistics.lineText(t, it) }
        assertTrue(lines.toString(), lines.any { it.startsWith("C  1勝1敗 50.0%") && it.contains("検証 53.2%") })   // v0.7.59 weekday C
        assertTrue(lines.toString(), lines.any { it.startsWith("C  見送り 1件・入っていたら 1勝0敗") })
        assertEquals(1, t.counts.count { it.skipped }); assertTrue(RankStatistics.isSkipCount(t, t.counts.single { it.skipped }))
        val s = historyStatistics(rows).getValue(3)
        assertEquals(3, s.entries); assertEquals(2, s.skipShadow)
        val share = RankStatistics.entryShareByHour(rows).getValue("平日")
        assertEquals(4 to 3, share[10]); assertEquals(1 to 0, share[11])
        assertEquals("平日 ENTRY 60%（3/5枠）", RankStatistics.entryShareText(rows))
        assertTrue(RankFilter.matches(rows[2], "C")); assertFalse(RankFilter.matches(rows[2], "D〜H"))
    }
}

package jp.gmk.mobile.runtime

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import jp.gmk.mobile.MainActivity

/**
 * v0.7.54 signal notifications (rules in domain/SignalAlerts). A refused permission or an OS error never affects a scan:
 * every failure simply returns false and is counted in the diagnostics.
 */
object GmkSignalNotifier {
    private const val CHANNEL_ID = "gmk_signals_v0754"
    @Volatile var posted = 0L
        private set
    @Volatile var failed = 0L
        private set
    @Volatile var lastError: String? = null
        private set

    fun permitted(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun ensureChannel(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "GMK シグナル", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "3分のENTRY（S〜B）と時間帯ルールの直前のお知らせ"
                    setShowBadge(true)
                }
            )
        }
    }

    fun post(context: Context, id: Int, title: String, text: String, timeoutMs: Long): Boolean {
        if (!permitted(context)) { failed++; lastError = "POST_NOTIFICATIONS not granted"; return false }
        return try {
            val manager = ContextCompat.getSystemService(context, NotificationManager::class.java)
                ?: run { failed++; lastError = "NotificationManager unavailable"; return false }
            ensureChannel(manager)
            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentTitle(title)
                .setContentText(text.lineSequence().firstOrNull().orEmpty())
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setAutoCancel(true)
                .setTimeoutAfter(timeoutMs)
                .setContentIntent(open)
                .build()
            manager.notify(id, notification)
            posted++
            true
        } catch (e: SecurityException) {
            failed++; lastError = "SecurityException: ${e.message.orEmpty()}".take(160); false
        } catch (e: RuntimeException) {
            failed++; lastError = "${e.javaClass.simpleName}: ${e.message.orEmpty()}".take(160); false
        }
    }
}

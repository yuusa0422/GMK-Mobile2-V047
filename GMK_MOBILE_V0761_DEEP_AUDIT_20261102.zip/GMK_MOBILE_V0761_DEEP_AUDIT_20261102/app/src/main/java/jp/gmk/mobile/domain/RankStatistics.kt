package jp.gmk.mobile.domain

import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * v0.7.50: bitbank 1-minute candlestick files are partitioned by UTC day (yyyyMMdd = 00:00-23:59 UTC = 09:00-08:59 JST).
 * Up to v0.7.49 the app asked for the JST day and added the previous day only below 30 bars, so scans for
 * 09:35-10:00 JST had 35-60 BTC bars (61 needed): weekday BTC dropped out of the choice, weekend slots became I.
 */
object BitbankDays {
    private val FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd")
    fun key(epochMs: Long): String = Instant.ofEpochMilli(epochMs).atZone(ZoneOffset.UTC).format(FMT)
    /** Newest first: the UTC day of [nowMs], then the UTC day [lookbackMinutes] earlier when it differs. */
    fun keys(nowMs: Long, lookbackMinutes: Long): List<String> =
        listOf(key(nowMs), key(nowMs - lookbackMinutes * 60_000L)).distinct()
    /** UTC day key [dayOffset] days before [nowMs] (horizon background history). */
    fun keyDaysBefore(nowMs: Long, dayOffset: Int): String =
        Instant.ofEpochMilli(nowMs).atZone(ZoneOffset.UTC).minusDays(dayOffset.toLong()).format(FMT)
}

/**
 * v0.7.50: a D..H skip of the 3-minute evidence policy is followed exactly like an ENTRY
 * ("if it had been entered"). The result is stored on the SKIP row; OutcomeStatistics already
 * counts such rows only as skips, so they never enter a win rate or a losing streak.
 */
object ObservationPolicy {
    val GRADES = setOf("D", "E", "F", "G", "H")
    /** v0.7.56: a C that the ENTRY amount setting skips is followed too (no earlier version skipped a C). */
    const val C_SKIP_SINCE = "0.7.56"
    /** v0.7.54: every 1-minute board row is observation only and is followed too. */
    fun tracks(decision: String, grade: String, policyVersion: String): Boolean =
        decision == "SKIP" && ((grade in GRADES && RankStatistics.evidenceVersion(policyVersion) != null) ||
            (grade == "C" && RankStatistics.atLeast(RankStatistics.evidenceVersion(policyVersion), C_SKIP_SINCE)) ||
            OneMinuteObservation.isObservation(policyVersion))
    fun tracks(row: HistoryRow): Boolean = tracks(row.decision, row.grade, row.policyVersion)
}

/** [skipped]: v0.7.56 C rows skipped by the ENTRY amount setting are counted apart from the C rows that were entered. */
class RankCount(val grade: String, val skipped: Boolean = false) {
    var wins = 0
    var losses = 0
    var pending = 0
    var unresolved = 0
    var total = 0
    val resolved: Int get() = wins + losses
    val rate: Double? get() = if (resolved > 0) wins.toDouble() / resolved else null
}

class RankTable(
    val key: String,
    val title: String,
    val oneMinute: Boolean,
    val counts: List<RankCount>,
    val validated: Map<String, Double>,
    /** v0.7.54: the 1-minute board is observation only - every grade is a skip ("if entered"). */
    val observationOnly: Boolean = false
)

/**
 * v0.7.54: the 1-minute board (OneMinuteLocalEngine, a momentum-following heuristic) replayed on one year of real 1-minute
 * candles (scripts/onemin_sim_v0754.py): weekday 45.0% (draws 10.4%), weekend 30.6% (draws 42.1%); every confidence grade
 * 43-47% on weekdays, every period below 46%. Reversed it is 44.7% (a draw loses both ways). The best simple 1-minute trade
 * found (fade an FX spike of 3 sigma or more: 53.6% over the year) fell to 49.5% in September and 41.6% in October 2026.
 * No 1-minute trade is validated, so the board is shown for reference and its rows are SKIP observations.
 */
object OneMinuteObservation {
    const val POLICY = "GMK_V0735_NATIVE_1M_V0754_OBSERVE"
    const val GRADE = "E"
    const val REASON = "1分ボードは参考表示（1年の再現で平日45.0%・土日30.6%、反対向きも44.7%）。1分で勝てる形は見つかっていないため見送り"
    fun isObservation(policyVersion: String): Boolean = policyVersion.startsWith(POLICY)
}

/** History by operational grade: 3-minute evidence rows per app version and weekday/weekend; the 1-minute board apart. */
object RankStatistics {
    const val ONE_MINUTE_POLICY = "GMK_V0735_NATIVE_1M"
    val ORDER = listOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I")
    val ONE_MINUTE_ORDER = listOf("S", "A", "B", "C", "E")
    /** Versions whose ranks are the current v0.7.57 ranks (validated column shown). Earlier versions used other rank rules. */
    val CURRENT_RANK_VERSIONS = setOf("0.7.59")
    const val NOTE = "勝率は ENTRY だけ。「見送り・入っていたら」は見送った枠をそのまま入った場合の参考で、勝率・連敗には入りません。" +
        "検証%は1年分を、作ったのとは別の期間で採点した勝率（S/Aの時間帯ルールは偶然の可能性も残るため実際は少し低めを見込む）。" +
        "v0.7.58: 平日は為替だけを毎分判定し、どの1時間も70%以上ENTRY。S/A（時間帯ルール3つ）は3分判定、B/C/D は5分判定。" +
        "S/A/B は55%以上、C は70%に入る分（平日53.2%）、土日のCは47.9%。同じ向き（円の同じ賭け）の重ね入りは控えめ。" +
        "設定で見送ったCは「C 見送り」に入ります。v0.7.56以前の表はランクの決め方が違います。1分ボードは参考表示のみ。" +
        "件数が少ないうちは上下に大きくぶれます。"
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")
    private val VERSION = Regex("^GMK_V0740_V(\\d)(\\d)(\\d)(\\d)")

    fun isOneMinute(row: HistoryRow): Boolean = row.policyVersion.startsWith(ONE_MINUTE_POLICY)

    /** "0.7.49" for GMK_V0740_V0749_EVIDENCE..., null for any other policy. */
    fun evidenceVersion(policyVersion: String): String? =
        VERSION.find(policyVersion)?.groupValues?.let { "${it[1]}.${it[2]}.${it[3]}${it[4]}" }

    fun versionKey(v: String?): Int = v?.split('.')?.mapNotNull { it.toIntOrNull() }?.fold(0) { a, b -> a * 100 + b } ?: -1
    /** True when evidence version [v] (e.g. "0.7.56") is [min] or later; false for null. */
    fun atLeast(v: String?, min: String): Boolean = v != null && versionKey(v) >= versionKey(min)

    fun isWeekend(entryTimeJst: String): Boolean? =
        runCatching { ZonedDateTime.parse(entryTimeJst).withZoneSameInstant(JST).dayOfWeek.value >= 6 }.getOrNull()

    fun tables(rows: List<HistoryRow>): List<RankTable> {
        class Group(val title: String, val oneMinute: Boolean, val version: String?, val weekend: Boolean, val counts: LinkedHashMap<String, RankCount>,
                    val observe: Boolean = false)
        val groups = LinkedHashMap<String, Group>()
        for (r in rows) {
            val weekend = isWeekend(r.entryTimeJst) ?: continue
            val seg = if (weekend) "土日" else "平日"
            val oneMinute = isOneMinute(r)
            val version = if (oneMinute) null else evidenceVersion(r.policyVersion) ?: continue
            val order = if (oneMinute) ONE_MINUTE_ORDER else ORDER
            if (r.grade !in order) continue
            val observe = oneMinute && OneMinuteObservation.isObservation(r.policyVersion)
            val key = if (observe) "1mobs|$seg" else if (oneMinute) "1m|$seg" else "$version|$seg"
            val g = groups.getOrPut(key) {
                val title = if (observe) "1分ボード $seg（参考・見送り）" else if (oneMinute) "1分ボード $seg（簡易ルール・検証なし）" else "3分 v$version $seg"
                Group(title, oneMinute, version, weekend, LinkedHashMap<String, RankCount>().also { m ->
                    order.forEach { m[it] = RankCount(it); if (it == "C" && !oneMinute) m[C_SKIP_KEY] = RankCount("C", skipped = true) }
                }, observe)
            }
            val skippedC = !oneMinute && r.grade == "C" && r.decision == "SKIP"
            val c = g.counts.getValue(if (skippedC) C_SKIP_KEY else r.grade)
            c.total++
            when (r.resultStatus) {
                "WIN" -> c.wins++
                "LOSE" -> c.losses++
                "WAIT_ENTRY", "WAIT_JUDGE" -> c.pending++
                else -> c.unresolved++
            }
        }
        return groups.entries
            .sortedWith(compareBy<Map.Entry<String, Group>> { if (it.value.oneMinute) 1 else 0 }
                .thenBy { if (it.value.observe) 0 else 1 }
                .thenByDescending { versionKey(it.value.version) }
                .thenBy { if (it.value.weekend) 1 else 0 })
            .map { (key, g) ->
                val validated = if (!g.oneMinute && g.version in CURRENT_RANK_VERSIONS)
                    g.counts.values.map { it.grade }.distinct().mapNotNull { grade -> EvidencePolicy.gradeRate(true, g.weekend, grade)?.let { grade to it } }.toMap()
                else emptyMap()
                RankTable(key, g.title, g.oneMinute, g.counts.values.filter { it.total > 0 }, validated, g.observe)
            }
    }

    private fun pct(x: Double): String = String.format(Locale.US, "%.1f%%", x * 100.0)

    private const val C_SKIP_KEY = "C|SKIP"

    /**
     * v0.7.56: share of 3-minute AUTO slots entered, per segment ("平日"/"土日") and JST hour: hour -> (slots, ENTRY).
     * Only rows of the current policy version are counted (other versions entered other amounts).
     */
    fun entryShareByHour(rows: List<HistoryRow>): Map<String, Map<Int, Pair<Int, Int>>> {
        val out = LinkedHashMap<String, java.util.TreeMap<Int, Pair<Int, Int>>>()
        val current = evidenceVersion(EvidencePolicy.POLICY_TAG)
        for (r in rows) {
            if (r.source != "AUTO" || r.candidateRank != 1 || isOneMinute(r) || evidenceVersion(r.policyVersion) != current) continue
            val t = runCatching { ZonedDateTime.parse(r.entryTimeJst).withZoneSameInstant(JST) }.getOrNull() ?: continue
            val seg = if (t.dayOfWeek.value >= 6) "土日" else "平日"
            val m = out.getOrPut(seg) { java.util.TreeMap() }
            val old = m[t.hour] ?: (0 to 0)
            // v0.7.58: the slots are the 5-minute boundaries; ENTRY rows of the minutes between them count as entries of that hour
            val slot = t.second == 0 && t.minute % 5 == 0
            m[t.hour] = (old.first + (if (slot) 1 else 0)) to (old.second + if (r.decision == "ENTRY") 1 else 0)
        }
        return out
    }

    /** One line per segment: "平日 ENTRY 61%（120/197枠）" for the history panel; empty when nothing is recorded yet. */
    fun entryShareText(rows: List<HistoryRow>): String = entryShareByHour(rows).entries.joinToString("　") { (seg, hours) ->
        val slots = hours.values.sumOf { it.first }; val entries = hours.values.sumOf { it.second }
        "$seg ENTRY ${if (slots > 0) Math.round(entries * 100.0 / slots) else 0}%（$entries/${slots}枠）"
    }

    fun isSkipGrade(table: RankTable, grade: String): Boolean =
        grade == "I" || grade in ObservationPolicy.GRADES || (table.oneMinute && grade == "E") || table.observationOnly
    fun isSkipCount(table: RankTable, c: RankCount): Boolean = c.skipped || isSkipGrade(table, c.grade)

    fun lineText(table: RankTable, c: RankCount): String {
        val wait = if (c.pending > 0) "（判定待ち${c.pending}）" else ""
        val v = table.validated[c.grade]?.let { " ｜検証 ${pct(it)}" } ?: ""
        return when {
            c.grade == "I" -> "I  判定不能 ${c.total}件（データ不足など・観察のみ）"
            isSkipCount(table, c) -> "${c.grade}  見送り ${c.total}件" +
                (c.rate?.let { "・入っていたら ${c.wins}勝${c.losses}敗 ${pct(it)}" } ?: "") + wait + v
            else -> "${c.grade}  ${c.wins}勝${c.losses}敗 ${c.rate?.let(::pct) ?: "—"}" + wait + v
        }
    }
}

/** History list filter by operational grade (replaces the retired chart-similarity E..H filter). */
object RankFilter {
    val filters = listOf("すべて", "S", "A", "B", "C", "D〜H", "I", "1分")
    fun matches(row: HistoryRow, filter: String): Boolean {
        val oneMinute = RankStatistics.isOneMinute(row)
        return when (filter) {
            "すべて" -> true
            "1分" -> oneMinute
            "D〜H" -> !oneMinute && row.grade in ObservationPolicy.GRADES
            else -> !oneMinute && row.grade == filter
        }
    }
}

"""v0.7.50 audit fixes: source gate layered on the unchanged v0.7.49 audit.

Every v0.7.49 check is re-run. Rows that fail only because a v0.7.50-modified file changed are re-pinned to the
v0.7.50 bytes. Models, strength ladder, pattern tables and the ENTRY/rank rule are unchanged; the fixes are pinned below.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'
EXPIRY = D + 'domain/ExpiryProfiles.kt'
RANKS = D + 'domain/RankStatistics.kt'
REPO = D + 'data/MarketRepository.kt'
STORE = D + 'data/HistoryStore.kt'
VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'
GRADLE = 'app/build.gradle.kts'
TEST = 'app/src/test/java/AuditFixV0750Test.kt'
# Rows of earlier audits that describe one exact earlier edit of a file v0.7.50 edits again.
SUPERSEDED = {
    'expiry_original_operations_identical_with_metadata_projection': EXPIRY,
    'viewmodel_only_live_quote_call_changed': VM,
    'repository_only_records_yahoo_meta_quote': REPO,
}


def audit():
    spec = importlib.util.spec_from_file_location('v0749_audit', ROOT/'tools/audit_v0749.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0750_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0750_audit_fix:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.49 source bytes plus the pinned v0.7.50 change only.')
        elif name in SUPERSEDED and not row['pass']:
            p = SUPERSEDED[name]
            row.update(check='authorized_v0750_audit_fix:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; the file carries the pinned v0.7.50 change on top of it.')
        elif name == 'evidence_model_frozen_parameters_v0749':
            row.update(check='evidence_model_frozen_parameters_v0750', **{'pass': all(s in policy for s in (
                'const val VERSION = "V0750_AUDIT_FIX"', 'const val POLICY_TAG = "GMK_V0740_V0750_EVIDENCE"',
                'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER',
                'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER', 'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576',
                'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
                'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]',
                'val pm = if (choice.fresh) choice.patternCodes?.let { EvidencePatterns.decide(it, dirInt, decision.enter) } else null',
                'val grade = when { pm != null -> EvidencePatterns.grade(pm.pattern.rate); decision.enter -> "C"; else -> decision.grade }'))},
                detail='v0.7.50: strength ENTRY rule and v0.7.49 pattern ranks unchanged; only tags and the I-row record changed.')
        elif name == 'gradle_only_version_changed_v0749':
            row.update(check='gradle_only_version_changed_v0750', **{'pass': sha_text(gradle.replace('versionCode = 120', 'versionCode = 119')
                       .replace('versionName = "0.7.50-audit-fix"', 'versionName = "0.7.49-pattern-ranks"')) == changed[GRADLE]['v0749_sha256']})
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*120\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.50-audit-fix"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    known = {}
    for v in ('0744', '0745', '0746', '0747', '0748', '0749'):
        m = json.loads((ROOT/f'tools/v{v}_source_extension.json').read_text())
        mod = m['modified_existing']
        if isinstance(mod, dict): known |= {p: x['updated_sha256'] for p, x in mod.items()}
        nsf = m.get('new_source_files', {})
        if isinstance(nsf, dict): known |= nsf
    old_zip_files = {}
    pkg = ROOT/'PACKAGE_MANIFEST_SHA256.txt'
    for path, item in changed.items():
        check('pinned_v0750_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0749_original_before_v0750:' + path, known[path] == item['v0749_sha256'])
    for path, digest in new.items():
        check('pinned_v0750_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    repo = (ROOT/REPO).read_text(); store = (ROOT/STORE).read_text(); vm = (ROOT/VM).read_text(); main = (ROOT/MAIN).read_text()
    expiry = (ROOT/EXPIRY).read_text(); ranks = (ROOT/RANKS).read_text(); test = (ROOT/TEST).read_text()
    check('v0750_bitbank_utc_day_files', 'jp.gmk.mobile.domain.BitbankDays.keys(System.currentTimeMillis(), 130L)' in repo
          and 'jp.gmk.mobile.domain.BitbankDays.key(targetEpochMs)' in repo and 'BitbankDays.keyDaysBefore(System.currentTimeMillis(),dayOffset)' in repo
          and 'loadDate(now.minusDays(1))' not in repo and 'atZone(ZoneOffset.UTC)' in ranks)
    check('v0750_history_filter', 'RankStatistics.evidenceVersion(row.policyVersion) != null || RankStatistics.isOneMinute(row)' in expiry
          and 'const val ONE_MINUTE_POLICY = "GMK_V0735_NATIVE_1M"' in ranks)
    check('v0750_observation_is_skip_only', 'decision == "SKIP" && grade in GRADES && RankStatistics.evidenceVersion(policyVersion) != null' in ranks
          and 'jp.gmk.mobile.domain.ObservationPolicy.tracks(top.decision, top.grade, result.policyVersion)) "WAIT_ENTRY" else "SKIP"' in store
          and 'if (top.decision != "ENTRY" && !ObservationPolicy.tracks(top.decision, top.grade, result.policyVersion)) return' in vm
          and '(it.decision == "ENTRY" || ObservationPolicy.tracks(it)) && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")' in vm
          and 'policyVersion = h.policyVersion' in vm)
    stats = (ROOT/'app/src/main/java/jp/gmk/mobile/domain/OutcomeStatistics.java').read_text()
    check('v0750_skip_rows_never_in_win_rate', 'if(row.decision.equals("SKIP")){skips++;if(row.status.equals("WIN")||row.status.equals("LOSE"))skipShadow++;return;}' in stats)
    check('v0750_one_minute_session_rule', 'val required = TradingSession.requiredInstruments(entry)' in vm and 'if (eligible.size != required.size) {' in vm
          and 'result.candidates.size != required.size' in vm)
    check('v0750_contract_check_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm)
    check('v0750_ui_rank_panel', 'RankStatsPanel(rows)' in main and 'RankFilterChips(rows, rankFilter) { rankFilter = it }' in main
          and 'if (hasLegacyChartRanks) {' in main and 'val reference = evidenceScan && c.rank != 1' in main)
    check('v0750_i_row_record', 'judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)' in policy and 'val label = "判定不能 I（$why・観察のみ）"' in policy)
    check('v0750_tests_present', all(f'fun {n}()' in test for n in (
        'bitbankDayFilesAreUtcDaysAndTheMorningWindowSpansTwoFiles', 'historyCountsOneMinuteBoardAndEvidenceRowsWhateverTheThreeMinuteSwitch',
        'onlyEvidenceSkipsDtoHAreObservedAndTheyNeverEnterWinRateOrStreak', 'rankTableSeparatesVersionsSegmentsAndTheOneMinuteBoard',
        'rankFilterUsesOperationalGradesAndKeepsTheOneMinuteBoardApart', 'undecidableSlotIsAnIRowOfThisPolicyWithAThreeMinuteJudge')))
    for f in ('EvidencePatternData.kt', 'EvidencePatterns.kt', 'EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModel.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        p = D + 'domain/' + f
        if p in known: check('v0750_model_file_unchanged:' + f, sha(ROOT/p) == known[p])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0750_AUDIT_FIX_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.50-audit-fix')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""v0.7.52 confirmed ranks: source gate layered on the unchanged v0.7.51 audit.

Every v0.7.51 check is re-run; rows that fail only because a v0.7.52-modified file changed are re-pinned to the v0.7.52 bytes,
and rows describing an exact earlier edit of a file changed again are replaced by the v0.7.52 gates below.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; VM = D + 'ui/GmkViewModel.kt'; REPO = D + 'data/MarketRepository.kt'
GRADLE = 'app/build.gradle.kts'; TEST = 'app/src/test/java/ConfirmedRanksV0752Test.kt'
SUPERSEDED = {
    'v0751_policy_constants': POLICY, 'v0751_ladder': RULES, 'gradle_only_version_changed_v0751': GRADLE,
    'authorized_v0751_session_ranks:v0749_pattern_overlay': POLICY, 'authorized_v0751_session_ranks:evidence_model_frozen_parameters_v0750': POLICY,
    'authorized_v0751_session_ranks:v0750_i_row_record': POLICY, 'authorized_v0751_session_ranks:gradle_only_version_changed_v0750': GRADLE,
    'authorized_v0751_session_ranks:authorized_v0750_audit_fix:viewmodel_only_live_quote_call_changed': VM,
    'authorized_v0750_audit_fix:repository_only_records_yahoo_meta_quote': REPO,
    'evidence_policy_runs_after_every_overlay_with_live_quotes': VM,   # the evidence policy now runs on the native scan directly
}


def audit():
    spec = importlib.util.spec_from_file_location('v0751_audit', ROOT/'tools/audit_v0751.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0752_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0752_confirmed_ranks:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.51 source bytes plus the pinned v0.7.52 change only.')
        elif name in SUPERSEDED and not row['pass']:
            p = SUPERSEDED[name]
            row.update(check='authorized_v0752_confirmed_ranks:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; replaced by the v0.7.52 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*122\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.52-confirmed-ranks"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v51 = json.loads((ROOT/'tools/v0751_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v51['modified_existing'].items()} | v51['new_source_files']
    for path, item in changed.items():
        check('pinned_v0752_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0751_original_before_v0752:' + path, known[path] == item['v0751_sha256'])
    for path, digest in new.items():
        check('pinned_v0752_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0752', sha_text(gradle.replace('versionCode = 122', 'versionCode = 121')
          .replace('versionName = "0.7.52-confirmed-ranks"', 'versionName = "0.7.51-session-ranks"')) == changed[GRADLE]['v0751_sha256'])
    rules = (ROOT/RULES).read_text(); vm = (ROOT/VM).read_text(); repo = (ROOT/REPO).read_text(); test = (ROOT/TEST).read_text()
    check('v0752_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0752_CONFIRMED_RANKS"', 'const val POLICY_TAG = "GMK_V0740_V0752_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)',
        'val modelGrade = RankLadder.modelGrade(decision.grade, weekend, confirmed)')))
    check('v0752_ladder', all(s in rules for s in (
        '"S" -> if (weekend) "B" else if (confirmed) "B" else "C"', '"A" -> if (weekend) "C" else if (confirmed) "B" else "C"', '"B", "C" -> "C"',
        'const val FX_SPIKE_SIGMA = 2.5', 'const val BTC_FOLLOW_LOW = 1.0', 'const val BTC_FOLLOW_HIGH = 3.0',
        'return if (instrument == "BTCJPY") rel >= BTC_FOLLOW_LOW && rel < BTC_FOLLOW_HIGH else rel <= -FX_SPIKE_SIGMA')))
    check('v0752_event_rules_unchanged', all(s in rules for s in (
        'Rule("FIX955_POS", "S", Clock.JST, 9 * 60 + 55, Feature.POS60L, 0.8, true,', 'Rule("JST1220_POS", "A", Clock.JST, 12 * 60 + 20, Feature.POS60L, 0.8, false,',
        'Rule("JST2250_R15", "A", Clock.JST, 22 * 60 + 50, Feature.R15, 1.0, false,', 'Rule("LON0725_R5", "A", Clock.LONDON, 7 * 60 + 25, Feature.R5, 1.0, false,')))
    check('v0752_legacy_horizon_not_used', 'horizonRuntime.start(' not in vm and 'horizonRuntime.apply(' not in vm
          and 'EvidencePolicy.apply(native, native, eligible, liveQuotes)' in vm)
    check('v0752_btc_forming_minute_live_price', 'if (ts == currentMinuteStartMs) forming = Candle(ts, open, high, low, close, volume)' in repo
          and 'forming?.let { LiveQuoteBoard.record("BTCJPY", it.close, System.currentTimeMillis()) }' in repo and repo.count('LiveQuoteBoard.record(') == 2)
    check('v0752_diagnostics', '"backup_model_rows"' in vm and 's.history.take(3000).forEach { h ->' in vm)
    check('v0752_contract_check_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm)
    check('v0752_tests_present', all(f'fun {n}()' in test for n in ('confirmationRulesFollowTheResearchFlags', 'realSlotsMarkConfirmedTradesExactly',
          'ladderRatesAreOrderedAndBackupModelHasNoConfirmedTier')))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0752_CONFIRMED_RANKS_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.52-confirmed-ranks')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

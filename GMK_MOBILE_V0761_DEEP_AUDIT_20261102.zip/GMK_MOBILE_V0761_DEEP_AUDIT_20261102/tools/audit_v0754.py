"""v0.7.54 loss patterns: source gate layered on the unchanged v0.7.53 audit.

Every v0.7.53 check is re-run; rows that fail only because a v0.7.54-modified file changed are re-pinned to the v0.7.54 bytes,
and rows describing an exact earlier edit of a file changed again are replaced by the v0.7.54 gates below.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
OUTCOME = D + 'domain/OutcomeStatistics.java'; VM = D + 'ui/GmkViewModel.kt'; REPO = D + 'data/MarketRepository.kt'
MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'; PREFS = D + 'data/AppPrefs.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/LossPatternsV0754Test.kt'; SKEW = 'app/src/test/java/ClockSkewV0754Test.kt'
NOTIFIER = D + 'runtime/GmkSignalNotifier.kt'; CLOCK = D + 'domain/ProviderClock.kt'; ALERTS = D + 'domain/SignalAlerts.kt'
SUPERSEDED = {
    'v0750_observation_is_skip_only': STATS, 'v0750_skip_rows_never_in_win_rate': OUTCOME, 'v0752_ladder': RULES,
    'authorized_v0752_confirmed_ranks:evidence_policy_runs_after_every_overlay_with_live_quotes': VM,
    'authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:authorized_v0750_audit_fix:viewmodel_only_live_quote_call_changed': VM,
    'authorized_v0752_confirmed_ranks:authorized_v0750_audit_fix:repository_only_records_yahoo_meta_quote': REPO,
    'authorized_v0753_more_rules:authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:evidence_model_frozen_parameters_v0750': POLICY,
    'authorized_v0753_more_rules:authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:gradle_only_version_changed_v0750': GRADLE,
    'authorized_v0753_more_rules:authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:v0749_pattern_overlay': POLICY,
    'authorized_v0753_more_rules:authorized_v0752_confirmed_ranks:gradle_only_version_changed_v0751': GRADLE,
    'authorized_v0753_more_rules:authorized_v0752_confirmed_ranks:v0751_policy_constants': POLICY,
    'authorized_v0753_more_rules:authorized_v0752_confirmed_ranks:v0751_ladder': RULES,
    'authorized_v0753_more_rules:v0751_rank_rule': POLICY, 'authorized_v0753_more_rules:v0751_event_rules': RULES,
    'authorized_v0753_more_rules:gradle_only_version_changed_v0752': GRADLE, 'authorized_v0753_more_rules:v0752_policy_constants': POLICY,
    'authorized_v0753_more_rules:v0752_event_rules_unchanged': RULES,
    'gradle_only_version_changed_v0753': GRADLE, 'v0753_policy_constants': POLICY, 'v0753_rank_rule': POLICY, 'v0753_ladder': RULES,
    'v0753_rank_statistics_version': STATS, 'v0753_viewmodel_repository_unchanged_since_v0752': VM,
    'v0753_main_activity_only_legend_text': MAIN, 'v0753_build_release': BUILD,
}
RULE_LINES = (
    'Rule("FIX955_POS", Clock.JST, 9 * 60 + 55, Feature.POS60L, true,', 'Rule("FIX955_BBZ", Clock.JST, 9 * 60 + 55, Feature.BBZL, true,',
    'Rule("JST1220_POS", Clock.JST, 12 * 60 + 20, Feature.POS60L, false,', 'Rule("JST2250_R15", Clock.JST, 22 * 60 + 50, Feature.R15, false,',
    'Rule("LON0725_R5", Clock.LONDON, 7 * 60 + 25, Feature.R5, false,', 'Rule("US0830_BBZ", Clock.NEW_YORK, 8 * 60 + 30, Feature.BBZL, false,',
    'Rule("US0830_F1", Clock.NEW_YORK, 8 * 60 + 30, Feature.F1, false,', 'Rule("UK0930_F1", Clock.LONDON, 9 * 60 + 30, Feature.F1, false,')


def audit():
    spec = importlib.util.spec_from_file_location('v0753_audit', ROOT/'tools/audit_v0753.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0754_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0754_loss_patterns:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.53 source bytes plus the pinned v0.7.54 change only.')
        elif name in SUPERSEDED and not row['pass']:
            p = SUPERSEDED[name]
            row.update(check='authorized_v0754_loss_patterns:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; replaced by the v0.7.54 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*124\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.54-loss-patterns"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v53 = json.loads((ROOT/'tools/v0753_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v53['modified_existing'].items()} | v53['new_source_files']
    for path, item in changed.items():
        check('pinned_v0754_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0753_original_before_v0754:' + path, known[path] == item['v0753_sha256'])
    for path, digest in new.items():
        check('pinned_v0754_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0754', sha_text(gradle.replace('versionCode = 124', 'versionCode = 123')
          .replace('versionName = "0.7.54-loss-patterns"', 'versionName = "0.7.53-more-rules"')) == changed[GRADLE]['v0753_sha256'])
    txt = {k: (ROOT/k).read_text() for k in (POLICY, RULES, STATS, OUTCOME, VM, REPO, MAIN, SCREENS, PREFS, TEST, SKEW, NOTIFIER, CLOCK, ALERTS, BUILD)}
    policy, rules, stats, vm, repo = txt[POLICY], txt[RULES], txt[STATS], txt[VM], txt[REPO]
    check('v0754_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0754_LOSS_PATTERNS"', 'const val POLICY_TAG = "GMK_V0740_V0754_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'const val MAX_STATE_AGE_SEC = 21L * 24 * 3600',
        'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
        'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]',
        'val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)')))
    check('v0754_rank_rule', all(s in policy for s in (
        'val decision = decide(choice, weekend, b, record = native.source == "AUTO")',
        'val modelGrade = RankLadder.modelGrade(decision.grade, weekend, confirmed, hourJst)',
        'val demoted = if (ruleMatch == null && decision.enter) RankLadder.demotion(decision.grade, weekend, confirmed, hourJst) else null',
        'val enter = caution == null && (ruleMatch != null || (decision.enter && demoted == null))',
        'caution != null -> if (decision.enter) "D" else modelGrade', 'ruleMatch != null -> ruleMatch.grade',
        'judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)')) and 'EvidencePatterns.decide' not in policy)
    check('v0754_ladder', all(s in rules for s in (
        '"S" to Rate(0.6820, 0.7692, 26), "A" to Rate(0.6007, 0.5949, 79), "B" to Rate(0.5602, 0.5407, 344)',
        '"C" to Rate(0.5222, 0.5213, 3290), "D" to Rate(0.5052, 0.4686, 350), "E" to Rate(0.4878, 0.5018, 566))',
        '"B" to Rate(0.5403, 0.5472, 307), "D" to Rate(0.4827, 0.4616, 873), "E" to Rate(0.4162, 0.4229, 551)',
        '"S", "A" -> if (confirmed) "B" else "C"', '"A", "B", "C" -> "D"', '"D", "E" -> "E"',
        'if (g == "C" && hourJst == PRE_FIX_HOUR) "E" else g', 'const val PRE_FIX_HOUR = 9', 'val ENTRY_GRADES = setOf("S", "A", "B", "C")',
        'const val FX_SPIKE_SIGMA = 2.5', 'const val BTC_FOLLOW_LOW = 1.0', 'const val BTC_FOLLOW_HIGH = 3.0')))
    check('v0754_event_rules_unchanged', all(s in rules for s in RULE_LINES + ('const val S_CONFLUENCE = 3',
          'NEW_YORK(ZoneId.of("America/New_York"))', 'Window(at(29, 22, 10), at(29, 23, 0),')) and rules.count('        Rule("') == 8)
    check('v0754_one_minute_observation', all(s in vm for s in (
        'grade = OneMinuteObservation.GRADE,', 'decision = "SKIP",', 'policyVersion = OneMinuteObservation.POLICY'))
          and 'decision = if (top.confidence >= 0.53) "ENTRY" else "SKIP"' not in vm
          and 'const val POLICY = "GMK_V0735_NATIVE_1M_V0754_OBSERVE"' in stats
          and 'OneMinuteObservation.isObservation(policyVersion))' in stats and 'table.observationOnly' in stats)
    check('v0754_observation_recovery', '.filter { (it.decision == "ENTRY" || ObservationPolicy.tracks(it)) && it.source != "MANUAL" }' in vm
          and '(it.decision == "ENTRY" || ObservationPolicy.tracks(it)) && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")' in vm
          and 'if (top.decision != "ENTRY" && !ObservationPolicy.tracks(top.decision, top.grade, result.policyVersion)) return' in vm)
    check('v0754_skip_rows_never_in_win_rate', 'if(row.decision.equals("SKIP")){skips++;if(row.status.equals("WIN")||row.status.equals("LOSE"))skipShadow++;if(row.status.equals("WIN"))skipShadowWins++;return;}' in txt[OUTCOME])
    check('v0754_provider_clock', 'jp.gmk.mobile.domain.ProviderClock.effective(rawTsMs,receivedMs)' in repo
          and repo.count('jp.gmk.mobile.domain.ProviderClock.effectiveSeconds(') == 3 and 'const val MAX_AHEAD_MS = 3_000L' in txt[CLOCK])
    check('v0754_signal_notifications', 'scheduleOutcomeTracking(result)\n            notifySignal(result)' in vm and 'startRuleAlertLoop()' in vm
          and 'ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED' in txt[NOTIFIER]
          and 'android.permission.POST_NOTIFICATIONS' in (ROOT/'app/src/main/AndroidManifest.xml').read_text()
          and 'const val PRE_ALERT_LEAD_SEC = 120L' in txt[ALERTS] and 'setSignalNotify = vm::setSignalNotify' in txt[MAIN])
    check('v0754_contract_check_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm)
    check('v0754_rank_statistics_version', 'val CURRENT_RANK_VERSIONS = setOf("0.7.54")' in stats)
    check('v0754_tests_present', all(f'fun {n}()' in txt[TEST] for n in ('modelGradeSkipsTheLosingContexts', 'ladderRatesForV0754',
          'realSlotsSkipWeekendCAndPreFixC', 'oneMinuteBoardIsObservationOnly', 'providerClockToleratesASmallLeadOnly',
          'signalAlertsFollowTheRulesAndTheCalendar')) and all(f'fun {n}()' in txt[SKEW] for n in ('tickSlightlyAheadOfThePhoneClockIsLive', 'tickFarAheadStaysInvalid')))
    build = txt[BUILD]
    check('v0754_build_release', 'VERSION_CODE = 124' in build and '"LossPatternsV0754Test": 6' in build and '"ClockSkewV0754Test": 2' in build
          and 'tools/audit_v0754.py' in build)
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModel.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        rows = [r for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}']
        check('v0754_model_file_unchanged_since_v0750:' + f, len(rows) == 1 and rows[0]['pass'])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0754_LOSS_PATTERNS_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.54-loss-patterns')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

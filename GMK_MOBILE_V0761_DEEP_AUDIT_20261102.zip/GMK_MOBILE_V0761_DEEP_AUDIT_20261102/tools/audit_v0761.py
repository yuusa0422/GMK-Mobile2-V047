"""v0.7.61 deep audit: source gate layered on the unchanged v0.7.60 audit.

Every v0.7.60 check is re-run; rows that fail only because a v0.7.61-modified file changed are re-pinned to the v0.7.61 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.61 gates below. The model and its data stay byte-identical; the decision
rule changes only in the hour quota (70% of the hour's slots the app runs, as the research counts the slots with data).
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
MODE = D + 'domain/EntryMode.kt'; VM = D + 'ui/GmkViewModel.kt'; MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'
MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'; ALERTS = D + 'domain/SignalAlerts.kt'
IDENTITY = D + 'domain/HistoryIdentity.kt'; LIVE = D + 'domain/LiveEntryState.kt'; STORE = D + 'data/HistoryStore.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/DeepAuditV0761Test.kt'; FIXTURE = 'app/src/test/resources/v0761_hour_slots_parity.txt.gz'
GATES60 = {'v0760_live_state': LIVE, 'v0760_notification_default': ALERTS, 'v0760_history_identity': IDENTITY,
           'v0760_one_minute_board_status': VM, 'v0760_tests_present': 'app/src/test/java/AuditFixV0760Test.kt', 'v0760_build_release': BUILD,
           'gradle_only_version_changed_v0760': GRADLE}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    old = load('v0760_audit', 'tools/audit_v0760.py'); result = old.audit()
    a59 = load('v0759_audit_map', 'tools/audit_v0759.py'); a58 = load('v0758_audit_map', 'tools/audit_v0758.py')
    a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.60 used
    EARLIER.update({
        'v0755_policy_constants': POLICY, 'v0755_rank_rule': POLICY, 'v0755_ladder': RULES, 'v0755_rank_statistics_version': STATS,
        'v0755_notification_grades': ALERTS, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': POLICY, 'v0756_rank_rule': POLICY, 'v0756_ladder': RULES, 'v0756_rank_statistics': STATS,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': POLICY,
        'v0756_entry_mode': MODE, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': ALERTS,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(old.GATES59); EARLIER.update(GATES60)
    manifest = json.loads((ROOT/'tools/v0761_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0761_deep_audit:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.60 source bytes plus the pinned v0.7.61 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0761_deep_audit:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.61; replaced by the v0.7.61 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*131\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.61-deep-audit"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m60 = json.loads((ROOT/'tools/v0760_source_extension.json').read_text()); m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m60['modified_existing'].items()}; known.update(m60['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0761_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0760_original_before_v0761:' + path, known[path] == item['v0760_sha256'])
    for path, digest in new.items():
        check('pinned_v0761_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0761', sha_text(gradle.replace('versionCode = 131', 'versionCode = 130')
          .replace('versionName = "0.7.61-deep-audit"', 'versionName = "0.7.60-audit-fix"')) == changed[GRADLE]['v0760_sha256'])
    check('v0761_rank_statistics_unchanged', STATS not in changed)
    for p in (MODEL, MODEL5):
        check('v0761_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    t = {k: (ROOT/k).read_text() for k in (POLICY, RULES, VM, MAIN, SCREENS, LIVE, STORE, TEST, BUILD)}
    check('v0761_hour_slots_rule', all(s in t[RULES] for s in (
        'fun minuteCut(fresh: Boolean, hourJst: Int, minuteOfHour: Int, hourEntries: Int, hourSlots: Int = 12): MinuteCut {',
        'val need = hourQuota(hourSlots.coerceIn(0, 12)) - hourEntries; val left = (60 - minuteOfHour).coerceIn(1, 60)',
        'const val SAME_DIRECTION_PENALTY = 0.03', 'const val HOUR_SHARE = 0.7')))
    check('v0761_policy_slots', all(s in t[POLICY] for s in (
        'const val POLICY_TAG = "GMK_V0740_V0759_EVIDENCE"',
        'mode: EntryMode = EntryMode.FIFTY_FIVE, hourEntries: Int = 0, openHigh: Int = 0, openLow: Int = 0, hourSlots: Int = 12): ScanResult {',
        'val mc = five?.let { RankLadder.minuteCut(it.fresh, hourJst, minuteOfHour, hourEntries, hourSlots) }',
        'val fiveGrade = if (five != null && mc != null) (if (five.probability >= mc.cut) "C" else "D") else null',
        ' slots=$hourSlots', '回/${hourSlots}枠）まであと')))
    check('v0761_live_slots', all(s in t[LIVE] for s in (
        'data class State(val hourEntries: Int, val openHigh: Int, val openLow: Int, val hourSlots: Int = 12)',
        'if (e != null && e.second == 0 && e.minute % 5 == 0 && !e.isBefore(hourStart) && e.isBefore(entry)) seen++',
        'if (r.source == "AUTO" && e.second == 0 && e.minute % 5 == 0) seen++', 'val ahead = (entry.minute..59).count { it % 5 == 0 }',
        'return State(hour, high, low, seen + ahead)', 'if (!e.isBefore(entry) || e.isBefore(from)) continue',
        'if (j.isAfter(entry)) { if (r.direction == "HIGH") high++ else if (r.direction == "LOW") low++ }'))
          and 'EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode, live.hourEntries, live.openHigh, live.openLow, live.hourSlots)' in t[VM])
    check('v0761_countdown', 'while (scanAt.isBefore(z) && ChronoUnit.MILLIS.between(scanAt, z) >= 1000L) {' in t[MAIN])
    check('v0761_history_write_throttle', all(s in t[STORE] for s in (
        'private const val LARGE_HISTORY_ROWS = 3_000', 'private const val LARGE_WRITE_INTERVAL_MS = 20_000L',
        'val peek = pendingWrite.get() ?: break', 'val waitMs = lastPersistSuccessMs.get() + LARGE_WRITE_INTERVAL_MS - System.currentTimeMillis()')))
    check('v0761_texts', '旧モデル用のスイッチ。今の運用等級（S/Aは3分・B/C/Dは5分判定、土日は3分）には影響しません' in t[MAIN]
          and 'ENTRYの割合（今のバージョン・自動・5分の区切りあたり）' in t[MAIN]
          and 'AUTO（平日毎分・土日5分ごと） / 1分AUTO' in t[SCREENS] and '途中から動いた時間は動いた枠の70%' in t[SCREENS])
    check('v0761_fixture_present', (ROOT/FIXTURE).is_file() and sha(ROOT/FIXTURE) == new[FIXTURE])
    check('v0761_tests_present', all(f'fun {n}()' in t[TEST] for n in ('slotsCountStoredSlotRowsAndTheSlotsAhead',
          'quotaUsesTheSlotsAndMatchesTheResearch', 'policyShowsAndUsesTheHourSlots')))
    check('v0761_build_release', 'VERSION_CODE = 131' in t[BUILD] and '"DeepAuditV0761Test": 3' in t[BUILD] and '"AuditFixV0760Test": 5' in t[BUILD]
          and 'tools/audit_v0761.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0761_DEEP_AUDIT_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.61-deep-audit')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""v0.7.59 same direction: source gate layered on the unchanged v0.7.58 audit.

Every v0.7.58 check is re-run; rows that fail only because a v0.7.59-modified file changed are re-pinned to the v0.7.59 bytes, and the
v0.7.58 exact-edit gates of those files are replaced by the v0.7.59 gates below (the model, its data, the cuts and the rules are untouched).
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
MODE = D + 'domain/EntryMode.kt'; VM = D + 'ui/GmkViewModel.kt'; MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'
MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/SameDirectionV0759Test.kt'; TEST58 = 'app/src/test/java/EveryMinuteV0758Test.kt'
GATES58 = {
    'v0758_policy_constants': POLICY, 'v0758_weekday_rule': POLICY, 'v0758_hour_rule': RULES, 'v0758_active_rules': RULES, 'v0758_ladder': RULES,
    'v0758_model5_data': MODEL5, 'v0758_rank_statistics': STATS, 'v0758_viewmodel_every_minute': VM, 'v0758_screens': MAIN,
    'v0758_tests_present': TEST58, 'v0758_build_release': BUILD, 'gradle_only_version_changed_v0758': GRADLE,
}


def audit():
    spec = importlib.util.spec_from_file_location('v0758_audit', ROOT/'tools/audit_v0758.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    spec5 = importlib.util.spec_from_file_location('v0755_audit_base', ROOT/'tools/audit_v0755.py')
    a55 = importlib.util.module_from_spec(spec5); spec5.loader.exec_module(a55)
    ALERTS = D + 'domain/SignalAlerts.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 / v0.7.58 used
    EARLIER.update({
        'v0755_policy_constants': POLICY, 'v0755_rank_rule': POLICY, 'v0755_ladder': RULES, 'v0755_rank_statistics_version': STATS,
        'v0755_notification_grades': ALERTS, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': POLICY, 'v0756_rank_rule': POLICY, 'v0756_ladder': RULES, 'v0756_rank_statistics': STATS,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': POLICY,
        'v0756_entry_mode': MODE, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': ALERTS,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(old.REPLACED); EARLIER.update(GATES58)
    manifest = json.loads((ROOT/'tools/v0759_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0759_same_direction:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.58 source bytes plus the pinned v0.7.59 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0759_same_direction:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.59; replaced by the v0.7.59 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*129\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.59-same-direction"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m58['modified_existing'].items()}; known.update(m58['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0759_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0758_original_before_v0759:' + path, known[path] == item['v0758_sha256'])
    for path, digest in new.items():
        check('pinned_v0759_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0759', sha_text(gradle.replace('versionCode = 129', 'versionCode = 128')
          .replace('versionName = "0.7.59-same-direction"', 'versionName = "0.7.58-every-minute"')) == changed[GRADLE]['v0758_sha256'])
    for p in (MODEL, MODEL5, 'app/src/test/resources/v0758_model5_parity.txt.gz'):
        check('v0759_unchanged_since_v0758:' + p, sha(ROOT/p) == (m58['modified_existing'][p]['updated_sha256'] if p in m58['modified_existing'] else m58['new_source_files'][p]))
    t = {k: (ROOT/k).read_text() for k in (POLICY, RULES, STATS, MODE, VM, MAIN, SCREENS, TEST, BUILD)}
    policy, rules, vm = t[POLICY], t[RULES], t[VM]
    check('v0759_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0759_SAME_DIRECTION"', 'const val POLICY_TAG = "GMK_V0740_V0759_EVIDENCE"',
        'fiveMinute: Boolean = false, openByDirection: Map<String, Int> = emptyMap()): Choice? {',
        'val score = if (fiveMinute) p - RankLadder.SAME_DIRECTION_PENALTY * (openByDirection[if (d == 1) "HIGH" else "LOW"] ?: 0) else p',
        'if (best == null || score > bestScore) {', 'val p = model.probability(if (fiveMinute) x0 + doubleArrayOf(if (boundary) 1.0 else 0.0) else x0)')))
    check('v0759_weekday_rule', all(s in policy for s in (
        'mode: EntryMode = EntryMode.FIFTY_FIVE, hourEntries: Int = 0, openHigh: Int = 0, openLow: Int = 0): ScanResult {',
        'choose(native, candles, quotes, entry, fiveMinute = true, openByDirection = mapOf("HIGH" to openHigh, "LOW" to openLow))',
        'val mc = five?.let { RankLadder.minuteCut(it.fresh, hourJst, minuteOfHour, hourEntries) }',
        'val fiveGrade = if (five != null && mc != null) (if (five.probability >= mc.cut) "C" else "D") else null',
        'val weekdayB = !weekend && boundary && ruleMatch == null && modelGrade == "B" && choice.instrument != "BTCJPY"',
        'val minuteNote = (if (boundary) "" else " MINUTE") + " OPEN=H$openHigh/L$openLow"')))
    check('v0759_ladder', all(s in rules for s in (
        'const val SAME_DIRECTION_PENALTY = 0.03', 'const val HOUR_SHARE = 0.7',
        '"C" to Rate(0.5322, 0.4860, 1325), "D" to Rate(0.5120, 0.5100, 1553))', '"C" to Rate(0.5226, 0.5026, 1325), "D" to Rate(0.5070, 0.5039, 1546))',
        'val ACTIVE_IDS = setOf("FIX955_POS", "FIX955_BBZ", "US0830_F1")', 'val frac = maxOf(need.toDouble() / left, baseShare(fresh, hourJst) / 2.0)')))
    check('v0759_rank_statistics', 'val CURRENT_RANK_VERSIONS = setOf("0.7.59")' in t[STATS] and 'const val C_SKIP_SINCE = "0.7.56"' in t[STATS])
    check('v0759_viewmodel_open_trades', all(s in vm for s in (
        'private fun openTradesAt(entryTimeJst: String): Pair<Int, Int> {',
        'if (e != null && j != null && e.isBefore(entry) && j.isAfter(entry)) { if (r.direction == "HIGH") high++ else if (r.direction == "LOW") low++ }',
        'val open = openTradesAt(native.entryTimeJst)',
        'EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode, hourEntriesBefore(native.entryTimeJst), open.first, open.second)',
        'val inSlotWindow = isAutoMinute(now) && now.second in 50..54', 'error("ENTRY/SKIP契約違反")')))
    check('v0759_tests_present', all(f'fun {n}()' in t[TEST] for n in ('constantsAndRates', 'noOpenTradesKeepTheV0758Choice',
          'openTradesInOneDirectionMoveThePickOnlyAcrossDirections', 'policyRecordsOpenTradesAndStillFollowsTheHourRule')))
    check('v0759_build_release', 'VERSION_CODE = 129' in t[BUILD] and '"SameDirectionV0759Test": 4' in t[BUILD] and '"EveryMinuteV0758Test": 5' in t[BUILD]
          and 'tools/audit_v0759.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0759_SAME_DIRECTION_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.59-same-direction')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

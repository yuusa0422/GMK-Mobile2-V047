"""v0.7.51 session ranks: source gate layered on the unchanged v0.7.50 audit.

Every v0.7.50 check is re-run. Rows that fail only because a v0.7.51-modified file changed are re-pinned to the v0.7.51
bytes; rows that described the v0.7.49 pattern overlay (removed in v0.7.51) are replaced by the v0.7.51 rank gates below.
Stage-1 models, strength ladder and their data files are unchanged.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'
RULES = D + 'domain/EventRules.kt'
VM = D + 'ui/GmkViewModel.kt'
PREFS = D + 'data/AppPrefs.kt'
GRADLE = 'app/build.gradle.kts'
TEST = 'app/src/test/java/SessionRanksV0751Test.kt'
PTEST = 'app/src/test/java/EvidencePolicyTest.kt'
# Rows of earlier audits that describe the removed v0.7.49 pattern overlay or an exact earlier edit of a file changed again.
SUPERSEDED = {
    'v0749_pattern_overlay': POLICY, 'v0749_tests_present': PTEST, 'evidence_model_frozen_parameters_v0750': POLICY,
    'v0750_i_row_record': POLICY, 'gradle_only_version_changed_v0750': GRADLE,
    'authorized_v0750_audit_fix:viewmodel_only_live_quote_call_changed': VM,
}


def audit():
    spec = importlib.util.spec_from_file_location('v0750_audit', ROOT/'tools/audit_v0750.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0751_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0751_session_ranks:' + path, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.50 source bytes plus the pinned v0.7.51 change only.')
        elif name in SUPERSEDED and not row['pass']:
            p = SUPERSEDED[name]
            row.update(check='authorized_v0751_session_ranks:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Gate of the removed pattern overlay / earlier exact edit; replaced by the v0.7.51 rank gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*121\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.51-session-ranks"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v50 = json.loads((ROOT/'tools/v0750_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v50['modified_existing'].items()} | v50['new_source_files']
    for path, item in changed.items():
        check('pinned_v0751_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0750_original_before_v0751:' + path, known[path] == item['v0750_sha256'])
    for path, digest in new.items():
        check('pinned_v0751_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0751', sha_text(gradle.replace('versionCode = 121', 'versionCode = 120')
          .replace('versionName = "0.7.51-session-ranks"', 'versionName = "0.7.50-audit-fix"')) == changed[GRADLE]['v0750_sha256'])
    rules = (ROOT/RULES).read_text(); vm = (ROOT/VM).read_text(); prefs = (ROOT/PREFS).read_text(); test = (ROOT/TEST).read_text()
    check('v0751_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0751_SESSION_RANKS"', 'const val POLICY_TAG = "GMK_V0740_V0751_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
        'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]')))
    check('v0751_rank_rule', all(s in policy for s in (
        'val decision = decide(choice, weekend, b, record = native.source == "AUTO")',
        'val enter = caution == null && (ruleMatch != null || decision.enter)',
        'caution != null -> if (decision.enter) "D" else modelGrade', 'ruleMatch != null -> ruleMatch.rule.grade',
        'judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)')) and 'EvidencePatterns.decide' not in policy and 'PatternFeatures.codes' not in policy)
    check('v0751_event_rules', all(s in rules for s in (
        'Rule("FIX955_POS", "S", Clock.JST, 9 * 60 + 55, Feature.POS60L, 0.8, true,',
        'Rule("JST1220_POS", "A", Clock.JST, 12 * 60 + 20, Feature.POS60L, 0.8, false,',
        'Rule("JST2250_R15", "A", Clock.JST, 22 * 60 + 50, Feature.R15, 1.0, false,',
        'Rule("LON0725_R5", "A", Clock.LONDON, 7 * 60 + 25, Feature.R5, 1.0, false,',
        'if (entry.second != 0 || entry.nano != 0 || entry.minute % 5 != 0) return emptyList()',
        'if (!TradingSession.fxOpen(entry)) return emptyList()', 'LONDON(ZoneId.of("Europe/London"))')))
    check('v0751_ladder', all(s in rules for s in ('"S" -> "B"', '"A" -> if (weekend) "C" else "B"', '"B", "C" -> "C"')))
    check('v0751_october_calendar', 'Window(at(29, 22, 10), at(29, 23, 0),' in rules and 'Window(at(30, 11, 30), at(30, 13, 30),' in rules
          and 'Window(at(30, 15, 25), at(30, 16, 30),' in rules)
    check('v0751_state_persistence', 'runCatching { EvidencePolicy.importState(prefs.evidenceState, System.currentTimeMillis() / 1000L) }' in vm
          and 'if (source == "AUTO") withContext(Dispatchers.IO) { runCatching { prefs.evidenceState = EvidencePolicy.exportState() } }' in vm
          and 'prefs.getString("evidence_state_v1", "")' in prefs and 'const val MAX_STATE_AGE_SEC = 21L * 24 * 3600' in policy)
    check('v0751_contract_check_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm)
    check('v0751_tests_present', all(f'fun {n}()' in test for n in (
        'ruleTradesMatchPythonOnRealSlots', 'londonRuleFollowsTheOctoberClockChange', 'fixRuleTakesUsdjpyFirstOtherRulesTakeTheLargestMove',
        'octoberCalendarWindows', 'rankTableOrderAndModelGradeMapping', 'rollingStateSurvivesARestart', 'rollingStateFromRealSlotsKeepsRecentEntries',
        'finalRanksOnRealSlotsFollowTheNewLadder', 'eventRuleReplacesTheModelTradeOnARealFixSlot')))
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModel.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        p = ROOT/(D + 'domain/' + f)
        check('v0751_model_file_unchanged_since_v0750:' + f, p.is_file() and f'v0750_model_file_unchanged:{f}' in {r['check'] for r in result['results']}
              and next(r['pass'] for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}'))
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0751_SESSION_RANKS_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.51-session-ranks')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

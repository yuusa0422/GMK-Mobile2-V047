"""v0.7.56 entry-sixty: source gate layered on the unchanged v0.7.55 audit.

Every v0.7.55 check is re-run; rows that fail only because a v0.7.56-modified file changed are re-pinned to the v0.7.56 bytes,
and rows describing an exact earlier edit of a file changed again are replaced by the v0.7.56 gates below.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
ALERTS = D + 'domain/SignalAlerts.kt'; MODE = D + 'domain/EntryMode.kt'; VM = D + 'ui/GmkViewModel.kt'; PREFS = D + 'data/AppPrefs.kt'
MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/EntrySixtyV0756Test.kt'; TEST55 = 'app/src/test/java/FiftyFiveV0755Test.kt'


def audit():
    spec = importlib.util.spec_from_file_location('v0755_audit', ROOT/'tools/audit_v0755.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    # earlier exact-edit gates (last name segment) -> the file whose v0.7.56 bytes now stand for them
    BASE = dict(old.BASE)
    BASE.update({
        'v0755_policy_constants': POLICY, 'v0755_rank_rule': POLICY, 'v0755_ladder': RULES, 'v0755_rank_statistics_version': STATS,
        'v0755_notification_grades': ALERTS, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
    })
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0756_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        path = next((p for p in changed if name.endswith(':' + p)), None)
        base = name.rsplit(':', 1)[-1]
        if path is not None:
            row.update(check='authorized_v0756_entry_sixty:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.55 source bytes plus the pinned v0.7.56 change only.')
        elif base in BASE:
            p = BASE[base]
            row.update(check='authorized_v0756_entry_sixty:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; replaced by the v0.7.56 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*126\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.56-entry-sixty"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    known = {}
    for v in ('0752', '0753', '0754', '0755'):
        m = json.loads((ROOT/f'tools/v{v}_source_extension.json').read_text())
        known.update({p: x['updated_sha256'] for p, x in m['modified_existing'].items()}); known.update(m['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0756_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0755_original_before_v0756:' + path, known[path] == item['v0755_sha256'])
    for path, digest in new.items():
        check('pinned_v0756_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0756', sha_text(gradle.replace('versionCode = 126', 'versionCode = 125')
          .replace('versionName = "0.7.56-entry-sixty"', 'versionName = "0.7.55-fifty-five"')) == changed[GRADLE]['v0755_sha256'])
    t = {k: (ROOT/k).read_text() for k in (POLICY, RULES, STATS, ALERTS, MODE, VM, PREFS, MAIN, SCREENS, TEST, TEST55, BUILD)}
    policy, rules, vm, mode = t[POLICY], t[RULES], t[VM], t[MODE]
    check('v0756_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0756_ENTRY_SIXTY"', 'const val POLICY_TAG = "GMK_V0740_V0756_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'const val MAX_STATE_AGE_SEC = 21L * 24 * 3600', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
        'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]',
        'val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)')))
    check('v0756_rank_rule', all(s in policy for s in (
        'mode: EntryMode = EntryMode.FIFTY_FIVE): ScanResult {',
        'val decision = decide(choice, weekend, b, record = native.source == "AUTO")',
        'val againstHour = RankLadder.againstHour(pos60, dirInt)',
        'val modelGrade = RankLadder.modelGrade(decision.grade, weekend, confirmed, hourJst, againstHour, decision.rankStrength, decision.strength, choice.fresh)',
        'RankLadder.demotion(decision.grade, weekend, confirmed, hourJst, againstHour, modelGrade, mode) else null',
        'val enter = caution == null && (ruleMatch != null || (demoted == null && mode.enters(modelGrade, weekend)))',
        'caution != null -> if (decision.enter || modelGrade == "C") "D" else modelGrade', 'ruleMatch != null -> ruleMatch.grade',
        'judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)', ' MODE=${mode.key}$ruleNote -> $grade/')))
    check('v0756_ladder', all(s in rules for s in (
        '"S" to Rate(0.6820, 0.7692, 26), "A" to Rate(0.6007, 0.5949, 79), "B" to Rate(0.5602, 0.5407, 344)',
        '"C" to Rate(0.5279, 0.5234, 2482), "D" to Rate(0.5081, 0.5149, 808), "E" to Rate(0.5052, 0.4686, 350), "F" to Rate(0.4878, 0.5018, 566))',
        '"B" to Rate(0.5709, 0.5278, 180), "C" to Rate(0.4787, 0.4701, 1087), "D" to Rate(0.4168, 0.4756, 164), "E" to Rate(0.4096, 0.4000, 300)',
        '"C" to Rate(0.5098, null, null), "D" to Rate(0.5039, null, null)', '"B" to Rate(0.5504, null, null), "C" to Rate(0.4656, null, null)',
        'val ENTRY_GRADES = EntryMode.ENTRY_BASE', 'const val FRESH_WEEKDAY_C_CUT = 0.5126473828714029',
        'const val FALLBACK_WEEKDAY_C_CUT = 0.500316186307408', 'const val FRESH_WEEKEND_C_CUT = 0.4122092384871319',
        'const val FALLBACK_WEEKEND_C_CUT = 0.4087182577634557', 'v0748 == "S" && againstHour -> "B"',
        '"S", "A" -> if (confirmed) "B" else if (hourJst == PRE_FIX_HOUR) "F" else if (rank >= weekdayCut(fresh)) "C" else "D"',
        'pos60 != null && pos60.isFinite() && pos60 * direction <= 0.0',
        'const val FX_SPIKE_SIGMA = 2.5', 'const val BTC_FOLLOW_LOW = 1.0', 'const val BTC_FOLLOW_HIGH = 3.0', 'const val S_CONFLUENCE = 3'))
          and rules.count('        Rule("') == 8)
    check('v0756_entry_mode', all(s in mode for s in (
        'FIFTY_FIVE("55", "55%優先", false, false,', 'WEEKDAY_60("60W", "平日60%", true, false,', 'ALL_60("60", "毎日60%", true, true,',
        'val ENTRY_BASE = setOf("S", "A", "B")', 'val ENTRY_WITH_C = setOf("S", "A", "B", "C")', 'val DEFAULT = WEEKDAY_60')))
    check('v0756_viewmodel_mode', all(s in vm for s in (
        'val entryMode = EntryMode.parse(prefs.entryMode)', 'EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode)',
        '(it.grade == "C" && it.decision != (if (it.rank != 1 || entryMode.enters("C", slotWeekend)) "ENTRY" else "SKIP"))',
        'fun setEntryMode(value: String) {', '"entry_share_by_hour"', 'RankStatistics.isSkipCount(t, c)'))
          and 'get() = jp.gmk.mobile.domain.EntryMode.parse(prefs.getString("entry_mode_v0756", null)).key' in t[PREFS])
    check('v0756_contract_check_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm
          and 'if (source == "AUTO" && autoBoundary != null) refreshLiveQuotesBeforeDecision(eligible.keys.toList(), autoBoundary)' in vm)
    check('v0756_rank_statistics', 'val CURRENT_RANK_VERSIONS = setOf("0.7.56")' in t[STATS] and 'const val C_SKIP_SINCE = "0.7.56"' in t[STATS]
          and 'fun entryShareByHour(rows: List<HistoryRow>)' in t[STATS] and 'fun isSkipCount(table: RankTable, c: RankCount): Boolean' in t[STATS])
    check('v0756_notification_grades', 'fun normalizeMinGrade(grade: String?): String = when (grade) { "A" -> "A"; "C" -> "C"; else -> DEFAULT_MIN_GRADE }' in t[ALERTS]
          and 'listOf("A" to "S/Aだけ", "B" to "S〜B（55%以上）", "C" to "全ENTRY（S〜C）")' in t[SCREENS])
    check('v0756_screens', 'Text("ENTRYの量"' in t[SCREENS] and 'setEntryMode: (String) -> Unit = {}' in t[SCREENS]
          and 'setEntryMode = vm::setEntryMode' in t[MAIN] and 'RankStatistics.entryShareText(rows)' in t[MAIN])
    check('v0756_tests_present', all(f'fun {n}()' in t[TEST] for n in ('modesRatesAndCuts', 'modelGradeSplitsTheFormerC',
          'realSlotsFollowTheModeAndTheCuts', 'skippedCIsFollowedAndCountedApart'))
          and all(f'fun {n}()' in t[TEST55] for n in ('ladderRatesAndConstants', 'modelGradeMapping', 'weekendStrongTradeEntersOnlyAgainstTheHourOnRealSlots',
          'weekdayEntersOnlySAndB', 'liveAgeIsRecordedInLabelAndNote')))
    check('v0756_build_release', 'VERSION_CODE = 126' in t[BUILD] and '"EntrySixtyV0756Test": 4' in t[BUILD] and 'tools/audit_v0756.py' in t[BUILD])
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModel.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        rows = [r for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}']
        check('v0756_model_file_unchanged_since_v0750:' + f, len(rows) == 1 and rows[0]['pass'])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0756_ENTRY_SIXTY_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.56-entry-sixty')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

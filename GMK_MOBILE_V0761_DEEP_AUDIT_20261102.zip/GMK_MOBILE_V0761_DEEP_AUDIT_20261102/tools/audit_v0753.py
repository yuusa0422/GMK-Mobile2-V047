"""v0.7.53 more rules: source gate layered on the unchanged v0.7.52 audit.

Every v0.7.52 check is re-run; rows that fail only because a v0.7.53-modified file changed are re-pinned to the v0.7.53 bytes,
and rows describing an exact earlier edit of a file changed again are replaced by the v0.7.53 gates below.
"""
from pathlib import Path
import argparse, gzip, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
VM = D + 'ui/GmkViewModel.kt'; REPO = D + 'data/MarketRepository.kt'; MAIN = D + 'MainActivity.kt'
GRADLE = 'app/build.gradle.kts'; TEST = 'app/src/test/java/MoreRulesV0753Test.kt'; FIXTURE = 'app/src/test/resources/v0753_event_parity.txt.gz'
SUPERSEDED = {
    'authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:evidence_model_frozen_parameters_v0750': POLICY,
    'authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:gradle_only_version_changed_v0750': GRADLE,
    'authorized_v0752_confirmed_ranks:authorized_v0751_session_ranks:v0749_pattern_overlay': POLICY,
    'authorized_v0752_confirmed_ranks:gradle_only_version_changed_v0751': GRADLE,
    'authorized_v0752_confirmed_ranks:v0751_policy_constants': POLICY, 'authorized_v0752_confirmed_ranks:v0751_ladder': RULES,
    'v0751_rank_rule': POLICY, 'v0751_event_rules': RULES,
    'gradle_only_version_changed_v0752': GRADLE, 'v0752_policy_constants': POLICY, 'v0752_event_rules_unchanged': RULES,
}
RULE_LINES = (
    'Rule("FIX955_POS", Clock.JST, 9 * 60 + 55, Feature.POS60L, true,', 'Rule("FIX955_BBZ", Clock.JST, 9 * 60 + 55, Feature.BBZL, true,',
    'Rule("JST1220_POS", Clock.JST, 12 * 60 + 20, Feature.POS60L, false,', 'Rule("JST2250_R15", Clock.JST, 22 * 60 + 50, Feature.R15, false,',
    'Rule("LON0725_R5", Clock.LONDON, 7 * 60 + 25, Feature.R5, false,', 'Rule("US0830_BBZ", Clock.NEW_YORK, 8 * 60 + 30, Feature.BBZL, false,',
    'Rule("US0830_F1", Clock.NEW_YORK, 8 * 60 + 30, Feature.F1, false,', 'Rule("UK0930_F1", Clock.LONDON, 9 * 60 + 30, Feature.F1, false,')


def audit():
    spec = importlib.util.spec_from_file_location('v0752_audit', ROOT/'tools/audit_v0752.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0753_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text(); policy = (ROOT/POLICY).read_text()
    for row in result['results']:
        name = row['check']
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None and not row['pass']:
            row.update(check='authorized_v0753_more_rules:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.52 source bytes plus the pinned v0.7.53 change only.')
        elif name in SUPERSEDED and not row['pass']:
            p = SUPERSEDED[name]
            row.update(check='authorized_v0753_more_rules:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; replaced by the v0.7.53 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*123\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.53-more-rules"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v52 = json.loads((ROOT/'tools/v0752_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in v52['modified_existing'].items()} | v52['new_source_files']
    for path, item in changed.items():
        check('pinned_v0753_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0752_original_before_v0753:' + path, known[path] == item['v0752_sha256'])
    for path, digest in new.items():
        check('pinned_v0753_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0753', sha_text(gradle.replace('versionCode = 123', 'versionCode = 122')
          .replace('versionName = "0.7.53-more-rules"', 'versionName = "0.7.52-confirmed-ranks"')) == changed[GRADLE]['v0752_sha256'])
    rules = (ROOT/RULES).read_text(); stats = (ROOT/STATS).read_text(); test = (ROOT/TEST).read_text()
    check('v0753_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0753_MORE_RULES"', 'const val POLICY_TAG = "GMK_V0740_V0753_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'const val MAX_STATE_AGE_SEC = 21L * 24 * 3600',
        'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
        'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]',
        'val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)',
        'val modelGrade = RankLadder.modelGrade(decision.grade, weekend, confirmed)')))
    check('v0753_rank_rule', all(s in policy for s in (
        'val decision = decide(choice, weekend, b, record = native.source == "AUTO")',
        'val enter = caution == null && (ruleMatch != null || decision.enter)',
        'caution != null -> if (decision.enter) "D" else modelGrade', 'ruleMatch != null -> ruleMatch.grade',
        'judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)')) and 'ruleMatch.rule.grade' not in policy
          and 'EvidencePatterns.decide' not in policy and 'PatternFeatures.codes' not in policy)
    check('v0753_event_rules', all(s in rules for s in RULE_LINES + (
        'NEW_YORK(ZoneId.of("America/New_York"))', 'LONDON(ZoneId.of("Europe/London"))',
        'enum class Feature(val threshold: Double) { POS60L(0.8), BBZL(1.5), R5(1.0), R15(1.0), F1(1.0) }', 'const val S_CONFLUENCE = 3',
        'val grade: String get() = if (confluence >= S_CONFLUENCE) "S" else "A"',
        'o.isFinite() && abs(o) >= f.threshold && sign(o) == sign(v)', 'if (f == rule.feature) return@count false',
        'Feature.BBZL -> x.bbzLive', 'Feature.F1 -> x.f1',
        'if (entry.second != 0 || entry.nano != 0 || entry.minute % 5 != 0) return emptyList()',
        'if (!TradingSession.fxOpen(entry)) return emptyList()')) and rules.count('        Rule("') == 8)
    check('v0753_ladder', all(s in rules for s in (
        '"S" to Rate(0.6820, 0.7692, 26), "A" to Rate(0.6007, 0.5949, 79), "B" to Rate(0.5602, 0.5407, 344)',
        '"C" to Rate(0.5201, 0.5193, 3503), "D" to Rate(0.5052, 0.4686, 350), "E" to Rate(0.4877, 0.5099, 353))',
        '"S" -> if (weekend) "B" else if (confirmed) "B" else "C"', '"A" -> if (weekend) "C" else if (confirmed) "B" else "C"', '"B", "C" -> "C"',
        'const val FX_SPIKE_SIGMA = 2.5', 'const val BTC_FOLLOW_LOW = 1.0', 'const val BTC_FOLLOW_HIGH = 3.0')))
    check('v0753_october_calendar_kept', 'Window(at(29, 22, 10), at(29, 23, 0),' in rules and 'Window(at(30, 11, 30), at(30, 13, 30),' in rules
          and 'Window(at(30, 15, 25), at(30, 16, 30),' in rules)
    check('v0753_rank_statistics_version', 'val CURRENT_RANK_VERSIONS = setOf("0.7.53")' in stats)
    check('v0753_viewmodel_repository_unchanged_since_v0752', sha(ROOT/VM) == known[VM] and sha(ROOT/REPO) == known[REPO])
    main_v52 = changed[MAIN]['v0752_sha256']
    check('v0753_main_activity_only_legend_text', sha_text((ROOT/MAIN).read_text().replace(
        '"運用等級: S/A = 時間帯ルール（仲値9:55・米指標NY8:30・英指標ロンドン9:30など。ほかのサインも揃うとS）、B/C = モデルの強さ、ここまでENTRY。',
        '"運用等級: S/A = 時間帯ルール（仲値9:55など）、B/C = モデルの強さ、ここまでENTRY。')) == main_v52)
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModel.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        rows = [r for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}']
        check('v0753_model_file_unchanged_since_v0750:' + f, len(rows) == 1 and rows[0]['pass'])
    check('v0753_tests_present', all(f'fun {n}()' in test for n in ('ruleTradesGradesAndConfluenceMatchPythonOnRealSlots',
          'newRulesFollowTheNewYorkAndLondonClocks', 'confluenceDecidesBetweenSAndA', 'policyGradesRuleTradesSOrAWithLabelsAndRates', 'ladderRatesForV0753')))
    fx = gzip.open(ROOT/FIXTURE, 'rt').read().splitlines()
    ms = [l.split('|') for l in fx if l.startswith('EXPM|') and l != 'EXPM|NONE']
    check('v0753_fixture_covers_every_rule_and_both_grades', {m[1] for m in ms} == {l.split('"')[1] for l in RULE_LINES}
          and {m[6] for m in ms} == {'S', 'A'} and sum(1 for l in fx if l == 'EXPM|NONE') >= 10)
    build = (ROOT/'tools/build_release.py').read_text()
    check('v0753_build_release', 'VERSION_CODE = 123' in build and '"MoreRulesV0753Test": 5' in build and 'tools/audit_v0753.py' in build)
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0753_MORE_RULES_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.53-more-rules')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

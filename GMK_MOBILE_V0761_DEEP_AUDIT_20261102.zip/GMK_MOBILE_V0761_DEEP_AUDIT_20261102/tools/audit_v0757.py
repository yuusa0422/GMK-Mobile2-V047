"""v0.7.57 five-minute: source gate layered on the unchanged v0.7.56 audit.

Every v0.7.56 check is re-run; rows that fail only because a v0.7.57-modified file changed are re-pinned to the v0.7.57 bytes,
and rows describing an exact earlier edit of a file changed again are replaced by the v0.7.57 gates below.
EvidenceModel.kt (frozen since v0.7.50) only gains the 5-minute ensemble loader: checked by removing that block.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
ALERTS = D + 'domain/SignalAlerts.kt'; MODE = D + 'domain/EntryMode.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/FiveMinuteV0757Test.kt'; TEST56 = 'app/src/test/java/EntrySixtyV0756Test.kt'
FIXTURE = 'app/src/test/resources/v0757_model5_parity.txt.gz'
LOADER = """

        /**
         * v0.7.57: the same design and training setup, target = 5-minute WIN (open(B+300) vs open(B), DRAW = LOSE), weekday rows of
         * the six instruments ([EvidenceModel5Data]). Used for weekday FX trades judged at 5 minutes.
         */
        val fresh5: EvidenceEnsemble by lazy { load(EvidenceModel5Data.freshTexts(), EvidenceModel5Data.FRESH_SHA256) }
        val fallback5: EvidenceEnsemble by lazy { load(EvidenceModel5Data.fallbackTexts(), EvidenceModel5Data.FALLBACK_SHA256) }"""


def audit():
    spec = importlib.util.spec_from_file_location('v0756_audit', ROOT/'tools/audit_v0756.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    spec5 = importlib.util.spec_from_file_location('v0755_audit_base', ROOT/'tools/audit_v0755.py')
    a55 = importlib.util.module_from_spec(spec5); spec5.loader.exec_module(a55)
    # earlier exact-edit gates (last name segment) -> the file whose v0.7.57 bytes now stand for them
    BASE = dict(a55.BASE)
    BASE.update({
        'v0755_policy_constants': POLICY, 'v0755_rank_rule': POLICY, 'v0755_ladder': RULES, 'v0755_rank_statistics_version': STATS,
        'v0755_notification_grades': ALERTS, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': POLICY, 'v0756_rank_rule': POLICY, 'v0756_ladder': RULES, 'v0756_rank_statistics': STATS,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': POLICY,
        'v0756_entry_mode': MODE, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': ALERTS,
        'v0756_tests_present': TEST56,
    })
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0757_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    model_text = (ROOT/MODEL).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        path = next((p for p in changed if name.endswith(':' + p)), None)
        base = name.rsplit(':', 1)[-1]
        if path is not None:
            row.update(check='authorized_v0757_five_minute:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.56 source bytes plus the pinned v0.7.57 change only.')
        elif base == 'EvidenceModel.kt':
            row.update(check='authorized_v0757_five_minute:' + name, **{'pass': sha(ROOT/MODEL) == changed[MODEL]['updated_sha256']},
                       detail='Frozen model loader; v0.7.57 adds only the 5-minute ensemble block (v0757_model_loader_only_adds_five_minute).')
        elif base in BASE:
            p = BASE[base]
            row.update(check='authorized_v0757_five_minute:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; replaced by the v0.7.57 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*127\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.57-five-minute"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    known = {}
    for v in ('0752', '0753', '0754', '0755', '0756'):
        m = json.loads((ROOT/f'tools/v{v}_source_extension.json').read_text())
        known.update({p: x['updated_sha256'] for p, x in m['modified_existing'].items()}); known.update(m['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0757_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0756_original_before_v0757:' + path, known[path] == item['v0756_sha256'])
    for path, digest in new.items():
        check('pinned_v0757_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0757', sha_text(gradle.replace('versionCode = 127', 'versionCode = 126')
          .replace('versionName = "0.7.57-five-minute"', 'versionName = "0.7.56-entry-sixty"')) == changed[GRADLE]['v0756_sha256'])
    check('v0757_model_loader_only_adds_five_minute', model_text.count(LOADER) == 1 and sha_text(model_text.replace(LOADER, '')) == changed[MODEL]['v0756_sha256'])
    t = {k: (ROOT/k).read_text() for k in (POLICY, RULES, STATS, ALERTS, MODE, VM, MAIN, SCREENS, MODEL5, TEST, BUILD)}
    policy, rules, vm, model5 = t[POLICY], t[RULES], t[VM], t[MODEL5]
    check('v0757_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0757_FIVE_MINUTE"', 'const val POLICY_TAG = "GMK_V0740_V0757_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]',
        'val model = if (fiveMinute) (if (fresh) EvidenceEnsemble.fresh5 else EvidenceEnsemble.fallback5)',
        'else if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
        'native.candidates.filter { if (fiveMinute) it.instrument != "BTCJPY" else (!weekend || it.instrument == "BTCJPY") }',
        'val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)')))
    check('v0757_weekday_rule', all(s in policy for s in (
        'val ruleMatch = if (!weekend && ruleFound?.instrument == "BTCJPY") null else ruleFound',
        'val weekdayB = !weekend && ruleMatch == null && modelGrade == "B" && choice.instrument != "BTCJPY"',
        'choose(native, candles, quotes, entry, fiveMinute = true)',
        'val fiveGrade = if (five != null && cut != null) (if (five.probability >= cut) "C" else "D") else null',
        'else -> fiveGrade == "C" && mode.enters("C", false)', 'val minutes = RankLadder.judgeMinutes(weekend, grade)',
        'val hz = "【${minutes}分判定】"', 'reasons = listOf("判定: ${minutes}分", note)',
        'CandidateAssessmentFactory.correction(target, nativeTop, finalDirection, grade, action, minutes, label,',
        'return native.copy(judgeTimeJst = entry.plusMinutes(minutes.toLong()).toString()', ' HZ=$minutes$fiveNote$btcNote$ruleNote -> ')))
    check('v0757_ladder', all(s in rules for s in (
        '"S" to Rate(0.6887, 0.8750, 8), "A" to Rate(0.6040, 0.5000, 26), "B" to Rate(0.5756, 0.5000, 40)',
        '"C" to Rate(0.5263, 0.5101, 1084), "D" to Rate(0.5079, 0.5082, 671))', '"C" to Rate(0.5136, null, null), "D" to Rate(0.5057, null, null))',
        'fun judgeMinutes(weekend: Boolean, grade: String): Int = if (weekend || grade in setOf("S", "A", "I")) 3 else 5',
        '(if (fresh) EvidenceModel5Data.FRESH_HOUR_CUTS else EvidenceModel5Data.FALLBACK_HOUR_CUTS)[(hourJst - 9).coerceIn(0, 13)]',
        '"B" to Rate(0.5709, 0.5278, 180), "C" to Rate(0.4787, 0.4701, 1087)', 'val ENTRY_GRADES = EntryMode.ENTRY_BASE',
        'const val FX_SPIKE_SIGMA = 2.5', 'const val S_CONFLUENCE = 3')) and rules.count('        Rule("') == 8)
    check('v0757_model5_data', model5.count('private const val FRESH_') == 5 and model5.count('private const val FALLBACK_') == 5
          and model5.count('_HOUR_CUTS = doubleArrayOf(') == 2 and '// v0.7.57 5-minute ensembles' in model5)
    check('v0757_fixture_present', (ROOT/FIXTURE).is_file() and sha(ROOT/FIXTURE) == new[FIXTURE])
    check('v0757_rank_statistics', 'val CURRENT_RANK_VERSIONS = setOf("0.7.57")' in t[STATS] and 'const val C_SKIP_SINCE = "0.7.56"' in t[STATS])
    check('v0757_notification_minutes', 'fun entryTitle(grade: String, instrument: String, direction: String, minutes: Int = 3): String =' in t[ALERTS]
          and '"【${minutes}分判定】$grade ENTRY' in t[ALERTS]
          and 'SignalAlerts.entryTitle(top.grade, top.instrument, top.direction, SignalAlerts.minutesBetween(result.entryTimeJst, result.judgeTimeJst) ?: 3)' in vm)
    check('v0757_judge_badge', 'internal fun JudgeBadge(minutes: Int, large: Boolean = false)' in t[MAIN] and 'JudgeBadge(minutes, large = true)' in t[MAIN]
          and t[MAIN].count('JudgeBadge(') >= 5 and 'ザオプションで「${minutes}分」を選んでエントリー' in t[MAIN])
    check('v0757_viewmodel_contract_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm
          and 'EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode)' in vm
          and 'if (source == "AUTO" && autoBoundary != null) refreshLiveQuotesBeforeDecision(eligible.keys.toList(), autoBoundary)' in vm)
    check('v0757_tests_present', all(f'fun {n}()' in t[TEST] for n in ('fiveMinuteEnsembleMatchesPythonExactly', 'cutsRatesAndJudgementLength',
          'realSlotsUseTheRightJudgementLength', 'fiveMinuteRowsAreCountedAsFiveMinuteResults')))
    check('v0757_build_release', 'VERSION_CODE = 127' in t[BUILD] and '"FiveMinuteV0757Test": 4' in t[BUILD] and 'tools/audit_v0757.py' in t[BUILD])
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        rows = [r for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}']
        check('v0757_model_file_unchanged_since_v0750:' + f, len(rows) == 1 and rows[0]['pass'])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0757_FIVE_MINUTE_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.57-five-minute')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

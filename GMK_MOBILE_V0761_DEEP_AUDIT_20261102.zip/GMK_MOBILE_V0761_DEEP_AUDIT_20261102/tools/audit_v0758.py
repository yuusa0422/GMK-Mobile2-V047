"""v0.7.58 every minute: source gate layered on the unchanged v0.7.57 audit.

Every v0.7.57 check is re-run (with the v0.7.57 test file and parity fixture, which v0.7.58 replaced, pointed at their v0.7.58
successors); rows that fail only because a v0.7.58-modified file changed are re-pinned to the v0.7.58 bytes, rows for the two removed
files pass only when the file is gone and listed as removed, and the v0.7.57 exact-edit gates are replaced by the v0.7.58 gates below.
EvidenceModel.kt only gains the input count of the 5-minute ensembles: checked by undoing exactly that edit.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
MODE = D + 'domain/EntryMode.kt'; VM = D + 'ui/GmkViewModel.kt'; MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'
MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'; PREFS = D + 'data/AppPrefs.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/EveryMinuteV0758Test.kt'; FIXTURE = 'app/src/test/resources/v0758_model5_parity.txt.gz'
LOADER_EDITS = [
    ('''        private fun load(texts: List<String>, hashes: List<String>, features: Int = EvidenceModelData.FEATURES.size): EvidenceEnsemble {
            check(texts.size == hashes.size && texts.size == 5) { "EVIDENCE_ENSEMBLE_SIZE" }
            return EvidenceEnsemble(texts.indices.map { EvidenceTreeModel.parse(texts[it], hashes[it], features) })
        }''', '''        private fun load(texts: List<String>, hashes: List<String>): EvidenceEnsemble {
            check(texts.size == hashes.size && texts.size == 5) { "EVIDENCE_ENSEMBLE_SIZE" }
            return EvidenceEnsemble(texts.indices.map { EvidenceTreeModel.parse(texts[it], hashes[it], EvidenceModelData.FEATURES.size) })
        }'''),
    ('''        // v0.7.58: every weekday minute; the 46 design inputs + isk0 (1 = exact 5-minute boundary)
        val fresh5: EvidenceEnsemble by lazy { load(EvidenceModel5Data.freshTexts(), EvidenceModel5Data.FRESH_SHA256, EvidenceModel5Data.FEATURE_COUNT) }
        val fallback5: EvidenceEnsemble by lazy { load(EvidenceModel5Data.fallbackTexts(), EvidenceModel5Data.FALLBACK_SHA256, EvidenceModel5Data.FEATURE_COUNT) }''',
     '''        val fresh5: EvidenceEnsemble by lazy { load(EvidenceModel5Data.freshTexts(), EvidenceModel5Data.FRESH_SHA256) }
        val fallback5: EvidenceEnsemble by lazy { load(EvidenceModel5Data.fallbackTexts(), EvidenceModel5Data.FALLBACK_SHA256) }'''),
]
# v0.7.57 exact-edit gates -> the file whose v0.7.58 bytes now stand for them (the v0.7.58 gates below check the new content)
REPLACED = {
    'v0757_policy_constants': POLICY, 'v0757_weekday_rule': POLICY, 'v0757_ladder': RULES, 'v0757_model5_data': MODEL5,
    'v0757_fixture_present': FIXTURE, 'v0757_rank_statistics': STATS, 'v0757_viewmodel_contract_kept': VM, 'v0757_tests_present': TEST,
    'v0757_build_release': BUILD, 'v0757_model_loader_only_adds_five_minute': MODEL, 'gradle_only_version_changed_v0757': GRADLE,
    'v0757_judge_badge': MAIN, 'v0757_notification_minutes': VM,
}


def audit():
    spec = importlib.util.spec_from_file_location('v0757_audit', ROOT/'tools/audit_v0757.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    old.TEST = TEST          # the v0.7.57 test file was replaced in v0.7.58 (its gate is re-authorized below; the old fixture reads as missing)
    result = old.audit()
    # the earlier exact-edit gates that v0.7.57 re-authorized by a file's v0.7.57 bytes (audit_v0757.BASE): same files here
    spec5 = importlib.util.spec_from_file_location('v0755_audit_base', ROOT/'tools/audit_v0755.py')
    a55 = importlib.util.module_from_spec(spec5); spec5.loader.exec_module(a55)
    STATS57, ALERTS57 = STATS, D + 'domain/SignalAlerts.kt'
    BASE57 = dict(a55.BASE)
    BASE57.update({
        'v0755_policy_constants': POLICY, 'v0755_rank_rule': POLICY, 'v0755_ladder': RULES, 'v0755_rank_statistics_version': STATS57,
        'v0755_notification_grades': ALERTS57, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': POLICY, 'v0756_rank_rule': POLICY, 'v0756_ladder': RULES, 'v0756_rank_statistics': STATS57,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': POLICY,
        'v0756_entry_mode': MODE, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': ALERTS57,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    manifest = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']; removed = manifest['removed_files']
    gradle = (ROOT/GRADLE).read_text(); model_text = (ROOT/MODEL).read_text()
    pin = lambda p: changed[p]['updated_sha256'] if p in changed else new[p]
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        gone = next((p for p in removed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0758_every_minute:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.57 source bytes plus the pinned v0.7.58 change only.')
        elif gone is not None:
            row.update(check='authorized_v0758_removed:' + name, **{'pass': not (ROOT/gone).exists()},
                       detail='Replaced in v0.7.58 (EveryMinuteV0758Test / v0758_model5_parity).')
        elif name.startswith('authorized_v0757_five_minute:') and base in BASE57 and BASE57[base] in changed:
            p = BASE57[base]
            row.update(check='authorized_v0758_every_minute:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate re-authorized in v0.7.57 by this file; v0.7.58 re-pins the file.')
        elif name in REPLACED or base in REPLACED:
            p = REPLACED.get(name) or REPLACED[base]
            row.update(check='authorized_v0758_every_minute:' + name, **{'pass': sha(ROOT/p) == pin(p)},
                       detail='v0.7.57 exact-edit gate; replaced by the v0.7.58 gates.')
        elif base == 'EvidenceModel.kt':
            row.update(check='authorized_v0758_every_minute:' + name, **{'pass': sha(ROOT/MODEL) == changed[MODEL]['updated_sha256']},
                       detail='Model loader; v0.7.58 changes only the input count of the 5-minute ensembles (v0758_model_loader_only_input_count).')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*128\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.58-every-minute"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m57 = json.loads((ROOT/'tools/v0757_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m57['modified_existing'].items()}; known.update(m57['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0758_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0757_original_before_v0758:' + path, known[path] == item['v0757_sha256'])
    for path, digest in new.items():
        check('pinned_v0758_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    for path, digest in removed.items():
        check('removed_in_v0758:' + path, not (ROOT/path).exists() and m57['new_source_files'].get(path) == digest)
    check('gradle_only_version_changed_v0758', sha_text(gradle.replace('versionCode = 128', 'versionCode = 127')
          .replace('versionName = "0.7.58-every-minute"', 'versionName = "0.7.57-five-minute"')) == changed[GRADLE]['v0757_sha256'])
    undone = model_text
    for a, b in LOADER_EDITS: undone = undone.replace(a, b) if undone.count(a) == 1 else '<edit missing>'
    check('v0758_model_loader_only_input_count', sha_text(undone) == changed[MODEL]['v0757_sha256'])
    t = {k: (ROOT/k).read_text() for k in (POLICY, RULES, STATS, MODE, VM, MAIN, SCREENS, MODEL5, TEST, BUILD, PREFS)}
    policy, rules, vm, model5 = t[POLICY], t[RULES], t[VM], t[MODEL5]
    check('v0758_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0758_EVERY_MINUTE"', 'const val POLICY_TAG = "GMK_V0740_V0758_EVIDENCE"',
        'fun isBoundary(entry: ZonedDateTime): Boolean = entry.second == 0 && entry.nano == 0 && entry.minute % 5 == 0',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKDAY_BUFFER_SIZE = 288', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'val p = model.probability(if (fiveMinute) x0 + doubleArrayOf(if (boundary) 1.0 else 0.0) else x0)',
        'native.candidates.filter { if (fiveMinute) it.instrument != "BTCJPY" else (!weekend || it.instrument == "BTCJPY") }')))
    check('v0758_weekday_rule', all(s in policy for s in (
        'mode: EntryMode = EntryMode.FIFTY_FIVE, hourEntries: Int = 0): ScanResult {',
        'val decision = decide(choice, weekend, b, record = native.source == "AUTO" && boundary)',
        'val weekdayB = !weekend && boundary && ruleMatch == null && modelGrade == "B" && choice.instrument != "BTCJPY"',
        'val mc = five?.let { RankLadder.minuteCut(it.fresh, hourJst, minuteOfHour, hourEntries) }',
        'val fiveGrade = if (five != null && mc != null) (if (five.probability >= mc.cut) "C" else "D") else null',
        'else -> fiveGrade == "C" && mode.enters("C", false)', 'val minutes = RankLadder.judgeMinutes(weekend, grade)',
        'return native.copy(judgeTimeJst = entry.plusMinutes(minutes.toLong()).toString()', ' HZ=$minutes$minuteNote$fiveNote$btcNote$ruleNote -> ')))
    check('v0758_hour_rule', all(s in rules for s in (
        'const val HOUR_SHARE = 0.7', 'fun hourQuota(slots: Int = 12): Int = kotlin.math.ceil(HOUR_SHARE * slots - 1e-9).toInt()',
        'val need = hourQuota() - hourEntries; val left = (60 - minuteOfHour).coerceIn(1, 60)',
        'if (need >= left) return MinuteCut(Double.NEGATIVE_INFINITY, need, left, catchUp = true, full = false)',
        'if (need <= 0) return MinuteCut(Double.POSITIVE_INFINITY, need, left, catchUp = false, full = true)',
        'val frac = maxOf(need.toDouble() / left, baseShare(fresh, hourJst) / 2.0)',
        'fun judgeMinutes(weekend: Boolean, grade: String): Int = if (weekend || grade in setOf("S", "A", "I")) 3 else 5')))
    check('v0758_active_rules', 'val ACTIVE_IDS = setOf("FIX955_POS", "FIX955_BBZ", "US0830_F1")' in rules and 'if (r.id !in active) return@filter false' in rules
          and 'fun rulesAt(entry: ZonedDateTime, active: Set<String> = ACTIVE_IDS): List<Rule> {' in rules and rules.count('        Rule("') == 8
          and 'for (rule in rulesAt(entry, active)) {' in rules)
    check('v0758_ladder', all(s in rules for s in (
        '"S" to Rate(0.8000, 1.0, 2), "A" to Rate(0.5894, 0.5556, 9), "B" to Rate(0.5756, 0.5000, 40)',
        '"C" to Rate(0.5345, 0.4902, 1326), "D" to Rate(0.5170, 0.5146, 1541))', '"C" to Rate(0.5265, 0.5015, 1328), "D" to Rate(0.5130, 0.4974, 1530))',
        '"B" to Rate(0.5709, 0.5278, 180), "C" to Rate(0.4787, 0.4701, 1087)', 'const val FX_SPIKE_SIGMA = 2.5', 'const val S_CONFLUENCE = 3')))
    check('v0758_model5_data', model5.count('private const val FRESH_') == 5 and model5.count('private const val FALLBACK_') == 5
          and model5.count('_QUANTILES: Array<DoubleArray> = arrayOf(') == 2 and model5.count('_BASE = doubleArrayOf(') == 2
          and 'const val FEATURE_COUNT = 47' in model5 and '// v0.7.58 every-minute 5-minute ensembles' in model5)
    check('v0758_fixture_present', (ROOT/FIXTURE).is_file() and sha(ROOT/FIXTURE) == new[FIXTURE])
    check('v0758_rank_statistics', 'val CURRENT_RANK_VERSIONS = setOf("0.7.58")' in t[STATS] and 'const val C_SKIP_SINCE = "0.7.56"' in t[STATS]
          and 'm[t.hour] = (old.first + (if (slot) 1 else 0)) to (old.second + if (r.decision == "ENTRY") 1 else 0)' in t[STATS])
    check('v0758_viewmodel_every_minute', all(s in vm for s in (
        'return TradingSession.isWeekday(entry) || t.withZoneSameInstant(jst).minute % 5 == 4',
        'val inSlotWindow = isAutoMinute(now) && now.second in 50..54', 'while (!isAutoMinute(candidate) || !candidate.isAfter(now)) {',
        'val isThreeMinuteAutoMinute = prefs.autoScan && isAutoMinute(now)', 'val reservedFor3m = prefs.autoScan && isAutoMinute(scheduled)',
        'EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode, hourEntriesBefore(native.entryTimeJst))',
        'val keepRow = result.top1?.decision == "ENTRY" || EvidencePolicy.isBoundaryText(result.entryTimeJst) || source != "AUTO"',
        'error("ENTRY/SKIP契約違反")', 'error("未知ランク検出")',
        'if (source == "AUTO" && autoBoundary != null) refreshLiveQuotesBeforeDecision(eligible.keys.toList(), autoBoundary)',
        'SignalAlerts.entryTitle(top.grade, top.instrument, top.direction, SignalAlerts.minutesBetween(result.entryTimeJst, result.judgeTimeJst) ?: 3)'))
          and 'minute % 5 == 4' not in vm.replace('t.withZoneSameInstant(jst).minute % 5 == 4', ''))
    check('v0758_screens', 'internal fun JudgeBadge(minutes: Int, large: Boolean = false)' in t[MAIN] and 'ザオプションで「${minutes}分」を選んでエントリー' in t[MAIN]
          and 'val step = if (jp.gmk.mobile.domain.TradingSession.isWeekday(boundary.plusMinutes(1))) 1 else 5' in t[MAIN]
          and '平日70% = どの1時間も12枠中9回以上ENTRY' in t[SCREENS] and 'WEEKDAY_60("60W", "平日70%", true, false,' in t[MODE])
    check('v0758_tests_present', all(f'fun {n}()' in t[TEST] for n in ('everyMinuteEnsembleMatchesPythonExactly', 'hourRuleCutsAndRates',
          'boundarySlotsFollowTheHourRule', 'minutesBetweenBoundariesUseOnlyTheFiveMinuteModel', 'hourShareCountsBoundarySlotsAndAllEntries')))
    check('v0758_build_release', 'VERSION_CODE = 128' in t[BUILD] and '"EveryMinuteV0758Test": 5' in t[BUILD] and 'tools/audit_v0758.py' in t[BUILD]
          and '"FiveMinuteV0757Test"' not in t[BUILD])
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        rows = [r for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}']
        check('v0758_model_file_unchanged_since_v0750:' + f, len(rows) == 1 and rows[0]['pass'])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0758_EVERY_MINUTE_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.58-every-minute')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""v0.7.60 audit fix: source gate layered on the unchanged v0.7.59 audit.

Every v0.7.59 check is re-run; rows that fail only because a v0.7.60-modified file changed are re-pinned to the v0.7.60 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.60 gates below. The decision rule (policy, ladder, model, cuts, rules)
must be byte-identical to v0.7.59.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
MODE = D + 'domain/EntryMode.kt'; VM = D + 'ui/GmkViewModel.kt'; MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'
MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'; ALERTS = D + 'domain/SignalAlerts.kt'
IDENTITY = D + 'domain/HistoryIdentity.kt'; LIVE = D + 'domain/LiveEntryState.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/AuditFixV0760Test.kt'; FIXTURE = 'app/src/test/resources/v0760_hour_rule_parity.txt.gz'
GATES59 = {'v0759_policy_constants': POLICY, 'v0759_weekday_rule': POLICY, 'v0759_ladder': RULES, 'v0759_rank_statistics': STATS,
           'v0759_viewmodel_open_trades': VM, 'v0759_tests_present': 'app/src/test/java/SameDirectionV0759Test.kt', 'v0759_build_release': BUILD,
           'gradle_only_version_changed_v0759': GRADLE}


def audit():
    spec = importlib.util.spec_from_file_location('v0759_audit', ROOT/'tools/audit_v0759.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    spec8 = importlib.util.spec_from_file_location('v0758_audit_map', ROOT/'tools/audit_v0758.py')
    a58 = importlib.util.module_from_spec(spec8); spec8.loader.exec_module(a58)
    spec5 = importlib.util.spec_from_file_location('v0755_audit_base', ROOT/'tools/audit_v0755.py')
    a55 = importlib.util.module_from_spec(spec5); spec5.loader.exec_module(a55)
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.59 used
    EARLIER.update({
        'v0755_policy_constants': POLICY, 'v0755_rank_rule': POLICY, 'v0755_ladder': RULES, 'v0755_rank_statistics_version': STATS,
        'v0755_notification_grades': ALERTS, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': POLICY, 'v0756_rank_rule': POLICY, 'v0756_ladder': RULES, 'v0756_rank_statistics': STATS,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': POLICY,
        'v0756_entry_mode': MODE, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': ALERTS,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(old.GATES58); EARLIER.update(GATES59)
    manifest = json.loads((ROOT/'tools/v0760_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0760_audit_fix:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.59 source bytes plus the pinned v0.7.60 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0760_audit_fix:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.60; replaced by the v0.7.60 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*130\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.60-audit-fix"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m59 = json.loads((ROOT/'tools/v0759_source_extension.json').read_text()); m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m59['modified_existing'].items()}; known.update(m59['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0760_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0759_original_before_v0760:' + path, known[path] == item['v0759_sha256'])
    for path, digest in new.items():
        check('pinned_v0760_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0760', sha_text(gradle.replace('versionCode = 130', 'versionCode = 129')
          .replace('versionName = "0.7.60-audit-fix"', 'versionName = "0.7.59-same-direction"')) == changed[GRADLE]['v0759_sha256'])
    # the decision rule is byte-identical to v0.7.59
    for p in (POLICY, RULES, STATS):
        check('v0760_decision_rule_unchanged:' + p, sha(ROOT/p) == m59['modified_existing'][p]['updated_sha256'])
    for p in (MODEL, MODEL5):
        check('v0760_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    t = {k: (ROOT/k).read_text() for k in (VM, ALERTS, IDENTITY, LIVE, SCREENS, MODE, TEST, BUILD)}
    vm = t[VM]
    check('v0760_live_state', all(s in t[LIVE] for s in (
        'fun of(rows: List<HistoryRow>, entryTimeJst: String, policyTag: String): State {',
        'if (r.decision != "ENTRY" || r.candidateRank != 1 || !r.policyVersion.startsWith(policyTag)) continue',
        'if (!e.isBefore(entry) || e.isBefore(from)) continue', 'if (!e.isBefore(hourStart)) hour++',
        'if (j.isAfter(entry)) { if (r.direction == "HIGH") high++ else if (r.direction == "LOW") low++ }'))
          and 'val live = LiveEntryState.of(historyStore.rows.value, native.entryTimeJst, EvidencePolicy.POLICY_TAG)' in vm
          and 'EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode, live.hourEntries, live.openHigh, live.openLow)' in vm
          and 'fun hourEntriesBefore(' not in vm and 'fun openTradesAt(' not in vm)
    check('v0760_notification_default', 'const val DEFAULT_MIN_GRADE = "C"' in t[ALERTS]
          and 'fun normalizeMinGrade(grade: String?): String = when (grade) { "A" -> "A"; "B" -> "B"; "C" -> "C"; else -> DEFAULT_MIN_GRADE }' in t[ALERTS]
          and 'S/Aだけ 64.6%（1日0.8回・3分判定）・S〜B 58.7%（5.2回）・S〜C 53.5%（103回・ほぼ5分判定）' in t[SCREENS])
    check('v0760_history_identity', 'if(row.entryTimeJst==result.entryTimeJst)return true' in t[IDENTITY]
          and 'if(differentJstMinute(row.entryTimeJst,result.entryTimeJst))return false' in t[IDENTITY]
          and '}.getOrDefault(row.entryTimeJst==result.entryTimeJst)' in t[IDENTITY]
          and 'a.endsWith("+09:00") && b.endsWith("+09:00") && a.regionMatches(0, b, 0, 16).not()' in t[IDENTITY])
    check('v0760_one_minute_board_status', '"1分AUTO待機: 平日はAUTO（毎分・5分判定）が優先。1分ボードは土日かAUTOオフの時に動きます"' in vm
          and 'val inSlotWindow = isAutoMinute(now) && now.second in 50..54' in vm and 'error("ENTRY/SKIP契約違反")' in vm)
    check('v0760_fixture_present', (ROOT/FIXTURE).is_file() and sha(ROOT/FIXTURE) == new[FIXTURE])
    check('v0760_tests_present', all(f'fun {n}()' in t[TEST] for n in ('liveStateCountsThisHourAndRunningTrades', 'liveStateMatchesTheFullScanOnALongHistory',
          'hourRuleMatchesTheResearchExactly', 'historyIdentityKeepsItsMeaning', 'notificationsAnnounceEveryEntryByDefaultButKeepAChoice')))
    check('v0760_build_release', 'VERSION_CODE = 130' in t[BUILD] and '"AuditFixV0760Test": 5' in t[BUILD] and '"SameDirectionV0759Test": 4' in t[BUILD]
          and 'tools/audit_v0760.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0760_AUDIT_FIX_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.60-audit-fix')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

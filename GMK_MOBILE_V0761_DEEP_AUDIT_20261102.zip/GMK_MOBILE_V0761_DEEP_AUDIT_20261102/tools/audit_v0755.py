"""v0.7.55 fifty-five: source gate layered on the unchanged v0.7.54 audit.

Every v0.7.54 check is re-run; rows that fail only because a v0.7.55-modified file changed are re-pinned to the v0.7.55 bytes,
and rows describing an exact earlier edit of a file changed again are replaced by the v0.7.55 gates below.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; STATS = D + 'domain/RankStatistics.kt'
ALERTS = D + 'domain/SignalAlerts.kt'; VM = D + 'ui/GmkViewModel.kt'; MAIN = D + 'MainActivity.kt'; SCREENS = D + 'MarketScreens.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST = 'app/src/test/java/FiftyFiveV0755Test.kt'; TEST54 = 'app/src/test/java/LossPatternsV0754Test.kt'
# earlier exact-edit gates (last name segment) -> the file whose v0.7.55 bytes now stand for them
BASE = {
    'evidence_model_frozen_parameters_v0750': POLICY, 'evidence_policy_runs_after_every_overlay_with_live_quotes': VM,
    'viewmodel_only_live_quote_call_changed': VM, 'v0749_pattern_overlay': POLICY, 'v0750_observation_is_skip_only': STATS,
    'v0751_policy_constants': POLICY, 'v0751_rank_rule': POLICY, 'v0751_event_rules': RULES, 'v0751_ladder': RULES,
    'v0752_policy_constants': POLICY, 'v0752_ladder': RULES, 'v0752_event_rules_unchanged': RULES,
    'v0753_policy_constants': POLICY, 'v0753_rank_rule': POLICY, 'v0753_ladder': RULES, 'v0753_rank_statistics_version': STATS,
    'v0753_viewmodel_repository_unchanged_since_v0752': VM, 'v0753_main_activity_only_legend_text': MAIN, 'v0753_build_release': BUILD,
    'v0754_policy_constants': POLICY, 'v0754_rank_rule': POLICY, 'v0754_ladder': RULES, 'v0754_rank_statistics_version': STATS,
    'v0754_tests_present': TEST54, 'v0754_build_release': BUILD,
    **{f'gradle_only_version_changed_v07{n}': GRADLE for n in ('50', '51', '52', '53', '54')},
}


def audit():
    spec = importlib.util.spec_from_file_location('v0754_audit', ROOT/'tools/audit_v0754.py')
    old = importlib.util.module_from_spec(spec); spec.loader.exec_module(old)
    result = old.audit()
    manifest = json.loads((ROOT/'tools/v0755_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        path = next((p for p in changed if name.endswith(':' + p)), None)
        base = name.rsplit(':', 1)[-1]
        if path is not None:
            row.update(check='authorized_v0755_fifty_five:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.54 source bytes plus the pinned v0.7.55 change only.')
        elif base in BASE:
            p = BASE[base]
            row.update(check='authorized_v0755_fifty_five:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate; replaced by the v0.7.55 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*125\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.55-fifty-five"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    v54 = json.loads((ROOT/'tools/v0754_source_extension.json').read_text())
    v53 = json.loads((ROOT/'tools/v0753_source_extension.json').read_text())
    v52 = json.loads((ROOT/'tools/v0752_source_extension.json').read_text())
    known = {}
    for m in (v52, v53, v54):
        known.update({p: x['updated_sha256'] for p, x in m['modified_existing'].items()}); known.update(m['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0755_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0754_original_before_v0755:' + path, known[path] == item['v0754_sha256'])
    for path, digest in new.items():
        check('pinned_v0755_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0755', sha_text(gradle.replace('versionCode = 125', 'versionCode = 124')
          .replace('versionName = "0.7.55-fifty-five"', 'versionName = "0.7.54-loss-patterns"')) == changed[GRADLE]['v0754_sha256'])
    t = {k: (ROOT/k).read_text() for k in (POLICY, RULES, STATS, ALERTS, VM, MAIN, SCREENS, TEST, BUILD)}
    policy, rules, vm = t[POLICY], t[RULES], t[VM]
    check('v0755_policy_constants', all(s in policy for s in (
        'const val VERSION = "V0755_FIFTY_FIVE"', 'const val POLICY_TAG = "GMK_V0740_V0755_EVIDENCE"',
        'const val WEEKDAY_ENTRY_RATE = EvidenceStrengthData.WEEKDAY_COVER', 'const val WEEKEND_ENTRY_RATE = EvidenceStrengthData.WEEKEND_COVER',
        'const val WEEKDAY_BUFFER_SIZE = 288', 'const val WEEKEND_BUFFER_SIZE = 576', 'const val BUFFER_MIN = 96', 'const val LIVE_MAX_AGE_MS = 40_000L',
        'const val MAX_STATE_AGE_SEC = 21L * 24 * 3600', 'val model = if (fresh) EvidenceEnsemble.fresh else EvidenceEnsemble.fallback',
        'enter = if (q == null) e >= seedEnter else q >= 1.0 - WEEKDAY_ENTRY_RATE', 'enter = e >= c[0]',
        'val confirmed = choice.fresh && !weekend && inputs != null && RankLadder.confirms(choice.instrument, dirInt, inputs.f1)')))
    check('v0755_rank_rule', all(s in policy for s in (
        'val decision = decide(choice, weekend, b, record = native.source == "AUTO")',
        'val againstHour = RankLadder.againstHour(pos60, dirInt)',
        'val modelGrade = RankLadder.modelGrade(decision.grade, weekend, confirmed, hourJst, againstHour)',
        'val enter = caution == null && (ruleMatch != null || (decision.enter && demoted == null && modelGrade in RankLadder.ENTRY_GRADES))',
        'caution != null -> if (decision.enter) "D" else modelGrade', 'ruleMatch != null -> ruleMatch.grade',
        'judgeTimeJst = judge, policyVersion = POLICY_TAG + suffix)', '" qage=${quoteAgeMs?.let { "${it}ms" } ?: "none"}')))
    check('v0755_ladder', all(s in rules for s in (
        '"S" to Rate(0.6820, 0.7692, 26), "A" to Rate(0.6007, 0.5949, 79), "B" to Rate(0.5602, 0.5407, 344)',
        '"D" to Rate(0.5222, 0.5213, 3290), "E" to Rate(0.5052, 0.4686, 350), "F" to Rate(0.4878, 0.5018, 566))',
        '"B" to Rate(0.5709, 0.5278, 180), "D" to Rate(0.4838, 0.4760, 1000), "E" to Rate(0.4162, 0.4229, 551)',
        '"B" to Rate(0.5504, null, null), "D" to Rate(0.4694, null, null)', 'val ENTRY_GRADES = setOf("S", "A", "B")',
        '"S" -> if (againstHour) "B" else "D"', '"S", "A" -> if (confirmed) "B" else if (hourJst == PRE_FIX_HOUR) "F" else "D"',
        'pos60 != null && pos60.isFinite() && pos60 * direction <= 0.0',
        'const val FX_SPIKE_SIGMA = 2.5', 'const val BTC_FOLLOW_LOW = 1.0', 'const val BTC_FOLLOW_HIGH = 3.0', 'const val S_CONFLUENCE = 3'))
          and rules.count('        Rule("') == 8)
    check('v0755_late_live_refresh', 'if (source == "AUTO" && autoBoundary != null) refreshLiveQuotesBeforeDecision(eligible.keys.toList(), autoBoundary)' in vm
          and 'private val LIVE_REFRESH_RESERVE_MS = 1_800L' in vm and 'val budgetMs = (remainingMs - LIVE_REFRESH_RESERVE_MS).coerceAtMost(LIVE_REFRESH_MAX_MS)' in vm
          and 'LiveQuoteBoard.record(symbol, price, at)' in vm and '"live_price_age"' in vm)
    check('v0755_contract_check_kept', 'error("ENTRY/SKIP契約違反")' in vm and 'error("未知ランク検出")' in vm)
    check('v0755_rank_statistics_version', 'val CURRENT_RANK_VERSIONS = setOf("0.7.55")' in t[STATS])
    check('v0755_notification_grades', 'fun normalizeMinGrade(grade: String?): String = if (grade == "A") "A" else DEFAULT_MIN_GRADE' in t[ALERTS]
          and 'listOf("A" to "S/Aだけ", "B" to "全ENTRY（S〜B）")' in t[SCREENS])
    check('v0755_tests_present', all(f'fun {n}()' in t[TEST] for n in ('ladderRatesAndConstants', 'modelGradeMapping',
          'weekendStrongTradeEntersOnlyAgainstTheHourOnRealSlots', 'weekdayEntersOnlySAndB', 'liveAgeIsRecordedInLabelAndNote')))
    check('v0755_build_release', 'VERSION_CODE = 125' in t[BUILD] and '"FiftyFiveV0755Test": 5' in t[BUILD] and 'tools/audit_v0755.py' in t[BUILD])
    for f in ('EvidenceStrength.kt', 'EvidenceStrengthData.kt', 'EvidenceModel.kt', 'EvidenceModelData.kt', 'EvidenceFeatures.kt'):
        rows = [r for r in result['results'] if r['check'] == f'v0750_model_file_unchanged:{f}']
        check('v0755_model_file_unchanged_since_v0750:' + f, len(rows) == 1 and rows[0]['pass'])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0755_FIFTY_FIVE_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.55-fifty-five')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

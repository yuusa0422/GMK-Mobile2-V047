"""v0.7.64 run regime: source gate layered on the unchanged v0.7.63 audit.

Every v0.7.62 check is re-run; rows that fail only because a v0.7.63-modified file changed are re-pinned to the v0.7.63 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.63 gates below. The model, cuts and hour rule are untouched; the rules skip
the Tokyo fixing on Japanese bank holidays.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; LIVE = D + 'domain/LiveEntryState.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; CLOCK = D + 'domain/AutoClock.kt'; EDGE = D + 'domain/RecentEdge.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'; TEST = 'app/src/test/java/ClockGuardV0762Test.kt'
GATES61 = {'v0761_countdown': MAIN, 'v0761_texts': MAIN, 'v0761_build_release': BUILD, 'gradle_only_version_changed_v0761': GRADLE}
GATES62 = {'v0762_build_release': BUILD, 'gradle_only_version_changed_v0762': GRADLE, 'v0762_tests_present': 'app/src/test/java/ClockGuardV0762Test.kt'}
STATS = D + 'domain/RankStatistics.kt'; HOL = D + 'domain/JapanHolidays.kt'; RUN = D + 'domain/RunRegime.kt'
GATES63 = {'v0763_build_release': BUILD, 'gradle_only_version_changed_v0763': GRADLE, 'v0763_tests_present': 'app/src/test/java/HolidayV0763Test.kt'}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    a63 = load('v0763_audit', 'tools/audit_v0763.py'); result = a63.audit(); old = load('v0761_audit_map', 'tools/audit_v0761.py')
    a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.61 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60); EARLIER.update(GATES61); EARLIER.update(GATES62); EARLIER.update(GATES63)
    manifest = json.loads((ROOT/'tools/v0764_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0764_run_regime:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.63 source bytes plus the pinned v0.7.64 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0764_run_regime:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.62; replaced by the v0.7.64 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*134\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.64-run-regime"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m63 = json.loads((ROOT/'tools/v0763_source_extension.json').read_text()); m62 = json.loads((ROOT/'tools/v0762_source_extension.json').read_text())
    m61 = json.loads((ROOT/'tools/v0761_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m63['modified_existing'].items()}; known.update(m63['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0764_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0763_original_before_v0764:' + path, known[path] == item['v0763_sha256'])
    for path, digest in new.items():
        check('pinned_v0764_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0764', sha_text(gradle.replace('versionCode = 134', 'versionCode = 133')
          .replace('versionName = "0.7.64-run-regime"', 'versionName = "0.7.63-holiday"')) == changed[GRADLE]['v0763_sha256'])
    def pin(p):
        for m in (m63, m62):
            if p in m['modified_existing']: return m['modified_existing'][p]['updated_sha256']
            if p in m['new_source_files']: return m['new_source_files'][p]
        return m61['modified_existing'][p]['updated_sha256']
    for p in (POLICY, RULES, LIVE, STATS, CLOCK, EDGE, HOL):
        check('v0764_unchanged_since_v0763:' + p, sha(ROOT/p) == pin(p))
    m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    for p in (MODEL, MODEL5): check('v0764_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    t = {k: (ROOT/k).read_text() for k in (RUN, VM, MAIN, BUILD, 'app/src/test/java/RunRegimeV0764Test.kt')}
    check('v0764_run_regime', all(x in t[RUN] for x in ('const val BARS = 240', 'const val WARN = 1.0', 'const val HOT = 1.1',
          'if (done[i + 1].timeEpochMs - done[i].timeEpochMs == STEP_MS) kotlin.math.ln(done[i + 1].close) - kotlin.math.ln(done[i].close) else Double.NaN',
          'if (r15.size < 100) return null', 'if (r60.size < 40) return null', 'return sampleVar(r60) / (4.0 * v15)', 'val yen = if (vals.size >= 3) vals.sum() / vals.size else null')))
    check('v0764_viewmodel_refresh', all(x in t[VM] for x in ('val runRegime: RunRegime.State? = null,',
          'if (now - last >= 15 * 60_000L && !_state.value.busy && !_state.value.oneMinuteBusy && !shouldReserveYahooForUpcomingAuto()) {',
          'repository.fetchChartCandles(p, "15m").candles', 'val st = RunRegime.of(candles, System.currentTimeMillis())', 'root.put("run_regime", s.runRegime?.let {'))
          and 'Text(jp.gmk.mobile.domain.RunRegime.label(state.runRegime)' in t[MAIN])
    check('v0764_tests_present', all(f'fun {n}()' in t['app/src/test/java/RunRegimeV0764Test.kt'] for n in ('matchesTheResearchOnRealCandles', 'levelsAndGaps')))
    check('v0764_build_release', 'VERSION_CODE = 134' in t[BUILD] and '"RunRegimeV0764Test": 2' in t[BUILD] and '"HolidayV0763Test": 2' in t[BUILD] and 'tools/audit_v0764.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0764_RUN_REGIME_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.64-run-regime')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""v0.7.65 gap fill: source gate layered on the unchanged v0.7.64 audit.

Every v0.7.64 check is re-run; rows that fail only because a v0.7.65-modified file changed are re-pinned to the v0.7.65 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.65 gates below. Only the Yahoo 1-minute candle list is touched (a single
missing minute is rebuilt); the model, cuts, rules and the hour rule are unchanged.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; LIVE = D + 'domain/LiveEntryState.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; CLOCK = D + 'domain/AutoClock.kt'; EDGE = D + 'domain/RecentEdge.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
FEAT = D + 'domain/EvidenceFeatures.kt'; STATS = D + 'domain/RankStatistics.kt'; HOL = D + 'domain/JapanHolidays.kt'; RUN = D + 'domain/RunRegime.kt'
REPO = D + 'data/MarketRepository.kt'; FILL = D + 'domain/MinuteGapFill.kt'; TEST = 'app/src/test/java/GapFillV0765Test.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
GATES64 = {'v0764_build_release': BUILD, 'gradle_only_version_changed_v0764': GRADLE, 'v0764_viewmodel_refresh': VM}
REPO_V0765_NEW = ('                val raw = buildList {\n', '                }\n                // v0.7.65: rebuild the single minute Yahoo leaves out before its daily roll (08:59 JST in winter, 07:59 in summer)\n'
                  '                val out = jp.gmk.mobile.domain.MinuteGapFill.fill(raw).also { jp.gmk.mobile.domain.GapFillBoard.record(instrument, it.filledMinutes) }.candles.takeLast(120)\n')
REPO_V0764_OLD = ('                val out = buildList {\n', '                }.takeLast(120)\n')


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    a64 = load('v0764_audit', 'tools/audit_v0764.py'); result = a64.audit(); old = load('v0761_audit_map', 'tools/audit_v0761.py')
    a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.64 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60)
    EARLIER.update(a64.GATES61); EARLIER.update(a64.GATES62); EARLIER.update(a64.GATES63); EARLIER.update(GATES64)
    EARLIER['repository_only_records_yahoo_meta_quote'] = REPO     # v0.7.44 exact-edit gate of the repository (re-pinned in v0.7.54)
    manifest = json.loads((ROOT/'tools/v0765_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0765_gap_fill:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.64 source bytes plus the pinned v0.7.65 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0765_gap_fill:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.65; replaced by the v0.7.65 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*135\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.65-gap-fill"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m64 = json.loads((ROOT/'tools/v0764_source_extension.json').read_text()); m63 = json.loads((ROOT/'tools/v0763_source_extension.json').read_text())
    m62 = json.loads((ROOT/'tools/v0762_source_extension.json').read_text()); m61 = json.loads((ROOT/'tools/v0761_source_extension.json').read_text())
    def pin(p):
        for m in (m64, m63, m62):
            if p in m['modified_existing']: return m['modified_existing'][p]['updated_sha256']
            if p in m['new_source_files']: return m['new_source_files'][p]
        if p in m61['modified_existing']: return m61['modified_existing'][p]['updated_sha256']
        return None
    for path, item in changed.items():
        check('pinned_v0765_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if pin(path) is not None: check('v0764_original_before_v0765:' + path, pin(path) == item['v0764_sha256'])
    for path, digest in new.items():
        check('pinned_v0765_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0765', sha_text(gradle.replace('versionCode = 135', 'versionCode = 134')
          .replace('versionName = "0.7.65-gap-fill"', 'versionName = "0.7.64-run-regime"')) == changed[GRADLE]['v0764_sha256'])
    for p in (POLICY, RULES, LIVE, STATS, CLOCK, EDGE, HOL, RUN, MAIN):
        check('v0765_unchanged_since_v0764:' + p, sha(ROOT/p) == pin(p))
    m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    for p in (MODEL, MODEL5): check('v0765_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    check('v0765_features_unchanged:' + FEAT, FEAT not in changed and FEAT not in new)
    t = {k: (ROOT/k).read_text() for k in (FILL, REPO, VM, BUILD, TEST)}
    check('v0765_gap_fill', all(x in t[FILL] for x in ('const val MAX_MISSING = 1L', 'if (gap % STEP_MS == 0L && gap / STEP_MS - 1 in 1..MAX_MISSING) {',
          'val o = prev.close; val c = next.open', 'out.add(Candle(prev.timeEpochMs + k * STEP_MS, o, maxOf(o, c), minOf(o, c), c, 0.0))')))
    check('v0765_repository_uses_fill', t[REPO].count('MinuteGapFill.fill(') == 1 and
          'val out = jp.gmk.mobile.domain.MinuteGapFill.fill(raw).also { jp.gmk.mobile.domain.GapFillBoard.record(instrument, it.filledMinutes) }.candles.takeLast(120)' in t[REPO]
          and '.addQueryParameter("period1", (nowSec - 4L * 60L * 60L).toString())' in t[REPO])
    rv = t[REPO]
    for n, o in zip(REPO_V0765_NEW, REPO_V0764_OLD): rv = rv.replace(n, o, 1) if rv.count(n) == 1 else rv + '#'
    check('v0765_repository_only_the_fill_changed', sha_text(rv) == changed[REPO]['v0764_sha256'])
    check('v0765_diagnostics', '.put("minute_gap_fill", JSONObject().also { o -> jp.gmk.mobile.domain.GapFillBoard.snapshot().forEach { (k, e) ->' in t[VM])
    check('v0765_viewmodel_v0764_parts_kept', all(x in t[VM] for x in ('val runRegime: RunRegime.State? = null,', 'repository.fetchChartCandles(p, "15m").candles',
          'val st = RunRegime.of(candles, System.currentTimeMillis())', 'root.put("run_regime", s.runRegime?.let {')))
    check('v0765_tests_present', all(f'fun {n}()' in t[TEST] for n in ('realYahooRollIsRebuilt', 'winterRollOpensTheNineOClockHour',
          'longerGapsStayAndCompleteDataIsUnchanged', 'boardCountsEachMinuteOnce')))
    check('v0765_build_release', 'VERSION_CODE = 135' in t[BUILD] and '"GapFillV0765Test": 4' in t[BUILD] and '"RunRegimeV0764Test": 2' in t[BUILD]
          and 'tools/audit_v0765.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0765_GAP_FILL_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.65-gap-fill')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

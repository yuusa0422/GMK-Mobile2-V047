"""v0.7.69 audit fixes: source gate layered on the unchanged v0.7.68 audit.

Every v0.7.68 check is re-run; rows that fail only because a v0.7.69-modified file changed are re-pinned to the v0.7.69 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.69 gates below. Only history storage (newest rows rewritten on each save,
older rows in an archive file, the backup in its own file) and the start window of the runs-indicator chart fetch change; decisions,
model, cuts, ranks, rules, the weekday every-minute AUTO and the hour rule are unchanged.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
VM = D + 'ui/GmkViewModel.kt'; STORE = D + 'data/HistoryStore.kt'; ARCH = D + 'domain/HistoryArchive.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'
TEST69 = 'app/src/test/java/HistoryArchiveV0769Test.kt'; TEST69R = 'app/src/test/java/HistoryStoreArchiveV0769Test.kt'
UNCHANGED = [D + p for p in ('domain/EvidencePolicy.kt', 'domain/EventRules.kt', 'domain/LiveEntryState.kt', 'domain/RecentEdge.kt', 'domain/JapanHolidays.kt',
             'domain/RunRegime.kt', 'domain/MinuteGapFill.kt', 'data/MarketRepository.kt', 'MainActivity.kt', 'MarketScreens.kt', 'domain/AutoClock.kt',
             'domain/EvidenceFeatures.kt', 'domain/EvidenceModel.kt', 'domain/EvidenceModel5Data.kt', 'domain/CutInPolicy.kt', 'domain/RankStatistics.kt',
             'domain/OutcomeRepair.kt', 'domain/SignalAlerts.kt', 'domain/HistoryIdentity.kt', 'data/AssessmentJsonCodec.kt', 'data/AppPrefs.kt')]
GATES68 = {'v0768_repair_loop': VM, 'v0768_slot_log': VM, 'v0768_build_release': BUILD, 'gradle_only_version_changed_v0768': GRADLE}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    a68 = load('v0768_audit', 'tools/audit_v0768.py'); result = a68.audit()
    a67 = load('v0767_audit_map', 'tools/audit_v0767.py'); a65 = load('v0765_audit_map', 'tools/audit_v0765.py'); a64 = load('v0764_audit_map', 'tools/audit_v0764.py')
    old = load('v0761_audit_map', 'tools/audit_v0761.py'); a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO, MAIN = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt', D + 'MainActivity.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.68 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60)
    EARLIER.update(a64.GATES61); EARLIER.update(a64.GATES62); EARLIER.update(a64.GATES63); EARLIER.update(a65.GATES64); EARLIER.update(a67.GATES65)
    EARLIER.update(a67.SUPERSEDED67); EARLIER.update(a68.GATES67); EARLIER.update(GATES68)
    manifest = json.loads((ROOT/'tools/v0769_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0769_audit:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.68 source bytes plus the pinned v0.7.69 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0769_audit:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.69; replaced by the v0.7.69 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*139\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.69-audit"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m68 = json.loads((ROOT/'tools/v0768_source_extension.json').read_text())
    for path, item in changed.items():
        check('pinned_v0769_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in m68['modified_existing']: check('v0768_original_before_v0769:' + path, m68['modified_existing'][path]['updated_sha256'] == item['v0768_sha256'])
    for path, digest in new.items():
        check('pinned_v0769_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0769', sha_text(gradle.replace('versionCode = 139', 'versionCode = 138')
          .replace('versionName = "0.7.69-audit"', 'versionName = "0.7.68-repair"')) == changed[GRADLE]['v0768_sha256'])
    # every other source file has the v0.7.68 bytes (the v0.7.68 audit above pins them)
    for p in UNCHANGED: check('v0769_not_in_change_set:' + p, p not in changed and p not in new)
    t = {k: (ROOT/k).read_text() for k in (VM, STORE, ARCH, TEST69, TEST69R, BUILD)}
    check('v0769_archive_plan', all(x in t[ARCH] for x in ('const val RECENT_KEEP = 300', 'const val RECENT_MAX = 800',
          'fun key(r: HistoryRow): String = "${r.id}|${r.scanId}|${r.atJst}"', 'for (r in recent) if (key(r) !in keys)',
          'if (keepPrevious && file.isFile && !file.renameTo(previous))', 'if (!tmp.renameTo(file))', 'out.fd.sync()')))
    check('v0769_history_store', all(x in t[STORE] for x in ('context.getSharedPreferences("gmk_mobile_history_backup", Context.MODE_PRIVATE)',
          'AtomicLinesFile(java.io.File(context.filesDir, ARCHIVE_FILE_NAME))', 'const val ARCHIVE_FILE_NAME = "gmk_history_archive.jsonl"',
          'prefs.getString("items_backup", null) ?: backupPrefs.getString("items", null) ?: "[]"',
          'fun withArchive(recent: List<HistoryRow>) = HistoryArchivePlan.merge(recent, archived, MAX_HISTORY_ROWS)',
          'val plan = if (archiveWritable) HistoryArchivePlan.plan(snapshot, persistedArchive, archiveNeedsWrite)',
          'archive.write(lines, keepPrevious = true)', 'plan.recent.forEach { h -> a.put(rowToJson(h)) }',
          'editor.remove("items_backup").remove("items_backup_at_ms")', 'private const val MAX_HISTORY_ROWS = 20_000',
          'if (line.startsWith(ARCHIVE_END)) return if (seen == n && line == "$ARCHIVE_END $n") out else null'))
          and 'editor.putString("items_backup"' not in t[STORE])
    check('v0769_regime_window', all(x in t[VM] for x in ('ZonedDateTime.now(jst).second in 0..20', 'withTimeout(REGIME_FETCH_TIMEOUT_MS)',
          'private val REGIME_FETCH_TIMEOUT_MS = 15_000L')) and t[VM].count('withTimeout(25_000L)') == 1)   # the chart screen's own fetch
    check('v0769_tests_present', all(f'fun {n}()' in t[TEST69] for n in ('smallHistoryStaysRecentAndOverflowMovesOlderRowsOnce',
          'changedArchivedRowOrTrimmedTailIsHandled', 'rowInBothPartsIsTakenOnceInItsArchiveVersion', 'atomicFileKeepsOneEarlierVersionAndSurvivesAStopBeforeTheRename'))
          and all(f'fun {n}()' in t[TEST69R] for n in ('oldSingleFileHistoryIsSplitOnceAndReloadsUnchanged',
          'aStopBetweenTheArchiveAndTheRecentWriteLosesAndDoublesNothing', 'anUnreadableArchiveFallsBackToTheVersionBeforeItAndIsRewritten')))
    check('v0769_build_release', 'VERSION_CODE = 139' in t[BUILD] and '"HistoryArchiveV0769Test": 4' in t[BUILD] and '"HistoryStoreArchiveV0769Test": 3' in t[BUILD]
          and '"RepairV0768Test": 3' in t[BUILD] and 'tools/audit_v0769.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0769_AUDIT_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.69-audit')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

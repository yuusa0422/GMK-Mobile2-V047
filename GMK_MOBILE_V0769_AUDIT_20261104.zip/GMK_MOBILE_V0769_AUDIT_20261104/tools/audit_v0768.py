"""v0.7.68 repair: source gate layered on the unchanged v0.7.67 audit.

Every v0.7.67 check is re-run; rows that fail only because a v0.7.68-modified file changed are re-pinned to the v0.7.68 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.68 gates below. Only result tracking (missed prices retried while the app
runs), the hourly share display (I rows are not slots) and two diagnostics blocks change; decisions, model, cuts, rules, the weekday
every-minute AUTO and the hour rule are unchanged.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; LIVE = D + 'domain/LiveEntryState.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; CLOCK = D + 'domain/AutoClock.kt'; EDGE = D + 'domain/RecentEdge.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
FEAT = D + 'domain/EvidenceFeatures.kt'; STATS = D + 'domain/RankStatistics.kt'; HOL = D + 'domain/JapanHolidays.kt'; RUN = D + 'domain/RunRegime.kt'
REPO = D + 'data/MarketRepository.kt'; FILL = D + 'domain/MinuteGapFill.kt'; TEST = 'app/src/test/java/GapFillV0765Test.kt'; TEST67 = 'app/src/test/java/CleanupV0767Test.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'; FEAT_SHA = 'b57e11d32d4259b13cae7cbcb42d8b4d330729728a6b47e66d28948a1d43512b'
GATES65 = {'v0765_build_release': BUILD, 'gradle_only_version_changed_v0765': GRADLE, 'v0765_diagnostics': VM, 'v0765_viewmodel_v0764_parts_kept': VM}
STATS = D + 'domain/RankStatistics.kt'; REPAIR = D + 'domain/OutcomeRepair.kt'; TEST68 = 'app/src/test/java/RepairV0768Test.kt'
UNCHANGED = [D + p for p in ('domain/EvidencePolicy.kt', 'domain/EventRules.kt', 'domain/LiveEntryState.kt', 'domain/RecentEdge.kt', 'domain/JapanHolidays.kt',
             'domain/RunRegime.kt', 'domain/MinuteGapFill.kt', 'data/MarketRepository.kt', 'MainActivity.kt', 'MarketScreens.kt', 'domain/AutoClock.kt',
             'domain/EvidenceFeatures.kt', 'domain/EvidenceModel.kt', 'domain/EvidenceModel5Data.kt', 'data/HistoryStore.kt', 'domain/CutInPolicy.kt')]
GATES67 = {'v0767_build_release': BUILD, 'gradle_only_version_changed_v0767': GRADLE, 'v0767_screen_removed_unused': D + 'domain/RankStatistics.kt',
           'v0767_viewmodel_switches_off': VM}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    a67 = load('v0767_audit', 'tools/audit_v0767.py'); result = a67.audit(); a65 = load('v0765_audit_map', 'tools/audit_v0765.py'); a64 = load('v0764_audit_map', 'tools/audit_v0764.py'); old = load('v0761_audit_map', 'tools/audit_v0761.py')
    a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.64 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60)
    EARLIER.update(a64.GATES61); EARLIER.update(a64.GATES62); EARLIER.update(a64.GATES63); EARLIER.update(a65.GATES64); EARLIER.update(a67.GATES65); EARLIER.update(a67.SUPERSEDED67); EARLIER.update(GATES67)
    manifest = json.loads((ROOT/'tools/v0768_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0768_repair:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.67 source bytes plus the pinned v0.7.68 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0768_repair:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.68; replaced by the v0.7.68 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*138\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.68-repair"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m67 = json.loads((ROOT/'tools/v0767_source_extension.json').read_text())
    for path, item in changed.items():
        check('pinned_v0768_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in m67['modified_existing']: check('v0767_original_before_v0768:' + path, m67['modified_existing'][path]['updated_sha256'] == item['v0767_sha256'])
    for path, digest in new.items():
        check('pinned_v0768_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0768', sha_text(gradle.replace('versionCode = 138', 'versionCode = 137')
          .replace('versionName = "0.7.68-repair"', 'versionName = "0.7.67-cleanup"')) == changed[GRADLE]['v0767_sha256'])
    # every other source file has the v0.7.67 bytes (the v0.7.67 audit above pins them)
    for p in UNCHANGED: check('v0768_not_in_change_set:' + p, p not in changed and p not in new)
    t = {k: (ROOT/k).read_text() for k in (VM, STATS, REPAIR, TEST68, BUILD)}
    check('v0768_repair_rule', all(x in t[REPAIR] for x in ('const val MIN_AGE_MINUTES = 3L', 'const val MAX_AGE_HOURS = 24L', 'const val MAX_ATTEMPTS = 3',
          'const val INTERVAL_MS = 10L * 60L * 1000L', '.filter { it.resultStatus in MISSED && it.source != "MANUAL" && it.scanId.isNotBlank() }',
          '.filter { it.decision == "ENTRY" || ObservationPolicy.tracks(it) }')))
    check('v0768_repair_loop', all(x in t[VM] for x in ('                startRuleAlertLoop()\n                startOutcomeRepairLoop()',
          'if (!historyInitialized || _state.value.busy || shouldReserveYahooForUpcomingAuto(ZonedDateTime.now(jst))) return',
          'val reopened = withContext(Dispatchers.IO) { due.filter { historyStore.reopenMinuteAlignedMissForRecovery(it.scanId) } }.map { it.scanId }.toSet()',
          'for (h in rows) { scheduleOutcomeTracking(syntheticResult(h)); delay(20) }', 'outcomeRepairJob?.cancel()\n        outcomeJobs.values.forEach { it.cancel() }')))
    check('v0768_slot_log', t[VM].count('AutoSlotLog.record(') == 4 and all(x in t[VM] for x in ('AutoSlotLog.record(key, "MISSED_SLEEP")',
          'AutoSlotLog.record(key, "MISSED_WINDOW"', 'AutoSlotLog.record(key, "FAILED"', 'AutoSlotLog.record(key, "OK"',
          '.put("auto_slot_log", JSONObject()', '.put("outcome_repair", JSONObject()')))
    check('v0768_share_excludes_I', 'val slot = t.second == 0 && t.minute % 5 == 0 && r.grade != "I"' in t[STATS])
    check('v0768_tests_present', all(f'fun {n}()' in t[TEST68] for n in ('dueRowsAreRecentMinuteAlignedMisses', 'autoSlotLogKeepsOutcomesAndCounts',
          'shareDisplayDoesNotCountUnjudgeableSlots')))
    check('v0768_build_release', 'VERSION_CODE = 138' in t[BUILD] and '"RepairV0768Test": 3' in t[BUILD] and '"CleanupV0767Test": 2' in t[BUILD]
          and 'tools/audit_v0768.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0768_REPAIR_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.68-repair')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

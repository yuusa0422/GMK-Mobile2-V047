"""v0.7.67 cleanup: source gate layered on the unchanged v0.7.65 audit.

Every v0.7.65 check is re-run; rows that fail only because a v0.7.67-modified file changed are re-pinned to the v0.7.67 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.67 gates below. Only the screen (unused switches and the 1-minute board
removed, the judge/countdown text), the AUTO clock helpers and one statistics note change; decisions, model, cuts, rules, the weekday
every-minute AUTO and the hour rule are unchanged (the 5-minute v0.7.66 is not used).
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; LIVE = D + 'domain/LiveEntryState.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; CLOCK = D + 'domain/AutoClock.kt'; EDGE = D + 'domain/RecentEdge.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
FEAT = D + 'domain/EvidenceFeatures.kt'; STATS = D + 'domain/RankStatistics.kt'; HOL = D + 'domain/JapanHolidays.kt'; RUN = D + 'domain/RunRegime.kt'
REPO = D + 'data/MarketRepository.kt'; FILL = D + 'domain/MinuteGapFill.kt'; TEST = 'app/src/test/java/GapFillV0765Test.kt'; TEST67 = 'app/src/test/java/CleanupV0767Test.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'; FEAT_SHA = 'b57e11d32d4259b13cae7cbcb42d8b4d330729728a6b47e66d28948a1d43512b'
GATES65 = {'v0765_build_release': BUILD, 'gradle_only_version_changed_v0765': GRADLE, 'v0765_diagnostics': VM, 'v0765_viewmodel_v0764_parts_kept': VM}
# earlier gate that pinned the text of the removed 3-minute switch; superseded by v0767_screen_removed_unused
SUPERSEDED67 = {'v0761_texts_kept': MAIN}          # pinned the text of the removed 3-minute switch


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    a65 = load('v0765_audit', 'tools/audit_v0765.py'); result = a65.audit(); a64 = load('v0764_audit_map', 'tools/audit_v0764.py'); old = load('v0761_audit_map', 'tools/audit_v0761.py')
    a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.64 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60)
    EARLIER.update(a64.GATES61); EARLIER.update(a64.GATES62); EARLIER.update(a64.GATES63); EARLIER.update(a65.GATES64); EARLIER.update(GATES65); EARLIER.update(SUPERSEDED67)
    manifest = json.loads((ROOT/'tools/v0767_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0767_cleanup:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.65 source bytes plus the pinned v0.7.67 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0767_cleanup:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.67; replaced by the v0.7.67 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*137\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.67-cleanup"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m65 = json.loads((ROOT/'tools/v0765_source_extension.json').read_text()); m64 = json.loads((ROOT/'tools/v0764_source_extension.json').read_text()); m63 = json.loads((ROOT/'tools/v0763_source_extension.json').read_text())
    m62 = json.loads((ROOT/'tools/v0762_source_extension.json').read_text()); m61 = json.loads((ROOT/'tools/v0761_source_extension.json').read_text())
    def pin(p):
        for m in (m65, m64, m63, m62):
            if p in m['modified_existing']: return m['modified_existing'][p]['updated_sha256']
            if p in m['new_source_files']: return m['new_source_files'][p]
        if p in m61['modified_existing']: return m61['modified_existing'][p]['updated_sha256']
        return None
    for path, item in changed.items():
        check('pinned_v0767_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if pin(path) is not None: check('v0765_original_before_v0767:' + path, pin(path) == item['v0765_sha256'])
    for path, digest in new.items():
        check('pinned_v0767_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0767', sha_text(gradle.replace('versionCode = 137', 'versionCode = 135')
          .replace('versionName = "0.7.67-cleanup"', 'versionName = "0.7.65-gap-fill"')) == changed[GRADLE]['v0765_sha256'])
    for p in (POLICY, RULES, LIVE, EDGE, HOL, RUN, FILL, REPO):
        check('v0767_unchanged_since_v0765:' + p, sha(ROOT/p) == pin(p))
    check('v0767_features_unchanged:' + FEAT, sha(ROOT/FEAT) == FEAT_SHA)
    m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    for p in (MODEL, MODEL5): check('v0767_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    SCREENS = D + 'MarketScreens.kt'
    t = {k: (ROOT/k).read_text() for k in (MAIN, VM, CLOCK, BUILD, TEST67, SCREENS, STATS)}
    check('v0767_screen_removed_unused', all(x not in t[MAIN] for x in ('"3分判定に固定"', '1分専用板', 'OneMinuteManualPanel(', 'ModeChip('))
          and 'Tab.History -> HistoryScreen(state.history, false) { row ->' in t[MAIN] and '1分AUTO' not in t[SCREENS] and '1分ボードは参考表示のみ。' not in t[STATS])
    check('v0767_screen_texts', all(x in t[MAIN] for x in ('jp.gmk.mobile.domain.AutoClock.scheduleText(ZonedDateTime.now(ZoneId.of("Asia/Tokyo")))',
          '"次回AUTOまで（平日は毎分）"', '"次の5分枠まで " + jp.gmk.mobile.domain.AutoClock.countdownText(slotSeconds)',
          'Text(jp.gmk.mobile.domain.RunRegime.label(state.runRegime)', 'CountdownPanel(onScan, state.busy || state.oneMinuteBusy)',
          'ENTRYの割合（今のバージョン・自動・5分の区切りあたり）')))
    check('v0767_viewmodel_switches_off', all(x in t[VM] for x in ('oneMinuteAutoScan = false,', 'forceThreeMinuteOutcome = false,',
          '        prefs.oneMinuteAutoScan = false\n        prefs.forceThreeMinuteOutcome = false\n',
          'return TradingSession.isWeekday(entry) || t.withZoneSameInstant(jst).minute % 5 == 4')))
    check('v0767_autoclock', all(x in t[CLOCK] for x in ('fun nextSlotScanSeconds(now: ZonedDateTime): Int {',
          'if (ahead && entry.minute % 5 == 0 && TradingSession.isActive(entry)) return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())',
          'val runs = TradingSession.isActive(entry) && (TradingSession.isWeekday(entry) || entry.minute % 5 == 0)',
          '"平日: 毎分スキャン（S/Aは3分判定・B/Cは5分判定）"', '"土日: 5分ごとにスキャン・3分判定"')))
    check('v0767_tests_present', all(f'fun {n}()' in t[TEST67] for n in ('weekdayCountsDownEveryMinuteAndToTheNextSlot', 'weekendCountsDownFiveMinutes')))
    check('v0767_build_release', 'VERSION_CODE = 137' in t[BUILD] and '"CleanupV0767Test": 2' in t[BUILD] and '"GapFillV0765Test": 4' in t[BUILD]
          and 'tools/audit_v0767.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0767_CLEANUP_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.67-cleanup')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

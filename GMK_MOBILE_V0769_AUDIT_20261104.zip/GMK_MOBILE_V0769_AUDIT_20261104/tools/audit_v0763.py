"""v0.7.63 holiday: source gate layered on the unchanged v0.7.62 audit.

Every v0.7.62 check is re-run; rows that fail only because a v0.7.63-modified file changed are re-pinned to the v0.7.63 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.63 gates below. The model, cuts and hour rule are untouched; the rules skip
the Tokyo fixing on Japanese bank holidays.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; LIVE = D + 'domain/LiveEntryState.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; CLOCK = D + 'domain/AutoClock.kt'; EDGE = D + 'domain/RecentEdge.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'; TEST = 'app/src/test/java/ClockGuardV0762Test.kt'
GATES61 = {'v0761_countdown': MAIN, 'v0761_texts': MAIN, 'v0761_build_release': BUILD, 'gradle_only_version_changed_v0761': GRADLE}
GATES62 = {'v0762_build_release': BUILD, 'gradle_only_version_changed_v0762': GRADLE, 'v0762_tests_present': 'app/src/test/java/ClockGuardV0762Test.kt'}
STATS = D + 'domain/RankStatistics.kt'; HOL = D + 'domain/JapanHolidays.kt'


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    a62 = load('v0762_audit', 'tools/audit_v0762.py'); result = a62.audit(); old = load('v0761_audit_map', 'tools/audit_v0761.py')
    a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.61 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60); EARLIER.update(GATES61); EARLIER.update(GATES62)
    manifest = json.loads((ROOT/'tools/v0763_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0763_holiday:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.62 source bytes plus the pinned v0.7.63 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0763_holiday:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.62; replaced by the v0.7.63 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*133\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.63-holiday"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m62 = json.loads((ROOT/'tools/v0762_source_extension.json').read_text()); m61 = json.loads((ROOT/'tools/v0761_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m62['modified_existing'].items()}; known.update(m62['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0763_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0762_original_before_v0763:' + path, known[path] == item['v0762_sha256'])
    for path, digest in new.items():
        check('pinned_v0763_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0763', sha_text(gradle.replace('versionCode = 133', 'versionCode = 132')
          .replace('versionName = "0.7.63-holiday"', 'versionName = "0.7.62-clock-guard"')) == changed[GRADLE]['v0762_sha256'])
    for p in (POLICY, LIVE, VM, MAIN, CLOCK, EDGE):
        pin = m62['modified_existing'][p]['updated_sha256'] if p in m62['modified_existing'] else m62['new_source_files'].get(p) or m61['modified_existing'][p]['updated_sha256']
        check('v0763_unchanged_since_v0762:' + p, sha(ROOT/p) == pin)
    m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    for p in (MODEL, MODEL5): check('v0763_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    t = {k: (ROOT/k).read_text() for k in (RULES, STATS, HOL, BUILD, 'app/src/test/java/HolidayV0763Test.kt')}
    check('v0763_holiday_rule', all(s in t[RULES] for s in ('val noFixing = JapanHolidays.isBankHoliday(entry)', 'if (noFixing && r.id.startsWith("FIX955")) return@filter false',
          'val ACTIVE_IDS = setOf("FIX955_POS", "FIX955_BBZ", "US0830_F1")')) and '"2026-11-03", "2026-11-23", "2026-12-31",' in t[HOL]
          and '"2025-' not in t[HOL] and 'fun isBankHoliday(t: ZonedDateTime): Boolean = t.withZoneSameInstant(JST).toLocalDate() in DATES' in t[HOL])
    check('v0763_rank_title', 'else "v$version $seg（${if (weekend) "3分判定" else "S/Aは3分・B/C/Dは5分判定"}）"' in t[STATS] and '"3分 v$version $seg"' not in t[STATS])
    check('v0763_tests_present', all(f'fun {n}()' in t['app/src/test/java/HolidayV0763Test.kt'] for n in ('fixingRulesSkipJapaneseBankHolidays', 'nextRuleTextSkipsTheHoliday')))
    check('v0763_build_release', 'VERSION_CODE = 133' in t[BUILD] and '"HolidayV0763Test": 2' in t[BUILD] and '"ClockGuardV0762Test": 2' in t[BUILD] and 'tools/audit_v0763.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0763_HOLIDAY_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.63-holiday')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

"""v0.7.62 clock guard: source gate layered on the unchanged v0.7.61 audit.

Every v0.7.61 check is re-run; rows that fail only because a v0.7.62-modified file changed are re-pinned to the v0.7.62 bytes, and the
earlier exact-edit gates of those files are replaced by the v0.7.62 gates below. The decision rule, the model and its data are untouched.
"""
from pathlib import Path
import argparse, hashlib, importlib.util, json, re

ROOT = Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sha_text(text): return hashlib.sha256(text.encode()).hexdigest()
D = 'app/src/main/java/jp/gmk/mobile/'
POLICY = D + 'domain/EvidencePolicy.kt'; RULES = D + 'domain/EventRules.kt'; LIVE = D + 'domain/LiveEntryState.kt'; VM = D + 'ui/GmkViewModel.kt'
MAIN = D + 'MainActivity.kt'; CLOCK = D + 'domain/AutoClock.kt'; EDGE = D + 'domain/RecentEdge.kt'; MODEL = D + 'domain/EvidenceModel.kt'; MODEL5 = D + 'domain/EvidenceModel5Data.kt'
GRADLE = 'app/build.gradle.kts'; BUILD = 'tools/build_release.py'; TEST = 'app/src/test/java/ClockGuardV0762Test.kt'
GATES61 = {'v0761_countdown': MAIN, 'v0761_texts': MAIN, 'v0761_build_release': BUILD, 'gradle_only_version_changed_v0761': GRADLE}


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, ROOT/file)
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod


def audit():
    old = load('v0761_audit', 'tools/audit_v0761.py'); result = old.audit()
    a60 = load('v0760_audit_map', 'tools/audit_v0760.py'); a59 = load('v0759_audit_map', 'tools/audit_v0759.py')
    a58 = load('v0758_audit_map', 'tools/audit_v0758.py'); a55 = load('v0755_audit_base', 'tools/audit_v0755.py')
    P_, R_, S_ = D + 'domain/EvidencePolicy.kt', D + 'domain/EventRules.kt', D + 'domain/RankStatistics.kt'
    AL, MO = D + 'domain/SignalAlerts.kt', D + 'domain/EntryMode.kt'
    EARLIER = dict(a55.BASE)                    # the same earlier-gate -> file map that v0.7.57 .. v0.7.61 used
    EARLIER.update({
        'v0755_policy_constants': P_, 'v0755_rank_rule': P_, 'v0755_ladder': R_, 'v0755_rank_statistics_version': S_,
        'v0755_notification_grades': AL, 'v0755_build_release': BUILD, 'v0752_legacy_horizon_not_used': VM,
        'gradle_only_version_changed_v0755': GRADLE, 'v0749_tests_present': 'app/src/test/java/EvidencePolicyTest.kt',
        'v0756_policy_constants': P_, 'v0756_rank_rule': P_, 'v0756_ladder': R_, 'v0756_rank_statistics': S_,
        'v0756_build_release': BUILD, 'gradle_only_version_changed_v0756': GRADLE, 'weekend_pool_is_btc_only': P_,
        'v0756_entry_mode': MO, 'v0756_viewmodel_mode': VM, 'v0756_screens': MAIN, 'v0756_notification_grades': AL,
        'v0756_tests_present': 'app/src/test/java/EntrySixtyV0756Test.kt',
    })
    EARLIER.update(a58.REPLACED); EARLIER.update(a59.GATES58); EARLIER.update(a60.GATES59); EARLIER.update(old.GATES60); EARLIER.update(GATES61)
    manifest = json.loads((ROOT/'tools/v0762_source_extension.json').read_text())
    changed = manifest['modified_existing']; new = manifest['new_source_files']
    gradle = (ROOT/GRADLE).read_text()
    for row in result['results']:
        name = row['check']
        if row['pass']: continue
        base = name.rsplit(':', 1)[-1]
        path = next((p for p in changed if name.endswith(':' + p)), None)
        if path is not None:
            row.update(check='authorized_v0762_clock_guard:' + name, **{'pass': sha(ROOT/path) == changed[path]['updated_sha256']},
                       detail='v0.7.61 source bytes plus the pinned v0.7.62 change only.')
        elif base in EARLIER and EARLIER[base] in changed:
            p = EARLIER[base]
            row.update(check='authorized_v0762_clock_guard:' + name, **{'pass': sha(ROOT/p) == changed[p]['updated_sha256']},
                       detail='Earlier exact-edit gate of a file changed again in v0.7.62; replaced by the v0.7.62 gates.')
        elif name == 'updated_version_code': row['pass'] = re.search(r'versionCode\s*=\s*132\b', gradle) is not None
        elif name == 'updated_version_name': row['pass'] = 'versionName = "0.7.62-clock-guard"' in gradle

    def check(name, ok):
        result['results'].append({'check': name, 'pass': bool(ok)})
    m61 = json.loads((ROOT/'tools/v0761_source_extension.json').read_text())
    known = {p: x['updated_sha256'] for p, x in m61['modified_existing'].items()}; known.update(m61['new_source_files'])
    for path, item in changed.items():
        check('pinned_v0762_change:' + path, sha(ROOT/path) == item['updated_sha256'])
        if path in known: check('v0761_original_before_v0762:' + path, known[path] == item['v0761_sha256'])
    for path, digest in new.items():
        check('pinned_v0762_new_file:' + path, (ROOT/path).is_file() and sha(ROOT/path) == digest)
    check('gradle_only_version_changed_v0762', sha_text(gradle.replace('versionCode = 132', 'versionCode = 131')
          .replace('versionName = "0.7.62-clock-guard"', 'versionName = "0.7.61-deep-audit"')) == changed[GRADLE]['v0761_sha256'])
    for p in (POLICY, RULES, LIVE, VM):
        check('v0762_decision_unchanged:' + p, sha(ROOT/p) == (m61['modified_existing'][p]['updated_sha256'] if p in m61['modified_existing'] else ''))
    m58 = json.loads((ROOT/'tools/v0758_source_extension.json').read_text())
    for p in (MODEL, MODEL5): check('v0762_model_unchanged:' + p, sha(ROOT/p) == m58['modified_existing'][p]['updated_sha256'])
    t = {k: (ROOT/k).read_text() for k in (MAIN, CLOCK, EDGE, TEST, BUILD)}
    check('v0762_clock', all(s in t[CLOCK] for s in (
        'val runs = TradingSession.isActive(entry) && (TradingSession.isWeekday(entry) || entry.minute % 5 == 0)',
        'val ahead = !scanAt.isBefore(z) || ChronoUnit.MILLIS.between(scanAt, z) < 1000L', 'if (ahead && runs) return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())'))
          and 'private fun nextScanSeconds(): Int = jp.gmk.mobile.domain.AutoClock.nextAutoScanSeconds(' in t[MAIN]
          and 'Text(jp.gmk.mobile.domain.AutoClock.countdownText(seconds)' in t[MAIN] and 'while (scanAt.isBefore(z)' not in t[MAIN])
    check('v0762_recent_edge', all(s in t[EDGE] for s in ('const val DAYS = 10', 'const val MIN_DAYS = 3', 'const val MIN_ROWS_PER_DAY = 20',
          'const val BREAK_EVEN = 1.0 / 1.9', 'const val STOP = 0.50', 'if (r.decision != "ENTRY" || r.candidateRank != 1 || !r.policyVersion.startsWith(policyTag)) continue',
          'if (day.dayOfWeek.value > 5 || !day.isBefore(today)) continue'))
          and 'jp.gmk.mobile.domain.RecentEdge.of(state.history, java.time.LocalDate.now(ZoneId.of("Asia/Tokyo")), jp.gmk.mobile.domain.EvidencePolicy.POLICY_TAG)' in t[MAIN]
          and 'Text(jp.gmk.mobile.domain.RecentEdge.label(edge)' in t[MAIN])
    check('v0761_texts_kept', '旧モデル用のスイッチ。今の運用等級（S/Aは3分・B/C/Dは5分判定、土日は3分）には影響しません' in t[MAIN]
          and 'ENTRYの割合（今のバージョン・自動・5分の区切りあたり）' in t[MAIN])
    check('v0762_tests_present', all(f'fun {n}()' in t[TEST] for n in ('countdownMatchesTheAutoScheduleDayAndNight', 'recentEdgeUsesFinishedWeekdaysOnly')))
    check('v0762_build_release', 'VERSION_CODE = 132' in t[BUILD] and '"ClockGuardV0762Test": 2' in t[BUILD] and '"DeepAuditV0761Test": 3' in t[BUILD]
          and 'tools/audit_v0762.py' in t[BUILD])
    result.update(status='PASS' if all(r['pass'] for r in result['results']) else 'FAIL',
                  scope='V0762_CLOCK_GUARD_SOURCE_GATES; ANDROID_REPLAY_AND_APK_REQUIRED_SEPARATELY',
                  checks=len(result['results']), failed=[r['check'] for r in result['results'] if not r['pass']], current_version='0.7.62-clock-guard')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = audit()
    if args.output: args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ['status', 'checks', 'failed', 'scope']}, ensure_ascii=False))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)

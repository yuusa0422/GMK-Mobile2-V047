import jp.gmk.mobile.domain.*
import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

/** v0.7.67: the countdown says what the AUTO does - weekday every minute (S/A 3-minute, B/C 5-minute judging), weekend every 5 minutes. */
class CleanupV0767Test {
    private val jst = ZoneId.of("Asia/Tokyo")
    private fun t(d: Int, h: Int, m: Int, s: Int) = ZonedDateTime.of(2026, 11, d, h, m, s, 0, jst)

    @Test fun weekdayCountsDownEveryMinuteAndToTheNextSlot() {
        val now = t(4, 17, 51, 20)                                    // Wednesday 17:51:20 -> next scan 17:51:50, next slot scan 17:54:50
        assertEquals(30, AutoClock.nextAutoScanSeconds(now))
        assertEquals(210, AutoClock.nextSlotScanSeconds(now))
        assertTrue(AutoClock.everyMinute(now))
        assertEquals("平日: 毎分スキャン（S/Aは3分判定・B/Cは5分判定）", AutoClock.scheduleText(now))
        assertEquals(0, AutoClock.nextSlotScanSeconds(t(4, 17, 54, 50).plusNanos(400_000_000)))
        // last slot of the day 22:55 -> after it the next one is 09:00 the next weekday (T-10 = 08:59:50)
        assertEquals(10 * 3600 + 4 * 60 + 50, AutoClock.nextSlotScanSeconds(t(4, 22, 55, 0)))
    }

    @Test fun weekendCountsDownFiveMinutes() {
        val sat = t(7, 10, 1, 0)                                      // Saturday: scans only on 5-minute slots, 3-minute judging
        assertEquals(3 * 60 + 50, AutoClock.nextAutoScanSeconds(sat))
        assertEquals(AutoClock.nextAutoScanSeconds(sat), AutoClock.nextSlotScanSeconds(sat))
        assertFalse(AutoClock.everyMinute(sat))
        assertEquals("土日: 5分ごとにスキャン・3分判定", AutoClock.scheduleText(sat))
        // Friday 22:58 still has the weekday 22:59 scan; after it (22:59:55) the next scan is Saturday 09:00 (weekend schedule)
        assertTrue(AutoClock.everyMinute(t(6, 22, 58, 0)))
        assertFalse(AutoClock.everyMinute(t(6, 22, 59, 55)))
    }
}

package jp.gmk.mobile.domain

import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.max

/** v0.7.62: the "次回AUTOまで" countdown follows the scans that really run. */
object AutoClock {
    private val JST: ZoneId = ZoneId.of("Asia/Tokyo")

    /** Seconds to the next AUTO scan that will run: T-10 before an entry minute inside 09:00-23:00 JST (weekday every minute,
     *  weekend every 5 minutes). Outside the hours it counts down to the first scan of the session (up to v0.7.61 it restarted
     *  every minute all night). A scan that started less than a second ago still shows 0. */
    fun nextAutoScanSeconds(now: ZonedDateTime): Int {
        val z = now.withZoneSameInstant(JST)
        var entry = z.truncatedTo(ChronoUnit.MINUTES)
        repeat(4 * 24 * 60) {
            val scanAt = entry.minusSeconds(10)
            val ahead = !scanAt.isBefore(z) || ChronoUnit.MILLIS.between(scanAt, z) < 1000L
            val runs = TradingSession.isActive(entry) && (TradingSession.isWeekday(entry) || entry.minute % 5 == 0)
            if (ahead && runs) return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())
            entry = entry.plusMinutes(1)
        }
        return 0
    }

    /** v0.7.67: seconds to the AUTO scan of the next 5-minute slot (:00, :05, ...), the slots the hour's 70% is counted in. */
    fun nextSlotScanSeconds(now: ZonedDateTime): Int {
        val z = now.withZoneSameInstant(JST)
        var entry = z.truncatedTo(ChronoUnit.MINUTES)
        repeat(4 * 24 * 60) {
            val scanAt = entry.minusSeconds(10)
            val ahead = !scanAt.isBefore(z) || ChronoUnit.MILLIS.between(scanAt, z) < 1000L
            if (ahead && entry.minute % 5 == 0 && TradingSession.isActive(entry)) return max(0, ChronoUnit.SECONDS.between(z, scanAt).toInt())
            entry = entry.plusMinutes(1)
        }
        return 0
    }

    /** The next AUTO scan is a weekday one (every minute) rather than a weekend one (every 5 minutes). */
    fun everyMinute(now: ZonedDateTime): Boolean {
        val next = now.withZoneSameInstant(JST).plusSeconds(nextAutoScanSeconds(now) + 10L)
        return TradingSession.isWeekday(next)
    }

    /** What the AUTO does at the next scan, in the words of the screen. */
    fun scheduleText(now: ZonedDateTime): String =
        if (everyMinute(now)) "平日: 毎分スキャン（S/Aは3分判定・B/Cは5分判定）" else "土日: 5分ごとにスキャン・3分判定"

    fun countdownText(seconds: Int): String =
        if (seconds >= 3600) String.format("%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
        else String.format("%02d:%02d", seconds / 60, seconds % 60)
}

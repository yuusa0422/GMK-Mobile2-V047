package jp.gmk.mobile

import android.os.Bundle
import android.os.Build
import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Duration
import jp.gmk.mobile.domain.*
import jp.gmk.mobile.ui.GmkUiState
import jp.gmk.mobile.ui.GmkViewModel
import jp.gmk.mobile.runtime.GmkRuntimeHolder
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.max

private val Paper = Color(0xFFF6EBDD)
private val Paper2 = Color(0xFFFFF8EE)
private val Wood = Color(0xFF4A3029)
private val Wine = Color(0xFFA63847)
private val WineDark = Color(0xFF6D2430)
private val Ink = Color(0xFF35211E)
private val High = Color(0xFFC73B4D)
private val Low = Color(0xFF315FB6)
private val Gold = Color(0xFFB7893C)

// Reimu night-shrine scan theme
private val ScanBg = Color(0xFF07142A)
private val ScanPanel = Color(0xD9142343)
private val ScanPanel2 = Color(0xE21A1834)
private val ScanCyan = Color(0xFF35D9FF)
private val ScanPink = Color(0xFFFF4F91)
private val ScanPurple = Color(0xFF9E6CFF)
private val ScanText = Color(0xFFF6F2FF)
private val ScanMuted = Color(0xFF9FB4D9)
private val ScanGreen = Color(0xFF53E6A4)

class MainActivity : ComponentActivity() {
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Foreground runtime still functions; UI power/runtime diagnostics remain visible if denied. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Wine, background = Paper)) { GmkApp() }
        }
    }

    override fun onResume() {
        super.onResume()
        GmkRuntimeHolder.get(application).refreshDevicePowerState()
    }
}

enum class Tab { Prediction, Chart, Strength, History, Status }

@Composable
fun GmkApp() {
    val app = LocalContext.current.applicationContext as android.app.Application
    val vm = remember(app) { GmkRuntimeHolder.get(app) }
    val state by vm.state.collectAsState()
    var tabName by rememberSaveable { mutableStateOf(Tab.Prediction.name) }
    val tab = runCatching { Tab.valueOf(tabName) }.getOrDefault(Tab.Prediction)
    var selectedInstrument by rememberSaveable { mutableStateOf("EURJPY") }
    var chartTimeframe by rememberSaveable { mutableStateOf("1m") }
    var autoFollowScan by rememberSaveable { mutableStateOf(true) }
    var focusHistory by remember { mutableStateOf<HistoryRow?>(null) }
    val newestScanCandidate = listOfNotNull(
        state.scan?.let { scan -> scan.top1?.let { scan.atJst to it.instrument } },
        state.oneMinuteScan?.let { scan -> scan.top1?.let { scan.atJst to it.instrument } }
    ).maxByOrNull { (at, _) -> runCatching { ZonedDateTime.parse(at).toInstant().toEpochMilli() }.getOrDefault(0L) }
    LaunchedEffect(newestScanCandidate?.first, autoFollowScan) {
        if (autoFollowScan) newestScanCandidate?.second?.let {
            selectedInstrument = it
            focusHistory = null
        }
    }
    val context = LocalContext.current
    val diagnosticLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching {
                val stream = requireNotNull(context.contentResolver.openOutputStream(uri)) { "保存先を開けません" }
                stream.use { out ->
                    out.write(vm.buildDiagnosticJson().toByteArray(Charsets.UTF_8))
                    out.flush()
                }
                true
            }.getOrDefault(false)
            Toast.makeText(
                context,
                if (ok) "診断ログを保存しました" else "診断ログの保存に失敗しました",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
    Scaffold(
        containerColor = Paper,
        bottomBar = {
            BottomBar(tab) {
                tabName = it.name
                if (it == Tab.History) vm.loadHistory()
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.Prediction -> ScanScreen(
                    state,
                    vm::manualScan,
                    vm::manualOneMinuteScan,
                    vm::setAuto,
                    vm::setOneMinuteAuto,
                    vm::setForceThreeMinute
                )
                Tab.Chart -> ChartScreen(
                    state = state,
                    instrument = selectedInstrument,
                    timeframe = chartTimeframe,
                    focusHistory = focusHistory,
                    autoFollowScan = autoFollowScan,
                    onToggleAutoFollow = { autoFollowScan = !autoFollowScan },
                    onInstrument = { selectedInstrument = it; focusHistory = null; autoFollowScan = false },
                    onTimeframe = { chartTimeframe = it },
                    onRefresh = vm::loadChart
                )
                Tab.Strength -> CurrencyStrengthScreen(
                    state = state,
                    onRefresh = vm::loadStrength,
                    onSelectPair = { selectedInstrument = it; focusHistory = null; autoFollowScan = false; tabName = Tab.Chart.name }
                )
                Tab.History -> HistoryScreen(state.history, false) { row ->
                    selectedInstrument = row.instrument
                    focusHistory = row
                    chartTimeframe = "1m"
                    autoFollowScan = false
                    tabName = Tab.Chart.name
                }
                Tab.Status -> StatusScreen(
                    state = state,
                    setCutInEnabled = vm::setCutInEnabled,
                    exportDiagnostic = { diagnosticLauncher.launch("GMK_DIAGNOSTICS_${System.currentTimeMillis()}.json") },
                    setSignalNotify = vm::setSignalNotify,
                    setNotifyMinGrade = vm::setNotifyMinGrade,
                    setEntryMode = vm::setEntryMode
                )
            }
            CutInOverlay(
                state = state,
                controller = vm.cutInEvents,
                onShown = vm::recordCutInShown,
                onSuppressed = vm::recordCutInSuppressed
            )
        }
    }
}


@Composable
private fun PowerPolicyWarning(state: GmkUiState) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE6E6))
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("バックグラウンド制限を確認してください", color = WineDark, fontWeight = FontWeight.Bold)
            Text(
                if (state.backgroundRestricted)
                    "Androidがバックグラウンド実行を制限中です。AUTO/T-10が遅延する可能性があります。"
                else
                    "電池最適化の対象です。画面OFF/DozeでAUTO/T-10が遅延する可能性があります。",
                color = Ink, fontSize = 12.sp
            )
            TextButton(onClick = {
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) { Text("電池最適化設定を開く") }
        }
    }
}

@Composable
private fun ScanScreen(
    state: GmkUiState,
    onScan: () -> Unit,
    onOneMinuteScan: () -> Unit,
    onAuto: (Boolean) -> Unit,
    onOneMinuteAuto: (Boolean) -> Unit,
    onForceThreeMinute: (Boolean) -> Unit
) {
    Box(Modifier.fillMaxSize().background(ScanBg)) {
        Image(
            painter = painterResource(R.drawable.scan_reimu_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color(0x66030A19), Color(0xCC07142A), Color(0xF207142A))
                )
            )
        )
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Box(Modifier.fillMaxWidth()) {
                    Image(
                        painterResource(R.drawable.scan_reimu_hero), null,
                        Modifier.fillMaxWidth().aspectRatio(1024f / 680f),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        Modifier.matchParentSize().background(
                            Brush.verticalGradient(listOf(Color.Transparent, Color(0xB807142A)))
                        )
                    )
                    Column(
                        Modifier.align(Alignment.BottomStart).padding(start = 18.dp, end = 18.dp, bottom = 14.dp)
                    ) {
                        Text("豪徳寺 三花システム", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("GMK MOBILE  •  幻想の相場に、弾を放て", color = Color(0xFFE9C8FF), fontSize = 11.sp)
                    }
                }
                StatusStrip(state)
                if (!state.batteryOptimizationExempt || state.backgroundRestricted) {
                    PowerPolicyWarning(state)
                }
                ModePanel(state.autoScan, state.forceThreeMinuteOutcome, onAuto)
                NextRuleLine()
                CountdownPanel(onScan, state.busy || state.oneMinuteBusy)
                // v0.7.62: is the edge there right now (this version's own results over the last 10 weekdays)
                val edge = remember(state.history) {
                    jp.gmk.mobile.domain.RecentEdge.of(state.history, java.time.LocalDate.now(ZoneId.of("Asia/Tokyo")), jp.gmk.mobile.domain.EvidencePolicy.POLICY_TAG)
                }
                Text(jp.gmk.mobile.domain.RecentEdge.label(edge), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                    color = when (edge.level) {
                        jp.gmk.mobile.domain.RecentEdge.Level.STOP -> Color(0xFFFF5A6E)
                        jp.gmk.mobile.domain.RecentEdge.Level.BELOW_BREAK_EVEN -> Color(0xFFFFB04A)
                        jp.gmk.mobile.domain.RecentEdge.Level.GOOD -> Color(0xFF6EE7B7)
                        else -> ScanMuted
                    }, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                // v0.7.64: runs indicator (display only)
                Text(jp.gmk.mobile.domain.RunRegime.label(state.runRegime), modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp),
                    color = when (state.runRegime?.level) {
                        jp.gmk.mobile.domain.RunRegime.Level.STRONG_RUNS -> Color(0xFFFF5A6E)
                        jp.gmk.mobile.domain.RunRegime.Level.RUNS -> Color(0xFFFFB04A)
                        jp.gmk.mobile.domain.RunRegime.Level.CALM -> Color(0xFF6EE7B7)
                        else -> ScanMuted
                    }, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            item { Top1Card(state.scan?.top1, state.scan?.candidates?.size ?: 0, expiryMinutes(state.scan?.entryTimeJst.orEmpty(), state.scan?.judgeTimeJst.orEmpty(), 3)) }
            item { SectionTitle("スキャン結果") }
            val evidenceScan = RankStatistics.evidenceVersion(state.scan?.policyVersion.orEmpty()) != null
            val entryMode = EntryMode.parse(state.entryMode)
            item { Text(if (evidenceScan) "運用等級: 平日は為替だけを毎分判定し、どの1時間も70%以上ENTRY。S/A = 時間帯ルール（仲値9:55・米指標8:30。ほかのサインも揃うとS）→【3分判定】。B = 強い取引×直前1分の一致、C = 5分モデルが70%に入る側 →【5分判定】（土日は5分ごと・全部3分）。S/A/B は1年55%以上、C は平日53.2%・土日47.9%。ENTRYの量「${entryMode.label}」: ${entryMode.summary}（状態タブで変更）。D〜H = 見送り（理由つき）、I = 判定不能。等級は1位だけ、2位以下は参考。" else "類似ランク E / F / G / H / 保留。E〜Hは元E候補の類似推定順（強弱未検証）。ENTRY/SKIPは従来の判定です。", Modifier.padding(horizontal = 14.dp, vertical = 4.dp), color = ScanMuted, fontSize = 10.sp) }
            val results = state.scan?.candidates.orEmpty()
            if (results.isEmpty()) {
                items(state.rates) { RateOnlyRow(it) }
            } else {
                items(results) { c -> ResultRow(c, state.rates.firstOrNull { it.instrument == c.instrument }, evidenceScan) }
                val candidateSet = results.map { it.instrument }.toSet()
                val excludedRates = state.rates.filter { it.instrument !in candidateSet }
                if (excludedRates.isNotEmpty()) {
                    item { SectionTitle("今回の判定対象外") }
                    items(excludedRates) { RateOnlyRow(it) }
                }
            }
            if (state.lastScanExcluded.isNotEmpty()) {
                item {
                    Text(
                        state.lastScanExcluded.entries.joinToString(" / ") { "${it.key}: ${it.value}" },
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        color = Color(0xFFFF9AAE), fontSize = 11.sp
                    )
                }
            }
            val divergenceAlerts = state.quoteCandleDivergencePct.filter { (ins, pct) ->
                pct >= if (ins == "BTCJPY") 1.50 else 0.50
            }
            if (divergenceAlerts.isNotEmpty()) {
                item {
                    Text(
                        "価格整合注意: " + divergenceAlerts.entries.joinToString(" / ") {
                            "${it.key} ${"%.3f".format(it.value)}%"
                        },
                        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                        color = Color(0xFFFF728F), fontSize = 11.sp, fontWeight = FontWeight.Bold
                    )
                }
            }
            item { RecentHistoryPreview(state.history) }
            item { Spacer(Modifier.height(18.dp)) }
        }
    }
}

private typealias CutInKind = CutInEventQueue.Kind

private data class CutInDisplay(
    val key: String,
    val scanId: String,
    val instrument: String,
    val kind: CutInKind,
    val slot: Int,
    val oneMinuteAdvantage: Boolean = false
)

private fun cutInDrawable(kind: CutInKind, slot: Int, oneMinuteAdvantage: Boolean = false): Int {
    val i = slot.coerceIn(1, 10) - 1
    val winAdv = intArrayOf(
        R.drawable.cutin_win_adv_01, R.drawable.cutin_win_adv_02, R.drawable.cutin_win_adv_03,
        R.drawable.cutin_win_adv_04, R.drawable.cutin_win_adv_05, R.drawable.cutin_win_adv_06,
        R.drawable.cutin_win_adv_07, R.drawable.cutin_win_adv_08, R.drawable.cutin_win_adv_09,
        R.drawable.cutin_win_adv_10
    )
    val winFinal = intArrayOf(
        R.drawable.cutin_win_final_01, R.drawable.cutin_win_final_02, R.drawable.cutin_win_final_03,
        R.drawable.cutin_win_final_04, R.drawable.cutin_win_final_05, R.drawable.cutin_win_final_06,
        R.drawable.cutin_win_final_07, R.drawable.cutin_win_final_08, R.drawable.cutin_win_final_09,
        R.drawable.cutin_win_final_10
    )
    val loseAdv = intArrayOf(
        R.drawable.cutin_lose_adv_01, R.drawable.cutin_lose_adv_02, R.drawable.cutin_lose_adv_03,
        R.drawable.cutin_lose_adv_04, R.drawable.cutin_lose_adv_05, R.drawable.cutin_lose_adv_06,
        R.drawable.cutin_lose_adv_07, R.drawable.cutin_lose_adv_08, R.drawable.cutin_lose_adv_09,
        R.drawable.cutin_lose_adv_10
    )
    val loseFinal = intArrayOf(
        R.drawable.cutin_lose_final_01, R.drawable.cutin_lose_final_02, R.drawable.cutin_lose_final_03,
        R.drawable.cutin_lose_final_04, R.drawable.cutin_lose_final_05, R.drawable.cutin_lose_final_06,
        R.drawable.cutin_lose_final_07, R.drawable.cutin_lose_final_08, R.drawable.cutin_lose_final_09,
        R.drawable.cutin_lose_final_10
    )
    val winAdv1m = intArrayOf(
        R.drawable.cutin_win_adv_1m_01, R.drawable.cutin_win_adv_1m_02, R.drawable.cutin_win_adv_1m_03,
        R.drawable.cutin_win_adv_1m_04, R.drawable.cutin_win_adv_1m_05, R.drawable.cutin_win_adv_1m_06,
        R.drawable.cutin_win_adv_1m_07, R.drawable.cutin_win_adv_1m_08, R.drawable.cutin_win_adv_1m_09,
        R.drawable.cutin_win_adv_1m_10
    )
    val loseAdv1m = intArrayOf(
        R.drawable.cutin_lose_adv_1m_01, R.drawable.cutin_lose_adv_1m_02, R.drawable.cutin_lose_adv_1m_03,
        R.drawable.cutin_lose_adv_1m_04, R.drawable.cutin_lose_adv_1m_05, R.drawable.cutin_lose_adv_1m_06,
        R.drawable.cutin_lose_adv_1m_07, R.drawable.cutin_lose_adv_1m_08, R.drawable.cutin_lose_adv_1m_09,
        R.drawable.cutin_lose_adv_1m_10
    )
    return when (kind) {
        CutInKind.WIN_ADVANTAGE -> if (oneMinuteAdvantage) winAdv1m[i] else winAdv[i]
        CutInKind.LOSE_ADVANTAGE -> if (oneMinuteAdvantage) loseAdv1m[i] else loseAdv[i]
        CutInKind.WIN_FINAL -> winFinal[i]
        CutInKind.LOSE_FINAL -> loseFinal[i]
    }
}

private fun stableCutInSlot(scanId: String, instrument: String): Int {
    val hash = (scanId.ifBlank { instrument }).hashCode()
    return Math.floorMod(hash, 10) + 1
}

@Composable
internal fun CutInOverlay(
    state: GmkUiState,
    controller: CutInEventQueue,
    onShown: (String, String, String) -> Unit,
    onSuppressed: (String, String, String) -> Unit
) {
    if (!state.cutInEnabled) return
    val lifecycle = (LocalContext.current as? androidx.lifecycle.LifecycleOwner)?.lifecycle
    var foreground by remember(lifecycle) {
        mutableStateOf(lifecycle == null || lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED))
    }
    DisposableEffect(lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, _ ->
            foreground = lifecycle == null || lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }
    var current by remember { mutableStateOf<CutInDisplay?>(null) }
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            delay(250)
        }
    }
    LaunchedEffect(nowMs, state.history, state.rates, state.cutInEnabled, foreground) {
        val at = System.currentTimeMillis()
        val suppressed = CutInPolicy.observeEvents(controller, state.history, state.rates, at, state.cutInEnabled)
        // Coroutines can keep running while an Activity is stopped. Queue results, but
        // never consume/mark them as shown until a visible screen can display them.
        if (!foreground) {
            current = null
            return@LaunchedEffect
        }
        val tick = controller.advance(at, android.os.SystemClock.elapsedRealtime())
        current = tick.current?.let { event -> CutInDisplay(event.key, event.scanId, event.instrument,
            event.kind, stableCutInSlot(event.scanId, event.instrument), event.oneMinuteAdvantage) }
        tick.started?.let { onShown(it.kind.name, it.scanId, it.instrument) }
        suppressed.firstOrNull()?.let { onSuppressed(it.reason, it.scanId, it.instrument) }
    }

    AnimatedVisibility(
        visible = current != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it / 3 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it / 3 })
    ) {
        current?.let { cut ->
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.18f))
                    .clickable { controller.dismiss(); current = null },
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(0.96f),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF070A12))
                ) {
                    Column {
                        // Every asset is rebuilt to exactly 16:5. Fit + explicit aspect ratio means
                        // character faces, labels, and countdowns can never be cropped by the container.
                        Image(
                            painter = painterResource(cutInDrawable(cut.kind, cut.slot, cut.oneMinuteAdvantage)),
                            contentDescription = "GMK ${cut.kind.name} cut-in",
                            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 5f),
                            contentScale = ContentScale.Fit
                        )
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Color(0xF211131C))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                when (cut.kind) {
                                    CutInKind.WIN_ADVANTAGE -> "勝ち優勢"
                                    CutInKind.LOSE_ADVANTAGE -> "負け優勢"
                                    CutInKind.WIN_FINAL -> "WIN"
                                    CutInKind.LOSE_FINAL -> "LOSE"
                                },
                                color = when (cut.kind) {
                                    CutInKind.WIN_ADVANTAGE, CutInKind.WIN_FINAL -> Color(0xFF71E3A6)
                                    else -> Color(0xFFFF7A8C)
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(cut.instrument, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(Modifier.weight(1f))
                            Text("GMK MOBILE", color = Color.LightGray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LocalOnlyStrip() {
    Row(
        Modifier.fillMaxWidth().background(Color(0xCC101D3B)).padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("✦ 端末単体版", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ScanCyan)
        Spacer(Modifier.width(8.dp))
        Text("判定・履歴はスマホ内 / クラウド不要", fontSize = 10.sp, color = ScanMuted)
    }
}

@Composable
private fun StatusStrip(state: GmkUiState) {
    val allLive = state.rateLiveCount == 6
    val edge = if (allLive) ScanCyan else ScanPink
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .border(1.dp, edge.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
            .background(ScanPanel, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                when {
                    allLive -> "● 6/6 LIVE"
                    state.rateAvailableCount > 0 -> "● LIVE ${state.rateLiveCount}/6  取得 ${state.rateAvailableCount}/6"
                    else -> "● レート取得待機"
                },
                fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = if (allLive) ScanGreen else Color(0xFFFF8DA8)
            )
            Spacer(Modifier.weight(1f))
            if (state.scannableCount > 0) {
                Text("判定可能 ${state.scannableCount}/6", fontSize = 10.sp, color = ScanMuted)
            }
        }
        state.rateStatus?.let { Text(it.take(180), fontSize = 10.sp, color = Color(0xFFFFA7B8), maxLines = 2) }
        state.scanStatus?.let { Text(it.take(220), fontSize = 10.sp, color = ScanText, maxLines = 3) }
        state.outcomeStatus?.let { Text(it.take(220), fontSize = 10.sp, color = ScanGreen, maxLines = 2) }
        state.error?.let { Text(it.take(180), fontSize = 10.sp, color = Color(0xFFFF728F), maxLines = 2) }
    }
}

/** v0.7.54: when the next time-of-day rule (the only S/A source) applies. */
@Composable
private fun NextRuleLine() {
    var now by remember { mutableStateOf(ZonedDateTime.now(ZoneId.of("Asia/Tokyo"))) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); now = ZonedDateTime.now(ZoneId.of("Asia/Tokyo")) } }
    val text = remember(now.hour, now.minute) { SignalAlerts.nextRuleText(now) }
    Text(text, Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp), color = ScanGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun ModePanel(auto: Boolean, fixedThreeMinute: Boolean, onAuto: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)
            .border(1.dp, ScanPurple.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .background(ScanPanel2, RoundedCornerShape(12.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // v0.7.67: what the AUTO really does (the old chips showed a fixed "3分" and an unused "1分")
        Column(Modifier.weight(1f)) {
            Text("判定", fontWeight = FontWeight.Bold, color = ScanText)
            Text(jp.gmk.mobile.domain.AutoClock.scheduleText(ZonedDateTime.now(ZoneId.of("Asia/Tokyo"))), fontSize = 11.sp, color = ScanMuted)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text("AUTO SCAN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = ScanMuted)
            Switch(checked = auto, onCheckedChange = onAuto)
        }
    }
}


@Composable
private fun CountdownPanel(onScan: () -> Unit, busy: Boolean) {
    var seconds by remember { mutableStateOf(nextScanSeconds()) }
    var slotSeconds by remember { mutableStateOf(nextSlotSeconds()) }
    LaunchedEffect(Unit) { while (true) { seconds = nextScanSeconds(); slotSeconds = nextSlotSeconds(); delay(1000) } }
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Card(
            Modifier.weight(0.9f).border(1.dp, ScanCyan.copy(alpha = .6f), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = ScanPanel)
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(if (jp.gmk.mobile.domain.AutoClock.everyMinute(ZonedDateTime.now(ZoneId.of("Asia/Tokyo")))) "次回AUTOまで（平日は毎分）" else "次回AUTOまで（5分ごと）",
                    fontSize = 11.sp, color = ScanMuted)
                Text(jp.gmk.mobile.domain.AutoClock.countdownText(seconds), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = ScanCyan)
                Text("次の5分枠まで " + jp.gmk.mobile.domain.AutoClock.countdownText(slotSeconds), fontSize = 11.sp, color = ScanMuted)
            }
        }
        Spacer(Modifier.width(8.dp))
        Button(
            onClick = onScan, enabled = !busy,
            modifier = Modifier.weight(1.35f).height(78.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(12.dp)
        ) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(listOf(Color(0xFFDA2367), Color(0xFF7B3BFF))), RoundedCornerShape(12.dp)
                ).border(1.dp, Color(0xFFFFB5DA), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (busy) "スキャン中…" else "▶ スキャン開始", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

private fun nextScanSeconds(): Int = jp.gmk.mobile.domain.AutoClock.nextAutoScanSeconds(ZonedDateTime.now(ZoneId.of("Asia/Tokyo")))
private fun nextSlotSeconds(): Int = jp.gmk.mobile.domain.AutoClock.nextSlotScanSeconds(ZonedDateTime.now(ZoneId.of("Asia/Tokyo")))

@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun Top1Card(top: ScanCandidate?, coverageCount: Int, minutes: Int) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            .border(1.dp, Color(0xFFFFB04A), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xE3151C36))
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF7C2757), Color(0xFF2E4D91)))).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (coverageCount in 1..5) "✦ TOP1（部分 ${coverageCount}/6）" else "✦ TOP1", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            if (top == null) {
                Text("まだスキャン結果がありません", Modifier.padding(18.dp), color = ScanMuted)
            } else {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(top.instrument, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ScanText, maxLines = 1, softWrap = false)
                        DirectionBox(top.direction)
                        JudgeBadge(minutes, large = true)
                        Text(top.decision, color = if (top.decision == "ENTRY") ScanGreen else ScanMuted, fontWeight = FontWeight.Bold)
                    }
                    if (top.decision == "ENTRY") Text("ザオプションで「${minutes}分」を選んでエントリー", color = if (minutes == 5) Color(0xFF14B8A6) else Color(0xFFFF8A3D),
                        fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("${if(top.grade=="R") "追加判定" else "運用等級 ${top.grade}"}  •  ${minutes}分判定  •  ${top.regime}", color = Color(0xFFFFC76A), fontWeight = FontWeight.Bold)
                    val currentLabel = top.assessment?.correctionLabel
                    if (currentLabel != null) {
                        // v0.7.50: the operational grade and its own reason only (legacy rule grade / similarity rank /
                        // legacy rule statistics belong to retired engines and contradicted the grade above).
                        Text(currentLabel, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ScanCyan)
                    } else {
                    Text(if (top.chartRankLabel == null) "元ルール ${top.legacyRuleGrade} • 推定強度: ${top.strengthLabel}" else "元ルール ${top.legacyRuleGrade}", fontSize = 11.sp, color = ScanMuted)
                    top.chartRankLabel?.let { Text(it, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = ScanCyan) }
                    top.assessment?.chartRank?.let {
                        Text(it.evidenceLabel, fontSize = 10.sp, color = ScanMuted)
                        if (it.grade == "UNRANKED") Text("保留理由: ${it.statusReasonLabel}", fontSize = 10.sp, color = ScanMuted)
                    }
                    if (top.decision == "SKIP") Text("見送り: ${top.skipReasonLabel}", fontSize = 11.sp, color = ScanMuted)
                    Text(top.historicalRateLabel, fontSize = 10.sp, color = ScanMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        "✦ $text",
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp)
            .background(Brush.horizontalGradient(listOf(Color(0xFF351546), Color(0xFF123B65))), RoundedCornerShape(8.dp))
            .padding(horizontal = 13.dp, vertical = 8.dp),
        color = Color.White, fontWeight = FontWeight.Bold
    )
}

@Composable
private fun ResultRow(c: ScanCandidate, rate: RateRow?, evidenceScan: Boolean = false) {
    val reference = evidenceScan && c.rank != 1
    val high = c.direction.uppercase() == "HIGH"
    val accent = if (high) ScanPink else ScanCyan
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .border(1.dp, accent.copy(alpha = if (c.rank == 1) .95f else .45f), RoundedCornerShape(10.dp))
            .background(if (c.rank == 1) Color(0xE2311834) else Color(0xD913213D), RoundedCornerShape(10.dp))
            .padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(30.dp).background(Color(0xFF182A4B), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Text("${c.rank}", fontWeight = FontWeight.Bold, color = Color(0xFFFFD16C))
        }
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(c.instrument, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = ScanText)
                if (evidenceScan && c.rank == 1) { Spacer(Modifier.width(6.dp)); JudgeBadge(c.assessment?.chosenAction?.judgeMinutes ?: 3) }
            }
            Text(rate?.price?.let(::formatPrice) ?: "—", fontSize = 11.sp, color = ScanMuted)
            Text("${c.regime} ${(c.regimeConfidence * 100).toInt()}%", fontSize = 10.sp, color = ScanMuted)
            if (reference) {
                Text("参考（判定は1位だけ）", fontSize = 10.sp, color = ScanMuted)
            } else if (evidenceScan) {
                c.assessment?.correctionLabel?.let { Text(it, fontSize = 10.sp, color = ScanCyan) }
            } else {
            Text(if (c.chartRankLabel == null) "元ルール ${c.legacyRuleGrade} • 強度: ${c.strengthLabel}" else "元ルール ${c.legacyRuleGrade}", fontSize = 10.sp, color = ScanMuted)
            c.chartRankLabel?.let { Text(it, fontSize = 10.sp, color = ScanCyan) }
            if (c.decision == "SKIP") Text(c.skipReasonLabel, fontSize = 10.sp, color = ScanMuted)
            }
        }
        DirectionBox(c.direction)
        Spacer(Modifier.width(8.dp))
        Text(if (reference) "等級\n—" else "等級\n${c.grade}", Modifier.width(34.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFD16C), textAlign = TextAlign.Center)
        val displayDecision = when { c.rank == 1 -> c.decision; reference -> "参考"; c.decision == "ENTRY" -> "候補"; else -> "SKIP" }
        Text(displayDecision, Modifier.width(48.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold,
            color = if (c.rank == 1 && c.decision == "ENTRY") ScanGreen else ScanMuted, textAlign = TextAlign.End)
    }
}

@Composable
private fun RateOnlyRow(r: RateRow) {
    val status = when {
        r.price == null -> "UNAVAILABLE"
        r.freshnessStatus == "LIVE" -> "LIVE"
        r.freshnessStatus == "LAST" -> "LAST"
        else -> r.freshnessStatus
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .border(1.dp, Color(0x5535D9FF), RoundedCornerShape(10.dp))
            .background(Color(0xD913213D), RoundedCornerShape(10.dp)).padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(r.instrument, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = ScanText)
        Column(horizontalAlignment = Alignment.End) {
            Text(r.price?.let(::formatPrice) ?: "—", fontWeight = FontWeight.Bold, color = ScanText)
            val ageLabel = r.ageSeconds?.let { " ${it.toInt()}s" } ?: ""
            Text("$status$ageLabel ${r.source}", fontSize = 10.sp,
                color = when (status) { "LIVE" -> ScanGreen; "LAST" -> Color(0xFFFFC76A); else -> Color(0xFFFF728F) })
        }
    }
}

/** v0.7.57: judgement length badge - theoption's expiry must match it (3分 orange, 5分 teal, never colour alone: the text says it). */
@Composable
internal fun JudgeBadge(minutes: Int, large: Boolean = false) {
    val color = when (minutes) { 5 -> Color(0xFF14B8A6); 3 -> Color(0xFFFF8A3D); 1 -> Color(0xFF8E8E9E); else -> Color(0xFFB07CFF) }
    Surface(color = color, shape = RoundedCornerShape(8.dp)) {
        Text("${minutes}分判定", Modifier.padding(horizontal = if (large) 12.dp else 7.dp, vertical = if (large) 7.dp else 3.dp),
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (large) 17.sp else 11.sp, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun DirectionBox(direction: String) {
    val normalized = direction.uppercase()
    val (label, color) = when (normalized) {
        "HIGH" -> "▲ HIGH" to ScanPink
        "LOW" -> "▼ LOW" to Color(0xFF2E8DFF)
        else -> "—" to Color.Gray
    }
    Surface(color = color.copy(alpha = .92f), shape = RoundedCornerShape(8.dp)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun formatJstTime(iso: String): String {
    if (iso.isBlank()) return "—"
    return runCatching {
        ZonedDateTime.parse(iso)
            .withZoneSameInstant(ZoneId.of("Asia/Tokyo"))
            .format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"))
    }.getOrElse { "—" }
}

private fun formatPrice(x: Double): String = if (x >= 100000) "%,.0f".format(x) else if (x >= 100) "%.3f".format(x) else "%.5f".format(x)

@Composable
private fun RecentHistoryPreview(rows: List<HistoryRow>) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp)) {
        Text("直近の予測結果", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))

        if (rows.isEmpty()) {
            Text("まだ結果はありません。", fontSize = 11.sp, color = Color.Gray)
        } else {
            rows.take(5).forEach { h ->
                val resultColor = if (h.decision == "SKIP") Color.Gray else when (h.resultStatus) {
                    "WIN" -> Color(0xFF2E7D32)
                    "LOSE" -> Wine
                    else -> Color.Gray
                }
                Row(
                    Modifier.fillMaxWidth()
                        .background(Paper2)
                        .padding(horizontal = 8.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(h.instrument, Modifier.width(72.dp), fontWeight = FontWeight.Bold)
                    Text(
                        h.direction,
                        Modifier.width(50.dp),
                        color = if (h.direction == "HIGH") High else Low,
                        fontWeight = FontWeight.Bold
                    )
                    Text(h.source, Modifier.width(64.dp), fontSize = 10.sp, color = Color.Gray)
                    if (RankStatistics.evidenceVersion(h.policyVersion) != null) JudgeBadge(expiryMinutes(h.entryTimeJst, h.judgeTimeJst, 3))
                    Spacer(Modifier.weight(1f))
                    Text(
                        if (h.decision == "SKIP") "SKIP" else when (h.resultStatus) {
                            "WIN" -> "WIN"
                            "LOSE" -> "LOSE"
                            "WAIT_ENTRY" -> "ENTRY待ち"
                             "WAIT_JUDGE" -> "${expiryMinutes(h.entryTimeJst,h.judgeTimeJst,if(h.source.contains("1M"))1 else 3)}分判定待ち"
                            "ENTRY_RATE_MISSED" -> "ENTRY取得失敗"
                            "JUDGE_RATE_MISSED" -> "判定取得失敗"
                            "INVALID_RATE_DATA" -> "保存レート異常・集計除外"
                            "INVALID_TIMING_DATA" -> "保存時刻異常・追跡除外"
                            "LEGACY_NO_OUTCOME" -> "旧履歴"
                            else -> h.resultStatus
                        },
                        color = resultColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
                h.chartRankLabel?.let { Text(it, fontSize = 10.sp, color = Ink) }
            }
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun HistoryScreen(rows: List<HistoryRow>, fixedThreeMinute: Boolean, onOpenChart: (HistoryRow) -> Unit) {
    var nowMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val hasPendingJudge = rows.any { it.resultStatus == "WAIT_JUDGE" }
    LaunchedEffect(hasPendingJudge) {
        if (hasPendingJudge) while (true) { nowMs = System.currentTimeMillis(); delay(1000) }
    }
    var includeLegacy by rememberSaveable { mutableStateOf(false) }
    var chartRankFilter by rememberSaveable { mutableStateOf("すべて") }
    var rankFilter by rememberSaveable { mutableStateOf("すべて") }
    val hasLegacyChartRanks = remember(rows) { rows.any { it.assessment?.chartRank != null } }
    val visibleRows = remember(rows, chartRankFilter, rankFilter) {
        rows.filter { ChartRankDisplay.matches(it.assessment, chartRankFilter) && RankFilter.matches(it, rankFilter) }
    }
    val counted = remember(rows, fixedThreeMinute, includeLegacy) {
        rows.filter { ExpiryProfiles.includes(it, fixedThreeMinute, includeLegacy) }
    }
    val stats = remember(counted) { historyStatistics(counted) }
    val combined = remember(counted) { historyCombinedStatistics(counted) }
    val threeRows = remember(counted) { counted.filter { it.statisticsRow().minutes() == 3 } }
    val oneRows = remember(counted) { counted.filter { it.statisticsRow().minutes() == 1 } }
    // v0.7.54: the 1-minute board is observation only; its tile shows the "if entered" result of those rows.
    val oneObserved = remember(counted) { counted.filter { OneMinuteObservation.isObservation(it.policyVersion) } }
    fun summary(minutes: Int): String {
        val s = stats.getValue(minutes)
        val wr = s.winRate()
        if (minutes == 1 && oneObserved.isNotEmpty()) {
            val w = oneObserved.count { it.resultStatus == "WIN" }; val l = oneObserved.count { it.resultStatus == "LOSE" }
            return "参考のみ（見送り）\n入っていたら ${w}勝 ${l}敗" + (if (w + l > 0) "\n${"%.1f".format(100.0 * w / (w + l))}%" else "")
        }
        return if (wr == null) "確定なし" else "${s.wins}勝 ${s.losses}敗\n${"%.2f".format(wr)}%\n最大${s.maxConsecutiveLosses}連敗"
    }

    Box(Modifier.fillMaxSize().background(ScanBg)) {
        Image(
            painter = painterResource(R.drawable.history_gensokyo_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alpha = 0.58f
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x44120A2A),
                        Color(0xAA07142A),
                        Color(0xE8071020)
                    )
                )
            )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            item(key = "summary") {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xAA1A0D36), Color(0x6610162A))))
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "予測結果一覧",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "— 幻想の相場に、弾を放て —",
                            fontSize = 11.sp,
                            color = Color(0xFFDFB8FF)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("博麗神社", color = ScanPink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("GMK MOBILE", color = ScanMuted, fontSize = 9.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "3分判定",
                        value = summary(3),
                        accent = ScanPink,
                        icon = "✿"
                    )
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "1分判定",
                        value = summary(1),
                        accent = ScanCyan,
                        icon = "☯"
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "10分判定",
                        value = summary(10),
                        accent = ScanPurple,
                        icon = "✦"
                    )
                    HistorySummaryTile(
                        modifier = Modifier.weight(1f),
                        title = "15分判定",
                        value = summary(15),
                        accent = ScanPurple,
                        icon = "✦"
                    )
                }
                Spacer(Modifier.height(6.dp))
                HistorySummaryTile(modifier = Modifier.fillMaxWidth(), title = "5分判定", value = summary(5), accent = ScanPink, icon = "✿")
                val three = stats.getValue(3)
                Text("3分: 最大${three.maxConsecutiveLosses}連敗・現在${three.currentLossStreak}連敗（全判定 最大${combined.maxConsecutiveLosses}・現在${combined.currentLossStreak}）", color = ScanText, fontSize = 12.sp)
                Text("3連敗以上${combined.runsAtLeast3}回・5連敗以上${combined.runsAtLeast5}回。SKIP・未確定・取得失敗で連敗をリセットしません。", color = ScanMuted, fontSize = 10.sp)
                Text("SKIP ${stats.values.sumOf { it.skips }}件・判定待ち ${stats.values.sumOf { it.pending }}件・取得失敗 ${stats.values.sumOf { it.missed }}件は勝率対象外。同値は負け。", color = ScanMuted, fontSize = 10.sp)
                if (stats.getValue(0).resolved() > 0) Text("判定時刻不明 ${stats.getValue(0).resolved()}件は上の勝率に含めません。", color = ScanMuted, fontSize = 9.sp)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (includeLegacy) "集計: 全バージョン" else "集計: 更新後（3分の運用等級＋1分ボード）", color = ScanText, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = { includeLegacy = !includeLegacy }) { Text(if (includeLegacy) "更新後に戻す" else "旧履歴も含める", fontSize = 11.sp) }
                }
                Spacer(Modifier.height(8.dp))
                RankStatsPanel(rows)
                Spacer(Modifier.height(6.dp))
                Text("一覧の運用等級で絞り込み（上の集計は変わりません）", color = ScanMuted, fontSize = 9.sp)
                RankFilterChips(rows, rankFilter) { rankFilter = it }
                if (hasLegacyChartRanks) {
                    Text("旧・類似ランク（v0.7.42〜43の記録だけ。今の運用等級とは別物）", color = ScanMuted, fontSize = 9.sp)
                    ChartRankFilterChips(rows, chartRankFilter) { chartRankFilter = it }
                }
            }

            }
            if (rows.isEmpty()) {
                item(key = "empty") {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Card(
                        modifier = Modifier.padding(22.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xDD101B34)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x669E6CFF))
                    ) {
                        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("履歴はまだありません", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "3・5・10・15分/1分のENTRYと判定結果が、ここに幻想郷風カードで記録されます。",
                                color = ScanMuted,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                }
            } else if (visibleRows.isEmpty()) {
                item(key = "empty-chart-rank-filter") { Text("絞り込み（運用等級 $rankFilter / 類似ランク $chartRankFilter）に当てはまる履歴はありません", Modifier.padding(16.dp), color = ScanMuted, fontSize = 12.sp) }
            } else {
                    items(visibleRows) { h ->
                        val isWin = h.decision == "ENTRY" && h.resultStatus == "WIN"
                        val isLose = h.decision == "ENTRY" && h.resultStatus == "LOSE"
                        val isWaiting = h.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
                        val statusColor = when {
                            isWin -> ScanGreen
                            isLose -> Color(0xFFFF4F73)
                            isWaiting -> ScanPurple
                            h.resultStatus.contains("MISSED") || h.resultStatus.contains("MISSING") || h.resultStatus in setOf("INVALID_RATE_DATA", "INVALID_TIMING_DATA") -> Color(0xFFFFB84F)
                            else -> ScanMuted
                        }
                        val directionColor = if (h.direction == "HIGH") ScanPink else ScanCyan
                        val cardTop = when {
                            isWin -> Color(0xDD24102A)
                            isLose -> Color(0xDD251026)
                            else -> Color(0xDD0B2140)
                        }
                        val cardBottom = Color(0xEE081329)
                        val statusText = if (h.decision == "SKIP") {
                            if (h.resultStatus in setOf("WIN", "LOSE")) "SKIP（入っていたら ${h.resultStatus}）"
                            else if (isWaiting) "SKIP（観察中）" else "SKIP"
                        } else if (isLose && h.entryRate != null && h.entryRate == h.judgeRate) {
                            "⚔ LOSE（同値）"
                        } else when (h.resultStatus) {
                            "WIN" -> "✿  WIN"
                            "LOSE" -> "⚔  LOSE"
                            "WAIT_ENTRY" -> "⌛ ENTRY待ち"
                            "WAIT_JUDGE" -> if (runCatching { ZonedDateTime.parse(h.judgeTimeJst).toInstant().toEpochMilli() <= nowMs }.getOrDefault(false)) {
                                if (h.source == "MANUAL") "⌛ 判定時刻到達・対象秒レート取得中" else "⌛ 判定時刻到達・対象分OPEN配信待ち"
                            } else "⌛ ${expiryMinutes(h.entryTimeJst,h.judgeTimeJst,if(h.source.contains("1M"))1 else 3)}分判定待ち"
                            "ENTRY_RATE_MISSED" -> "⚠ ENTRY取得失敗"
                            "JUDGE_RATE_MISSED" -> "⚠ 判定取得失敗"
                            "ENTRY_RATE_MISSING" -> "⚠ ENTRY不明"
                            "INVALID_RATE_DATA" -> "⚠ 保存レート異常・集計除外"
                            "INVALID_TIMING_DATA" -> "⚠ 保存時刻異常・追跡除外"
                            "LEGACY_NO_OUTCOME" -> "旧履歴・結果なし"
                            else -> if (h.decision == "SKIP" && h.resultStatus in setOf("WIN", "LOSE")) {
                                "SKIP参考 ${h.resultStatus}"
                            } else h.resultStatus
                        }

                        Box(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp)
                                .border(1.dp, statusColor.copy(alpha = 0.72f), RoundedCornerShape(14.dp))
                                .background(Brush.verticalGradient(listOf(cardTop, cardBottom)), RoundedCornerShape(14.dp))
                                .clickable { onOpenChart(h) }
                        ) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(34.dp)
                                            .background(directionColor.copy(alpha = 0.18f), RoundedCornerShape(17.dp))
                                            .border(1.dp, directionColor.copy(alpha = 0.75f), RoundedCornerShape(17.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(if (h.instrument == "BTCJPY") "₿" else if (h.direction == "HIGH") "↗" else "↘", color = directionColor, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.width(9.dp))
                                    Column(Modifier.weight(1f)) {
                                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text(h.instrument, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                                            if (RankStatistics.evidenceVersion(h.policyVersion) != null)
                                                JudgeBadge(expiryMinutes(h.entryTimeJst, h.judgeTimeJst, 3))
                                            Text(
                                                h.direction,
                                                color = directionColor,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                maxLines = 1,
                                                softWrap = false,
                                                modifier = Modifier
                                                    .background(directionColor.copy(alpha = 0.14f), RoundedCornerShape(6.dp))
                                                    .border(1.dp, directionColor.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                            Text(
                                                statusText,
                                                color = statusColor,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                modifier = Modifier
                                                    .background(statusColor.copy(alpha = 0.10f), RoundedCornerShape(8.dp))
                                                    .border(1.dp, statusColor.copy(alpha = 0.72f), RoundedCornerShape(8.dp))
                                                    .padding(horizontal = 9.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                                Text("${h.source} / 運用等級 ${h.grade} / ${h.regime}\n${h.policyVersion}", fontSize = 10.sp, color = ScanMuted)
                                if (RankStatistics.evidenceVersion(h.policyVersion) != null) {
                                    // v0.7.50: current 3-minute rows show only the operational grade's own reason.
                                    h.assessment?.correctionLabel?.let { Text(it, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ScanCyan) }
                                    if (ObservationPolicy.tracks(h)) Text("見送りの観察: 入っていたらの結果を記録（勝率・連敗には入りません）", fontSize = 9.sp, color = ScanMuted)
                                } else if (RankStatistics.isOneMinute(h)) {
                                    Text("1分ボード（簡易ルール・検証なし）の等級 ${h.grade}。3分の運用等級とは別物です。", fontSize = 10.sp, color = ScanMuted)
                                } else {
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("元ルール ${h.legacyRuleGrade}", fontSize = 10.sp, color = ScanMuted)
                                    if (h.chartRankLabel == null) Text("強度: ${h.strengthLabel}", fontSize = 10.sp, color = ScanMuted)
                                }
                                h.chartRankLabel?.let { Text(it, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = ScanCyan) }
                                h.assessment?.chartRank?.let {
                                    Text(it.evidenceLabel, fontSize = 9.sp, color = ScanMuted)
                                    if (it.grade == "UNRANKED") Text("保留理由: ${it.statusReasonLabel}", fontSize = 9.sp, color = ScanMuted)
                                }
                                if (h.decision == "SKIP") Text("見送り: ${h.skipReasonLabel}", fontSize = 10.sp, color = ScanMuted)
                                h.assessment?.correctionLabel?.let { Text("補正: $it", fontSize = 10.sp, color = ScanMuted) }
                                }

                                Spacer(Modifier.height(9.dp))
                                Box(Modifier.fillMaxWidth().height(1.dp).background(statusColor.copy(alpha = 0.20f)))
                                Spacer(Modifier.height(8.dp))

                                Text("スキャン  ${formatJstTime(h.atJst)}", fontSize = 10.sp, color = ScanMuted)
                                Text(
                                    "ENTRY・市場参考  ${formatJstTime(h.entryTimeJst)}  ${h.entryRate?.let(::formatPrice) ?: "—"}",
                                    fontSize = 11.sp,
                                    color = ScanText
                                )
                                Text(
                                    "${expiryMinutes(h.entryTimeJst,h.judgeTimeJst,if(h.source.contains("1M"))1 else 3)}分後・市場参考  ${formatJstTime(h.judgeTimeJst)}  ${h.judgeRate?.let(::formatPrice) ?: "—"}",
                                    fontSize = 11.sp,
                                    color = ScanText
                                )

                                if (h.entryRateSource.isNotBlank() || h.judgeRateSource.isNotBlank()) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(
                                        "ENTRY: ${h.entryRateSource.ifBlank { "—" }} / 判定: ${h.judgeRateSource.ifBlank { "—" }}",
                                        fontSize = 8.sp,
                                        color = Color(0xFF8FA6C7)
                                    )
                                    Text(
                                        "取得遅延 ENTRY=${h.entryCaptureDelayMs?.let { "${it}ms" } ?: "—"} / 判定=${h.judgeCaptureDelayMs?.let { "${it}ms" } ?: "—"}  " +
                                            "${if (h.entryRateSource.contains("1mopen",true)) "対象分OPENの配信待ち" else "provider age"} ENTRY=${h.entryProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"} / 判定=${h.judgeProviderAgeSeconds?.let { "%.1fs".format(it) } ?: "—"}",
                                        fontSize = 8.sp,
                                        color = Color(0xFF7186A7)
                                    )
                                }
                                if (isWin || isLose) {
                                    Spacer(Modifier.height(8.dp))
                                    Image(
                                        painter = painterResource(if (isWin) R.drawable.history_reimu_win else R.drawable.history_youmu_lose),
                                        contentDescription = null,
                                        modifier = Modifier.align(Alignment.End)
                                            .width(if (isWin) 118.dp else 145.dp)
                                            .height(if (isWin) 118.dp else 105.dp)
                                            .testTag("history-result-art-${h.id}"),
                                        contentScale = ContentScale.Crop,
                                        alpha = if (isWin) 0.82f else 0.78f
                                    )
                                }
                            }
                        }
                    }
            }
        }
    }
}

/** v0.7.50: results by operational grade (3-minute per version and weekday/weekend; the 1-minute board apart). */
@Composable
internal fun RankStatsPanel(rows: List<HistoryRow>) {
    val tables = remember(rows) { RankStatistics.tables(rows) }
    Column(Modifier.fillMaxWidth()) {
        Text("運用等級別の結果", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        if (tables.isEmpty()) Text("まだ等級つきの記録がありません", color = ScanMuted, fontSize = 10.sp)
        tables.forEach { table ->
            Spacer(Modifier.height(4.dp))
            Text(table.title, color = Color(0xFFFFC76A), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            table.counts.forEach { count ->
                Text(RankStatistics.lineText(table, count), color = ScanText, fontSize = 10.sp)
            }
        }
        val share = remember(rows) { RankStatistics.entryShareText(rows) }
        if (share.isNotEmpty()) Text("ENTRYの割合（今のバージョン・自動・5分の区切りあたり）: $share", color = ScanText, fontSize = 10.sp)
        Spacer(Modifier.height(4.dp))
        Text(RankStatistics.NOTE, color = ScanMuted, fontSize = 9.sp)
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun RankFilterChips(rows: List<HistoryRow>, selected: String, onSelect: (String) -> Unit) {
    val counts = remember(rows) { RankFilter.filters.associateWith { label -> rows.count { RankFilter.matches(it, label) } } }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
        RankFilter.filters.forEach { label ->
            val count = counts.getValue(label)
            FilterChip(selected = selected == label, onClick = { onSelect(label) },
                modifier = Modifier.testTag("rank-filter-$label"),
                label = { Text("$label ($count)", fontSize = 10.sp) })
        }
    }
}

@Composable
@OptIn(ExperimentalLayoutApi::class)
internal fun ChartRankFilterChips(rows: List<HistoryRow>, selected: String, onSelect: (String) -> Unit) {
    val counts = remember(rows) { ChartRankDisplay.filters.associateWith { label ->
        rows.count { ChartRankDisplay.matches(it.assessment, label) }
    } }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
        ChartRankDisplay.filters.forEach { label ->
            val count = counts.getValue(label)
            FilterChip(selected = selected == label, onClick = { onSelect(label) },
                modifier = Modifier.testTag("chart-rank-filter-$label"),
                label = { Text("$label ($count)", fontSize = 10.sp) })
        }
    }
}

@Composable
private fun HistorySummaryTile(
    modifier: Modifier,
    title: String,
    value: String,
    accent: Color,
    icon: String
) {
    Column(
        modifier
            .border(1.dp, accent.copy(alpha = 0.72f), RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.14f), Color(0xCC09142B))
                ),
                RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 7.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, color = accent, fontSize = 17.sp)
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(value, color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun BottomBar(tab: Tab, select: (Tab) -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A1022), Color(0xFF26102B), Color(0xFF0A1022))))
            .windowInsetsPadding(WindowInsets.navigationBars).height(66.dp)
            .border(1.dp, Color(0x55FF4F91))
    ) {
        BottomItem("✿", "予測", tab == Tab.Prediction) { select(Tab.Prediction) }
        BottomItem("⌁", "チャート", tab == Tab.Chart) { select(Tab.Chart) }
        BottomItem("◉", "通貨強弱", tab == Tab.Strength) { select(Tab.Strength) }
        BottomItem("▤", "履歴", tab == Tab.History) { select(Tab.History) }
        BottomItem("≡", "状態", tab == Tab.Status) { select(Tab.Status) }
    }
}

@Composable
private fun RowScope.BottomItem(icon: String, text: String, active: Boolean, click: () -> Unit) {
    Column(
        Modifier.weight(1f).fillMaxHeight().clickable(onClick = click)
            .background(if (active) Brush.verticalGradient(listOf(Color(0x884F173E), Color(0xAA9C1E53))) else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, color = if (active) Color(0xFFFFB6D0) else Color.White, fontSize = 22.sp)
        Text(text, color = Color.White, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp, maxLines = 1)
        if (active) Box(Modifier.padding(top = 3.dp).height(3.dp).width(36.dp).background(ScanPink, RoundedCornerShape(2.dp)))
    }
}

internal fun expiryMinutes(entry: String, judge: String, fallback: Int): Int = runCatching {
    java.time.Duration.between(java.time.ZonedDateTime.parse(entry), java.time.ZonedDateTime.parse(judge)).toMinutes().toInt().takeIf { it in setOf(1,3,5,10,15) } ?: fallback
}.getOrDefault(fallback)

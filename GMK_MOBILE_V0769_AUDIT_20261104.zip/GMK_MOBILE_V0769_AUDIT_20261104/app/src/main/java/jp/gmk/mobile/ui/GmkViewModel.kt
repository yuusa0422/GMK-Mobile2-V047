package jp.gmk.mobile.ui

import android.app.Application
import android.content.Intent
import jp.gmk.mobile.runtime.GmkRuntimeKeepAliveService
import jp.gmk.mobile.runtime.GmkRuntimeServiceControl
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import jp.gmk.mobile.BuildConfig
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.AssessmentJsonCodec
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.domain.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import org.json.JSONArray
import org.json.JSONObject


data class GmkUiState(
    val connected: Boolean = false,
    val busy: Boolean = false,
    val error: String? = null,
    val rateStatus: String? = null,
    val scanStatus: String? = null,
    val rates: List<RateRow> = emptyList(),
    val scan: ScanResult? = null,
    val history: List<HistoryRow> = emptyList(),
    val autoScan: Boolean = true,
    val oneMinuteAutoScan: Boolean = false,
    val forceThreeMinuteOutcome: Boolean = false,
    val cutInEnabled: Boolean = true,
    val signalNotify: Boolean = true,
    val notifyMinGrade: String = SignalAlerts.DEFAULT_MIN_GRADE,
    val entryMode: String = EntryMode.DEFAULT.key,
    val oandaToken: String = "",
    val oandaAccountId: String = "",
    val oandaEnvironment: String = "practice",
    val yahooFallback: Boolean = true,
    val lastRateUpdateMs: Long = 0L,
    val lastRateSuccessMs: Long = 0L,
    val lastScanAttemptMs: Long = 0L,
    val lastScanSuccessMs: Long = 0L,
    val modeLabel: String = "端末単体",
    val rateLiveCount: Int = 0,
    val rateAvailableCount: Int = 0,
    val scannableCount: Int = 0,
    val lastScanExcluded: Map<String, String> = emptyMap(),
    val lastCandleErrors: Map<String, String> = emptyMap(),
    val lastCandleLatestMs: Map<String, Long> = emptyMap(),
    val quoteCandleDivergencePct: Map<String, Double> = emptyMap(),
    val oneMinuteBusy: Boolean = false,
    val oneMinuteStatus: String? = null,
    val oneMinuteScan: OneMinuteScanResult? = null,
    val outcomeStatus: String? = null,
    val batteryOptimizationExempt: Boolean = false,
    val backgroundRestricted: Boolean = false,
    val runtimeServiceRunning: Boolean = false,
    val runtimeServiceError: String? = null,
    val cutInShownCount: Int = 0,
    val lastCutInType: String? = null,
    val lastCutInScanId: String? = null,
    val lastCutInInstrument: String? = null,
    val lastCutInAtJst: String? = null,
    val lastCutInSuppressedReason: String? = null,
    val lastCutInSuppressedScanId: String? = null,
    val lastHistoryPublishedMs: Long = 0L,
    val lastSettledHistoryPublishDelayMs: Long? = null,
    val chartCandles: List<Candle> = emptyList(),
    val chartInstrument: String = "EURJPY",
    val chartTimeframe: String = "1m",
    val chartLoading: Boolean = false,
    val chartError: String? = null,
    val chartUpdatedAtMs: Long = 0L,
    val strengthCandles: Map<String, List<Candle>> = emptyMap(),
    val strengthTimeframe: String = "1h",
    val strengthLoading: Boolean = false,
    val strengthErrors: Map<String, String> = emptyMap(),
    val strengthUpdatedAtMs: Long = 0L,
    /** v0.7.64: runs indicator (display only), refreshed from 15-minute candles every 15 minutes. */
    val runRegime: RunRegime.State? = null,
    val runRegimeError: String? = null,
    val networkRequestCount: Long = 0L,
    val networkFailureCount: Long = 0L,
    val networkCancelledCount: Long = 0L,
    val network429Count: Long = 0L,
    val network5xxCount: Long = 0L,
    val lastNetworkError: String? = null
)

class GmkViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    private val historyStore = HistoryStore(app)
    private val repository = MarketRepository(prefs)
    private val outcomeRepository = MarketRepository(prefs)
    private val forexRepository = MarketRepository(prefs,networkTimeoutSeconds=8)
    private val bitcoinRepository = MarketRepository(prefs,networkTimeoutSeconds=8)
    private val bitcoinRealtime = jp.gmk.mobile.data.BitbankRealtimeFeed()
    private val horizonRuntime = jp.gmk.mobile.data.HorizonRuntime(app, MarketRepository(prefs))
    private val ruleEngine = LocalRuleEngine()
    private val oneMinuteEngine = OneMinuteLocalEngine()
    private val jst = ZoneId.of("Asia/Tokyo")

    private val _state = MutableStateFlow(
        GmkUiState(
            history = emptyList(),
            autoScan = prefs.autoScan,
            oneMinuteAutoScan = false,          // v0.7.67: the reference-only 1-minute board is removed
            forceThreeMinuteOutcome = false,    // v0.7.67: the old "3分判定に固定" switch is removed (it did not change judgments)
            cutInEnabled = prefs.cutInEnabled,
            signalNotify = prefs.signalNotify,
            notifyMinGrade = prefs.notifyMinGrade,
            entryMode = prefs.entryMode,
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = prefs.yahooFallback,
            batteryOptimizationExempt = isBatteryOptimizationExempt(app),
            backgroundRestricted = isBackgroundRestricted(app)
        )
    )
    val state: StateFlow<GmkUiState> = _state

    init {
        // v0.7.67: switches that were removed from the screen are turned off for good (a saved ON would keep the 1-minute AUTO running)
        prefs.oneMinuteAutoScan = false
        prefs.forceThreeMinuteOutcome = false
    }

    private var rateJob: Job? = null
    private var bitcoinJob: Job? = null
    private var autoJob: Job? = null
    private var oneMinuteAutoJob: Job? = null
    private var oneMinuteJob: Job? = null
    private var outcomeRecoveryJob: Job? = null
    // v0.7.68: results whose price could not be fetched in time are retried while the app runs (before: only after a restart)
    private var outcomeRepairJob: Job? = null
    private val outcomeRepairAttempts = java.util.concurrent.ConcurrentHashMap<String, Int>()
    private var chartJob: Job? = null
    private var strengthJob: Job? = null
    private var ruleAlertJob: Job? = null
    private val appContext: Application = app
    private val outcomeJobs = mutableMapOf<String, Job>()
    private val outcomeUnexpectedRetryCounts = mutableMapOf<String, Int>()
    // Limit individual network requests only; provider retry waits must release capacity.
    private val outcomeCaptureSemaphore = Semaphore(2)
    val cutInEvents = CutInEventQueue()
    private val MAX_OUTCOME_TRACKING_JOBS = 8
    private val REGIME_FETCH_TIMEOUT_MS = 15_000L
    private val LIVE_REFRESH_RESERVE_MS = 1_800L
    private val LIVE_REFRESH_MAX_MS = 3_000L
    private val LIVE_REFRESH_MIN_MS = 600L
    private var lastAutoBoundaryKey: String? = prefs.lastAutoBoundaryKey.takeIf { it.isNotBlank() }
    private var lastOneMinuteBoundaryKey: String? = prefs.lastOneMinuteBoundaryKey.takeIf { it.isNotBlank() }
    private var lastSchedulerTickMs: Long = 0L
    private var lastSchedulerElapsedMs: Long = 0L
    private var lastOneMinuteSchedulerTickMs: Long = 0L
    private var lastOneMinuteSchedulerElapsedMs: Long = 0L
    @Volatile private var historyInitialized: Boolean = false

    private fun isBatteryOptimizationExempt(app: Application): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.M) return true
        val pm = app.getSystemService(android.os.PowerManager::class.java)
        return pm?.isIgnoringBatteryOptimizations(app.packageName) == true
    }

    private fun isBackgroundRestricted(app: Application): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.P) return false
        val am = app.getSystemService(android.app.ActivityManager::class.java)
        return am?.isBackgroundRestricted == true
    }

    fun refreshDevicePowerState() {
        val app = getApplication<Application>()
        _state.value = _state.value.copy(
            batteryOptimizationExempt = isBatteryOptimizationExempt(app),
            backgroundRestricted = isBackgroundRestricted(app)
        )
        // A visible activity can retry a previously refused background start.
        syncForegroundRuntimeService()
    }

    init {
        // v0.7.64: runs indicator - the 15-minute candles of the five yen crosses every 15 minutes, never inside the AUTO windows
        viewModelScope.launch {
            delay(20_000L)
            while (isActive) {
                val now = System.currentTimeMillis()
                val last = _state.value.runRegime?.updatedAtMs ?: 0L
                // v0.7.69: start only in the first 20 seconds of a minute and give up after 15 s, so the five chart requests are over
                // before the :40-:54 AUTO window (weekday AUTO runs every minute; a 25 s fetch from :35 overlapped the scan's Yahoo calls)
                if (now - last >= 15 * 60_000L && ZonedDateTime.now(jst).second in 0..20 && !_state.value.busy && !_state.value.oneMinuteBusy &&
                    !shouldReserveYahooForUpcomingAuto()) {
                    try {
                        val candles = withTimeout(REGIME_FETCH_TIMEOUT_MS) {
                            RunRegime.PAIRS.map { p -> async { p to runCatching { repository.fetchChartCandles(p, "15m").candles }.getOrDefault(emptyList()) } }.awaitAll().toMap()
                        }
                        val st = RunRegime.of(candles, System.currentTimeMillis())
                        _state.value = _state.value.copy(runRegime = st, runRegimeError = if (st.level == RunRegime.Level.UNKNOWN) "15分足が足りません" else null)
                    } catch (ce: CancellationException) {
                        if (!isActive) throw ce
                        _state.value = _state.value.copy(runRegimeError = "15分足の取得がタイムアウトしました")
                    } catch (t: Exception) {
                        _state.value = _state.value.copy(runRegimeError = t.message ?: "15分足の取得に失敗しました")
                    }
                }
                delay(10_000L)
            }
        }
        viewModelScope.launch {
            var observedStatuses = emptyMap<String, String>()
            historyStore.rows.collect { rows ->
                if (historyInitialized) {
                    val nowMs = System.currentTimeMillis()
                    val latestCapture = rows.asSequence().filter { row ->
                        row.resultStatus in setOf("WIN", "LOSE") && observedStatuses[row.scanId] != row.resultStatus
                    }.mapNotNull { runCatching { ZonedDateTime.parse(it.settledAtJst).toInstant().toEpochMilli() }.getOrNull() }
                        .maxOrNull()
                    _state.value = _state.value.copy(history = rows, lastHistoryPublishedMs = nowMs,
                        lastSettledHistoryPublishDelayMs = latestCapture?.let { (nowMs - it).coerceAtLeast(0L) }
                            ?: _state.value.lastSettledHistoryPublishDelayMs)
                    // Observe even when the Activity is between screens/recreated/backgrounded.
                    CutInPolicy.observeEvents(cutInEvents, rows, _state.value.rates, nowMs, _state.value.cutInEnabled)
                }
                observedStatuses = rows.associate { it.scanId to it.resultStatus }
            }
        }
        viewModelScope.launch {
            GmkRuntimeServiceControl.lifecycle.collect { status ->
                _state.value = _state.value.copy(runtimeServiceRunning = status.first,
                    runtimeServiceError = status.second ?: GmkRuntimeServiceControl.lastError(app))
            }
        }
        // v0.7.52: the legacy horizon models (PC R13 / Direct19 / October similarity / chart rank) are no longer started.
        // Since v0.7.44 their output never decided anything, but they still loaded large models, downloaded minute history
        // for 19 symbols, prepared frames at T-25..T-15 and fetched a quote burst at :41-:45 - CPU and Yahoo traffic that
        // competed with the real T-10 scan (risk of 429s and of the scan missing its publish deadline).
        startRateLoop()
        // Start the foreground runtime immediately only when AUTO itself requires it.
        // Pending manual outcomes are discovered from history below and then keep the service alive.
        syncForegroundRuntimeService()

        // Large history JSON must never be parsed on Activity/Service main thread.
        // AUTO schedulers are intentionally started only after recovery finishes so a boot/process
        // restore cannot publish a new trade before dedup/pending state has been reconstructed.
        viewModelScope.launch(Dispatchers.IO) {
            var loaded = historyStore.load()

            // AUTO and 1m use exact minute OPEN, so a transient provider outage can be repaired
            // after restart. Reopen only recent misses; arbitrary-second MANUAL 3m is intentionally
            // excluded because its original quote cannot be reconstructed from M1 history.
            val now = ZonedDateTime.now(jst)
            // v0.7.54: followed SKIP rows (D..H "if entered", the 1-minute board) are repaired the same way.
            loaded.asSequence()
                .filter { (it.decision == "ENTRY" || ObservationPolicy.tracks(it)) && it.source != "MANUAL" }
                .filter { it.resultStatus in setOf("ENTRY_RATE_MISSED", "JUDGE_RATE_MISSED") }
                .filter { row ->
                    val judge = runCatching { ZonedDateTime.parse(row.judgeTimeJst) }.getOrNull()
                    judge != null && !judge.isAfter(now) &&
                        java.time.Duration.between(judge, now).toHours() <= 24L
                }
                .take(32)
                .forEach { historyStore.reopenMinuteAlignedMissForRecovery(it.scanId) }

            loaded = historyStore.load()
            // v0.7.51: continue the rolling distributions from before the restart (seed only when nothing was saved).
            runCatching { EvidencePolicy.importState(prefs.evidenceState, System.currentTimeMillis() / 1000L) }
            val pending = loaded.filter {
                (it.decision == "ENTRY" || ObservationPolicy.tracks(it)) && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
            }
            withContext(Dispatchers.Main.immediate) {
                _state.value = _state.value.copy(history = loaded)
                historyInitialized = true
                resumePendingOutcomes(pending)
                startAutoLoop()
                startOneMinuteAutoLoop()
                startRuleAlertLoop()
                startOutcomeRepairLoop()
                syncForegroundRuntimeService()
            }
        }
    }

    /** v0.7.54: reminder [SignalAlerts.PRE_ALERT_LEAD_SEC] before each time-of-day rule minute (the only S/A source). */
    private fun startRuleAlertLoop() {
        ruleAlertJob?.cancel()
        ruleAlertJob = viewModelScope.launch {
            while (isActive) {
                runCatching {
                    if (prefs.signalNotify && prefs.autoScan) {
                        val due = SignalAlerts.preAlertDue(ZonedDateTime.now(jst))
                        val key = due?.boundary?.toLocalDateTime()?.toString()
                        if (due != null && key != null && prefs.lastRuleAlertKey != key) {
                            prefs.lastRuleAlertKey = key
                            jp.gmk.mobile.runtime.GmkSignalNotifier.post(appContext, SignalAlerts.notificationId("rule|$key"),
                                SignalAlerts.preAlertTitle(due), SignalAlerts.preAlertText(due), 4L * 60_000L)
                        }
                    }
                }
                delay(1_000)
            }
        }
    }

    /** v0.7.54: phone notification for a new 3-minute ENTRY at or above the chosen grade. */
    private fun notifySignal(result: ScanResult) {
        val top = result.top1 ?: return
        if (!prefs.signalNotify) return
        if (!SignalAlerts.shouldNotify(top.decision, top.grade, result.policyVersion, prefs.notifyMinGrade)) return
        runCatching {
            jp.gmk.mobile.runtime.GmkSignalNotifier.post(appContext, SignalAlerts.notificationId(result.scanId),
                SignalAlerts.entryTitle(top.grade, top.instrument, top.direction, SignalAlerts.minutesBetween(result.entryTimeJst, result.judgeTimeJst) ?: 3),
                SignalAlerts.entryText(result.entryTimeJst, result.judgeTimeJst, top.assessment?.correctionLabel), 4L * 60_000L)
        }
    }

    private fun allRatesAvailable(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rows.all { it.price != null }

    private fun rateLiveCount(rows: List<RateRow>): Int =
        rows.count { it.price != null && it.freshnessStatus == "LIVE" }

    private fun allFresh(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rateLiveCount(rows) == 6

    private fun rateSummary(rows: List<RateRow>): String? {
        if (rows.isEmpty()) return "レート取得待機中"
        val missing = rows.filter { it.price == null }.map { it.instrument }
        val last = rows.filter { it.price != null && it.freshnessStatus != "LIVE" }.map { it.instrument }
        return when {
            missing.isNotEmpty() -> "未取得: ${missing.joinToString(",")}"
            last.isNotEmpty() -> "LIVE ${rateLiveCount(rows)}/6 / LAST: ${last.joinToString(",")}"
            else -> null
        }
    }

    private fun refreshNetworkDiagnosticState() {
        val market = repository.diagnosticStats()
        val outcomes = outcomeRepository.diagnosticStats()
        val bitcoin = bitcoinRepository.diagnosticStats()
        val forex = forexRepository.diagnosticStats()
        val marketError = market.optString("last_error").takeIf { it.isNotBlank() && it != "null" }
        val outcomeError = outcomes.optString("last_error").takeIf { it.isNotBlank() && it != "null" }
        _state.value = _state.value.copy(
            networkRequestCount = market.optLong("requests") + outcomes.optLong("requests") + bitcoin.optLong("requests") + forex.optLong("requests"),
            networkFailureCount = market.optLong("failure") + outcomes.optLong("failure") + bitcoin.optLong("failure") + forex.optLong("failure"),
            networkCancelledCount = market.optLong("cancelled") + outcomes.optLong("cancelled") + bitcoin.optLong("cancelled") + forex.optLong("cancelled"),
            network429Count = market.optLong("http_429") + outcomes.optLong("http_429") + bitcoin.optLong("http_429") + forex.optLong("http_429"),
            network5xxCount = market.optLong("http_5xx") + outcomes.optLong("http_5xx") + bitcoin.optLong("http_5xx") + forex.optLong("http_5xx"),
            lastNetworkError = marketError ?: outcomeError ?: bitcoin.optString("last_error").takeIf { it.isNotBlank() && it!="null" }
                ?: forex.optString("last_error").takeIf { it.isNotBlank() && it!="null" }
        )
    }

    private fun freshnessLimit(instrument: String): Double =
        if (instrument == "BTCJPY") MarketRepository.BTC_MAX_LIVE_AGE_SECONDS else 20.0

    private fun mergeRates(previous: List<RateRow>, incoming: List<RateRow>, elapsedSeconds: Double): List<RateRow> {
        val old=previous.associateBy { it.instrument };val updates=incoming.associateBy { it.instrument }
        val nowMs=System.currentTimeMillis();val elapsed=elapsedSeconds.coerceAtLeast(0.0)
        fun age(r:RateRow,advance:Boolean):RateRow {
            val source=r.sourceEpochMs;val received=r.receivedEpochMs
            val providerAge=if(source!=null) { if(source in 1L..nowMs)(nowMs-source)/1000.0 else Double.MAX_VALUE }
                else (r.ageSeconds ?: Double.MAX_VALUE)+if(advance)elapsed else 0.0
            val fetchAge=if(received!=null)(nowMs-received).coerceAtLeast(0)/1000.0 else (r.fetchAgeSeconds ?: 0.0)+if(advance)elapsed else 0.0
            val valid=r.price?.let { it.isFinite() && it>0 }==true
            val live=valid && r.freshnessStatus=="LIVE" && providerAge<=freshnessLimit(r.instrument)
            return r.copy(price=r.price?.takeIf { it.isFinite() && it>0 },ageSeconds=providerAge.takeIf { it.isFinite() && it<Double.MAX_VALUE },
                fetchAgeSeconds=fetchAge,freshnessStatus=if(live)"LIVE" else if(valid)"LAST" else "UNAVAILABLE",
                source=if(valid && !live)"${r.source.removeSuffix(" cache")} cache" else r.source)
        }
        return listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY","BTCJPY").map { symbol ->
            val cached=old[symbol]?.let { age(it,true) };val candidate=updates[symbol]?.let { age(it,false) }
            when {
                candidate==null -> cached ?: RateRow(symbol,null,null,null,"取得待機",null,"UNAVAILABLE")
                cached?.price==null -> candidate
                candidate.price==null -> {
                    // A failed REST request begun before a new socket tick cannot invalidate it.
                    if(symbol=="BTCJPY" && (cached.receivedEpochMs ?: 0)>(candidate.receivedEpochMs ?: Long.MAX_VALUE))cached
                    else cached.copy(freshnessStatus="LAST",source="${cached.source.removeSuffix(" cache")} cache")
                }
                cached.sourceEpochMs!=null && candidate.sourceEpochMs!=null ->
                    if(candidate.sourceEpochMs<cached.sourceEpochMs)cached else candidate
                candidate.freshnessStatus=="LIVE" && cached.freshnessStatus!="LIVE" -> candidate
                (candidate.ageSeconds ?: Double.MAX_VALUE)<=(cached.ageSeconds ?: Double.MAX_VALUE) -> candidate
                else -> cached
            }
        }
    }

    private fun publishRates(incoming:List<RateRow>) {
        val current=_state.value;val nowMs=System.currentTimeMillis()
        val elapsed=if(current.lastRateUpdateMs>0)(nowMs-current.lastRateUpdateMs).coerceAtLeast(0)/1000.0 else 0.0
        val rows=mergeRates(current.rates,incoming,elapsed)
        horizonRuntime.observe(incoming)
        _state.value=current.copy(rates=rows,connected=allFresh(rows),rateLiveCount=rateLiveCount(rows),
            rateAvailableCount=rows.count { it.price!=null },rateStatus=rateSummary(rows),lastRateUpdateMs=nowMs,
            lastRateSuccessMs=if(allFresh(rows))nowMs else current.lastRateSuccessMs)
        CutInPolicy.observeEvents(cutInEvents, current.history, rows, nowMs, current.cutInEnabled)
        refreshNetworkDiagnosticState()
    }

    private fun startBitcoinLoop() {
        bitcoinJob?.cancel();bitcoinRealtime.stop()
        bitcoinJob=viewModelScope.launch {
            launch { bitcoinRealtime.latest.collect { row->if(row!=null)publishRates(listOf(row)) } }
            bitcoinRealtime.start(this)
            try {
                while(isActive) {
                    val nowMs=System.currentTimeMillis()
                    if(!bitcoinRealtime.hasFreshStream(nowMs)) {
                        val attemptedAt=nowMs
                        val row=try { withTimeout(9000) { bitcoinRepository.fetchRate("BTCJPY") } }
                        catch(e:TimeoutCancellationException) { RateRow("BTCJPY",null,null,null,"bitbank再取得タイムアウト",null,"UNAVAILABLE") }
                        catch(e:CancellationException) { throw e }
                        catch(e:Exception) { RateRow("BTCJPY",null,null,null,"bitbank再取得失敗",null,"UNAVAILABLE") }
                        publishRates(listOf(if(row.price==null)row.copy(receivedEpochMs=attemptedAt) else row))
                    } else publishRates(emptyList())
                    delay(2000)
                }
            } finally { if(bitcoinJob==coroutineContext[Job])bitcoinRealtime.stop() }
        }
    }

    private fun millisUntilNextOneMinuteT10(now: ZonedDateTime = ZonedDateTime.now(jst)): Long {
        var candidate = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        if (!candidate.isAfter(now)) candidate = candidate.plusMinutes(1)
        return java.time.Duration.between(now, candidate).toMillis()
    }

    private fun shouldReserveYahooForUpcomingAuto(now: ZonedDateTime = ZonedDateTime.now(jst)): Boolean {
        // A normal quote refresh may occupy Yahoo slots for several seconds. Reserve the final
        // 10 seconds before T-10 AND the active :50-:54 window itself. At exactly :50.000,
        // "next T-10" already points to the following slot, so the explicit current-window
        // check prevents a race where live polling starts just before AUTO sets busy=true.
        fun entryAllowed(entry: ZonedDateTime) = TradingSession.isActive(entry)
        val currentBoundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
        val inCurrentThreeMinuteWindow = prefs.autoScan && isAutoMinute(now) && now.second in 40..54 && entryAllowed(currentBoundary)
        val inCurrentOneMinuteWindow = prefs.oneMinuteAutoScan && now.second in 40..54 && entryAllowed(currentBoundary)
        val threeWait = millisUntilNextAutoT10(now)
        val oneWait = millisUntilNextOneMinuteT10(now)
        val threeMinuteSoon = prefs.autoScan && threeWait in 0L..10_000L && entryAllowed(now.plusNanos(threeWait * 1_000_000L).plusSeconds(10))
        val oneMinuteSoon = prefs.oneMinuteAutoScan && oneWait in 0L..10_000L && entryAllowed(now.plusNanos(oneWait * 1_000_000L).plusSeconds(10))
        return inCurrentThreeMinuteWindow || inCurrentOneMinuteWindow || threeMinuteSoon || oneMinuteSoon
    }

    private fun pauseAuxiliaryMarketRequestsForScan() {
        forexRepository.cancelInFlightRequests()
        val chartWasActive = chartJob?.isActive == true
        val strengthWasActive = strengthJob?.isActive == true
        chartJob?.cancel()
        strengthJob?.cancel()
        if (chartWasActive || strengthWasActive) {
            val s = _state.value
            _state.value = s.copy(
                chartLoading = if (chartWasActive) false else s.chartLoading,
                chartError = if (chartWasActive) "スキャンを優先して更新を一時停止" else s.chartError,
                strengthLoading = if (strengthWasActive) false else s.strengthLoading,
                strengthErrors = if (strengthWasActive) mapOf("sync" to "スキャンを優先して更新を一時停止") else s.strengthErrors
            )
        }
    }

    private fun startRateLoop() {
        rateJob?.cancel()
        startBitcoinLoop()
        rateJob=viewModelScope.launch {
            fun paused()=_state.value.busy || _state.value.oneMinuteBusy || shouldReserveYahooForUpcomingAuto()
            // Each currency publishes immediately. A slow or failed pair cannot delay
            // the other four. The process-wide Yahoo semaphore still limits requests.
            for(symbol in listOf("USDJPY","EURJPY","GBPJPY","AUDJPY","NZDJPY"))launch {
                while(isActive) {
                    if(paused()) { delay(250);continue }
                    val row=try { withTimeout(20_000) { forexRepository.fetchRate(symbol) } }
                    catch(e:jp.gmk.mobile.data.MarketRequestAbortedException) { null }
                    catch(e:TimeoutCancellationException) { RateRow(symbol,null,null,null,"為替再取得タイムアウト",null,"UNAVAILABLE") }
                    catch(e:CancellationException) { throw e }
                    catch(e:Exception) { RateRow(symbol,null,null,null,"為替再取得失敗",null,"UNAVAILABLE") }
                    // Scan-priority abort is not a provider outage; retain the last sample
                    // under its original provider timestamp and normal 20s freshness gate.
                    publishRates(if (row != null) listOf(row) else emptyList());delay(6000)
                }
            }
            var wasPaused=false
            while(isActive) {
                val isPaused=paused()
                if(isPaused && !wasPaused)forexRepository.cancelInFlightRequests()
                wasPaused=isPaused
                publishRates(emptyList());delay(250)
            }
        }
    }

    /**
     * v0.7.58: AUTO runs at T-10 of every weekday minute (FX, every clock hour >= 70% ENTRY); on weekends only before the
     * 5-minute boundaries as before. The 1-minute board yields to it, so on weekdays it runs only when AUTO is off.
     */
    private fun isAutoMinute(t: ZonedDateTime): Boolean {
        val entry = t.withZoneSameInstant(jst).plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
        return TradingSession.isWeekday(entry) || t.withZoneSameInstant(jst).minute % 5 == 4
    }

    private fun latestScheduledT10AtOrBefore(now: ZonedDateTime): ZonedDateTime {
        // v0.7.61: step back to the previous AUTO minute (weekday every minute, weekend :X4) — not a fixed 5 minutes
        var m = now.truncatedTo(ChronoUnit.MINUTES)
        if (m.withSecond(50).isAfter(now)) m = m.minusMinutes(1)
        while (!isAutoMinute(m)) m = m.minusMinutes(1)
        return m.withSecond(50).withNano(0)
    }

    private fun latestOneMinuteT10AtOrBefore(now: ZonedDateTime): ZonedDateTime {
        var t = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        if (t.isAfter(now)) t = t.minusMinutes(1)
        return t
    }

    private fun isExpectedFxWeekendGap(aMs: Long, bMs: Long): Boolean {
        if (aMs <= 0L || bMs <= aMs) return false
        val gapMs = bMs - aMs
        if (gapMs < 24L * 60L * 60L * 1000L) return false

        val a = java.time.Instant.ofEpochMilli(aMs).atZone(java.time.ZoneOffset.UTC)
        val b = java.time.Instant.ofEpochMilli(bMs).atZone(java.time.ZoneOffset.UTC)

        val olderOk = a.dayOfWeek == java.time.DayOfWeek.FRIDAY
        val newerOk = b.dayOfWeek == java.time.DayOfWeek.SUNDAY ||
            b.dayOfWeek == java.time.DayOfWeek.MONDAY

        return olderOk && newerOk && gapMs <= 80L * 60L * 60L * 1000L
    }

    private fun isKnownEntryContractGrade(grade: String): Boolean {
        return grade.uppercase() in setOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I", "R")
    }

    private fun startAutoLoop() {
        autoJob?.cancel()
        // A preference toggle/restart is not a device sleep. Reset the monotonic baseline
        // so time spent with AUTO disabled can never generate a false MISSED event.
        lastSchedulerTickMs = 0L
        lastSchedulerElapsedMs = 0L
        autoJob = viewModelScope.launch {
            while (isActive) {
                if (!historyInitialized) {
                    delay(100)
                    continue
                }
                val now = ZonedDateTime.now(jst)
                val nowMs = System.currentTimeMillis()
                val elapsedNow = android.os.SystemClock.elapsedRealtime()

                if (prefs.autoScan) {
                    // Use monotonic elapsed time so manual clock/NTP changes do not create a false MISSED.
                    if (lastSchedulerTickMs > 0L &&
                        lastSchedulerElapsedMs > 0L &&
                        elapsedNow - lastSchedulerElapsedMs > 1_500L) {
                        val previousTick = java.time.Instant.ofEpochMilli(lastSchedulerTickMs).atZone(jst)
                        val scheduled = latestScheduledT10AtOrBefore(now)

                        if (scheduled.isAfter(previousTick) && !now.isBefore(scheduled.plusSeconds(5))) {
                            val boundary = scheduled.plusSeconds(10).truncatedTo(ChronoUnit.MINUTES)
                            val key = boundary.toLocalDateTime().toString()

                            if (TradingSession.isActive(boundary) && lastAutoBoundaryKey != key && prefs.claimThreeMinuteBoundary(key)) {
                                prefs.completeThreeMinuteBoundary(key)
                                lastAutoBoundaryKey = key
                                AutoSlotLog.record(key, "MISSED_SLEEP")
                                _state.value = _state.value.copy(
                                    scan = null,
                                    scanStatus = "AUTO_SCAN_MISSED: 端末スリープ/停止中にT-10有効ウィンドウを通過"
                                )
                            }
                        }
                    }

                    val inSlotWindow = isAutoMinute(now) && now.second in 50..54

                    if (inSlotWindow) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        if (!TradingSession.isActive(boundary)) {
                            _state.value = _state.value.copy(
                                scanStatus = "AUTO待機: 本番時間外 (${TradingSession.LABEL})"
                            )
                            delay(100)
                            continue
                        }
                        val key = boundary.toLocalDateTime().toString()

                        if (lastAutoBoundaryKey != key) {
                            if (!_state.value.busy) {
                                // Do not consume the boundary while another operation is still winding down.
                                // Keep retrying throughout the valid :50-:54 window.
                                if (_state.value.oneMinuteBusy) {
                                    oneMinuteJob?.cancelAndJoin()
                                    _state.value = _state.value.copy(
                                        oneMinuteBusy = false,
                                        oneMinuteStatus = "1分手動停止: 3分AUTO T-10を優先"
                                    )
                                }
                                if (prefs.claimThreeMinuteBoundary(key)) {
                                    try {
                                        val beforeSuccessMs = _state.value.lastScanSuccessMs
                                        performScan("AUTO", boundary, null)
                                        val published = _state.value.lastScanSuccessMs > beforeSuccessMs
                                        val after = ZonedDateTime.now(jst)
                                        if (published) {
                                            prefs.completeThreeMinuteBoundary(key)
                                            lastAutoBoundaryKey = key
                                            val slotTop: ScanCandidate? = _state.value.scan?.top1
                                            AutoSlotLog.record(key, "OK", if (slotTop == null) "" else slotTop.grade + " " + slotTop.decision)
                                        } else if (after.isBefore(boundary) && after.second <= 54) {
                                            // Data/provider failure inside the valid window: release the short lease
                                            // so the same boundary can retry before :55.
                                            prefs.releaseThreeMinuteBoundary(key)
                                        } else {
                                            prefs.completeThreeMinuteBoundary(key)
                                            lastAutoBoundaryKey = key
                                            AutoSlotLog.record(key, "FAILED", _state.value.scanStatus ?: _state.value.error ?: "")
                                        }
                                    } finally {
                                        prefs.releaseThreeMinuteBoundary(key)
                                    }
                                }
                            } else {
                                _state.value = _state.value.copy(
                                    scanStatus = "AUTO待機: T-10有効ウィンドウ内で実行中処理の終了待ち"
                                )
                            }
                        }
                    } else if (isAutoMinute(now) && now.second in 55..59) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()
                        if (TradingSession.isActive(boundary) && lastAutoBoundaryKey != key && prefs.claimThreeMinuteBoundary(key)) {
                            prefs.completeThreeMinuteBoundary(key)
                            lastAutoBoundaryKey = key
                            AutoSlotLog.record(key, "MISSED_WINDOW", if (_state.value.busy) "busy" else "")
                            _state.value = _state.value.copy(
                                scan = null,
                                scanStatus = "AUTO_SCAN_MISSED: T-10有効ウィンドウ内に開始できませんでした"
                            )
                        }
                    }
                }

                // Use the actual end-of-iteration clocks. performScan() may suspend for
                // several seconds; counting its own work as scheduler sleep creates false gap alarms.
                lastSchedulerTickMs = System.currentTimeMillis()
                lastSchedulerElapsedMs = android.os.SystemClock.elapsedRealtime()
                delay(100)
            }
        }
    }

    private fun millisUntilNextAutoT10(now: ZonedDateTime = ZonedDateTime.now(jst)): Long {
        var candidate = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        while (!isAutoMinute(candidate) || !candidate.isAfter(now)) {
            candidate = candidate.plusMinutes(1).withSecond(50).withNano(0)
        }
        return java.time.Duration.between(now, candidate).toMillis()
    }

    fun manualScan() {
        if (!historyInitialized) {
            _state.value = _state.value.copy(scanStatus = "手動スキャン待機: 履歴/結果追跡を復旧中")
            return
        }
        if (_state.value.busy) return
        val now = ZonedDateTime.now(jst)
        val manualEntryTarget = now.plusSeconds(10)
        if (!TradingSession.isActive(manualEntryTarget)) {
            _state.value = _state.value.copy(scanStatus = "3分手動見送り: ENTRY時刻が本番時間外 (${TradingSession.LABEL})")
            return
        }
        if (_state.value.oneMinuteBusy) {
            _state.value = _state.value.copy(scanStatus = "3分手動待機: 1分手動スキャン中")
            return
        }

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..20_000L) {
                _state.value = _state.value.copy(
                    scanStatus = "手動スキャン待機: AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        viewModelScope.launch { performScan("MANUAL", null, manualEntryTarget) }
    }

    fun manualOneMinuteScan() {
        if (!historyInitialized) {
            _state.value = _state.value.copy(oneMinuteStatus = "1分手動待機: 履歴/結果追跡を復旧中")
            return
        }
        if (_state.value.oneMinuteBusy || _state.value.busy) return
        val now = ZonedDateTime.now(jst)
        val oneMinuteEntryTarget = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
        if (oneMinuteEntryTarget.hour !in 9..22) {
            _state.value = _state.value.copy(oneMinuteStatus = "1分手動見送り: ENTRY時刻が本番時間外 (09:00-23:00)")
            return
        }

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..15_000L) {
                _state.value = _state.value.copy(
                    oneMinuteStatus = "1分手動待機: 3分AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        startOneMinuteScan("MANUAL_1M", oneMinuteEntryTarget)
    }

    private fun startOneMinuteAutoLoop() {
        oneMinuteAutoJob?.cancel()
        lastOneMinuteSchedulerTickMs = 0L
        lastOneMinuteSchedulerElapsedMs = 0L
        oneMinuteAutoJob = viewModelScope.launch {
            while (isActive) {
                if (!historyInitialized) {
                    delay(100)
                    continue
                }
                val now = ZonedDateTime.now(jst)
                val nowMs = System.currentTimeMillis()
                val elapsedNow = android.os.SystemClock.elapsedRealtime()
                if (prefs.oneMinuteAutoScan) {
                    // Detect a real scheduler suspension that skipped the whole :50-:54 window.
                    // Do not count the 3m-reserved minute as a 1m miss when 3m AUTO is enabled.
                    if (lastOneMinuteSchedulerTickMs > 0L && lastOneMinuteSchedulerElapsedMs > 0L &&
                        elapsedNow - lastOneMinuteSchedulerElapsedMs > 1_500L) {
                        val previousTick = java.time.Instant.ofEpochMilli(lastOneMinuteSchedulerTickMs).atZone(jst)
                        val scheduled = latestOneMinuteT10AtOrBefore(now)
                        val reservedFor3m = prefs.autoScan && isAutoMinute(scheduled)
                        if (!reservedFor3m && scheduled.isAfter(previousTick) && !now.isBefore(scheduled.plusSeconds(5))) {
                            val boundary = scheduled.plusSeconds(10).truncatedTo(ChronoUnit.MINUTES)
                            val key = boundary.toLocalDateTime().toString()
                            if (boundary.hour in 9..22 && lastOneMinuteBoundaryKey != key && prefs.claimOneMinuteBoundary(key)) {
                                prefs.completeOneMinuteBoundary(key)
                                lastOneMinuteBoundaryKey = key
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = "1分AUTO_MISSED: 端末スリープ/停止中にT-10有効ウィンドウを通過"
                                )
                            }
                        }
                    }

                    // Operating hours are enforced on the ENTRY boundary, not the current
                    // scan clock. This allows the valid 08:59:50 -> 09:00:00 first entry while
                    // still blocking 22:59:50 -> 23:00:00.

                    // 3m AUTO uses the same :50 at minutes 4/9/14/... and always has priority.
                    val isThreeMinuteAutoMinute = prefs.autoScan && isAutoMinute(now)
                    val inWindow = now.second in 50..54

                    if (inWindow && !isThreeMinuteAutoMinute) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()

                        if (lastOneMinuteBoundaryKey != key) {
                            if (boundary.hour !in 9..22) {
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = "1分AUTO見送り: ENTRY時刻が本番時間外 (09:00-23:00)"
                                )
                            } else if (!_state.value.busy && !_state.value.oneMinuteBusy) {
                                // Claim only when the scan can actually start. Completion is recorded
                                // only after a result is published; failed attempts release the lease
                                // while the :50-:54 retry window is still open.
                                if (prefs.claimOneMinuteBoundary(key)) {
                                    startOneMinuteScan("AUTO_1M", boundary)
                                }
                            } else {
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = "1分AUTO待機: T-10有効ウィンドウ内で実行中処理の終了待ち"
                                )
                            }
                        }
                    } else if (!isThreeMinuteAutoMinute && now.second in 55..59) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()
                        if (boundary.hour in 9..22 && lastOneMinuteBoundaryKey != key && prefs.claimOneMinuteBoundary(key)) {
                            prefs.completeOneMinuteBoundary(key)
                            lastOneMinuteBoundaryKey = key
                            _state.value = _state.value.copy(
                                oneMinuteStatus = "1分AUTO_MISSED: T-10有効ウィンドウ内に開始できませんでした"
                            )
                        }
                    } else if (inWindow && isThreeMinuteAutoMinute && now.minute % 5 != 4) {
                        // v0.7.60: weekday AUTO scans every minute, so the 1-minute board only runs on weekends or with AUTO off
                        val text = "1分AUTO待機: 平日はAUTO（毎分・5分判定）が優先。1分ボードは土日かAUTOオフの時に動きます"
                        if (_state.value.oneMinuteStatus != text) _state.value = _state.value.copy(oneMinuteStatus = text)
                    }
                }
                lastOneMinuteSchedulerTickMs = nowMs
                lastOneMinuteSchedulerElapsedMs = elapsedNow
                delay(100)
            }
        }
    }

    private fun startOneMinuteScan(source: String, requestedEntryTarget: ZonedDateTime? = null) {
        if (_state.value.oneMinuteBusy || _state.value.busy) return

        oneMinuteJob?.cancel()
        oneMinuteJob = viewModelScope.launch {
            val autoBoundaryKey = if (source == "AUTO_1M" && requestedEntryTarget != null) {
                requestedEntryTarget.toLocalDateTime().toString()
            } else null
            var published = false

            _state.value = _state.value.copy(
                oneMinuteBusy = true,
                oneMinuteScan = null,
                oneMinuteStatus = "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}: 6通貨Context取得中"
            )
            pauseAuxiliaryMarketRequestsForScan()

            // Do not cancel shared rate requests here. Scan traffic and live-rate polling
            // must not abort each other; cancellation is reserved for runtime shutdown.

            try {
                val now = ZonedDateTime.now(jst)
                val entry = (requestedEntryTarget ?: now.plusMinutes(1)).truncatedTo(ChronoUnit.MINUTES)
                if (entry.hour !in 9..22) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分見送り: ENTRY時刻が本番時間外 (09:00-23:00)"
                    )
                    return@launch
                }
                val remainingMs = java.time.Duration.between(now, entry).toMillis()

                if (remainingMs < 2_500L) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 次1分枠まで${remainingMs.coerceAtLeast(0L)}ms"
                    )
                    return@launch
                }

                val fetchBudget = minOf(8_000L, (remainingMs - 1_000L).coerceAtLeast(1_500L))
                val batch = withTimeout(fetchBudget) { repository.fetchAllCandles() }

                // v0.7.50: same session rule as the 3-minute scan - weekdays six instruments, Saturday/Sunday BTCJPY only.
                // (v0.7.49 always demanded six, so the 1-minute board could never run on a weekend.)
                val required = TradingSession.requiredInstruments(entry)
                val eligible = linkedMapOf<String, List<Candle>>()
                val errors = linkedMapOf<String, String>()
                val nowMs = System.currentTimeMillis()

                required.forEach { ins ->
                    val rows = batch.candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                    val fetchError = batch.errors[ins]
                    val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                    val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE
                    val expectedLastStartMs = ((nowMs / 60_000L) * 60_000L) - 60_000L
                    val latestLagMs = if (last > 0L) (expectedLastStartMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                    val tail15 = rows.takeLast(15)
                    val gaps = tail15.zipWithNext { a, b -> b.timeEpochMs - a.timeEpochMs }
                    val maxGapMs = gaps.maxOrNull() ?: 0L
                    val spanMs = if (tail15.size >= 2) {
                        tail15.last().timeEpochMs - tail15.first().timeEpochMs
                    } else Long.MAX_VALUE

                    when {
                        fetchError != null -> errors[ins] = "取得失敗: $fetchError"
                        rows.size < 15 -> errors[ins] = "1分足不足 ${rows.size}/15"
                        last <= 0L || latestLagMs > 5_000L ->
                            errors[ins] = "直近完成1分足欠損 lag=${if (latestLagMs == Long.MAX_VALUE) "不明" else "${latestLagMs / 1000}s"}"
                        ageMs > 180_000L ->
                            errors[ins] = "1分足STALE ${ageMs / 1000}s"
                        maxGapMs > 90_000L ->
                            errors[ins] = "1分足不連続 gap=${maxGapMs / 1000L}s"
                        spanMs > 16L * 60_000L ->
                            errors[ins] = "1分足不連続 span=${spanMs / 60_000L}m"
                        else -> eligible[ins] = rows
                    }
                }

                if (eligible.size != required.size) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: ${required.size}/${required.size}必須 / " +
                            errors.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                    )
                    return@launch
                }

                val latestTimes = eligible.mapValues { (_, rows) -> rows.last().timeEpochMs }
                val latestSpreadMs = (latestTimes.values.maxOrNull() ?: 0L) -
                    (latestTimes.values.minOrNull() ?: 0L)

                if (latestSpreadMs > 90_000L) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 6通貨M1時刻ずれ ${latestSpreadMs / 1000L}s"
                    )
                    return@launch
                }

                val decisionNow = ZonedDateTime.now(jst)
                if (!decisionNow.isBefore(entry)) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 次1分枠開始後"
                    )
                    return@launch
                }

                val raw = withContext(Dispatchers.Default) {
                    oneMinuteEngine.scan(eligible, now, entry)
                }
                val result = raw.copy(source = source)

                if (result.candidates.size != required.size || result.top1 == null) {
                    error("1分候補数異常 ${result.candidates.size}/${required.size}")
                }

                val topGuarded = result.top1?.reasons?.any {
                    it.startsWith("1M_TREND_SWITCH_GUARD")
                } == true

                if (topGuarded) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: TOP1がトレンド切替逆方向"
                    )
                    return@launch
                }

                if (!ZonedDateTime.now(jst).isBefore(entry)) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 判定完了が次枠開始後"
                    )
                    return@launch
                }

                val top = result.top1 ?: error("1分TOP1欠損")
                val historyResult = ScanResult(
                    scanId = result.scanId,
                    atJst = result.atJst,
                    entryTimeJst = result.entryTimeJst,
                    judgeTimeJst = result.judgeTimeJst,
                    candidates = listOf(
                        ScanCandidate(
                            rank = 1,
                            instrument = top.instrument,
                            display = top.instrument,
                            direction = top.direction,
                            // v0.7.54: observation only (OneMinuteObservation): followed "as if entered", never an ENTRY.
                            grade = OneMinuteObservation.GRADE,
                            probability = top.confidence,
                            decision = "SKIP",
                            score = top.score,
                            regime = top.regime,
                            regimeConfidence = top.confidence,
                            reasons = listOf(OneMinuteObservation.REASON) + top.reasons
                        )
                    ),
                    warnings = emptyList(),
                    source = source,
                    policyVersion = OneMinuteObservation.POLICY
                )

                withContext(Dispatchers.IO) { historyStore.add(historyResult) }
                scheduleOutcomeTracking(historyResult)

                val topDecision = historyResult.top1?.decision ?: "SKIP"
                val topGrade = historyResult.top1?.grade ?: "E"
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteScan = result,
                    history = historyStore.rows.value,
                    oneMinuteStatus = "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}（参考・見送り）: ${top.instrument} ${top.direction}" +
                        " / ${if (topDecision == "ENTRY") "ENTRY" else "入っていたらを記録"} / $topGrade"
                )
                published = true
            } catch (e: TimeoutCancellationException) {
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = "1分技術見送り: 市場Contextタイムアウト"
                )
            } catch (ce: CancellationException) {
                val current = _state.value.oneMinuteStatus
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = if (current?.contains("3分AUTO T-10を優先") == true) current else "1分スキャン停止"
                )
                throw ce
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = "1分スキャン失敗: ${e.message}"
                )
            } finally {
                if (autoBoundaryKey != null && requestedEntryTarget != null) {
                    val after = ZonedDateTime.now(jst)
                    if (published) {
                        prefs.completeOneMinuteBoundary(autoBoundaryKey)
                        lastOneMinuteBoundaryKey = autoBoundaryKey
                    } else if (after.isBefore(requestedEntryTarget) && after.second <= 54) {
                        prefs.releaseOneMinuteBoundary(autoBoundaryKey)
                    } else {
                        prefs.completeOneMinuteBoundary(autoBoundaryKey)
                        lastOneMinuteBoundaryKey = autoBoundaryKey
                    }
                }
            }
        }
    }

    private var liveRefreshAttempts = 0L
    private var liveRefreshQuotes = 0L
    private var liveRefreshSkipped = 0L
    private var lastLiveRefreshMs = 0L

    /** v0.7.55: one late Yahoo quote round for the FX instruments; budget ends [LIVE_REFRESH_RESERVE_MS] before the boundary. */
    private suspend fun refreshLiveQuotesBeforeDecision(instruments: List<String>, boundary: ZonedDateTime) {
        val fx = instruments.filter { it != "BTCJPY" }
        if (fx.isEmpty()) return
        val remainingMs = java.time.Duration.between(ZonedDateTime.now(jst), boundary).toMillis()
        val budgetMs = (remainingMs - LIVE_REFRESH_RESERVE_MS).coerceAtMost(LIVE_REFRESH_MAX_MS)
        if (budgetMs < LIVE_REFRESH_MIN_MS) { liveRefreshSkipped++; return }
        liveRefreshAttempts++
        val started = System.currentTimeMillis()
        withTimeoutOrNull(budgetMs) {
            coroutineScope {
                fx.forEach { symbol ->
                    launch {
                        val row = try { repository.fetchRate(symbol) } catch (ce: CancellationException) { throw ce } catch (e: Exception) { null }
                        val price = row?.price; val at = row?.sourceEpochMs
                        if (row != null && price != null && at != null && row.freshnessStatus == "LIVE") {
                            LiveQuoteBoard.record(symbol, price, at); liveRefreshQuotes++
                        }
                    }
                }
            }
        }
        lastLiveRefreshMs = System.currentTimeMillis() - started
    }

    private suspend fun performScan(source: String, autoBoundary: ZonedDateTime?, manualEntryOverride: ZonedDateTime? = null) {
        val scanStarted = ZonedDateTime.now(jst)
        val manualEntryTarget = manualEntryOverride ?: scanStarted.plusSeconds(10)
        if (source == "MANUAL" && !TradingSession.isActive(manualEntryTarget)) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "3分手動見送り: ENTRY時刻が本番時間外 (${TradingSession.LABEL})"
            )
            return
        }

        // Raise the scan lock first so the rate loop cannot start a new request
        // between cancelAll() and the beginning of candle acquisition.
        _state.value = _state.value.copy(
            busy = true,
            scan = null,
            scannableCount = 0,
            lastScanExcluded = emptyMap(),
            lastCandleErrors = emptyMap(),
            lastCandleLatestMs = emptyMap(),
            quoteCandleDivergencePct = emptyMap(),
            lastScanAttemptMs = System.currentTimeMillis(),
            scanStatus = if (source == "AUTO") "AUTOスキャン実行中" else "手動スキャン実行中",
            error = null
        )
        pauseAuxiliaryMarketRequestsForScan()

        // Do not cancel shared live-rate requests when a scan starts. The old cancelAll()
        // caused periodic LIVE-rate dropouts exactly when AUTO scans were active.

        try {
            val batch = if (source == "AUTO") {
                // AUTO starts at T-10. Do not let slow network publish after entry time.
                withTimeout(8_500) { repository.fetchAllCandles() }
            } else {
                // MANUAL entry is scan-start +10s. Data acquisition must finish before that.
                val remainingToEntry = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (remainingToEntry <= 1_200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scanStatus = "手動技術見送り: +10秒ENTRYまで時間不足"
                    )
                    return
                }
                withTimeout(minOf(8_000L, (remainingToEntry - 700L).coerceAtLeast(1_000L))) {
                    repository.fetchAllCandles()
                }
            }

            val candles = batch.candles
            // v0.7.43: weekday sessions need all six; Saturday/Sunday sessions are BTCJPY only.
            val required = TradingSession.requiredInstruments(
                if (source == "AUTO" && autoBoundary != null) autoBoundary else manualEntryTarget
            )
            val nowMs = System.currentTimeMillis()
            val latestTimes = required.associateWith { ins ->
                candles[ins].orEmpty().maxOfOrNull { it.timeEpochMs } ?: 0L
            }

            val excluded = linkedMapOf<String, String>()
            val eligible = linkedMapOf<String, List<Candle>>()

            required.forEach { ins ->
                val rows = candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                val fetchError = batch.errors[ins]

                when {
                    fetchError != null -> excluded[ins] = "取得失敗: $fetchError"
                    rows.size < 21 -> excluded[ins] = "1分足不足 ${rows.size}/21"
                    else -> {
                        val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                        val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE
                        val expectedLastStartMs = ((nowMs / 60_000L) * 60_000L) - 60_000L
                        val latestLagMs = if (last > 0L) (expectedLastStartMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                        // Timestamp is the beginning of the completed M1 candle.
                        // 240s keeps short provider delays usable without accepting closed-market history.
                        val tail = rows.takeLast(30)
                        val gapPairs = tail.zipWithNext { a, b -> Triple(a.timeEpochMs, b.timeEpochMs, b.timeEpochMs - a.timeEpochMs) }
                        val unexpectedGaps = gapPairs.filter { (a, b, gap) ->
                            gap > 90_000L &&
                                !(ins != "BTCJPY" && isExpectedFxWeekendGap(a, b))
                        }
                        val spanMs = if (tail.size >= 2) tail.last().timeEpochMs - tail.first().timeEpochMs else Long.MAX_VALUE
                        val hasWeekendBridge = gapPairs.any { (a, b, gap) ->
                            gap > 90_000L && ins != "BTCJPY" && isExpectedFxWeekendGap(a, b)
                        }

                        when {
                            last <= 0L || latestLagMs > 5_000L ->
                                excluded[ins] = "直近完成1分足欠損 lag=${if (latestLagMs == Long.MAX_VALUE) "不明" else "${latestLagMs / 1000}s"}"
                            ageMs > 240_000L ->
                                excluded[ins] = "1分足STALE ${ageMs / 1000}s"
                            unexpectedGaps.isNotEmpty() ->
                                excluded[ins] = "1分足不連続 gap=${unexpectedGaps.maxOf { it.third } / 1000L}s"
                            !hasWeekendBridge && tail.size >= 30 && spanMs > 45L * 60_000L ->
                                excluded[ins] = "1分足欠損多発 span=${spanMs / 60_000L}m"
                            else -> eligible[ins] = rows
                        }
                    }
                }
            }

            val liveRates = _state.value.rates.associateBy { it.instrument }
            val divergence = linkedMapOf<String, Double>()
            eligible.forEach { (ins, rows) ->
                val q = liveRates[ins]
                val candleClose = rows.lastOrNull()?.close
                if (q?.price != null && q.freshnessStatus == "LIVE" &&
                    candleClose != null && candleClose > 0.0) {
                    val pct = kotlin.math.abs(q.price - candleClose) / candleClose * 100.0
                    divergence[ins] = pct
                }
            }

            val divergenceWarnings = divergence
                .filter { (ins, pct) -> pct >= if (ins == "BTCJPY") 1.50 else 0.50 }
                .map { (ins, pct) -> "$ins quote/candle乖離 ${"%.3f".format(pct)}%" }

            val divergenceBlocked = divergence.filter { (ins, pct) ->
                pct >= if (ins == "BTCJPY") 1.50 else 0.50
            }.keys
            divergenceBlocked.forEach { ins ->
                eligible.remove(ins)
                excluded[ins] = "quote/candle乖離大: fail-safe SKIP"
            }

            if (eligible.isEmpty()) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = 0,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン待機: " + excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // v0.7.8 production policy was validated by comparing all six instruments.
            // Never choose TOP1 from a partial universe because that changes the ranking distribution.
            if (eligible.size != required.size) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = eligible.size,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン見送り: ${required.size}/${required.size}必須 (${eligible.size}/${required.size}) / " +
                        excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // MANUAL also has a hard publish deadline: scan-start +10 seconds.
            if (source == "MANUAL") {
                val remainingMs = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (remainingMs <= 500L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "手動技術見送り: +10秒ENTRY直前/超過"
                    )
                    return
                }
            }

            // AUTO result must still be ready before the target frame opens.
            if (source == "AUTO" && autoBoundary != null) {
                val remainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (remainingMs <= 400L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 対象枠開始まで${remainingMs.coerceAtLeast(0)}ms"
                    )
                    return
                }
            }

            val entryTarget = if (source == "AUTO") autoBoundary else manualEntryTarget
            // v0.7.55: the research live price is the last price before entry; fetch the FX quotes once more, as late as the
            // publish deadline allows (never past it). Each quote that arrives in time replaces an older one.
            if (source == "AUTO" && autoBoundary != null) refreshLiveQuotesBeforeDecision(eligible.keys.toList(), autoBoundary)
            val entryMode = EntryMode.parse(prefs.entryMode)
            val result0 = withContext(Dispatchers.Default) {
                val native = ruleEngine.scan(eligible, source, scanStarted, entryTarget)
                // v0.7.44: final evidence-model ENTRY decision after every optional overlay.
                // Live quotes: Yahoo meta from this scan's candle fetch + the LIVE rate rows (BTC stream).
                val liveQuotes = EvidencePolicy.newestQuotes(LiveQuoteBoard.snapshot(), EvidencePolicy.quotesFromRates(liveRates.values.toList()))
                // v0.7.60: this hour's entries and the running trades by direction, in one pass over the history (LiveEntryState)
                val live = LiveEntryState.of(historyStore.rows.value, native.entryTimeJst, EvidencePolicy.POLICY_TAG)
                EvidencePolicy.apply(native, native, eligible, liveQuotes, entryMode, live.hourEntries, live.openHigh, live.openLow, live.hourSlots)
            }

            if (source == "AUTO" && autoBoundary != null) {
                val publishRemainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (publishRemainingMs <= 500L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 判定完了が対象枠直前/開始後"
                    )
                    return
                }
            }

            if (source == "MANUAL") {
                val publishRemainingMs = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (publishRemainingMs <= 200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "手動技術見送り: 判定完了が+10秒ENTRY直前/超過"
                    )
                    return
                }
            }

            if (result0.candidates.isEmpty()) error("有効候補0件")
            if (result0.candidates.size != eligible.size) {
                error("候補数異常: ${result0.candidates.size}/${eligible.size}")
            }

            val expectedRanks = (1..result0.candidates.size).toSet()
            if (result0.candidates.map { it.rank }.toSet() != expectedRanks) {
                error("順位整合性エラー")
            }

            if (result0.candidates.any { it.direction !in setOf("HIGH", "LOW") }) {
                error("方向値エラー")
            }

            if (result0.candidates.any { !isKnownEntryContractGrade(it.grade) }) {
                error("未知ランク検出")
            }

            // v0.7.56: the 1st candidate's C is ENTRY only when the ENTRY amount setting enters C on this day; any other C is ENTRY.
            val slotWeekend = RankStatistics.isWeekend(result0.entryTimeJst) ?: false
            if (result0.candidates.any {
                    (it.grade in setOf("D", "E", "F", "G", "H", "I") && it.decision != "SKIP") ||
                    (it.grade !in setOf("C", "D", "E", "F", "G", "H", "I") && it.decision != "ENTRY") ||
                    (it.grade == "C" && it.decision != (if (it.rank != 1 || entryMode.enters("C", slotWeekend)) "ENTRY" else "SKIP"))
                }) {
                error("ENTRY/SKIP契約違反")
            }

            val coverageWarning = if (excluded.isNotEmpty()) {
                "6/6確認後に除外発生: " + excluded.entries.joinToString(", ") { "${it.key}=${it.value}" }
            } else null

            val result = result0.copy(
                warnings = result0.warnings + listOfNotNull(coverageWarning) + divergenceWarnings
            )

            // v0.7.58: weekday minutes between the 5-minute boundaries are kept only when they ENTER; the boundary rows stay
            // the slot record (ENTRY share per hour, 'if entered' results), so the history does not grow five-fold.
            val keepRow = result.top1?.decision == "ENTRY" || EvidencePolicy.isBoundaryText(result.entryTimeJst) || source != "AUTO"
            if (keepRow) withContext(Dispatchers.IO) { historyStore.add(result) }
            if (source == "AUTO") withContext(Dispatchers.IO) { horizonRuntime.commit(result.scanId) }
            if (source == "AUTO") withContext(Dispatchers.IO) { runCatching { prefs.evidenceState = EvidencePolicy.exportState() } }
            if (keepRow) scheduleOutcomeTracking(result)
            notifySignal(result)

            _state.value = _state.value.copy(
                busy = false,
                scan = result,
                history = historyStore.rows.value,
                lastScanSuccessMs = System.currentTimeMillis(),
                scannableCount = eligible.size,
                lastScanExcluded = excluded,
                lastCandleErrors = batch.errors,
                lastCandleLatestMs = latestTimes,
                quoteCandleDivergencePct = divergence,
                scanStatus = coverageWarning ?: "スキャン完了 ${eligible.size}/6",
                error = null
            )
        } catch (e: TimeoutCancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "${source}スキャン失敗: 市場データ取得タイムアウト",
                error = null
            )
        } catch (ce: CancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = if (source == "AUTO") "AUTOスキャン停止" else "スキャン停止",
                error = null
            )
            throw ce
        } catch (e: Exception) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "スキャン失敗: ${e.message}",
                error = null
            )
        } finally {
            horizonRuntime.discardPending()
        }
    }

    private fun scheduleOutcomeTracking(result: ScanResult) {
        val top = result.top1 ?: return
        // v0.7.50: D..H skips of the 3-minute policy are followed too ("if entered"); they stay SKIP rows,
        // so OutcomeStatistics never counts them in a win rate or a losing streak.
        if (top.decision != "ENTRY" && !ObservationPolicy.tracks(top.decision, top.grade, result.policyVersion)) return
        val scanId = result.scanId
        if (scanId.isBlank()) return
        if (outcomeJobs[scanId]?.isActive == true) return

        val job = viewModelScope.launch {
            try {
                val entryTarget = ZonedDateTime.parse(result.entryTimeJst)
                val judgeTarget = ZonedDateTime.parse(result.judgeTimeJst)

                var row = historyStore.rows.value.firstOrNull { it.scanId == scanId } ?: return@launch

                if (row.resultStatus == "WAIT_ENTRY") {
                    delayUntil(entryTarget)
                    val entryRate = fetchOutcomeRateAtTarget(
                        top.instrument, entryTarget, exactMinuteOpen = result.source != "MANUAL"
                    )
                    if (entryRate == null) {
                        withContext(Dispatchers.IO) { historyStore.markEntryMissed(scanId) }
                        refreshHistory("結果追跡: ENTRYレート取得失敗/時刻超過")
                        return@launch
                    }

                    withContext(Dispatchers.IO) { historyStore.updateEntryRate(
                        scanId = scanId,
                        rate = entryRate.price,
                        source = entryRate.source,
                        capturedAtJst = entryRate.capturedAtJst,
                        captureDelayMs = entryRate.captureDelayMs,
                        providerAgeSeconds = entryRate.providerAgeSeconds
                    ) }
                    refreshHistory("結果追跡: ENTRY ${top.instrument} ${formatOutcomeRate(entryRate.price)}")
                    row = historyStore.rows.value.firstOrNull { it.scanId == scanId } ?: return@launch
                }

                if (row.resultStatus != "WAIT_JUDGE") return@launch

                delayUntil(judgeTarget)
                refreshHistory(if (result.source != "MANUAL")
                    "判定時刻到達: ${top.instrument} / 対象分OPEN配信待ち" else
                    "判定時刻到達: ${top.instrument} / 対象秒LIVEレート取得中")
                val judgeRate = fetchOutcomeRateAtTarget(
                    top.instrument, judgeTarget, exactMinuteOpen = result.source != "MANUAL"
                )
                if (judgeRate == null) {
                    withContext(Dispatchers.IO) { historyStore.markJudgeMissed(scanId) }
                    refreshHistory("結果追跡: 判定レート取得失敗/時刻超過")
                    return@launch
                }

                withContext(Dispatchers.IO) { historyStore.settle(
                    scanId = scanId,
                    judgeRate = judgeRate.price,
                    source = judgeRate.source,
                    settledAtJst = judgeRate.capturedAtJst,
                    captureDelayMs = judgeRate.captureDelayMs,
                    providerAgeSeconds = judgeRate.providerAgeSeconds
                ) }
                refreshHistory("結果確定: ${top.instrument}")
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                val retry = (outcomeUnexpectedRetryCounts[scanId] ?: 0) + 1
                outcomeUnexpectedRetryCounts[scanId] = retry
                if (retry <= 2) {
                    refreshHistory("結果追跡エラー: ${e.message ?: e::class.java.simpleName} / ${retry}回目・再試行")
                } else {
                    val pendingRow = historyStore.rows.value.firstOrNull { it.scanId == scanId }
                    when (pendingRow?.resultStatus) {
                        "WAIT_ENTRY" -> withContext(Dispatchers.IO) { historyStore.markEntryMissed(scanId, "ENTRY_RATE_MISSED") }
                        "WAIT_JUDGE" -> withContext(Dispatchers.IO) { historyStore.markJudgeMissed(scanId, "JUDGE_RATE_MISSED") }
                    }
                    outcomeUnexpectedRetryCounts.remove(scanId)
                    refreshHistory("結果追跡エラー: 再試行上限 / ${e.message ?: e::class.java.simpleName}")
                }
            } finally {
                outcomeJobs.remove(scanId)
                val retryCount = outcomeUnexpectedRetryCounts[scanId] ?: 0
                val stillPending = historyStore.rows.value.any {
                    it.scanId == scanId && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
                }
                if (retryCount in 1..2 && stillPending) {
                    viewModelScope.launch {
                        delay(3_000)
                        scheduleOutcomeTracking(result)
                    }
                } else if (!stillPending) {
                    outcomeUnexpectedRetryCounts.remove(scanId)
                }
                syncForegroundRuntimeService()
            }
        }

        outcomeJobs[scanId] = job
        // Manual ENTRYs also need background protection even when both AUTO toggles are OFF.
        syncForegroundRuntimeService()
    }

    private fun resumePendingOutcomes(pendingRows: List<HistoryRow>) {
        outcomeRecoveryJob?.cancel()
        outcomeRecoveryJob = viewModelScope.launch {
            val ordered = pendingRows.sortedBy { row ->
                runCatching { ZonedDateTime.parse(row.judgeTimeJst).toInstant().toEpochMilli() }
                    .getOrDefault(Long.MAX_VALUE)
            }
            for (h in ordered) {
                if (!isActive) break
                if (h.scanId.isBlank() || h.entryTimeJst.isBlank() || h.judgeTimeJst.isBlank()) continue

                // Bound the number of live waiting jobs. Capture concurrency is separately
                // limited to 2, while this cap prevents a corrupt/large backlog from creating
                // thousands of suspended coroutines at process start.
                while (isActive && outcomeJobs.values.count { it.isActive } >= MAX_OUTCOME_TRACKING_JOBS) {
                    delay(250)
                }
                if (!isActive) break

                scheduleOutcomeTracking(syntheticResult(h))
                delay(20)
            }
        }
    }

    private fun syntheticResult(h: HistoryRow): ScanResult = ScanResult(
        scanId = h.scanId,
        atJst = h.atJst,
        entryTimeJst = h.entryTimeJst,
        judgeTimeJst = h.judgeTimeJst,
        candidates = listOf(
            ScanCandidate(
                rank = h.candidateRank,
                instrument = h.instrument,
                display = h.instrument,
                direction = h.direction,
                grade = h.grade,
                probability = null,
                decision = h.decision,
                regime = h.regime,
                assessment = h.assessment
            )
        ),
        source = h.source,
        policyVersion = h.policyVersion
    )

    /** v0.7.68: every 10 minutes, reopen recent AUTO/1-minute results that missed their price and read the exact minute OPEN again. */
    private fun startOutcomeRepairLoop() {
        outcomeRepairJob?.cancel()
        outcomeRepairJob = viewModelScope.launch {
            delay(60_000L)
            while (isActive) {
                try { repairMissedOutcomes() } catch (ce: CancellationException) { throw ce } catch (_: Exception) { }
                delay(OutcomeRepair.INTERVAL_MS)
            }
        }
    }

    private suspend fun repairMissedOutcomes() {
        if (!historyInitialized || _state.value.busy || shouldReserveYahooForUpcomingAuto(ZonedDateTime.now(jst))) return
        val due = OutcomeRepair.due(historyStore.rows.value, ZonedDateTime.now(jst), outcomeRepairAttempts)
        if (due.isEmpty()) return
        val reopened = withContext(Dispatchers.IO) { due.filter { historyStore.reopenMinuteAlignedMissForRecovery(it.scanId) } }.map { it.scanId }.toSet()
        if (reopened.isEmpty()) return
        reopened.forEach { id -> outcomeRepairAttempts.merge(id, 1, Int::plus) }
        val rows: List<HistoryRow> = historyStore.rows.value.filter { it.scanId in reopened && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") }
        refreshHistory("結果の再取得: ${rows.size}件（価格が取れなかった判定）")
        for (h in rows) { scheduleOutcomeTracking(syntheticResult(h)); delay(20) }
    }

    private suspend fun delayUntil(target: ZonedDateTime) {
        val waitMs = java.time.Duration.between(ZonedDateTime.now(jst), target).toMillis()
        if (waitMs > 0L) delay(waitMs)
    }

    private data class CapturedOutcomeRate(
        val price: Double,
        val source: String,
        val capturedAtJst: String,
        val captureDelayMs: Long,
        val providerAgeSeconds: Double
    )

    private suspend fun fetchOutcomeRateAtTarget(
        instrument: String,
        target: ZonedDateTime,
        exactMinuteOpen: Boolean
    ): CapturedOutcomeRate? {
        if (!exactMinuteOpen) {
            // 3-minute MANUAL entries are intentionally +10 seconds and are not aligned to
            // a minute boundary. A candle OPEN can never represent e.g. 15:00:37, so capture
            // a genuinely fresh provider quote around the requested second instead.
            val deadline = target.plusSeconds(20)
            while (ZonedDateTime.now(jst).isBefore(deadline)) {
                val now = ZonedDateTime.now(jst)
                if (now.isBefore(target)) {
                    delay(java.time.Duration.between(now, target).toMillis().coerceAtMost(1_000L))
                    continue
                }
                try {
                    val budgetMs = java.time.Duration.between(ZonedDateTime.now(jst), deadline).toMillis().coerceIn(1L, 6_000L)
                    val q = withTimeout(budgetMs) { outcomeCaptureSemaphore.withPermit { outcomeRepository.fetchRate(instrument) } }
                    val price = q.price
                    val ageSec = q.ageSeconds
                    if (price != null && price.isFinite() && price > 0.0 &&
                        q.freshnessStatus == "LIVE" && ageSec != null && ageSec.isFinite()) {
                        val captured = ZonedDateTime.now(jst)
                        val capturedMs = captured.toInstant().toEpochMilli()
                        val providerAtMs = q.sourceEpochMs ?: (capturedMs - (ageSec * 1000.0).toLong())
                        // Yahoo timestamps are second-resolution. Require the provider sample to
                        // belong to the target second or later; never accept a quote from a prior second.
                        val targetSecondMs = target.truncatedTo(ChronoUnit.SECONDS).toInstant().toEpochMilli()
                        if (providerAtMs >= targetSecondMs && providerAtMs <= capturedMs && captured.isBefore(deadline)) {
                            val lateMs = java.time.Duration.between(target, captured).toMillis().coerceAtLeast(0L)
                            return CapturedOutcomeRate(
                                price = price,
                                source = "${q.source} manual live",
                                capturedAtJst = captured.toString(),
                                captureDelayMs = lateMs,
                                providerAgeSeconds = ageSec
                            )
                        }
                    }
                } catch (_: TimeoutCancellationException) {
                    // A request timeout is retryable inside the overall capture deadline.
                } catch (ce: CancellationException) {
                    throw ce
                } catch (_: Exception) {
                }
                delay(1_500)
            }
            return null
        }

        // AUTO and 1-minute modes are minute-aligned: use exact target-minute candle OPEN.
        val targetMs = target.toInstant().toEpochMilli()
        val startNow = ZonedDateTime.now(jst)
        val hardDeadline = if (startNow.isAfter(target.plusSeconds(90))) {
            startNow.plusSeconds(20)
        } else {
            target.plusSeconds(90)
        }

        while (ZonedDateTime.now(jst).isBefore(hardDeadline)) {
            try {
                val budgetMs = java.time.Duration.between(ZonedDateTime.now(jst), hardDeadline).toMillis().coerceIn(1L, 6_000L)
                val candle = withTimeout(budgetMs) { outcomeCaptureSemaphore.withPermit { outcomeRepository.fetchMinuteOpenAt(instrument, targetMs) } }
                if (candle != null && candle.open.isFinite() && candle.open > 0.0 && ZonedDateTime.now(jst).isBefore(hardDeadline)) {
                    val now = ZonedDateTime.now(jst)
                    val lateMs = java.time.Duration.between(target, now).toMillis().coerceAtLeast(0L)
                    return CapturedOutcomeRate(
                        price = candle.open,
                        source = if (instrument == "BTCJPY") "bitbank 1m open" else "Yahoo 1m open",
                        capturedAtJst = now.toString(),
                        captureDelayMs = lateMs,
                        providerAgeSeconds = lateMs / 1000.0
                    )
                }
            } catch (_: TimeoutCancellationException) {
                    // A request timeout is retryable inside the overall capture deadline.
                } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
            }
            delay(3_000)
        }

        return null
    }

    private fun refreshHistory(status: String) {
        _state.value = _state.value.copy(
            history = historyStore.rows.value,
            outcomeStatus = status
        )
    }

    private fun formatOutcomeRate(v: Double): String =
        if (v >= 1_000_000.0) "%,.0f".format(v) else "%.3f".format(v)

    fun buildDiagnosticJson(): String {
        val s = _state.value
        val strengthCandidate = listOfNotNull(
            s.scan?.let { scan -> scan.top1?.let { Triple(scan.atJst, it.instrument, it.direction) } },
            s.oneMinuteScan?.let { scan -> scan.top1?.let { Triple(scan.atJst, it.instrument, it.direction) } }
        ).maxByOrNull { runCatching { ZonedDateTime.parse(it.first).toInstant().toEpochMilli() }.getOrDefault(0L) }
        val strengthScores = currencyRelativeStrength(s.strengthCandles)
        val candidateStrengthCheck = strengthCandidate?.let { (at, pair, direction) ->
            val gap = strengthScores[pair.removeSuffix("JPY")]?.let { base -> strengthScores["JPY"]?.let { base - it } }
            JSONObject()
                .put("at_jst", at)
                .put("instrument", pair)
                .put("direction", direction)
                .put("strength_gap_percent", gap ?: JSONObject.NULL)
                .put("direction_aligned", gap?.let { (direction == "HIGH" && it > 0.0) || (direction == "LOW" && it < 0.0) } ?: JSONObject.NULL)
                .put("ranking_weight", 0.0)
        } ?: JSONObject.NULL
        val selectedCandidateJson: Any = strengthCandidate?.let { (at, pair, direction) ->
            JSONObject()
                .put("at_jst", at)
                .put("instrument", pair)
                .put("direction", direction)
                .put("source", if (s.oneMinuteScan?.atJst == at) s.oneMinuteScan?.source else s.scan?.source)
                .put("entry_time_jst", if (s.oneMinuteScan?.atJst == at) s.oneMinuteScan?.entryTimeJst else s.scan?.entryTimeJst)
                .put("judge_time_jst", if (s.oneMinuteScan?.atJst == at) s.oneMinuteScan?.judgeTimeJst else s.scan?.judgeTimeJst)
        } ?: JSONObject.NULL
        val root = JSONObject()
            .put("horizon_policy", horizonRuntime.diagnosticStats())
            .put("generated_at_jst", ZonedDateTime.now(jst).toString())
            .put("app", "GMK MOBILE Rule v${BuildConfig.VERSION_NAME}")
            .put("version_code", BuildConfig.VERSION_CODE)
            .put("connected_6", s.connected)
            .put("available_6", allRatesAvailable(s.rates))
            .put("live_6", allFresh(s.rates))
            .put("busy", s.busy)
            .put("error", s.error ?: JSONObject.NULL)
            .put("rate_status", s.rateStatus ?: JSONObject.NULL)
            .put("scan_status", s.scanStatus ?: JSONObject.NULL)
            .put("auto_scan", s.autoScan)
            .put("fx_provider", "YahooFinanceChart-keyless")
            .put("fx_provider_official_api", false)
            .put("fx_provider_freshness_gate_seconds", 20)
            .put("btc_provider", "bitbank-public")
            .put("battery_optimization_exempt", s.batteryOptimizationExempt)
            .put("background_restricted", s.backgroundRestricted)
            .put("runtime_service", GmkRuntimeServiceControl.diagnosticStats(getApplication<Application>()))
            .put("market_network_stats", repository.diagnosticStats())
            .put("btc_network_stats", bitcoinRepository.diagnosticStats())
            .put("forex_network_stats", forexRepository.diagnosticStats())
            .put("btc_realtime_stream", bitcoinRealtime.diagnosticStats())
            .put("btc_independent_of_yahoo_and_scans",true)
            .put("btc_live_gate_seconds",MarketRepository.BTC_MAX_LIVE_AGE_SECONDS)
            .put("outcome_network_stats", outcomeRepository.diagnosticStats())
            .put("history_persistence_stats", historyStore.diagnosticStats())
            .put("history_initialized", historyInitialized)
            .put("history_mutations_dispatcher", "IO")
            .put("history_last_published_ms", s.lastHistoryPublishedMs)
            .put("history_last_settled_publish_delay_ms", s.lastSettledHistoryPublishDelayMs ?: JSONObject.NULL)
            .put("outcome_capacity_scope", "INDIVIDUAL_REQUEST; RETRY_WAIT_RELEASES_PERMIT")
            .put("outcome_exact_minute_open_preserved", true)
            .put("outcome_active_jobs", outcomeJobs.values.count { it.isActive })
            .put("outcome_unexpected_retry_entries", outcomeUnexpectedRetryCounts.size)
            .put("auto_network_reservation_active", shouldReserveYahooForUpcomingAuto())
            .put("last_rate_update_ms", s.lastRateUpdateMs)
            .put("last_rate_success_ms", s.lastRateSuccessMs)
            .put("last_auto_boundary_key", lastAutoBoundaryKey ?: JSONObject.NULL)
            .put("last_scan_attempt_ms", s.lastScanAttemptMs)
            .put("last_scan_success_ms", s.lastScanSuccessMs)
            .put("rate_live_count", s.rateLiveCount)
            .put("rate_available_count", s.rateAvailableCount)
            .put("scannable_count", s.scannableCount)
            .put("last_scan_excluded", JSONObject(s.lastScanExcluded))
            .put("last_candle_errors", JSONObject(s.lastCandleErrors))
            .put("last_candle_latest_ms", JSONObject(s.lastCandleLatestMs))
            .put("quote_candle_divergence_pct", JSONObject(s.quoteCandleDivergencePct))
            .put("last_scan_full_coverage", s.scan?.candidates?.size == 6)
            .put("last_scan_candidate_count", s.scan?.candidates?.size ?: 0)
            .put("selected_candidate", selectedCandidateJson)
            .put("network_error_count", s.networkFailureCount)
            .put("last_network_error", s.lastNetworkError ?: JSONObject.NULL)
            .put("one_minute_mode", "SMARTPHONE_LOCAL_1M")
            .put("one_minute_auto_scan", s.oneMinuteAutoScan)
            .put("chart_sync", JSONObject()
                .put("instrument", s.chartInstrument)
                .put("timeframe", s.chartTimeframe)
                .put("candle_count", s.chartCandles.size)
                .put("latest_candle_ms", s.chartCandles.lastOrNull()?.timeEpochMs ?: JSONObject.NULL)
                .put("updated_at_ms", s.chartUpdatedAtMs)
                .put("loading", s.chartLoading)
                .put("error", s.chartError ?: JSONObject.NULL))
            .put("currency_strength_sync", JSONObject()
                .put("timeframe", s.strengthTimeframe)
                .put("instrument_count", s.strengthCandles.count { it.value.isNotEmpty() })
                .put("updated_at_ms", s.strengthUpdatedAtMs)
                .put("loading", s.strengthLoading)
                .put("errors", JSONObject(s.strengthErrors))
                .put("candidate_check", candidateStrengthCheck))
            .put("cut_in_queue", JSONObject().put("pending", cutInEvents.pendingCount())
                .put("active_key", cutInEvents.activeKey() ?: JSONObject.NULL)
                .put("expired_events", cutInEvents.expiredCount())
                .put("max_dispatch_delay_ms", cutInEvents.maxDispatchDelayMs()))
            .put("cut_in_enabled", s.cutInEnabled)
            .put("cut_in_shown_count", s.cutInShownCount)
            .put("cut_in_last_type", s.lastCutInType ?: JSONObject.NULL)
            .put("cut_in_last_scan_id", s.lastCutInScanId ?: JSONObject.NULL)
            .put("cut_in_last_instrument", s.lastCutInInstrument ?: JSONObject.NULL)
            .put("cut_in_last_at_jst", s.lastCutInAtJst ?: JSONObject.NULL)
            .put("cut_in_suppressed_reason", s.lastCutInSuppressedReason ?: JSONObject.NULL)
            .put("cut_in_suppressed_scan_id", s.lastCutInSuppressedScanId ?: JSONObject.NULL)
            .put("one_minute_busy", s.oneMinuteBusy)
            .put("one_minute_status", s.oneMinuteStatus ?: JSONObject.NULL)
            .put("outcome_status", s.outcomeStatus ?: JSONObject.NULL)
            .put("outcome_pending_count", s.history.count { it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") })
            .put("outcome_win_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "WIN" })
            .put("outcome_lose_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" })
            .put("entry_win_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "WIN" })
            .put("entry_lose_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" })
            .put("skip_shadow_resolved_count", s.history.count {
                it.decision == "SKIP" && it.resultStatus in setOf("WIN", "LOSE")
            })
        val selections = JSONArray()
        s.history.groupBy { "${it.policyVersion}|${it.source}|${it.instrument}" }.forEach { (_, rows) ->
            val row = rows.first()
            selections.put(JSONObject().put("policy_version", row.policyVersion).put("source", row.source)
                .put("instrument", row.instrument).put("selected_count", rows.size)
                .put("entry_count", rows.count { it.decision == "ENTRY" })
                .put("skip_count", rows.count { it.decision == "SKIP" }))
        }
        root.put("selection_counts_by_policy_source_symbol", selections)
            .put("rank_assessment_contract", "GMK_V0742_CHART200_EH_SEPARATE_NATIVE_TRACE")
            .put("strength_status", "UNVALIDATED")
            .put("calibrated_strength_available", s.scan?.candidates?.any { it.assessment?.chartRank?.grade in setOf("E", "F", "G", "H") } == true)
            .put("probability_definition", "CHART200_EH_ESTIMATE_IN_ASSESSMENT; LEGACY_RULE_AVERAGE_IN_PROBABILITY; STRENGTH_UNVALIDATED")
        val lastCandidates = JSONArray()
        s.scan?.candidates?.forEach { c -> lastCandidates.put(JSONObject().put("rank", c.rank)
            .put("instrument", c.instrument).put("direction", c.direction).put("grade", c.grade)
            .put("decision", c.decision).put("probability", c.probability ?: JSONObject.NULL)
            .put("assessment", AssessmentJsonCodec.encode(c.assessment) ?: JSONObject.NULL)
            .put("score", c.score).put("regime", c.regime).put("reasons", JSONArray(c.reasons))) }
        root.put("last_scan_candidates", lastCandidates)
        val rates = JSONArray()
        s.rates.forEach { r -> rates.put(JSONObject()
            .put("instrument", r.instrument).put("price", r.price ?: JSONObject.NULL)
            .put("last", r.price ?: JSONObject.NULL)
            .put("bid", r.bid ?: JSONObject.NULL).put("ask", r.ask ?: JSONObject.NULL)
            .put("source", r.source).put("age_seconds", r.ageSeconds ?: JSONObject.NULL)
            .put("fetch_age_seconds", r.fetchAgeSeconds ?: JSONObject.NULL)
            .put("freshness", r.freshnessStatus)) }
        root.put("rates", rates)
        val historyJson = JSONArray()
        val horizonStats = JSONArray()
        fun addStats(rows: List<HistoryRow>, scope: String) {
            historyStatistics(rows).forEach { (minutes, counts) ->
                horizonStats.put(JSONObject().put("scope",scope).put("expiry_minutes",minutes)
                    .put("wins",counts.wins).put("losses",counts.losses).put("draw_losses",counts.draws)
                    .put("resolved_entries",counts.resolved()).put("win_rate_pct",counts.winRate() ?: JSONObject.NULL)
                    .put("entry_count",counts.entries).put("skip_count",counts.skips)
                    .put("skip_shadow_count",counts.skipShadow).put("pending",counts.pending).put("missing",counts.missed)
                    .put("current_loss_streak",counts.currentLossStreak).put("max_consecutive_losses",counts.maxConsecutiveLosses)
                    .put("runs_at_least_3",counts.runsAtLeast3).put("runs_at_least_5",counts.runsAtLeast5))
            }
        }
        addStats(s.history,"ALL_HISTORY")
        s.history.groupBy { it.policyVersion }.forEach { (version,rows) -> addStats(rows,version) }
        s.history.groupBy { "${it.policyVersion}|source=${it.source}" }.forEach { (version,rows) -> addStats(rows,version) }
        val combined = historyCombinedStatistics(s.history)
        root.put("combined_outcome_statistics",JSONObject()
            .put("current_loss_streak",combined.currentLossStreak).put("max_consecutive_losses",combined.maxConsecutiveLosses)
            .put("runs_at_least_3",combined.runsAtLeast3).put("runs_at_least_5",combined.runsAtLeast5))
            .put("loss_streak_definition","UTC_ENTRY_ORDER; RESOLVED_ENTRY_RESULTS; SKIP_PENDING_MISSING_DO_NOT_RESET; DRAW_IS_LOSS")
        root.put("outcome_statistics",horizonStats).put("win_rate_definition","ENTRY_AND_WIN_OR_LOSE; DRAW_IS_LOSS; SKIP_PENDING_MISSING_EXCLUDED")
            .put("expiry_profile",if(s.forceThreeMinuteOutcome) "THREE_MINUTE_FIXED" else "DIRECT19_3_5_WITH_PC_OUTSIDE_SESSION")
            .put("result_history_total_count",s.history.size).put("result_history_exported_count",minOf(3000,s.history.size))
            .put("result_history_truncated",s.history.size>3000)
        s.history.take(3000).forEach { h ->
            historyJson.put(JSONObject()
                .put("scan_id", h.scanId)
                .put("source", h.source)
                .put("instrument", h.instrument)
                .put("direction", h.direction)
                .put("grade", h.grade)
                .put("decision", h.decision)
                .put("assessment", AssessmentJsonCodec.encode(h.assessment) ?: JSONObject.NULL)
                .put("policy_version",h.policyVersion)
                .put("expiry_minutes",h.statisticsRow().minutes())
                .put("entry_time_jst", h.entryTimeJst)
                .put("judge_time_jst", h.judgeTimeJst)
                .put("entry_rate", h.entryRate ?: JSONObject.NULL)
                .put("judge_rate", h.judgeRate ?: JSONObject.NULL)
                .put("entry_rate_source",h.entryRateSource).put("judge_rate_source",h.judgeRateSource)
                .put("entry_captured_at_jst",h.entryCapturedAtJst).put("settled_at_jst",h.settledAtJst)
                .put("entry_capture_delay_ms", h.entryCaptureDelayMs ?: JSONObject.NULL)
                .put("judge_capture_delay_ms", h.judgeCaptureDelayMs ?: JSONObject.NULL)
                .put("entry_provider_age_seconds", h.entryProviderAgeSeconds ?: JSONObject.NULL)
                .put("judge_provider_age_seconds", h.judgeProviderAgeSeconds ?: JSONObject.NULL)
                .put("result_status", h.resultStatus))
        }
        root.put("result_history", historyJson)
        root.put("run_regime", s.runRegime?.let { rr -> JSONObject().put("level", rr.level.name).put("yen_vr", rr.yen ?: JSONObject.NULL)
            .put("pairs", JSONObject().also { o -> rr.pairs.forEach { (k, v) -> o.put(k, v ?: JSONObject.NULL) } }).put("updated_at_ms", rr.updatedAtMs) } ?: JSONObject.NULL)
            .put("run_regime_error", s.runRegimeError ?: JSONObject.NULL)
            .put("auto_slot_log", JSONObject().put("counts", JSONObject(AutoSlotLog.counts() as Map<*, *>)).put("recent", org.json.JSONArray(AutoSlotLog.recent())))
            .put("outcome_repair", JSONObject().put("rows_retried", outcomeRepairAttempts.size).put("retries", outcomeRepairAttempts.values.sum())
                .put("missed_now", historyStore.rows.value.count { it.resultStatus in OutcomeRepair.MISSED }))
            .put("minute_gap_fill", JSONObject().also { o -> jp.gmk.mobile.domain.GapFillBoard.snapshot().forEach { (k, e) ->
                o.put(k, JSONObject().put("distinct_filled_minutes", e.distinctFilled).put("recent_jst", org.json.JSONArray(e.recentJst))) } })
        // v0.7.50: results by operational grade (3-minute per version x weekday/weekend; D..H = "if entered" observation).
        val rankTables = JSONArray()
        RankStatistics.tables(s.history).forEach { t ->
            val lines = JSONArray()
            t.counts.forEach { c ->
                lines.put(JSONObject().put("grade", c.grade).put("skipped_by_setting", c.skipped).put("total", c.total).put("wins", c.wins).put("losses", c.losses)
                    .put("pending", c.pending).put("unresolved", c.unresolved)
                    .put("observation_only", RankStatistics.isSkipCount(t, c))
                    .put("validated_rate", t.validated[c.grade] ?: JSONObject.NULL))
            }
            rankTables.put(JSONObject().put("key", t.key).put("title", t.title).put("one_minute", t.oneMinute).put("grades", lines))
        }
        root.put("rank_statistics", rankTables)
        // v0.7.52: how often the backup model (no live price within 40 s) decided a 3-minute slot.
        val evidenceRows = s.history.filter { RankStatistics.evidenceVersion(it.policyVersion) != null && RankStatistics.evidenceVersion(it.policyVersion) == RankStatistics.evidenceVersion(EvidencePolicy.POLICY_TAG) }
        root.put("evidence_live_price", JSONObject().put("rows", evidenceRows.size)
            .put("backup_model_rows", evidenceRows.count { it.assessment?.correctionLabel?.contains("予備モデル") == true })
            .put("rule_rows", evidenceRows.count { it.assessment?.correctionLabel?.contains("時間帯ルール") == true })
            // v0.7.57: rows by judgement length (time-of-day rules 3 minutes, other weekday trades 5 minutes)
            .put("three_minute_rows", evidenceRows.count { SignalAlerts.minutesBetween(it.entryTimeJst, it.judgeTimeJst) == 3 })
            .put("five_minute_rows", evidenceRows.count { SignalAlerts.minutesBetween(it.entryTimeJst, it.judgeTimeJst) == 5 })
            .put("caution_rows", evidenceRows.count { it.assessment?.correctionLabel?.contains("（注意）") == true })
            .put("demoted_rows", evidenceRows.count { r -> r.assessment?.correctionLabel?.let { l -> listOf("55%未満", "旧Cのうち強さが下位", "9時台（仲値の前）", "追いかける", "土日の普通の強さ", "土日のC", "平日5分のC", "平日毎分のC").any { it in l } } == true }))
        // v0.7.56: ENTRY amount setting and the share of AUTO slots entered, by JST hour (current version rows).
        root.put("entry_mode", JSONObject().put("key", prefs.entryMode).put("label", EntryMode.parse(prefs.entryMode).label)
            .put("summary", EntryMode.parse(prefs.entryMode).summary))
        val shareJson = JSONObject()
        RankStatistics.entryShareByHour(evidenceRows).forEach { (seg, hours) ->
            val h = JSONObject(); hours.forEach { (hour, c) -> h.put(hour.toString(), JSONObject().put("slots", c.first).put("entry", c.second)) }
            shareJson.put(seg, h)
        }
        root.put("entry_share_by_hour", shareJson)
        // v0.7.54: provider stamps ahead of the phone clock (bitbank, ms) - estimate of how far the phone clock is behind.
        val nowForClock = System.currentTimeMillis()
        root.put("provider_clock", JSONObject().put("max_ahead_ms_10min", ProviderClock.maxAheadMs(nowForClock))
            .put("tolerance_ms", ProviderClock.MAX_AHEAD_MS).put("accepted", ProviderClock.counts().first).put("too_far_ahead", ProviderClock.counts().second))
        root.put("signal_notifications", JSONObject().put("enabled", prefs.signalNotify).put("min_grade", prefs.notifyMinGrade)
            .put("permitted", runCatching { jp.gmk.mobile.runtime.GmkSignalNotifier.permitted(appContext) }.getOrDefault(false))
            .put("posted", jp.gmk.mobile.runtime.GmkSignalNotifier.posted).put("failed", jp.gmk.mobile.runtime.GmkSignalNotifier.failed)
            .put("last_error", jp.gmk.mobile.runtime.GmkSignalNotifier.lastError ?: JSONObject.NULL)
            .put("next_rule", SignalAlerts.nextRuleText(ZonedDateTime.now(jst))))
        // v0.7.55: real results by the age of the live price used (label "直前価格 N.N秒前"), current version only.
        val ageRe = Regex("直前価格 ([0-9]+(?:\\.[0-9]+)?)秒前")
        val ageBuckets = linkedMapOf("0-10s" to IntArray(4), "10-20s" to IntArray(4), "20-30s" to IntArray(4), "30s+" to IntArray(4))
        evidenceRows.forEach { r ->
            val sec = r.assessment?.correctionLabel?.let { ageRe.find(it)?.groupValues?.get(1)?.toDoubleOrNull() } ?: return@forEach
            val key = when { sec < 10.0 -> "0-10s"; sec < 20.0 -> "10-20s"; sec < 30.0 -> "20-30s"; else -> "30s+" }
            val a = ageBuckets.getValue(key); val entry = r.decision == "ENTRY"
            when (r.resultStatus) { "WIN" -> a[if (entry) 0 else 2]++; "LOSE" -> a[if (entry) 1 else 3]++ }
        }
        root.put("live_price_age", JSONObject().apply {
            ageBuckets.forEach { (k, a) -> put(k, JSONObject().put("entry_wins", a[0]).put("entry_losses", a[1]).put("skip_if_entered_wins", a[2]).put("skip_if_entered_losses", a[3])) }
            put("late_refresh_attempts", liveRefreshAttempts); put("late_refresh_quotes", liveRefreshQuotes); put("late_refresh_skipped", liveRefreshSkipped)
            put("last_late_refresh_ms", lastLiveRefreshMs)
        })
        val oneMinuteObserved = s.history.filter { OneMinuteObservation.isObservation(it.policyVersion) }
        root.put("one_minute_observation", JSONObject().put("rows", oneMinuteObserved.size)
            .put("if_entered_wins", oneMinuteObserved.count { it.resultStatus == "WIN" })
            .put("if_entered_losses", oneMinuteObserved.count { it.resultStatus == "LOSE" }))

        s.oneMinuteScan?.let { scan ->
            root.put("last_one_minute_manual", JSONObject()
                .put("scan_id", scan.scanId)
                .put("source", scan.source)
                .put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst)
                .put("judge_time_jst", scan.judgeTimeJst)
                .put("policy_version", OneMinuteObservation.POLICY)
                .put("candidate_count", scan.candidates.size)
                .put("top1", scan.top1?.let { c ->
                    JSONObject()
                        .put("instrument", c.instrument)
                        .put("direction", c.direction)
                        .put("confidence", c.confidence)
                        .put("regime", c.regime)
                        .put("score", c.score)
                        .put("reasons", JSONArray(c.reasons))
                } ?: JSONObject.NULL))
        }

        s.scan?.let { scan ->
            val cands = JSONArray()
            scan.candidates.forEach { c -> cands.put(JSONObject()
                .put("rank", c.rank).put("instrument", c.instrument).put("direction", c.direction)
                .put("grade", c.grade).put("probability", c.probability ?: JSONObject.NULL)
                .put("assessment", AssessmentJsonCodec.encode(c.assessment) ?: JSONObject.NULL)
                .put("decision", c.decision).put("score", c.score)
                .put("regime", c.regime)
                .put("regime_confidence", c.regimeConfidence)
                .put("reasons", JSONArray(c.reasons))) }
            root.put("last_scan", JSONObject()
                .put("scan_id", scan.scanId).put("source", scan.source).put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst).put("judge_time_jst", scan.judgeTimeJst)
                .put("policy_version",scan.policyVersion)
                .put("warnings", JSONArray(scan.warnings)).put("candidates", cands))
        }
        return root.toString(2)
    }

    fun needsKeepAliveService(): Boolean {
        if (prefs.autoScan || prefs.oneMinuteAutoScan) return true
        // If the service is already running while history recovery is in progress, keep it alive
        // until pending manual outcomes have been reconstructed.
        if (!historyInitialized) return true
        if (outcomeJobs.values.any { it.isActive }) return true
        return _state.value.history.any {
            it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
        }
    }

    private fun syncForegroundRuntimeService() {
        val app = getApplication<Application>()
        val intent = Intent(app, GmkRuntimeKeepAliveService::class.java)
        val shouldStart = prefs.autoScan || prefs.oneMinuteAutoScan ||
            outcomeJobs.values.any { it.isActive } ||
            (historyInitialized && _state.value.history.any {
                it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE")
            })
        if (shouldStart) {
            GmkRuntimeServiceControl.start(app)
        } else {
            app.stopService(intent)
        }
        _state.value = _state.value.copy(
            runtimeServiceRunning = GmkRuntimeServiceControl.foregroundRunning,
            runtimeServiceError = GmkRuntimeServiceControl.lastError(app)
        )
    }

    fun setOneMinuteAuto(value: Boolean) {
        prefs.oneMinuteAutoScan = value
        _state.value = _state.value.copy(oneMinuteAutoScan = value)
        startOneMinuteAutoLoop()
        syncForegroundRuntimeService()
    }

    fun setForceThreeMinute(value: Boolean) {
        if (_state.value.busy || _state.value.oneMinuteBusy) return
        prefs.forceThreeMinuteOutcome = value
        _state.value = _state.value.copy(forceThreeMinuteOutcome = value)
    }

    fun setAuto(value: Boolean) {
        prefs.autoScan = value
        _state.value = _state.value.copy(autoScan = value)
        startAutoLoop()
        syncForegroundRuntimeService()
    }

    fun recordCutInShown(type: String, scanId: String, instrument: String) {
        val s = _state.value
        _state.value = s.copy(
            cutInShownCount = s.cutInShownCount + 1,
            lastCutInType = type,
            lastCutInScanId = scanId,
            lastCutInInstrument = instrument,
            lastCutInAtJst = ZonedDateTime.now(jst).toString(),
            lastCutInSuppressedReason = null,
            lastCutInSuppressedScanId = null
        )
    }

    fun recordCutInSuppressed(reason: String, scanId: String, instrument: String) {
        val s = _state.value
        if (s.lastCutInSuppressedReason == reason && s.lastCutInSuppressedScanId == scanId) return
        _state.value = s.copy(
            lastCutInSuppressedReason = reason,
            lastCutInSuppressedScanId = scanId,
            lastCutInInstrument = instrument
        )
    }

    fun setSignalNotify(value: Boolean) {
        prefs.signalNotify = value
        _state.value = _state.value.copy(signalNotify = value)
    }

    fun setNotifyMinGrade(value: String) {
        prefs.notifyMinGrade = value
        _state.value = _state.value.copy(notifyMinGrade = prefs.notifyMinGrade)
    }

    /** v0.7.56: ENTRY amount (55%優先 / 平日70% / 毎日（土日60%）); applies from the next scan. */
    fun setEntryMode(value: String) {
        prefs.entryMode = value
        _state.value = _state.value.copy(entryMode = prefs.entryMode)
    }

    fun setCutInEnabled(value: Boolean) {
        prefs.cutInEnabled = value
        if (!value) cutInEvents.clearVisibleAndPending()
        _state.value = _state.value.copy(cutInEnabled = value)
    }

    fun loadChart(instrument: String = _state.value.chartInstrument, timeframe: String = _state.value.chartTimeframe, focusEpochMs: Long? = null) {
        if (instrument !in setOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")) return
        if (timeframe !in setOf("1m", "5m", "15m", "1h", "4h", "1d")) return
        if (_state.value.busy || _state.value.oneMinuteBusy || shouldReserveYahooForUpcomingAuto()) {
            chartJob?.cancel()
            _state.value = _state.value.copy(
                chartInstrument = instrument,
                chartTimeframe = timeframe,
                chartCandles = emptyList(),
                chartLoading = false,
                chartUpdatedAtMs = 0L,
                chartError = "スキャンを優先中。次回更新時にチャートを取得します"
            )
            return
        }
        chartJob?.cancel()
        _state.value = _state.value.copy(
            chartInstrument = instrument,
            chartTimeframe = timeframe,
            chartCandles = emptyList(),
            chartLoading = true,
            chartUpdatedAtMs = 0L,
            chartError = null
        )
        chartJob = viewModelScope.launch {
            try {
                val result = withTimeout(20_000L) { repository.fetchChartCandles(instrument, timeframe, focusEpochMs) }
                val candles = result.candles
                val chartWarnings = buildList {
                    addAll(result.warnings)
                    if (candles.size < 34) add("取得足が少なく、BB20/MACD 12-26-9の表示範囲が限られます")
                }.take(3).joinToString(" / ").takeIf { it.isNotBlank() }
                if (isActive && _state.value.chartInstrument == instrument && _state.value.chartTimeframe == timeframe) {
                    _state.value = _state.value.copy(
                        chartCandles = candles,
                        chartLoading = false,
                        chartError = chartWarnings,
                        chartUpdatedAtMs = System.currentTimeMillis()
                    )
                    refreshNetworkDiagnosticState()
                }
            } catch (timeout: TimeoutCancellationException) {
                if (isActive && _state.value.chartInstrument == instrument && _state.value.chartTimeframe == timeframe) {
                    _state.value = _state.value.copy(chartLoading = false, chartError = "チャート取得がタイムアウトしました。再取得できます")
                    refreshNetworkDiagnosticState()
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Exception) {
                if (isActive && _state.value.chartInstrument == instrument && _state.value.chartTimeframe == timeframe) {
                    _state.value = _state.value.copy(chartLoading = false, chartError = t.message ?: "チャート取得に失敗しました")
                    refreshNetworkDiagnosticState()
                }
            }
        }
    }

    fun loadStrength(timeframe: String = _state.value.strengthTimeframe) {
        if (timeframe !in setOf("1m", "5m", "15m", "1h", "4h", "1d")) return
        if (_state.value.busy || _state.value.oneMinuteBusy || shouldReserveYahooForUpcomingAuto()) {
            strengthJob?.cancel()
            _state.value = _state.value.copy(
                strengthTimeframe = timeframe,
                strengthCandles = emptyMap(),
                strengthLoading = false,
                strengthUpdatedAtMs = 0L,
                strengthErrors = mapOf("sync" to "スキャンを優先中。次回更新時に通貨足を取得します")
            )
            return
        }
        strengthJob?.cancel()
        _state.value = _state.value.copy(
            strengthTimeframe = timeframe,
            strengthCandles = emptyMap(),
            strengthLoading = true,
            strengthUpdatedAtMs = 0L,
            strengthErrors = emptyMap()
        )
        strengthJob = viewModelScope.launch {
            try {
                val batch = withTimeout(25_000L) { repository.fetchAllChartCandles(timeframe) }
                if (isActive && _state.value.strengthTimeframe == timeframe) {
                    _state.value = _state.value.copy(
                        strengthCandles = batch.candles,
                        strengthErrors = batch.errors,
                        strengthLoading = false,
                        strengthUpdatedAtMs = System.currentTimeMillis()
                    )
                    refreshNetworkDiagnosticState()
                }
            } catch (timeout: TimeoutCancellationException) {
                if (isActive && _state.value.strengthTimeframe == timeframe) {
                    _state.value = _state.value.copy(strengthLoading = false, strengthErrors = mapOf("all" to "通貨強弱の取得がタイムアウトしました。再取得できます"))
                    refreshNetworkDiagnosticState()
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Exception) {
                if (isActive && _state.value.strengthTimeframe == timeframe) {
                    _state.value = _state.value.copy(
                        strengthLoading = false,
                        strengthErrors = mapOf("all" to (t.message ?: "通貨強弱の取得に失敗しました"))
                    )
                    refreshNetworkDiagnosticState()
                }
            }
        }
    }

    fun loadHistory() {
        _state.value = _state.value.copy(history = historyStore.rows.value)
    }

    fun saveSettings(token: String, accountId: String, environment: String, yahooFallback: Boolean) {
        // v0.7.8: OANDA runtime dependency removed. Keep signature only for source compatibility.
        prefs.yahooFallback = true
        _state.value = _state.value.copy(
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = true,
            rateStatus = "設定を保存しました。レート再接続中",
            error = null
        )
        startRateLoop()
    }

    fun shutdownRuntime() {
        horizonRuntime.stop()
        rateJob?.cancel()
        bitcoinJob?.cancel()
        bitcoinRealtime.stop()
        bitcoinRepository.cancelInFlightRequests()
        forexRepository.cancelInFlightRequests()
        chartJob?.cancel()
        strengthJob?.cancel()
        autoJob?.cancel()
        oneMinuteAutoJob?.cancel()
        oneMinuteJob?.cancel()
        ruleAlertJob?.cancel()
        outcomeRecoveryJob?.cancel()
        outcomeRepairJob?.cancel()
        outcomeJobs.values.forEach { it.cancel() }
        repository.cancelInFlightRequests()
        outcomeRepository.cancelInFlightRequests()
    }

    override fun onCleared() {
        shutdownRuntime()
        super.onCleared()
    }
}

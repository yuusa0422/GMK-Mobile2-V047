# GMK MOBILE Rule v0.5.2 深掘り横断監査

## 今回修正した重要不具合

1. 6通貨のうち1通貨でもローソク取得に例外が出ると、coroutineScope全体が失敗しスキャン不能
   - 修正: 通貨ごとに例外を隔離。失敗通貨だけ対象外にして他通貨の判定を継続。

2. 6通貨すべて30本以上・180秒以内でなければスキャン全体を強制停止
   - 修正: 判定可能通貨だけで部分スキャン可能。
   - 古い足は無理に使わない。
   - 240秒超は対象外として理由をUI/診断へ表示。

3. レート取得とスキャン可否が混同されていた
   - 修正: LIVE数 / 取得数 / 判定可能数を分離。

4. OANDAが一部通貨だけ取得できた場合、その結果を全部捨ててYahooへ切替
   - 修正: OANDA結果を保持し、不足・STALE通貨だけYahooで補完。

5. Yahooへ2秒ごとに5通貨アクセスし続け、レート制限や通信不安定化を起こしやすい
   - 修正: 6秒間隔へ緩和。

6. 旧UIは price!=null だけで「6通貨 最新値取得済み」と表示
   - 修正: 6/6 LIVE / LIVE x/6 / 取得 y/6 を分離表示。

7. 成功済みスキャンがあると、その後判定対象外になった通貨が一覧から見えない
   - 修正: 「今回の判定対象外」を追加し全6通貨の状態を確認可能。

8. スキャン失敗理由が一括エラーだけ
   - 修正: 通貨ごとの取得失敗・足不足・STALE秒数を保持し診断JSONへ出力。

9. OANDAトークンがSharedPreferences保存なのにAndroid backup許可
   - 修正: android:allowBackup=false。

10. REGIME判定が画面で見えない
    - 修正: TOP1と候補一覧にTREND_UP / TREND_DOWN / RANGE / CHOPPYと信頼度を表示。

## 維持した安全条件

- 未来足は使わない。
- 現在進行中1分足はローソク履歴から除外。
- 古い市場データを最新値と偽装しない。
- D以外はENTRY、DのみSKIPというルール契約は判定可能候補について維持。
- トレンド切替直後の逆張りD/SKIPガードを維持。
- REGIMEそのものはD/SKIP量産器にしない。
- 5分境界10秒前AUTO、3分判定を維持。

## 診断JSON追加項目

- rate_live_count
- rate_available_count
- scannable_count
- last_scan_excluded
- last_candle_errors
- candidate.regime
- candidate.regime_confidence

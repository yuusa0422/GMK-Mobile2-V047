# GMK Mobile v0.7.7 Final Rank Rescue Production Audit

## Production policy
- Active window: JST 09:00 <= hour < 23:00
- Base matcher: v0.7.6 matching order preserved exactly.
- Base rule is selected first, then rank is remapped by the 2026-primary / 2025-guard table.
- Only E/no-match candidates enter the rescue stages.
- Rescue stage 1: 172 deterministic rules (1-3 feature conditions).
- Rescue stage 2: 244 deterministic rules (4 feature conditions).
- Direct and HIGH/LOW reversal rescues are both supported.
- S/A/B/C = ENTRY; E = SKIP.

## 2026 replay target
- ENTRY rows: 35,784
- Usable/graded ENTRY rows: 31,863
- E/SKIP rows: 2,856
- Overall graded win rate: 61.2183%

### Period win rates
- Jan-Apr: 59.7994%
- May-Jun: 62.3249%
- Jul-Aug18: 63.5146%

### Rescue ranks (E-origin candidates)
- S: 237 rows, 199 usable, 80.9045%
- A: 1,178 rows, 981 usable, 72.8848%
- B: 6,807 rows, 6,050 usable, 65.4876%
- C: 17,510 rows, 15,621 usable, 59.5096%
- E remains: 2,856 rows, 2,505 usable, 50.9780%

## Verification
- Functional contract test: PASS 18/18
- Kotlin domain compile: PASS
- No AI/LLM inference is used.
- FX provider remains keyless Yahoo Chart with freshness/fail-safe from v0.7.6.
- BTCJPY provider remains bitbank public API.

# GMK MOBILE RULE v0.7.9 深掘り監査

対象: v0.7.8 Deep Audit Fix を基準に追加監査。

## 今回確定・修正した不具合

1. **直近完成M1欠損を許容する問題**
   - 旧実装は3分側で最大240秒、1分側で最大180秒の古さを許容していた。
   - T-10で直近1〜2本の完成足が欠けても候補化される可能性があり、Replay前提と不一致。
   - v0.7.9では `current minute start - 1 minute` の完成足が存在することを必須化。
   - 1分/3分の両方へ適用。

2. **旧SKIP履歴の result_status 復元誤り**
   - result_statusを持たない旧SKIP行が WAIT_ENTRY として復元される経路があった。
   - outcome追跡はENTRYのみなので誤取引にはならないが、画面/診断pending件数が不正になる。
   - v0.7.9では decision=SKIP の旧行は必ず `SKIP` として復元。

3. **F/G/H/Iランク契約の将来互換不足**
   - HistoryStoreはF〜Iを認識していたが、ViewModel側のランク契約はD/Eまでだった。
   - 現行FinalRankPolicyは最終出力をS/A/B/C/Eへ正規化するため直近では発火しないが、将来F〜Iを直接返す変更でクラッシュ/誤ENTRYの恐れ。
   - v0.7.9ではD/E/F/G/H/IをSKIP契約として統一。

## 過学習リスクへの本番ガード

第2段E救済(4特徴条件)には少数標本ルールが混在していた。
- Stage1: 172本、n<20は1本
- Stage2: 244本、n<20が90本、n<15が44本

v0.7.9ではStage2を **usable sample >=25** に限定。
研究値だけを最大化する小標本ルールを本番から除外した。

### 2026年・09:00-23:00 保守Replay（Stage2 n>=25）
- ENTRY: 33,643
- E/SKIP: 4,997
- 採点可能ENTRY: 29,940
- 全体勝率: 60.354%
- 1〜4月: 59.152%
- 5〜6月: 61.219%
- 7〜8/18: 62.402%
- S: 81.081% (usable 37)
- A: 71.967% (usable 717)
- B: 64.538% (usable 7,236)
- C: 58.560% (usable 21,950)
- E(除外群): 49.684% (usable 4,428)

## 継続注意事項

- Yahoo Finance Chartは口座/APIキー不要だが非公式エンドポイント。取得不能/仕様変更時は6/6 strict gateでENTRYしない。
- FX5通貨が閉場する土日は6/6条件を満たさないため、現行3分本番はBTC単独ENTRYを行わない。BTC週末専用ルールは別Replay検証が必要。
- この環境ではAndroid Gradle assemble全体は実行していない。domain Kotlin compileと機能契約テストは実行済み。GitHub workflowに全体compile/assemble工程あり。

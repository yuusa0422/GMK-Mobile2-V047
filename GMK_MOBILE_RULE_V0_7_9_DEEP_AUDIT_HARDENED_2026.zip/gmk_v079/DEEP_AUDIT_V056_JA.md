# GMK MOBILE Rule v0.5.6 再監査

V0.5.5生成物そのものを再監査し、生成工程由来の問題も修正。

1. Kotlin Regex文字列に不正な\s escapeが入る可能性を検出
   - raw triple-quoted Regexへ修正。
2. build.yml先頭に余計なバックスラッシュが入る生成不具合を検出
   - workflowを完全再生成。
3. scan開始時cancelAllされたrate HTTPがgeneric IOExceptionとなりretryして競合復活する問題
   - RequestAbortedExceptionを追加しnon-retryable化。
4. cancelAll後にYahoo query2からquery1/OANDAからYahooへfallbackを続ける問題
   - RequestAbortedExceptionは全fallback層で即propagate。
5. cached source文字列が失敗のたびに"cache cache"と増える問題
   - removeSuffix(" cache")で正規化。
6. Workflowが無関係ZIPを選ぶ可能性
   - GMK_MOBILE_RULE_*.zipだけを候補化。
7. ZIP path traversal対策なし
   - safe_extractでbuildsrc外へ出るentryを拒否。
8. Workflowにsource ZIP SHA-256表示を追加。

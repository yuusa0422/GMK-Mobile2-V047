# GMK MOBILE Rule v0.5.5 追加深掘り監査

V0.5.4から追加で修正した主な不具合:

1. BTCレート取得のrunCatchingがCancellationExceptionを飲み込む可能性
   - 修正: cancellationを必ず再throw。

2. 一部レート取得失敗が「成功扱い」で旧レートを消す
   - 修正: 新値がUNAVAILABLEなら直前値をLAST/cacheとして保持。LIVEとは明確に区別。

3. レート更新がT-10直前に開始済みだとスキャンと通信競合
   - 修正: スキャン開始時に非重要なin-flightレートHTTPをcancelAllしてからローソク取得。

4. HTTP 401/403/404等まで無駄にretry
   - 修正: retryは408/425/429/5xxと通信例外だけ。認証・要求エラーは即時終了。

5. CancellableContinuationのcancel/resume競合
   - 修正: tryResume/tryResumeWithException + completeResumeに変更。

6. bitbankのlastが欠けてもbid/askが使えるのにSTALE扱い
   - 修正: 実際に採用したpriceの有無とageでLIVE/LAST/UNAVAILABLE判定。

7. OANDA/bitbankのNaN/Infinity/0/負値・crossed bid/ask検証不足
   - 修正: finite positive validationとquote整合性チェック。

8. 未来timestampローソク混入防止不足
   - 修正: 現在+90秒より未来の足を正規化段階で除外。

9. 履歴JSONの1行破損で全履歴が消える
   - 修正: 行単位で不正データをskip。JSON全体破損はcorrupt backupへ保存。

10. AUTO OFFで実行中AUTOが止まらない
    - 修正: AUTO設定切替時にschedulerをrestartし、進行中AUTO coroutineをcancel。

11. performScanが一般CancellationExceptionを通常エラーとして握り潰す
    - 修正: 状態を停止へ戻した後にrethrow。

12. 新スキャン開始時に前回の対象外理由/判定可能数が残る
    - 修正: scan開始時にcurrent scan/対象外/error detailをclear。

13. 診断ログのapp versionがhardcode
    - 修正: BuildConfig.VERSION_NAME/VERSION_CODEを使用。

14. 診断に各通貨の最終ローソクtimestampが無い
    - 修正: last_candle_latest_ms追加。

15. 診断ログ保存失敗がUI上無言
    - 修正: 実際のstream open/write/flush成否をToast表示。

16. レート行でageが見えない
    - 修正: LIVE/LASTの横に秒数表示。

17. AUTOカウントダウンが:50直後に即4:59へ飛ぶ表示
    - 修正: 1秒未満は00:00表示を維持。

18. GitHubに旧ZIPと新ZIPが共存すると古いZIPを選ぶ可能性
    - 修正: ファイル名からVx.y.zを解析して最高version ZIPを必ず選択。

19. GitHub repoに古い展開済みprojectがあると新ZIPを無視する可能性
    - 修正: ZIPが存在する場合はZIPを優先して毎回clean extract。

20. WorkflowのAPK metadata検証がversion固定で次版で壊れる
    - 修正: source build.gradle.ktsからapplicationId/versionCode/versionNameを読み、生成APKと動的照合。

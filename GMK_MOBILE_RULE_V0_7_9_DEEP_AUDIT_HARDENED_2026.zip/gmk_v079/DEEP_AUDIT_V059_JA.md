# GMK MOBILE Rule v0.5.9 追加深掘り監査

V0.5.8からさらに修正した項目:

1. 新しいproviderレスポンスに価格があるだけで、より新しいcached LIVE値を上書きできた
- mergeRatesをfreshness/age比較へ変更。
- 古いLASTが新しいLIVEを上書きしない。

2. providerが6通貨すべてUNAVAILABLEでもlast_rate_success_msを更新
- 実価格が1件以上返ったときだけ成功時刻を更新。

3. scheduler停止検出がSystem.currentTimeMillisだけ
- 手動時刻変更/NTP補正で誤MISSEDの余地。
- SystemClock.elapsedRealtimeによるmonotonic gap検出へ変更。

4. 部分スキャンのTOP1が通常TOP1と同じ表示
- TOP1（部分 n/6）と明示。
- warningsにも「利用可能通貨内の順位」と記録。

5. 最新quoteと最新完了1分足closeの価格整合監査が無い
- LIVE quoteとcandle closeの乖離率を算出。
- FX 0.50%以上 / BTC 1.50%以上は警告。
- これは診断警告だけでD/SKIPにはしない。

6. quote/candle乖離が診断JSONに無い
- quote_candle_divergence_pct追加。

7. 診断で部分スキャンか6/6か即判別できない
- last_scan_full_coverage / last_scan_candidate_count追加。

方針:
- D/SKIPは増やしていない。
- quote/candle乖離は観測・警告だけでENTRY可否を変えない。
- 部分スキャンを禁止せず、TOP1の意味だけ明確化。

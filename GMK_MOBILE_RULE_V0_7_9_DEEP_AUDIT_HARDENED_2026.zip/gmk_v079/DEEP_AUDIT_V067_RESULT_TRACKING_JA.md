# GMK MOBILE Rule v0.6.7 — 結果追跡 追加深掘り監査

V0.6.6をさらに横断監査して修正。

## 重大修正
1. 手動スキャンの市場データ取得timeoutが18秒だった
   - ENTRYはスキャン開始+10秒なのに、結果がENTRY後に完成する矛盾があった。
   - 手動取得を残り時間連動timeoutへ変更。
   - ルール計算前/計算後の両方で+10秒ENTRY deadlineを監査。
   - ENTRY直前/超過なら予測を公開しない。

2. 旧バージョン履歴が永遠にWAIT_ENTRY表示になる
   - scan_id / entry_time / judge_timeがない旧履歴をLEGACY_NO_OUTCOMEへ移行。
   - 旧履歴を結果追跡対象にしない。

3. 複数の結果追跡JobによるSharedPreferences load-modify-save競合
   - HistoryStoreのload/add/update/settle/pendingをsynchronized化。
   - 別スキャンのENTRY/JUDGE更新が互いを消す危険を低減。

4. quote age <=5秒だけでは「判定時刻より前のquote」を拾える
   - captured now - ageSecondsからprovider quote時刻を推定。
   - targetより1秒以上前のquoteは不採用。
   - target〜+6秒窓を基本に採用。

5. D/SKIP予測のWIN/LOSEまで勝率に混ぜていた
   - 結果自体は参考として残す。
   - 公式表示の勝率はdecision=ENTRYの確定WIN/LOSEだけで計算。
   - SKIP確定件数は「SKIP参考」と別表示。

## 維持
- DRAWはLOSE。
- レート取得不能時は勝敗を捏造しない。
- AUTO T-10優先。
- 1分と3分は別Engine。

# GMK MOBILE Rule v0.5.1 — Regime policy correction

Policy:
- REGIME classification must NOT mass-produce D/SKIP.
- TREND_UP/TREND_DOWN counter-direction: confidence penalty only.
- CHOPPY: confidence penalty only; not automatic D.
- RANGE outer-edge chase: small penalty only.
- Hard D/SKIP remains only for the explicit TREND_SWITCH safety guard:
  - candidate is opposite the newly switched trend, or
  - trend switch confirmation is below 3/4 votes.

Grade thresholds remain unchanged:
S >= 0.76
A >= 0.68
B >= 0.61
C >= 0.55
D < 0.55

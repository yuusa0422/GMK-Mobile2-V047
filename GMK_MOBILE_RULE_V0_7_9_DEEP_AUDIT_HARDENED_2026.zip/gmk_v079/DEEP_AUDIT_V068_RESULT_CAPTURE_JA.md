# GMK MOBILE Rule v0.6.8 — さらに深掘りした結果取得監査

追加で見つけた問題:

1. 結果判定のたびに6通貨全部のレートを取得
- TOP1は1通貨だけなのに6通貨取得していたため、ENTRY/JUDGEの6秒窓を無駄に消費。
- MarketRepository.fetchRate(instrument) を追加。
- 結果追跡は対象1通貨だけ取得。

2. Yahoo FXとOANDA/bitbankを同じ5秒age閾値で扱っていた
- Yahooは更新粒度が異なるため、正常な結果まで大量に取得失敗になり得る。
- OANDA/bitbank: provider age 5秒以内。
- Yahoo: provider age 15秒以内。
- ただしquote推定時刻がtargetより2秒以上前なら不採用。

3. 「取得した時刻」と「provider側のquote時刻」の品質が履歴から分からない
- entry/judge capture delay(ms)
- entry/judge provider age(seconds)
を履歴・診断JSON・画面へ追加。

4. 異常な0/NaN/Infinityレートを書き込める余地
- HistoryStoreでrate > 0かつfiniteを再検証。
- provider ageもfinite/非負を再検証。

5. 6秒窓を大幅に過ぎて再開したpending jobがネット取得を試す無駄
- target+6秒経過済みなら即null。
- 過去レートは捏造しない。

6. UI上の結果レートがTHE OPTION約定レートと誤認される余地
- 「市場参考」と明記。
- source / capture delay / provider ageを表示。

維持:
- DRAW=LOSE。
- ENTRY勝率とSKIP参考は分離。
- 手動はscan開始+10秒。
- AUTOはT-10→対象枠開始をENTRY基準。

# GMK MOBILE Rule v0.6.5 — 3分予測 WIN/LOSE 自動結果追跡

対象:
- 3分手動スキャン
- 3分AUTOスキャン

結果判定:
1. スキャン開始から約10秒後をENTRY基準時刻にする。
   - AUTOは既存T-10対象枠境界をENTRY基準。
   - MANUALはスキャン開始+10秒。
2. ENTRY時刻にTOP1通貨のLIVEレートを取得。
3. その3分後に同じ通貨のLIVEレートを再取得。
4. HIGH: 判定レート > ENTRYレート ならWIN。
5. LOW: 判定レート < ENTRYレート ならWIN。
6. 同値(DRAW)はLOSE。
7. LIVEレートを正確な時点で取得できない場合は、推測せず取得失敗として残す。

表示:
- 予測結果一覧
- MANUAL / AUTO
- 通貨 / HIGH・LOW / Grade / Regime
- ENTRY時刻・ENTRYレート
- 3分後時刻・判定レート
- WIN / LOSE / 待機 / 取得失敗

永続化:
- 履歴にentry_rate / judge_rate / result_status等を保存。
- アプリ起動中のpendingは自動追跡。
- 再起動時もpendingを再読込するが、時刻を大幅に過ぎた場合は過去レートを捏造せずMISSED扱い。

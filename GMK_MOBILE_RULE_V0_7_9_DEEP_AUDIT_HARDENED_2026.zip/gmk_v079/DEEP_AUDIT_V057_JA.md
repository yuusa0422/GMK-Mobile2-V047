# GMK MOBILE Rule v0.5.7 追加深掘り監査

V0.5.6からさらに確認した不具合と修正:

1. AUTOが:51〜:54でも開始できる
- 固定仕様ではT-10(:50)から1秒以上遅れた開始はAUTO_SCAN_MISSED。
- 修正: :50.xだけ開始可。:51以降はMISSEDとして同一slotでlate recoveryしない。

2. AUTOスロット中にbusyだと何も記録されず消える
- 修正: T-10時点busyならAUTO_SCAN_MISSEDを明示。

3. AUTO entry_timeをルール計算終了時刻から再計算
- 修正: schedulerが確定した対象5分境界をLocalRuleEngineへ明示的に渡す。
- judge_timeはそのentry + 3分。

4. scan開始直前のcancelAllとrate loopに競合窓
- 修正: busy=trueを先に立ててからin-flight rate HTTPをcancel。

5. レート取得タイムアウト時にキャッシュageが進まない
- 修正: timeoutでも経過秒を加算してLAST化。

6. 連続取得失敗時にcache ageを二重加算する可能性
- 修正: failureごとにlastRateUpdateMsを更新し、次回は直前更新からの差分だけ加算。

7. connected_6が「6通貨価格あり」で、LIVE 6/6と意味がずれていた
- 修正: connected_6は6/6 LIVE基準へ統一。
- available_6を別項目として診断へ追加。

8. 最終成功レート更新時刻が診断に無い
- 修正: last_rate_success_ms追加。

9. CandleBatch errorへ生の例外messageを入れていた
- 修正: safeError()を通し、Bearer情報などをマスク。

10. 履歴保存がSharedPreferences.apply()で非同期
- scan直後のプロセス終了で最新履歴を失う余地。
- 修正: 履歴の200件保存のみcommit()へ変更。

11. AUTO schedulerの監査キーが診断に無い
- 修正: last_auto_boundary_key追加。

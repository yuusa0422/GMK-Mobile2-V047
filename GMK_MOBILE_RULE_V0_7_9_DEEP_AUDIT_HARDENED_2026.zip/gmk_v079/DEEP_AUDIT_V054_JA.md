# GMK MOBILE Rule v0.5.4 追加深掘り監査

V0.5.3を再監査して、新たに以下を修正した。

1. withTimeoutが実質効かない可能性
- 原因: OkHttp同期executeはCoroutine cancellationで即停止しない。
- 修正: enqueue + suspendCancellableCoroutineへ変更し、cancel時にCall.cancel()。

2. CancellationExceptionをrunCatching/catch(Throwable)が飲み込む
- AUTO 8.5秒タイムアウト後もYahoo query1/query2やretryが続く可能性。
- 修正: 取得全経路でCancellationExceptionを必ず再throw。

3. OANDAのSTALE値をYahooのUNAVAILABLEで上書きする
- 修正: Yahooに実価格が無い場合は既存OANDA値を保持。
- 両方価格ありならLIVE優先、その後ageが小さい方を採用。

4. AUTO期限チェックがルール計算「前」だけ
- 計算中に境界を越える可能性。
- 修正: ルール計算後・publish直前にも期限チェック。

5. スキャン失敗後に前回TOP1が画面に残る
- 古い候補を現在候補と誤認する危険。
- 修正: 新しいスキャン開始時にcurrent scanをクリア。

6. ローソク30本あれば欠損だらけでも判定
- 修正: 直近30本のspan>45分、または最大gap>10分を対象外。

7. レート全体取得失敗時、旧LIVE表示が残る
- 修正: 旧価格はLASTへ降格し、「表示値はキャッシュ」と明示。

8. トレンド切替の確認不足だけでD/SKIP
- ユーザー方針「D/SKIP量産禁止」と衝突。
- 修正: 真の切替逆張りだけ強制D。
- 切替確認不足は-4ptの減点のみ。

9. GitHub Actionsが複数APK時に先頭APKを拾う
- 修正: app-debug.apkを優先し、androidTest APKを除外。

10. APK検証が署名だけ
- 修正: package/versionCode/versionNameをaaptで検証。

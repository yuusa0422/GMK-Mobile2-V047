# GMK MOBILE Rule v0.6.1 GitHub compile修正

GitHub Actions実コンパイルで判明した4系統を修正。

1. AppPrefs.lastAutoBoundaryKey setter
- SharedPreferences.commit()はBooleanを返すためexpression-body setterがUnit不一致。
- block-body setterへ変更し戻り値を捨てる。

2. normalizeCandles
- SequenceにtakeLast()は存在しない。
- distinct/sort後にtoList()してからtakeLast(120)。

3. CancellableContinuation internal API
- tryResumeWithException / tryResume / completeResume が使用環境でinternal APIエラー。
- 標準Continuation.resumeWith(Result.success/failure)へ変更。
- cancellation時はOkHttp Call.cancel()を維持。

4. version
- versionCode=61
- versionName=0.6.1-local

V0.6.0で追加したAUTO/REGIME/週明けgap/部分scan修正は維持。

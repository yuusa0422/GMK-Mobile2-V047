# GMK MOBILE Rule v0.6.4 — 1分スマホ版 不具合監査

V0.6.3で追加した1分手動を重点監査し、以下を修正。

1. 1分判定なのにM1 freshnessを240秒まで許容
- 180秒へ短縮。
- 次1分判定で極端に古い入力を使いにくくした。

2. 15本あれば途中欠損でも1分判定可能
- 直近15本の最大gap > 90秒を技術見送り。
- span > 16分も技術見送り。

3. 6通貨それぞれはfreshでも、最新M1時刻が通貨間でずれる可能性
- 6通貨のlatest candle timestamp spread > 90秒を技術見送り。

4. switchCounterTrendを末尾順位へ落とすだけで、全6候補がguard対象ならguard候補がTOP1になれる
- TOP1にTREND_SWITCH_GUARDが残る場合は結果を公開せず技術見送り。

5. 3分AUTOが1分処理をcancelした際、1分側catchが停止理由を上書き
- 「3分AUTO T-10を優先」を保持。

6. UI上では3分実行中でも1分ボタン、1分実行中でも3分ボタンが押せるように見える
- 双方向でボタンをdisable。

維持:
- 1分と3分は別Engine。
- 1分はPC/Ollama不要。
- 6通貨Context必須。
- 3分AUTO T-10を最優先。
- 1分CHOPPYは軽い減点のみで、一律SKIPしない。

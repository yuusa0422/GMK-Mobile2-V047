# GMK MOBILE Rule v0.6.6 — 結果追跡 深掘り修正

修正:
- 再起動後WAIT_JUDGEなのにENTRYレートを取り直す不具合を修正。
- 結果取得でCancellationExceptionを握り潰さない。
- ENTRY/JUDGEはtarget+6秒以内、quote age 5秒以内だけ採用。
- target+6秒まで短い再試行を実施。
- 履歴更新はWAIT_ENTRY/WAIT_JUDGEの期待状態でのみ許可。
- 結果一覧の時刻をJST HH:mm:ss表示へ修正。
- WIN/LOSE件数と現在勝率を結果一覧上部に追加。
- DRAWはLOSEのまま。

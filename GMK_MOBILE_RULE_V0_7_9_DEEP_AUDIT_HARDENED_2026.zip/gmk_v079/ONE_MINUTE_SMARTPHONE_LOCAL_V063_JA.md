# GMK MOBILE Rule v0.6.3 — 1分手動 スマホ単体版

- 3分: LocalRuleEngine / 5分枠 / 3分判定。
- 1分手動: OneMinuteLocalEngine / 次1分枠 / 1分判定。
- 1分は3分エンジンを呼ばず、3分スコアを流用しない。
- PC / Ollama / 14B / Railway不要。
- 6通貨Context必須。
- 次1分枠開始後に完了した結果は採用しない。
- 3分AUTO T-10を最優先。
- 1分trend-switch直後の新方向への逆張り候補はTOP1から抑制。
- CHOPPYは軽い減点だけで、一律SKIPしない。

// LEGACY/UNUSED: retained for source history only. Not referenced by v0.7.9 production path.
package jp.gmk.mobile.domain

/**
 * Deterministic 2026 historical pattern router.
 * No AI/ML inference. Scores are smoothed physical 3-minute win rates from
 * 2026-01-01 through 2026-08-18, grouped only by instrument/regime/direction.
 */
object HistoricalPatternRouter {
    private val scoreByKey = mapOf(
        "AUDJPY|CHOPPY|HIGH" to 0.50788991,
        "AUDJPY|CHOPPY|LOW" to 0.48710938,
        "AUDJPY|RANGE|HIGH" to 0.50514276,
        "AUDJPY|RANGE|LOW" to 0.48074220,
        "AUDJPY|TREND_DOWN|HIGH" to 0.50000000,
        "AUDJPY|TREND_DOWN|LOW" to 0.46981588,
        "AUDJPY|TREND_UP|HIGH" to 0.49580046,
        "AUDJPY|TREND_UP|LOW" to 0.48148148,
        "BTCJPY|CHOPPY|HIGH" to 0.49506970,
        "BTCJPY|CHOPPY|LOW" to 0.50652921,
        "BTCJPY|RANGE|HIGH" to 0.51206186,
        "BTCJPY|RANGE|LOW" to 0.49914821,
        "BTCJPY|TREND_DOWN|HIGH" to 0.46280992,
        "BTCJPY|TREND_DOWN|LOW" to 0.51029565,
        "BTCJPY|TREND_UP|HIGH" to 0.50630896,
        "BTCJPY|TREND_UP|LOW" to 0.51533742,
        "EURJPY|CHOPPY|HIGH" to 0.51469027,
        "EURJPY|CHOPPY|LOW" to 0.47263487,
        "EURJPY|RANGE|HIGH" to 0.49549784,
        "EURJPY|RANGE|LOW" to 0.47834395,
        "EURJPY|TREND_DOWN|HIGH" to 0.50000000,
        "EURJPY|TREND_DOWN|LOW" to 0.46256058,
        "EURJPY|TREND_UP|HIGH" to 0.49247284,
        "EURJPY|TREND_UP|LOW" to 0.48076923,
        "GBPJPY|CHOPPY|HIGH" to 0.50808229,
        "GBPJPY|CHOPPY|LOW" to 0.47760618,
        "GBPJPY|RANGE|HIGH" to 0.50164417,
        "GBPJPY|RANGE|LOW" to 0.47939223,
        "GBPJPY|TREND_DOWN|HIGH" to 0.52631579,
        "GBPJPY|TREND_DOWN|LOW" to 0.48351648,
        "GBPJPY|TREND_UP|HIGH" to 0.48968746,
        "GBPJPY|TREND_UP|LOW" to 0.50000000,
        "NZDJPY|CHOPPY|HIGH" to 0.50000000,
        "NZDJPY|CHOPPY|LOW" to 0.49118684,
        "NZDJPY|RANGE|HIGH" to 0.50207316,
        "NZDJPY|RANGE|LOW" to 0.48595104,
        "NZDJPY|TREND_DOWN|HIGH" to 0.48275862,
        "NZDJPY|TREND_DOWN|LOW" to 0.47721648,
        "NZDJPY|TREND_UP|HIGH" to 0.48969666,
        "NZDJPY|TREND_UP|LOW" to 0.46296296,
        "USDJPY|CHOPPY|HIGH" to 0.50159067,
        "USDJPY|CHOPPY|LOW" to 0.47086429,
        "USDJPY|RANGE|HIGH" to 0.51308305,
        "USDJPY|RANGE|LOW" to 0.47598645,
        "USDJPY|TREND_DOWN|HIGH" to 0.55172414,
        "USDJPY|TREND_DOWN|LOW" to 0.46487730,
        "USDJPY|TREND_UP|HIGH" to 0.50377653,
        "USDJPY|TREND_UP|LOW" to 0.50909091,
    )

    fun score(instrument: String, regime: String, direction: String): Double =
        scoreByKey["$instrument|$regime|$direction"] ?: 0.5
}

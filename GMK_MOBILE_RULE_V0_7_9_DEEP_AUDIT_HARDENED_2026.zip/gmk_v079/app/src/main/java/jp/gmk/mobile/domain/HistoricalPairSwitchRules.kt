// LEGACY/UNUSED: retained for source history only. Not referenced by v0.7.9 production path.
package jp.gmk.mobile.domain

/**
 * Deterministic 2026 pair-switch rules for the 3-minute smartphone engine.
 *
 * No AI and no remote inference. Rules compare the current C-ranked TOP1 with
 * another simultaneously scanned instrument using decision-time features only.
 */
object HistoricalPairSwitchRules {
    data class Features(
        val instrument: String,
        val regime: String,
        val direction: String,
        val score: Double,
        val confidence: Double,
        val rsi14: Double,
        val atrPct: Double,
        val agreement: Double,
        val efficiency: Double,
        val emaGapAtr: Double
    )

    data class Match(
        val grade: String,
        val quality: Double,
        val priority: Double,
        val ruleIndex: Int
    )

    private data class Rule(
        val grade: String,
        val quality: Double,
        val priority: Double,
        val curRank: String? = null,
        val curInstrument: String? = null,
        val altInstrument: String? = null,
        val curRegime: String? = null,
        val curDirection: String? = null,
        val altRegime: String? = null,
        val altDirection: String? = null,
        val curHour3: Int? = null,
        val dConfBin: Int? = null,
        val dScoreBin: Int? = null,
        val dAgreeBin: Int? = null,
        val dEmaBin: Int? = null,
        val dEffBin: Int? = null,
        val dRsiBin: Int? = null,
        val altConfBin: Int? = null,
        val altRsiBin: Int? = null,
        val altAgreeBin: Int? = null,
        val altAtrBin: Int? = null
    )

    private val rules = listOf(
        Rule(grade = "B", quality = 0.58333333, priority = 0.08333333, curRank = "C", curInstrument = "USDJPY", altInstrument = "NZDJPY", curRegime = null, curDirection = null, altRegime = "RANGE", altDirection = null, curHour3 = null, dConfBin = null, dScoreBin = 1, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = 1, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "C", quality = 0.57894737, priority = 0.13953488, curRank = "C", curInstrument = "EURJPY", altInstrument = "AUDJPY", curRegime = "RANGE", curDirection = null, altRegime = null, altDirection = null, curHour3 = null, dConfBin = null, dScoreBin = 1, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "C", quality = 0.57142857, priority = 0.09523810, curRank = "C", curInstrument = "EURJPY", altInstrument = "AUDJPY", curRegime = "RANGE", curDirection = null, altRegime = null, altDirection = null, curHour3 = null, dConfBin = 1, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "B", quality = 0.58620690, priority = 0.11538462, curRank = "C", curInstrument = "EURJPY", altInstrument = "AUDJPY", curRegime = null, curDirection = null, altRegime = null, altDirection = null, curHour3 = null, dConfBin = 1, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "B", quality = 0.58695652, priority = 0.10714286, curRank = "C", curInstrument = "USDJPY", altInstrument = "EURJPY", curRegime = null, curDirection = "LOW", altRegime = "RANGE", altDirection = "LOW", curHour3 = null, dConfBin = null, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "B", quality = 0.59259259, priority = 0.11111111, curRank = "C", curInstrument = "AUDJPY", altInstrument = "EURJPY", curRegime = "RANGE", curDirection = "LOW", altRegime = null, altDirection = null, curHour3 = null, dConfBin = null, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = 0),
        Rule(grade = "B", quality = 0.63888889, priority = 0.10714286, curRank = "C", curInstrument = "USDJPY", altInstrument = "EURJPY", curRegime = null, curDirection = "HIGH", altRegime = null, altDirection = null, curHour3 = null, dConfBin = 2, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "B", quality = 0.60000000, priority = 0.06666667, curRank = "C", curInstrument = "USDJPY", altInstrument = "NZDJPY", curRegime = "RANGE", curDirection = null, altRegime = null, altDirection = null, curHour3 = null, dConfBin = null, dScoreBin = null, dAgreeBin = 3, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null),
        Rule(grade = "B", quality = 0.59090909, priority = 0.03225806, curRank = "C", curInstrument = "USDJPY", altInstrument = "GBPJPY", curRegime = "RANGE", curDirection = null, altRegime = null, altDirection = null, curHour3 = null, dConfBin = null, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = null, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = 0, altAtrBin = null),
        Rule(grade = "C", quality = 0.53488372, priority = 0.04651163, curRank = "C", curInstrument = "BTCJPY", altInstrument = "NZDJPY", curRegime = null, curDirection = null, altRegime = null, altDirection = null, curHour3 = null, dConfBin = null, dScoreBin = null, dAgreeBin = null, dEmaBin = null, dEffBin = 0, dRsiBin = null, altConfBin = null, altRsiBin = null, altAgreeBin = null, altAtrBin = null)
    )

    fun match(
        curRank: String,
        current: Features,
        alternative: Features,
        hour: Int
    ): Match? {
        val hour3 = (hour / 3) * 3
        val dConfBin = bin(
            alternative.confidence - current.confidence,
            doubleArrayOf(-0.08, -0.04, -0.015, 0.015, 0.04, 0.08)
        )
        val dScoreBin = bin(
            kotlin.math.abs(alternative.score) - kotlin.math.abs(current.score),
            doubleArrayOf(-0.15, -0.07, -0.025, 0.025, 0.07, 0.15)
        )
        val dAgreeBin = bin(
            alternative.agreement - current.agreement,
            doubleArrayOf(-0.34, -0.17, -0.01, 0.01, 0.17, 0.34)
        )
        val dEmaBin = bin(
            alternative.emaGapAtr - current.emaGapAtr,
            doubleArrayOf(-1.0, -0.4, -0.1, 0.1, 0.4, 1.0)
        )
        val dEffBin = bin(
            alternative.efficiency - current.efficiency,
            doubleArrayOf(-0.25, -0.1, -0.03, 0.03, 0.1, 0.25)
        )
        val dRsiBin = bin(
            alternative.rsi14 - current.rsi14,
            doubleArrayOf(-20.0, -10.0, -4.0, 4.0, 10.0, 20.0)
        )
        val altConfBin = bin(
            alternative.confidence,
            doubleArrayOf(0.55, 0.59, 0.63, 0.67, 0.71, 0.75)
        )
        val altRsiBin = bin(
            alternative.rsi14,
            doubleArrayOf(30.0, 40.0, 47.0, 53.0, 60.0, 70.0)
        )
        val altAgreeBin = bin(
            alternative.agreement,
            doubleArrayOf(0.50, 0.67, 0.84)
        )
        val altAtrBin = bin(
            alternative.atrPct,
            doubleArrayOf(0.0001, 0.00018, 0.0003, 0.00055, 0.001)
        )

        // v0.7.3: additional USDJPY(C) -> NZDJPY deterministic rescue rules.
        // These were required to stay positive across Jan-Apr, May-Jun and Jul-Aug 2026.
        var best: Match? = null
        if (curRank == "C" && current.instrument == "USDJPY" && alternative.instrument == "NZDJPY") {
            val dEma = alternative.emaGapAtr - current.emaGapAtr

            // R1: NZDJPY RSI 55..65. 2026 split WR: 65.31% / 66.67% / 64.29%.
            if (alternative.rsi14 > 55.0 && alternative.rsi14 <= 65.0) {
                best = Match(grade = "B", quality = 0.64285714, priority = 0.09090909, ruleIndex = 100)
            }

            // R2: current USDJPY HIGH while NZDJPY points LOW.
            // 2026 split WR: 62.75% / 60.00% / 63.64%.
            if (current.direction == "HIGH" && alternative.direction == "LOW") {
                val m = Match(grade = "B", quality = 0.60000000, priority = 0.06060606, ruleIndex = 101)
                if (best == null || m.priority > best!!.priority ||
                    (m.priority == best!!.priority && m.quality > best!!.quality)) best = m
            }

            // R3: NZDJPY HIGH with near-neutral relative EMA-gap difference.
            // 2026 split WR: 58.82% / 62.50% / 62.50%.
            if (alternative.direction == "HIGH" && dEma > -0.2 && dEma <= 0.2) {
                val m = Match(grade = "B", quality = 0.58823529, priority = 0.11764706, ruleIndex = 102)
                if (best == null || m.priority > best!!.priority ||
                    (m.priority == best!!.priority && m.quality > best!!.quality)) best = m
            }
        }

        for ((index, r) in rules.withIndex()) {
            if (r.curRank != null && r.curRank != curRank) continue
            if (r.curInstrument != null && r.curInstrument != current.instrument) continue
            if (r.altInstrument != null && r.altInstrument != alternative.instrument) continue
            if (r.curRegime != null && r.curRegime != current.regime) continue
            if (r.curDirection != null && r.curDirection != current.direction) continue
            if (r.altRegime != null && r.altRegime != alternative.regime) continue
            if (r.altDirection != null && r.altDirection != alternative.direction) continue
            if (r.curHour3 != null && r.curHour3 != hour3) continue
            if (r.dConfBin != null && r.dConfBin != dConfBin) continue
            if (r.dScoreBin != null && r.dScoreBin != dScoreBin) continue
            if (r.dAgreeBin != null && r.dAgreeBin != dAgreeBin) continue
            if (r.dEmaBin != null && r.dEmaBin != dEmaBin) continue
            if (r.dEffBin != null && r.dEffBin != dEffBin) continue
            if (r.dRsiBin != null && r.dRsiBin != dRsiBin) continue
            if (r.altConfBin != null && r.altConfBin != altConfBin) continue
            if (r.altRsiBin != null && r.altRsiBin != altRsiBin) continue
            if (r.altAgreeBin != null && r.altAgreeBin != altAgreeBin) continue
            if (r.altAtrBin != null && r.altAtrBin != altAtrBin) continue

            val m = Match(r.grade, r.quality, r.priority, index)
            if (best == null || m.priority > best!!.priority ||
                (m.priority == best!!.priority && m.quality > best!!.quality)) {
                best = m
            }
        }
        return best
    }

    private fun bin(value: Double, cuts: DoubleArray): Int {
        var i = 0
        while (i < cuts.size && value > cuts[i]) i++
        return i
    }
}

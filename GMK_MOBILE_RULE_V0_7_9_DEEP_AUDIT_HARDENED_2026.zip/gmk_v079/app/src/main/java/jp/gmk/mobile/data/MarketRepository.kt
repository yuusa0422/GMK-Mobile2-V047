package jp.gmk.mobile.data

import jp.gmk.mobile.domain.Candle
import jp.gmk.mobile.domain.CandleBatch
import jp.gmk.mobile.domain.RateRow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

class MarketRepository(private val prefs: AppPrefs) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(15, TimeUnit.SECONDS)
        .build()

    private val instruments = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
    private val yahooMap = mapOf(
        "USDJPY" to "JPY=X", "EURJPY" to "EURJPY=X", "GBPJPY" to "GBPJPY=X",
        "AUDJPY" to "AUDJPY=X", "NZDJPY" to "NZDJPY=X"
    )

    suspend fun fetchRates(): List<RateRow> = coroutineScope {
        val fxDeferred = async { fetchFxRates() }
        val btcDeferred = async {
            try {
                fetchBitbankTicker()
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                RateRow("BTCJPY", null, null, null, "bitbank unavailable: ${safeError(t)}", null, "UNAVAILABLE")
            }
        }
        val fxMap = fxDeferred.await()
        val btcRow = btcDeferred.await()
        instruments.map { ins ->
            if (ins == "BTCJPY") btcRow
            else fxMap[ins] ?: RateRow(ins, null, null, null, "unavailable", null, "UNAVAILABLE")
        }
    }

    suspend fun fetchRate(instrument: String): RateRow {
        require(instrument in instruments) { "unsupported instrument: $instrument" }

        if (instrument == "BTCJPY") {
            return try {
                fetchBitbankTicker()
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                RateRow("BTCJPY", null, null, null, "bitbank unavailable: ${safeError(t)}", null, "UNAVAILABLE")
            }
        }

        val sym = yahooMap[instrument]
            ?: return RateRow(instrument, null, null, null, "symbol unavailable", null, "UNAVAILABLE")
        return try {
            fetchYahooQuote(instrument, sym)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            RateRow(instrument, null, null, null, "Yahoo unavailable: ${safeError(t)}", null, "UNAVAILABLE")
        }
    }

    suspend fun fetchAllCandles(): CandleBatch = coroutineScope {
        val results = instruments.map { ins ->
            async {
                try {
                    Triple(ins, normalizeCandles(fetchCandles(ins)), null)
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    Triple(ins, emptyList<Candle>(), safeError(t))
                }
            }
        }.awaitAll()

        CandleBatch(
            candles = results.associate { it.first to it.second },
            errors = results.mapNotNull { row ->
                row.third?.let { row.first to it }
            }.toMap()
        )
    }

    private suspend fun fetchFxRates(): Map<String, RateRow> = coroutineScope {
        yahooMap.map { (ins, sym) ->
            async {
                val row = try {
                    fetchYahooQuote(ins, sym)
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    RateRow(ins, null, null, null, "Yahoo unavailable: ${safeError(t)}", null, "UNAVAILABLE")
                }
                ins to row
            }
        }.awaitAll().toMap()
    }

    private suspend fun fetchYahooQuote(instrument: String, symbol: String): RateRow = withContext(Dispatchers.IO) {
        val hosts = listOf("query2.finance.yahoo.com", "query1.finance.yahoo.com")
        var lastError: Throwable? = null
        for (host in hosts) {
            try {
                val url = "https://$host/v8/finance/chart/$symbol".toHttpUrl().newBuilder()
                    .addQueryParameter("interval", "1m")
                    .addQueryParameter("range", "1d")
                    .addQueryParameter("includePrePost", "true")
                    .build()
                val text = executeWithRetry(Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build())
                val result = JSONObject(text).optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)
                    ?: throw IOException("Yahoo chart result empty")
                val timestamps = result.optJSONArray("timestamp") ?: JSONArray()
                val quote = result.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
                val closes = quote?.optJSONArray("close") ?: JSONArray()

                var lastPrice: Double? = null
                var lastTs = 0L
                val n = minOf(timestamps.length(), closes.length())
                for (i in n - 1 downTo 0) {
                    val c = closes.optDoubleFinite(i) ?: continue
                    val t = timestamps.optLong(i, 0L)
                    if (t > 0L) {
                        lastPrice = c
                        lastTs = t
                        break
                    }
                }

                val meta = result.optJSONObject("meta")
                val metaPrice = meta?.optDoubleOrNull("regularMarketPrice")
                val metaTs = meta?.optLong("regularMarketTime", 0L) ?: 0L

                val useMeta = metaPrice != null && metaTs > 0L && metaTs >= lastTs
                val price = if (useMeta) metaPrice else (lastPrice ?: metaPrice)
                val ts = if (useMeta) metaTs else if (lastTs > 0L) lastTs else metaTs
                val age = if (ts > 0L) (System.currentTimeMillis() / 1000.0 - ts).coerceAtLeast(0.0) else null
                val freshness = when {
                    price == null -> "UNAVAILABLE"
                    (age ?: 9999.0) <= 75.0 -> "LIVE"
                    else -> "LAST"
                }
                return@withContext RateRow(instrument, price, null, null, "YahooFX ${host.substringBefore('.')} keyless", age, freshness)
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IOException("Yahoo FX all endpoints failed: ${lastError?.message ?: "unknown"}")
    }

    private suspend fun fetchBitbankTicker(): RateRow = withContext(Dispatchers.IO) {
        val text = executeWithRetry(Request.Builder().url("https://public.bitbank.cc/btc_jpy/ticker").build())
        val d = JSONObject(text).optJSONObject("data") ?: JSONObject()
        val rawBid = d.optString("buy").toFinitePositiveOrNull()
        val rawAsk = d.optString("sell").toFinitePositiveOrNull()
        val bid = rawBid?.takeIf { rawAsk == null || rawAsk >= it }
        val ask = rawAsk?.takeIf { rawBid == null || it >= rawBid }
        val last = d.optString("last").toFinitePositiveOrNull()
        val tsMs = d.optLong("timestamp", 0L)
        val age = if (tsMs > 0) ((System.currentTimeMillis() - tsMs) / 1000.0).coerceAtLeast(0.0) else null
        val price = last ?: if (bid != null && ask != null) (bid + ask) / 2.0 else (bid ?: ask)
        RateRow("BTCJPY", price, bid, ask, "bitbank", age, if (price != null && (age ?: 9999.0) <= 15.0) "LIVE" else if (price != null) "LAST" else "UNAVAILABLE")
    }

    private suspend fun fetchCandles(instrument: String): List<Candle> {
        return if (instrument == "BTCJPY") {
            fetchBitbankCandles()
        } else {
            fetchYahooCandles(instrument, yahooMap.getValue(instrument))
        }
    }

    private suspend fun fetchYahooCandles(instrument: String, symbol: String): List<Candle> = withContext(Dispatchers.IO) {
        val hosts = listOf("query2.finance.yahoo.com", "query1.finance.yahoo.com")
        var lastError: Throwable? = null
        for (host in hosts) {
            try {
                val url = "https://$host/v8/finance/chart/$symbol".toHttpUrl().newBuilder()
                    .addQueryParameter("interval", "1m")
                    .addQueryParameter("range", "5d")
                    .addQueryParameter("includePrePost", "true")
                    .build()
                val text = executeWithRetry(Request.Builder().url(url).header("User-Agent", "Mozilla/5.0").build())
                val result = JSONObject(text).optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)
                    ?: throw IOException("$instrument: Yahoo chart result empty")
                val ts = result.optJSONArray("timestamp") ?: throw IOException("$instrument: Yahoo timestamps empty")
                val q = result.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
                    ?: throw IOException("$instrument: Yahoo quote empty")
                val opens = q.optJSONArray("open") ?: JSONArray()
                val highs = q.optJSONArray("high") ?: JSONArray()
                val lows = q.optJSONArray("low") ?: JSONArray()
                val closes = q.optJSONArray("close") ?: JSONArray()
                val vols = q.optJSONArray("volume") ?: JSONArray()
                val out = buildList {
                    val n = minOf(ts.length(), opens.length(), highs.length(), lows.length(), closes.length())
                    val currentMinuteStartMs = (System.currentTimeMillis() / 60_000L) * 60_000L
                    for (i in 0 until n) {
                        val candleMs = ts.optLong(i) * 1000L
                        if (candleMs <= 0L || candleMs >= currentMinuteStartMs) continue
                        val o = opens.optDoubleFinite(i) ?: continue
                        val h = highs.optDoubleFinite(i) ?: continue
                        val l = lows.optDoubleFinite(i) ?: continue
                        val c = closes.optDoubleFinite(i) ?: continue
                        add(Candle(candleMs, o, h, l, c, vols.optDoubleFinite(i) ?: 0.0))
                    }
                }.takeLast(120)
                if (out.isNotEmpty()) return@withContext out
                throw IOException("$instrument: Yahoo candles empty")
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (t: Throwable) {
                lastError = t
            }
        }
        throw IOException("$instrument: Yahoo all endpoints failed: ${lastError?.message ?: "unknown"}")
    }

    private suspend fun fetchBitbankCandles(): List<Candle> = withContext(Dispatchers.IO) {
        val jst = ZoneId.of("Asia/Tokyo")
        val out = mutableListOf<Candle>()

        suspend fun loadDate(z: ZonedDateTime) {
            val date = z.format(DateTimeFormatter.ofPattern("yyyyMMdd"))
            val text = executeWithRetry(
                Request.Builder().url("https://public.bitbank.cc/btc_jpy/candlestick/1min/$date").build()
            )
            val cs = JSONObject(text).optJSONObject("data")?.optJSONArray("candlestick") ?: return
            val currentMinuteStartMs = (System.currentTimeMillis() / 60_000L) * 60_000L
            for (g in 0 until cs.length()) {
                val ohlcv = cs.optJSONObject(g)?.optJSONArray("ohlcv") ?: continue
                for (i in 0 until ohlcv.length()) {
                    val a = ohlcv.optJSONArray(i) ?: continue
                    if (a.length() < 6) continue
                    val open = a.optString(0).toFinitePositiveOrNull() ?: continue
                    val high = a.optString(1).toFinitePositiveOrNull() ?: continue
                    val low = a.optString(2).toFinitePositiveOrNull() ?: continue
                    val close = a.optString(3).toFinitePositiveOrNull() ?: continue
                    val volume = a.optString(4).toDoubleOrNull() ?: 0.0
                    val ts = a.optLong(5, 0L)
                    if (ts <= 0L || ts >= currentMinuteStartMs) continue
                    out += Candle(ts, open, high, low, close, volume)
                }
            }
        }

        val now = ZonedDateTime.now(jst)
        loadDate(now)

        // Just after midnight there may not yet be 30 complete candles.
        if (out.distinctBy { it.timeEpochMs }.size < 30) {
            loadDate(now.minusDays(1))
        }

        normalizeCandles(out).takeLast(120)
    }

    private fun normalizeCandles(input: List<Candle>): List<Candle> {
        val currentMinuteStartMs = (System.currentTimeMillis() / 60_000L) * 60_000L
        return input
            .asSequence()
            .filter { c ->
                c.timeEpochMs > 0L && c.timeEpochMs < currentMinuteStartMs &&
                c.open.isFinite() && c.high.isFinite() && c.low.isFinite() && c.close.isFinite() &&
                c.open > 0.0 && c.high > 0.0 && c.low > 0.0 && c.close > 0.0 &&
                c.high >= maxOf(c.open, c.close) &&
                c.low <= minOf(c.open, c.close) &&
                c.high >= c.low
            }
            .sortedBy { it.timeEpochMs }
            .distinctBy { it.timeEpochMs }
            .toList()
            .takeLast(120)
    }

    fun cancelInFlightRequests() {
        client.dispatcher.cancelAll()
    }

    private class RequestAbortedException : IOException("request aborted")
    private class HttpStatusException(val statusCode: Int, message: String) : IOException(message)

    private suspend fun executeWithRetry(req: Request, maxAttempts: Int = 2): String {
        var last: Throwable? = null
        repeat(maxAttempts.coerceAtLeast(1)) { attempt ->
            try {
                return executeCancellable(req)
            } catch (ce: CancellationException) {
                throw ce
            } catch (a: RequestAbortedException) {
                throw a
            } catch (h: HttpStatusException) {
                last = h
                val transient = h.statusCode == 408 || h.statusCode == 425 || h.statusCode == 429 || h.statusCode >= 500
                if (!transient || attempt + 1 >= maxAttempts) throw h
                delay(180L * (attempt + 1))
            } catch (t: Throwable) {
                last = t
                if (attempt + 1 < maxAttempts) delay(180L * (attempt + 1))
            }
        }
        throw IOException(last?.message ?: "network request failed", last)
    }

    private suspend fun executeCancellable(req: Request): String =
        suspendCancellableCoroutine { cont ->
            val call = client.newCall(req)

            cont.invokeOnCancellation { call.cancel() }

            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    val error = if (call.isCanceled()) RequestAbortedException() else e
                    if (cont.isActive) {
                        runCatching { cont.resumeWith(Result.failure(error)) }
                    }
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { r ->
                        val text = r.body?.string().orEmpty()
                        if (!cont.isActive) return

                        if (!r.isSuccessful) {
                            val err = HttpStatusException(r.code, "HTTP ${r.code}: ${text.take(180)}")
                            runCatching { cont.resumeWith(Result.failure(err)) }
                        } else {
                            runCatching { cont.resumeWith(Result.success(text)) }
                        }
                    }
                }
            })
        }

    private fun safeError(t: Throwable): String = (t.message ?: t::class.java.simpleName)
        .replace(Regex("""Bearer\s+[^\s]+""", RegexOption.IGNORE_CASE), "Bearer ***")
        .take(180)

}

private fun JSONObject.optDoubleOrNull(name: String): Double? {
    if (!has(name) || isNull(name)) return null
    val d = optDouble(name, Double.NaN)
    return if (d.isFinite()) d else null
}

private fun JSONArray.optDoubleFinite(index: Int): Double? {
    if (index < 0 || index >= length() || isNull(index)) return null
    val d = optDouble(index, Double.NaN)
    return if (d.isFinite()) d else null
}

private fun String.toFinitePositiveOrNull(): Double? {
    val d = toDoubleOrNull() ?: return null
    return d.takeIf { it.isFinite() && it > 0.0 }
}

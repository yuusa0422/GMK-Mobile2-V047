package jp.gmk.mobile.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import jp.gmk.mobile.runtime.GmkRuntimeKeepAliveService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import jp.gmk.mobile.BuildConfig
import jp.gmk.mobile.data.AppPrefs
import jp.gmk.mobile.data.HistoryStore
import jp.gmk.mobile.data.MarketRepository
import jp.gmk.mobile.domain.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import org.json.JSONArray
import org.json.JSONObject


data class GmkUiState(
    val connected: Boolean = false,
    val busy: Boolean = false,
    val error: String? = null,
    val rateStatus: String? = null,
    val scanStatus: String? = null,
    val rates: List<RateRow> = emptyList(),
    val scan: ScanResult? = null,
    val history: List<HistoryRow> = emptyList(),
    val autoScan: Boolean = true,
    val oneMinuteAutoScan: Boolean = false,
    val oandaToken: String = "",
    val oandaAccountId: String = "",
    val oandaEnvironment: String = "practice",
    val yahooFallback: Boolean = true,
    val lastRateUpdateMs: Long = 0L,
    val lastRateSuccessMs: Long = 0L,
    val lastScanAttemptMs: Long = 0L,
    val lastScanSuccessMs: Long = 0L,
    val modeLabel: String = "端末単体",
    val rateLiveCount: Int = 0,
    val rateAvailableCount: Int = 0,
    val scannableCount: Int = 0,
    val lastScanExcluded: Map<String, String> = emptyMap(),
    val lastCandleErrors: Map<String, String> = emptyMap(),
    val lastCandleLatestMs: Map<String, Long> = emptyMap(),
    val quoteCandleDivergencePct: Map<String, Double> = emptyMap(),
    val oneMinuteBusy: Boolean = false,
    val oneMinuteStatus: String? = null,
    val oneMinuteScan: OneMinuteScanResult? = null,
    val outcomeStatus: String? = null
)

class GmkViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = AppPrefs(app)
    private val historyStore = HistoryStore(app)
    private val repository = MarketRepository(prefs)
    private val outcomeRepository = MarketRepository(prefs)
    private val ruleEngine = LocalRuleEngine()
    private val oneMinuteEngine = OneMinuteLocalEngine()
    private val jst = ZoneId.of("Asia/Tokyo")

    private val _state = MutableStateFlow(
        GmkUiState(
            history = historyStore.load(),
            autoScan = prefs.autoScan,
            oneMinuteAutoScan = prefs.oneMinuteAutoScan,
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = prefs.yahooFallback
        )
    )
    val state: StateFlow<GmkUiState> = _state

    private var rateJob: Job? = null
    private var autoJob: Job? = null
    private var oneMinuteAutoJob: Job? = null
    private var oneMinuteJob: Job? = null
    private val outcomeJobs = mutableMapOf<String, Job>()
    private var lastAutoBoundaryKey: String? = prefs.lastAutoBoundaryKey.takeIf { it.isNotBlank() }
    private var lastOneMinuteBoundaryKey: String? = prefs.lastOneMinuteBoundaryKey.takeIf { it.isNotBlank() }
    private var lastSchedulerTickMs: Long = 0L
    private var lastSchedulerElapsedMs: Long = 0L

    init {
        startRateLoop()
        startAutoLoop()
        startOneMinuteAutoLoop()
        resumePendingOutcomes()
        syncForegroundRuntimeService()
    }

    private fun allRatesAvailable(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rows.all { it.price != null }

    private fun rateLiveCount(rows: List<RateRow>): Int =
        rows.count { it.price != null && it.freshnessStatus == "LIVE" }

    private fun allFresh(rows: List<RateRow>): Boolean =
        rows.size >= 6 && rateLiveCount(rows) == 6

    private fun rateSummary(rows: List<RateRow>): String? {
        if (rows.isEmpty()) return "レート取得待機中"
        val missing = rows.filter { it.price == null }.map { it.instrument }
        val last = rows.filter { it.price != null && it.freshnessStatus != "LIVE" }.map { it.instrument }
        return when {
            missing.isNotEmpty() -> "未取得: ${missing.joinToString(",")}"
            last.isNotEmpty() -> "LIVE ${rateLiveCount(rows)}/6 / LAST: ${last.joinToString(",")}"
            else -> null
        }
    }

    private fun mergeRates(previous: List<RateRow>, incoming: List<RateRow>, elapsedSeconds: Double): List<RateRow> {
        val old = previous.associateBy { it.instrument }

        fun effectiveAge(r: RateRow): Double =
            r.ageSeconds ?: Double.MAX_VALUE

        return incoming.map { candidate ->
            val cached = old[candidate.instrument]

            if (cached?.price == null) {
                candidate
            } else if (candidate.price == null) {
                cached.copy(
                    ageSeconds = effectiveAge(cached) + elapsedSeconds.coerceAtLeast(0.0),
                    freshnessStatus = "LAST",
                    source = "${cached.source.removeSuffix(" cache")} cache"
                )
            } else {
                val cachedAdvancedAge = effectiveAge(cached) + elapsedSeconds.coerceAtLeast(0.0)

                val chooseIncoming = when {
                    candidate.freshnessStatus == "LIVE" && cached.freshnessStatus != "LIVE" -> true
                    candidate.freshnessStatus != "LIVE" && cached.freshnessStatus == "LIVE" &&
                        cachedAdvancedAge <= 75.0 -> false
                    else -> effectiveAge(candidate) <= cachedAdvancedAge
                }

                if (chooseIncoming) {
                    candidate
                } else {
                    cached.copy(
                        ageSeconds = cachedAdvancedAge,
                        freshnessStatus = if (cachedAdvancedAge <= 75.0 && cached.freshnessStatus == "LIVE") "LIVE" else "LAST",
                        source = "${cached.source.removeSuffix(" cache")} cache"
                    )
                }
            }
        }
    }

    private fun startRateLoop() {
        rateJob?.cancel()
        rateJob = viewModelScope.launch {
            while (isActive) {
                if (_state.value.busy || _state.value.oneMinuteBusy) {
                    delay(250)
                    continue
                }

                try {
                    val before = _state.value
                    val attemptStartedMs = System.currentTimeMillis()
                    val elapsed = if (before.lastRateUpdateMs > 0L) {
                        (attemptStartedMs - before.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0

                    val incoming = withTimeout(5_500) { repository.fetchRates() }
                    val completedMs = System.currentTimeMillis()
                    val rows = mergeRates(before.rates, incoming, elapsed)
                    val providerReturnedPrice = incoming.any { it.price != null }

                    _state.value = _state.value.copy(
                        rates = rows,
                        connected = allFresh(rows),
                        rateLiveCount = rateLiveCount(rows),
                        rateAvailableCount = rows.count { it.price != null },
                        rateStatus = rateSummary(rows),
                        lastRateUpdateMs = completedMs,
                        lastRateSuccessMs = if (providerReturnedPrice) completedMs else before.lastRateSuccessMs
                    )
                } catch (te: TimeoutCancellationException) {
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    val cached = s.rates.map { r ->
                        if (r.price != null) {
                            r.copy(
                                ageSeconds = (r.ageSeconds ?: 0.0) + elapsed,
                                freshnessStatus = "LAST",
                                source = "${r.source.removeSuffix(" cache")} cache"
                            )
                        } else r.copy(freshnessStatus = "UNAVAILABLE")
                    }
                    _state.value = s.copy(
                        connected = false,
                        rates = cached,
                        rateLiveCount = 0,
                        rateAvailableCount = cached.count { it.price != null },
                        rateStatus = "レート再取得タイムアウト（表示値はキャッシュ）",
                        lastRateUpdateMs = nowMs
                    )
                } catch (ce: CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    val s = _state.value
                    val nowMs = System.currentTimeMillis()
                    val elapsed = if (s.lastRateUpdateMs > 0L) {
                        (nowMs - s.lastRateUpdateMs).coerceAtLeast(0L) / 1000.0
                    } else 0.0
                    val cached = s.rates.map { r ->
                        if (r.price != null) {
                            r.copy(
                                ageSeconds = (r.ageSeconds ?: 0.0) + elapsed,
                                freshnessStatus = "LAST",
                                source = "${r.source.removeSuffix(" cache")} cache"
                            )
                        } else r.copy(freshnessStatus = "UNAVAILABLE")
                    }
                    _state.value = s.copy(
                        connected = false,
                        rates = cached,
                        rateLiveCount = 0,
                        rateAvailableCount = cached.count { it.price != null },
                        rateStatus = "レート再取得失敗（表示値はキャッシュ）: ${e.message}",
                        lastRateUpdateMs = nowMs
                    )
                }
                delay(6_000)
            }
        }
    }

    private fun latestScheduledT10AtOrBefore(now: ZonedDateTime): ZonedDateTime {
        var m = now.truncatedTo(ChronoUnit.MINUTES)
        while (m.minute % 5 != 4) m = m.minusMinutes(1)
        return m.withSecond(50).withNano(0)
    }

    private fun isExpectedFxWeekendGap(aMs: Long, bMs: Long): Boolean {
        if (aMs <= 0L || bMs <= aMs) return false
        val gapMs = bMs - aMs
        if (gapMs < 24L * 60L * 60L * 1000L) return false

        val a = java.time.Instant.ofEpochMilli(aMs).atZone(java.time.ZoneOffset.UTC)
        val b = java.time.Instant.ofEpochMilli(bMs).atZone(java.time.ZoneOffset.UTC)

        val olderOk = a.dayOfWeek == java.time.DayOfWeek.FRIDAY
        val newerOk = b.dayOfWeek == java.time.DayOfWeek.SUNDAY ||
            b.dayOfWeek == java.time.DayOfWeek.MONDAY

        return olderOk && newerOk && gapMs <= 80L * 60L * 60L * 1000L
    }

    private fun isKnownEntryContractGrade(grade: String): Boolean {
        return grade.uppercase() in setOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I")
    }

    private fun startAutoLoop() {
        autoJob?.cancel()
        autoJob = viewModelScope.launch {
            while (isActive) {
                val now = ZonedDateTime.now(jst)
                val nowMs = System.currentTimeMillis()
                val elapsedNow = android.os.SystemClock.elapsedRealtime()

                if (prefs.autoScan && now.hour in 9..22) {
                    // Use monotonic elapsed time so manual clock/NTP changes do not create a false MISSED.
                    if (lastSchedulerTickMs > 0L &&
                        lastSchedulerElapsedMs > 0L &&
                        elapsedNow - lastSchedulerElapsedMs > 1_500L) {
                        val previousTick = java.time.Instant.ofEpochMilli(lastSchedulerTickMs).atZone(jst)
                        val scheduled = latestScheduledT10AtOrBefore(now)

                        if (scheduled.isAfter(previousTick) && scheduled.isBefore(now)) {
                            val boundary = scheduled.plusSeconds(10).truncatedTo(ChronoUnit.MINUTES)
                            val key = boundary.toLocalDateTime().toString()

                            if (lastAutoBoundaryKey != key && prefs.claimThreeMinuteBoundary(key)) {
                                lastAutoBoundaryKey = key
                                _state.value = _state.value.copy(
                                    scan = null,
                                    scanStatus = "AUTO_SCAN_MISSED: 端末スリープ/停止中にT-10を通過"
                                )
                            }
                        }
                    }

                    val inSlotWindow = now.minute % 5 == 4 && now.second in 50..54

                    if (inSlotWindow) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        if (boundary.hour !in 9..22) {
                            _state.value = _state.value.copy(
                                scanStatus = "AUTO待機: 本番時間外 (09:00-23:00)"
                            )
                            delay(100)
                            continue
                        }
                        val key = boundary.toLocalDateTime().toString()

                        if (lastAutoBoundaryKey != key && prefs.claimThreeMinuteBoundary(key)) {
                            lastAutoBoundaryKey = key

                            if (now.second == 50 && !_state.value.busy) {
                                if (_state.value.oneMinuteBusy) {
                                    oneMinuteJob?.cancel()
                                    repository.cancelInFlightRequests()
                                    _state.value = _state.value.copy(
                                        oneMinuteBusy = false,
                                        oneMinuteStatus = "1分手動停止: 3分AUTO T-10を優先"
                                    )
                                }
                                performScan("AUTO", boundary)
                            } else {
                                _state.value = _state.value.copy(
                                    scan = null,
                                    scanStatus = if (_state.value.busy) {
                                        "AUTO_SCAN_MISSED: T-10時点で別処理実行中"
                                    } else {
                                        "AUTO_SCAN_MISSED: ${now.second}秒開始は許可しません"
                                    }
                                )
                            }
                        }
                    }
                }

                lastSchedulerTickMs = nowMs
                lastSchedulerElapsedMs = elapsedNow
                delay(100)
            }
        }
    }

    private fun millisUntilNextAutoT10(now: ZonedDateTime = ZonedDateTime.now(jst)): Long {
        var candidate = now.truncatedTo(ChronoUnit.MINUTES).withSecond(50).withNano(0)
        while (candidate.minute % 5 != 4 || !candidate.isAfter(now)) {
            candidate = candidate.plusMinutes(1).withSecond(50).withNano(0)
        }
        return java.time.Duration.between(now, candidate).toMillis()
    }

    fun manualScan() {
        if (_state.value.busy) return
        val now = ZonedDateTime.now(jst)
        if (now.hour !in 9..22) {
            _state.value = _state.value.copy(scanStatus = "3分手動見送り: 本番時間外 (09:00-23:00)")
            return
        }
        if (_state.value.oneMinuteBusy) {
            _state.value = _state.value.copy(scanStatus = "3分手動待機: 1分手動スキャン中")
            return
        }

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..20_000L) {
                _state.value = _state.value.copy(
                    scanStatus = "手動スキャン待機: AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        viewModelScope.launch { performScan("MANUAL", null) }
    }

    fun manualOneMinuteScan() {
        if (_state.value.oneMinuteBusy || _state.value.busy) return
        val now = ZonedDateTime.now(jst)
        if (now.hour !in 9..22) {
            _state.value = _state.value.copy(oneMinuteStatus = "1分手動見送り: 本番時間外 (09:00-23:00)")
            return
        }

        if (prefs.autoScan) {
            val untilAutoMs = millisUntilNextAutoT10()
            if (untilAutoMs in 0L..15_000L) {
                _state.value = _state.value.copy(
                    oneMinuteStatus = "1分手動待機: 3分AUTO T-10まで${(untilAutoMs / 1000L).coerceAtLeast(0L)}秒"
                )
                return
            }
        }

        startOneMinuteScan("MANUAL_1M")
    }

    private fun startOneMinuteAutoLoop() {
        oneMinuteAutoJob?.cancel()
        oneMinuteAutoJob = viewModelScope.launch {
            while (isActive) {
                if (prefs.oneMinuteAutoScan) {
                    val now = ZonedDateTime.now(jst)

                    // Production operating window is 09:00-23:00 JST for both 1m and 3m.
                    if (now.hour !in 9..22) {
                        delay(250)
                        continue
                    }

                    // 3m AUTO uses the same :50 at minutes 4/9/14/... and always has priority.
                    val isThreeMinuteAutoMinute = now.minute % 5 == 4
                    val inWindow = now.second in 50..54

                    if (inWindow && !isThreeMinuteAutoMinute) {
                        val boundary = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                        val key = boundary.toLocalDateTime().toString()

                        if (lastOneMinuteBoundaryKey != key && prefs.claimOneMinuteBoundary(key)) {
                            lastOneMinuteBoundaryKey = key

                            if (now.second == 50 && !_state.value.busy && !_state.value.oneMinuteBusy) {
                                startOneMinuteScan("AUTO_1M")
                            } else {
                                _state.value = _state.value.copy(
                                    oneMinuteStatus = if (_state.value.busy || _state.value.oneMinuteBusy) {
                                        "1分AUTO_MISSED: T-10時点で別処理実行中"
                                    } else {
                                        "1分AUTO_MISSED: ${now.second}秒開始は許可しません"
                                    }
                                )
                            }
                        }
                    }
                }
                delay(100)
            }
        }
    }

    private fun startOneMinuteScan(source: String) {
        if (_state.value.oneMinuteBusy || _state.value.busy) return

        oneMinuteJob?.cancel()
        oneMinuteJob = viewModelScope.launch {
            _state.value = _state.value.copy(
                oneMinuteBusy = true,
                oneMinuteScan = null,
                oneMinuteStatus = "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}: 6通貨Context取得中"
            )

            repository.cancelInFlightRequests()

            try {
                val now = ZonedDateTime.now(jst)
                val entry = now.plusMinutes(1).truncatedTo(ChronoUnit.MINUTES)
                val remainingMs = java.time.Duration.between(now, entry).toMillis()

                if (remainingMs < 2_500L) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 次1分枠まで${remainingMs.coerceAtLeast(0L)}ms"
                    )
                    return@launch
                }

                val fetchBudget = minOf(8_000L, (remainingMs - 1_000L).coerceAtLeast(1_500L))
                val batch = withTimeout(fetchBudget) { repository.fetchAllCandles() }

                val required = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
                val eligible = linkedMapOf<String, List<Candle>>()
                val errors = linkedMapOf<String, String>()
                val nowMs = System.currentTimeMillis()

                required.forEach { ins ->
                    val rows = batch.candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                    val fetchError = batch.errors[ins]
                    val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                    val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE
                    val expectedLastStartMs = ((nowMs / 60_000L) * 60_000L) - 60_000L
                    val latestLagMs = if (last > 0L) (expectedLastStartMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                    val tail15 = rows.takeLast(15)
                    val gaps = tail15.zipWithNext { a, b -> b.timeEpochMs - a.timeEpochMs }
                    val maxGapMs = gaps.maxOrNull() ?: 0L
                    val spanMs = if (tail15.size >= 2) {
                        tail15.last().timeEpochMs - tail15.first().timeEpochMs
                    } else Long.MAX_VALUE

                    when {
                        fetchError != null -> errors[ins] = "取得失敗: $fetchError"
                        rows.size < 15 -> errors[ins] = "1分足不足 ${rows.size}/15"
                        last <= 0L || latestLagMs > 5_000L ->
                            errors[ins] = "直近完成1分足欠損 lag=${if (latestLagMs == Long.MAX_VALUE) "不明" else "${latestLagMs / 1000}s"}"
                        ageMs > 180_000L ->
                            errors[ins] = "1分足STALE ${ageMs / 1000}s"
                        maxGapMs > 90_000L ->
                            errors[ins] = "1分足不連続 gap=${maxGapMs / 1000L}s"
                        spanMs > 16L * 60_000L ->
                            errors[ins] = "1分足不連続 span=${spanMs / 60_000L}m"
                        else -> eligible[ins] = rows
                    }
                }

                if (eligible.size != 6) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 6/6必須 / " +
                            errors.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                    )
                    return@launch
                }

                val latestTimes = eligible.mapValues { (_, rows) -> rows.last().timeEpochMs }
                val latestSpreadMs = (latestTimes.values.maxOrNull() ?: 0L) -
                    (latestTimes.values.minOrNull() ?: 0L)

                if (latestSpreadMs > 90_000L) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 6通貨M1時刻ずれ ${latestSpreadMs / 1000L}s"
                    )
                    return@launch
                }

                val decisionNow = ZonedDateTime.now(jst)
                if (!decisionNow.isBefore(entry)) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 次1分枠開始後"
                    )
                    return@launch
                }

                val raw = withContext(Dispatchers.Default) {
                    oneMinuteEngine.scan(eligible, decisionNow)
                }
                val result = raw.copy(source = source)

                if (result.candidates.size != 6 || result.top1 == null) {
                    error("1分候補数異常 ${result.candidates.size}/6")
                }

                val topGuarded = result.top1?.reasons?.any {
                    it.startsWith("1M_TREND_SWITCH_GUARD")
                } == true

                if (topGuarded) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: TOP1がトレンド切替逆方向"
                    )
                    return@launch
                }

                if (!ZonedDateTime.now(jst).isBefore(entry)) {
                    _state.value = _state.value.copy(
                        oneMinuteBusy = false,
                        oneMinuteStatus = "1分技術見送り: 判定完了が次枠開始後"
                    )
                    return@launch
                }

                val top = result.top1!!
                val historyResult = ScanResult(
                    scanId = result.scanId,
                    atJst = result.atJst,
                    entryTimeJst = result.entryTimeJst,
                    judgeTimeJst = result.judgeTimeJst,
                    candidates = listOf(
                        ScanCandidate(
                            rank = 1,
                            instrument = top.instrument,
                            display = top.instrument,
                            direction = top.direction,
                            grade = "C",
                            probability = top.confidence,
                            decision = "ENTRY",
                            score = top.score,
                            regime = top.regime,
                            regimeConfidence = top.confidence,
                            reasons = top.reasons
                        )
                    ),
                    warnings = emptyList(),
                    source = source
                )

                historyStore.add(historyResult)
                scheduleOutcomeTracking(historyResult)

                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteScan = result,
                    history = historyStore.load(),
                    oneMinuteStatus = "${if (source == "AUTO_1M") "1分AUTO" else "1分手動"}完了: " +
                        "${top.instrument} ${top.direction} / 1分後判定"
                )
            } catch (e: TimeoutCancellationException) {
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = "1分技術見送り: 市場Contextタイムアウト"
                )
            } catch (ce: CancellationException) {
                val current = _state.value.oneMinuteStatus
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = if (current?.contains("3分AUTO T-10を優先") == true) current else "1分スキャン停止"
                )
                throw ce
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    oneMinuteBusy = false,
                    oneMinuteStatus = "1分スキャン失敗: ${e.message}"
                )
            }
        }
    }

    private suspend fun performScan(source: String, autoBoundary: ZonedDateTime?) {
        val scanStarted = ZonedDateTime.now(jst)
        val manualEntryTarget = scanStarted.plusSeconds(10).withNano(0)

        // Raise the scan lock first so the rate loop cannot start a new request
        // between cancelAll() and the beginning of candle acquisition.
        _state.value = _state.value.copy(
            busy = true,
            scan = null,
            scannableCount = 0,
            lastScanExcluded = emptyMap(),
            lastCandleErrors = emptyMap(),
            lastCandleLatestMs = emptyMap(),
            quoteCandleDivergencePct = emptyMap(),
            lastScanAttemptMs = System.currentTimeMillis(),
            scanStatus = if (source == "AUTO") "AUTOスキャン実行中" else "手動スキャン実行中",
            error = null
        )

        // A non-critical rate refresh must never consume the T-10 scan window.
        repository.cancelInFlightRequests()

        try {
            val batch = if (source == "AUTO") {
                // AUTO starts at T-10. Do not let slow network publish after entry time.
                withTimeout(8_500) { repository.fetchAllCandles() }
            } else {
                // MANUAL entry is scan-start +10s. Data acquisition must finish before that.
                val remainingToEntry = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (remainingToEntry <= 1_200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scanStatus = "手動技術見送り: +10秒ENTRYまで時間不足"
                    )
                    return
                }
                withTimeout(minOf(8_000L, (remainingToEntry - 700L).coerceAtLeast(1_000L))) {
                    repository.fetchAllCandles()
                }
            }

            val candles = batch.candles
            val required = listOf("USDJPY", "EURJPY", "GBPJPY", "AUDJPY", "NZDJPY", "BTCJPY")
            val nowMs = System.currentTimeMillis()
            val latestTimes = required.associateWith { ins ->
                candles[ins].orEmpty().maxOfOrNull { it.timeEpochMs } ?: 0L
            }

            val excluded = linkedMapOf<String, String>()
            val eligible = linkedMapOf<String, List<Candle>>()

            required.forEach { ins ->
                val rows = candles[ins].orEmpty().sortedBy { it.timeEpochMs }
                val fetchError = batch.errors[ins]

                when {
                    fetchError != null -> excluded[ins] = "取得失敗: $fetchError"
                    rows.size < 21 -> excluded[ins] = "1分足不足 ${rows.size}/21"
                    else -> {
                        val last = rows.lastOrNull()?.timeEpochMs ?: 0L
                        val ageMs = if (last > 0L) (nowMs - last).coerceAtLeast(0L) else Long.MAX_VALUE
                        val expectedLastStartMs = ((nowMs / 60_000L) * 60_000L) - 60_000L
                        val latestLagMs = if (last > 0L) (expectedLastStartMs - last).coerceAtLeast(0L) else Long.MAX_VALUE

                        // Timestamp is the beginning of the completed M1 candle.
                        // 240s keeps short provider delays usable without accepting closed-market history.
                        val tail = rows.takeLast(30)
                        val gapPairs = tail.zipWithNext { a, b -> Triple(a.timeEpochMs, b.timeEpochMs, b.timeEpochMs - a.timeEpochMs) }
                        val unexpectedGaps = gapPairs.filter { (a, b, gap) ->
                            gap > 10L * 60_000L &&
                                !(ins != "BTCJPY" && isExpectedFxWeekendGap(a, b))
                        }
                        val spanMs = if (tail.size >= 2) tail.last().timeEpochMs - tail.first().timeEpochMs else Long.MAX_VALUE
                        val hasWeekendBridge = gapPairs.any { (a, b, gap) ->
                            gap > 10L * 60_000L && ins != "BTCJPY" && isExpectedFxWeekendGap(a, b)
                        }

                        when {
                            last <= 0L || latestLagMs > 5_000L ->
                                excluded[ins] = "直近完成1分足欠損 lag=${if (latestLagMs == Long.MAX_VALUE) "不明" else "${latestLagMs / 1000}s"}"
                            ageMs > 240_000L ->
                                excluded[ins] = "1分足STALE ${ageMs / 1000}s"
                            unexpectedGaps.isNotEmpty() ->
                                excluded[ins] = "1分足大欠損 gap=${unexpectedGaps.maxOf { it.third } / 60_000L}m"
                            !hasWeekendBridge && tail.size >= 30 && spanMs > 45L * 60_000L ->
                                excluded[ins] = "1分足欠損多発 span=${spanMs / 60_000L}m"
                            else -> eligible[ins] = rows
                        }
                    }
                }
            }

            val liveRates = _state.value.rates.associateBy { it.instrument }
            val divergence = linkedMapOf<String, Double>()
            eligible.forEach { (ins, rows) ->
                val q = liveRates[ins]
                val candleClose = rows.lastOrNull()?.close
                if (q?.price != null && q.freshnessStatus == "LIVE" &&
                    candleClose != null && candleClose > 0.0) {
                    val pct = kotlin.math.abs(q.price - candleClose) / candleClose * 100.0
                    divergence[ins] = pct
                }
            }

            val divergenceWarnings = divergence
                .filter { (ins, pct) -> pct >= if (ins == "BTCJPY") 1.50 else 0.50 }
                .map { (ins, pct) -> "$ins quote/candle乖離 ${"%.3f".format(pct)}%" }

            if (eligible.isEmpty()) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = 0,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン待機: " + excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // v0.7.8 production policy was validated by comparing all six instruments.
            // Never choose TOP1 from a partial universe because that changes the ranking distribution.
            if (eligible.size != required.size) {
                _state.value = _state.value.copy(
                    busy = false,
                    scannableCount = eligible.size,
                    lastScanExcluded = excluded,
                    lastCandleErrors = batch.errors,
                    lastCandleLatestMs = latestTimes,
                    quoteCandleDivergencePct = divergence,
                    scanStatus = "スキャン見送り: 6/6必須 (${eligible.size}/6) / " +
                        excluded.entries.joinToString(" / ") { "${it.key} ${it.value}" }
                )
                return
            }

            // MANUAL also has a hard publish deadline: scan-start +10 seconds.
            if (source == "MANUAL") {
                val remainingMs = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (remainingMs <= 500L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "手動技術見送り: +10秒ENTRY直前/超過"
                    )
                    return
                }
            }

            // AUTO result must still be ready before the target frame opens.
            if (source == "AUTO" && autoBoundary != null) {
                val remainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (remainingMs <= 400L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 対象枠開始まで${remainingMs.coerceAtLeast(0)}ms"
                    )
                    return
                }
            }

            val decisionTime = ZonedDateTime.now(jst)
            val entryTarget = if (source == "AUTO") autoBoundary else manualEntryTarget
            val result0 = withContext(Dispatchers.Default) {
                ruleEngine.scan(eligible, source, decisionTime, entryTarget)
            }

            if (source == "AUTO" && autoBoundary != null) {
                val publishRemainingMs = java.time.Duration.between(ZonedDateTime.now(jst), autoBoundary).toMillis()
                if (publishRemainingMs <= 200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "AUTO技術見送り: 判定完了が対象枠直前/開始後"
                    )
                    return
                }
            }

            if (source == "MANUAL") {
                val publishRemainingMs = java.time.Duration.between(
                    ZonedDateTime.now(jst), manualEntryTarget
                ).toMillis()
                if (publishRemainingMs <= 200L) {
                    _state.value = _state.value.copy(
                        busy = false,
                        scannableCount = eligible.size,
                        lastScanExcluded = excluded,
                        lastCandleErrors = batch.errors,
                        lastCandleLatestMs = latestTimes,
                        quoteCandleDivergencePct = divergence,
                        scanStatus = "手動技術見送り: 判定完了が+10秒ENTRY直前/超過"
                    )
                    return
                }
            }

            if (result0.candidates.isEmpty()) error("有効候補0件")
            if (result0.candidates.size != eligible.size) {
                error("候補数異常: ${result0.candidates.size}/${eligible.size}")
            }

            val expectedRanks = (1..result0.candidates.size).toSet()
            if (result0.candidates.map { it.rank }.toSet() != expectedRanks) {
                error("順位整合性エラー")
            }

            if (result0.candidates.any { it.direction !in setOf("HIGH", "LOW") }) {
                error("方向値エラー")
            }

            if (result0.candidates.any { !isKnownEntryContractGrade(it.grade) }) {
                error("未知ランク検出")
            }

            if (result0.candidates.any {
                    (it.grade in setOf("D", "E", "F", "G", "H", "I") && it.decision != "SKIP") ||
                    (it.grade !in setOf("D", "E", "F", "G", "H", "I") && it.decision != "ENTRY")
                }) {
                error("ENTRY/SKIP契約違反")
            }

            val coverageWarning = if (excluded.isNotEmpty()) {
                "6/6確認後に除外発生: " + excluded.entries.joinToString(", ") { "${it.key}=${it.value}" }
            } else null

            val result = result0.copy(
                warnings = result0.warnings + listOfNotNull(coverageWarning) + divergenceWarnings
            )

            historyStore.add(result)
            scheduleOutcomeTracking(result)

            _state.value = _state.value.copy(
                busy = false,
                scan = result,
                history = historyStore.load(),
                lastScanSuccessMs = System.currentTimeMillis(),
                scannableCount = eligible.size,
                lastScanExcluded = excluded,
                lastCandleErrors = batch.errors,
                lastCandleLatestMs = latestTimes,
                quoteCandleDivergencePct = divergence,
                scanStatus = coverageWarning ?: "スキャン完了 ${eligible.size}/6",
                error = null
            )
        } catch (e: TimeoutCancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "${source}スキャン失敗: 市場データ取得タイムアウト",
                error = null
            )
        } catch (ce: CancellationException) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = if (source == "AUTO") "AUTOスキャン停止" else "スキャン停止",
                error = null
            )
            throw ce
        } catch (e: Exception) {
            _state.value = _state.value.copy(
                busy = false,
                scanStatus = "スキャン失敗: ${e.message}",
                error = null
            )
        }
    }

    private fun scheduleOutcomeTracking(result: ScanResult) {
        val top = result.top1 ?: return
        if (top.decision != "ENTRY") return
        val scanId = result.scanId
        if (scanId.isBlank()) return
        if (outcomeJobs[scanId]?.isActive == true) return

        val job = viewModelScope.launch {
            try {
                val entryTarget = ZonedDateTime.parse(result.entryTimeJst)
                val judgeTarget = ZonedDateTime.parse(result.judgeTimeJst)

                var row = historyStore.load().firstOrNull { it.scanId == scanId } ?: return@launch

                if (row.resultStatus == "WAIT_ENTRY") {
                    delayUntil(entryTarget)
                    val entryRate = fetchOutcomeRateAtTarget(top.instrument, entryTarget)
                    if (entryRate == null) {
                        historyStore.markEntryMissed(scanId)
                        refreshHistory("結果追跡: ENTRYレート取得失敗/時刻超過")
                        return@launch
                    }

                    historyStore.updateEntryRate(
                        scanId = scanId,
                        rate = entryRate.price,
                        source = entryRate.source,
                        capturedAtJst = entryRate.capturedAtJst,
                        captureDelayMs = entryRate.captureDelayMs,
                        providerAgeSeconds = entryRate.providerAgeSeconds
                    )
                    refreshHistory("結果追跡: ENTRY ${top.instrument} ${formatOutcomeRate(entryRate.price)}")
                    row = historyStore.load().firstOrNull { it.scanId == scanId } ?: return@launch
                }

                if (row.resultStatus != "WAIT_JUDGE") return@launch

                delayUntil(judgeTarget)
                val judgeRate = fetchOutcomeRateAtTarget(top.instrument, judgeTarget)
                if (judgeRate == null) {
                    historyStore.markJudgeMissed(scanId)
                    refreshHistory("結果追跡: 判定レート取得失敗/時刻超過")
                    return@launch
                }

                historyStore.settle(
                    scanId = scanId,
                    judgeRate = judgeRate.price,
                    source = judgeRate.source,
                    settledAtJst = judgeRate.capturedAtJst,
                    captureDelayMs = judgeRate.captureDelayMs,
                    providerAgeSeconds = judgeRate.providerAgeSeconds
                )
                refreshHistory("結果確定: ${top.instrument}")
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                refreshHistory("結果追跡エラー: ${e.message ?: e::class.java.simpleName}")
            } finally {
                outcomeJobs.remove(scanId)
            }
        }

        outcomeJobs[scanId] = job
    }

    private fun resumePendingOutcomes() {
        historyStore.pending().forEach { h ->
            if (h.scanId.isBlank() || h.entryTimeJst.isBlank() || h.judgeTimeJst.isBlank()) {
                return@forEach
            }

            val synthetic = ScanResult(
                scanId = h.scanId,
                atJst = h.atJst,
                entryTimeJst = h.entryTimeJst,
                judgeTimeJst = h.judgeTimeJst,
                candidates = listOf(
                    ScanCandidate(
                        rank = h.candidateRank,
                        instrument = h.instrument,
                        display = h.instrument,
                        direction = h.direction,
                        grade = h.grade,
                        probability = null,
                        decision = h.decision,
                        regime = h.regime
                    )
                ),
                source = h.source
            )
            scheduleOutcomeTracking(synthetic)
        }
    }

    private suspend fun delayUntil(target: ZonedDateTime) {
        val waitMs = java.time.Duration.between(ZonedDateTime.now(jst), target).toMillis()
        if (waitMs > 0L) delay(waitMs)
    }

    private data class CapturedOutcomeRate(
        val price: Double,
        val source: String,
        val capturedAtJst: String,
        val captureDelayMs: Long,
        val providerAgeSeconds: Double
    )

    private suspend fun fetchOutcomeRateAtTarget(
        instrument: String,
        target: ZonedDateTime
    ): CapturedOutcomeRate? {
        val nowAtStart = ZonedDateTime.now(jst)

        // We cannot reconstruct a true historic tick after this window has passed.
        if (nowAtStart.isAfter(target.plusSeconds(6))) return null

        val hardDeadline = target.plusSeconds(6)

        while (ZonedDateTime.now(jst).isBefore(hardDeadline)) {
            try {
                val r = withTimeout(2_500) { outcomeRepository.fetchRate(instrument) }
                val now = ZonedDateTime.now(jst)
                val lateMs = java.time.Duration.between(target, now).toMillis()
                val price = r.price
                val ageSeconds = r.ageSeconds

                val providerQuoteAt = if (ageSeconds != null && ageSeconds.isFinite()) {
                    now.minusNanos((ageSeconds.coerceAtLeast(0.0) * 1_000_000_000.0).toLong())
                } else null

                val quoteVsTargetMs = providerQuoteAt?.let {
                    java.time.Duration.between(target, it).toMillis()
                }

                val maxProviderAge = when {
                    r.source.startsWith("bitbank") -> 5.0
                    r.source.startsWith("Yahoo") -> 15.0
                    else -> 5.0
                }

                val minQuoteVsTargetMs = when {
                    r.source.startsWith("Yahoo") -> -2_000L
                    else -> -1_000L
                }

                if (
                    price != null &&
                    price.isFinite() &&
                    price > 0.0 &&
                    r.freshnessStatus == "LIVE" &&
                    ageSeconds != null &&
                    ageSeconds.isFinite() &&
                    ageSeconds in 0.0..maxProviderAge &&
                    lateMs in 0L..6_000L &&
                    quoteVsTargetMs != null &&
                    quoteVsTargetMs in minQuoteVsTargetMs..6_000L
                ) {
                    return CapturedOutcomeRate(
                        price = price,
                        source = r.source,
                        capturedAtJst = now.toString(),
                        captureDelayMs = lateMs,
                        providerAgeSeconds = ageSeconds
                    )
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Throwable) {
                // Retry only inside the narrow official capture window.
            }

            delay(250)
        }

        return null
    }

    private fun refreshHistory(status: String) {
        _state.value = _state.value.copy(
            history = historyStore.load(),
            outcomeStatus = status
        )
    }

    private fun formatOutcomeRate(v: Double): String =
        if (v >= 1_000_000.0) "%,.0f".format(v) else "%.3f".format(v)

    fun buildDiagnosticJson(): String {
        val s = _state.value
        val root = JSONObject()
            .put("generated_at_jst", ZonedDateTime.now(jst).toString())
            .put("app", "GMK MOBILE Rule v${BuildConfig.VERSION_NAME}")
            .put("version_code", BuildConfig.VERSION_CODE)
            .put("connected_6", s.connected)
            .put("available_6", allRatesAvailable(s.rates))
            .put("live_6", allFresh(s.rates))
            .put("busy", s.busy)
            .put("error", s.error ?: JSONObject.NULL)
            .put("rate_status", s.rateStatus ?: JSONObject.NULL)
            .put("scan_status", s.scanStatus ?: JSONObject.NULL)
            .put("auto_scan", s.autoScan)
            .put("fx_provider", "YahooFinanceChart-keyless")
            .put("fx_provider_official_api", false)
            .put("fx_provider_freshness_gate_seconds", 75)
            .put("btc_provider", "bitbank-public")
            .put("last_rate_update_ms", s.lastRateUpdateMs)
            .put("last_rate_success_ms", s.lastRateSuccessMs)
            .put("last_auto_boundary_key", lastAutoBoundaryKey ?: JSONObject.NULL)
            .put("last_scan_attempt_ms", s.lastScanAttemptMs)
            .put("last_scan_success_ms", s.lastScanSuccessMs)
            .put("rate_live_count", s.rateLiveCount)
            .put("rate_available_count", s.rateAvailableCount)
            .put("scannable_count", s.scannableCount)
            .put("last_scan_excluded", JSONObject(s.lastScanExcluded))
            .put("last_candle_errors", JSONObject(s.lastCandleErrors))
            .put("last_candle_latest_ms", JSONObject(s.lastCandleLatestMs))
            .put("quote_candle_divergence_pct", JSONObject(s.quoteCandleDivergencePct))
            .put("last_scan_full_coverage", s.scan?.candidates?.size == 6)
            .put("last_scan_candidate_count", s.scan?.candidates?.size ?: 0)
            .put("one_minute_mode", "SMARTPHONE_LOCAL_1M")
            .put("one_minute_auto_scan", s.oneMinuteAutoScan)
            .put("one_minute_busy", s.oneMinuteBusy)
            .put("one_minute_status", s.oneMinuteStatus ?: JSONObject.NULL)
            .put("outcome_status", s.outcomeStatus ?: JSONObject.NULL)
            .put("outcome_pending_count", s.history.count { it.resultStatus == "WAIT_ENTRY" || it.resultStatus == "WAIT_JUDGE" })
            .put("outcome_win_count", s.history.count { it.resultStatus == "WIN" })
            .put("outcome_lose_count", s.history.count { it.resultStatus == "LOSE" })
            .put("entry_win_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "WIN" })
            .put("entry_lose_count", s.history.count { it.decision == "ENTRY" && it.resultStatus == "LOSE" })
            .put("skip_shadow_resolved_count", s.history.count {
                it.decision == "SKIP" && it.resultStatus in setOf("WIN", "LOSE")
            })
        val rates = JSONArray()
        s.rates.forEach { r -> rates.put(JSONObject()
            .put("instrument", r.instrument).put("price", r.price ?: JSONObject.NULL)
            .put("bid", r.bid ?: JSONObject.NULL).put("ask", r.ask ?: JSONObject.NULL)
            .put("source", r.source).put("age_seconds", r.ageSeconds ?: JSONObject.NULL)
            .put("freshness", r.freshnessStatus)) }
        root.put("rates", rates)
        val historyJson = JSONArray()
        s.history.take(30).forEach { h ->
            historyJson.put(JSONObject()
                .put("scan_id", h.scanId)
                .put("source", h.source)
                .put("instrument", h.instrument)
                .put("direction", h.direction)
                .put("grade", h.grade)
                .put("decision", h.decision)
                .put("entry_time_jst", h.entryTimeJst)
                .put("judge_time_jst", h.judgeTimeJst)
                .put("entry_rate", h.entryRate ?: JSONObject.NULL)
                .put("judge_rate", h.judgeRate ?: JSONObject.NULL)
                .put("entry_capture_delay_ms", h.entryCaptureDelayMs ?: JSONObject.NULL)
                .put("judge_capture_delay_ms", h.judgeCaptureDelayMs ?: JSONObject.NULL)
                .put("entry_provider_age_seconds", h.entryProviderAgeSeconds ?: JSONObject.NULL)
                .put("judge_provider_age_seconds", h.judgeProviderAgeSeconds ?: JSONObject.NULL)
                .put("result_status", h.resultStatus))
        }
        root.put("result_history", historyJson)

        s.oneMinuteScan?.let { scan ->
            root.put("last_one_minute_manual", JSONObject()
                .put("scan_id", scan.scanId)
                .put("source", scan.source)
                .put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst)
                .put("judge_time_jst", scan.judgeTimeJst)
                .put("candidate_count", scan.candidates.size)
                .put("top1", scan.top1?.let { c ->
                    JSONObject()
                        .put("instrument", c.instrument)
                        .put("direction", c.direction)
                        .put("confidence", c.confidence)
                        .put("regime", c.regime)
                        .put("score", c.score)
                        .put("reasons", JSONArray(c.reasons))
                } ?: JSONObject.NULL))
        }

        s.scan?.let { scan ->
            val cands = JSONArray()
            scan.candidates.forEach { c -> cands.put(JSONObject()
                .put("rank", c.rank).put("instrument", c.instrument).put("direction", c.direction)
                .put("grade", c.grade).put("probability", c.probability ?: JSONObject.NULL)
                .put("decision", c.decision).put("score", c.score)
                .put("regime", c.regime)
                .put("regime_confidence", c.regimeConfidence)
                .put("reasons", JSONArray(c.reasons))) }
            root.put("last_scan", JSONObject()
                .put("scan_id", scan.scanId).put("source", scan.source).put("at_jst", scan.atJst)
                .put("entry_time_jst", scan.entryTimeJst).put("judge_time_jst", scan.judgeTimeJst)
                .put("warnings", JSONArray(scan.warnings)).put("candidates", cands))
        }
        return root.toString(2)
    }

    private fun syncForegroundRuntimeService() {
        val app = getApplication<Application>()
        val intent = Intent(app, GmkRuntimeKeepAliveService::class.java)
        if (prefs.autoScan || prefs.oneMinuteAutoScan) {
            ContextCompat.startForegroundService(app, intent)
        } else {
            app.stopService(intent)
        }
    }

    fun setOneMinuteAuto(value: Boolean) {
        prefs.oneMinuteAutoScan = value
        _state.value = _state.value.copy(oneMinuteAutoScan = value)
        startOneMinuteAutoLoop()
        syncForegroundRuntimeService()
    }

    fun setAuto(value: Boolean) {
        prefs.autoScan = value
        _state.value = _state.value.copy(autoScan = value)
        startAutoLoop()
        syncForegroundRuntimeService()
    }

    fun loadHistory() {
        _state.value = _state.value.copy(history = historyStore.load())
    }

    fun saveSettings(token: String, accountId: String, environment: String, yahooFallback: Boolean) {
        // v0.7.8: OANDA runtime dependency removed. Keep signature only for source compatibility.
        prefs.yahooFallback = true
        _state.value = _state.value.copy(
            oandaToken = prefs.oandaToken,
            oandaAccountId = prefs.oandaAccountId,
            oandaEnvironment = prefs.oandaEnvironment,
            yahooFallback = true,
            rateStatus = "設定を保存しました。レート再接続中",
            error = null
        )
        startRateLoop()
    }

    fun shutdownRuntime() {
        rateJob?.cancel()
        autoJob?.cancel()
        oneMinuteAutoJob?.cancel()
        oneMinuteJob?.cancel()
        outcomeJobs.values.forEach { it.cancel() }
        repository.cancelInFlightRequests()
        outcomeRepository.cancelInFlightRequests()
    }

    override fun onCleared() {
        shutdownRuntime()
        super.onCleared()
    }
}

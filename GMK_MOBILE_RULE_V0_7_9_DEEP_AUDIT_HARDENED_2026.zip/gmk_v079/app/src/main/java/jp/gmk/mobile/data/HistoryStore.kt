package jp.gmk.mobile.data

import android.content.Context
import jp.gmk.mobile.domain.HistoryRow
import jp.gmk.mobile.domain.ScanResult
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("gmk_mobile_history", Context.MODE_PRIVATE)

    @Synchronized
    fun add(result: ScanResult) {
        val top = result.top1 ?: return
        val current = load().toMutableList()

        if (result.source.startsWith("AUTO")) {
            current.removeAll {
                it.source == result.source && it.judgeTimeJst == result.judgeTimeJst
            }
        }

        current.add(0, HistoryRow(
            id = System.currentTimeMillis(),
            scanId = result.scanId,
            source = result.source,
            atJst = result.atJst,
            instrument = top.instrument,
            direction = top.direction,
            grade = top.grade,
            decision = top.decision,
            candidateRank = top.rank,
            regime = top.regime,
            entryTimeJst = result.entryTimeJst,
            judgeTimeJst = result.judgeTimeJst,
            resultStatus = if (top.decision == "ENTRY") "WAIT_ENTRY" else "SKIP"
        ))
        save(current.take(200))
    }

    @Synchronized
    fun load(): List<HistoryRow> {
        fun decode(text: String): List<HistoryRow>? {
            val array = try {
                JSONArray(text)
            } catch (_: Throwable) {
                return null
            }

            return buildList {
                for (i in 0 until array.length()) {
                    val x = array.optJSONObject(i) ?: continue
                    val instrument = x.optString("instrument")
                    val direction = x.optString("direction")
                    if (instrument.isBlank() || direction !in setOf("HIGH", "LOW")) continue

                    val grade = x.optString("grade", x.optString("rank", "D")).uppercase()
                    if (!isKnownGrade(grade)) continue

                    val decision = x.optString("decision").uppercase().ifBlank {
                        if (grade in setOf("D", "E", "F", "G", "H", "I")) "SKIP" else "ENTRY"
                    }
                    if (decision !in setOf("ENTRY", "SKIP")) continue

                    add(HistoryRow(
                        id = x.optLong("id").takeIf { it > 0L } ?: System.currentTimeMillis(),
                        scanId = x.optString("scan_id", ""),
                        source = x.optString("source"),
                        atJst = x.optString("at_jst"),
                        instrument = instrument,
                        direction = direction,
                        grade = grade,
                        decision = decision,
                        candidateRank = x.optInt("candidate_rank", 1).coerceAtLeast(1),
                        regime = x.optString("regime", "UNKNOWN"),
                        entryTimeJst = x.optString("entry_time_jst", ""),
                        judgeTimeJst = x.optString("judge_time_jst", ""),
                        entryRate = x.optDouble("entry_rate").takeIf { x.has("entry_rate") && !x.isNull("entry_rate") },
                        judgeRate = x.optDouble("judge_rate").takeIf { x.has("judge_rate") && !x.isNull("judge_rate") },
                        entryRateSource = x.optString("entry_rate_source", ""),
                        judgeRateSource = x.optString("judge_rate_source", ""),
                        entryCapturedAtJst = x.optString("entry_captured_at_jst", ""),
                        settledAtJst = x.optString("settled_at_jst", ""),
                        entryCaptureDelayMs = x.optLong("entry_capture_delay_ms").takeIf {
                            x.has("entry_capture_delay_ms") && !x.isNull("entry_capture_delay_ms")
                        },
                        judgeCaptureDelayMs = x.optLong("judge_capture_delay_ms").takeIf {
                            x.has("judge_capture_delay_ms") && !x.isNull("judge_capture_delay_ms")
                        },
                        entryProviderAgeSeconds = x.optDouble("entry_provider_age_seconds").takeIf {
                            x.has("entry_provider_age_seconds") && !x.isNull("entry_provider_age_seconds")
                        },
                        judgeProviderAgeSeconds = x.optDouble("judge_provider_age_seconds").takeIf {
                            x.has("judge_provider_age_seconds") && !x.isNull("judge_provider_age_seconds")
                        },
                        resultStatus = if (x.has("result_status")) {
                            x.optString("result_status", "LEGACY_NO_OUTCOME")
                        } else if (decision == "SKIP") {
                            "SKIP"
                        } else {
                            val legacyScanId = x.optString("scan_id", "")
                            val legacyEntry = x.optString("entry_time_jst", "")
                            val legacyJudge = x.optString("judge_time_jst", "")
                            if (legacyScanId.isBlank() || legacyEntry.isBlank() || legacyJudge.isBlank()) {
                                "LEGACY_NO_OUTCOME"
                            } else {
                                "WAIT_ENTRY"
                            }
                        }
                    ))
                }
            }
        }

        val primary = prefs.getString("items", "[]") ?: "[]"
        decode(primary)?.let { return it }

        // Preserve the broken primary and try the last known-good snapshot.
        prefs.edit().putString("items_corrupt_last", primary.take(200_000)).commit()

        val backup = prefs.getString("items_backup", "[]") ?: "[]"
        val recovered = decode(backup)
        if (recovered != null) {
            prefs.edit()
                .putString("items", backup)
                .putBoolean("history_recovered_from_backup", true)
                .commit()
            return recovered
        }

        return emptyList()
    }

    private fun isKnownGrade(grade: String): Boolean {
        if (grade in setOf("S", "A", "B", "C", "D", "E", "F", "G", "H", "I")) return true
        if (!grade.startsWith("C")) return false
        val n = grade.removePrefix("C").toIntOrNull() ?: return false
        return n in 1..10
    }

    @Synchronized
    fun updateEntryRate(
        scanId: String,
        rate: Double,
        source: String,
        capturedAtJst: String,
        captureDelayMs: Long,
        providerAgeSeconds: Double
    ) {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return
        val h = rows[idx]
        if (h.resultStatus != "WAIT_ENTRY") return
        if (!rate.isFinite() || rate <= 0.0) return
        if (!providerAgeSeconds.isFinite() || providerAgeSeconds < 0.0) return
        rows[idx] = h.copy(
            entryRate = rate,
            entryRateSource = source,
            entryCapturedAtJst = capturedAtJst,
            entryCaptureDelayMs = captureDelayMs,
            entryProviderAgeSeconds = providerAgeSeconds,
            resultStatus = "WAIT_JUDGE"
        )
        save(rows)
    }

    @Synchronized
    fun markEntryMissed(scanId: String, reason: String = "ENTRY_RATE_MISSED") {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return
        if (rows[idx].resultStatus != "WAIT_ENTRY") return
        rows[idx] = rows[idx].copy(resultStatus = reason)
        save(rows)
    }

    @Synchronized
    fun settle(
        scanId: String,
        judgeRate: Double,
        source: String,
        settledAtJst: String,
        captureDelayMs: Long,
        providerAgeSeconds: Double
    ) {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return

        val h = rows[idx]
        if (h.resultStatus != "WAIT_JUDGE") return
        if (!judgeRate.isFinite() || judgeRate <= 0.0) return
        if (!providerAgeSeconds.isFinite() || providerAgeSeconds < 0.0) return
        val entry = h.entryRate
        if (entry == null) {
            rows[idx] = h.copy(
                judgeRate = judgeRate,
                judgeRateSource = source,
                settledAtJst = settledAtJst,
                resultStatus = "ENTRY_RATE_MISSING"
            )
            save(rows)
            return
        }

        // DRAW is directional LOSE by specification.
        val win = when (h.direction) {
            "HIGH" -> judgeRate > entry
            "LOW" -> judgeRate < entry
            else -> false
        }

        rows[idx] = h.copy(
            judgeRate = judgeRate,
            judgeRateSource = source,
            settledAtJst = settledAtJst,
            judgeCaptureDelayMs = captureDelayMs,
            judgeProviderAgeSeconds = providerAgeSeconds,
            resultStatus = if (win) "WIN" else "LOSE"
        )
        save(rows)
    }

    @Synchronized
    fun markJudgeMissed(scanId: String, reason: String = "JUDGE_RATE_MISSED") {
        val rows = load().toMutableList()
        val idx = rows.indexOfFirst { it.scanId == scanId }
        if (idx < 0) return
        if (rows[idx].resultStatus != "WAIT_JUDGE") return
        rows[idx] = rows[idx].copy(resultStatus = reason)
        save(rows)
    }

    @Synchronized
    fun pending(): List<HistoryRow> =
        load().filter { it.decision == "ENTRY" && it.resultStatus in setOf("WAIT_ENTRY", "WAIT_JUDGE") }

    private fun save(rows: List<HistoryRow>) {
        val a = JSONArray()
        rows.forEach { h ->
            a.put(JSONObject()
                .put("id", h.id)
                .put("scan_id", h.scanId)
                .put("source", h.source)
                .put("at_jst", h.atJst)
                .put("instrument", h.instrument)
                .put("direction", h.direction)
                .put("grade", h.grade)
                .put("decision", h.decision)
                .put("candidate_rank", h.candidateRank)
                .put("regime", h.regime)
                .put("entry_time_jst", h.entryTimeJst)
                .put("judge_time_jst", h.judgeTimeJst)
                .put("entry_rate", h.entryRate ?: JSONObject.NULL)
                .put("judge_rate", h.judgeRate ?: JSONObject.NULL)
                .put("entry_rate_source", h.entryRateSource)
                .put("judge_rate_source", h.judgeRateSource)
                .put("entry_captured_at_jst", h.entryCapturedAtJst)
                .put("settled_at_jst", h.settledAtJst)
                .put("entry_capture_delay_ms", h.entryCaptureDelayMs ?: JSONObject.NULL)
                .put("judge_capture_delay_ms", h.judgeCaptureDelayMs ?: JSONObject.NULL)
                .put("entry_provider_age_seconds", h.entryProviderAgeSeconds ?: JSONObject.NULL)
                .put("judge_provider_age_seconds", h.judgeProviderAgeSeconds ?: JSONObject.NULL)
                .put("result_status", h.resultStatus))
        }
        val payload = a.toString()
        val previous = prefs.getString("items", null)

        // Write the current valid payload as backup before replacing primary.
        val editor = prefs.edit()
        if (!previous.isNullOrBlank()) {
            try {
                JSONArray(previous)
                editor.putString("items_backup", previous)
            } catch (_: Throwable) {
                // Do not promote a corrupt primary into backup.
            }
        }
        editor.putString("items", payload)
        editor.putBoolean("history_recovered_from_backup", false)
        editor.commit()
    }
}

# GMK Mobile Rule v0.7.7 深掘り修正

- OANDA runtime依存を削除。FXはYahoo Finance Chart keyless経路をprimary化（query1/query2）。
- BTCJPYはbitbank Public API継続。
- E/F/G/H/IをHistoryStore既知ランクへ追加。旧E等のdecision欠落時はSKIPへ復元。
- FinalRankPolicyの実機で一致不能な emaBin=nan 3ルールを削除。
- 9〜23時・E=SKIP・freshness gateは維持。
- Yahoo Finance Chartは非公式/内部APIのため、LIVE鮮度判定・二重host・timeout・LASTキャッシュでfail-safe運用。

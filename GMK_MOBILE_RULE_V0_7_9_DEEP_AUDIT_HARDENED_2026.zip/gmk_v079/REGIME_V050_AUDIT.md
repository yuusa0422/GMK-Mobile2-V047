# GMK MOBILE Rule v0.5.0 — Dedicated Regime Classifier

## Added regimes
- TREND_UP
- TREND_DOWN
- RANGE
- CHOPPY

## Evidence used
All features are calculated from completed 1-minute candles only:
- EMA8/EMA21 separation normalized by ATR
- EMA8 3-minute slope normalized by ATR
- 12-bar efficiency ratio
- one-minute direction alternation ratio
- directional persistence
- EMA sign-flip ratio
- Bollinger width expansion/contraction
- ATR

## Hard guards
- TREND_UP + LOW candidate => D / SKIP
- TREND_DOWN + HIGH candidate => D / SKIP
- CHOPPY => D / SKIP
- TREND_SWITCH counter-trend => D / SKIP
- TREND_SWITCH with <3/4 confirmation votes => D / SKIP
- RANGE outer-Bollinger chase => confidence capped to C; never reverse the direction

## Diagnostics
Each candidate records:
- regime
- regime_confidence
- trend/range/choppy evidence
- efficiency ratio
- alternation ratio
- EMA gap/ATR
- EMA slope/ATR

This classifier is deterministic and on-device. It does not call an LLM or server.

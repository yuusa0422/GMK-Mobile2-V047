# GMK MOBILE Rule v0.5.3 深掘り横断監査・修正

## V0.5.2から新たに確認した不具合

1. レート更新ループがスキャン中にもYahoo/OANDAへ通信していた
   - AUTO T-10のローソク取得と競合し、タイムアウト・429・DNS失敗を増やす可能性。
   - 修正: busy中はレート更新を一時停止。

2. rateSummaryがscanのエラー表示を6秒ごとに上書き
   - スキャン不能理由がすぐ消える。
   - 修正: rateStatus / scanStatusを完全分離。

3. AUTOスキャンの通信に15秒まで掛かり、対象5分枠開始後に結果を出す可能性
   - 修正: AUTO取得8.5秒タイムアウト + 対象枠開始400ms前を過ぎた結果は採用しない。

4. AUTOの同一5秒窓で失敗時に再実行され得る設計を監査
   - 修正: 対象boundary keyを処理開始前に固定。同一枠は必ず1回。

5. bitbank 1分足で毎回「前日＋当日」の2 HTTP要求
   - 不要な遅延。
   - 修正: 当日を先に取得し30本未満の時だけ前日取得。

6. ローソク足のOHLC整合性チェック不足
   - high<open/close、low>open/close等の異常値がルールへ入る可能性。
   - 修正: finite/positive/OHLC整合性/時刻重複を正規化して除外。

7. 一時的ネットワーク失敗に再試行なし
   - 修正: Yahoo/OANDA/bitbank HTTPへ短い2回リトライ。

8. 履歴のrankフィールドに実際はgradeを保存していた
   - データ名と内容が不一致。
   - 修正: gradeとcandidateRankを分離。旧履歴も読み込める移行処理。

9. 履歴画面で時刻・ENTRY/SKIP・REGIME・候補順位が見えない
   - 修正: 表示追加。

10. network_security_config.xmlが存在するのにManifestから参照されていなかった
    - 修正: android:networkSecurityConfigを明示。

11. 旧GitHub ActionsがversionCode=47/versionName=0.4.7-localへ強制書換え
    - 新版をビルドしてもAPKメタデータが旧版へ戻る。
    - 修正: V0.5.3同梱workflowはSOURCEのversionを一切上書きしない。

## 維持
- 5分枠T-10 AUTO。
- 3分判定。
- DのみSKIP。
- REGIMEだけでDを量産しない。
- トレンド切替直後の逆張りはD/SKIP。
- 古い足をLIVEとして判定しない。
- 部分取得時は利用可能通貨を明示し、除外理由を保存。

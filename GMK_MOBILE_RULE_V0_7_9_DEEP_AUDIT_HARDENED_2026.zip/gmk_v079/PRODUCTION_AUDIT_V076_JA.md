# GMK MOBILE RULE v0.7.7 本番深掘り監査

## 修正済み重大不具合
1. HistoryStore が E/F/G/H/I を未知ランクとして破棄する不具合を修正。decision欠落の旧E以下はSKIPとして復元。
2. 研究側のEMAビン生成で `nan` になったBTCJPYルール3件が実機では一致不能だった不整合を修正。3ルールを本番表から除外し、実機と同じ `2.5+` ビン定義で再Replay。
3. OANDA runtime依存を削除。FXは口座/APIキー不要のYahoo Finance Chart (query1/query2) をprimary化。BTCJPYはbitbank Public API。
4. 設定画面からOANDA Token/Account入力を撤去。保存済み旧値は互換目的のみで、runtimeでは未使用。

## 2026年 実機相当Replay (09:00-23:00)
- 全枠: 38,640
- ENTRY: 23,721
- E/SKIP: 14,919
- 採点可能ENTRY: 20,930
- 全体勝率: 56.8944%
- 1-4月: 56.1538% (n=10,920)
- 5-6月: 57.5451% (n=5,540)
- 7-8/18: 57.8971% (n=4,470)
- A: 70.8487% (n=271)
- B: 64.2434% (n=3,040)
- C: 55.4118% (n=17,619)
- SKIP群をそのまま取った場合の勝率: 48.0801%

## Provider fail-safe
- Yahoo FXは75秒を超えた値をLAST扱い。scan側は鮮度/ローソク足検証で除外。
- query1/query2の2ホストで冗長化。HTTP 429/5xxは短いretry。
- BTCJPYはbitbank ticker 15秒閾値。
- Provider障害時は古い表示値をENTRYへ流用しない。

## 追加深掘り修正
5. SKIP履歴が `WAIT_ENTRY` のまま残る表示/状態不整合を修正。SKIPは保存時点で `resultStatus=SKIP`。
6. 6通貨未満の部分スキャンでTOP1を選ぶReplay不整合を修正。3分本番は6/6必須、欠けた場合は見送り。
7. 09:00-23:00外でAUTOがE/SKIP履歴を量産する問題を修正。時間外は3分AUTO/手動とも判定を開始しない。
8. 本番固定ルールは実機一致不能3件を除き248ルール。

## 検証
- functional contract: 18/18 PASS
- domain Kotlin compile (Models/FinalRankPolicy/LocalRuleEngine/OneMinuteLocalEngine): PASS
- Android full Gradle compile: この作業環境にGradle実行ファイルがないため未実行。GitHub build workflowにはcompile/assemble手順を保持。

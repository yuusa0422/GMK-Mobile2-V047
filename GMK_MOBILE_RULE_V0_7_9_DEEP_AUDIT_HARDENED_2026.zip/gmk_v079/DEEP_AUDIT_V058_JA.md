# GMK MOBILE Rule v0.5.8 追加深掘り監査

V0.5.7からさらに修正した不具合:

1. 端末スリープ/OS停止でT-10を丸ごと跨いだ場合、:55以降に復帰するとMISSED記録すら残らない
- scheduler heartbeatを追加。
- 前回tickから1.5秒以上空き、その間にT-10を跨いだらAUTO_SCAN_MISSEDを記録。
- late recoveryはしない。

2. アプリプロセス再起動でlastAutoBoundaryKeyが消え、同一slotを二重実行できる
- lastAutoBoundaryKeyをSharedPreferencesへ永続化。

3. FX週明け直後、OANDAの120本に週末gapが含まれると「大欠損」と誤判定
- Friday→Sunday/Mondayの24〜80時間gapだけを期待される市場休場gapとして許容。
- BTCには適用しない。

4. Yahoo candle range=1dのため月曜早朝に必要本数が不足しやすい
- candle取得だけrange=5dへ変更。
- quoteは1dのまま。

5. 一律30本必須で、EMA21等が計算可能でも不要にSKIP
- 最小必要本数を21本へ変更。
- 未来足・進行中足は引き続き禁止。

6. REGIME cautionがC候補をDへ落とし、実質D/SKIPを増やせる
- REGIME cautionだけでは0.55未満へ落とさない。
- 真のtrend-switch逆張りhard guardだけはD可。

7. ENTRY/SKIP検証が「D以外なら全部ENTRY」だった
- 未知gradeでもENTRY扱いになる穴を修正。
- S/A/B/C/C1〜C10はENTRY、DはSKIP、未知gradeはエラー。

8. LocalRuleEngine側も同じく未知gradeをENTRY扱いしていた
- isEntryGrade()を追加しC1〜C10互換を明示。

9. 履歴primary JSON破損時、空履歴へ落ちるだけで自動復元しない
- last-known-good backupを追加。
- primary破損時はbackupから自動復元。
- corrupt payloadは診断用に保持。

10. 履歴内の未知grade / 不正decisionをそのまま表示できる
- load時validation追加。

11. Yahoo失敗メッセージの一部がsafeErrorを通っていなかった
- 例外文字列をsanitizerへ統一。

# GMK MOBILE Rule v0.6.0 追加深掘り監査

V0.5.9からさらに修正:
1. ViewModel=21本 / Engine=30本の不整合を21本へ統一。
2. 週明けgapを3分/5分momentumとして誤計算しないよう連続足だけでreturn計算。
3. trend-switchは直近4本が連続時だけ有効。
4. REGIME短期構造は最後の大gap以降のcontinuous tailを使用。
5. Yahooはchart closeとregularMarketPriceのtimestampを比較し新しい方を採用。
6. generic candle sanitizerでもcurrent/future minuteを除外。
7. AUTO ON時、T-10まで20秒以内のMANUAL開始を保留してAUTO優先。
8. AUTO同一slotの履歴をjudgeTimeで重複排除。

D/SKIP:
- DのみSKIP。
- REGIME cautionだけでDへ落とさない。
- 真のtrend-switch逆張りhard guardは維持。
